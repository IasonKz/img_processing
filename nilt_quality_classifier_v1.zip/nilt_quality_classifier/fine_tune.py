from __future__ import annotations

import argparse
import multiprocessing as mp

from qc.config import load_yaml
from qc.finetuning import run_fine_tuning


def main() -> None:
    parser = argparse.ArgumentParser(description="Fine-tune an existing GOOD/BAD model.")
    parser.add_argument("--config", required=True, help="Path to a fine-tuning YAML file")
    args = parser.parse_args()
    result = run_fine_tuning(load_yaml(args.config))
    print(f"\nCandidate model: {result['best_model']}")
    print(f"Run directory: {result['run_dir']}")


if __name__ == "__main__":
    mp.freeze_support()
    main()
