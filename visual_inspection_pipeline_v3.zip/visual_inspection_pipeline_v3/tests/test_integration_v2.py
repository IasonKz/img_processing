"""File lifecycle and orchestration tests; prediction is explicitly mocked.

These tests verify hashes, relocation, frozen policies and output contracts.
They do not execute neural networks and must not be reported as model validation.
"""
from __future__ import annotations

import copy
from pathlib import Path
import shutil
import tempfile
import unittest
from types import SimpleNamespace
from contextlib import ExitStack
from unittest.mock import patch

import numpy as np
from PIL import Image

from nilt.common import DEFAULTS, merge_dict, read_json, sha_file, write_csv, write_json
from nilt.data import pixel_signature


def fixture_run(base, name="old", threshold=5.0):
    """Create an immutable synthetic run with an opaque, non-executable checkpoint."""
    root = Path(base)
    data, run = root / (name + "_data"), root / name
    rows = []
    for label, class_name in ((0, "bad"), (1, "good")):
        for split_index, split in enumerate(("train", "val", "threshold", "selection", "test")):
            for i in range(2):
                relative = f"{class_name}/{split}_{i}.png"
                source = data / relative
                source.parent.mkdir(parents=True, exist_ok=True)
                arr = np.random.default_rng(label * 100 + split_index * 10 + i).integers(
                    0, 255, (32, 32, 3), dtype=np.uint8)
                Image.fromarray(arr).save(source)
                digest, phash, width, height = pixel_signature(source)
                rows.append({"path": str(source), "relative_path": relative, "label": label,
                             "class_name": class_name, "pixel_hash": digest, "phash": phash,
                             "width": width, "height": height, "group": f"{class_name}_{split}_{i}",
                             "split_hint": "", "split": split})
    cfg = merge_dict(DEFAULTS, {"task": "top", "profile": "laptop", "pilot": True,
                     "data_root": str(data), "output_root": str(root / "results"),
                     "weights_dir": str(root / "weights"), "pretrained": False,
                     "image_size": 32, "resize": "pad", "device": "cpu",
                     "models": ["patchcore"], "seeds": [42], "dataset_version": "synthetic-v1",
                     "independent_units_confirmed": True, "export_images": True})
    run.mkdir(parents=True)
    write_json(run / "config.json", cfg)
    write_csv(run / "manifest.csv", rows)
    write_json(run / "integrity.json", {"config_sha256": sha_file(run / "config.json"),
                                       "manifest_sha256": sha_file(run / "manifest.csv")})
    write_json(run / "data_location.json", {"data_root": str(data)})
    write_json(run / "split_summary.json", {"train": {"good": 2, "bad": 2}})
    model = run / "models" / "patchcore_seed42"
    model.mkdir(parents=True)
    checkpoint = model / "best.pt"
    checkpoint.write_bytes(b"Opaque test checkpoint; not a PyTorch model.\n")
    (model / "last.pt").write_bytes(b"Opaque training state for package round-trip.\n")
    candidate = {"name": "patchcore_seed42", "task": "top", "threshold": threshold,
                 "score_type": "anomaly_score", "members": [{"checkpoint": checkpoint.relative_to(run).as_posix(),
                    "sha256": sha_file(checkpoint), "architecture": "patchcore", "kind": "patchcore"}],
                 "policy": cfg["policy"], "status": "PENDING_INDEPENDENT_TEST",
                 "empirical_target_met": True, "comparison_complete": True,
                 "final_test_completed": False}
    write_json(run / "selected.json", candidate)
    write_json(run / "selection_integrity.json", {"sha256": sha_file(run / "selected.json")})
    write_json(run / "candidates.json", [candidate])
    write_json(run / "model_state.json", {"status": "SELECTED", "task": "top"})
    return run, data, rows


class OrchestrationLifecycleTests(unittest.TestCase):
    def test_audit_select_export_and_incremental_incumbent_with_mocked_backend(self):
        """Exercise file orchestration only, with deterministic fake model outputs."""
        from nilt.workflow import new_run, run_training, final_test, predict_folder, open_run
        import importlib.metadata
        original_version = importlib.metadata.version
        calls = []
        fake_torch = SimpleNamespace(__version__="0.0.mock", version=SimpleNamespace(cuda=None),
                                     cuda=SimpleNamespace(is_available=lambda: False))
        fake_tv = SimpleNamespace(__version__="0.0.mock")

        def fake_train(name, seed, rows, cfg, out, init_checkpoint=None):
            out = Path(out)
            out.mkdir(parents=True, exist_ok=True)
            checkpoint = out / "best.pt"
            checkpoint.write_bytes(f"Opaque orchestration test {name} {seed}".encode())
            write_json(out / "completed.json", {"checkpoint_sha256": sha_file(checkpoint),
                "best_val_pr_auc_bad": 1.0, "epochs_ran": 1,
                "kind": "patchcore" if name == "patchcore" else "supervised"})
            return checkpoint

        def fake_predict(run, members, rows, cfg):
            kinds = {member["architecture"] == "patchcore" for member in members}
            if len(kinds) != 1:
                raise AssertionError("Raw anomaly scores mixed with probabilities")
            anomaly = True in kinds
            calls.append(tuple(row.get("split") for row in rows))
            return np.array([(9.0 if anomaly else 0.9) if row["label"] == 0 else
                             (1.0 if anomaly else 0.1) for row in rows]), 0.01

        def versions(package):
            return "0.0.mock" if package in ("torch", "torchvision") else original_version(package)

        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            fixture, data, _ = fixture_run(root, "fixture")
            cfg = read_json(fixture / "config.json")
            cfg.update(models=["resnet18", "patchcore"], seeds=[42, 43],
                       near_duplicate_distance=-1, ensembles=True)
            with ExitStack() as stack:
                stack.enter_context(patch("nilt.engine.check_weights"))
                stack.enter_context(patch("nilt.engine.torch_modules", return_value=(fake_torch, fake_tv)))
                stack.enter_context(patch("nilt.engine.train_one", side_effect=fake_train))
                stack.enter_context(patch("nilt.workflow.predict_members", side_effect=fake_predict))
                stack.enter_context(patch("importlib.metadata.version", side_effect=versions))
                old = run_training(new_run(cfg))
                selected = read_json(old / "selected.json")
                self.assertTrue((old / "model_report.html").exists())
                self.assertTrue((old / "comparison_folders" / selected["name"] / "predicted/good").is_dir())
                candidates = read_json(old / "candidates.json")
                self.assertTrue(any(candidate["name"] == "resnet18_mean" for candidate in candidates))
                self.assertFalse(any(candidate["name"] == "patchcore_mean" for candidate in candidates))
                first_test = final_test(old)
                self.assertEqual(first_test["metrics"]["bad_passed_as_good_FN"], 0)
                with self.assertRaises(ValueError):
                    final_test(old)
                predict_folder(old, data, root / "predictions", labeled=True)
                self.assertEqual(read_json(root / "predictions/prediction_summary.json")["n_classified"], 20)
                cfg["previous_run"] = str(old)
                updated = run_training(new_run(cfg))
                new_candidates = read_json(updated / "candidates.json")
                incumbent = next(candidate for candidate in new_candidates if candidate["name"] == "incumbent_frozen")
                self.assertEqual(incumbent["threshold"], selected["threshold"])
                self.assertTrue((updated / "comparison_with_previous.html").exists())
                prior_map = {row["pixel_hash"]: row["split"] for row in open_run(old)[1]}
                updated_map = {row["pixel_hash"]: row["split"] for row in open_run(updated)[1]}
                self.assertEqual(prior_map, updated_map)


class RunIntegrityTests(unittest.TestCase):
    def test_open_run_resolves_current_data_location_without_rewriting_manifest(self):
        from nilt.workflow import open_run, verify_sources
        with tempfile.TemporaryDirectory() as temp:
            run, source, _ = fixture_run(temp)
            relocated = Path(temp) / "relocated_data"
            shutil.copytree(source, relocated)
            shutil.rmtree(source)
            original_config = (run / "config.json").read_bytes()
            original_manifest = (run / "manifest.csv").read_bytes()
            write_json(run / "data_location.json", {"data_root": str(relocated)})
            cfg, rows = open_run(run)
            self.assertEqual(Path(cfg["data_root"]), relocated)
            self.assertTrue(all(Path(row["path"]).is_relative_to(relocated) for row in rows))
            verify_sources(rows)
            self.assertEqual(original_config, (run / "config.json").read_bytes())
            self.assertEqual(original_manifest, (run / "manifest.csv").read_bytes())

    def test_runtime_overrides_cannot_change_release_or_pilot_semantics(self):
        from nilt.workflow import open_run
        with tempfile.TemporaryDirectory() as temp:
            run, _, _ = fixture_run(temp)
            for illegal in ({"pilot": False}, {"release": {"require_statistical_evidence": False}},
                            {"policy": {"max_bad_escape_rate": 1.0}}, {"image_size": 64}):
                with self.subTest(override=illegal):
                    write_json(run / "runtime_overrides.json", illegal)
                    with self.assertRaises(ValueError):
                        open_run(run)

    def test_tampered_selection_is_rejected_by_prediction_and_final_test(self):
        from nilt.workflow import final_test, predict_folder
        with tempfile.TemporaryDirectory() as temp:
            run, data, _ = fixture_run(temp)
            selected = read_json(run / "selected.json")
            selected["threshold"] = 0.001
            write_json(run / "selected.json", selected)
            with patch("nilt.workflow.predict_members") as predictor:
                with self.assertRaises(ValueError):
                    final_test(run)
                with self.assertRaises(ValueError):
                    predict_folder(run, data, Path(temp) / "predictions", labeled=True)
                predictor.assert_not_called()

    def test_saved_configuration_tampering_is_rejected(self):
        from nilt.workflow import open_run
        with tempfile.TemporaryDirectory() as temp:
            run, _, _ = fixture_run(temp)
            cfg = read_json(run / "config.json")
            cfg["image_size"] = 64
            write_json(run / "config.json", cfg)
            with self.assertRaises(ValueError):
                open_run(run)

    def test_selected_threshold_tampering_is_rejected(self):
        from nilt.workflow import load_selected
        with tempfile.TemporaryDirectory() as temp:
            run, _, _ = fixture_run(temp)
            selected = read_json(run / "selected.json")
            selected["threshold"] = 0.001
            write_json(run / "selected.json", selected)
            with self.assertRaises(ValueError):
                load_selected(run)

    def test_modified_image_is_rejected_before_scoring(self):
        from nilt.workflow import open_run, verify_sources
        with tempfile.TemporaryDirectory() as temp:
            run, _, _ = fixture_run(temp)
            _, rows = open_run(run)
            Image.new("RGB", (32, 32), (1, 2, 3)).save(rows[0]["path"])
            with self.assertRaises(ValueError):
                verify_sources(rows)


class TrainingPackageTests(unittest.TestCase):
    def test_package_and_restore_preserve_checkpoints_and_rebind_data(self):
        from nilt.registry import create_training_package, restore_training_package
        from nilt.workflow import open_run, verify_sources
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            run, data, _ = fixture_run(root)
            manifest = (run / "manifest.csv").read_bytes()
            config = (run / "config.json").read_bytes()
            saved = create_training_package(run, root / "package")
            self.assertFalse(any(p.suffix.lower() == ".png" for p in Path(saved).rglob("*")))
            moved = root / "moved_data"
            shutil.copytree(data, moved)
            shutil.rmtree(data)
            restored = restore_training_package(saved, moved, root / "restored")
            cfg, rows = open_run(restored)
            verify_sources(rows)
            self.assertEqual(Path(cfg["data_root"]), moved)
            self.assertEqual(manifest, (Path(restored) / "manifest.csv").read_bytes())
            self.assertEqual(config, (Path(restored) / "config.json").read_bytes())
            self.assertEqual((run / "models/patchcore_seed42/last.pt").read_bytes(),
                             (Path(restored) / "models/patchcore_seed42/last.pt").read_bytes())

    def test_restore_rejects_data_with_changed_pixels(self):
        from nilt.registry import create_training_package, restore_training_package
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            run, data, _ = fixture_run(root)
            package = create_training_package(run, root / "package")
            Image.new("RGB", (32, 32), "white").save(data / "bad/train_0.png")
            with self.assertRaises(ValueError):
                restore_training_package(package, data, root / "restored")

    def test_restore_rejects_tampered_checkpoint(self):
        from nilt.registry import create_training_package, restore_training_package
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            run, data, _ = fixture_run(root)
            package = Path(create_training_package(run, root / "package"))
            checkpoints = list(package.rglob("best.pt"))
            self.assertEqual(len(checkpoints), 1)
            checkpoints[0].write_bytes(b"changed")
            with self.assertRaises(ValueError):
                restore_training_package(package, data, root / "restored")


class ExternalHoldoutLineageTests(unittest.TestCase):
    @staticmethod
    def external_images(root):
        folder = Path(root) / "external_holdout"
        for class_name, offset in (("bad", 9000), ("good", 9100)):
            (folder / class_name).mkdir(parents=True)
            for index in range(2):
                pixels = np.random.default_rng(offset + index).integers(
                    0, 255, (32, 32, 3), dtype=np.uint8)
                Image.fromarray(pixels).save(folder / class_name / f"external_{index}.png")
        return folder

    @staticmethod
    def predictions(run, members, rows, cfg):
        return np.array([9.0 if row["label"] == 0 else 1.0 for row in rows]), 0.01

    def test_ancestor_external_holdout_cannot_be_reused_as_fresh_in_child(self):
        from nilt.workflow import external_history, final_test
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            ancestor, _, _ = fixture_run(root, "ancestor")
            holdout = self.external_images(root)
            with patch("nilt.workflow.predict_members", side_effect=self.predictions) as predictor:
                first = final_test(ancestor, input_dir=holdout)
                self.assertEqual(first["evaluation_role"], "external")
                self.assertEqual(predictor.call_count, 1)
            child, _, _ = fixture_run(root, "child")
            cfg = read_json(child / "config.json")
            cfg["previous_run"] = str(ancestor)
            write_json(child / "config.json", cfg)
            integrity = read_json(child / "integrity.json")
            integrity["config_sha256"] = sha_file(child / "config.json")
            write_json(child / "integrity.json", integrity)
            self.assertEqual(len(external_history(child)), 1)
            with patch("nilt.workflow.predict_members") as predictor:
                with self.assertRaisesRegex(ValueError, "earlier inspected evaluation"):
                    final_test(child, input_dir=holdout)
                predictor.assert_not_called()
            self.assertFalse((child / "final_test_summary.json").exists())

    def test_previously_evaluated_external_image_cannot_enter_development_data(self):
        from nilt.workflow import final_test, new_run
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            ancestor, data, _ = fixture_run(root, "ancestor")
            holdout = self.external_images(root)
            with patch("nilt.workflow.predict_members", side_effect=self.predictions):
                final_test(ancestor, input_dir=holdout)
            shutil.copy2(holdout / "bad/external_0.png", data / "bad/added_external_image.png")
            cfg = read_json(ancestor / "config.json")
            cfg["previous_run"] = str(ancestor)
            with patch("nilt.workflow.predict_members") as predictor:
                with self.assertRaisesRegex(ValueError, "previously inspected external holdout"):
                    new_run(cfg)
                predictor.assert_not_called()
            failed = list((root / "results/top").glob("*/model_state.json"))
            self.assertEqual(len(failed), 1)
            self.assertEqual(read_json(failed[0])["status"], "AUDIT_FAILED")


class FrozenComparisonTests(unittest.TestCase):
    def test_both_versions_are_scored_on_identical_selection_images(self):
        from nilt.registry import compare_runs
        calls = []

        def predictions(run, members, rows, cfg):
            calls.append((str(run), tuple(row["pixel_hash"] for row in rows),
                          tuple(row["split"] for row in rows)))
            return np.array([9.0 if row["label"] == 0 else 1.0 for row in rows]), 0.01

        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            old, _, _ = fixture_run(root, "old", 5.0)
            new, _, _ = fixture_run(root, "new", 6.0)
            original = [(r / "selected.json").read_bytes() for r in (old, new)]
            with patch("nilt.workflow.predict_members", side_effect=predictions):
                result = compare_runs(old, new, root / "comparison")
            self.assertIsInstance(result, dict)
            self.assertEqual(len(calls), 2)
            self.assertEqual(calls[0][1], calls[1][1])
            self.assertEqual(len(calls[0][1]), 4)
            self.assertTrue(all(split == "selection" for call in calls for split in call[2]))
            self.assertEqual(original, [(r / "selected.json").read_bytes() for r in (old, new)])

    def test_comparison_rejects_shared_units_used_in_training(self):
        from nilt.registry import compare_runs
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            old, _, _ = fixture_run(root, "old")
            new, _, rows = fixture_run(root, "new")
            selected_group = next(row["group"] for row in rows if row["split"] == "selection")
            next(row for row in rows if row["split"] == "train")["group"] = selected_group
            write_csv(new / "manifest.csv", rows)
            integrity = read_json(new / "integrity.json")
            integrity["manifest_sha256"] = sha_file(new / "manifest.csv")
            write_json(new / "integrity.json", integrity)
            with patch("nilt.workflow.predict_members") as predictor:
                with self.assertRaises(ValueError):
                    compare_runs(old, new, root / "comparison")
                predictor.assert_not_called()

    def test_comparison_rejects_conflicting_ground_truth(self):
        from nilt.registry import compare_runs
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            old, _, _ = fixture_run(root, "old")
            new, _, rows = fixture_run(root, "new")
            next(row for row in rows if row["split"] == "selection")["label"] = 1
            write_csv(new / "manifest.csv", rows)
            integrity = read_json(new / "integrity.json")
            integrity["manifest_sha256"] = sha_file(new / "manifest.csv")
            write_json(new / "integrity.json", integrity)
            with patch("nilt.workflow.predict_members") as predictor:
                with self.assertRaises(ValueError):
                    compare_runs(old, new, root / "comparison")
                predictor.assert_not_called()


if __name__ == "__main__":
    unittest.main()
