# Troubleshooting

## Read the actual error first

`FAILED` means the operation raised an error or could not complete normally. It is not an accuracy of zero and does not mean Optuna pruned the trial. Inspect the operation log and that trial's `failure.json`.

| State | Meaning | Next action |
| --- | --- | --- |
| COMPLETE | Trial completed and recorded its objective | Inspect validation and selection results |
| PRUNED | Search stopped an unpromising trial under the configured pruning rule | Usually expected search behavior |
| FAIL / FAILED | Execution failed | Read `error` and `traceback` |
| RUNNING | Trial is active or its resumable state remains open | Inspect progress, process, and outcome |
| TIMEOUT_RESUMABLE | Time allowance interrupted work with resumable state | Resume remaining allowance or start a new experiment |
| TARGET_NOT_MET | The decision did not meet both operating targets | Improve data/model/decision and evaluate again |

Example trial path: `results/vig/RUN_ID/search/resnet18/trial_00000/failure.json`. Use the current failed trial and run, not an old file with a similar name.

## Dashboard does not start

Run `Start.cmd` and read the retained console. It uses the interpreter recorded during setup, so `PS` without a visible `(venv)` is normal.

```powershell
$StudioPython = (Get-Content .studio-python.txt -Raw).Trim()
& $StudioPython -c "import sys; print(sys.executable)"
& $StudioPython inspection.py dashboard --config project.yaml
```

If `.studio-python.txt` is absent, run setup on this computer. If the port is occupied, use `Start.cmd -Port 8766`. Closing the browser does not stop the server or worker.

## Package installation or import failed

```powershell
$StudioPython = (Get-Content .studio-python.txt -Raw).Trim()
& $StudioPython -m pip check
& $StudioPython -c "import torch, torchvision, optuna, sklearn; print(torch.__version__); print(torchvision.__version__)"
```

`pip check` checks package declarations; it does not exercise every binary operation. Setup additionally performs real model computation. A later model-specific import or export path can still fail and should report its own exception.

For a Windows path-length installation failure, use the short separate environment created by `Setup.cmd`; do not place another environment deep inside repeated project subfolders. Leave old environments intact. If a partial manual environment is unusable, create a new directory rather than deleting one that other projects use.

## CUDA unavailable or out of memory

```powershell
nvidia-smi
```

Check that the installed torch wheel is the CUDA variant and that `torch.cuda.is_available()` is true. Workstation profiles require CUDA. Driver installation may require the company's approved process.

An out-of-memory failure depends on input resolution and model size, not only dataset size. Reduce the training/evaluation microbatch and inspect PatchCore bank sizes where applicable. Full-image preservation means there is no silent crop/downsample fallback. A CPU profile is a separate explicit choice.

## Missing pretrained weights

Use **Download pretrained weights** for the intended profile while online, then **Check installation**. For offline machines, transfer the complete configured weights folder. `pretrained: true` does not silently fall back to random weights when a file is missing.

## WinError 5 while replacing a progress file

The file writer creates unique temporary files and retries transient Windows access, sharing, and lock failures for a bounded period. A persistent access denial still fails explicitly. `WinError 5` alone does not identify the blocking process or prove a transient lock.

1. Read the new traceback and confirm which file operation failed.
2. Confirm no earlier training worker is still running against that experiment.
3. Confirm the run directory is a writable local folder for the current account.
4. Close an editor or preview that is holding the reported output file, if applicable.
5. If company endpoint controls block the operation persistently, give IT the exact path and traceback.

Do not remove access controls, disable antivirus, or repeatedly overwrite shared results to hide the cause. Restart the actual worker after replacing source code; an already running process may retain the previous imported module.

## Search already running or abandoned lock

Use **Pause active search** and wait for completion. Dashboard shutdown is separate from worker shutdown. A lock prevents simultaneous writers to one experiment.

After a confirmed process crash, and only after verifying no worker is active:

```powershell
& $StudioPython inspection.py search --run 'D:/Inspection/results/vig/RUN_ID' --recover-lock
```

Recovery does not make two simultaneous workers safe. Historical failed trials stay failed; a resumed run does not relabel past errors as successful.

## Classification or review is empty

Verify the saved decision points to intact model artifacts and that the input contains supported image files. Review previews require copies. Reference metrics require actual supplied labels; predictions in `good`/`bad` output folders are not reference labels.

For a relocated experiment, use the training package/restore path or the supported verified source override. Editing a frozen manifest or replacing files under an existing model identity invalidates its evidence.

## Model quality is poor

Inspect false negatives and false positives with the original tags. Check label consistency, bit depth and image geometry, grouping, duplicate conflicts, training curves, and variation across trays. Evaluate the composed decision on representative independent data. Longer training, more models, or more rotations do not guarantee the required error rates.
