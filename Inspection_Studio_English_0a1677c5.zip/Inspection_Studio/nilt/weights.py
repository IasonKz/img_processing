"""Verified public weight provisioning, shared by every compute profile.

Known TorchVision URLs and curated Hugging Face safetensors checkpoints are
accepted. This module performs HTTPS GET requests for model files; it never
reads or uploads dataset images and does not install packages. Offline runs
continue to require verified local weight files and checkpoint provenance.
"""
from __future__ import annotations

import hashlib
import math
import os
from pathlib import Path
import re
import tempfile
import time
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

from .common import _replace_file_with_retry, read_json, write_json


def _official_url(url):
    parsed = urlsplit(url)
    if (parsed.scheme != "https" or parsed.netloc != "download.pytorch.org"
            or parsed.query or parsed.fragment
            or not re.fullmatch(r"/models/[A-Za-z0-9_.-]+\.pth", parsed.path)):
        raise ValueError("Weight downloads allow only official HTTPS download.pytorch.org/models/*.pth URLs.")
    return url


class _OfficialRedirects(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        _official_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def download_policy(cfg, allow_download=None):
    enabled = cfg.get("download_missing_weights", False) if allow_download is None else allow_download
    if type(enabled) is not bool:
        raise ValueError("download_missing_weights must be true or false.")
    timeout = cfg.get("weight_download_timeout_seconds", 15)
    if (isinstance(timeout, bool) or not isinstance(timeout, (int, float))
            or not math.isfinite(timeout) or timeout <= 0):
        raise ValueError("weight_download_timeout_seconds must be finite and positive.")
    return enabled, float(timeout)


def _check_stop(stop_check, deadline):
    from .engine import TrainingStopped, check_stop
    check_stop(stop_check)
    if deadline is not None and time.time() >= deadline:
        raise TrainingStopped("budget_exhausted")


def _digest(path, stop_check=None, deadline=None):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while True:
            _check_stop(stop_check, deadline)
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def weight_descriptor(name):
    from .engine import WEIGHTS, torch_modules
    if name not in WEIGHTS:
        raise ValueError(f"Unsupported pretrained model: {name}")
    _, tv = torch_modules()
    url = _official_url(tv.models.get_model_weights(name)[WEIGHTS[name]].url)
    match = re.search(r"-([a-f0-9]{8,64})\.pth$", urlsplit(url).path)
    if not match:
        raise ValueError(f"Official weight URL has no verifiable SHA-256 hash prefix: {name}")
    return {"model": name, "weight": WEIGHTS[name], "filename": f"{name}__{WEIGHTS[name]}.pth",
            "source": url, "sha256_prefix": match.group(1)}


def _download(descriptor, target, timeout, stop_check=None, deadline=None):
    """Create a unique partial file; publish only after integrity verification."""
    from .engine import TrainingStopped
    _check_stop(stop_check, deadline)
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=target.name + ".", suffix=".download", dir=target.parent)
    temporary = Path(temporary)
    os.close(fd)
    try:
        remaining = timeout if deadline is None else min(timeout, max(.001, deadline - time.time()))
        request = Request(_official_url(descriptor["source"]), headers={"User-Agent": "NILT-Inspection-Studio/6.1"})
        print(f"Downloading official pretrained weights: {descriptor['model']} -> {target}", flush=True)
        digest, received = hashlib.sha256(), 0
        opener = build_opener(_OfficialRedirects())
        with opener.open(request, timeout=remaining) as response, temporary.open("wb") as stream:
            _official_url(response.geturl())
            raw_length = response.headers.get("Content-Length")
            expected = int(raw_length) if raw_length and raw_length.isdigit() else None
            while True:
                _check_stop(stop_check, deadline)
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                stream.write(chunk)
                digest.update(chunk)
                received += len(chunk)
            stream.flush()
            os.fsync(stream.fileno())
        _check_stop(stop_check, deadline)
        if expected is not None and expected != received:
            raise ValueError(f"Incomplete download for {descriptor['model']}: received {received} of {expected} bytes.")
        actual = digest.hexdigest()
        if not actual.startswith(descriptor["sha256_prefix"]):
            raise ValueError(f"Checksum mismatch for downloaded {descriptor['model']}; the file was not installed.")
        _replace_file_with_retry(temporary, target)
        print(f"Verified pretrained weights: {descriptor['model']} ({received / 2**20:.1f} MiB)", flush=True)
        return actual
    except TrainingStopped:
        raise
    except (OSError, ValueError) as exc:
        _check_stop(stop_check, deadline)
        raise RuntimeError(f"Cannot provision official weights for {descriptor['model']}: {exc}. "
                           "Check internet/proxy access or use download-weights on a connected computer "
                           "and copy the verified weights folder. No dataset images were transmitted.") from exc
    finally:
        temporary.unlink(missing_ok=True)


def ensure_pretrained_weights(cfg, *, stop_check=None, deadline=None, allow_download=None):
    """Return verified manifest entries. Old configs without a flag stay offline.

    The training supervisor's wall-clock budget includes downloads. Cancellation
    is checked between reads; a blocked network read is bounded by the request
    timeout and, for supervised searches, the parent process deadline.
    """
    from .engine import required_weight_names
    enabled, timeout = download_policy(cfg, allow_download)
    if not cfg.get("pretrained", True):
        return []
    _check_stop(stop_check, deadline)
    output = Path(cfg["weights_dir"])
    names = required_weight_names(cfg)
    from .backbones import TIMM_MODELS
    from .hub_weights import ensure_hub_weights
    descriptors = [weight_descriptor(name) for name in names if name not in TIMM_MODELS]
    missing = [output / item["filename"] for item in descriptors if not (output / item["filename"]).is_file()]
    if missing and not enabled:
        raise FileNotFoundError("Missing local pretrained weights:\n" + "\n".join(map(str, missing))
                                + "\nAutomatic downloads are disabled. Use download-weights explicitly or enable "
                                "download_missing_weights. Dataset images remain local in either mode.")
    entries = ensure_hub_weights(cfg, [name for name in names if name in TIMM_MODELS],
                                 enabled, timeout, stop_check, deadline) if any(name in TIMM_MODELS for name in names) else []
    for descriptor in descriptors:
        _check_stop(stop_check, deadline)
        target = output / descriptor["filename"]
        digest = _digest(target, stop_check, deadline) if target.is_file() else _download(
            descriptor, target, timeout, stop_check, deadline)
        if not digest.startswith(descriptor["sha256_prefix"]):
            raise ValueError(f"Checksum mismatch for local pretrained weights {target}. "
                             "The existing file was preserved; move it aside and provision verified weights again.")
        entries.append({**descriptor, "sha256": digest})
    if entries and enabled:
        manifest_path = output / "weights_manifest.json"
        previous = read_json(manifest_path) if manifest_path.is_file() else []
        if not isinstance(previous, list):
            raise ValueError(f"Invalid weight manifest format: {manifest_path}")
        merged = {row["model"]: row for row in previous if isinstance(row, dict) and "model" in row}
        merged.update({row["model"]: row for row in entries})
        write_json(manifest_path, list(merged.values()))
    return entries
