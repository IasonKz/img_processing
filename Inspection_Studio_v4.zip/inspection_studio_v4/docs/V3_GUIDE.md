# Compatibility guide

The integrated workflow is documented in [EXPERIMENT_GUIDE.md](EXPERIMENT_GUIDE.md).
For Windows setup use [INSTALLATION.md](INSTALLATION.md); for the current interface use [OPERATOR_GUIDE.md](OPERATOR_GUIDE.md).

Existing v3 experiments remain separate recorded artifacts. Do not overwrite their frozen configurations or copy old patches onto Inspection Studio 4.
