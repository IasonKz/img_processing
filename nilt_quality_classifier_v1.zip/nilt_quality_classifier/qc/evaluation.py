from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .config import get, resolve_path
from .data import DEFAULT_UNIT_ID_REGEX, canonicalize_unit_id, extract_unit_id
from .ground_truth import load_ground_truth, resolve_column
from .metrics import (
    add_review_decisions,
    binary_metrics,
    predictions_frame,
    release_policy_metrics,
    save_evaluation_bundle,
    threshold_sweep,
)
from .utils import setup_logging, write_json


def _prepare_predictions(frame: pd.DataFrame, config: dict[str, Any]) -> pd.DataFrame:
    p_bad_column = resolve_column(frame, str(config.get("p_bad_column", "p_bad")))
    path_column = None
    if config.get("path_column"):
        path_column = resolve_column(frame, str(config["path_column"]))
    elif "path" in frame.columns:
        path_column = "path"

    unit_column = None
    if config.get("unit_id_column"):
        unit_column = resolve_column(frame, str(config["unit_id_column"]))
    elif "unit_id" in frame.columns:
        unit_column = "unit_id"

    unit_pattern = str(config.get("unit_id_regex", DEFAULT_UNIT_ID_REGEX))
    output = frame.copy()
    output["p_bad"] = pd.to_numeric(output[p_bad_column], errors="coerce")
    output = output[output["p_bad"].notna()].copy()

    if unit_column:
        output["unit_id_raw_prediction"] = output[unit_column].astype(str)
        output["unit_id"] = output[unit_column].map(canonicalize_unit_id)
    elif path_column:
        raw_and_canonical = output[path_column].map(
            lambda value: extract_unit_id(str(value), unit_pattern)
        )
        output["unit_id_raw_prediction"] = raw_and_canonical.map(lambda pair: pair[0])
        output["unit_id"] = raw_and_canonical.map(lambda pair: pair[1])
    else:
        raise ValueError("Predictions need a unit_id column or a path column")

    if path_column:
        output["path"] = output[path_column].astype(str)
    else:
        output["path"] = ""
    if "filename" not in output.columns:
        output["filename"] = output["path"].map(lambda value: Path(value).name if value else "")

    duplicate_policy = str(config.get("duplicate_policy", "all")).lower()
    if duplicate_policy == "highest_p_bad":
        output = output.sort_values("p_bad").drop_duplicates("unit_id", keep="last")
    elif duplicate_policy == "lowest_p_bad":
        output = output.sort_values("p_bad").drop_duplicates("unit_id", keep="first")
    elif duplicate_policy == "first":
        output = output.drop_duplicates("unit_id", keep="first")
    elif duplicate_policy == "last":
        output = output.drop_duplicates("unit_id", keep="last")
    elif duplicate_policy != "all":
        raise ValueError(f"Unsupported predictions.duplicate_policy: {duplicate_policy}")
    return output.reset_index(drop=True)


def run_prediction_evaluation(config: dict[str, Any]) -> dict[str, Any]:
    predictions_path = resolve_path(
        get(config, "predictions.path"), config=config, must_exist=True
    )
    truth_path = resolve_path(
        get(config, "ground_truth.csv_path"), config=config, must_exist=True
    )
    if predictions_path is None or truth_path is None:
        raise ValueError("Set predictions.path and ground_truth.csv_path")

    output_value = get(config, "evaluation.output_folder")
    if output_value:
        output_dir = resolve_path(output_value, config=config)
        assert output_dir is not None
    else:
        output_dir = predictions_path.parent / "evaluation"
    output_dir.mkdir(parents=True, exist_ok=True)
    logger = setup_logging(output_dir / "evaluation.log")

    predictions_raw = pd.read_csv(predictions_path, encoding="utf-8-sig")
    predictions = _prepare_predictions(predictions_raw, config.get("predictions", {}) or {})
    truth, truth_details = load_ground_truth(
        truth_path,
        config.get("ground_truth", {}) or {},
    )
    skipped_truth = truth_details["skipped"]
    if isinstance(skipped_truth, pd.DataFrame) and not skipped_truth.empty:
        skipped_truth.to_csv(
            output_dir / "ground_truth_skipped_rows.csv", index=False, encoding="utf-8"
        )

    matched = predictions.merge(truth, on="unit_id", how="inner", suffixes=("", "_gt"))
    unmatched_predictions = predictions[~predictions["unit_id"].isin(truth["unit_id"])].copy()
    unmatched_truth = truth[~truth["unit_id"].isin(predictions["unit_id"])].copy()
    unmatched_predictions.to_csv(
        output_dir / "unmatched_predictions.csv", index=False, encoding="utf-8"
    )
    unmatched_truth.to_csv(output_dir / "unmatched_ground_truth.csv", index=False, encoding="utf-8")

    if matched.empty:
        raise ValueError(
            "No predictions matched the ground-truth Unit Identifiers. Check unit_id_regex "
            "and separator differences such as '-' versus '_'."
        )

    threshold_value = get(config, "evaluation.threshold_bad")
    if threshold_value is None and "threshold_bad" in matched.columns:
        unique_thresholds = pd.to_numeric(matched["threshold_bad"], errors="coerce").dropna().unique()
        threshold = float(unique_thresholds[0]) if len(unique_thresholds) else 0.5
    else:
        threshold = 0.5 if threshold_value is None else float(threshold_value)

    matched["predicted_index"] = (matched["p_bad"] >= threshold).astype(int)
    matched["predicted_label"] = np.where(
        matched["predicted_index"] == 1, "bad", "good"
    )
    matched["correct"] = matched["predicted_index"] == matched["true_index"].astype(int)
    matched["error_type"] = ""
    matched.loc[
        (matched["true_index"].astype(int) == 1) & (matched["predicted_index"] == 0),
        "error_type",
    ] = "false_pass"
    matched.loc[
        (matched["true_index"].astype(int) == 0) & (matched["predicted_index"] == 1),
        "error_type",
    ] = "false_reject"

    review_config = get(config, "evaluation.review", {}) or {}
    if "decision" not in matched.columns or bool(review_config.get("recompute", False)):
        matched = add_review_decisions(
            matched,
            enabled=bool(review_config.get("enabled", False)),
            good_max_p_bad=(
                None
                if review_config.get("good_max_p_bad") is None
                else float(review_config["good_max_p_bad"])
            ),
            bad_min_p_bad=(
                threshold
                if review_config.get("bad_min_p_bad") is None
                else float(review_config["bad_min_p_bad"])
            ),
        )

    sweep = threshold_sweep(
        matched["true_index"].astype(int).to_numpy(),
        matched["p_bad"].to_numpy(),
        steps=int(get(config, "evaluation.threshold_sweep_steps", 1001)),
    )
    metrics = save_evaluation_bundle(
        output_dir=output_dir,
        name="external_test",
        y_true=matched["true_index"].astype(int).to_numpy(),
        p_bad=matched["p_bad"].to_numpy(),
        threshold=threshold,
        predictions=matched,
        threshold_sweep_frame=sweep,
        export_error_images=bool(get(config, "evaluation.export_error_images", True)),
        source_root=get(config, "predictions.source_root"),
    )
    policy_metrics = release_policy_metrics(
        matched["true_index"].astype(int).to_numpy(),
        matched["decision"].astype(str).tolist(),
    )
    write_json(policy_metrics, output_dir / "release_policy_metrics.json")

    summary = {
        "predictions_path": str(predictions_path),
        "ground_truth_path": str(truth_path),
        "output_folder": str(output_dir),
        "predictions_total": int(len(predictions)),
        "ground_truth_usable": int(len(truth)),
        "matched": int(len(matched)),
        "unmatched_predictions": int(len(unmatched_predictions)),
        "unmatched_ground_truth": int(len(unmatched_truth)),
        "threshold_bad": threshold,
        "metrics": metrics,
        "release_policy_metrics": policy_metrics,
        "ground_truth_details": truth_details["summary"],
    }
    write_json(summary, output_dir / "evaluation_summary.json")
    logger.info(
        "Matched %d/%d predictions. False passes: %d; false-pass rate: %.4f",
        len(matched),
        len(predictions),
        metrics["false_pass"],
        metrics["false_pass_rate"],
    )
    return summary
