"""Integrated loopback UI with the original annotation controller embedded."""
import html
import json
import mimetypes
import threading
import webbrowser
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
from .server import AnnotationServer, AnnotationHandler, WEB_ROOT, MAX_BODY_BYTES
from .common import read_json, safe_path, load_config, atomic_json
from .project import Project, ConflictError
from .jobs import JobManager
from .registry import catalog
from .search import DEFAULT_SEARCH, settings


class StudioServer(AnnotationServer):
    def __init__(self,cfg,config_path,port=0):
        super().__init__(cfg,port)
        self.RequestHandlerClass=StudioHandler
        self.config_path=Path(config_path).resolve()
        self.cfg=cfg
        self.jobs=JobManager(cfg)


class StudioHandler(AnnotationHandler):
    def _query(self):return {k:v[0] for k,v in parse_qs(urlsplit(self.path).query).items()}

    def do_GET(self):
        path=urlsplit(self.path).path
        if path=='/annotate':
            self.path='/';super().do_GET();return
        assets={'/':'studio.html','/studio.js':'studio.js','/studio.css':'studio.css','/NIL-logo.png':'NIL-logo.png','/plotly.min.js':'plotly.min.js'}
        if path not in assets and not path.startswith('/api/studio/') and path!='/api/template':
            super().do_GET();return
        if not self._authorize():return
        try:
            if path in assets:
                file=WEB_ROOT/assets[path]
                if path=='/': self._send(200,file.read_text(encoding='utf-8').replace('__SESSION_TOKEN__',html.escape(self.server.session_token)),'text/html; charset=utf-8')
                else:self._send(200,file.read_bytes(),mimetypes.guess_type(file)[0] or 'application/octet-stream')
                return
            q=self._query();cfg=self.server.cfg;output=Path(cfg['output_dir'])
            if path=='/api/template':self._send(200,self.server.project.polygon_template());return
            if path=='/api/studio/encoders':
                from .registry import encoder_names
                self._send(200,{'encoders':encoder_names()});return
            if path=='/api/studio/state':
                items=self.server.project.items()
                counts={status:sum(i['status']==status for i in items) for status in ('approved','draft','unannotated','rejected')}
                self._send(200,dict(config=cfg,counts=counts,total=len(items),job=self.server.jobs.current(),models=catalog(),defaults=DEFAULT_SEARCH));return
            if path=='/api/studio/studies':
                entries=[]
                for p in sorted((output/'studies').glob('*/summary.json')):
                    d=read_json(p);entries.append({'name':p.parent.name,'best':d.get('best'),'trials':len(d['trials'])})
                self._send(200,{'studies':entries});return
            if path in ('/api/studio/study','/api/studio/evaluation'):
                name=q.get('name','');settings({'study_name':name});root=output/'studies'/name
                if path.endswith('evaluation'):
                    role=q.get('split','validation')
                    if role not in ('validation','test'):raise ValueError('Invalid split.')
                    folder=root/'evaluations'/f"{int(q['trial']):05d}_{role}"
                    self._send(200,{'metrics':read_json(folder/'metrics.json'),'images':read_json(folder/'images.json'),'relative_dir':folder.relative_to(output).as_posix()});return
                result=read_json(root/'summary.json')
                histories={str(t['number']):read_json(root/'trials'/f"{t['number']:05d}"/'history.json') for t in result['trials'] if (root/'trials'/f"{t['number']:05d}"/'history.json').exists()}
                self._send(200,{**result,'histories':histories,'settings':read_json(root/'search_settings.json'),'split':read_json(root/'split.json')});return
            if path=='/api/studio/artifact':
                file=safe_path(output,q.get('path',''))
                if file.suffix.lower() not in ('.png','.jpg','.csv','.json','.zip','.html','.pt','.onnx'):
                    raise ValueError('Unsupported artifact type.')
                self._send(200,file.read_bytes(),mimetypes.guess_type(file)[0] or 'application/octet-stream');return
            self._send(404,{'error':'Resource not found.'})
        except (ValueError,TypeError) as exc:self._send(400,{'error':str(exc)})
        except (FileNotFoundError,KeyError):self._send(404,{'error':'Result is not available yet.'})
        except Exception as exc:self._send(500,{'error':str(exc)})

    def do_POST(self):
        path=urlsplit(self.path).path
        if not path.startswith('/api/studio/') and not path.startswith('/api/template'):
            super().do_POST();return
        if not self._authorize(mutate=True):self.close_connection=True;return
        try:
            length=int(self.headers.get('Content-Length',0))
            if self.headers.get('Transfer-Encoding') or not 0<length<=MAX_BODY_BYTES or self.headers.get('Content-Type','').split(';')[0]!='application/json':
                self.close_connection=True;raise ValueError('Send a bounded JSON object.')
            payload=json.loads(self.rfile.read(length),parse_constant=lambda _:(_ for _ in ()).throw(ValueError('Non-finite JSON.')))
            if not isinstance(payload,dict):raise ValueError('Expected an object.')
            with self.server.project_lock:
                project=self.server.project
                if path=='/api/template':
                    result=project.save_polygon_template(payload['image_id'],payload['roi'],payload['expected_revision'],payload.get('mode','normalized'),payload.get('enabled',True))
                elif path=='/api/template/roi':
                    row=project._row(payload['image_id']); template=project.polygon_template()
                    if not template.get('revision'):raise ValueError('Save a custom polygon first.')
                    result={'roi':project.template_roi(row['width'],row['height'],{**template,'enabled':True})}
                elif path=='/api/template/apply':result=project.apply_polygon_template(payload.get('include_approved',False))
                elif path=='/api/studio/start':
                    action=payload['action']; request=payload.get('settings',{})
                    if action in ('search','preflight'): settings(request)
                    result=self.server.jobs.start(action,request)
                elif path=='/api/studio/stop':result=self.server.jobs.stop()
                elif path=='/api/studio/config':
                    if self.server.jobs.current().get('status') in ('running','starting'):raise ValueError('Wait for the active operation before changing project paths.')
                    allowed={'name','input_dir','project_dir','output_dir','group_regex'}
                    if set(payload)-allowed:raise ValueError('Unknown project setting.')
                    import yaml
                    candidate={**self.server.cfg,**payload}
                    path_cfg=self.server.config_path
                    temp=path_cfg.with_name(path_cfg.name+'.new.yaml')
                    try:
                        temp.write_text(yaml.safe_dump(candidate,sort_keys=False),encoding='utf-8')
                        cfg=load_config(temp);new_project=Project(cfg)
                        if candidate.get('group_regex')!=self.server.cfg.get('group_regex') and new_project.items():
                            raise ValueError('Use a new annotation project when changing grouping.')
                        temp.replace(path_cfg)
                    finally:temp.unlink(missing_ok=True)
                    self.server.cfg=cfg;self.server.project=new_project;self.server.jobs=JobManager(cfg)
                    result={'config':cfg}
                else:self._send(404,{'error':'Operation not found.'});return
            self._send(200,result)
        except ConflictError as exc:self._send(409,{'error':str(exc)})
        except (ValueError,KeyError,TypeError,FileNotFoundError) as exc:self._send(400,{'error':str(exc)})
        except Exception as exc:self._send(500,{'error':str(exc)})


def serve_studio(cfg,config_path,open_browser=True):
    server=StudioServer(cfg,config_path,cfg['annotation']['port'])
    address=f'http://127.0.0.1:{server.server_port}/'
    print(f'Top Segmentation Studio: {address}\nKeep this terminal open. Ctrl+C closes the UI server.',flush=True)
    if open_browser:threading.Timer(.5,lambda:webbrowser.open(address)).start()
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()
