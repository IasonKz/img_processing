# Ordered inspection workflows

A workflow applies several saved model decisions to the **same input image**. It is useful for testing a fast first screen, a second opinion, or a voting rule. It does not join separate top, bottom, and VIG captures into a physical-unit decision. Stages must use the same task.

## Create a recipe

Train and select candidates first. Save the desired decision for each in **Decision explorer**. Then add the decisions in **Inspection workflow**, arrange their order, choose the rule, and save the recipe.

Each saved decision carries its model identity, preprocessing, mode, and threshold. A workflow refers to those decisions rather than creating another untrained model. To change a stage threshold, save a new decision and then save a new workflow version.

| Rule | Final bad decision | Early exit | Consequence to measure |
| --- | --- | --- | --- |
| `any_bad` | At least one stage predicts bad | First bad result | May catch more defects and reject more good images |
| `all_bad` | Every stage predicts bad | First good result | May retain more good images and pass more defects |
| `majority` | At least half the stages predict bad; ties are bad | No | Depends on complementary, rather than repeated, errors |

Stages are deterministic saved decisions. For `any_bad` and `all_bad`, order changes which images reach later stages and the compute cost; it does not change the final Boolean rule. The trace identifies stages skipped because the result was already decided.

Scores from different stages are never blindly averaged. A PatchCore anomaly distance is not on the same scale as a supervised softmax score. Scores-only decisions cannot be filtering stages because they provide no good/bad vote.

## Determine whether a workflow helps

Use a representative labeled development batch that was not used for training. Compare each fixed model and the composed workflow on the same images. Inspect:

1. Bad escapes and good rejects, including the raw counts.
2. Which model corrects another model's errors and which new errors it creates.
3. Final accepted contamination and balanced accuracy.
4. End-to-end processing time and the share of images reaching each stage.

Do not multiply individual error rates to predict the combined rate: model errors are commonly dependent. Evaluate the composed decisions directly. A later stage in `any_bad` sees a selected subset; its conditional statistics are not its accuracy on the original whole batch.

After settling the order, thresholds, and rule, freeze the recipe and evaluate fresh independent labeled data. Repeatedly changing the recipe while looking at one batch turns that batch into development data. Workflow output is marked `NOT_INDEPENDENTLY_VALIDATED`; descriptive reference-label metrics do not automatically qualify the workflow.

## Command-line recipe

Create a JSON file such as `workflow-spec.json`. Replace the decision paths with complete saved decision locations:

```json
{
  "name": "VIG two-stage screen",
  "task": "vig",
  "rule": "any_bad",
  "stages": [
    {
      "name": "Primary screen",
      "decision": "D:/Inspection/decisions/primary/decision.json"
    },
    {
      "name": "Secondary inspection",
      "decision": "D:/Inspection/decisions/secondary/decision.json"
    }
  ]
}
```

From PowerShell in the project folder:

```powershell
$StudioPython = (Get-Content .studio-python.txt -Raw).Trim()
& $StudioPython inspection.py workflow-create --spec workflow-spec.json --output-root workflows
```

Use the saved workflow path printed by the command:

```powershell
& $StudioPython inspection.py workflow-run --workflow 'D:/Inspection/workflows/WORKFLOW/workflow.json' --input 'D:/Inspection/incoming/vig' --output-root classified --device cuda
```

Add `--labeled` only for real reference-tag folders. Use `--device cpu` on the laptop. Copies are created by default; `--no-copy-images` saves storage but prevents copied-image previews. Each run creates a separate output directory.

## Output and traceability

| Artifact | Purpose |
| --- | --- |
| `workflow.json` and integrity record | Saved stage order, rule, and decision references |
| `review_progress.json` | Live batch progress |
| `records/<id>.json` | Complete per-image review records |
| `predictions.jsonl` / `predictions.csv` | Incremental / completed prediction tables |
| `stage_trace.jsonl` | Ordered stage scores, decisions, and skipped stages |
| `summary.json` | Batch identity, status, counts, and decision scope |
| `metrics.json` | Reference-label metrics when reference labels exist |
| `review_session.json` | Review session metadata |
| `predicted/good` / `predicted/bad` | Copies categorized by the final prediction |

Retain all source decisions and their model artifacts. A workflow recipe is not a bundle of its neural network weights. ONNX export remains a per-decision/model package operation; saving a workflow does not automatically export one combined ONNX graph.
