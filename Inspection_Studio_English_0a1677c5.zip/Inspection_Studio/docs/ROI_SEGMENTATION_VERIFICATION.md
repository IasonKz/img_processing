# Shared ROI/Segmentation verification — 2026-10-05

Verified in the cloud workspace with Python 3.12, CPU PyTorch, OpenCV, Node and system Chromium. Inputs were synthetic. Windows, GPU execution and production defect accuracy were not tested.

## Backend regression and real training

```bash
python -m pytest -q tests/segmentation \
  tests/test_roi_geometry.py tests/test_roi_context.py tests/test_roi_project.py \
  tests/test_roi_learning.py tests/test_roi_dashboard.py tests/test_roi_classification.py \
  tests/test_roi_segmentation.py tests/test_workspace_studio.py \
  tests/test_v6_image_depth.py tests/test_dashboard_preprocessing.py \
  tests/test_untagged_preparation.py
```

**216 passed, 82 subtests passed.** This is one combined run, not a sum of overlapping checks. Coverage includes:

- Real TOP/BOTTOM geometry exports → crop import → native working pixels → approved annotations → frozen snapshot → dashboard restart.
- Exact uint16 preservation and a tensor check distinguishing intensities one level apart; display previews remain uint8.
- Unit/source/ROI provenance, inherited train/validation/test splits, missing defect support, conflicting roles and changed source rejection.
- Shared review revisions, session isolation between views, local CSRF checks, bound source paths and BOTTOM whole-image refusal. Legacy BOTTOM worker recovery is retained.
- A real one-epoch crop Optuna study, evaluation of its original held-out test, native prediction, exported Python package prediction outside the repo, direct training and fine-tuning with the same unit roles.
- A real one-epoch geometric localizer through the Segmentation API alias, prediction on source images, application in ROI Detection and frozen mask evaluation. Existing engine/checkpoints/history paths are retained.
- Existing whole-image annotation, search, training, segmentation HTTP, geometry/quality separation, classification handoff, worker identity/stop and preprocessing regressions.

## Browser workflows

```bash
STUDIO_PYTHON=/path/to/project/python \
STUDIO_BROWSER_EXECUTABLE=/path/to/chromium \
  node tests/browser_roi_workflow.cjs /tmp/roi-segmentation-evidence

STUDIO_PYTHON=/path/to/project/python \
STUDIO_BROWSER_EXECUTABLE=/path/to/chromium \
  node tests/browser_preprocessing.cjs /tmp/preprocessing-evidence
```

Both use Playwright, temporary projects and actual loopback APIs, without intercepted routes. The ROI workflow exercises:

- Geometry import/review/export and existing Classification handoff.
- TOP crop annotation saved through the editor in ROI Detection and opened as the same approved review in Segmentation.
- Crop model-search controls with inherited split fractions locked and the one-class default enabled.
- Annotation fullscreen in both sections, a BOTTOM pin crop editor with the correct view labels, TOP/BOTTOM selection and TOP whole-image navigation.
- Localizer training controls in Segmentation and the selected geometry-export handoff from ROI Detection.

The preprocessing workflow checks native uint16 preparation, final/post-only TOP/BOTTOM defaults, all three classification handoffs, authenticated operations and desktop/mobile layouts. Browser evidence is synthetic and is written outside the repository.

The four existing DOM suites (`test_roi_ui.cjs`, `test_v4_ui.cjs`, `test_v5_ui.cjs`, `test_v61_quality_ui.cjs`) also pass. They test event wiring/escaping separately from browser layout.

## Boundaries

No production accuracy result is inferred from the synthetic runs. Geometry localization, crop defect segmentation and binary quality classification retain distinct model semantics. This change connects annotation/data/training flows; it does not create or qualify a combined TOP/BOTTOM production verdict. The [operator guide](ROI_SEGMENTATION.md) describes the available workflows.
