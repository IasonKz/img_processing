/* Local annotation controller. Footprints are native-resolution binary objects.
 * Visibility changes display only; all objects remain in the authoritative mask.
 * Original source images are never edited by the annotation workspace. */
'use strict';
(() => {
  const $ = id => document.getElementById(id), M = window.TopsegMask;
  const token = document.querySelector('meta[name="session-token"]').content;
  const clone = value => value == null ? value : JSON.parse(JSON.stringify(value));
  const state = {items: [], current: null, objects: [], selected: null, region: null, mask: null, image: null, tool: 'brush', dirty: false, busy: false, zoom: 1, x: 0, y: 0, undo: [], redo: [], drag: null, polygon: [], pointer: null, space: false, automation: null, erase: null, selectedZone: null, reloadUndo: null, proposalStats: null};
  const viewport = $('viewport'), wrap = $('canvas-wrap');
  const imageCanvas = $('image-canvas'), maskCanvas = $('mask-canvas'), guideCanvas = $('guide-canvas');
  const imageContext = imageCanvas.getContext('2d'), maskContext = maskCanvas.getContext('2d'), guideContext = guideCanvas.getContext('2d');
  let toastTimer, selectionCache = null, fieldCheckpoint = null;
  async function api(path, payload) {
    const response = await fetch(path, {method: payload === undefined ? 'GET' : 'POST', headers: {'X-Session-Token': token, ...(payload === undefined ? {} : {'Content-Type': 'application/json'})}, ...(payload === undefined ? {} : {body: JSON.stringify(payload)})});
    if (!response.ok) { let body; try { body = await response.json(); } catch (_) {} throw new Error(body?.error || `Request failed (${response.status}).`); }
    return response.json();
  }
  function toast(message, isError = false) { $('toast').textContent = message; $('toast').classList.toggle('error', isError); $('toast').classList.remove('hidden'); clearTimeout(toastTimer); toastTimer = setTimeout(() => $('toast').classList.add('hidden'), isError ? 11000 : 5000); }
  function error(exc) { console.error(exc); toast(exc.message || String(exc), true); }
  function busy(value, message = 'Loading image…') { state.busy = value; $('loading').textContent = message; $('loading').classList.toggle('hidden', !value); updateButtons(); }
  function pending() { return state.dirty || state.polygon.length > 0 || (state.drag && state.drag.mode !== 'pan'); }
  function dirty() { state.dirty = true; showProposalStatus(); updateStatus(); }
  function currentIndex() { return state.items.findIndex(x => x.id === state.current?.id); }
  function updateStatus() {
    const status = state.current?.status || 'unannotated', rejected = status === 'rejected';
    $('image-status').textContent = !state.current ? 'No image' : rejected ? `Excluded${state.dirty ? ' · unsaved edits' : ' from dataset'}` : state.dirty ? 'Unsaved changes' : status === 'approved' ? 'Approved' : 'Draft · review required';
    $('image-status').className = `status ${rejected ? 'rejected' : state.dirty ? 'draft' : status}`;
    $('save-state').textContent = state.current ? (state.dirty ? '● Unsaved changes' : `Saved revision ${state.current.revision}`) : 'No unsaved changes';
    $('save-state').style.color = state.dirty ? '#ebbf76' : '';
    $('exclusion-note').classList.toggle('hidden', !rejected);
    $('restore-image').classList.toggle('hidden', !rejected);
    $('reject-next').classList.toggle('hidden', rejected);
    updateButtons();
  }
  function updateButtons() {
    const disabled = !state.current || state.busy;
    for (const id of ['save-draft', 'regenerate', 'detect-roi', 'clear-mask', 'class-inner', 'class-outer', 'brush-size', 'reject-next', 'restore-image', 'save-template', 'load-template', 'apply-template', 'draw-zone', 'draw-eye', 'draw-scope', 'apply-eye', 'reset-eye', 'save-profile', 'load-profile', 'read-chamfer', 'apply-chamfer']) $(id).disabled = disabled;
    for (const id of ['approve', 'approve-clean']) $(id).disabled = disabled || state.current?.status === 'rejected';
    document.querySelectorAll('[data-tool], .properties-panel input, .properties-panel select, .properties-panel textarea, .object-row button, .zone-row button, .reference-list button').forEach(element => { element.disabled = disabled; });
    $('undo-reload').disabled = disabled || !state.reloadUndo;
    $('undo').disabled = disabled || !state.undo.length; $('redo').disabled = disabled || !state.redo.length;
    $('previous').disabled = disabled || currentIndex() <= 0; $('next').disabled = disabled || currentIndex() >= state.items.length - 1;
  }
  function renderQueue() {
    const approved = state.items.filter(x => x.status === 'approved').length, excluded = state.items.filter(x => x.status === 'rejected').length;
    $('queue-total').textContent = state.items.length;
    $('progress-text').textContent = `${approved} / ${state.items.length - excluded} approved${excluded ? ` · ${excluded} excluded` : ''}`;
    $('progress-bar').style.width = `${state.items.length ? (approved + excluded) / state.items.length * 100 : 0}%`;
    const list = $('image-list'); list.replaceChildren(); const term = $('search').value.toLowerCase();
    for (const item of state.items) {
      if (term && !item.relative_path.toLowerCase().includes(term)) continue;
      if (item.id !== state.current?.id && (($('unapproved-only').checked && ['approved', 'rejected'].includes(item.status)) || ($('hide-rejected').checked && item.status === 'rejected'))) continue;
      const button = document.createElement('button'); button.className = `image-item ${item.id === state.current?.id ? 'active' : ''}`;
      button.dataset.imageId = item.id;
      const name = document.createElement('span'); name.className = 'image-item-name'; name.textContent = item.relative_path;
      const meta = document.createElement('span'); meta.className = 'image-item-meta';
      const status = document.createElement('span'); status.textContent = item.status === 'approved' ? '✓ Approved' : item.status === 'rejected' ? '⊘ Excluded' : item.status === 'draft' ? '○ Draft' : '· Unreviewed';
      if (item.status === 'approved') status.className = 'approved-dot'; if (item.status === 'rejected') status.className = 'rejected-dot';
      const dimensions = document.createElement('span'); dimensions.textContent = `${item.width} × ${item.height}`;
      meta.append(status, dimensions); button.append(name, meta); button.addEventListener('click', () => openImage(item.id)); list.append(button);
    }
  }
  function mergeItem(item) { const index = state.items.findIndex(x => x.id === item.id); if (index >= 0) state.items[index] = {...state.items[index], ...item}; renderQueue(); }
  async function openImage(id, force = false) {
    if (state.busy || (!force && state.current?.id === id)) return;
    if (pending() && !force && !confirm('Discard unsaved changes and open another image?')) return;
    busy(true);
    try {
      const item = await api(`/api/image/${id}`);
      const response = await fetch(item.rgb_url, {headers: {'X-Session-Token': token}});
      if (!response.ok) throw new Error('The working-copy image could not be loaded.');
      const image = await createImageBitmap(await response.blob());
      if (image.width !== item.width || image.height !== item.height) { image.close(); throw new Error('Image geometry differs from the annotation record.'); }
      if (state.image) state.image.close(); state.image = image; applyRecord(item); state.polygon = []; state.drag = null; state.pointer = null;
      for (const canvas of [imageCanvas, maskCanvas, guideCanvas]) { canvas.width = item.width; canvas.height = item.height; }
      wrap.style.width = `${item.width}px`; wrap.style.height = `${item.height}px`;
      imageContext.drawImage(image, 0, 0); $('empty-state').classList.add('hidden');
      $('image-name').textContent = item.relative_path; $('image-name').title = item.relative_path;
      $('image-position').textContent = `IMAGE ${currentIndex() + 1} OF ${state.items.length}`;
      $('canvas-info').textContent = `${item.width} × ${item.height} px · drag background to pan`;
      fit(); drawMask(); drawGuide(); renderObjects(); mergeItem(item);
      if (item.legacy_corrections_notice) toast(item.legacy_corrections_notice);
      if (item.statistics?.proposal?.failed) toast((item.statistics.proposal.warnings || ['Automatic proposals could not be generated. Switch to Basic or change the settings.']).join(' '), true);
      if (item.statistics?.proposal?.low_contrast) toast('Low-contrast image: inspect it manually. No reliable automatic proposal may be available.');
    } catch (exc) { error(exc); } finally { busy(false); }
  }
  function applyRecord(item) {
    state.current = item; state.selected = null; state.selectedZone = null; selectionCache = null;
    state.automation = {...clone(AUTOMATION_DEFAULTS), ...clone(item.automation || {})};
    state.erase = M.sparseDecode(item.manual_edits?.erase_rle || [[0, item.width * item.height]], item.width * item.height);
    state.reloadUndo = null; state.proposalStats = clone(item.statistics?.proposal || null);
    if (Array.isArray(item.objects)) state.objects = item.objects.map(object => ({id: object.id, name: object.name, kind: object.kind, visible: object.visible !== false, mask: M.sparseDecode(object.mask_rle, item.width * item.height)}));
    else { const mask = M.sparseDecode(item.mask_rle, item.width * item.height); state.objects = M.hasPixels(mask) ? [{id: 'legacy-import', name: 'Existing annotation', kind: 'legacy', visible: true, mask}] : []; }
    state.region = M.regionMask(item.width, item.height, item.roi); state.mask = M.compose(state.objects, state.region);
    const savedMask = M.decode(item.mask_rle, item.width * item.height);
    state.dirty = state.mask.some((label, i) => label !== savedMask[i]); state.undo = []; state.redo = [];
    if (state.dirty) toast('Existing defect classes were updated to follow the boundary. Review and save this change.');
    $('notes').value = item.notes || ''; $('sensitivity').value = item.settings?.sensitivity ?? 4; $('min-area').value = item.settings?.min_area ?? 6; $('polarity').value = item.settings?.polarity || 'both';
    syncAutomation(); syncChamfer(); showProposalStatus(); fieldCheckpoint = capture(); updateStatus();
  }
  // Completed object buffers are immutable. A new stroke/eraser owns new buffers,
  // so history can share masks while preserving exact undo and avoiding copies.
  function capture() { return {objects: state.objects.map(object => ({...object})), roi: clone(state.current.roi), detection: clone(state.current.roi_detection), selected: state.selected, selectedZone: state.selectedZone, automation: clone(state.automation), erase: state.erase, notes: $('notes').value, settings: {sensitivity: $('sensitivity').value, min_area: $('min-area').value, polarity: $('polarity').value}, proposalStats: clone(state.proposalStats)}; }
  function trimHistory() {
    const all = [...state.undo, ...state.redo, ...(state.reloadUndo ? [state.reloadUndo] : [])]; const buffers = new Set(); let bytes = 0;
    for (const snapshot of all) for (const mask of [...snapshot.objects.map(object=>object.mask), snapshot.erase].filter(Boolean)) if (!buffers.has(mask)) { buffers.add(mask); bytes += mask.spans ? mask.spans.length * 80 : mask.byteLength; }
    while ((state.undo.length > 30 || state.redo.length > 30 || bytes > 128 * 1024 * 1024) && state.undo.length + state.redo.length > 1) {
      if (state.undo.length > 1) state.undo.shift(); else if (state.redo.length > 1) state.redo.shift(); else break;
      return trimHistory();
    }
  }
  function historyPush() { state.reloadUndo = null; state.undo.push(capture()); state.redo = []; trimHistory(); updateButtons(); }
  function restoreSnapshot(snapshot) {
    state.objects = snapshot.objects.map(object => ({...object})); state.current.roi = clone(snapshot.roi); state.current.roi_detection = clone(snapshot.detection); state.selected = snapshot.selected; state.selectedZone = snapshot.selectedZone;
    state.automation = clone(snapshot.automation); state.erase = snapshot.erase; state.proposalStats = clone(snapshot.proposalStats); $('notes').value = snapshot.notes;
    $('sensitivity').value = snapshot.settings.sensitivity; $('min-area').value = snapshot.settings.min_area; $('polarity').value = snapshot.settings.polarity;
    state.region = M.regionMask(state.current.width, state.current.height, state.current.roi); selectionCache = null; syncAutomation(); syncChamfer(); showProposalStatus(); fieldCheckpoint = capture();
  }
  function historyMove(from, to) {
    if (!from.length || state.busy || state.drag) return;
    state.polygon = []; state.reloadUndo = null; to.push(capture()); restoreSnapshot(from.pop()); trimHistory(); dirty(); drawMask(); drawGuide(); renderObjects();
  }
  function drawMask() {
    if (!state.current || !state.region) return;
    state.mask = M.compose(state.objects, state.region);
    const display = state.objects.some(object => object.visible === false) ? M.compose(state.objects, state.region, true) : state.mask;
    const pixels = maskContext.createImageData(state.current.width, state.current.height), opacity = Number($('opacity').value) * 2.55;
    for (let i = 0; i < display.length; i++) {
      const label = display[i]; if (!label) continue; const p = i * 4;
      pixels.data[p] = label === 1 ? 255 : 70; pixels.data[p + 1] = label === 1 ? 100 : 186; pixels.data[p + 2] = label === 1 ? 105 : 255; pixels.data[p + 3] = opacity;
    }
    maskContext.putImageData(pixels, 0, 0); maskCanvas.style.display = $('show-mask').checked ? '' : 'none';
    const counts = M.counts(state.mask); $('inner-count').textContent = counts[1].toLocaleString(); $('outer-count').textContent = counts[2].toLocaleString();
  }
  function thumbnail(canvas, object) {
    const w = state.current.width, h = state.current.height, box = M.bounds(object.mask, w, h), ctx = canvas.getContext('2d');
    canvas.width = 64; canvas.height = 56;
    if (!box) return;
    const sw = box.right - box.left + 1, sh = box.bottom - box.top + 1, scale = Math.min(52 / sw, 44 / sh), left = (64 - sw * scale) / 2, top = (56 - sh * scale) / 2;
    // Downsample by occupancy, so even a one-pixel or fine ring remains visible.
    const pixels = ctx.createImageData(64, 56);
    M.each(object.mask, i => {
      const x = i % w, y = Math.floor(i / w);
      const px0 = Math.floor(left + (x - box.left) * scale), py0 = Math.floor(top + (y - box.top) * scale);
      const px1 = Math.min(63, Math.ceil(left + (x - box.left + 1) * scale)), py1 = Math.min(55, Math.ceil(top + (y - box.top + 1) * scale));
      for (let py = py0; py <= py1; py++) for (let px = px0; px <= px1; px++) {
        const k = 4 * (px + py * 64), inner = state.region[i]; pixels.data[k] = inner ? 255 : 70; pixels.data[k + 1] = inner ? 100 : 186; pixels.data[k + 2] = inner ? 105 : 255; pixels.data[k + 3] = 255;
      }
    });
    ctx.putImageData(pixels, 0, 0);
  }
  function renderObjects() {
    const list = $('object-list'); list.replaceChildren(); $('object-count').textContent = state.objects.length;
    const selected = state.objects.find(object => object.id === state.selected);
    $('selected-object').textContent = selected ? `Selected: ${selected.name}${selected.visible === false ? ' (hidden)' : ''}` : 'Select a shape to highlight its outline.';
    $('empty-objects').classList.toggle('hidden', state.objects.length > 0);
    for (const object of [...state.objects].reverse()) {
      const row = document.createElement('div'); row.className = `object-row${state.selected === object.id ? ' selected' : ''}${object.visible === false ? ' object-hidden' : ''}`; row.dataset.objectId = object.id;
      const select = document.createElement('button'); select.className = 'object-select'; select.type = 'button'; select.title = `Select ${object.name}`; select.setAttribute('aria-pressed', String(state.selected === object.id));
      const canvas = document.createElement('canvas'); canvas.className = 'object-thumbnail'; canvas.setAttribute('aria-label', `${object.name} shape preview`); thumbnail(canvas, object);
      const text = document.createElement('span'); text.className = 'object-label'; const name = document.createElement('span'); name.textContent = object.name;
      const detail = document.createElement('small'); const area = M.bounds(object.mask, state.current.width, state.current.height)?.area || 0; detail.textContent = `${object.kind} · ${area.toLocaleString()} px`; text.append(name, detail); select.append(canvas, text);
      select.addEventListener('click', () => { state.selected = state.selected === object.id ? null : object.id; selectionCache = null; renderObjects(); drawGuide(); });
      const visible = document.createElement('input'); visible.type = 'checkbox'; visible.className = 'object-visible'; visible.checked = object.visible !== false; visible.title = 'Show shape (hidden shapes remain in the dataset)'; visible.setAttribute('aria-label', `Show ${object.name}`);
      visible.addEventListener('change', () => { if (state.busy || state.drag) return; historyPush(); state.objects = state.objects.map(o => o.id === object.id ? {...o, visible: visible.checked} : o); dirty(); drawMask(); drawGuide(); renderObjects(); });
      const remove = document.createElement('button'); remove.className = 'object-delete'; remove.type = 'button'; remove.textContent = '×'; remove.title = `Delete ${object.name} (undo available)`; remove.setAttribute('aria-label', `Delete ${object.name}`);
      remove.addEventListener('click', () => deleteObject(object.id)); row.append(select, visible, remove); list.append(row);
    }
    updateButtons();
  }
  function deleteObject(id) { if (state.busy || state.drag) return; historyPush(); const deleted = state.objects.find(object => object.id === id); if (deleted?.kind === 'proposal') state.erase = M.union(state.erase, deleted.mask); state.objects = state.objects.filter(object => object.id !== id); if (state.selected === id) state.selected = null; dirty(); drawMask(); drawGuide(); renderObjects(); }
  function addObject(kind, mask) {
    if (!M.hasPixels(mask)) return null;
    const base = kind[0].toUpperCase() + kind.slice(1); let number = 1;
    const names = new Set(state.objects.map(object => object.name)); while (names.has(`${base} ${number}`)) number++;
    const object = {id: `obj-${crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2)}`, name: `${base} ${number}`, kind, visible: true, mask};
    state.objects.push(object); state.selected = null; return object;
  }
  function roiString(roi) { return roi.type === 'polygon' ? `${roi.points.length}-vertex inner boundary · drag handles with Boundary tool` : `Ellipse · centre ${Math.round(roi.cx)}, ${Math.round(roi.cy)} · use Boundary to replace`; }
  function ellipseFromDrag(a, b, shift) {
    let dx = b.x - a.x, dy = b.y - a.y;
    if (shift) { const size = Math.min(Math.abs(dx), Math.abs(dy)); dx = Math.sign(dx || 1) * size; dy = Math.sign(dy || 1) * size; }
    return {cx: a.x + dx / 2, cy: a.y + dy / 2, rx: Math.abs(dx) / 2, ry: Math.abs(dy) / 2};
  }
  function drawSelection() {
    const object = state.objects.find(o => o.id === state.selected);
    if (!object || object.visible === false || !$('show-mask').checked) return;
    if (!selectionCache || selectionCache.mask !== object.mask) {
      const {width: w, height: h} = state.current, canvas = document.createElement('canvas'); canvas.width = w; canvas.height = h;
      const ctx = canvas.getContext('2d'), data = ctx.createImageData(w, h), mask = M.dense(object.mask);
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const i = x + y * w; if (mask[i] && (!x || !y || x === w - 1 || y === h - 1 || !mask[i - 1] || !mask[i + 1] || !mask[i - w] || !mask[i + w])) { data.data.set([255, 255, 255, 255], 4 * i); } }
      ctx.putImageData(data, 0, 0); selectionCache = {mask: object.mask, canvas};
    }
    guideContext.drawImage(selectionCache.canvas, 0, 0);
  }
  function drawGuide() {
    guideContext.clearRect(0, 0, guideCanvas.width, guideCanvas.height);
    if (!state.current) return;
    const ctx = guideContext, roi = state.current.roi;
    const drawEllipse = r => { if (r && r.rx > 0 && r.ry > 0) { ctx.beginPath(); ctx.ellipse(r.cx, r.cy, r.rx, r.ry, 0, 0, 2 * Math.PI); ctx.stroke(); } };
    const drawPolygon = points => { if (!points?.length) return; ctx.beginPath(); ctx.moveTo(points[0].x, points[0].y); for (const p of points.slice(1)) ctx.lineTo(p.x, p.y); ctx.closePath(); ctx.stroke(); };
    drawSelection(); ctx.lineWidth = 1.5 / state.zoom;
    if (roi && $('show-roi').checked) {
      ctx.strokeStyle = '#f4d77c'; ctx.setLineDash([7 / state.zoom, 5 / state.zoom]);
      if (roi.type === 'polygon') drawPolygon(roi.points); else drawEllipse(roi); ctx.setLineDash([]);
      if (state.tool === 'roi' && roi.type === 'polygon' && !state.polygon.length) { ctx.fillStyle = '#f4d77c'; for (const p of roi.points) { ctx.fillRect(p.x - 3 / state.zoom, p.y - 3 / state.zoom, 6 / state.zoom, 6 / state.zoom); } }
    }
    drawAutomationGuides(ctx, drawPolygon, drawEllipse);
    $('roi-readout').textContent = roi ? `${roiString(roi)}${state.current.roi_detection ? state.current.roi_detection.found ? ' · Detected — review outline' : ' · Initial estimate — adjust boundary' : ' · Manual boundary'}` : 'Draw a polygon around the inner lens.';
    ctx.strokeStyle = ['roi', 'octagon'].includes(state.tool) ? '#f4d77c' : state.tool === 'eraser' ? '#ffffff' : '#bbf2df';
    ctx.fillStyle = ['roi', 'octagon'].includes(state.tool) ? '#f4d77c22' : '#bbf2df22';
    const drag = state.drag;
    if (drag && drag.mode === 'shape') {
      const a = drag.start, b = drag.end;
      if (drag.tool === 'circle') { const r = Math.hypot(b.x - a.x, b.y - a.y); drawEllipse({cx: a.x, cy: a.y, rx: r, ry: r}); ctx.fill(); }
      else if (['ellipse', 'eye'].includes(drag.tool)) { drawEllipse(ellipseFromDrag(a, b, drag.shift)); ctx.fill(); }
      else if (drag.tool === 'octagon') { drawPolygon(M.octagon(a, b).points); ctx.fill(); }
      else if (drag.tool === 'rectangle') { ctx.strokeRect(a.x, a.y, b.x - a.x, b.y - a.y); ctx.fillRect(a.x, a.y, b.x - a.x, b.y - a.y); }
    }
    if (state.polygon.length) {
      ctx.beginPath(); ctx.moveTo(state.polygon[0].x, state.polygon[0].y); for (const p of state.polygon.slice(1)) ctx.lineTo(p.x, p.y); if (state.pointer && inside(state.pointer)) ctx.lineTo(state.pointer.x, state.pointer.y); ctx.stroke();
      for (const p of state.polygon) { ctx.beginPath(); ctx.arc(p.x, p.y, 3 / state.zoom, 0, 2 * Math.PI); ctx.fill(); }
    }
    if (state.pointer && inside(state.pointer) && !state.space && !state.drag && ['brush', 'eraser'].includes(state.tool)) drawEllipse({cx: state.pointer.x, cy: state.pointer.y, rx: Number($('brush-size').value) / 2, ry: Number($('brush-size').value) / 2});
  }
  function transform() { wrap.style.transform = `translate(${state.x}px, ${state.y}px) scale(${state.zoom})`; $('zoom-value').textContent = `${Math.round(state.zoom * 100)}%`; drawGuide(); }
  function fit() { if (!state.current || state.drag) return; state.zoom = Math.max(0.01, Math.min((viewport.clientWidth - 40) / state.current.width, (viewport.clientHeight - 40) / state.current.height)); state.x = (viewport.clientWidth - state.current.width * state.zoom) / 2; state.y = (viewport.clientHeight - state.current.height * state.zoom) / 2; transform(); }
  function zoom(value, clientX, clientY) {
    if (!state.current || state.drag) return; const rect = viewport.getBoundingClientRect(), px = (clientX ?? rect.left + rect.width / 2) - rect.left, py = (clientY ?? rect.top + rect.height / 2) - rect.top;
    const next = Math.max(0.01, Math.min(30, value)), ratio = next / state.zoom; state.x = px - (px - state.x) * ratio; state.y = py - (py - state.y) * ratio; state.zoom = next; transform();
  }
  function point(event) { const rect = viewport.getBoundingClientRect(); return {x: (event.clientX - rect.left - state.x) / state.zoom, y: (event.clientY - rect.top - state.y) / state.zoom}; }
  function inside(p) { return state.current && p.x >= 0 && p.y >= 0 && p.x < state.current.width && p.y < state.current.height; }
  function bounded(p) { return {x: Math.max(0, Math.min(state.current.width, p.x)), y: Math.max(0, Math.min(state.current.height, p.y))}; }
  function setTool(tool) { if (state.drag) return; if (state.polygon.length && tool !== state.tool && !confirm('Discard the unfinished polygon?')) return; state.polygon = []; state.tool = tool; document.querySelectorAll('[data-tool]').forEach(x => x.classList.toggle('selected', x.dataset.tool === tool)); viewport.style.cursor = tool === 'pan' ? 'grab' : 'crosshair'; drawGuide(); }
  function setROI(roi) { state.current.roi = roi; state.current.roi_detection = null; state.region = M.regionMask(state.current.width, state.current.height, roi); dirty(); syncChamfer(); syncEye(); drawMask(); drawGuide(); }
  function finishPolygon() {
    if (['roi', 'scope', 'zone'].includes(state.tool) && state.polygon.length > 128) { toast('An inner boundary can have at most 128 vertices.', true); return; }
    if (!M.validPolygon(state.polygon)) { toast('Use at least three vertices and a closed outline without crossing edges.', true); return; }
    if(state.tool==='zone' && state.automation.zones.length>=64){toast('At most 64 exclusion zones are supported. Remove a zone before drawing another.',true);return;}
    historyPush();
    if (state.tool === 'roi') setROI({type: 'polygon', points: state.polygon.map(p => ({...p}))});
    else if (state.tool === 'scope') { state.automation.scope_roi = {type:'polygon', points: clone(state.polygon)}; state.automation.scope = 'custom'; syncAutomation(); }
    else if (state.tool === 'zone') { const category = $('zone-category').value; const id = makeId('zone'); state.automation.zones.push({id, name: `${category[0].toUpperCase()+category.slice(1)} ${state.automation.zones.length + 1}`, category, roi:{type:'polygon',points:clone(state.polygon)}}); state.selectedZone = id; syncAutomation(); }
    else { const mask = new Uint8Array(state.current.width * state.current.height); M.polygon(mask, state.current.width, state.current.height, state.polygon, 1); addObject('polygon', M.compact(mask)); }
    state.polygon = []; dirty(); drawMask(); drawGuide(); renderObjects();
  }
  function brushAt(a, b) {
    const drag = state.drag, w = state.current.width, h = state.current.height;
    if (drag.eraser) { const eraser = M.strokeFootprint(w, h, a, b, drag.size); state.erase = M.union(state.erase, eraser); state.objects = state.objects.map(object => ({...object, mask: M.subtract(object.mask, eraser)})); }
    else M.stroke(drag.object.mask, w, h, a, b, drag.size, 1);
    dirty(); drawMask();
  }
  viewport.addEventListener('pointerdown', event => {
    if (!state.current || state.busy || state.drag || (event.button !== 0 && event.button !== 1)) return;
    event.preventDefault(); viewport.focus(); const p = point(event); state.pointer = p;
    // Decide once at pointerdown: background drags pan, image drags annotate.
    // Crossing an image edge later never changes the gesture type.
    if (state.tool === 'pan' || state.space || event.button === 1 || !inside(p)) { state.drag = {mode: 'pan', pointerId: event.pointerId, start: {x: event.clientX, y: event.clientY}, originX: state.x, originY: state.y}; viewport.setPointerCapture(event.pointerId); viewport.style.cursor = 'grabbing'; return; }
    if (state.tool === 'roi' && !state.polygon.length && state.current.roi?.type === 'polygon' && $('show-roi').checked) {
      const index = state.current.roi.points.findIndex(vertex => Math.hypot(p.x - vertex.x, p.y - vertex.y) <= 9 / state.zoom);
      if (index >= 0) { const before = capture(), redoBefore = state.redo.slice(); historyPush(); state.current.roi = clone(state.current.roi); state.current.roi_detection = null; state.drag = {mode: 'vertex', pointerId: event.pointerId, index, before, redoBefore, previousDirty: state.dirty}; viewport.setPointerCapture(event.pointerId); return; }
    }
    if (['zone', 'scope'].includes(state.tool) && !state.polygon.length) {
      const roi = state.tool === 'scope' ? state.automation.scope_roi : state.automation.zones.find(z => z.id === state.selectedZone)?.roi;
      const index = roi?.type === 'polygon' ? roi.points.findIndex(vertex => Math.hypot(p.x-vertex.x,p.y-vertex.y) <= 9/state.zoom) : -1;
      if (index >= 0) { const before=capture(), redoBefore=state.redo.slice(); historyPush(); state.automation=clone(state.automation); state.drag={mode:'automation-vertex',target:state.tool,zoneId:state.selectedZone,pointerId:event.pointerId,index,before,redoBefore,previousDirty:state.dirty}; viewport.setPointerCapture(event.pointerId); return; }
    }
    if (['polygon', 'roi', 'scope', 'zone'].includes(state.tool)) {
      if (state.polygon.length >= 3 && Math.hypot(p.x - state.polygon[0].x, p.y - state.polygon[0].y) < 8 / state.zoom) finishPolygon();
      else if (['roi','zone','scope'].includes(state.tool) && state.polygon.length >= 128) toast('Maximum 128 boundary vertices. Press Enter to close.', true);
      else { state.polygon.push(p); drawGuide(); } return;
    }
    viewport.setPointerCapture(event.pointerId);
    if (['brush', 'eraser'].includes(state.tool)) {
      const before = capture(), previousDirty = state.dirty, redoBefore = state.redo.slice(); historyPush();
      state.drag = {mode: 'brush', pointerId: event.pointerId, last: p, eraser: state.tool === 'eraser', size: Number($('brush-size').value), before, previousDirty, redoBefore};
      if (!state.drag.eraser) { const mask = new Uint8Array(state.current.width * state.current.height); M.stroke(mask, state.current.width, state.current.height, p, p, state.drag.size, 1); state.drag.object = addObject('brush', mask); }
      brushAt(p, p);
    } else state.drag = {mode: 'shape', pointerId: event.pointerId, tool: state.tool, start: p, end: p, shift: event.shiftKey};
    drawGuide();
  });
  viewport.addEventListener('pointermove', event => {
    if (!state.current || state.busy) return;
    state.pointer = point(event); const drag = state.drag;
    if (drag && drag.pointerId !== event.pointerId) return;
    if (drag?.mode === 'pan') { state.x = drag.originX + event.clientX - drag.start.x; state.y = drag.originY + event.clientY - drag.start.y; transform(); return; }
    viewport.style.cursor = state.tool === 'pan' || state.space || !inside(state.pointer) ? 'grab' : 'crosshair';
    if (drag?.mode === 'brush') { brushAt(drag.last, state.pointer); drag.last = state.pointer; }
    else if (drag?.mode === 'shape') { drag.end = bounded(state.pointer); drag.shift = event.shiftKey; }
    else if (drag?.mode === 'automation-vertex') { automationDragROI(drag).points[drag.index] = bounded(state.pointer); dirty(); }
    else if (drag?.mode === 'vertex') { state.current.roi.points[drag.index] = bounded(state.pointer); state.region = M.regionMask(state.current.width, state.current.height, state.current.roi); dirty(); drawMask(); }
    drawGuide();
  });
  function endCapture(event) { if (event && viewport.hasPointerCapture(event.pointerId)) viewport.releasePointerCapture(event.pointerId); viewport.style.cursor = state.tool === 'pan' ? 'grab' : 'crosshair'; }
  viewport.addEventListener('pointerup', event => {
    const drag = state.drag; if (!drag || drag.pointerId !== event.pointerId) return;
    if (drag.mode === 'brush') {
      brushAt(drag.last, point(event)); state.objects = state.objects.filter(object => M.hasPixels(object.mask)).map(object => ({...object, mask: M.compact(object.mask)}));
      if (!state.objects.some(object => object.id === state.selected)) state.selected = null;
    } else if (drag.mode === 'automation-vertex') {
      const roi=automationDragROI(drag); roi.points[drag.index]=bounded(point(event));
      if (!M.validPolygon(roi.points)) { restoreSnapshot(drag.before);state.undo.pop();state.redo=drag.redoBefore;state.dirty=drag.previousDirty;toast('Polygon edges cannot cross. Previous geometry restored.',true); }
      else { dirty(); syncAutomation(); }
    } else if (drag.mode === 'vertex') {
      state.current.roi.points[drag.index] = bounded(point(event));
      if (!M.validPolygon(state.current.roi.points)) { restoreSnapshot(drag.before); state.undo.pop(); state.redo = drag.redoBefore || []; state.dirty = drag.previousDirty; toast('Boundary edges cannot cross. The previous boundary was restored.', true); }
      else { state.region = M.regionMask(state.current.width, state.current.height, state.current.roi); dirty(); }
    } else if (drag.mode === 'shape') {
      drag.end = bounded(point(event)); drag.shift = event.shiftKey; const a = drag.start, b = drag.end;
      if (Math.hypot(b.x - a.x, b.y - a.y) >= 1) {
        const w = state.current.width, h = state.current.height, mask = new Uint8Array(w * h);
        if (drag.tool === 'eye') { const eye={type:'ellipse',...ellipseFromDrag(a,b,drag.shift)};if(eye.rx>=1&&eye.ry>=1){historyPush();state.automation.eye=eye;dirty();syncEye();}else toast('Draw an eye ellipse with positive width and height.',true); }
        else if (drag.tool === 'octagon') { const roi = M.octagon(a, b); if (M.validPolygon(roi.points)) { historyPush(); setROI(roi); } }
        else {
          if (drag.tool === 'circle') { const radius = Math.hypot(b.x - a.x, b.y - a.y); M.ellipse(mask, w, h, a.x, a.y, radius, radius, 1); }
          else if (drag.tool === 'rectangle') M.rectangle(mask, w, h, a, b, 1);
          else { const roi = ellipseFromDrag(a, b, drag.shift); M.ellipse(mask, w, h, roi.cx, roi.cy, roi.rx, roi.ry, 1); }
          if (mask.some(Boolean)) { historyPush(); addObject(drag.tool, M.compact(mask)); dirty(); }
        }
      }
    }
    state.drag = null; endCapture(event); drawMask(); drawGuide(); renderObjects(); updateStatus();
  });
  function cancelGesture(event) {
    const drag = state.drag;
    if (drag?.before) { restoreSnapshot(drag.before); state.undo.pop(); state.redo = drag.redoBefore || []; state.dirty = drag.previousDirty; }
    state.drag = null; state.polygon = []; endCapture(event); drawMask(); drawGuide(); renderObjects(); updateStatus();
  }
  viewport.addEventListener('pointercancel', cancelGesture);
  viewport.addEventListener('lostpointercapture', event => { if (state.drag?.pointerId === event.pointerId) cancelGesture(event); });
  viewport.addEventListener('pointerleave', () => { if (!state.drag) { state.pointer = null; drawGuide(); } });
  viewport.addEventListener('wheel', event => { event.preventDefault(); if (!state.busy) zoom(state.zoom * Math.exp(-event.deltaY * 0.0015), event.clientX, event.clientY); }, {passive: false});
  function settings() {
    const sensitivity = Number($('sensitivity').value), minArea = Number($('min-area').value);
    if (!Number.isFinite(sensitivity) || sensitivity < 0.5 || sensitivity > 20 || !Number.isInteger(minArea) || minArea < 1 || minArea > 100000) throw new Error('Sensitivity must be 0.5–20 and minimum area must be an integer from 1 to 100000.');
    return {...state.current.settings, sensitivity, min_area: minArea, polarity: $('polarity').value};
  }
  function serializeObjects() { return state.objects.map(({mask, ...object}) => ({...object, mask_rle: M.encode(mask)})); }
  function unfinished() { if (state.polygon.length || state.drag) { toast('Finish the current stroke or shape, or press Escape to cancel, before continuing.', true); return true; } return false; }
  async function nextUnfinished() {
    const index = currentIndex(); const next = [...state.items.slice(index + 1), ...state.items.slice(0, index)].find(x => !['approved', 'rejected'].includes(x.status));
    if (next) await openImage(next.id); else toast('Review complete. Included images are approved; excluded images stay out of the dataset.');
  }
  async function save(approved, clean = false, advance = true) {
    if (!state.current || state.busy || unfinished()) return false;
    if (approved && state.current.status === 'rejected') { toast('Restore this image to a draft before approving it.', true); return false; }
    const counts = M.counts(state.mask);
    if (approved && counts[1] + counts[2] === 0 && !clean) { toast('This mask is empty. Use “Approve clean & next” to confirm a reviewed negative image.', true); return false; }
    if (clean && counts[1] + counts[2] > 0) { toast('Clear all defect pixels before approving a clean image. Hidden objects still contain defect pixels.', true); return false; }
    let payload; try { payload = {objects: serializeObjects(), mask_rle: M.encode(state.mask), roi: state.current.roi, settings: settings(), automation: clone(state.automation), manual_edits: {erase_rle:M.encode(state.erase)}, proposal_statistics: clone(state.proposalStats), expected_revision: state.current.revision, approved, clean, notes: $('notes').value}; } catch (exc) { error(exc); return false; }
    const id = state.current.id; busy(true, 'Saving annotation…');
    try {
      const item = await api(`/api/image/${id}/annotation`, payload); applyRecord(item); mergeItem(item); drawMask(); drawGuide(); renderObjects();
      toast(approved ? (clean ? 'Clean image approved.' : 'Annotation approved.') : item.status === 'rejected' ? 'Edits saved. Image remains excluded.' : 'Draft saved.');
      busy(false); if (approved && advance) await nextUnfinished(); return true;
    } catch (exc) { error(exc); return false; } finally { busy(false); updateStatus(); }
  }
  async function changeInclusion(reject) {
    if (!state.current || state.busy || unfinished()) return;
    if (state.dirty && !(await save(false, false, false))) return;
    busy(true, reject ? 'Excluding image from the dataset…' : 'Restoring image as a draft…');
    try {
      const item = await api(`/api/image/${state.current.id}/${reject ? 'reject' : 'restore'}`, {expected_revision: state.current.revision});
      applyRecord(item); mergeItem(item); drawMask(); drawGuide(); renderObjects(); busy(false);
      if (reject) { toast('Image excluded. Its original and annotations are preserved.'); await nextUnfinished(); }
      else toast('Image restored as a draft. Review and approve it to include it in training.');
    } catch (exc) { error(exc); } finally { busy(false); }
  }
  async function detectROI() {
    if (!state.current || state.busy || unfinished()) return;
    busy(true, 'Looking for the polygonal inner boundary…');
    try {
      const result = await api(`/api/image/${state.current.id}/detect-roi`, {expected_revision: state.current.revision, roi: state.current.roi, mode:$('boundary-mode').value || 'guided'});
      if (result.detection?.found && result.roi) { historyPush(); setROI(result.roi); state.current.roi_detection = clone(result.detection); drawGuide(); renderObjects(); toast(result.detection.note || 'Boundary proposal applied. Inspect the yellow outline and adjust its vertices before approval.'); }
      else toast(result.detection?.note || 'No reliable polygon was found. Draw the boundary manually; your current annotations are preserved.');
    } catch (exc) { error(exc); } finally { busy(false); }
  }
  async function regenerate() {
    if (!state.current || state.busy || unfinished()) return;
    const keep = $('keep-manual').checked;
    if (!keep && (state.objects.some(object => object.kind !== 'proposal') || M.hasPixels(state.erase)) && !confirm('Discard manual additions and erasures for this reload? Undo remains available until you save or leave this image.')) return;
    let payload; try { payload = {roi: clone(state.current.roi), settings: settings(), automation:clone(state.automation), expected_revision: state.current.revision}; } catch (exc) { error(exc); return; }
    const before = capture(); busy(true, 'Generating proposals at native resolution…');
    try {
      const result = await api(`/api/image/${state.current.id}/proposal-preview`, payload);
      const total = state.current.width * state.current.height;
      // Decode every response before touching live state, so malformed/failed responses preserve edits.
      const erase = keep ? state.erase : {spans:[],length:total};
      const proposals = result.objects.map(object => ({id:makeId('proposal'),name:object.name,kind:'proposal',visible:object.visible !== false,mask:M.subtract(M.sparseDecode(object.mask_rle,total),erase)})).filter(object=>M.hasPixels(object.mask));
      const retained = keep ? state.objects.filter(object=>object.kind !== 'proposal') : [];
      historyPush(); state.reloadUndo = before; state.erase = erase; state.objects = [...proposals,...retained]; state.selected = null;
      state.automation = clone(result.automation || payload.automation); state.proposalStats = clone(result.statistics?.proposal || result.statistics || {});
      state.polygon = []; dirty(); syncAutomation(); fieldCheckpoint=capture(); drawMask(); drawGuide(); renderObjects(); showProposalStatus();
      toast(state.proposalStats.warnings?.length ? state.proposalStats.warnings.join(' ') : 'Proposals reloaded. Manual review is required; save when ready.', !!state.proposalStats.failed);
    } catch (exc) { error(exc); } finally { busy(false); }
  }
  function navigate(direction) { let index = currentIndex() + direction; while (index >= 0 && index < state.items.length && $('hide-rejected').checked && state.items[index].status === 'rejected') index += direction; if (index >= 0 && index < state.items.length) openImage(state.items[index].id); }
  const AUTOMATION_DEFAULTS = {method:'basic',scope:'full',scope_roi:null,zones:[],exclude_label:true,exclude_symbols:true,exclude_eye:false,exclude_custom:true,suppress_edges:false,eye:null,radial_strength:1,reference_ids:[],reference_max_shift:32,reference_rotation:3,reference_min_correlation:.75};
  let automationProfile = {revision:0,enabled:false};
  const makeId = prefix => `${prefix}-${crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36)+Math.random().toString(36).slice(2)}`;
  const methodHelp = {basic:'Current detector. No label, symbol or eye exclusions. Detection area still applies.',exclusions:'Current detector with the enabled exclusion zones removed from automatic proposals.',structure:'Experimental ring correction and optional edge filtering, with enabled exclusion zones. Inspect the result carefully.',reference:'Experimental comparison with your selected good images, using alignment and brightness correction. Enabled exclusions still apply.'};
  function stableJSON(value) { if(Array.isArray(value))return `[${value.map(stableJSON).join(',')}]`;if(value && typeof value==='object')return `{${Object.keys(value).sort().map(key=>`${JSON.stringify(key)}:${stableJSON(value[key])}`).join(',')}}`;return JSON.stringify(value); }
  function showProposalStatus() {
    const stats=state.proposalStats, warnings=stats?.warnings || [];
    if(stats?.input_context && state.current) { try { stats.stale = stableJSON(stats.input_context)!==stableJSON({roi:state.current.roi,settings:settings(),automation:state.automation}); } catch(_) { stats.stale=true; } }
    const stale=stats?.stale?'Settings or boundary changed since these proposals; reload to apply them. ':'';
    $('proposal-status').textContent = stale + (stats?.failed ? `No automatic proposals generated. ${warnings.join(' ')} Choose Basic or change the settings and reload.` : warnings.length ? warnings.join(' ') : 'Reload previews changes. Save or approve when ready.');
    $('proposal-status').classList.toggle('proposal-warning', !!stats?.failed || !!stats?.stale || warnings.length>0);
  }
  function syncAutomation() {
    const a=state.automation; if(!a)return;
    $('annotation-method').value=a.method; $('detection-scope').value=a.scope;
    for(const key of ['exclude_label','exclude_symbols','exclude_eye','exclude_custom','suppress_edges']) $(key.replaceAll('_','-')).checked=a[key];
    $('radial-strength').value=a.radial_strength; $('reference-shift').value=a.reference_max_shift; $('reference-rotation').value=a.reference_rotation; $('reference-correlation').value=a.reference_min_correlation;
    $('method-help').textContent=methodHelp[a.method]; $('structure-section').classList.toggle('hidden',a.method!=='structure'); $('reference-section').classList.toggle('hidden',a.method!=='reference'); $('custom-scope-controls').classList.toggle('hidden',a.scope!=='custom');
    $('scope-info').textContent=a.scope_roi ? 'Custom area saved for this image. Draw again to replace, or drag its handles.' : 'Draw a polygon, then Enter. Required before custom-area reload.';
    syncEye();renderZones();renderReferences();updateButtons();
  }
  function effectiveEye() {
    if(state.automation?.eye)return state.automation.eye;
    const roi=state.current?.roi;if(!roi)return null;
    const pts=roi.type==='polygon'?roi.points:[{x:roi.cx-roi.rx,y:roi.cy-roi.ry},{x:roi.cx+roi.rx,y:roi.cy+roi.ry}];
    const left=Math.min(...pts.map(p=>p.x)),right=Math.max(...pts.map(p=>p.x)),top=Math.min(...pts.map(p=>p.y)),bottom=Math.max(...pts.map(p=>p.y));
    return {type:'ellipse',cx:(left+right)/2,cy:(top+bottom)/2,rx:(right-left)*.175,ry:(bottom-top)*.175};
  }
  function syncEye(){const roi=effectiveEye();if(!roi)return;const box=roi.type==='polygon'?{cx:(Math.min(...roi.points.map(p=>p.x))+Math.max(...roi.points.map(p=>p.x)))/2,cy:(Math.min(...roi.points.map(p=>p.y))+Math.max(...roi.points.map(p=>p.y)))/2,rx:(Math.max(...roi.points.map(p=>p.x))-Math.min(...roi.points.map(p=>p.x)))/2,ry:(Math.max(...roi.points.map(p=>p.y))-Math.min(...roi.points.map(p=>p.y)))/2}:roi;for(const k of ['cx','cy','rx','ry'])$(`eye-${k}`).value=Number(box[k].toFixed(2));}
  function renderZones(){
    const list=$('zone-list');list.replaceChildren();
    for(const zone of state.automation?.zones || []){
      const row=document.createElement('div');row.className=`zone-row${state.selectedZone===zone.id?' selected':''}`;
      const button=document.createElement('button');button.className='zone-select';button.textContent=zone.name;button.title=`${zone.category}: select to drag vertices`;button.addEventListener('click',()=>{if(state.busy)return;setTool('zone');state.selectedZone=zone.id;renderZones();drawGuide();});
      const remove=document.createElement('button');remove.textContent='×';remove.className='zone-delete';remove.title=`Remove ${zone.name}`;remove.addEventListener('click',()=>{if(state.busy)return;historyPush();state.automation.zones=state.automation.zones.filter(z=>z.id!==zone.id);if(state.selectedZone===zone.id)state.selectedZone=null;dirty();renderZones();drawGuide();});row.append(button,remove);list.append(row);
    }
    if(!state.automation?.zones.length){const note=document.createElement('p');note.className='small muted';note.textContent='No exclusion polygons drawn.';list.append(note);}
  }
  function renderReferences(){
    const list=$('reference-list');list.replaceChildren();if(!state.current)return;
    const selected=state.automation.reference_ids,term=$('reference-filter').value.toLowerCase();$('reference-count').textContent=`${selected.length} / 8 selected`;
    const candidates=state.items.filter(item=>selected.includes(item.id)||(item.id!==state.current.id&&item.width===state.current.width&&item.height===state.current.height&&(!term||item.relative_path.toLowerCase().includes(term)))).sort((x,y)=>Number(selected.includes(y.id))-Number(selected.includes(x.id))); 
    for(const item of candidates.slice(0,100)){
      const label=document.createElement('label');label.className='reference-row';const check=document.createElement('input');check.type='checkbox';check.checked=selected.includes(item.id);check.setAttribute('aria-label',`Reference ${item.relative_path}`);
      const name=document.createElement('span');name.textContent=`${item.relative_path}${item.id===state.current.id?' (current image — choose another)':''}`;label.title=name.textContent;label.append(check,name);
      check.addEventListener('change',()=>{if(state.busy)return;if(check.checked&&state.automation.reference_ids.length>=8){check.checked=false;toast('Choose at most 8 good reference images.',true);return;}historyPush();state.automation.reference_ids=check.checked?[...state.automation.reference_ids,item.id]:state.automation.reference_ids.filter(id=>id!==item.id);dirty();renderReferences();});list.append(label);
    }
    if(candidates.length>100){const p=document.createElement('p');p.className='small muted';p.textContent='Showing first 100 matches. Filter to find more images.';list.append(p);}
    for(const id of selected.filter(id=>!state.items.some(item=>item.id===id))){const remove=document.createElement('button');remove.className='wide danger-quiet';remove.textContent=`Remove unavailable reference ${id.slice(0,12)}`;remove.addEventListener('click',()=>{historyPush();state.automation.reference_ids=state.automation.reference_ids.filter(x=>x!==id);dirty();renderReferences();});list.append(remove);}
  }
  function automationDragROI(drag){return drag.target==='scope'?state.automation.scope_roi:state.automation.zones.find(z=>z.id===drag.zoneId).roi;}
  function drawAutomationGuides(ctx,drawPolygon,drawEllipse){
    const a=state.automation;if(!a)return;const stroke=(roi,color,handles=false)=>{if(!roi)return;ctx.strokeStyle=color;ctx.lineWidth=1.5/state.zoom;ctx.setLineDash([4/state.zoom,4/state.zoom]);if(roi.type==='polygon')drawPolygon(roi.points);else drawEllipse(roi);ctx.setLineDash([]);if(handles&&roi.type==='polygon'){ctx.fillStyle=color;for(const p of roi.points)ctx.fillRect(p.x-3/state.zoom,p.y-3/state.zoom,6/state.zoom,6/state.zoom);}};
    if($('show-zones').checked){const colors={label:'#d2a9ff',symbols:'#f3a8d1',eye:'#d79bff',custom:'#ffaf73'};for(const zone of a.zones){const active=a.method!=='basic'&&a[`exclude_${zone.category}`];stroke(zone.roi,active?colors[zone.category]:'#87919b',state.tool==='zone'&&state.selectedZone===zone.id&&!state.polygon.length);}
      if(a.eye||a.exclude_eye||a.method==='structure'||state.tool==='eye')stroke(effectiveEye(),a.method==='basic'?'#87919b':'#d79bff');
    }
    if($('show-scope').checked&&a.scope!=='full'){const roi=a.scope==='custom'?a.scope_roi:state.proposalStats?.effective_scope;stroke(roi,'#8cddb3',state.tool==='scope'&&!state.polygon.length);}
  }
  function syncChamfer(){
    const roi=state.current?.roi;if(!roi)return;const pts=roi.type==='polygon'?roi.points:[{x:roi.cx-roi.rx,y:roi.cy-roi.ry},{x:roi.cx+roi.rx,y:roi.cy+roi.ry}];
    // An eight-vertex chamfer template starts with its upper straight segment.
    const angle=pts.length===8?Math.atan2(pts[1].y-pts[0].y,pts[1].x-pts[0].x):0,cos=Math.cos(angle),sin=Math.sin(angle);
    const local=pts.map(p=>({x:p.x*cos+p.y*sin,y:-p.x*sin+p.y*cos}));const left=Math.min(...local.map(p=>p.x)),right=Math.max(...local.map(p=>p.x)),top=Math.min(...local.map(p=>p.y)),bottom=Math.max(...local.map(p=>p.y));const mx=(left+right)/2,my=(top+bottom)/2;
    const params={cx:mx*cos-my*sin,cy:mx*sin+my*cos,width:right-left,height:bottom-top,rotation:angle*180/Math.PI};for(const[k,v]of Object.entries(params))$(`chamfer-${k}`).value=Number(v.toFixed(2));
    const cuts=pts.length===8?{tl:{x:local[0].x-left,y:local[7].y-top},tr:{x:right-local[1].x,y:local[2].y-top},br:{x:right-local[4].x,y:bottom-local[3].y},bl:{x:local[5].x-left,y:bottom-local[6].y}}:Object.fromEntries(['tl','tr','br','bl'].map(k=>[k,{x:(right-left)*.15,y:(bottom-top)*.15}]));
    for(const c of ['tl','tr','br','bl'])for(const axis of ['x','y'])$(`cut-${c}-${axis}`).value=Number(Math.max(0,cuts[c][axis]).toFixed(2));
  }
  async function refreshProfile(){automationProfile=await api('/api/automation');$('profile-info').textContent=automationProfile.revision?`Profile revision ${automationProfile.revision} · ${automationProfile.enabled?'reuse enabled':'reuse disabled'}`:'No automation profile saved.';if(automationProfile.revision)$('profile-enabled').checked=automationProfile.enabled;}
  for(const[id,key]of [['annotation-method','method'],['detection-scope','scope'],['radial-strength','radial_strength'],['reference-shift','reference_max_shift'],['reference-rotation','reference_rotation'],['reference-correlation','reference_min_correlation']])$(id).addEventListener('change',()=>{if(!state.current||state.busy)return;historyPush();state.automation[key]=['method','scope'].includes(key)?$(id).value:Number($(id).value);dirty();syncAutomation();drawGuide();});
  for(const key of ['exclude_label','exclude_symbols','exclude_eye','exclude_custom','suppress_edges'])$(key.replaceAll('_','-')).addEventListener('change',()=>{if(!state.current||state.busy)return;historyPush();state.automation[key]=$(key.replaceAll('_','-')).checked;dirty();drawGuide();});
  $('reference-filter').addEventListener('input',renderReferences);
  $('draw-zone').addEventListener('click',()=>{state.selectedZone=null;renderZones();});
  $('apply-eye').addEventListener('click',()=>{if(!state.current||state.busy||unfinished())return;const roi={type:'ellipse'};for(const k of ['cx','cy','rx','ry'])roi[k]=Number($(`eye-${k}`).value);if(![roi.cx,roi.cy,roi.rx,roi.ry].every(Number.isFinite)||roi.rx<1||roi.ry<1||roi.cx-roi.rx<0||roi.cy-roi.ry<0||roi.cx+roi.rx>state.current.width||roi.cy+roi.ry>state.current.height){toast('Eye ellipse must have positive radii and fit inside the image.',true);return;}historyPush();state.automation.eye=roi;dirty();drawGuide();});
  $('reset-eye').addEventListener('click',()=>{if(!state.current||state.busy)return;historyPush();state.automation.eye=null;syncEye();dirty();drawGuide();});
  $('read-chamfer').addEventListener('click',syncChamfer);
  $('apply-chamfer').addEventListener('click',()=>{if(!state.current||state.busy||unfinished())return;try{const params={cuts:{}};for(const k of ['cx','cy','width','height','rotation'])params[k]=Number($(`chamfer-${k}`).value);for(const c of ['tl','tr','br','bl'])params.cuts[c]={x:Number($(`cut-${c}-x`).value),y:Number($(`cut-${c}-y`).value)};const roi=M.chamferedRectangle(params);if(roi.points.some(p=>p.x<0||p.y<0||p.x>state.current.width||p.y>state.current.height))throw new Error('The rotated boundary must fit inside the image.');historyPush();setROI(roi);setTool('roi');toast('Boundary updated. Save custom polygon to reuse it on other images.');}catch(exc){error(exc);}});
  $('undo-reload').addEventListener('click',()=>{if(!state.reloadUndo||state.busy||unfinished())return;const before=state.reloadUndo;historyPush();restoreSnapshot(before);state.reloadUndo=null;dirty();drawMask();drawGuide();renderObjects();toast('Restored the annotation from before the last reload.');});
  $('save-profile').addEventListener('click',async()=>{if(!state.current||state.busy||unfinished())return;busy(true,'Saving reusable automation profile…');try{await api('/api/automation',{image_id:state.current.id,automation:clone(state.automation),expected_revision:automationProfile.revision,enabled:$('profile-enabled').checked});await refreshProfile();toast('Automation profile saved. New images use it when reuse is enabled.');}catch(exc){error(exc);}finally{busy(false);}});
  $('load-profile').addEventListener('click',async()=>{if(!state.current||state.busy||unfinished())return;busy(true,'Loading automation profile…');try{const result=await api('/api/automation/load',{image_id:state.current.id});historyPush();state.automation={...clone(AUTOMATION_DEFAULTS),...clone(result.automation)};dirty();syncAutomation();drawGuide();toast('Profile loaded. Click Reload proposals to apply this method.');}catch(exc){error(exc);}finally{busy(false);}});

  document.querySelectorAll('[data-tool]').forEach(x => x.addEventListener('click', () => setTool(x.dataset.tool)));
  for (const id of ['class-inner', 'class-outer']) $(id).addEventListener('click', () => toast('Classes are automatic: annotated pixels inside the yellow boundary are inner; annotated pixels outside are outer.'));
  $('brush-size').addEventListener('input', () => { $('brush-value').textContent = `${$('brush-size').value} px`; drawGuide(); });
  $('opacity').addEventListener('input', () => { $('opacity-value').textContent = `${$('opacity').value}%`; drawMask(); });
  $('show-mask').addEventListener('change', () => { drawMask(); drawGuide(); }); $('show-roi').addEventListener('change', drawGuide); $('show-zones').addEventListener('change', drawGuide); $('show-scope').addEventListener('change', drawGuide);
  $('undo').addEventListener('click', () => historyMove(state.undo, state.redo)); $('redo').addEventListener('click', () => historyMove(state.redo, state.undo));
  $('fit').addEventListener('click', fit); $('actual-size').addEventListener('click', () => zoom(1)); $('zoom-in').addEventListener('click', () => zoom(state.zoom * 1.25)); $('zoom-out').addEventListener('click', () => zoom(state.zoom / 1.25));
  $('previous').addEventListener('click', () => navigate(-1)); $('next').addEventListener('click', () => navigate(1));
  $('save-draft').addEventListener('click', () => save(false)); $('approve').addEventListener('click', () => save(true)); $('approve-clean').addEventListener('click', () => save(true, true)); $('regenerate').addEventListener('click', regenerate); $('detect-roi').addEventListener('click', detectROI);
  $('reject-next').addEventListener('click', () => changeInclusion(true)); $('restore-image').addEventListener('click', () => changeInclusion(false));
  $('clear-mask').addEventListener('click', () => { if (state.current && !state.busy && !state.drag && confirm('Clear every annotation object in this image? This can be undone before saving.')) { historyPush(); state.erase = M.union(state.erase,...state.objects.filter(object=>object.kind==='proposal').map(object=>object.mask)); state.objects = []; state.selected = null; state.polygon = []; dirty(); drawMask(); drawGuide(); renderObjects(); } });
  $('search').addEventListener('input', renderQueue); $('unapproved-only').addEventListener('change', renderQueue); $('hide-rejected').addEventListener('change', renderQueue);
  for (const id of ['notes', 'sensitivity', 'min-area', 'polarity']) {
    $(id).addEventListener('focus',()=>{if(state.current)fieldCheckpoint=capture();});
    $(id).addEventListener('input', () => {
      if(!state.current||state.busy)return;
      const before=capture();if(fieldCheckpoint){before.notes=fieldCheckpoint.notes;before.settings=clone(fieldCheckpoint.settings);}
      state.reloadUndo=null;state.undo.push(before);state.redo=[];trimHistory();fieldCheckpoint=capture();dirty();
    });
  }
  $('help-button').addEventListener('click', () => $('help-dialog').showModal()); $('close-help').addEventListener('click', () => $('help-dialog').close());
  window.addEventListener('beforeunload', event => { if (pending()) { event.preventDefault(); event.returnValue = ''; } });
  window.addEventListener('blur', () => { state.space = false; });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && !$('help-dialog').open && (state.polygon.length || state.drag)) { const pointerId = state.drag?.pointerId; cancelGesture(pointerId == null ? null : {pointerId}); event.preventDefault(); return; }
    const key = event.key.toLowerCase();
    if ((event.ctrlKey || event.metaKey) && key === 's') { event.preventDefault(); if (!state.busy && !$('help-dialog').open) save(false); return; }
    if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName) || $('help-dialog').open) return;
    if ((event.ctrlKey || event.metaKey) && ['z', 'y'].includes(key)) {
      event.preventDefault(); if (state.busy) return;
      if (key === 'y' || event.shiftKey) historyMove(state.redo, state.undo); else historyMove(state.undo, state.redo); return;
    }
    if (state.busy || event.ctrlKey || event.metaKey || event.altKey) return;
    const shortcuts = {b: 'brush', c: 'circle', e: 'ellipse', p: 'polygon', r: 'rectangle', x: 'eraser', l: 'roi', o: 'octagon', h: 'pan'};
    if (shortcuts[key]) setTool(shortcuts[key]);
    else if (key === ' ') { state.space = true; event.preventDefault(); }
    else if (key === 'enter' && state.polygon.length) { finishPolygon(); event.preventDefault(); }
    else if ((key === 'delete' || key === 'backspace') && state.selected) { deleteObject(state.selected); event.preventDefault(); }
    else if (key === '0') fit();
    else if (key === '+' || key === '=') zoom(state.zoom * 1.25);
    else if (key === '-') zoom(state.zoom / 1.25);
    else if (key === 'm') { $('show-mask').checked = !$('show-mask').checked; drawMask(); drawGuide(); }
    else if (key === 'pageup') { navigate(-1); event.preventDefault(); }
    else if (key === 'pagedown') { navigate(1); event.preventDefault(); }
    else if (key === '?') $('help-dialog').showModal();
  });
  document.addEventListener('keyup', event => { if (event.key === ' ') state.space = false; });
  new ResizeObserver(() => { if (state.current && !state.drag) drawGuide(); }).observe(viewport);

  let polygonTemplate = {revision: 0, enabled: false};
  async function refreshTemplate() {
    polygonTemplate = await api('/api/template');
    $('template-info').textContent = polygonTemplate.revision ? `Saved polygon revision ${polygonTemplate.revision} · ${polygonTemplate.enabled ? 'automatic reuse enabled' : 'automatic reuse disabled'}` : 'No custom polygon saved.';
    if (polygonTemplate.revision) { $('template-mode').value = polygonTemplate.mode; $('template-enabled').checked = polygonTemplate.enabled; }
  }
  $('save-template').addEventListener('click', async () => {
    if (!state.current || state.busy) return;
    if (state.polygon.length) { toast('Press Enter to finish your polygon first.', true); return; }
    try {
      await api('/api/template', {image_id: state.current.id, roi: state.current.roi, expected_revision: polygonTemplate.revision, mode: $('template-mode').value, enabled: $('template-enabled').checked});
      await refreshTemplate(); toast('Custom polygon saved in the project. It persists after restart.');
    } catch (e) { error(e); }
  });
  $('load-template').addEventListener('click', async () => {
    if (!state.current || state.busy) return;
    try { const r = await api('/api/template/roi', {image_id:state.current.id}); historyPush(); setROI(r.roi); drawMask(); drawGuide(); renderObjects(); toast('Saved polygon applied. Review and save this image.'); } catch (e) { error(e); }
  });
  $('apply-template').addEventListener('click', async () => {
    if (state.busy) return;
    if (pending()) { toast('Save or finish current edits before applying the polygon to the dataset.', true); return; }
    const all = $('template-approved').checked;
    if (!confirm(all ? 'Apply the polygon to existing images, including approved images? Changed masks become drafts and require approval again.' : 'Apply the polygon to existing drafts? Defect footprints and approved images are preserved.')) return;
    try { const r = await api('/api/template/apply', {include_approved:all}); state.items = (await api('/api/project')).items; renderQueue(); if(state.current) await openImage(state.current.id, true); toast(`${r.changed} boundaries updated. New images also use the saved polygon.`); } catch(e) { error(e); }
  });
  window.addEventListener('message', e => { if(e.origin === location.origin && e.data === 'refresh-project' && !pending()) start(); });

  async function start() {
    try {
      await refreshTemplate(); await refreshProfile();
      const project = await api('/api/project'); state.items = project.items; renderQueue(); updateButtons();
      if (state.items.length) await openImage((state.items.find(x => !['approved', 'rejected'].includes(x.status)) || state.items[0]).id);
      else { $('empty-state').querySelector('h2').textContent = 'No images have been imported'; $('empty-state').querySelector('p').textContent = 'Set input_dir in your configuration, then run the import command.'; }
    } catch (exc) { error(exc); $('empty-state').querySelector('h2').textContent = 'Workspace could not be loaded'; $('empty-state').querySelector('p').textContent = exc.message; }
  }
  window.TopsegEditor = {hasPending: () => !!pending()};
  start();
})();
