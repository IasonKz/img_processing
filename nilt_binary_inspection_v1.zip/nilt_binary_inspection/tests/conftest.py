from pathlib import Path
import copy

import numpy as np
from PIL import Image
import pytest
import torch

from binary_inspection.common import load_config


@pytest.fixture
def config(tmp_path):
    torch.set_num_threads(2)
    cfg = copy.deepcopy(load_config(Path(__file__).parents[1] / "configs" / "base.yaml"))
    cfg["paths"].update(dataset_root=str(tmp_path / "dataset"), output_dir=str(tmp_path / "run"),
                        pretrained_dir=str(tmp_path / "weights"), metadata_csv=None, warm_start_run=None)
    cfg["runtime"].update(device="cpu", cpu_threads=2, num_workers=0, amp=False)
    cfg["audit"]["near_duplicates"]["enabled"] = False
    cfg["split"].update(min_per_class_per_split=1, attempts=100)
    cfg["models"] = {"small_test": {"enabled": True, "architecture": "resnet18", "input_size": 64, "strategy": "frozen"}}
    cfg["training"].update(epochs=2, batch_size=8, head_epochs=1, gradient_accumulation=2,
                           allow_random_initialization=True, log_every_batches=50)
    cfg["anomaly"].update(enabled=False, backbone="resnet18", input_size=64, batch_size=4,
                          max_train_images=20, patches_per_image=8, pool_size=100, memory_size=12,
                          projection_dim=8, num_neighbors=3, query_chunk=32)
    cfg["selector"].update(use_anomaly_veto=False, min_selection_good_pass_rate=0.0, reject_weak_candidates=False)
    return cfg


def make_dataset(root: Path, per_class=40, seed=1):
    rng = np.random.default_rng(seed)
    for class_name, mean in (("good", 150), ("bad", 75)):
        folder = root / class_name
        folder.mkdir(parents=True, exist_ok=True)
        for i in range(per_class):
            arr = np.clip(rng.normal(mean, 35, (64, 64, 3)), 0, 255).astype(np.uint8)
            if class_name == "bad":
                arr[20:40, 20:40] = 230
            Image.fromarray(arr).save(folder / f"unit_{i:04d}_{class_name}.png")
