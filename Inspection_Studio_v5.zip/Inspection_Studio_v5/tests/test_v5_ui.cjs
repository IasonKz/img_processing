/* GUI contracts on the same DOM harness as v4; no simulated model performance. */
"use strict";
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=require('./test_v4_ui.cjs');
const {context,el,click,emit,settle,calls}=h;
const contract={search:{sampler:'tpe',objective:'validation_ap',seed:42,max_trials_per_model:8,startup_trials:3,
 trial_timeout_seconds:0,minimum_trial_seconds:60,max_failed_trials_per_model:3,study_patience_trials:0,
 minimum_improvement:0,shortlist_per_model:1,selection_reserve_fraction:.15,confirmation_reserve_fraction:.2,
 pruner:'median',pruner_startup_trials:3,pruner_warmup_steps:0,pruner_interval_steps:1,pruner_reduction_factor:3,
 min_finetune_epochs:2,total_budget_seconds:21600,enqueue_presets:true,model_spaces:{},
 space:{learning_rate:{kind:'range',low:1e-6,high:1e-4,log:true},mode:{kind:'choices',values:['head_only','full']},
 effective_batch_size:{kind:'choices',values:[8,16]}}},
 training:{epochs:30,patience:7,batch_size:2,eval_batch_size:2,amp:true},seeds:[42,123],
 image_strategy:'full_image',patches:{size:256,overlap:64,max_patches:64,chunk_size:4,aggregation:'max',topk:3,global_weight:.5},
 augmentation:{rotation90:true}};
const systems=[];
context.fetch=async(url,options={})=>{
 const route=new URL(url,'http://localhost').pathname,body=options.body?JSON.parse(options.body):null;
 if(!route.startsWith('/api/v5/'))return h.fetchMock(url,options);
 calls.push({path:route,body,options});let data;
 if(route==='/api/v5/defaults')data=contract;
 else if(route==='/api/v5/systems')data=systems;
 else if(route==='/api/v5/validate-search')data={valid:true};
 else if(route==='/api/v5/system-preview')data={definition:body.definition,tune_metrics:{n:4,review_rate:.25,coverage:.75},warnings:['Fixture: contract validation only']};
 else if(route==='/api/v5/system-save'){const record={path:'C:/decision_systems/frozen/decision_system.json',name:body.definition.name,definition:body.definition,tune_metrics:{n:4,review_rate:.25}};systems.push(record);data={path:record.path,system:record};}
 else if(route==='/api/v5/review-export')data={dataset_root:'C:/review_datasets/new/data',config_path:'C:/review_datasets/new/update_config.json',ready_for_update:true,counts:{new_train:2},notes:[]};
 else throw Error('Unexpected route '+route);
 return {ok:true,json:async()=>JSON.parse(JSON.stringify(data))};
};
(async()=>{
 await settle();
 vm.runInContext(fs.readFileSync(path.join(__dirname,'../nilt/ui/v5.js'),'utf8'),context,{filename:'v5.js'});
 await settle();
 const v5=vm.runInContext('InspectionV5',context);
 assert.equal(el('cs-objective').value,'validation_ap');
 el('search-preset').value='custom';await emit(el('search-preset'),'change');
 assert.equal(el('custom-search-panel').hidden,false);assert.equal(el('hours').disabled,true);
 el('cs-total-budget').value='1937';el('cs-objective').value='validation_roc_auc';
 el('cs-seeds').value='42, 123';el('cs-timeout').value='271';
 const chosen=v5.customPayload();assert.equal(chosen.search.total_budget_seconds,1937);
 assert.equal(chosen.search.trial_timeout_seconds,271);assert.equal(chosen.search.objective,'validation_roc_auc');
 assert.equal(chosen.search.space.learning_rate.log,true);
 await click('custom-preview');assert.equal(calls.at(-1).path,'/api/v5/validate-search');
 el('cs-image-strategy').value='global_patches';await emit(el('cs-image-strategy'),'change');
 assert.equal(el('patch-controls').hidden,false);assert.equal(v5.customPayload().patches.overlap,64);
 el('space-learning_rate-low').value='0';assert.throws(()=>v5.customPayload(),/positive/);el('space-learning_rate-low').value='0.000001';
 el('cs-model-spaces').value='{bad json';assert.throws(()=>v5.customPayload(),/invalid JSON/);el('cs-model-spaces').value='{}';
 const definition={name:'Ensemble test',kind:'weighted',sources:[{run:'C:/results/run1',candidate:'a'},{run:'C:/results/run1',candidate:'b'}],weights:[1,2],thresholds:{good:.2,bad:.8},calibrate_scores:true,
 tuning:{method:'optuna',n_trials:12,timeout_seconds:5,search_weights:true,good_range:[.1,.3],bad_range:[.7,.9],bad_cost:20,reject_cost:2,review_cost:.5}};
 v5.applySystem(definition);await settle();
 let payload=v5.systemDefinition();assert.equal(payload.sources.length,2);assert.equal(payload.weights[1],2);assert.equal(payload.tuning.bad_cost,20);assert.equal(payload.tuning.good_range[0],.1);
 await click('system-preview');assert.ok(el('system-evidence').textContent.includes('Ensemble test'));
 await click('system-save');assert.equal(el('system-saved').value,systems[0].path);
 assert.equal(el('system-evaluate').disabled,true);el('system-test-ack').checked=true;await emit(el('system-test-ack'),'change');
 await click('system-evaluate');let action=calls.filter(c=>c.path==='/api/action').at(-1).body;
 assert.equal(action.action,'system-evaluate');assert.equal(action.confirm_final_test,true);assert.equal(el('system-test-ack').checked,false);
 v5.applySystem({...definition,kind:'cascade',tuning:{method:'manual'},stages:[{source:0,name:'Screen',good:.02,bad:.98,accept:false,reject:true},{source:1,name:'Resolve',good:.3,bad:.7,accept:true,reject:true}]});
 payload=v5.systemDefinition();assert.equal(payload.stages[0].accept,false);assert.equal(payload.stages[1].good,.3);
 el('classify-source').value='system';el('classify-system').value=systems[0].path;el('predict-input').value='C:/incoming';
 await v5.classifySystem();action=calls.filter(c=>c.path==='/api/action').at(-1).body;assert.equal(action.action,'system-classify');
 el('review-session').value=h.sessions[0].path;el('review-export-output').value='C:/review_datasets';
 await click('review-export');assert.equal(el('review-finetune').disabled,false);await click('review-finetune');
 action=calls.filter(c=>c.path==='/api/action').at(-1).body;assert.equal(action.action,'review-finetune');
 assert.ok(calls.filter(c=>c.path.startsWith('/api/v5/')&&c.body).every(c=>c.options.headers['X-Inspection-Token']==='test-token'));
 console.log('PASS: Custom search fields/ranges/seconds/objective, patch controls, decision thresholds/weights/cascade, final-test acknowledgement, system inference, reviewed-data export/fine-tune and authenticated actions.');
})().catch(error=>{console.error(error);process.exitCode=1;});
