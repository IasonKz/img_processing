import os
os.environ['HF_HUB_OFFLINE']='1'
os.environ['HF_HUB_DISABLE_TELEMETRY']='1'
os.environ['TRANSFORMERS_OFFLINE']='1'
import sys
import traceback
from pathlib import Path
from .common import read_json, atomic_json


def main(folder):
    folder=Path(folder); request=read_json(folder/'request.json')
    cfg,payload,action=request['cfg'],request['payload'],request['action']
    atomic_json(folder/'status.json',{'status':'running','action':action})
    try:
        if action=='search':
            from .search import run_search
            result=run_search(cfg,payload,folder)
        elif action=='preflight':
            from .search import preflight
            result=preflight(payload,folder)
        elif action=='import':
            from .project import Project
            result={'status':'completed',**Project(cfg).import_images()}
        elif action=='report':
            from .reports import export_report
            result=export_report(cfg,payload,folder)
        else:
            from .operations import evaluate_trial,predict_folder,export_model,export_dataset
            result={'evaluate':evaluate_trial,'predict':predict_folder,'export':export_model,'dataset':export_dataset}[action](cfg,payload,folder)
        atomic_json(folder/'result.json',result)
        atomic_json(folder/'status.json',{'status':result.get('status','completed'),'action':action,'result':result})
    except InterruptedError as exc:
        atomic_json(folder/'status.json',{'status':'stopped','error':str(exc)})
    except BaseException as exc:
        traceback.print_exc()
        atomic_json(folder/'status.json',{'status':'failed','error':f'{type(exc).__name__}: {exc}'})
        return 1
    return 0


if __name__=='__main__':raise SystemExit(main(sys.argv[1]))
