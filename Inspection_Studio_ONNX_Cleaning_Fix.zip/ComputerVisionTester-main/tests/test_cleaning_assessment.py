"""Synthetic cleaning decisions test routing, persistence and file safety."""
import json
from pathlib import Path
import tempfile
from unittest.mock import patch

import numpy as np
from PIL import Image

from nilt.common import read_json, write_json, sha_file
from nilt.cleaning_assessment import assess, disagreement, load_source
from nilt.decisions import create_decision
from nilt.inspection_flow import create_workflow
from nilt.dashboard import Dashboard
from test_integration_v2 import fixture_run


def fixture(root):
    run, data, _ = fixture_run(root, threshold=5)
    decision = create_decision(run, output_root=root / "decisions", mode="manual", threshold=5)
    cfg = root / "project.yaml"
    cfg.write_text("paths:\n  output_root: results\ntasks:\n  top:\n    dataset_root: old_data\n")
    return Dashboard(cfg), data, decision


def score(run, members, rows, cfg, **options):
    return np.array([8 if "bad/" in row["relative_path"] else 2 for row in rows]), .01


def settings(root, decision, kind="decision"):
    return {"root": str(root), "source": str(decision), "source_sha256": sha_file(decision),
            "name": "Cleaning model", "kind": kind, "task": "top", "roi_scope": "whole_image", "device": "cpu"}


def test_saved_assessment_stays_with_relabel_and_undo_and_rejects_changed_pixels():
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory); app, data, decision = fixture(root)
        output = root / "cleaning_assessments" / "saved1";output.mkdir(parents=True)
        hashes = {row.relative_to(data).as_posix(): sha_file(row) for row in data.rglob("*.png")}
        with patch("nilt.workflow.predict_members", side_effect=score):
            report = assess(settings(data, decision), output)
        assert report["completed"] == 20
        assert hashes == {row.relative_to(data).as_posix(): sha_file(row) for row in data.rglob("*.png")}
        opened = app.cleaning_open({"path": str(data)})
        query = {"dataset": opened["dataset"], "task": "top", "assessment": "saved1"}
        assert app.cleaning_catalog(query)["comparison_counts"]["match"] == 20
        relative = "good/train_0.png"
        moved = app.cleaning_move({**query, "relative": relative, "label": "bad", "expected_sha256": hashes[relative]})
        fn = app.cleaning_catalog({**query, "comparison": "fn"})
        assert fn["pagination"]["total"] == 1
        assert fn["items"][0]["relative_path"] == moved["move"]["to"]
        assert fn["items"][0]["model"]["prediction"] == "good"
        app.cleaning_undo(query)
        assert app.cleaning_catalog({**query, "comparison": "fn"})["pagination"]["total"] == 0
        Image.new("RGB", (32,32), (5,2,1)).save(data / relative)
        item = app.cleaning_item({**query, "relative": relative})
        assert item["model"]["status"] == "stale"
        assert app.cleaning_catalog({**query, "comparison": "unscored"})["pagination"]["total"] == 1
        assert not app.cleaning_catalog({"dataset": opened["dataset"]})["assessment"]


def test_workflow_uses_frozen_votes_and_keeps_individual_scores():
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory); _, data, decision = fixture(root)
        second = create_decision(root / "old", output_root=root / "decisions", mode="manual", threshold=6)
        workflow = create_workflow({"name":"Cleaning workflow","rule":"any_bad","stages":[{"decision":str(decision)},{"decision":str(second)}]}, root / "workflows")
        output = root / "assessment";output.mkdir()
        with patch("nilt.workflow.predict_members", side_effect=score) as scorer:
            report = assess(settings(data, workflow, "workflow"), output)
        assert report["status"] == "completed"
        assert scorer.call_count == 2
        records = read_json(output / "predictions.json")
        bad = next(r for r in records if r["initial_label"] == "bad")
        assert bad["prediction"] == "bad" and bad["bad_score"] is None
        assert bad["stage_results"][0]["score"] == 8
        assert bad["stage_results"][1]["status"] == "skipped"


def test_assessment_rejects_scope_mismatch_changed_decision_and_stop():
    with tempfile.TemporaryDirectory() as directory:
        root=Path(directory); _, data, decision=fixture(root)
        import pytest
        with pytest.raises(ValueError, match="match"):
            load_source("decision", decision, "bottom", "pins")
        output=root/"assessment";output.mkdir()
        cfg=settings(data, decision);cfg["source_sha256"]="0"*64
        with pytest.raises(ValueError, match="changed"):
            assess(cfg, output)
        with pytest.raises(InterruptedError):
            assess(settings(data, decision), output, stop_check=lambda:True)
        assert len(list(data.rglob("*.png"))) == 20


def test_comparison_semantics():
    assert disagreement("bad", {"status":"ok", "prediction":"good"}) == "fn"
    assert disagreement("good", {"status":"ok", "prediction":"bad"}) == "fp"
    assert disagreement("good", {"status":"ok", "prediction":"review"}) == "mismatch"
    for label in ("review", "unsuitable"):
        assert not disagreement(label, {"status":"ok", "prediction":"good"})
    assert not disagreement("bad", {"status":"input_error", "prediction":"review"})


def test_cleaning_native_viewer_and_local_asset_guard():
    with tempfile.TemporaryDirectory() as directory:
        root=Path(directory);app,data,_=fixture(root)
        import cv2
        from io import BytesIO
        pixels=np.repeat(np.arange(1001,1201,dtype=np.uint16)[None,:],20,axis=0)
        cv2.imwrite(str(data/"good/native.png"),pixels)
        digest=sha_file(data/"good/native.png")
        query={"dataset":app.cleaning_open({"path":str(data)})["dataset"],"relative":"good/native.png"}
        assert app.cleaning_image_info(query)["min"] == 1001
        preview=Image.open(BytesIO(app.cleaning_image({**query,"window":"1","black":"min","white":"max"})))
        assert np.asarray(preview)[0,0,0] == 0 and np.asarray(preview)[0,-1,0] == 255
        assert sha_file(data/"good/native.png") == digest
        index=app.data_roots.index(data)
        assert app.viewer_image({"source":f"/images/{index}/good/native.png"},info=True)["bit_depth"] == 16
        import pytest
        with pytest.raises(ValueError):app.viewer_image({"source":"https://example.com/a.png"})
        with pytest.raises(ValueError):app.viewer_image({"source":f"/images/{index}/../project.yaml"})


def test_real_cpu_assessment_through_workspace_worker():
    import pytest
    torch=pytest.importorskip("torch");pytest.importorskip("torchvision")
    from nilt.engine import make_model, save_checkpoint
    from nilt.workspace_worker import run as worker_run
    with tempfile.TemporaryDirectory() as directory:
        root=Path(directory);run,data,_=fixture_run(root,threshold=.5)
        cfg=read_json(run/"config.json");cfg.update(cpu_threads=1,num_workers=0)
        write_json(run/"config.json",cfg)
        write_json(run/"integrity.json",{"config_sha256":sha_file(run/"config.json"),"manifest_sha256":sha_file(run/"manifest.csv")})
        torch.manual_seed(19);torch.set_num_threads(1)
        model,_=make_model("resnet18",cfg);save_checkpoint(run/"real.pt",model.eval(),cfg,"resnet18",19,0)
        candidate=read_json(run/"selected.json")
        candidate.update(name="resnet18_fixture",score_type="bad_probability_uncalibrated",threshold=.5,
                         members=[{"checkpoint":"real.pt","sha256":sha_file(run/"real.pt"),"architecture":"resnet18","kind":"supervised"}])
        write_json(run/"selected.json",candidate);write_json(run/"selection_integrity.json",{"sha256":sha_file(run/"selected.json")})
        write_json(run/"candidates.json",[candidate])
        decision=create_decision(run,mode="manual",threshold=.5,output_root=root/"decisions")
        before={str(p):sha_file(p) for p in data.rglob("*.png")}
        output=root/"assessment";request=root/"request.json"
        write_json(request,{"action":"cleaning-assess","settings":settings(data,decision),"output":str(output),"stop_file":str(root/"STOP")})
        assert worker_run(request)==0
        records=read_json(output/"predictions.json")
        assert len(records)==20 and all(np.isfinite(r["bad_score"]) for r in records)
        assert before=={str(p):sha_file(p) for p in data.rglob("*.png")}
