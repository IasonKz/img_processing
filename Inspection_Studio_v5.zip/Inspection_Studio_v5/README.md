# Inspection Studio 5

Local visual inspection software for training, comparing, and reviewing image classifiers. Version 5 adds editable Optuna search contracts, additional pretrained backbones, optional global-plus-patch learning, triage decisions, learned model combinations, and controlled review-dataset export.

**Start on Windows:** read [START_HERE.md](START_HERE.md), run `Setup.cmd` once, then open `Start.cmd`. **Start on Linux:** follow [INSTALLATION_LINUX.md](docs/INSTALLATION_LINUX.md), then run `bash Start.sh`. The interface and operating guides are in English.

## Operating workspace

| View | Purpose |
| --- | --- |
| Dataset & setup | Configure folders, check dependencies and weights, audit source data |
| Train & search | Use profile defaults or Custom Optuna controls; monitor learning curves, trial outcomes, timing, and failures |
| Compare models | Compare completed candidates on the recorded selection split |
| Decision explorer | Inspect calibration trade-offs; save policy, manual, argmax, or scores-only decisions |
| Decision lab | Fit and freeze Good / Review / Bad systems, weighted scores, held-out stacking, or cascades |
| Classify images | Load a saved decision and classify a local image folder |
| Inspection workflow | Run legacy ordered any-bad, all-bad, or majority rules from saved decisions |
| Image review | Inspect copied predictions and original tags; record human corrections and export controlled dataset revisions |
| Models & reports | Load experiments and assets; inspect reports and manage portable packages |

## Resource presets and custom execution

| Preset | Suggested device | Initial search budget | Default model families |
| --- | --- | ---: | --- |
| `laptop` | CPU | 2 hours | ResNet18, EfficientNet-B0 |
| `workstation` | NVIDIA CUDA GPU | 6 hours | EfficientNet-B0, ConvNeXt-Tiny |
| `workstation_large` | NVIDIA CUDA GPU | 12 hours | EfficientNet-B0, ConvNeXt-Tiny, EfficientNetV2-S |

Profiles supply starting values, not maximum limits. In Custom Optuna, choose CPU, CUDA, or Auto independently of the preset and set any positive finite total budget. A 24-hour GPU search is valid even when based on the laptop preset. The shared budget includes preparation and evaluation; more architectures leave less time per architecture. Resume retains the original contract and uses its remaining cumulative budget. Hardware, native image dimensions, and candidate complexity determine how many trials can complete.

Additional selectable pretrained classifiers are EfficientNet-B2, EfficientNetV2-S, MobileNetV3-Large, and DenseNet121. They are not all automatically added to the profile shortlist. Public weights must be provisioned before selecting a new architecture. Non-pretrained image-model training is not an operator mode in this release.

## New in version 5

- **Custom Optuna:** fixed values, categorical choices, numerical bounds, per-model overrides, validation objectives, TPE/Random/finite Grid sampling, pruning controls, explicit trial limits, independently selected CPU/CUDA/Auto execution, and user-defined cumulative budgets.
- **Search and comparison graphics:** objective histories, overlaid learning curves, trial duration/performance, parameter relationships, parallel coordinates, model metric comparisons, and confusion-matrix grids. Every view identifies the evidence role.
- **Full image or global plus patches:** a shared pretrained classifier processes the complete native-resolution padded image and overlapping local patches. Only image-level labels are used; no false patch labels are generated.
- **Decision systems:** single-model triage, compatible score-weighted ensembles, regularized stacking fitted on held-out calibration data, and confidence-routing cascades. Threshold/weight exploration does not read final-test labels.
- **Review loop:** human-confirmed labels, prediction/reference separation, content and group checks, and a copied dataset revision with old training replay and protected holdouts for fine-tuning.

See [V5_DESIGN_AND_LIMITS.md](docs/V5_DESIGN_AND_LIMITS.md) for the exact boundaries. Stacking is held-out fitting, not automatic out-of-fold retraining. The application does not claim to calibrate every output into a probability or certify a production error rate.

## Data and decision controls

- The VIG task is enabled initially; top and bottom are configured separately.
- Native source pixels are preserved with padding. There is no silent crop or downsampling fallback.
- VIG training augmentation uses only exact quarter-turn rotations; image labels are unchanged.
- Captures of the same tray/row/column unit stay together in the split.
- Training, validation, calibration, selection, and final test have separate roles.
- Saved decisions and workflow recipes are separate from trained checkpoints.
- Classification copies and review tags never overwrite the original dataset.
- Failed trials are reported with their errors. Pruned trials and timeouts have distinct states.
- Windows file publishing uses unique temporary files and bounded retries for transient access/sharing failures.

Training and inference run locally after public packages and model weights have been provisioned. The dashboard binds to loopback and has no external CDN requirement.

## Guides

- [Windows installation and repair](docs/INSTALLATION.md)
- [Arch/Linux installation and restart](docs/INSTALLATION_LINUX.md)
- [Migration from v3/v4](MIGRATION_V5.md)
- [Version 5 design and limitations](docs/V5_DESIGN_AND_LIMITS.md)
- [Custom Optuna controls](docs/CUSTOM_OPTUNA.md)
- [Search analytics and comparison charts](docs/SEARCH_AND_COMPARISON_CHARTS.md)
- [Decision Lab: triage, stacking, and cascades](docs/DECISION_LAB.md)
- [Daily operator workflow](docs/OPERATOR_GUIDE.md)
- [Model training and evaluation](docs/EXPERIMENT_GUIDE.md)
- [Ordered inspection workflows](docs/WORKFLOWS.md)
- [Image review and operator tags](docs/IMAGE_REVIEW.md)
- [Command reference](docs/CLI_REFERENCE.md)
- [Troubleshooting](docs/TROUBLESHOOTING.md)
- [Portable deployment](docs/DEPLOYMENT.md)
- [Validation scope](docs/VALIDATION_REPORT.md)
- [Release verification record](docs/RELEASE_VERIFICATION.md)

## Release boundary

This application provides inspection development and local batch operation. It is not a certified production-line controller. Release suitability requires independent representative data, agreed error limits, destination-machine verification, and an operational response for invalid images and equipment failures. A selected model, a saved workflow, or an exported package does not itself establish production qualification.

Use a new project folder and results root for this version. Keep earlier experiments read-only; do not resume an old training worker with new code. Preserve the original release for reproducing old training. Do not overlay old patch files onto this release.
