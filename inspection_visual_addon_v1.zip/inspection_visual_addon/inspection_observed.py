"""Run the existing training CLI with opt-in telemetry and automatic HTML output."""
from datetime import datetime
from pathlib import Path
import sys


def main():
    args = list(sys.argv[1:])
    if not args or args[0] in ("-h", "--help"):
        print("Usage: python inspection_observed.py {run|resume|update} <original inspection.py arguments> [--telemetry-every 25]\n"
              "Example: python inspection_observed.py run --config project.visual.yaml --profile laptop --task vig\n"
              "Use visual_report.py for existing runs. No original source files are modified.")
        return 0
    if args[0] not in ("run", "resume", "update"):
        print("Use inspection.py for other commands. This wrapper supports run, resume and update.", file=sys.stderr)
        return 2
    interval = 25
    if "--telemetry-every" in args:
        i = args.index("--telemetry-every")
        try:
            interval = int(args[i+1])
            if interval < 1:
                raise ValueError()
        except (IndexError, ValueError):
            print("--telemetry-every requires a positive integer.", file=sys.stderr)
            return 2
        del args[i:i+2]
    if not Path(__file__).with_name("inspection.py").is_file():
        print("Copy the add-on into the project root beside inspection.py.", file=sys.stderr)
        return 2
    import inspection
    from inspection_visual.telemetry import observe_training
    from inspection_visual.report import build_report
    result = 3
    with observe_training(interval) as runs:
        try:
            result = inspection.main(args)
        finally:
            if runs:
                try:
                    build_report(sorted(runs), Path(sorted(runs)[0]) / "visual_reports" /
                                 ("inspection_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f") + ".html"))
                except Exception as exc:
                    print(f"Report generation failed; training records are retained: {exc}", file=sys.stderr)
    return result


if __name__ == "__main__":
    raise SystemExit(main())
