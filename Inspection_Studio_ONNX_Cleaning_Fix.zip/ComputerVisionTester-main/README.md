# Inspection Studio 6.1

Local image-classification training, optimization, comparison, decision design, and operator review for NIL Technology. This release extends version 5 with additional Optuna samplers, native 16-bit input, optional Intel graphics execution, comparison radars, and explicit review routing.

The dashboard is organized into **Classification**, **Segmentation** and **ROI Detection**. Classification supports VIG/TOP/BOTTOM and isolated ROI classifiers; Segmentation supports whole-image TOP defects, TOP/BOTTOM ROI crop defects, and ROI localizer training. ROI Detection prepares geometry/crops and shares the crop annotation projects with Segmentation. Deployment includes per-unit **Quality review** with TOP/BOTTOM/VIG evidence, comparable distributions and optional reports. Reversible cleaning, tray roles, threshold tuning, VIG deployment, theme and native folder pickers remain available. See the [shared ROI segmentation guide](docs/ROI_SEGMENTATION.md), [ROI workflow](docs/ROI_WORKFLOW.md), [ROI architecture](docs/ROI_ARCHITECTURE.md), [verification and limitations](docs/ROI_VERIFICATION.md) and [workspace guide](docs/WORKSPACE_STUDIO.md).

**Windows:** run `Setup.cmd` once for CPU or NVIDIA CUDA, then `Start.cmd`. For experimental Windows Intel/AMD graphics execution, use `Setup-DirectML.cmd` in a separate environment. Begin with [START_HERE.md](START_HERE.md). Interface text and project documentation are maintained in English.

For the shared image viewer, staged Data Cleaning shortcuts, optional model/workflow comparisons and antialiased ONNX export, see [Data Cleaning and ONNX update](docs/DATA_CLEANING_AND_ONNX_FIX.md) and its [verification results](docs/DATA_CLEANING_ONNX_VERIFICATION.md).

Read [WHATS_NEW_6_1.md](WHATS_NEW_6_1.md) for Intel iGPU training, shared download controls and tray-quality documentation.

## Operating workspace

| View | Purpose |
| --- | --- |
| Preprocessing / Data processing | Prepare labelled CSVs for training or untagged tester folders into TOP/BOTTOM/VIG copies for classification; inspect counts and processing reports |
| Dataset & setup | Configure folders; audit dimensions, intensity depth, labels, duplicates, groups, and splits |
| Train & search | Define model families, sampler, search ranges, pruning, budgets, and execution device; monitor progress and errors |
| Compare models | Compare completed candidates using common data roles, metrics, curves, confusion matrices, and radars |
| Decision explorer | Inspect thresholds and choose a binary or two-threshold review decision |
| Decision lab | Fit and freeze weighted ensembles, held-out stacking, cascades, and optional disagreement guards |
| Classify images | Apply a saved decision to local inputs and retain image copies |
| Inspection workflow | Arrange saved decisions and choose final voting or consensus rules |
| Image review | Compare predictions with reference tags; record explicit human judgments |
| Quality & documentation | Document training membership and compare historical trays, model routing and manual references; export HTML/CSV/JSON |
| Models & reports | Load experiments, inspect artifacts, and create supported deployment packages |

## Changes in version 6

- **Search strategies:** TPE, Random, Grid, Gaussian Process, CMA-ES, NSGA-II, NSGA-III, QMC, and Brute Force. Fixed parameter specifications provide partial-fixed behavior. Options and compatibility checks are exposed. This release retains one selected validation objective; choosing NSGA does not create a multiobjective experiment automatically. See [SAMPLERS_V6.md](docs/SAMPLERS_V6.md).
- **Comparison radars:** compare final optimization settings and model metrics with disclosed scaling. Normalized parameter positions describe shared observed ranges among completed trials; a larger polygon is not a quality score. Categorical values remain explicit rather than being assigned a fictitious numeric order.
- **Two-threshold review:** automatically accept below a lower bad-score threshold, reject at or above an upper threshold, and route the intermediate band to human review. The original single-threshold mode remains available.
- **Ensemble uncertainty:** optionally route disagreeing models or high score dispersion to review. This is a diagnostic heuristic, not a calibrated probability that the decision is wrong. All guarded sources are evaluated; guarded cascades trade early-exit speed for agreement evidence.
- **Cancellation:** cooperative cancellation preserves available unfinished model state. Partial model predictions are diagnostic and require human review; they are not completed optimization results or automatically releasable decisions.
- **Intel graphics:** optional `torch-directml` execution on supported Windows hardware uses a separate dependency environment. Device/operator availability is checked and errors remain visible. Performance and architecture compatibility depend on the actual adapter and driver.
- **Native 16-bit input:** unsigned 16-bit PNG/TIFF data is decoded without an intermediate 8-bit conversion. One recorded intensity mapping is applied consistently to training and inference. Native spatial resolution remains the default.
- **Terminal NILT logo:** the NILT mark rotates while the dashboard server is open. Diagnostics stop the animation before printing. See [TERMINAL_V6.md](docs/TERMINAL_V6.md).

## Resource controls

| Preset | Suggested execution | Starting budget |
| --- | --- | ---: |
| `laptop` | CPU | 2 hours |
| `laptop_igpu` | Experimental Windows DirectML training | 2 hours |
| `workstation` | NVIDIA CUDA | 6 hours |
| `workstation_large` | NVIDIA CUDA | 12 hours |
| `workstation_50h` | NVIDIA CUDA · extended search | 48 hours · maximum 50 |

Presets are starting values. The extended `workstation_50h` profile enforces a maximum cumulative 50-hour budget; other profiles retain editable positive finite budgets. Custom search selects the device independently. The shared budget includes preparation, downloads and evaluation. More models and larger native images leave less time for each trial. Resume retains the recorded configuration and remaining cumulative allowance; it does not reset the budget. See [extended GPU search](docs/WORKSTATION_50H.md).

All image backbones use provisioned pretrained weights. The dashboard supports the original ResNet, EfficientNet, MobileNet, DenseNet, ConvNeXt-Tiny, Swin-T and PatchCore models plus 29 curated ConvNeXt V2, ConvNeXt, DeiT III, Swin V2, EVA-02 and EfficientNet V2 variants. New backbones fit the application's bad/good head and participate in training and comparison. Model cards and weight licenses are shown beside each new option. Commercial-compatible use is the default; selecting noncommercial research also enables ConvNeXt V2. A newly fitted classification head or logistic decision combiner is expected; random image-backbone training is not an operator mode.

## Image and evaluation contract

- Native padding preserves the input pixel grid. Explicit `resize: fit` resamples; the application does not silently fall back to it. Image/patch size limits report an error rather than secretly reduce resolution.
- For unsigned 16-bit sources, the default mapping uses black level `0` and white level `65535`. Device-specific levels require verified sensor information. There is no per-image automatic brightness or contrast normalization in the model loader.
- Eight-bit PNGs produced by dataset preprocessing remain valid. Their original 16-bit information cannot be recovered by converting them back to a 16-bit container.
- VIG augmentation uses exact 90-degree multiples with unchanged labels. Captures of the same tray/row/column unit stay together.
- Training, validation, calibration, selection, and final test retain distinct roles. Threshold tuning and decision fitting do not use final-test feedback.
- Review flags, predictions, original tags, and human labels are separate records. Only explicit human good/bad labels are eligible for controlled review-dataset export.
- Failed, pruned, cancelled, timed-out, and completed trials have distinct operator outcomes. Inspect the recorded reason; a failure is not a score of zero.

Training and inference process inspection data locally. New searches may download missing official public weights under the same opt-out policy for every profile; inference does not provision weights. The dashboard uses loopback networking and local assets.

The optional DirectML backend has a separate vendor diagnostic-data notice.
The weight-download checkbox is not a system-wide telemetry switch. Review
[Intel laptop training](docs/IGPU_V61.md) and company IT policy before enabling
that backend.

## Guides

- [Dashboard preprocessing](docs/DASHBOARD_PREPROCESSING.md)
- [Version 6.1 changes](WHATS_NEW_6_1.md)
- [Intel laptop training](docs/IGPU_V61.md)
- [Public weight downloads](docs/WEIGHT_DOWNLOADS_V61.md)
- [Tray quality documentation](docs/QUALITY_REPORTS_V61.md)

- [Start and reopen](START_HERE.md)
- [Windows installation](docs/INSTALLATION.md)
- [Linux installation](docs/INSTALLATION_LINUX.md)
- [Migration from version 5](MIGRATION_V6.md)
- [Custom search](docs/CUSTOM_OPTUNA.md)
- [VIG development plan](docs/VIG_CLASSIFICATION_PLAN.md)
- [Sampler selection](docs/SAMPLERS_V6.md)
- [Decision systems](docs/DECISION_LAB.md)
- [Review and uncertainty](docs/DECISION_REVIEW_V6.md)
- [Image review](docs/IMAGE_REVIEW.md)
- [Search and comparison charts](docs/SEARCH_AND_COMPARISON_CHARTS.md)
- [Command reference](docs/CLI_REFERENCE.md)
- [Portable deployment](docs/DEPLOYMENT.md)
- [Deployment quality review and per-unit reports](docs/DEPLOYMENT_QUALITY_REVIEW.md)
- [Release verification](docs/RELEASE_VERIFICATION.md)
- [Contributing](CONTRIBUTING.md)

Use a new project and results folder for this release. Preserve earlier experiments and their original code for reproduction. Do not resume an old worker with new code or overlay older patch files. Linux software checks do not establish Windows, CUDA, or Intel adapter qualification; verify the selected device and representative inspection data on the destination computer.

## Pretrained classifier comparison CLI

An optional `cvtester` CLI adds 29 license-aware pretrained ImageNet classifiers:
ConvNeXt V2, ConvNeXt, DeiT III, Swin V2, EVA-02 and EfficientNet V2 in multiple sizes.
It supports local ImageNet image prediction and dataset comparison with top-1/top-5
accuracy and forward speed. All catalog entries are also integrated into the
dashboard's binary classification training and comparison workflow.

See [classification model catalog and setup](docs/CLASSIFICATION_MODELS.md).
For GUI use and long GPU experiments, see [dashboard models and the 50-hour profile](docs/WORKSTATION_50H.md).
Install with `python -m pip install -e '.[classification]'`, then run `cvtester list`.
ConvNeXt V2 weights are noncommercial; the CLI defaults to commercial-compatible
models and loads only safetensors after checking model-card licenses.
