# Inspection Studio 6

Local image-classification training, optimization, comparison, decision design, and operator review for NIL Technology. This release extends version 5 with additional Optuna samplers, native 16-bit input, optional Intel graphics execution, comparison radars, and explicit review routing.

**Windows:** run `Setup.cmd` once for CPU or NVIDIA CUDA, then `Start.cmd`. For experimental Windows Intel/AMD graphics execution, use `Setup-DirectML.cmd` in a separate environment. Begin with [START_HERE.md](START_HERE.md). All interface text and operating guides are in English.

## Operating workspace

| View | Purpose |
| --- | --- |
| Dataset & setup | Configure folders; audit dimensions, intensity depth, labels, duplicates, groups, and splits |
| Train & search | Define model families, sampler, search ranges, pruning, budgets, and execution device; monitor progress and errors |
| Compare models | Compare completed candidates using common data roles, metrics, curves, confusion matrices, and radars |
| Decision explorer | Inspect thresholds and choose a binary or two-threshold review decision |
| Decision lab | Fit and freeze weighted ensembles, held-out stacking, cascades, and optional disagreement guards |
| Classify images | Apply a saved decision to local inputs and retain image copies |
| Inspection workflow | Arrange saved decisions and choose final voting or consensus rules |
| Image review | Compare predictions with reference tags; record independent human decisions |
| Models & reports | Load experiments, inspect artifacts, and create supported deployment packages |

## Changes in version 6

- **Search strategies:** TPE, Random, Grid, Gaussian Process, CMA-ES, NSGA-II, NSGA-III, QMC, and Brute Force. Fixed parameter specifications provide partial-fixed behavior. Options and compatibility checks are exposed. This release retains one selected validation objective; choosing NSGA does not create a multiobjective experiment automatically. See [SAMPLERS_V6.md](docs/SAMPLERS_V6.md).
- **Comparison radars:** compare final optimization settings and model metrics with disclosed scaling. Normalized parameter positions describe shared observed ranges among completed trials; a larger polygon is not a quality score. Categorical values remain explicit rather than being assigned a fictitious numeric order.
- **Two-threshold review:** automatically accept below a lower bad-score threshold, reject at or above an upper threshold, and route the intermediate band to human review. The original single-threshold mode remains available.
- **Ensemble uncertainty:** optionally route disagreeing models or high score dispersion to review. This is a diagnostic heuristic, not a calibrated probability that the decision is wrong. All guarded sources are evaluated; guarded cascades trade early-exit speed for agreement evidence.
- **Cancellation:** cooperative cancellation preserves available unfinished model state. Partial model predictions are diagnostic and require human review; they are not completed optimization results or automatically releasable decisions.
- **Intel graphics:** optional `torch-directml` execution on supported Windows hardware uses a separate dependency environment. Device/operator availability is checked and errors remain visible. Performance and architecture compatibility depend on the actual adapter and driver.
- **Native 16-bit input:** unsigned 16-bit PNG/TIFF data is decoded without an intermediate 8-bit conversion. One recorded intensity mapping is applied consistently to training and inference. Native spatial resolution remains the default.
- **Terminal NILT logo:** the supplied mark rotates while the dashboard server is open. Diagnostics stop the animation before printing. See [TERMINAL_V6.md](docs/TERMINAL_V6.md).

## Resource controls

| Preset | Suggested execution | Starting budget |
| --- | --- | ---: |
| `laptop` | CPU | 2 hours |
| `workstation` | NVIDIA CUDA | 6 hours |
| `workstation_large` | NVIDIA CUDA | 12 hours |

Presets are starting values, not limits. Custom search selects the device independently and accepts any positive finite total time allowance. The shared budget includes preparation and evaluation. More models and larger native images leave less time for each trial. Resume retains the recorded configuration and remaining cumulative allowance; it does not reset the budget.

All image backbones use provisioned pretrained weights. Supported families include ResNet18/50, EfficientNet-B0/B2/V2-S, MobileNetV3-Large, DenseNet121, ConvNeXt-Tiny, Swin-T, and PatchCore. A newly fitted classification head or logistic decision combiner is expected; random image-backbone training is not an operator mode.

## Image and evaluation contract

- Native padding preserves the input pixel grid. Explicit `resize: fit` resamples; the application does not silently fall back to it. Image/patch size limits report an error rather than secretly reduce resolution.
- For unsigned 16-bit sources, the default mapping uses black level `0` and white level `65535`. Device-specific levels require verified sensor information. There is no per-image automatic brightness or contrast normalization in the model loader.
- Eight-bit PNGs produced by dataset preprocessing remain valid. Their original 16-bit information cannot be recovered by converting them back to a 16-bit container.
- VIG augmentation uses exact 90-degree multiples with unchanged labels. Captures of the same tray/row/column unit stay together.
- Training, validation, calibration, selection, and final test retain distinct roles. Threshold tuning and decision fitting do not use final-test feedback.
- Review flags, predictions, original tags, and human labels are separate records. Only explicit human good/bad labels are eligible for controlled review-dataset export.
- Failed, pruned, cancelled, timed-out, and completed trials have distinct operator outcomes. Inspect the recorded reason; a failure is not a score of zero.

After packages and public weights are provisioned, training and inference operate locally. The dashboard uses loopback networking and local assets.

## Guides

- [Start and reopen](START_HERE.md)
- [Windows installation](docs/INSTALLATION.md)
- [Linux installation](docs/INSTALLATION_LINUX.md)
- [Migration from version 5](MIGRATION_V6.md)
- [Custom search](docs/CUSTOM_OPTUNA.md)
- [Sampler selection](docs/SAMPLERS_V6.md)
- [Decision systems](docs/DECISION_LAB.md)
- [Review and uncertainty](docs/DECISION_REVIEW_V6.md)
- [Image review](docs/IMAGE_REVIEW.md)
- [Search and comparison charts](docs/SEARCH_AND_COMPARISON_CHARTS.md)
- [Command reference](docs/CLI_REFERENCE.md)
- [Portable deployment](docs/DEPLOYMENT.md)
- [Release verification](docs/RELEASE_VERIFICATION.md)

Use a new project and results folder for this release. Preserve earlier experiments and their original code for reproduction. Do not resume an old worker with new code or overlay older patch files. Linux software checks do not establish Windows, CUDA, or Intel adapter qualification; verify the selected device and representative inspection data on the destination computer.
