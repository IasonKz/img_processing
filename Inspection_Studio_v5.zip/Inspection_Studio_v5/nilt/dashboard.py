"""Loopback-only operator dashboard. No cloud services, uploads, or shell commands.

The dashboard starts the same CLI as a terminal. Experiment logic lives in the
workflow modules; this module only supervises jobs and presents recorded data.
"""
from __future__ import annotations

import csv
from datetime import datetime, timezone
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import math
import mimetypes
import os
from pathlib import Path
import secrets
import subprocess
import sys
import threading
import time
from urllib.parse import parse_qs, unquote, urlparse
import webbrowser

from .common import MODEL_NAMES
from .dashboard_v5 import V5DashboardMixin

PROFILE_HOURS = {"laptop": 2, "workstation": 6, "workstation_large": 12}
MODELS = MODEL_NAMES
MODES = ("policy", "manual", "argmax", "scores_only")
STATIC = Path(__file__).with_name("ui")
PROJECT = Path(__file__).resolve().parent.parent


def _read_json(path, default=None):
    try:
        if Path(path).is_symlink():
            return default
        with Path(path).open(encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return default


def _read_csv(path, limit=10000):
    try:
        if Path(path).is_symlink():
            return []
        with Path(path).open(encoding="utf-8-sig", newline="") as handle:
            result = []
            for i, row in enumerate(csv.DictReader(handle)):
                if limit is not None and i >= limit:
                    break
                result.append(row)
            return result
    except (OSError, ValueError):
        return []


def _clean_json(value):
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, dict):
        return {str(k): _clean_json(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_clean_json(v) for v in value]
    return value


def _safe_path(root, relative):
    """Resolve symlinks before checking containment (also handles Windows)."""
    root = Path(root).resolve()
    path = (root / relative).resolve()
    if not path.is_relative_to(root):
        raise ValueError("Path is outside its configured root.")
    return path


class Dashboard(V5DashboardMixin):
    def __init__(self, config):
        self.base_config = Path(config).resolve()
        self.config = self.base_config
        self.base_config_sha256 = hashlib.sha256(self.base_config.read_bytes()).hexdigest()
        self._restore_active_config()
        self.token = secrets.token_urlsafe(32)
        self.lock = threading.RLock()
        self.jobs = []
        self.output_roots = []
        self.data_roots = []
        self.loaded_runs = []
        self._load_config()
        self._restore_registered_runs()
        self._restore_jobs()

    @staticmethod
    def _read_config(path):
        import yaml
        with Path(path).open(encoding="utf-8-sig") as handle:
            raw = yaml.safe_load(handle)
        Dashboard._validate_config(raw)
        return raw

    @staticmethod
    def _validate_config(raw):
        if not isinstance(raw, dict):
            raise ValueError("Project configuration must be a YAML mapping.")
        for key in ("paths", "tasks", "profiles", "defaults"):
            if key in raw and not isinstance(raw[key], dict):
                raise ValueError(f"Project {key} must be a YAML mapping.")
        if any(not isinstance(cfg, dict) for cfg in raw.get("tasks", {}).values()):
            raise ValueError("Each inspection task must be a YAML mapping.")
        for key in ("output_root", "weights_root", "incoming_root", "classification_output_root"):
            if key in raw.get("paths", {}) and not isinstance(raw["paths"][key], str):
                raise ValueError(f"Project path {key} must be a string.")
        for task in raw.get("tasks", {}).values():
            if task.get("dataset_root") is not None and not isinstance(task["dataset_root"], str):
                raise ValueError("Dataset paths must be strings.")
        if raw.get("profile", "laptop") not in PROFILE_HOURS:
            raise ValueError("Choose a supported project profile.")

    def _restore_active_config(self):
        """Reuse an operator snapshot only for an unchanged, explicitly selected base."""
        import yaml
        settings = _read_json(self.base_config.parent / "studio_settings.json", {})
        if (not isinstance(settings, dict) or settings.get("base_config") != str(self.base_config)
                or settings.get("base_sha256") != self.base_config_sha256):
            return
        name = settings.get("snapshot")
        if (not isinstance(name, str) or not name.startswith("project.dashboard.")
                or not name.endswith(".yaml") or "/" in name or "\\" in name):
            return
        snapshot = self.base_config.parent / name
        if snapshot.is_symlink() or snapshot.resolve().parent != self.base_config.parent:
            return
        try:
            self._read_config(snapshot)
        except (OSError, ValueError, TypeError, yaml.YAMLError):
            return
        self.config = snapshot

    def _load_config(self):
        self.raw = self._read_config(self.config)
        paths = self.raw.get("paths", {})
        for key, fallback in (("output_root", "results"), ("classification_output_root", "classified")):
            root = self._configured_path(paths.get(key, fallback))
            if root not in self.output_roots:
                self.output_roots.append(root)
        for folder in ("decisions", "packages", "dashboard_logs", "workflows", "decision_systems", "review_datasets"):
            root = self.config.parent / folder
            if root not in self.output_roots:
                self.output_roots.append(root)
        for cfg in self.raw.get("tasks", {}).values():
            if isinstance(cfg, dict) and cfg.get("dataset_root"):
                root = self._configured_path(cfg["dataset_root"])
                if root not in self.data_roots:
                    self.data_roots.append(root)

    @property
    def logs_root(self):
        return self.config.parent / "dashboard_logs"

    def _validate_run(self, value):
        if not str(value).strip():
            raise ValueError("Enter the experiment folder path.")
        run = Path(value).expanduser().resolve()
        cfg = _read_json(run / "config.json")
        if not run.is_dir() or not isinstance(cfg, dict) or cfg.get("task") not in ("vig", "top", "bottom"):
            raise ValueError("The folder must contain a valid experiment config.json with a supported task.")
        if "models" in cfg and (not isinstance(cfg["models"], list) or not cfg["models"] or any(m not in MODELS for m in cfg["models"])):
            raise ValueError("The experiment configuration contains unsupported models.")
        if not any((run / name).is_file() and not (run / name).is_symlink()
                   for name in ("model_state.json", "search_status.json", "manifest.csv")):
            raise ValueError("The folder has no recorded experiment state or dataset manifest.")
        if any(run == root or root.is_relative_to(run) for root in self.data_roots):
            raise ValueError("Choose an experiment folder, not a dataset or its parent.")
        return run

    def _restore_registered_runs(self):
        registered = _read_json(self.logs_root / "registered_runs.json", [])
        if not isinstance(registered, list):
            return
        for value in registered[:100]:
            try:
                run = self._validate_run(value)
            except (ValueError, TypeError, OSError):
                continue
            if run not in self.loaded_runs:
                self.loaded_runs.append(run)
            if run not in self.output_roots:
                self.output_roots.append(run)

    def load_run(self, data):
        from .common import write_json
        run = self._validate_run(data.get("path", data.get("run", "")))
        with self.lock:
            if run not in self.loaded_runs:
                self.loaded_runs.append(run)
            # Register only this verified experiment, never its parent directory.
            if run not in self.output_roots:
                self.output_roots.append(run)
            write_json(self.logs_root / "registered_runs.json", [str(p) for p in self.loaded_runs])
        return {"run": self.run_info(str(run)), "state": self.state()}

    def _persist_job(self, job):
        from .common import write_json
        if not job.get("id"):
            return
        write_json(self.logs_root / (job["id"] + ".job.json"),
                   {key: value for key, value in job.items() if key != "lines"})

    def _process_state(self, job):
        """A reused PID must never be mistaken for this dashboard's worker."""
        import psutil
        try:
            process = psutil.Process(int(job["pid"]))
            if job.get("process_created") is None:
                return "unverified"
            if abs(process.create_time() - float(job["process_created"])) > .01:
                return "stopped"
            if process.status() == psutil.STATUS_ZOMBIE or not process.is_running():
                return "stopped"
            expected = job.get("command", [])
            if len(expected) < 3 or Path(expected[2]).resolve() != PROJECT / "inspection.py":
                return "stopped"
            if process.cmdline() != expected:
                return "stopped"
            # Record the executable reported by the OS at launch. On Windows a
            # virtual-environment launcher may resolve to the base interpreter.
            executable = job.get("process_executable", expected[0])
            if Path(process.exe()).resolve() != Path(executable).resolve():
                return "stopped"
            return "running"
        except psutil.NoSuchProcess:
            return "stopped"
        except psutil.AccessDenied:
            return "unverified"
        except (KeyError, TypeError, ValueError, OSError):
            return "stopped"

    def _refresh_recovered_jobs(self):
        for job in self.jobs:
            if not job.get("detached") or job.get("status") not in ("running", "unverified"):
                continue
            state = self._process_state(job)
            job["lines"] = self._tail_log(job.get("log"))
            run_lines = job["lines"]
            if not job.get("run"):
                try:
                    log = Path(job.get("log", "")).resolve()
                    if log.is_relative_to(self.logs_root.resolve()) and log.suffix == ".log":
                        with log.open("r", encoding="utf-8", errors="replace") as handle:
                            run_lines = handle.read(16384).splitlines() + run_lines
                except OSError:
                    pass
            for line in run_lines:
                if line.startswith("RUN:"):
                    try:
                        job["run"] = str(self.run_path(line[4:].strip()))
                    except ValueError:
                        pass
            if state == "stopped":
                job.update(status="ended", finished=time.time(),
                           message="The recovered worker has ended. Inspect the experiment status and log for its result.")
            else:
                job["status"] = state
                if state == "unverified":
                    job["message"] = "Worker ownership could not be verified. Check the recorded process before starting another job."
            self._persist_job(job)

    def _tail_log(self, value):
        if not value:
            return []
        path = Path(value).resolve()
        if not path.is_relative_to(self.logs_root.resolve()) or path.suffix != ".log":
            return []
        try:
            with path.open("rb") as handle:
                handle.seek(0, 2)
                handle.seek(max(0, handle.tell() - 128 * 1024))
                return handle.read().decode("utf-8", errors="replace").splitlines()[-200:]
        except OSError:
            return []

    def _restore_jobs(self):
        for path in sorted(self.logs_root.glob("*.job.json"))[-100:]:
            job = _read_json(path, {})
            if not isinstance(job, dict) or job.get("id") != path.name[:-9]:
                continue
            job["lines"] = self._tail_log(job.get("log"))
            if job.get("status") in ("running", "unverified"):
                job["detached"] = True
            self.jobs.append(job)
        self._refresh_recovered_jobs()

    def _configured_path(self, value):
        path = Path(value).expanduser()
        return (path if path.is_absolute() else self.config.parent / path).resolve()

    def checked_output(self, value, exists=False):
        path = Path(value).expanduser().resolve()
        if not any(path.is_relative_to(root.resolve()) for root in self.output_roots):
            raise ValueError("Choose a path inside the configured results, decisions, classified or packages folders.")
        if exists and not path.exists():
            raise ValueError("The selected path does not exist.")
        return path

    def run_path(self, value):
        run = self.checked_output(value, exists=True)
        if not any((run / name).is_file() for name in ("config.json", "model_state.json", "search_status.json")):
            raise ValueError("Choose a recorded experiment folder.")
        return run

    def bootstrap(self):
        paths = self.raw.get("paths", {})
        return {"token": self.token, "config": str(self.config), "active_config": str(self.config),
                "base_config": str(self.base_config), "profile": self.raw.get("profile", "laptop"),
                "profiles": PROFILE_HOURS,
                "profile_models": {profile: self.raw.get("profiles", {}).get(profile, {}).get("models",
                                   self.raw.get("defaults", {}).get("models", ["resnet18"] if profile == "laptop" else list(MODELS)))
                                   for profile in PROFILE_HOURS},
                "task_models": {name: cfg["models"] for name, cfg in self.raw.get("tasks", {}).items()
                                if isinstance(cfg, dict) and cfg.get("models")},
                "models": MODELS, "tasks": list(self.raw.get("tasks", {"vig": {}})),
                "task_enabled": {name: cfg.get("enabled", True) for name, cfg in self.raw.get("tasks", {}).items()
                                 if isinstance(cfg, dict)},
                "datasets": {name: str(self._configured_path(cfg["dataset_root"]))
                             for name, cfg in self.raw.get("tasks", {}).items()
                             if isinstance(cfg, dict) and cfg.get("dataset_root")},
                "paths": {"output": str(self._configured_path(paths.get("output_root", "results"))),
                          "weights": str(self._configured_path(paths.get("weights_root", "weights"))),
                          "incoming": str(self._configured_path(paths.get("incoming_root", "incoming"))),
                          "classified": str(self._configured_path(paths.get("classification_output_root", "classified"))),
                          "decisions": str(self.config.parent / "decisions"),
                          "packages": str(self.config.parent / "packages"),
                          "workflows": str(self.config.parent / "workflows"),
                          "decision_systems": str(self.config.parent / "decision_systems"),
                          "review_datasets": str(self.config.parent / "review_datasets")},
                "offline": True}

    def save_config(self, data):
        """Write a new snapshot; never rewrite the user's configuration."""
        import copy
        import yaml
        from .common import write_json
        raw = copy.deepcopy(self.raw)
        for key in ("output_root", "weights_root", "incoming_root", "classification_output_root"):
            if key in raw.get("paths", {}):
                raw["paths"][key] = str(self._configured_path(raw["paths"][key]))
        for cfg in raw.get("tasks", {}).values():
            for key in ("dataset_root", "groups_csv", "previous_run"):
                if cfg.get(key):
                    cfg[key] = str(self._configured_path(cfg[key]))
        task = data.get("task", "vig")
        if task not in raw.get("tasks", {}):
            raise ValueError("Unknown task.")
        dataset = Path(str(data.get("dataset", ""))).expanduser().resolve()
        if not str(data.get("dataset", "")).strip() or not dataset.is_dir():
            raise ValueError("Dataset folder must exist on this computer.")
        raw["tasks"][task]["dataset_root"] = str(dataset)
        raw["tasks"][task]["enabled"] = True
        if "profile" in data:
            if data["profile"] not in PROFILE_HOURS:
                raise ValueError("Choose a supported project profile.")
            raw["profile"] = data["profile"]
        for field, key in (("output", "output_root"), ("weights", "weights_root")):
            if data.get(field):
                value = Path(data[field]).expanduser().resolve()
                if field == "output" and (value.is_relative_to(dataset) or dataset.is_relative_to(value)):
                    raise ValueError("Results and dataset folders must not overlap.")
                raw.setdefault("paths", {})[key] = str(value)
        self._validate_config(raw)
        # Same directory preserves any less common configuration-relative fields.
        target = self.config.parent / ("project.dashboard." + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%f") + ".yaml")
        with target.open("x", encoding="utf-8") as handle:
            yaml.safe_dump(raw, handle, sort_keys=False)
        # The saved copy is validated before publishing the pointer. The original
        # file's startup hash ensures external edits take precedence on restart.
        self._read_config(target)
        write_json(self.base_config.parent / "studio_settings.json", {
            "base_config": str(self.base_config), "base_sha256": self.base_config_sha256,
            "snapshot": target.name})
        self.config = target
        self._load_config()
        return self.bootstrap()

    def command(self, action, data):
        v5 = self.v5_command(action, data, PROJECT)
        if v5 is not None:
            return v5
        command = [sys.executable, "-u", str(PROJECT / "inspection.py")]
        if action in ("doctor", "audit", "search", "prepare-weights"):
            task, profile = data.get("task", "vig"), data.get("profile", "laptop")
            if profile not in PROFILE_HOURS or task not in self.raw.get("tasks", {}):
                raise ValueError("Unknown profile or task.")
            command += ["download-weights" if action == "prepare-weights" else action,
                        "--config", str(self.config), "--profile", profile, "--task", task]
            if action == "search":
                models = data.get("models", [])
                if not isinstance(models, list) or not models or any(m not in MODELS for m in models):
                    raise ValueError("Select at least one supported model.")
                if data.get("custom") is not None:
                    snapshot = self.v5_search_config(data)
                    command[command.index("--config") + 1] = str(snapshot)
                else:
                    hours = float(data.get("hours", PROFILE_HOURS[profile]))
                    if not math.isfinite(hours) or hours <= 0:
                        raise ValueError("Time budget must be finite and positive.")
                    if self._v5_resolved_config(profile, task).get("pretrained") is not True:
                        raise ValueError("Studio 5 searches require pretrained image models.")
                    command += ["--hours", str(hours)]
                command += ["--models", *dict.fromkeys(models)]
            elif action == "prepare-weights" and data.get("models") is not None:
                models = data["models"]
                if not isinstance(models, list) or not models or any(m not in MODELS for m in models):
                    raise ValueError("Select at least one supported model to provision weights.")
                command += ["--models", *dict.fromkeys(models)]
        elif action in ("finalize-search", "status", "report", "resume-search"):
            run = self.run_path(data.get("run", ""))
            command += ["search" if action == "resume-search" else action, "--run", str(run)]
        elif action == "decision":
            run = self.run_path(data.get("run", ""))
            mode = data.get("mode", "policy")
            if mode not in MODES:
                raise ValueError("Unknown decision mode.")
            candidate = str(data.get("candidate", "selected"))
            if candidate != "selected":
                candidates = _read_json(run / "candidates.json", [])
                if candidate not in {c["name"] for c in candidates}:
                    raise ValueError("Unknown candidate.")
            target = self.checked_output(data.get("output", self.config.parent / "decisions"))
            command += ["decision", "--run", str(run), "--mode", mode,
                        "--candidate", candidate, "--output-root", str(target)]
            if mode == "manual":
                value = float(data.get("threshold", "nan"))
                if not math.isfinite(value):
                    raise ValueError("A manual threshold must be finite.")
                command += ["--threshold", str(value)]
        elif action == "classify":
            decision = self.checked_output(data.get("decision", ""), exists=True)
            if decision.name != "decision.json":
                raise ValueError("Select a saved decision.json.")
            input_dir = Path(str(data.get("input", ""))).expanduser().resolve()
            if not str(data.get("input", "")).strip() or not input_dir.is_dir():
                raise ValueError("Input image folder does not exist.")
            output = self.checked_output(data.get("output", ""))
            device = data.get("device", "cpu")
            if device not in ("cpu", "cuda", "auto"):
                raise ValueError("Unknown device.")
            command += ["classify", "--decision", str(decision), "--input", str(input_dir),
                        "--output-root", str(output), "--device", device]
            if data.get("labeled"):
                command.append("--labeled")
            if data.get("copy_images", True):
                command.append("--copy-images")
        elif action == "workflow-run":
            from .inspection_flow import load_workflow
            workflow = self.checked_output(data.get("workflow", ""), exists=True)
            load_workflow(workflow)
            input_dir = Path(str(data.get("input", ""))).expanduser().resolve()
            if not str(data.get("input", "")).strip() or not input_dir.is_dir():
                raise ValueError("Input image folder does not exist.")
            output = self.checked_output(data.get("output", ""))
            device = data.get("device", "cpu")
            if device not in ("cpu", "cuda", "auto"):
                raise ValueError("Unknown device.")
            command += ["workflow-run", "--workflow", str(workflow), "--input", str(input_dir),
                        "--output-root", str(output), "--device", device]
            if data.get("labeled"):
                command.append("--labeled")
            if not data.get("copy_images", True):
                command.append("--no-copy-images")
        elif action in ("export", "package"):
            run = self.run_path(data.get("run", ""))
            output = self.checked_output(data.get("output", ""))
            command += [action, "--run", str(run), "--output", str(output)]
            if action == "export":
                command += ["--candidate", "selected"]
            else:
                kind = data.get("kind", "inference")
                if kind not in ("inference", "training"):
                    raise ValueError("Unknown package kind.")
                command += ["--kind", kind]
                if data.get("decision"):
                    if kind != "inference":
                        raise ValueError("Saved decision overrides apply to inference packages only.")
                    decision = self.checked_output(data["decision"], exists=True)
                    if decision.name != "decision.json":
                        raise ValueError("Choose a saved decision.json.")
                    command += ["--decision", str(decision)]
        else:
            raise ValueError("Unsupported dashboard action.")
        return command

    def start(self, action, data):
        command = self.command(action, data)
        with self.lock:
            self._refresh_recovered_jobs()
            if getattr(self, "_v5_operation", None) or any(j["status"] in ("running", "unverified") for j in self.jobs):
                raise ValueError("A job is already running. Wait or pause the search first.")
            root = self.config.parent / "dashboard_logs"
            root.mkdir(exist_ok=True)
            job_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%f")
            job = {"id": job_id, "action": action, "status": "running", "started": time.time(),
                   "command": command, "lines": [], "run": data.get("run"),
                   "log": str(root / (job_id + ".log"))}
            kwargs = {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt" else {"start_new_session": True}
            # A real file (not a pipe owned by this server) lets workers continue
            # safely if the dashboard is closed while training is running.
            with open(job["log"], "w", encoding="utf-8") as output:
                process = subprocess.Popen(command, cwd=str(PROJECT), stdout=output,
                                           stderr=subprocess.STDOUT,
                                           env={**os.environ, "PYTHONUNBUFFERED": "1"}, **kwargs)
            job["pid"] = process.pid
            import psutil
            try:
                identity = psutil.Process(process.pid)
                job["process_created"] = identity.create_time()
                job["process_executable"] = identity.exe()
            except psutil.NoSuchProcess:
                job["process_created"] = None
            except psutil.AccessDenied:
                job["process_created"] = None
                job["identity_unverified"] = True
            self.jobs.append(job)
            self._persist_job(job)
            threading.Thread(target=self._capture, args=(job, process), daemon=True).start()
            return {"job": job_id}

    def _capture(self, job, process):
        with open(job["log"], encoding="utf-8", errors="replace") as output:
            while True:
                line = output.readline()
                if not line:
                    if process.poll() is not None:
                        break
                    time.sleep(.2)
                    continue
                with self.lock:
                    job["lines"].append(line.rstrip())
                    del job["lines"][:-1000]
                    if line.startswith("RUN:"):
                        try:
                            job["run"] = str(self.checked_output(line[4:].strip()))
                            self._persist_job(job)
                        except ValueError:
                            pass
            code = process.wait()
        with self.lock:
            job.update(status="finished" if code == 0 else "failed", exit_code=code, finished=time.time())
            self._persist_job(job)

    def pause(self, selected_run=None):
        from .common import write_json
        with self.lock:
            self._refresh_recovered_jobs()
            if any(j.get("status") == "unverified" for j in self.jobs):
                raise ValueError("The recovered worker identity is unverified. Inspect its recorded PID before making changes.")
            job = next((j for j in reversed(self.jobs) if j["status"] == "running"), None)
            if job and (job["action"] not in ("search", "resume-search") or not job.get("run")):
                raise ValueError("A search must finish preparing its run before it can be paused.")
            if not job and not selected_run:
                raise ValueError("Choose an active search to pause.")
            run = self.run_path(job["run"] if job else selected_run)
            if not job:
                status = _read_json(run / "search_status.json", {}).get("status")
                if status not in ("SEARCHING", "SELECTING", "SEARCH_CONFIRMING"):
                    raise ValueError("The selected experiment has no active search to pause.")
            target = run / "control.json"
            write_json(target, {"action": "pause", "stop": True})
            if job:
                job["pause_requested"] = True
                self._persist_job(job)
        return {"message": "Pause requested. The worker will stop at a safe checkpoint boundary."}

    def runs(self):
        paths = set(self.loaded_runs)
        for root in self.output_roots:
            # Known layout: output_root / task / run. No recursive dataset scan.
            for pattern in ("*/config.json", "*/*/config.json", "*/model_state.json", "*/*/model_state.json"):
                for path in root.glob(pattern):
                    resolved = path.parent.resolve()
                    if resolved.is_relative_to(root.resolve()):
                        paths.add(resolved)
        result = []
        for run in sorted(paths, key=lambda p: p.name, reverse=True)[:100]:
            state = _read_json(run / "model_state.json", {})
            cfg = _read_json(run / "config.json", {})
            search = _read_json(run / "search_status.json", {})
            result.append({"path": str(run), "name": run.name, "task": cfg.get("task", state.get("task")),
                           "profile": cfg.get("profile"), "status": search.get("status", state.get("status", "UNKNOWN"))})
        return result

    def file_url(self, path):
        from urllib.parse import quote
        path = Path(path).resolve()
        for index, root in enumerate(self.output_roots):
            if path.is_relative_to(root.resolve()):
                return "/results/" + str(index) + "/" + quote(path.relative_to(root.resolve()).as_posix(), safe="/")
        raise ValueError("Result file is outside configured roots.")

    def run_info(self, value):
        run = self.run_path(value)
        histories = []
        folders = set()
        for pattern in ("models/*/history.csv", "search/*/trial_*/history.csv",
                        "search/confirmations/*/seed_*/history.csv", "models/*/progress.json",
                        "search/*/trial_*/progress.json", "search/confirmations/*/seed_*/progress.json"):
            for path in sorted(run.glob(pattern))[-200:]:
                if not path.resolve().is_relative_to(run):
                    continue
                folders.add(path.parent)
        for folder in sorted(folders):
            progress_path = folder / "progress.json"
            histories.append({"name": folder.relative_to(run).as_posix(),
                              "history": _read_csv(folder / "history.csv", 2000),
                              "progress": _read_json(progress_path, {}),
                              "updated": progress_path.stat().st_mtime if progress_path.exists() else 0})
        reports = []
        for pattern in ("*.html", "visual_reports/*.html", "inspection_reports/*.html"):
            for path in run.glob(pattern):
                if path.resolve().is_relative_to(run):
                    reports.append({"name": path.relative_to(run).as_posix(), "url": self.file_url(path)})
        failures = []
        failure_by_trial = {}
        for path in sorted(run.glob("search/*/trial_*/failure.json"))[-1000:]:
            if not path.resolve().is_relative_to(run):
                continue
            record = _read_json(path, {})
            if not isinstance(record, dict):
                continue
            failure = {"model": path.parent.parent.name, "trial": path.parent.name,
                       "error": record.get("error", "Unknown execution failure"),
                       "traceback": str(record.get("traceback", ""))[-24000:],
                       "oom": record.get("oom"), "url": self.file_url(path)}
            failures.append(failure)
            failure_by_trial[(failure["model"], failure["trial"])] = failure
        trials = _read_csv(run / "trials.csv", limit=None)
        for trial in trials:
            try:
                key = (trial.get("model"), "trial_" + str(int(trial.get("trial", -1))).zfill(5))
            except (TypeError, ValueError):
                continue
            if key in failure_by_trial:
                trial["failure"] = failure_by_trial[key]
                trial["error"] = failure_by_trial[key]["error"]
        return {"path": str(run), "state": _read_json(run / "model_state.json", {}),
                "search": _read_json(run / "search_status.json", {}),
                "trials": trials, "failures": failures, "histories": histories,
                "candidates": _read_json(run / "candidates.json", []),
                "selected": _read_json(run / "selected.json", {}),
                "splits": _read_json(run / "split_summary.json", {}),
                "audit": _read_json(run / "audit" / "audit_summary.json", {}),
                "reports": reports}

    def review_sessions(self):
        from .review import list_sessions
        found = {}
        for root in self.output_roots:
            for session in list_sessions(root):
                try:
                    path = self.checked_output(session["path"], exists=True)
                except (ValueError, KeyError):
                    continue
                found[str(path)] = session
        return sorted(found.values(), key=lambda item: item.get("created_utc", ""), reverse=True)[:500]

    def _review_session_path(self, value):
        session = self.checked_output(value, exists=True)
        if not session.is_dir() or not (session / "review_session.json").is_file():
            raise ValueError("Choose a recorded image review session.")
        return session

    def review_detail(self, data):
        from .review import session_detail
        from urllib.parse import urlencode
        session = self._review_session_path(data.get("session", ""))
        options = {key: data[key] for key in ("prediction", "reference", "review", "search", "filter", "sort") if data.get(key)}
        for key in ("page", "page_size", "offset", "limit"):
            if data.get(key) not in (None, ""):
                options[key] = int(data[key])
        options["errors_only"] = str(data.get("errors_only", "false")).lower() == "true"
        result = session_detail(session, **options)
        for item in result.get("items", []):
            if item.get("copied_path"):
                item["image_url"] = "/api/review-image?" + urlencode({"session": str(session), "item_id": item["id"]})
        return result

    def review_label(self, data):
        from .review import save_review
        session = self._review_session_path(data.get("session", ""))
        return save_review(session, str(data.get("item_id", "")), str(data.get("label", "")),
                           note=str(data.get("note", "")))

    def review_image(self, data):
        from .review import resolve_review_asset
        session = self._review_session_path(data.get("session", ""))
        path = resolve_review_asset(session, str(data.get("item_id", "")))
        path = self.checked_output(path, exists=True)
        if path.suffix.lower() not in (".bmp", ".png", ".jpg", ".jpeg"):
            raise ValueError("Only copied inspection images may be displayed.")
        if path.stat().st_size > 64 * 1024 * 1024:
            raise ValueError("Open this large image in its local folder.")
        return path

    def compare_review_sessions(self, data):
        from .session_compare import compare_sessions
        values = data.get("sessions", [])
        if not isinstance(values, list) or not 2 <= len(values) <= 4:
            raise ValueError("Choose two to four review sessions to compare.")
        return compare_sessions([self._review_session_path(value) for value in values])

    def workflows(self):
        records = []
        root = self.config.parent / "workflows"
        for path in root.glob("*/workflow.json"):
            if not path.resolve().is_relative_to(root.resolve()):
                continue
            record = _read_json(path, {})
            if isinstance(record, dict) and record.get("stages"):
                records.append(dict(record, path=str(path)))
        return sorted(records, key=lambda item: item["path"], reverse=True)[:200]

    def create_workflow(self, data):
        from .inspection_flow import create_workflow
        definition = data.get("definition")
        if not isinstance(definition, dict):
            raise ValueError("A workflow definition is required.")
        for stage in definition.get("stages", []):
            if not isinstance(stage, dict):
                raise ValueError("Each workflow stage must be an object.")
            self.checked_output(stage.get("decision", ""), exists=True)
        path = create_workflow(definition, self.config.parent / "workflows")
        return {"path": str(path), "workflow": _read_json(path, {})}

    def models(self):
        items = []
        for entry in self.runs():
            run = Path(entry["path"])
            selected = _read_json(run / "selected.json", {})
            candidates = _read_json(run / "candidates.json", [])
            if not isinstance(candidates, list):
                continue
            for candidate in candidates:
                if not isinstance(candidate, dict):
                    continue
                items.append({"run": str(run), "task": entry.get("task"), "candidate": candidate,
                              "selected": candidate.get("name") == selected.get("name")})
        return items[:1000]

    def decisions(self):
        items = []
        for root in self.output_roots:
            for path in root.glob("*/decision.json"):
                if not path.resolve().is_relative_to(root.resolve()):
                    continue
                data = _read_json(path, {})
                if data.get("mode") in MODES:
                    candidate = data.get("candidate", {})
                    reference = data.get("run_reference", {})
                    source_run = ((path.parent / reference["path"]).resolve()
                                  if reference.get("kind") == "relative" else Path(reference["path"]).resolve()
                                  if reference.get("path") else None)
                    items.append({"path": str(path), "mode": data["mode"], "threshold": data.get("threshold"),
                                  "candidate": candidate.get("name") if isinstance(candidate, dict) else candidate,
                                  "source_run": str(source_run) if source_run else None,
                                  "name": path.parent.name})
        return sorted(items, key=lambda x: x["name"], reverse=True)[:100]

    def state(self):
        with self.lock:
            self._refresh_recovered_jobs()
            jobs = [dict(j, lines=j["lines"][-200:]) for j in self.jobs[-20:]]
        return {"jobs": jobs, "runs": self.runs(), "decisions": self.decisions(),
                "workflows": self.workflows(), "review_sessions": self.review_sessions(), "models": self.models(),
                "systems": self.v5_systems(), "workspace_operation": getattr(self, "_v5_operation", None)}

    def preview(self, data):
        from .decisions import calibration_preview
        run = self.run_path(data.get("run", ""))
        candidate = data.get("candidate", "selected")
        threshold = data.get("threshold")
        if threshold not in (None, ""):
            threshold = float(threshold)
            if not math.isfinite(threshold):
                raise ValueError("Threshold must be finite.")
        else:
            threshold = None
        result = calibration_preview(run, candidate=candidate, threshold=threshold)
        # Original images are linked only after matching the immutable manifest.
        rows = _read_csv(run / "manifest.csv", limit=1000000)
        known = {r.get("relative_path"): r for r in rows if r.get("split") == "threshold"}
        location = _read_json(run / "data_location.json", {})
        cfg = _read_json(run / "config.json", {})
        root = Path(location.get("data_root", cfg.get("data_root", ""))).resolve()
        if root in self.data_roots:
            from urllib.parse import quote
            index = self.data_roots.index(root)
            for row in result.get("rows", []):
                relative = row.get("relative_path")
                if relative in known:
                    path = _safe_path(root, relative)
                    if path.is_file():
                        row["image_url"] = "/images/" + str(index) + "/" + quote(relative, safe="/")
        return result

    def open_folder(self, value):
        path = self.checked_output(value, exists=True)
        if not path.is_dir():
            path = path.parent
        if os.name == "nt":
            os.startfile(str(path))
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return {"message": "Opened the folder on this computer."}


def make_handler(app):
    class Handler(BaseHTTPRequestHandler):
        server_version = "InspectionStudio/5"

        def log_message(self, format, *args):
            pass

        def _check_host(self):
            expected = "127.0.0.1:" + str(self.server.server_port)
            if self.headers.get("Host") != expected:
                raise PermissionError("Open the dashboard using its exact 127.0.0.1 address.")
            origin = self.headers.get("Origin")
            if origin and origin != "http://" + expected:
                raise PermissionError("Cross-origin requests are not allowed.")

        def _send(self, body, content_type="application/json; charset=utf-8", status=200):
            if not isinstance(body, bytes):
                body = json.dumps(_clean_json(body), allow_nan=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            # Generated reports may embed their own scripts; dashboard assets don't.
            self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            try:
                self._check_host()
                parsed = urlparse(self.path)
                data = {k: v[0] for k, v in parse_qs(parsed.query).items()}
                path = unquote(parsed.path)
                if path == "/api/bootstrap":
                    result = app.bootstrap()
                elif path == "/api/state":
                    result = app.state()
                elif path == "/api/run":
                    result = app.run_info(data.get("run", ""))
                elif path == "/api/preview":
                    result = app.preview(data)
                elif path == "/api/review-sessions":
                    result = app.review_sessions()
                elif path == "/api/review":
                    result = app.review_detail(data)
                elif path == "/api/review-image":
                    file = app.review_image(data)
                    return self._send(file.read_bytes(), mimetypes.guess_type(file.name)[0] or "application/octet-stream")
                elif path == "/api/workflows":
                    result = app.workflows()
                elif path == "/api/models":
                    result = app.models()
                elif path == "/api/decisions":
                    result = app.decisions()
                elif path == "/api/v5/defaults":
                    result = app.v5_defaults(data)
                elif path == "/api/v5/systems":
                    result = app.v5_systems()
                elif path in ("/", "/app.js", "/v5.js", "/style.css", "/analytics.js", "/analytics.css", "/NIL-logo.png"):
                    file = STATIC / ({"/": "index.html"}.get(path, path[1:]))
                    return self._send(file.read_bytes(), mimetypes.guess_type(file.name)[0] or "text/plain")
                elif path.startswith(("/results/", "/images/")):
                    kind, index, relative = path.lstrip("/").split("/", 2)
                    roots = app.output_roots if kind == "results" else app.data_roots
                    number = int(index)
                    if number < 0 or number >= len(roots):
                        raise ValueError("Unknown file root.")
                    file = _safe_path(roots[number], relative)
                    allowed = {".png", ".bmp", ".jpg", ".jpeg"} if kind == "images" else {".html", ".css", ".js", ".png", ".bmp", ".jpg", ".jpeg", ".svg", ".json", ".csv", ".txt", ".log"}
                    if file.suffix.lower() not in allowed or not file.is_file():
                        raise ValueError("File is unavailable or not a report/image.")
                    if file.stat().st_size > 64 * 1024 * 1024:
                        raise ValueError("Open this large file in its local folder.")
                    return self._send(file.read_bytes(), mimetypes.guess_type(file.name)[0] or "text/plain")
                else:
                    return self._send({"error": "Not found"}, status=404)
                self._send(result)
            except PermissionError as exc:
                self._send({"error": str(exc)}, status=403)
            except Exception as exc:
                self._send({"error": str(exc)}, status=400)

        def do_POST(self):
            try:
                self._check_host()
                if not secrets.compare_digest(self.headers.get("X-Inspection-Token", ""), app.token):
                    raise PermissionError("Invalid dashboard session. Reload this page.")
                if self.headers.get_content_type() != "application/json":
                    raise ValueError("Expected JSON.")
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length <= 128 * 1024:
                    raise ValueError("Invalid request size.")
                data = json.loads(self.rfile.read(length))
                if not isinstance(data, dict):
                    raise ValueError("Expected an object.")
                if self.path == "/api/action":
                    result = app.start(data.pop("action", ""), data)
                elif self.path == "/api/config":
                    result = app.save_config(data)
                elif self.path == "/api/pause":
                    result = app.pause(data.get("run"))
                elif self.path == "/api/open-folder":
                    result = app.open_folder(data.get("path", ""))
                elif self.path == "/api/load-run":
                    result = app.load_run(data)
                elif self.path == "/api/review-label":
                    result = app.review_label(data)
                elif self.path == "/api/review-compare":
                    result = app.compare_review_sessions(data)
                elif self.path == "/api/workflows":
                    result = app.create_workflow(data)
                elif self.path == "/api/v5/system-preview":
                    result = app.v5_system_preview(data)
                elif self.path == "/api/v5/validate-search":
                    result = app.v5_search_config(data, persist=False)
                elif self.path == "/api/v5/system-save":
                    result = app.v5_system_save(data)
                elif self.path == "/api/v5/review-export":
                    result = app.v5_review_export(data)
                else:
                    return self._send({"error": "Not found"}, status=404)
                self._send(result)
            except PermissionError as exc:
                self._send({"error": str(exc)}, status=403)
            except Exception as exc:
                self._send({"error": str(exc)}, status=400)

    return Handler


def serve_dashboard(config, host="127.0.0.1", port=8765, open_browser=True):
    if host != "127.0.0.1":
        raise ValueError("The dashboard only binds to 127.0.0.1.")
    app = Dashboard(config)
    server = ThreadingHTTPServer((host, int(port)), make_handler(app))
    server.daemon_threads = True
    url = "http://127.0.0.1:" + str(server.server_port)
    print(f"Local dashboard: {url}\nKeep this terminal open. Press Ctrl+C to close the dashboard.", flush=True)
    print("Jobs already started continue independently; use Pause search before closing if required.", flush=True)
    if open_browser:
        threading.Timer(.4, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever(poll_interval=.3)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
