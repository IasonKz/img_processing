# Inspection Visual Reporting Add-on

Version 1.0.0 · Visual Inspection Pipeline 2.0.0 · Local operation

## Purpose

Generate a standalone HTML report for existing training runs and collect additional training timing and memory samples for future runs. The report works without a web server, internet connection or cloud account. Original images, checkpoints, selected thresholds and quality policies remain unchanged.

All scripts in this add-on use the original project's Python environment. NumPy and PyYAML are already included in its base requirements. Report generation does not require PyTorch, GPU access or access to the source images. Training still requires the original project's dependencies and compatible pretrained weights.

## Installation

1. Extract this archive to a temporary folder.
2. Copy its contents into the existing project root, beside `inspection.py`, `project.yaml` and `nilt/`.
3. Confirm that `visual_report.py`, `inspection_observed.py`, `configure_visual_profiles.py` and `inspection_visual/` are beside `inspection.py`.

The add-on does not replace `inspection.py`, `nilt/`, `project.yaml`, requirements or existing result files. No virtual environment is included. An active run can continue using its original command; batch measurements only become available when a future run uses the observed runner.

## Report existing VIG results now

In PowerShell, from the project root:

```powershell
.\.venv_vig\Scripts\python.exe visual_report.py --config project.yaml --task vig
```

The command reads `paths.output_root` from the YAML, finds the VIG runs and prints the complete HTML path. Open that HTML in Edge, Chrome or Firefox. By default, it creates a timestamped file under `output_root/visual_reports/`. Rebuild after a run completes; an already-open report is a snapshot, not a live dashboard.

For a specific run:

```powershell
.\.venv_vig\Scripts\python.exe visual_report.py --run "C:/inspection/results/vig/RUN_ID"
```

For all runs in an output directory:

```powershell
.\.venv_vig\Scripts\python.exe visual_report.py --results "C:/inspection/results" --task vig
```

For two explicitly selected runs:

```powershell
.\.venv_vig\Scripts\python.exe visual_report.py --run "C:/inspection/results/vig/OLD_RUN_ID" --run "C:/inspection/results/vig/NEW_RUN_ID"
```

Replace example paths and IDs with existing run folders. Optional `--output "C:/inspection/reports/experiment_01.html"` chooses a new destination. Existing HTML files are not overwritten.

## Report contents

| Tab | Contents |
| --- | --- |
| Overview | Accuracy, bad recall, bad escape, good rejection, confusion matrix, dataset split counts, recorded threshold, confidence bound, existing final-test summary |
| Quality & errors | Precision–recall curve, ROC curve, score histograms and locations of error-image copies |
| Training & batches | Epoch loss, validation average precision, backbone learning rate, epoch duration; when recorded, batch-window throughput, mean batch time and sampled RAM/VRAM |
| Benchmarks & runs | Candidate/run comparison, data-comparability indicator, recorded scoring throughput, mean time per image and training cost |
| Threshold explorer | Hypothetical threshold decisions on the threshold split only; does not save or activate a new threshold |
| Records | Effective configuration, environment, missing-data notices and metric definitions |

Use the run selector at the top to avoid confusing an audit-only folder with a completed training run. Use the candidate selector to inspect alternatives; selection is not production approval. The Print / Save PDF button exports the current run's sections through the browser print dialog.

The archive includes `VISUAL_REPORT_DEMO.html`, generated entirely from synthetic test records. It demonstrates the interface, not model performance on inspection images.

## Configure laptop and workstation profiles

The correct project key is plural `profiles:`. Both profiles can exist under that one key. The command-line flag selects the profile; it does not automatically detect which computer is in use.

Create an additional configuration with both profiles while preserving current paths, labels, quality policy and preprocessing:

```powershell
.\.venv_vig\Scripts\python.exe configure_visual_profiles.py --config project.yaml
```

This writes `project.visual.yaml` beside the original configuration, so relative paths retain their meaning. It refuses to overwrite an existing `project.visual.yaml`. Edit that generated file for subsequent changes.

| Setting | Laptop | Workstation |
| --- | --- | --- |
| Device | CPU | CUDA |
| Models | ResNet18 | ResNet18, ResNet50, EfficientNet-B0, ConvNeXt-Tiny, Swin-T, PatchCore-style detector |
| Seeds | 42 | 42, 123 |
| Maximum epochs | 15 | 30 |
| Warmup epochs | 2 | 2 |
| Early-stopping patience | 5 | 7 |
| Microbatch size / evaluation batch size | 1 / 1 | 1 / 1 |
| Gradient accumulation | 4 | 16 |
| AMP | Disabled | Enabled for supported CUDA training |
| Ensembles | Disabled | Enabled |

The preset uses small microbatches because the project supports images above 600×600. This is a starting resource budget, not a guarantee that every architecture fits any GPU. Gradient accumulation changes the number of images per optimizer update; it does not make the whole dataset reside in GPU memory. Increasing the microbatch size can improve throughput when GPU memory permits. Task-level `training`, `models`, `device` and `seeds` overrides take precedence over profiles; the configuration helper prints a notice when these exist.

The workstation model roster is intentionally larger and can take considerably longer. For an initial GPU check, edit its `models` to `[resnet18]` and `seeds` to `[42]`, verify one run, and then enable the wider comparison. Do not enable `independent_units_confirmed` unless the unit grouping is actually valid. Profile selection does not establish production qualification.

On the workstation, create a new virtual environment and install a matched CUDA-enabled Torch/Torchvision pair compatible with the GPU/driver. The laptop's CPU wheel will not use the GPU. Confirm the device before a workstation run:

```powershell
python -c "import torch; print(torch.__version__); print(torch.cuda.is_available()); print(torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CUDA unavailable')"
```

In the following workstation commands, `python` means that workstation environment's interpreter. In PyCharm, select the new interpreter or use its complete executable path.

```powershell
python inspection.py download-weights --config project.visual.yaml --profile workstation --task vig
python inspection.py doctor --config project.visual.yaml --profile workstation --task vig
python inspection_observed.py run --config project.visual.yaml --profile workstation --task vig
```

Only `download-weights` requires network access to obtain public weights. Reports and training operate locally. Existing weights are reusable when the required model/weight files match.

## Train on the laptop with telemetry

```powershell
.\.venv_vig\Scripts\python.exe inspection_observed.py run --config project.visual.yaml --profile laptop --task vig
```

The runner delegates to the existing pipeline and wraps its training data-loader iteration in memory. It does not patch source files or alter the optimizer, loss, threshold selection, checkpoints, splits or model selection. A report is generated after the operation, including recorded partial results after handled interruption. The report path is printed in the terminal. Use `visual_report.py` afterward to compare this run with older runs.

New records are written under:

```text
results/<task>/<run>/models/<model>/visual_telemetry/<session>/batch_windows.csv
results/<task>/<run>/models/<model>/visual_telemetry/<session>/session.json
```

By default, one timing/memory row covers 25 completed training microbatches. For individual microbatch timing, append `--telemetry-every 1`. This introduces additional synchronization and logging overhead, particularly on CUDA. It does not add per-batch loss; loss remains recorded per epoch by the existing pipeline.

For an interrupted run:

```powershell
.\.venv_vig\Scripts\python.exe inspection_observed.py resume --run "C:/inspection/results/vig/RUN_ID"
```

Existing resume safeguards still apply. Each telemetry session has a separate folder. Repeated, interrupted epochs may appear in separate sessions; those sessions are not combined into a fictitious uninterrupted benchmark. Resume epoch labels use the last recorded progress; inspect the original operation log if interruption happened during checkpoint commitment.

## Measurement scope

- Epoch timings and losses come from existing `history.csv`; they work on earlier runs when that file exists.
- Scoring time is the original pipeline's measured selection pass, including its loading and preprocessing. Mean ms/image is an aggregate, not per-image latency or p95.
- Ensemble selection duration is the sum of member scoring durations. Model construction, checkpoint loading, cold starts and deployment runtime overhead are not included.
- Training-window timing includes fetching, preprocessing, transfer, forward, backward and optimizer work between window boundaries. Validation is excluded.
- CUDA is synchronized at the boundaries to avoid reporting unfinished GPU work. Timings include instrumentation effects and normal operating-system load.
- RAM is sampled main-process resident memory, excluding loader workers. CUDA allocated/reserved memory is sampled at the end of a window, not peak GPU use. CPU runs show GPU memory as unavailable, not zero.
- PatchCore fitting has no supervised epoch/batch telemetry in this add-on. Saved candidate metrics and selection timing remain available.
- Old per-batch timing, missing hardware records and unmeasured peak memory cannot be recovered retrospectively. Missing values are explicitly reported.
- Compare speed only when hardware, image resolution, preprocessing, batch size, precision and measurement scope match. No automated GPU speedup claim is made.

Timing references: [Python performance counter](https://docs.python.org/3/library/time.html#time.perf_counter) and [PyTorch CUDA synchronization](https://docs.pytorch.org/docs/2.10/generated/torch.cuda.synchronize.html).

## Quality and threshold interpretation

Bad is the positive event even though its stored label is 0. Bad escape means a truly bad image was accepted as good; good rejection means a truly good image was classified as bad. Average precision is the project's `pr_auc_bad` ranking measure, not accuracy.

The threshold explorer only uses saved scores from the labeled threshold split. It is a what-if view and cannot update the deployed operating point. It never loads test scores, predicts test images or changes `selected.json`. Official reports still describe the recorded threshold. Do not manually edit selected artifacts to simulate a new qualified release.

Cross-run data comparability uses the full identities, labels and groups of the selection records, ignoring absolute source paths. A matching signature establishes shared evaluation records, not identical training conditions or independence from development decisions. Selecting repeatedly against those same records can overfit them. Existing final-test results are displayed separately; no test is executed by this add-on.

## Validation

See `docs/VISUAL_VALIDATION.md` for the shipped test record and environment limitations. To run the add-on's logic tests in the installed project:

```powershell
.\.venv_vig\Scripts\python.exe -m unittest discover -s tests -p "test_visual_addon.py" -v
```

The tests generate temporary synthetic records. They do not use production images.

## Troubleshooting

- **No run config.json found:** use the actual `paths.output_root`, or provide one run using `--run`.
- **No candidate yet:** select a completed run. Audit-only folders do not contain accuracy results.
- **Source scores missing:** aggregate metrics still display, but ROC/PR/threshold plots require the original `scores/` and `manifest.csv` in that run.
- **No batch or RAM graphs:** use the observed runner for a new run. A normal `inspection.py run` records epoch-level data only.
- **No CUDA:** install the workstation's compatible CUDA-enabled environment before using `--profile workstation`.
- **Out of memory:** keep microbatch/evaluation batch size at 1, test one architecture, inspect resolution, and only change resizing after checking whether small defects remain visible.
- **Output already exists:** choose a new HTML filename or use the timestamped default.
- **Selected record changed:** retain the original run and inspect its integrity before relying on its metrics. This add-on does not repair or requalify modified model packages.
