@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\setup_export_windows.ps1" %*
set "STUDIO_EXIT=%ERRORLEVEL%"
echo.
pause
exit /b %STUDIO_EXIT%
