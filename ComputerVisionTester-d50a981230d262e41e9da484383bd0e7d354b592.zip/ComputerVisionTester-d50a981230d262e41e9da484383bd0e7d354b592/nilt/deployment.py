"""Export selected candidates to integrity-checked, runtime-only ONNX packages."""
from __future__ import annotations

from datetime import datetime, timezone
import importlib.metadata
import platform
import sys
from pathlib import Path
import shutil
import time
import zipfile

import numpy as np

from .common import read_json, sha_file, write_csv, write_json
from .runtime import PackageRunner, predict_package, safe_asset
from .image_io import intensity_settings


def parity_result(source_scores, exported_scores, threshold, atol=1e-5, rtol=1e-4, good_threshold=None):
    source = np.asarray(source_scores, dtype=float)
    exported = np.asarray(exported_scores, dtype=float)
    if source.ndim != 1 or source.shape != exported.shape or not len(source):
        raise ValueError("Parity requires equal nonempty one-dimensional score arrays.")
    finite = bool(np.isfinite(source).all() and np.isfinite(exported).all())
    if not finite:
        return {"status": "failed", "images": len(source), "reason": "Nonfinite source/export scores."}
    absolute = np.abs(source - exported)
    if threshold is not None and (not np.isscalar(threshold) or not np.isfinite(threshold)):
        raise ValueError("Threshold must be finite or None for scores-only parity.")
    decisions_changed = np.zeros(source.shape, dtype=bool) if threshold is None else (source >= threshold) != (exported >= threshold)
    if good_threshold is not None:
        if threshold is None or not np.isfinite(good_threshold) or not good_threshold < threshold:
            raise ValueError("Triage parity requires finite lower < upper thresholds.")
        source_classes = np.where(source < good_threshold, 0, np.where(source >= threshold, 2, 1))
        exported_classes = np.where(exported < good_threshold, 0, np.where(exported >= threshold, 2, 1))
        decisions_changed = source_classes != exported_classes
    close = np.isclose(source, exported, atol=atol, rtol=rtol)
    return {"status": "passed" if close.all() and not decisions_changed.any() else "failed",
            "images": len(source), "atol": float(atol), "rtol": float(rtol),
            "max_absolute_score_difference": float(absolute.max()),
            "mean_absolute_score_difference": float(absolute.mean()),
            "score_tolerance_failures": int((~close).sum()),
            "decision_mismatches": None if threshold is None else int(decisions_changed.sum()),
            "decision_comparison": "not_applicable" if threshold is None else "performed",
            "threshold": None if threshold is None else float(threshold),
            "good_threshold": None if good_threshold is None else float(good_threshold)}


def _validate_selection(rows):
    if not rows or any(r.get("split") != "selection" for r in rows):
        raise ValueError("ONNX parity validation requires reserved selection records only; final test is not used for export.")
    if len({r.get("pixel_hash", str(r["path"])) for r in rows}) != len(rows):
        raise ValueError("Duplicate images in export parity validation rows.")


def _versions():
    result = {"python": platform.python_version(), "platform": platform.platform()}
    for name in ("torch", "torchvision", "onnx", "onnxruntime", "numpy", "Pillow", "opencv-python-headless"):
        try:
            result[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            if name == "onnxruntime":
                # CPU and GPU wheels expose the same module under different
                # distribution names. The laptop requirements need its version.
                try:
                    import onnxruntime
                    result[name] = onnxruntime.__version__
                except ImportError:
                    result[name] = "not_installed"
            else:
                result[name] = "not_installed"
    return result


def export_package(run, output, kind="inference", format="onnx", validation_rows=None, decision=None,
                   include_predictions=False):
    """Export a run's selected candidate and validate numeric/decision parity.

    Artifacts are usable only after successful validation. CPU export validation is
    distinct from model quality qualification; exporting never activates a model.
    """
    if kind != "inference" or format != "onnx":
        raise ValueError("This exporter supports inference/onnx only. Use the training package command for checkpoints.")
    from .engine import load_checkpoint, predict_checkpoint, torch_modules
    from .workflow import open_run, verify_sources, load_selected, member_runtime_config

    run, output = Path(run).resolve(), Path(output).resolve()
    if output.is_relative_to(run) or run.is_relative_to(output):
        raise ValueError("Export output must be outside the immutable run and must not contain the run.")
    if output.exists() and (not output.is_dir() or any(output.iterdir())):
        failed = read_json(output / "export_validation.json") if output.is_dir() and (output / "export_validation.json").is_file() else {}
        if failed.get("status") == "failed" and failed.get("exporter") == "inspection-studio-onnx":
            backup = output.with_name(output.name + ".failed_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%f"))
            output.rename(backup)
        else:
            raise FileExistsError("Export output must be absent or empty. Choose a new folder for a previously completed or older failed export.")
    if output.with_name(output.name + ".zip").exists():
        raise FileExistsError("A model ZIP with this name already exists. Choose a new output folder.")
    cfg, manifest_rows = open_run(run)
    frozen_decision = None
    if decision is not None:
        from .decisions import load_decision
        frozen_decision, verified_run, cfg, selected = load_decision(decision, run_override=run)
        if verified_run != run:
            raise ValueError("Decision/run mismatch.")
        selected = {**selected, "threshold": frozen_decision["threshold"], "status": frozen_decision["qualification_status"]}
    else:
        selected = load_selected(run)
    rows = list(validation_rows) if validation_rows is not None else [r for r in manifest_rows if r["split"] == "selection"]
    _validate_selection(rows)
    manifest_ids = {(r.get("pixel_hash"), r.get("relative_path")) for r in manifest_rows if r["split"] == "selection"}
    if any((r.get("pixel_hash"), r.get("relative_path")) not in manifest_ids for r in rows):
        raise ValueError("Export validation rows must belong to the run's reserved selection manifest.")
    verify_sources(rows)
    threshold = None if frozen_decision and frozen_decision["mode"] == "scores_only" else float(selected["threshold"])
    good_threshold = float(frozen_decision["good_threshold"]) if frozen_decision and frozen_decision["mode"] == "triage" else None
    if threshold is not None and not np.isfinite(threshold):
        raise ValueError("Selected threshold must be finite for deployment.")
    torch, _ = torch_modules()
    from .export_support import export_dependencies
    onnx, _ = export_dependencies()
    output.mkdir(parents=True, exist_ok=True)
    write_json(output / "export_validation.json", {"status": "in_progress", "validated_providers": [], "exporter": "inspection-studio-onnx"})
    start = time.perf_counter()
    deployment_cfg = cfg.get("deployment", {})
    members = []
    source_member_scores = []
    try:
        for index, member in enumerate(selected["members"]):
            checkpoint = safe_asset(run, member["checkpoint"])
            if sha_file(checkpoint) != member["sha256"]:
                raise ValueError("Selected checkpoint checksum mismatch.")
            state = torch.load(checkpoint, map_location="cpu", weights_only=True)
            member_dir = output / "members" / f"{index:03d}"
            member_dir.mkdir(parents=True)
            onnx_path = member_dir / "model.onnx"
            kind_name = state.get("kind", member.get("kind", "supervised"))
            member_cfg = member_runtime_config(run, member, cfg)
            member_cfg["intensity"] = state.get("intensity", intensity_settings({}))
            if index == 0:
                export_intensity = intensity_settings(member_cfg)
            elif intensity_settings(member_cfg) != export_intensity:
                raise ValueError("ONNX score averaging requires identical fixed intensity conversion for every member.")
            source_scores, elapsed = predict_checkpoint(checkpoint, rows, member_cfg, device="cpu")
            source_member_scores.append(np.asarray(source_scores, dtype=float))
            item = {"architecture": member["architecture"], "kind": kind_name,
                    "image_strategy": state.get("image_strategy", "full_image"),
                    "mean": list(state.get("mean", [0.485, 0.456, 0.406])),
                    "std": list(state.get("std", [0.229, 0.224, 0.225])),
                    "source_checkpoint_sha256": member["sha256"],
                    "onnx": onnx_path.relative_to(output).as_posix(), "input_name": "images",
                    "source_validation_seconds": float(elapsed)}
            if kind_name == "patchcore":
                if len(selected["members"]) != 1:
                    raise ValueError("PatchCore scores cannot be averaged with supervised probabilities.")
                from .patchcore import load_patchcore
                loaded, state = load_patchcore(checkpoint, member_cfg, torch.device("cpu"))
                export_model = loaded.extractor.eval()
                bank_path = member_dir / "memory_bank.npy"
                bank = state["memory_bank"].detach().cpu().numpy().astype(np.float32)
                if bank.ndim != 2 or not len(bank) or not np.isfinite(bank).all():
                    raise ValueError("Invalid PatchCore memory bank.")
                np.save(bank_path, bank, allow_pickle=False)
                item.update(memory_bank=bank_path.relative_to(output).as_posix(), output_name="embedding",
                            scoring="max_patch_euclidean_1nn_unweighted", memory_bank_shape=list(bank.shape),
                            query_chunk=int(state.get("patchcore_settings", cfg.get("patchcore", {})).get("query_chunk_size", 256)),
                            bank_chunk=int(state.get("patchcore_settings", cfg.get("patchcore", {})).get("memory_chunk_size", 2048)))
            elif kind_name == "supervised":
                model, state = load_checkpoint(checkpoint, member_cfg, torch.device("cpu"))

                class BadScore(torch.nn.Module):
                    def __init__(self, model):
                        super().__init__()
                        self.model = model

                    def forward(self, images):
                        return torch.softmax(self.model(images).float(), dim=1)[:, 0]

                export_model = BadScore(model).eval()
                item["output_name"] = "bad_score"
            else:
                raise ValueError(f"Unsupported deployment member: {kind_name}")
            sample = torch.zeros(1, 3, int(cfg["image_size"]), int(cfg["image_size"]), dtype=torch.float32)
            # Explicit legacy exporter avoids default changes between Torch releases.
            # Fixed input geometry is intentional and stored in preprocessing.json.
            with torch.inference_mode():
                torch.onnx.export(export_model, sample, str(onnx_path), export_params=True,
                                  opset_version=int(deployment_cfg.get("opset", 17)), do_constant_folding=True,
                                  input_names=["images"], output_names=[item["output_name"]],
                                  dynamic_axes=None, dynamo=False, external_data=False)
            onnx.checker.check_model(str(onnx_path))
            # Runtime loading must not resolve external tensor paths outside the package.
            proto = onnx.load(str(onnx_path), load_external_data=False)
            if any(t.data_location == onnx.TensorProto.EXTERNAL for t in proto.graph.initializer):
                raise ValueError("Unexpected external ONNX weights; this exporter requires self-contained member graphs.")
            members.append(item)
            del export_model, sample
        score_type = selected.get("score_type") or ("anomaly_distance" if members[0]["kind"] == "patchcore" else "bad_probability_score")
        preprocessing = {"format_version": 1, "image_size": int(cfg["image_size"]), "resize": cfg["resize"],
                         "input_shape": [1, 3, int(cfg["image_size"]), int(cfg["image_size"])],
                         "input_dtype": "float32", "channel_order": "RGB", "tensor_layout": "NCHW",
                         "exif_transpose": True, "scale_divisor": 255.0, "intensity": export_intensity,
                         "supported_bit_depths": [8, 16], "mean": [0.485, 0.456, 0.406],
                         "std": [0.229, 0.224, 0.225], "padding_rgb": [124, 116, 104],
                         "resize_interpolation": "Pillow.BILINEAR", "unsupported_bit_depths": ["float", "signed_integer"],
                         "automatic_input_rescaling": False}
        write_json(output / "preprocessing.json", preprocessing)
        write_json(output / "decision_policy.json", {"format_version": 1, "class_to_index": {"bad": 0, "good": 1},
                   "mode": frozen_decision["mode"] if frozen_decision else "policy",
                   "threshold": threshold, "good_threshold": good_threshold, "bad_threshold": threshold,
                   "rule": ("scores_only" if threshold is None else "good_below_lower_bad_at_or_above_upper_otherwise_review" if good_threshold is not None else "bad_if_score_greater_equal_threshold"), "score_type": score_type,
                   "ensemble_rule": "arithmetic_mean_member_bad_scores" if len(members) > 1 else "single_member",
                   "quality_policy": selected.get("policy", cfg.get("policy", {}))})
        current_state = read_json(run / "model_state.json") if (run / "model_state.json").exists() else {}
        evaluation_path = current_state.get("last_evaluation")
        latest_evaluation = read_json(safe_asset(run, evaluation_path)) if evaluation_path and not frozen_decision else None
        metadata = {"format_version": 1, "created_utc": datetime.now(timezone.utc).isoformat(),
                    "task": cfg["task"], "model_version": run.name + "/" + selected["name"],
                    "roi_scope": cfg.get("roi_scope", "whole_image"),
                    "candidate_name": selected["name"], "members": members, "runtime_cpu_threads": int(cfg.get("cpu_threads", 4)),
                    "qualification_status": frozen_decision["qualification_status"] if frozen_decision else current_state.get("status", selected.get("status", "not_recorded")),
                    "selection_status": selected.get("status", "not_recorded"),
                    "profile": cfg.get("profile", "unspecified"),
                    "source_config_sha256": sha_file(run / "config.json"), "source_manifest_sha256": sha_file(run / "manifest.csv")}
        write_json(output / "package.json", metadata)
        # The compact policy is sufficient to reproduce decisions. Dataset paths,
        # original predictions and full decision/evaluation histories stay in the run.
        write_json(output / "model_metadata.json", {**metadata, "versions": _versions(),
                   "selection_metrics": selected.get("selection_metrics") if not frozen_decision else None,
                   "latest_evaluation": ({k: latest_evaluation[k] for k in ("status", "metrics") if k in latest_evaluation}
                                         if latest_evaluation else None),
                   "source_run_id": run.name,
                   "note": "Source/runtime parity is separate from defect detection qualification. No final test images are used for export validation."})
        # Temporary in-progress packages cannot be loaded by the normal verify=True runtime.
        runner = PackageRunner(output, device="cpu", verify=False)
        exported = np.asarray([runner.score(row["path"]) for row in rows], dtype=float)
        source = np.mean(source_member_scores, axis=0)
        atol = float(deployment_cfg.get("score_atol", 1e-5))
        rtol = float(deployment_cfg.get("score_rtol", 1e-4))
        if atol < 0 or rtol < 0:
            raise ValueError("Parity tolerances cannot be negative.")
        if int(deployment_cfg.get("max_decision_disagreements", 0)) != 0:
            raise ValueError("Deployment requires zero decision disagreements; relaxing this gate is unsupported.")
        result = parity_result(source, exported, threshold, atol, rtol, good_threshold=good_threshold)
        # Compare against original selection scores as well: relocating a GPU-trained
        # candidate must not conceal a change in threshold decisions on CPU.
        archived_scores = run / "scores" / selected["name"] / "selection.npy"
        if archived_scores.exists():
            archived_scores = safe_asset(run, archived_scores.relative_to(run).as_posix())
            original = np.load(archived_scores, allow_pickle=False)
            original_rows = [r for r in manifest_rows if r["split"] == "selection"]
            if original.shape != (len(original_rows),):
                raise ValueError("Archived selection score shape does not match manifest.")
            index_by_id = {(r.get("pixel_hash"), r.get("relative_path")): i for i, r in enumerate(original_rows)}
            original = np.asarray([original[index_by_id[(r.get("pixel_hash"), r.get("relative_path"))]] for r in rows])
            result["archived_selection_parity"] = parity_result(original, exported, threshold, atol, rtol, good_threshold=good_threshold)
            if result["archived_selection_parity"]["status"] != "passed":
                result["status"] = "failed"
        else:
            result["archived_selection_parity"] = {"status": "unavailable", "reason": "Original selection scores not found."}
        result.update(exporter="inspection-studio-onnx", validated_providers=["CPUExecutionProvider"] if result["status"] == "passed" else [],
                      unvalidated_providers=["CUDAExecutionProvider"], validation_split="selection",
                      source_device="cpu", source_precision="float32",
                      validation_scope="all_selection_records" if len(rows) == len(manifest_ids) else "selection_subset",
                      source_dataset_manifest_sha256=sha_file(run / "manifest.csv"),
                      versions=_versions(), elapsed_seconds=time.perf_counter() - start)
        write_json(output / "export_validation.json", result)
        if include_predictions or result["status"] != "passed":
            write_csv(output / "parity_predictions.csv", [{"relative_path": row["relative_path"], "pixel_hash": row["pixel_hash"],
                   "source_score": float(a), "onnx_score": float(b), "absolute_difference": float(abs(a - b)),
                   "source_class": runner.classify_score(a),
                   "onnx_class": runner.classify_score(b)}
                       for row, a, b in zip(rows, source, exported)])
        if result["status"] != "passed":
            raise RuntimeError("ONNX parity failed; inspect export_validation.json and parity_predictions.csv. No deployable package was qualified.")
        shutil.copy2(Path(__file__).with_name("runtime.py"), output / "runtime.py")
        shutil.copy2(Path(__file__).with_name("image_io.py"), output / "image_io.py")
        (output / "predict.py").write_text('from runtime import main\n\nif __name__ == "__main__":\n    raise SystemExit(main())\n', encoding="utf-8")
        versions = _versions()
        runtime_requirements = [f"{p}=={versions[p]}" for p in ("numpy", "Pillow", "onnxruntime")]
        runtime_requirements.append("opencv-python-headless>=4.10,<5" if versions["opencv-python-headless"] == "not_installed" else f"opencv-python-headless=={versions['opencv-python-headless']}")
        (output / "requirements-runtime.txt").write_text("\n".join(runtime_requirements) + "\n", encoding="utf-8")
        (output / "OPERATOR_GUIDE.md").write_text(
            "# Visual Inspection Deployment Package\n\n"
            f"Copy this entire folder. Use Python {sys.version_info.major}.{sys.version_info.minor} to match the validated export environment. "
            "NumPy, Pillow, OpenCV and ONNX Runtime are required. Install dependencies using `python -m pip install -r requirements-runtime.txt`. "
            "For offline installation, prepare compatible wheels on a connected machine and use `--no-index --find-links WHEEL_DIRECTORY`.\n\n"
            "The bundled runtime calls ONNX Runtime's disable_telemetry_events() immediately after importing it, before creating any inference session. "
            "This disables ONNX Runtime platform telemetry. Inference reads local files and does not download models or upload input images.\n\n"
            "Run from this folder: `python predict.py --input IMAGE_DIRECTORY --output NEW_OUTPUT_DIRECTORY --device cpu`. "
            "Add `--labeled` when the input has good and bad subfolders. Outputs include predictions.csv, inference_summary.json, "
            "and copied images in predicted/good, predicted/bad and predicted/review. Labeled inputs also generate error folders. "
            "Source images are never modified. Output must be empty and outside input and package folders.\n\n"
            "Input geometry and threshold are immutable package settings. A larger input is rejected for review under the pad policy; "
            "fit permits explicitly configured whole-image rescaling. Re-export a separately validated model for a different policy.\n\n"
            "CPU source/runtime parity is recorded in export_validation.json. It is not a production quality certification. "
            "CUDA requires onnxruntime-gpu instead of onnxruntime and compatible NVIDIA libraries; use `--device cuda` or `--device auto`. "
            "CUDA parity has not been validated by this package export and this is recorded in inference_summary.json. "
            "GPU execution may use CPU kernels for unsupported operators. Explicit GPU requests fail if CUDA initialization is unavailable.\n\n"
            "Preserve the accompanying training checkpoint separately for further training. This package is inference-only. "
            "Integrity hashes detect file changes, not authenticity; use only packages from a trusted source.\n", encoding="utf-8")
        files = {p.relative_to(output).as_posix(): sha_file(p) for p in sorted(output.rglob("*")) if p.is_file() and p.name != "integrity.json"}
        write_json(output / "integrity.json", {"algorithm": "sha256", "files": files})
        archive_package(output)
        return output
    except Exception as error:
        validation_file = output / "export_validation.json"
        current = read_json(validation_file) if validation_file.exists() else {}
        current.update(status="failed", error_type=type(error).__name__, error=str(error), validated_providers=[])
        write_json(validation_file, current)
        raise


def archive_package(output):
    """Archive only a verified, complete inference package; publish atomically."""
    from .runtime import verify_package
    output = Path(output).resolve()
    verify_package(output)
    archive = output.with_name(output.name + ".zip")
    if archive.exists():
        raise FileExistsError(f"Package ZIP already exists: {archive}")
    temporary = archive.with_suffix(".zip.tmp")
    try:
        with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED) as bundle:
            for path in sorted(output.rglob("*")):
                if path.is_file():
                    bundle.write(path, path.relative_to(output).as_posix())
        temporary.replace(archive)
    finally:
        temporary.unlink(missing_ok=True)
    return archive
