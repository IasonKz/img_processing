"""Dashboard routing and boundaries for cancellation and partial inference."""
from http.server import ThreadingHTTPServer
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from nilt.common import read_json, sha_file, write_json
from nilt.dashboard import Dashboard, make_handler


class DashboardExecutionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.input = self.root / "images"
        self.input.mkdir()
        config = self.root / "project.yaml"
        config.write_text("tasks:\n  vig:\n    enabled: true\n    dataset_root: ./images\n", encoding="utf-8")
        self.app = Dashboard(config)
        self.run = self.root / "results" / "vig" / "run1"
        write_json(self.run / "config.json", {"task": "vig", "models": ["resnet18"]})
        write_json(self.run / "search_status.json", {"status": "SEARCHING"})
        self.relative = "search/resnet18/trial_00000/partial.pt"
        self.checkpoint = self.run / self.relative
        self.checkpoint.parent.mkdir(parents=True)
        self.checkpoint.write_bytes(b"opaque committed checkpoint: command routing test")
        write_json(self.checkpoint.with_suffix(".json"), {
            "checkpoint": "partial.pt", "checkpoint_sha256": sha_file(self.checkpoint),
            "status": "PARTIAL", "usable_for_inference": True})

    def tearDown(self):
        self.temp.cleanup()

    def payload(self, **overrides):
        return {"run": str(self.run), "checkpoint": self.relative,
                "input": str(self.input), "output": str(self.root / "classified" / "preview"),
                "device": "directml:0", "threshold": .6, **overrides}

    def test_partial_command_requires_verified_snapshot_and_passes_explicit_paths(self):
        command = self.app.command("partial-predict", self.payload())
        self.assertIsInstance(command, list)
        self.assertEqual(command[command.index("--checkpoint") + 1], str(self.checkpoint.resolve()))
        self.assertEqual(command[command.index("--input") + 1], str(self.input.resolve()))
        self.assertEqual(command[command.index("--output") + 1], str(self.root / "classified" / "preview"))
        self.assertEqual(command[command.index("--device") + 1], "directml:0")
        self.assertEqual(command[command.index("--threshold") + 1], "0.6")

    def test_unverified_and_tampered_checkpoint_are_rejected(self):
        self.checkpoint.write_bytes(b"changed after commit")
        with self.assertRaisesRegex(ValueError, "verified partial"):
            self.app.command("partial-predict", self.payload())
        self.checkpoint.with_suffix(".json").unlink()
        with self.assertRaisesRegex(ValueError, "verified partial"):
            self.app.command("partial-predict", self.payload())

    def test_registry_cannot_authorize_path_escape(self):
        escaped = "../../outside.pt"
        with patch("nilt.partial_checkpoints.list_partial_checkpoints",
                   return_value=[{"checkpoint": escaped, "integrity_verified": True}]):
            with self.assertRaisesRegex(ValueError, "inside the selected experiment"):
                self.app.command("partial-predict", self.payload(checkpoint=escaped))

    def test_checkpoint_symlink_escape_is_rejected(self):
        outside = self.root / "outside.pt"
        outside.write_bytes(self.checkpoint.read_bytes())
        self.checkpoint.unlink()
        try:
            self.checkpoint.symlink_to(outside)
        except OSError:
            self.skipTest("Symlinks are unavailable for this account")
        with self.assertRaisesRegex(ValueError, "inside the selected experiment"):
            self.app.command("partial-predict", self.payload())

    def test_partial_input_output_threshold_and_device_validation(self):
        for overrides in ({"input": ""}, {"input": str(self.root / "missing")},
                          {"output": str(self.root / "unregistered")},
                          {"threshold": float("nan")}, {"threshold": -1},
                          {"device": "directml:garbage"}):
            with self.subTest(overrides=overrides), self.assertRaises(ValueError):
                self.app.command("partial-predict", self.payload(**overrides))

    def test_raw_anomaly_threshold_is_forwarded_for_checkpoint_specific_validation(self):
        command = self.app.command("partial-predict", self.payload(threshold=2.5))
        self.assertEqual(command[command.index("--threshold") + 1], "2.5")

    def test_cancel_writes_cooperative_cancel_instead_of_pause(self):
        job = {"status": "running", "action": "search", "run": str(self.run)}
        self.app.jobs.append(job)
        result = self.app.pause(cancel=True)
        self.assertEqual(read_json(self.run / "control.json"), {"action": "cancel", "stop": True})
        self.assertTrue(job["cancel_requested"])
        self.assertIn("Cancel requested", result["message"])

    def test_reopened_dashboard_can_cancel_recorded_active_search(self):
        self.app.pause(str(self.run), cancel=True)
        self.assertEqual(read_json(self.run / "control.json")["action"], "cancel")
        write_json(self.run / "search_status.json", {"status": "SEARCH_CANCELLED"})
        with self.assertRaisesRegex(ValueError, "no active search"):
            self.app.pause(str(self.run), cancel=True)

    def test_cancel_http_endpoint_requires_session_token_and_routes_cancel(self):
        server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(self.app))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        url = f"http://127.0.0.1:{server.server_port}/api/cancel"
        body = json.dumps({"run": str(self.run)}).encode()
        try:
            request = Request(url, data=body, headers={"Content-Type": "application/json"})
            with self.assertRaises(HTTPError) as raised:
                urlopen(request, timeout=5)
            self.assertEqual(raised.exception.code, 403)
            self.assertFalse((self.run / "control.json").exists())
            request = Request(url, data=body, headers={"Content-Type": "application/json", "X-Inspection-Token": self.app.token})
            with urlopen(request, timeout=5) as response:
                result = json.load(response)
            self.assertIn("Cancel requested", result["message"])
            self.assertEqual(read_json(self.run / "control.json")["action"], "cancel")
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=3)


if __name__ == "__main__":
    unittest.main()
