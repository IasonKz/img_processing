"""Unit cohort identity, recorded model evidence, native assets and report exports."""
from http.server import ThreadingHTTPServer
from io import BytesIO
import csv
import json
from pathlib import Path
import tempfile
import threading
import unittest
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from zipfile import ZipFile

import numpy as np
from PIL import Image

from nilt.common import read_json, write_json, sha_file
from nilt.deployment_review import build_review, read_index, read_unit, preview_asset, export_review, score_evidence
from nilt.inspection_identity import physical_unit, capture_view
from nilt.review import initialize_session, append_prediction, finish_session
from topseg.prediction_evidence import pixel_evidence


def inspection_fixture(root):
    root = Path(root)
    source = root / "incoming"
    run = root / "deployment" / "runs" / "inspection"
    for view in ("top", "bottom", "vig"):
        for i in range(1, 4):
            path = source / view / f"C00000083_Rc01Cc{i:02d}_{view}.png"
            path.parent.mkdir(parents=True, exist_ok=True)
            Image.fromarray((np.arange(96, dtype=np.uint16).reshape(8, 12) * 200 + i)).save(path)

    def session(path, view, scores, scope="whole_image"):
        initialize_session(path, metadata={"task": view, "roi_scope": scope, "candidate": "synthetic_model",
            "source_input": str(source / view), "decision_sha256": view[0] * 64,
            "good_threshold": .3, "bad_threshold": .7}, total=len(scores))
        for i, score in enumerate(scores, 1):
            original = source / view / f"C00000083_Rc01Cc{i:02d}_{view}.png"
            copy = path / "copies" / original.name
            copy.parent.mkdir(exist_ok=True)
            copy.write_bytes(original.read_bytes())
            append_prediction(path, {"relative_path": original.name, "copied_path": copy.relative_to(path).as_posix(),
                "file_sha256": sha_file(original), "status": "ok", "bad_score": score,
                "prediction": "good" if score < .3 else "bad" if score >= .7 else "review",
                "good_threshold": .3, "bad_threshold": .7, "score_type": "bad_probability_uncalibrated",
                "stage_results": [{"name": "first", "status": "ok", "score": score, "threshold": .7,
                                    "predicted_class": "bad" if score >= .7 else "good"},
                                  {"name": "unused", "status": "skipped", "score": None}]})
        finish_session(path, completed=len(scores))
        return path

    base = session(run / "sessions" / "vig", "vig", [.1, .5, .9])
    top = session(root / "classified" / "top", "top", [.2, .2, .2])
    bottom = session(root / "classified" / "bottom", "bottom", [.2, .2, .2])
    write_json(run / "report.json", {"status": "completed", "session": str(base), "input": str(source),
        "resolved_input": str(source), "pipeline": {"name": "Synthetic inspection", "models": [{"model": "synthetic_model"}]},
        "counts": {"good": 1, "bad": 1, "review": 1}, "pipeline_sha256": "f" * 64})
    prediction = root / "segmentation" / "top" / "results" / "predictions" / "synthetic"
    rows = []
    for i in range(1, 4):
        original = source / "top" / f"C00000083_Rc01Cc{i:02d}_top.png"
        image = prediction / "images" / original.name
        image.parent.mkdir(parents=True, exist_ok=True)
        image.write_bytes(original.read_bytes())
        mask = np.zeros((8, 12), dtype=np.uint8)
        mask[0, :i] = 1
        mask[1, :i] = 2
        mask_file = prediction / "masks" / original.name
        overlay_file = prediction / "overlays" / original.name
        mask_file.parent.mkdir(exist_ok=True); overlay_file.parent.mkdir(exist_ok=True)
        Image.fromarray(mask).save(mask_file)
        Image.fromarray(np.repeat((mask * 60)[:, :, None], 3, axis=2)).save(overlay_file)
        probabilities = np.full((3, 8, 12), .1, dtype=np.float32)
        for value in range(3):
            probabilities[value, mask == value] = .8
        rows.append({"image": original.name, "source_image": "images/" + original.name,
            "source_sha256": sha_file(original), "unit_id": f"C83:R1:C{i}", "tray": "C83",
            "width": 12, "height": 8, "inner_pixels": i, "outer_pixels": i,
            "mask": "masks/" + original.name, "overlay": "overlays/" + original.name,
            "pixel_evidence": pixel_evidence(probabilities, mask)})
    write_json(prediction / "summary.json", {"schema": "topseg_prediction_evidence.v1", "status": "completed",
        "task": "top", "roi_scope": "whole_image", "input_dir": str(source / "top"), "images": rows,
        "model_type": "synthetic_segmentation", "checkpoint_sha256": "c" * 64, "study_name": "synthetic", "trial": 0})
    return {"run": run, "input": source, "base": base, "top": top, "bottom": bottom,
            "segmentation": prediction / "summary.json"}


class DeploymentReviewTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.fixture = inspection_fixture(self.root)
        self.output = self.fixture["run"] / "quality_review" / "snapshots" / "test"

    def build(self, **extra):
        return build_review({"run": str(self.fixture["run"]), "sessions": [str(self.fixture["top"]), str(self.fixture["bottom"])],
            "segmentation": [str(self.fixture["segmentation"])], **extra}, self.output)

    def test_unit_views_masks_and_cohort_statistics_use_real_records(self):
        index = self.build()
        self.assertEqual(len(index["units"]), 3)
        self.assertEqual(index["counts"], {"good": 1, "review": 1, "bad": 1})
        row = next(row for row in index["units"] if row["unit_id"] == "C83:R1:C2")
        _, unit = read_unit(self.fixture["run"], row["id"])
        self.assertEqual(unit["coverage"], 3)
        self.assertEqual(unit["views"]["top"]["segmentation"], 1)
        metrics = [stat for stat in unit["statistics"] if index["distributions"][stat["distribution"]]["name"] == "BAD score"
                   and index["distributions"][stat["distribution"]]["view"] == "vig"]
        self.assertEqual(metrics[0]["percentile"], 50)
        self.assertEqual(metrics[0]["value"], .5)
        distribution = index["distributions"][metrics[0]["distribution"]]
        self.assertEqual(sum(bin["count"] for bin in distribution["bins"]), 3)
        mask = next(asset for asset in index["assets"].values() if asset["kind"] == "mask")
        with Image.open(BytesIO(preview_asset(self.fixture["run"], index, mask["id"]))) as image:
            self.assertEqual(image.mode, "RGB")
            colors = set(map(tuple, np.asarray(image).reshape(-1, 3)))
            self.assertIn((242, 97, 102), colors)
            self.assertIn((57, 173, 234), colors)

    def test_missing_views_are_previewed_but_never_promoted_to_good(self):
        index = build_review({"run": str(self.fixture["run"])}, self.output)
        self.assertEqual(index["counts"], {"review": 2, "bad": 1})
        _, unit = read_unit(self.fixture["run"], index["units"][0]["id"])
        self.assertEqual(unit["views"]["top"]["result"], "not_inspected")
        self.assertTrue(any(item["view"] == "top" and item["kind"] == "image" for item in unit["items"]))

    def test_roi_only_good_labels_do_not_certify_complete_view(self):
        marker = read_json(self.fixture["bottom"] / "review_session.json")
        marker["roi_scope"] = "pins"
        write_json(self.fixture["bottom"] / "review_session.json", marker)
        index = self.build()
        _, unit = read_unit(self.fixture["run"], index["units"][0]["id"])
        self.assertEqual(unit["review_status"], "review")
        self.assertEqual(unit["views"]["bottom"]["result"], "review")

    def test_scores_only_output_does_not_create_a_quality_decision(self):
        from nilt.review import read_records
        scores = self.root/'classified'/'top_scores'
        initialize_session(scores, metadata={'task': 'top', 'roi_scope': 'whole_image', 'mode': 'scores_only'}, total=3)
        for row in read_records(self.fixture['top']):
            copied = self.fixture['top']/row['copied_path']
            target = scores/row['copied_path'];target.parent.mkdir(exist_ok=True)
            target.write_bytes(copied.read_bytes())
            row.update(prediction=None, predicted_class=None)
            append_prediction(scores, row)
        finish_session(scores, completed=3)
        index = self.build(sessions=[str(scores), str(self.fixture['bottom'])])
        _, unit = read_unit(self.fixture['run'], index['units'][0]['id'])
        self.assertEqual(unit['views']['top']['result'], 'not_inspected')
        self.assertEqual(unit['coverage'], 2)
        self.assertEqual(unit['review_status'], 'review')

    def test_native_assets_remain_uint16_and_frozen_hashes_are_enforced(self):
        index = self.build()
        asset = next(asset for asset in index["assets"].values() if asset["kind"] == "source")
        path = self.fixture["run"] / asset["path"]
        with Image.open(path) as image:
            self.assertEqual(np.asarray(image).dtype, np.uint16)
        path.write_bytes(b"changed")
        with self.assertRaisesRegex(ValueError, "changed"):
            preview_asset(self.fixture["run"], index, asset["id"])

    def test_prediction_evidence_rejects_source_changes_after_model_inference(self):
        from topseg.prediction_evidence import capture_evidence
        source = next((self.fixture['input']/'top').glob('*.png'))
        digest = sha_file(source)
        with Image.open(source) as image:
            shape = (image.height, image.width)
        source.write_bytes(b'changed during inference')
        output = self.root/'prediction_changed';output.mkdir()
        mask = np.zeros(shape, np.uint8)
        probabilities = np.full((3, *shape), 1/3, np.float32)
        with self.assertRaisesRegex(ValueError, 'changed during inference'):
            capture_evidence(source.parent, source, output, mask, probabilities, {}, expected=digest)

    def test_mask_count_conflict_is_visible_and_excluded_from_distributions(self):
        summary = read_json(self.fixture["segmentation"])
        summary["images"][0]["inner_pixels"] = 999
        write_json(self.fixture["segmentation"], summary)
        index = self.build()
        _, unit = read_unit(self.fixture["run"], index["units"][0]["id"])
        item = next(item for item in unit["items"] if item["kind"] == "segmentation")
        self.assertEqual(item["status"], "unavailable")
        self.assertIn("disagree", item["issues"][0])

    def test_segmentation_failures_are_routed_for_review_on_the_affected_unit(self):
        summary = read_json(self.fixture['segmentation'])
        summary['images'] = summary['images'][1:]
        summary['failures'] = [{'image': 'C00000083_Rc01Cc01_top.png', 'error': 'Synthetic read failure'}]
        write_json(self.fixture['segmentation'], summary)
        index = self.build()
        row = next(row for row in index['units'] if row['unit_id'] == 'C83:R1:C1')
        _, unit = read_unit(self.fixture['run'], row['id'])
        self.assertEqual(unit['review_status'], 'review')
        self.assertEqual(unit['views']['top']['result'], 'review')
        self.assertTrue(any('Synthetic read failure' in message for message in unit['issues']))

    def test_cancelled_rebuild_retains_current_snapshot(self):
        self.build()
        marker = (self.fixture["run"] / "quality_review" / "current.json").read_bytes()
        with self.assertRaises(InterruptedError):
            build_review({"run": str(self.fixture["run"])}, self.output.with_name("cancelled"), stop_check=lambda: True)
        self.assertEqual((self.fixture["run"] / "quality_review" / "current.json").read_bytes(), marker)

    def test_index_and_unit_tampering_are_rejected(self):
        index = self.build()
        unit = self.output / index["units"][0]["path"]
        unit.write_text("{}")
        with self.assertRaisesRegex(ValueError, "changed"):
            read_unit(self.fixture["run"], index["units"][0]["id"])
        (self.output / "index.json").write_text("{}")
        with self.assertRaisesRegex(ValueError, "changed"):
            read_index(self.fixture["run"])

    def test_single_unit_export_is_portable_and_contains_native_evidence(self):
        index = self.build()
        unit = index["units"][0]
        output = self.fixture["run"] / "quality_review" / "reports" / "selected"
        result = export_review({"run": str(self.fixture["run"]), "units": [unit["id"]]}, output)
        self.assertEqual(result["units"], 1)
        report = (output / "units" / (unit["id"] + ".html")).read_text()
        self.assertIn("data:image/png;base64,", report)
        self.assertIn("C83:R1:C1", report)
        with ZipFile(output / "reports.zip") as archive:
            self.assertIsNone(archive.testzip())
            self.assertIn("evidence.json", archive.namelist())
            evidence = json.loads(archive.read("evidence.json"))
            self.assertEqual(len(evidence["units"]), 1)
            for asset in evidence["assets"].values():
                self.assertIn(asset["path"], archive.namelist())
            self.assertTrue(any(asset["kind"] == "mask" for asset in evidence["assets"].values()))
        self.assertEqual(read_index(self.fixture["run"])[1]["snapshot"], index["snapshot"])

    def test_batch_export_without_images_contains_all_units_and_csv(self):
        self.build()
        output = self.fixture["run"] / "quality_review" / "reports" / "batch"
        result = export_review({"run": str(self.fixture["run"]), "include_images": False}, output)
        self.assertEqual(result["units"], 3)
        with (output / "units.csv").open(encoding="utf-8-sig", newline="") as stream:
            rows = list(csv.DictReader(stream))
        self.assertEqual(len(rows), 9)
        self.assertNotIn("<img", next((output / "units").glob("*.html")).read_text())

    def test_unit_identity_and_view_conflicts_are_not_silently_joined(self):
        self.assertEqual(physical_unit("C00000083_Rc01Cc02_ViTopFinal.png")["unit_id"], "C83:R1:C2")
        self.assertEqual(physical_unit("hash__pin.png", "C83_R1_C2")["unit_id"], "C83:R1:C2")
        self.assertNotEqual(physical_unit("image.png", origin="one"), physical_unit("image.png", origin="two"))
        self.assertEqual(capture_view("bottom/C00000083_Rc01Cc02_ViBottomPostTarget.png"), "bottom")
        with self.assertRaises(ValueError):
            capture_view("top/C00000083_Rc01Cc02_vig.png")

    def test_agreement_uses_only_recorded_evaluated_votes(self):
        result = score_evidence({"prediction": "good", "bad_score": .2, "threshold": .5,
            "stage_results": [{"status": "evaluated", "predicted_class": "good"},
                              {"status": "evaluated"}, {"status": "skipped", "predicted_class": "good"}]}, {})
        self.assertEqual(result["stage_agreement"], {"agreeing": 1, "decisions": 1, "evaluated": 2, "skipped": 1})
        self.assertAlmostEqual(result["decision_margin"], .3)

    def test_multiple_captures_contribute_one_worst_value_per_physical_unit(self):
        from nilt.deployment_review import add_distributions
        items = []
        for value in (.1, .4):
            items.append({"view": "vig", "scope": "whole_image", "kind": "classification", "status": "ok",
                "pipeline": {"decision_sha256": "d" * 64}, "evidence": {"score": value, "bad_threshold": .7}})
        units = {"one": {"items": items, "statistics": []},
                 "two": {"items": [dict(items[0], evidence={"score": .6, "bad_threshold": .7})], "statistics": []}}
        distributions = add_distributions(units)
        self.assertEqual(len(distributions), 1)
        self.assertEqual(next(iter(distributions.values()))['units'], 2)
        self.assertEqual(units['one']['statistics'][0]['value'], .4)
        units['two']['items'][0]['evidence']['bad_threshold'] = .8
        self.assertEqual(len(add_distributions(units)), 2)

    def test_unmatched_segmentation_units_do_not_copy_images_or_join_the_cohort(self):
        summary = read_json(self.fixture['segmentation'])
        summary['images'] = [dict(summary['images'][0], unit_id='C99:R1:C9', image='unmatched_crop.png')]
        write_json(self.fixture['segmentation'], summary)
        index = build_review({'run': str(self.fixture['run']), 'segmentation': [str(self.fixture['segmentation'])]}, self.output)
        self.assertEqual(len(index['units']), 3)
        self.assertFalse(any(asset['kind'] in ('mask', 'overlay') for asset in index['assets'].values()))
        self.assertTrue(any('No units' in issue for issue in index['issues']))


class DeploymentReviewHTTPTests(unittest.TestCase):
    def setUp(self):
        from nilt.dashboard import Dashboard, make_handler
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.fixture = inspection_fixture(self.root)
        self.config = self.root / "project.yaml"
        self.config.write_text("tasks:\n  vig:\n    dataset_root: ./incoming/vig\n", encoding="utf-8")
        self.app = Dashboard(self.config)
        self.output = self.fixture["run"] / "quality_review" / "snapshots" / "http"
        build_review({"run": str(self.fixture["run"]), "segmentation": [str(self.fixture["segmentation"])]}, self.output)
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(self.app))
        self.worker = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.worker.start()
        self.base = f"http://127.0.0.1:{self.server.server_port}"

    def tearDown(self):
        self.server.shutdown(); self.server.server_close(); self.worker.join(timeout=2)
        self.temp.cleanup()

    def test_real_catalog_unit_preview_and_containment(self):
        from urllib.parse import urlencode
        with urlopen(self.base + "/api/deployment/quality/catalog") as response:
            catalog = json.load(response)
        self.assertTrue(catalog["runs"][0]["review_ready"])
        query = urlencode({"run": str(self.fixture["run"])})
        with urlopen(self.base + "/api/deployment/quality?" + query) as response:
            detail = json.load(response)
        with urlopen(self.base + "/api/deployment/quality/unit?" + query + "&unit=" + detail["units"][0]["id"]) as response:
            unit = json.load(response)
        for asset in unit["assets"].values():
            with urlopen(self.base + asset["preview_url"]) as response:
                self.assertEqual(response.headers.get_content_type(), "image/png")
                self.assertTrue(response.read().startswith(b"\x89PNG"))
        with self.assertRaises(HTTPError) as error:
            urlopen(self.base + "/api/deployment/quality?run=" + str(self.root))
        self.assertEqual(error.exception.code, 400)
        with self.assertRaises(HTTPError):
            urlopen(self.base + "/api/deployment/quality/image?" + query + "&asset=../../project.yaml")

    def test_export_request_requires_token_and_valid_units(self):
        request = Request(self.base + "/api/action", data=json.dumps({"action": "deployment-quality-export", "run": str(self.fixture["run"])}).encode(), headers={"Content-Type": "application/json"})
        with self.assertRaises(HTTPError) as error:
            urlopen(request)
        self.assertEqual(error.exception.code, 403)
        with self.assertRaises(ValueError):
            self.app.deployment_quality_request({"run": str(self.fixture["run"]), "units": ["wrong"]}, export=True)
        request, output = self.app.deployment_quality_request({"run": str(self.fixture["run"])}, export=True)
        self.assertTrue(output.is_relative_to(self.fixture["run"] / "quality_review" / "reports"))
        self.assertEqual(request["snapshot"], "http")

    def test_cached_index_invalidates_on_content_change(self):
        self.app.deployment_quality_detail({'run': str(self.fixture['run'])})
        path = self.output/'index.json'
        previous = path.stat()
        path.write_text('{}')
        import os
        os.utime(path, ns=(previous.st_atime_ns, previous.st_mtime_ns))
        with self.assertRaisesRegex(ValueError, 'changed'):
            self.app.deployment_quality_detail({'run': str(self.fixture['run'])})


if __name__ == "__main__":
    unittest.main()
