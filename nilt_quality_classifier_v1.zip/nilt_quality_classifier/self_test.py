from __future__ import annotations

import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

from qc.data import ImageRecord, canonicalize_unit_id, stratified_group_split
from qc.ground_truth import load_ground_truth
from qc.metrics import choose_safety_threshold


def main() -> None:
    assert canonicalize_unit_id("C00000083-Rc01Cc02") == "C00000083RC01CC02"
    assert canonicalize_unit_id("C00000083_Rc01Cc02") == "C00000083RC01CC02"

    records = [
        ImageRecord(path=f"good_{i}.bmp", label=0, group=f"GOOD{i}") for i in range(10)
    ] + [ImageRecord(path=f"bad_{i}.bmp", label=1, group=f"BAD{i}") for i in range(5)]
    split = stratified_group_split(
        records, validation_fraction=0.2, test_fraction=0.2, seed=42
    )
    group_to_split = {}
    for record in split:
        group_to_split.setdefault(record.group, record.split)
        assert group_to_split[record.group] == record.split

    y_true = np.array([0, 0, 0, 1, 1, 1])
    p_bad = np.array([0.01, 0.10, 0.40, 0.30, 0.70, 0.95])
    threshold, metrics, _ = choose_safety_threshold(
        y_true, p_bad, target_bad_recall=1.0, steps=1001
    )
    assert metrics["false_pass"] == 0
    assert threshold <= 0.30 + 1e-9

    with tempfile.TemporaryDirectory() as temporary:
        csv_path = Path(temporary) / "truth.csv"
        pd.DataFrame(
            {
                "Unit Identifier": ["C00000083-Rc01Cc01", "C00000083-Rc01Cc02"],
                "EvaluationTimestamp": ["20260904T100000", "20260904T100100"],
                "Quality_VI_Bottom_Label": ["p", "f"],
            }
        ).to_csv(csv_path, sep=";", index=False)
        truth, _ = load_ground_truth(
            csv_path,
            {
                "separator": ";",
                "unit_id_column": "Unit Identifier",
                "timestamp_column": "EvaluationTimestamp",
                "label_columns": ["Quality_VI_Bottom_Label"],
                "combine": "single",
                "good_values": ["p"],
                "bad_values": ["f"],
            },
        )
        assert truth["true_label"].tolist() == ["good", "bad"]

    print("Self-test passed.")


if __name__ == "__main__":
    main()
