"""Loopback-only operator dashboard. No cloud services, uploads, or shell commands.

The dashboard starts the same CLI as a terminal. Experiment logic lives in the
workflow modules; this module only supervises jobs and presents recorded data.
"""
from __future__ import annotations

import csv
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import math
import mimetypes
import os
from pathlib import Path
import secrets
import subprocess
import sys
import threading
import time
from urllib.parse import parse_qs, unquote, urlparse
import webbrowser

PROFILE_HOURS = {"laptop": 2, "workstation": 6, "workstation_large": 12}
MODELS = ("resnet18", "resnet50", "efficientnet_b0", "convnext_tiny", "swin_t", "patchcore")
MODES = ("policy", "manual", "argmax", "scores_only")
STATIC = Path(__file__).with_name("ui")
PROJECT = Path(__file__).resolve().parent.parent


def _read_json(path, default=None):
    try:
        if Path(path).is_symlink():
            return default
        with Path(path).open(encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return default


def _read_csv(path, limit=10000):
    try:
        if Path(path).is_symlink():
            return []
        with Path(path).open(encoding="utf-8-sig", newline="") as handle:
            result = []
            for i, row in enumerate(csv.DictReader(handle)):
                if i >= limit:
                    break
                result.append(row)
            return result
    except (OSError, ValueError):
        return []


def _clean_json(value):
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, dict):
        return {str(k): _clean_json(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_clean_json(v) for v in value]
    return value


def _safe_path(root, relative):
    """Resolve symlinks before checking containment (also handles Windows)."""
    root = Path(root).resolve()
    path = (root / relative).resolve()
    if not path.is_relative_to(root):
        raise ValueError("Path is outside its configured root.")
    return path


class Dashboard:
    def __init__(self, config):
        self.config = Path(config).resolve()
        self.token = secrets.token_urlsafe(32)
        self.lock = threading.RLock()
        self.jobs = []
        self.output_roots = []
        self.data_roots = []
        self._load_config()

    def _load_config(self):
        import yaml
        with self.config.open(encoding="utf-8-sig") as handle:
            self.raw = yaml.safe_load(handle)
        if not isinstance(self.raw, dict):
            raise ValueError("Project configuration must be a YAML mapping.")
        paths = self.raw.get("paths", {})
        for key, fallback in (("output_root", "results"), ("classification_output_root", "classified")):
            root = self._configured_path(paths.get(key, fallback))
            if root not in self.output_roots:
                self.output_roots.append(root)
        for folder in ("decisions", "packages", "dashboard_logs"):
            root = self.config.parent / folder
            if root not in self.output_roots:
                self.output_roots.append(root)
        for cfg in self.raw.get("tasks", {}).values():
            if isinstance(cfg, dict) and cfg.get("dataset_root"):
                root = self._configured_path(cfg["dataset_root"])
                if root not in self.data_roots:
                    self.data_roots.append(root)

    def _configured_path(self, value):
        path = Path(value).expanduser()
        return (path if path.is_absolute() else self.config.parent / path).resolve()

    def checked_output(self, value, exists=False):
        path = Path(value).expanduser().resolve()
        if not any(path.is_relative_to(root.resolve()) for root in self.output_roots):
            raise ValueError("Choose a path inside the configured results, decisions, classified or packages folders.")
        if exists and not path.exists():
            raise ValueError("The selected path does not exist.")
        return path

    def run_path(self, value):
        run = self.checked_output(value, exists=True)
        if not any((run / name).is_file() for name in ("config.json", "model_state.json", "search_status.json")):
            raise ValueError("Choose a recorded experiment folder.")
        return run

    def bootstrap(self):
        paths = self.raw.get("paths", {})
        return {"token": self.token, "config": str(self.config), "profiles": PROFILE_HOURS,
                "profile_models": {profile: self.raw.get("profiles", {}).get(profile, {}).get("models",
                                   self.raw.get("defaults", {}).get("models", ["resnet18"] if profile == "laptop" else list(MODELS)))
                                   for profile in PROFILE_HOURS},
                "task_models": {name: cfg["models"] for name, cfg in self.raw.get("tasks", {}).items()
                                if isinstance(cfg, dict) and cfg.get("models")},
                "models": MODELS, "tasks": list(self.raw.get("tasks", {"vig": {}})),
                "task_enabled": {name: cfg.get("enabled", True) for name, cfg in self.raw.get("tasks", {}).items()
                                 if isinstance(cfg, dict)},
                "datasets": {name: str(self._configured_path(cfg["dataset_root"]))
                             for name, cfg in self.raw.get("tasks", {}).items()
                             if isinstance(cfg, dict) and cfg.get("dataset_root")},
                "paths": {"output": str(self._configured_path(paths.get("output_root", "results"))),
                          "weights": str(self._configured_path(paths.get("weights_root", "weights"))),
                          "incoming": str(self._configured_path(paths.get("incoming_root", "incoming"))),
                          "classified": str(self._configured_path(paths.get("classification_output_root", "classified"))),
                          "decisions": str(self.config.parent / "decisions"),
                          "packages": str(self.config.parent / "packages")},
                "offline": True}

    def save_config(self, data):
        """Write a new snapshot; never rewrite the user's configuration."""
        import copy
        import yaml
        raw = copy.deepcopy(self.raw)
        for key in ("output_root", "weights_root", "incoming_root", "classification_output_root"):
            if key in raw.get("paths", {}):
                raw["paths"][key] = str(self._configured_path(raw["paths"][key]))
        for cfg in raw.get("tasks", {}).values():
            for key in ("dataset_root", "groups_csv", "previous_run"):
                if cfg.get(key):
                    cfg[key] = str(self._configured_path(cfg[key]))
        task = data.get("task", "vig")
        if task not in raw.get("tasks", {}):
            raise ValueError("Unknown task.")
        dataset = Path(str(data.get("dataset", ""))).expanduser().resolve()
        if not str(data.get("dataset", "")).strip() or not dataset.is_dir():
            raise ValueError("Dataset folder must exist on this computer.")
        raw["tasks"][task]["dataset_root"] = str(dataset)
        raw["tasks"][task]["enabled"] = True
        for field, key in (("output", "output_root"), ("weights", "weights_root")):
            if data.get(field):
                value = Path(data[field]).expanduser().resolve()
                if field == "output" and (value.is_relative_to(dataset) or dataset.is_relative_to(value)):
                    raise ValueError("Results and dataset folders must not overlap.")
                raw.setdefault("paths", {})[key] = str(value)
        # Same directory preserves any less common configuration-relative fields.
        target = self.config.parent / ("project.dashboard." + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%f") + ".yaml")
        with target.open("x", encoding="utf-8") as handle:
            yaml.safe_dump(raw, handle, sort_keys=False)
        self.config = target
        self._load_config()
        return self.bootstrap()

    def command(self, action, data):
        command = [sys.executable, "-u", str(PROJECT / "inspection.py")]
        if action in ("doctor", "audit", "search"):
            task, profile = data.get("task", "vig"), data.get("profile", "laptop")
            if profile not in PROFILE_HOURS or task not in self.raw.get("tasks", {}):
                raise ValueError("Unknown profile or task.")
            command += [action, "--config", str(self.config), "--profile", profile, "--task", task]
            if action == "search":
                models = data.get("models", [])
                if not isinstance(models, list) or not models or any(m not in MODELS for m in models):
                    raise ValueError("Select at least one supported model.")
                hours = float(data.get("hours", PROFILE_HOURS[profile]))
                if not math.isfinite(hours) or not 0 < hours <= PROFILE_HOURS[profile]:
                    raise ValueError("Time budget must be positive and within this profile's limit.")
                command += ["--models", *dict.fromkeys(models), "--hours", str(hours)]
        elif action in ("finalize-search", "status", "report", "resume-search"):
            run = self.run_path(data.get("run", ""))
            command += ["search" if action == "resume-search" else action, "--run", str(run)]
        elif action == "decision":
            run = self.run_path(data.get("run", ""))
            mode = data.get("mode", "policy")
            if mode not in MODES:
                raise ValueError("Unknown decision mode.")
            candidate = str(data.get("candidate", "selected"))
            if candidate != "selected":
                candidates = _read_json(run / "candidates.json", [])
                if candidate not in {c["name"] for c in candidates}:
                    raise ValueError("Unknown candidate.")
            target = self.checked_output(data.get("output", self.config.parent / "decisions"))
            command += ["decision", "--run", str(run), "--mode", mode,
                        "--candidate", candidate, "--output-root", str(target)]
            if mode == "manual":
                value = float(data.get("threshold", "nan"))
                if not math.isfinite(value):
                    raise ValueError("A manual threshold must be finite.")
                command += ["--threshold", str(value)]
        elif action == "classify":
            decision = self.checked_output(data.get("decision", ""), exists=True)
            if decision.name != "decision.json":
                raise ValueError("Select a saved decision.json.")
            input_dir = Path(str(data.get("input", ""))).expanduser().resolve()
            if not str(data.get("input", "")).strip() or not input_dir.is_dir():
                raise ValueError("Input image folder does not exist.")
            output = self.checked_output(data.get("output", ""))
            device = data.get("device", "cpu")
            if device not in ("cpu", "cuda", "auto"):
                raise ValueError("Unknown device.")
            command += ["classify", "--decision", str(decision), "--input", str(input_dir),
                        "--output-root", str(output), "--device", device]
            if data.get("labeled"):
                command.append("--labeled")
            if data.get("copy_images", True):
                command.append("--copy-images")
        elif action in ("export", "package"):
            run = self.run_path(data.get("run", ""))
            output = self.checked_output(data.get("output", ""))
            command += [action, "--run", str(run), "--output", str(output)]
            if action == "export":
                command += ["--candidate", "selected"]
            else:
                kind = data.get("kind", "inference")
                if kind not in ("inference", "training"):
                    raise ValueError("Unknown package kind.")
                command += ["--kind", kind]
                if data.get("decision"):
                    if kind != "inference":
                        raise ValueError("Saved decision overrides apply to inference packages only.")
                    decision = self.checked_output(data["decision"], exists=True)
                    if decision.name != "decision.json":
                        raise ValueError("Choose a saved decision.json.")
                    command += ["--decision", str(decision)]
        else:
            raise ValueError("Unsupported dashboard action.")
        return command

    def start(self, action, data):
        command = self.command(action, data)
        with self.lock:
            if any(j["status"] == "running" for j in self.jobs):
                raise ValueError("A job is already running. Wait or pause the search first.")
            root = self.config.parent / "dashboard_logs"
            root.mkdir(exist_ok=True)
            job_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%f")
            job = {"id": job_id, "action": action, "status": "running", "started": time.time(),
                   "command": command, "lines": [], "run": data.get("run"),
                   "log": str(root / (job_id + ".log"))}
            kwargs = {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt" else {"start_new_session": True}
            # A real file (not a pipe owned by this server) lets workers continue
            # safely if the dashboard is closed while training is running.
            with open(job["log"], "w", encoding="utf-8") as output:
                process = subprocess.Popen(command, cwd=str(PROJECT), stdout=output,
                                           stderr=subprocess.STDOUT,
                                           env={**os.environ, "PYTHONUNBUFFERED": "1"}, **kwargs)
            job["pid"] = process.pid
            self.jobs.append(job)
            threading.Thread(target=self._capture, args=(job, process), daemon=True).start()
            return {"job": job_id}

    def _capture(self, job, process):
        with open(job["log"], encoding="utf-8", errors="replace") as output:
            while True:
                line = output.readline()
                if not line:
                    if process.poll() is not None:
                        break
                    time.sleep(.2)
                    continue
                with self.lock:
                    job["lines"].append(line.rstrip())
                    del job["lines"][:-1000]
                    if line.startswith("RUN:"):
                        try:
                            job["run"] = str(self.checked_output(line[4:].strip()))
                        except ValueError:
                            pass
            code = process.wait()
        with self.lock:
            job.update(status="finished" if code == 0 else "failed", exit_code=code, finished=time.time())

    def pause(self, selected_run=None):
        with self.lock:
            job = next((j for j in reversed(self.jobs) if j["status"] == "running"), None)
            if job and (job["action"] not in ("search", "resume-search") or not job.get("run")):
                raise ValueError("A search must finish preparing its run before it can be paused.")
            if not job and not selected_run:
                raise ValueError("Choose an active search to pause.")
            run = self.run_path(job["run"] if job else selected_run)
            if not job:
                status = _read_json(run / "search_status.json", {}).get("status")
                if status not in ("SEARCHING", "SELECTING", "SEARCH_CONFIRMING"):
                    raise ValueError("The selected experiment has no active search to pause.")
            target = run / "control.json"
            temp = target.with_suffix(".dashboard.tmp")
            temp.write_text(json.dumps({"action": "pause", "stop": True}), encoding="utf-8")
            os.replace(temp, target)
            if job:
                job["pause_requested"] = True
        return {"message": "Pause requested. The worker will stop at a safe checkpoint boundary."}

    def runs(self):
        paths = set()
        for root in self.output_roots:
            # Known layout: output_root / task / run. No recursive dataset scan.
            for pattern in ("*/config.json", "*/*/config.json", "*/model_state.json", "*/*/model_state.json"):
                for path in root.glob(pattern):
                    resolved = path.parent.resolve()
                    if resolved.is_relative_to(root.resolve()):
                        paths.add(resolved)
        result = []
        for run in sorted(paths, key=lambda p: p.name, reverse=True)[:100]:
            state = _read_json(run / "model_state.json", {})
            cfg = _read_json(run / "config.json", {})
            search = _read_json(run / "search_status.json", {})
            result.append({"path": str(run), "name": run.name, "task": cfg.get("task", state.get("task")),
                           "profile": cfg.get("profile"), "status": search.get("status", state.get("status", "UNKNOWN"))})
        return result

    def file_url(self, path):
        from urllib.parse import quote
        path = Path(path).resolve()
        for index, root in enumerate(self.output_roots):
            if path.is_relative_to(root.resolve()):
                return "/results/" + str(index) + "/" + quote(path.relative_to(root.resolve()).as_posix(), safe="/")
        raise ValueError("Result file is outside configured roots.")

    def run_info(self, value):
        run = self.run_path(value)
        histories = []
        folders = set()
        for pattern in ("models/*/history.csv", "search/*/trial_*/history.csv",
                        "search/confirmations/*/seed_*/history.csv", "models/*/progress.json",
                        "search/*/trial_*/progress.json", "search/confirmations/*/seed_*/progress.json"):
            for path in sorted(run.glob(pattern))[-200:]:
                if not path.resolve().is_relative_to(run):
                    continue
                folders.add(path.parent)
        for folder in sorted(folders):
            progress_path = folder / "progress.json"
            histories.append({"name": folder.relative_to(run).as_posix(),
                              "history": _read_csv(folder / "history.csv", 2000),
                              "progress": _read_json(progress_path, {}),
                              "updated": progress_path.stat().st_mtime if progress_path.exists() else 0})
        reports = []
        for pattern in ("*.html", "visual_reports/*.html", "inspection_reports/*.html"):
            for path in run.glob(pattern):
                if path.resolve().is_relative_to(run):
                    reports.append({"name": path.relative_to(run).as_posix(), "url": self.file_url(path)})
        return {"path": str(run), "state": _read_json(run / "model_state.json", {}),
                "search": _read_json(run / "search_status.json", {}),
                "trials": _read_csv(run / "trials.csv"), "histories": histories,
                "candidates": _read_json(run / "candidates.json", []),
                "selected": _read_json(run / "selected.json", {}),
                "splits": _read_json(run / "split_summary.json", {}),
                "audit": _read_json(run / "audit" / "audit_summary.json", {}),
                "reports": reports}

    def decisions(self):
        items = []
        for root in self.output_roots:
            for path in root.glob("*/decision.json"):
                if not path.resolve().is_relative_to(root.resolve()):
                    continue
                data = _read_json(path, {})
                if data.get("mode") in MODES:
                    candidate = data.get("candidate", {})
                    reference = data.get("run_reference", {})
                    source_run = ((path.parent / reference["path"]).resolve()
                                  if reference.get("kind") == "relative" else Path(reference["path"]).resolve()
                                  if reference.get("path") else None)
                    items.append({"path": str(path), "mode": data["mode"], "threshold": data.get("threshold"),
                                  "candidate": candidate.get("name") if isinstance(candidate, dict) else candidate,
                                  "source_run": str(source_run) if source_run else None,
                                  "name": path.parent.name})
        return sorted(items, key=lambda x: x["name"], reverse=True)[:100]

    def state(self):
        with self.lock:
            jobs = [dict(j, lines=j["lines"][-200:]) for j in self.jobs[-20:]]
        return {"jobs": jobs, "runs": self.runs(), "decisions": self.decisions()}

    def preview(self, data):
        from .decisions import calibration_preview
        run = self.run_path(data.get("run", ""))
        candidate = data.get("candidate", "selected")
        threshold = data.get("threshold")
        if threshold not in (None, ""):
            threshold = float(threshold)
            if not math.isfinite(threshold):
                raise ValueError("Threshold must be finite.")
        else:
            threshold = None
        result = calibration_preview(run, candidate=candidate, threshold=threshold)
        # Original images are linked only after matching the immutable manifest.
        rows = _read_csv(run / "manifest.csv", limit=1000000)
        known = {r.get("relative_path"): r for r in rows if r.get("split") == "threshold"}
        location = _read_json(run / "data_location.json", {})
        cfg = _read_json(run / "config.json", {})
        root = Path(location.get("data_root", cfg.get("data_root", ""))).resolve()
        if root in self.data_roots:
            from urllib.parse import quote
            index = self.data_roots.index(root)
            for row in result.get("rows", []):
                relative = row.get("relative_path")
                if relative in known:
                    path = _safe_path(root, relative)
                    if path.is_file():
                        row["image_url"] = "/images/" + str(index) + "/" + quote(relative, safe="/")
        return result

    def open_folder(self, value):
        path = self.checked_output(value, exists=True)
        if not path.is_dir():
            path = path.parent
        if os.name == "nt":
            os.startfile(str(path))
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return {"message": "Opened the folder on this computer."}


def make_handler(app):
    class Handler(BaseHTTPRequestHandler):
        server_version = "VisualInspection/3"

        def log_message(self, format, *args):
            pass

        def _check_host(self):
            expected = "127.0.0.1:" + str(self.server.server_port)
            if self.headers.get("Host") != expected:
                raise PermissionError("Open the dashboard using its exact 127.0.0.1 address.")
            origin = self.headers.get("Origin")
            if origin and origin != "http://" + expected:
                raise PermissionError("Cross-origin requests are not allowed.")

        def _send(self, body, content_type="application/json; charset=utf-8", status=200):
            if not isinstance(body, bytes):
                body = json.dumps(_clean_json(body), allow_nan=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            # Generated reports may embed their own scripts; dashboard assets don't.
            self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            try:
                self._check_host()
                parsed = urlparse(self.path)
                data = {k: v[0] for k, v in parse_qs(parsed.query).items()}
                path = unquote(parsed.path)
                if path == "/api/bootstrap":
                    result = app.bootstrap()
                elif path == "/api/state":
                    result = app.state()
                elif path == "/api/run":
                    result = app.run_info(data.get("run", ""))
                elif path == "/api/preview":
                    result = app.preview(data)
                elif path in ("/", "/app.js", "/style.css"):
                    file = STATIC / ({"/": "index.html"}.get(path, path[1:]))
                    return self._send(file.read_bytes(), mimetypes.guess_type(file.name)[0] or "text/plain")
                elif path.startswith(("/results/", "/images/")):
                    kind, index, relative = path.lstrip("/").split("/", 2)
                    roots = app.output_roots if kind == "results" else app.data_roots
                    number = int(index)
                    if number < 0 or number >= len(roots):
                        raise ValueError("Unknown file root.")
                    file = _safe_path(roots[number], relative)
                    allowed = {".png", ".bmp", ".jpg", ".jpeg"} if kind == "images" else {".html", ".css", ".js", ".png", ".bmp", ".jpg", ".jpeg", ".svg", ".json", ".csv", ".txt", ".log"}
                    if file.suffix.lower() not in allowed or not file.is_file():
                        raise ValueError("File is unavailable or not a report/image.")
                    if file.stat().st_size > 64 * 1024 * 1024:
                        raise ValueError("Open this large file in its local folder.")
                    return self._send(file.read_bytes(), mimetypes.guess_type(file.name)[0] or "text/plain")
                else:
                    return self._send({"error": "Not found"}, status=404)
                self._send(result)
            except PermissionError as exc:
                self._send({"error": str(exc)}, status=403)
            except Exception as exc:
                self._send({"error": str(exc)}, status=400)

        def do_POST(self):
            try:
                self._check_host()
                if not secrets.compare_digest(self.headers.get("X-Inspection-Token", ""), app.token):
                    raise PermissionError("Invalid dashboard session. Reload this page.")
                if self.headers.get_content_type() != "application/json":
                    raise ValueError("Expected JSON.")
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length <= 128 * 1024:
                    raise ValueError("Invalid request size.")
                data = json.loads(self.rfile.read(length))
                if not isinstance(data, dict):
                    raise ValueError("Expected an object.")
                if self.path == "/api/action":
                    result = app.start(data.pop("action", ""), data)
                elif self.path == "/api/config":
                    result = app.save_config(data)
                elif self.path == "/api/pause":
                    result = app.pause(data.get("run"))
                elif self.path == "/api/open-folder":
                    result = app.open_folder(data.get("path", ""))
                else:
                    return self._send({"error": "Not found"}, status=404)
                self._send(result)
            except PermissionError as exc:
                self._send({"error": str(exc)}, status=403)
            except Exception as exc:
                self._send({"error": str(exc)}, status=400)

    return Handler


def serve_dashboard(config, host="127.0.0.1", port=8765, open_browser=True):
    if host != "127.0.0.1":
        raise ValueError("The dashboard only binds to 127.0.0.1.")
    app = Dashboard(config)
    server = ThreadingHTTPServer((host, int(port)), make_handler(app))
    server.daemon_threads = True
    url = "http://127.0.0.1:" + str(server.server_port)
    print(f"Local dashboard: {url}\nKeep this terminal open. Press Ctrl+C to close the dashboard.", flush=True)
    print("Jobs already started continue independently; use Pause search before closing if required.", flush=True)
    if open_browser:
        threading.Timer(.4, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever(poll_interval=.3)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
