"""Regression checks for the Windows atomic snapshot and retry behavior (synthetic only)."""
import errno
import io
import json
import os
from pathlib import Path
import tempfile
import threading
import time
import unittest
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch

from nilt import common


def windows_error(code):
    exc = PermissionError(errno.EACCES, "simulated Windows access/sharing lock")
    exc.winerror = code
    return exc


class AtomicWrites(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.path = self.root / "progress.json"
        self.path.write_text('{"previous": true}', encoding="utf-8")
        self.old = self.path.read_bytes()

    def assert_old_intact(self):
        self.assertEqual(self.path.read_bytes(), self.old)
        self.assertEqual(list(self.root.glob(".*.tmp")), [])

    def test_json_unicode_format_and_return_value(self):
        data = {"epoch": 3, "task": "Unicode \u00e9", "metrics": [0.4, None, True]}
        self.assertIsNone(common.write_json(self.path, data))
        self.assertEqual(common.read_json(self.path), data)
        expected = json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False)
        self.assertEqual(self.path.read_bytes(), expected.replace("\n", os.linesep).encode())
        self.assertEqual(list(self.root.glob(".*.tmp")), [])

    def test_new_nested_destination_and_legacy_temp_are_safe(self):
        legacy = self.root / "progress.json.tmp"
        legacy.write_text("unrelated old temporary content", encoding="utf-8")
        common.write_json(self.path, {"new": 1})
        self.assertEqual(legacy.read_text(), "unrelated old temporary content")
        path = self.root / "nested" / "more" / "new.json"
        common.write_json(str(path), {"new": 2})
        self.assertEqual(common.read_json(path), {"new": 2})

    def test_invalid_json_never_replaces_valid_destination(self):
        for value in (float("nan"), float("inf"), object()):
            with self.subTest(value=repr(value)):
                with self.assertRaises((TypeError, ValueError)):
                    common.write_json(self.path, {"invalid": value})
                self.assert_old_intact()

    def test_windows_5_32_33_recover_after_transient_replace_failure(self):
        real_replace = os.replace
        for code in (5, 32, 33):
            for writer in ("json", "csv"):
                with self.subTest(code=code, writer=writer):
                    calls = []

                    def temporarily_locked(source, target):
                        self.assertEqual(Path(source).parent, Path(target).parent)
                        calls.append(str(source))
                        # The complete new snapshot is already closed on disk.
                        with open(source, "rb") as stream:
                            self.assertTrue(stream.read())
                        if len(calls) <= 3:
                            raise windows_error(code)
                        return real_replace(source, target)

                    with patch.object(common.os, "replace", side_effect=temporarily_locked), patch.object(common.time, "sleep") as sleep:
                        if writer == "json":
                            common.write_json(self.path, {"code": code})
                        else:
                            common.write_csv(self.path, [{"code": code}])
                    self.assertEqual(len(calls), 4)
                    self.assertEqual(len(set(calls)), 1)
                    self.assertEqual(sleep.call_count, 3)
                    self.assertEqual(list(self.root.glob(".*.tmp")), [])

    def test_persistent_denial_is_bounded_and_keeps_previous_file(self):
        failure = windows_error(5)
        with patch.object(common.os, "replace", side_effect=failure) as replace, patch.object(common.time, "sleep") as sleep:
            with self.assertRaises(PermissionError) as caught:
                common.write_json(self.path, {"lost": False})
        self.assertIs(caught.exception, failure)
        self.assertEqual(replace.call_count, 16)
        self.assertEqual(sleep.call_count, 15)
        self.assertAlmostEqual(sum(c.args[0] for c in sleep.call_args_list), 2.31)
        self.assert_old_intact()

    def test_non_lock_errors_are_not_retried(self):
        for failure in (OSError(errno.ENOSPC, "disk full"), OSError(errno.EIO, "I/O error"),
                        PermissionError(errno.EACCES, "ordinary permanent POSIX denial"),
                        windows_error(123)):
            with self.subTest(failure=repr(failure)):
                with patch.object(common.os, "replace", side_effect=failure) as replace, patch.object(common.time, "sleep") as sleep:
                    with self.assertRaises(OSError) as caught:
                        common.write_json(self.path, {"new": 1})
                self.assertIs(caught.exception, failure)
                self.assertEqual(replace.call_count, 1)
                sleep.assert_not_called()
                self.assert_old_intact()

    def test_failed_temp_creation_does_not_change_destination(self):
        with patch.object(common.tempfile, "mkstemp", side_effect=windows_error(5)):
            with self.assertRaises(PermissionError):
                common.write_json(self.path, {"new": 1})
        self.assert_old_intact()

    def test_fsync_failure_keeps_previous_file_and_cleans_temp(self):
        with patch.object(common.os, "fsync", side_effect=OSError(errno.ENOSPC, "disk full")):
            with self.assertRaises(OSError):
                common.write_json(self.path, {"new": 1})
        self.assert_old_intact()

    def test_descriptor_is_closed_when_stream_creation_fails(self):
        with patch.object(common.os, "fdopen", side_effect=ValueError("stream creation failed")) as fdopen:
            with self.assertRaises(ValueError):
                common.write_json(self.path, {"new": 1})
        with self.assertRaises(OSError):
            os.fstat(fdopen.call_args.args[0])
        self.assert_old_intact()

    def test_cleanup_error_never_hides_original_failure(self):
        failure = OSError(errno.ENOSPC, "disk full")
        with patch.object(common.os, "replace", side_effect=failure), patch.object(Path, "unlink", side_effect=windows_error(5)):
            with self.assertRaises(OSError) as caught:
                common.write_json(self.path, {"new": 1})
        self.assertIs(caught.exception, failure)
        self.assertEqual(self.path.read_bytes(), self.old)
        # The temp can remain locked; the valid destination was never deleted.
        self.assertEqual(len(list(self.root.glob(".*.tmp"))), 1)

    def test_interrupt_preserves_previous_file(self):
        with patch.object(common.os, "replace", side_effect=windows_error(32)), patch.object(common.time, "sleep", side_effect=KeyboardInterrupt):
            with self.assertRaises(KeyboardInterrupt):
                common.write_json(self.path, {"new": 1})
        self.assert_old_intact()

    def test_csv_format_bom_columns_and_roundtrip_unchanged(self):
        rows = [{"text": "a,b\nc", "score": 0.8, "ignored": 12}, {"text": "d", "score": None}]
        columns = ["score", "text"]
        buffer = io.StringIO(newline="")
        writer = common.csv.DictWriter(buffer, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
        self.assertIsNone(common.write_csv(self.path, iter(rows), columns))
        self.assertEqual(self.path.read_bytes(), buffer.getvalue().encode("utf-8-sig"))
        self.assertEqual(common.read_csv(self.path), [{"score": "0.8", "text": "a,b\nc"}, {"score": "", "text": "d"}])
        common.write_csv(self.path, [], ["epoch", "loss"])
        self.assertEqual(self.path.read_bytes(), b"\xef\xbb\xbfepoch,loss\r\n")

    def test_bad_csv_value_does_not_truncate_previous_file(self):
        class BrokenValue:
            def __str__(self):
                raise ValueError("bad cell")
        with self.assertRaisesRegex(ValueError, "bad cell"):
            common.write_csv(self.path, [{"cell": "first"}, {"cell": BrokenValue()}])
        self.assert_old_intact()

    def test_parallel_writers_use_distinct_complete_temp_files(self):
        real_replace = os.replace
        ready = threading.Barrier(2)
        sources = []

        def synchronized_replace(source, target):
            sources.append(str(source))
            ready.wait(timeout=5)
            return real_replace(source, target)

        payloads = [{"writer": i, "values": [i] * 1000} for i in (1, 2)]
        with patch.object(common.os, "replace", side_effect=synchronized_replace):
            with ThreadPoolExecutor(max_workers=2) as pool:
                futures = [pool.submit(common.write_json, self.path, value) for value in payloads]
                for future in futures:
                    future.result(timeout=10)
        self.assertEqual(len(set(sources)), 2)
        self.assertIn(common.read_json(self.path), payloads)
        self.assertEqual(list(self.root.glob(".*.tmp")), [])

    def test_reader_never_sees_partial_json_under_repeated_updates(self):
        done, reader_ready = threading.Event(), threading.Event()
        common.write_json(self.path, {"n": 0, "data": [0] * 100})

        def read_loop():
            reads = 0
            reader_ready.set()
            while not done.is_set():
                try:
                    value = common.read_json(self.path)
                except PermissionError:
                    # On Windows, the read itself can briefly race with replace.
                    continue
                self.assertEqual(value["data"], [value["n"]] * 100)
                reads += 1
                time.sleep(0.001)
            return reads

        with ThreadPoolExecutor(max_workers=1) as pool:
            reader = pool.submit(read_loop)
            self.assertTrue(reader_ready.wait(timeout=5))
            try:
                for n in range(1, 101):
                    common.write_json(self.path, {"n": n, "data": [n] * 100})
            finally:
                done.set()
            self.assertGreater(reader.result(timeout=5), 0)

    def test_existing_run_lock_remains_exclusive(self):
        with common.run_lock(self.root):
            with self.assertRaises(RuntimeError):
                with common.run_lock(self.root):
                    self.fail("Acquired already-owned lock")
        self.assertFalse((self.root / "operation.lock").exists())

    @unittest.skipUnless(os.name == "nt", "Native Windows file-lock test requires Windows")
    def test_native_windows_reader_lock_released_during_retry(self):
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        create = kernel.CreateFileW
        create.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p,
                           wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
        create.restype = wintypes.HANDLE
        close = kernel.CloseHandle
        close.argtypes = [wintypes.HANDLE]
        close.restype = wintypes.BOOL
        handle = create(str(self.path), 0x80000000, 1, None, 3, 0, None)
        self.assertNotEqual(handle, wintypes.HANDLE(-1).value)
        timer = threading.Timer(0.1, lambda: close(handle))
        timer.start()
        try:
            common.write_json(self.path, {"unlocked": True})
        finally:
            timer.join()
        self.assertEqual(common.read_json(self.path), {"unlocked": True})


if __name__ == "__main__":
    unittest.main(verbosity=2)
