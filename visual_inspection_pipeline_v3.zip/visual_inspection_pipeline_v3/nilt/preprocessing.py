"""Portable, explicit whole-image preprocessing shared by training and deployment."""
from __future__ import annotations

from PIL import Image, ImageOps

MEAN = [0.485, 0.456, 0.406]
STD = [0.229, 0.224, 0.225]
PAD_COLOR = (124, 116, 104)


def rotate_quarter_turn(image, k):
    """Exact 90-degree rotation with every original pixel preserved.

    A non-square image swaps width and height for odd k. Padding is applied only
    afterwards; no interpolation, corner crop, reflected pixels or relabeling.
    """
    if not isinstance(k, int) or isinstance(k, bool):
        raise ValueError("Quarter-turn count must be an integer.")
    method = {1: Image.Transpose.ROTATE_90, 2: Image.Transpose.ROTATE_180,
              3: Image.Transpose.ROTATE_270}.get(k % 4)
    return image.copy() if method is None else image.transpose(method)


def prepare_image(image, cfg):
    """Return an RGB square; pad never resamples or crops input pixels.

    ``fit`` is an explicit opt-in to aspect-preserving resampling. Images must
    already contain the intended inspection ROI. No detector or alignment step
    is inferred from image content.
    """
    size = cfg.get("image_size")
    if not isinstance(size, int) or isinstance(size, bool) or size < 32:
        raise ValueError("image_size must be a resolved integer >= 32.")
    mode = cfg.get("resize", "pad")
    if mode not in ("pad", "fit"):
        raise ValueError("Supported resize modes are pad and fit; tiling is not implemented.")
    if cfg.get("preserve_native_resolution", False) and mode != "pad":
        raise ValueError("Native resolution preservation requires resize=pad.")
    image = ImageOps.exif_transpose(image).convert("RGB")
    if mode == "fit":
        scale = size / max(image.size)
        dimensions = (max(1, round(image.width * scale)), max(1, round(image.height * scale)))
        image = image.resize(dimensions, Image.Resampling.BILINEAR)
    elif max(image.size) > size:
        raise ValueError(
            f"Input image {image.size} exceeds image_size={size}. "
            "Increase image_size or explicitly select resize=fit; no automatic scaling is performed."
        )
    left, top = (size - image.width) // 2, (size - image.height) // 2
    return ImageOps.expand(image, (left, top, size - image.width - left, size - image.height - top),
                           fill=PAD_COLOR)
