"use strict";
// Real dashboard interactions; no training jobs or model-performance claims.
const {firefox,chromium}=require("playwright");
const {spawn}=require("node:child_process");
const fs=require("node:fs"),path=require("node:path"),os=require("node:os"),assert=require("node:assert/strict");
const root=path.resolve(__dirname,".."),temporary=fs.mkdtempSync(path.join(os.tmpdir(),"studio-backbones-"));
const config=path.join(temporary,"project.yaml"),port=18766;
fs.writeFileSync(config,"tasks:\n  vig:\n    dataset_root: ./images\n");
const server=spawn(process.env.STUDIO_PYTHON||"python",["inspection.py","dashboard","--config",config,"--port",String(port),"--no-browser"],{cwd:root,stdio:["ignore","pipe","pipe"]});
let browser,log="";
server.stderr.on("data",chunk=>{log+=chunk.toString();});
async function main(){
  await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error("Startup timeout: "+log)),20000);server.stdout.on("data",chunk=>{log+=chunk.toString();if(log.includes("Local dashboard:")){clearTimeout(timer);resolve();}});server.on("exit",code=>{clearTimeout(timer);reject(Error("Server exited: "+code));});});
  browser=process.env.STUDIO_BROWSER_EXECUTABLE
    ? await chromium.launch({headless:true,executablePath:process.env.STUDIO_BROWSER_EXECUTABLE})
    : await firefox.launch({headless:true});
  const page=await browser.newPage({viewport:{width:1366,height:1000}}),errors=[];
  page.on("pageerror",error=>errors.push(error.message));
  await page.goto(`http://127.0.0.1:${port}`);
  await page.waitForFunction(()=>document.querySelectorAll("#models input").length===39);
  await page.locator("#nav-search").click();
  const restricted=page.locator('#models input[value="convnextv2-base"]');
  assert.equal(await restricted.isDisabled(),true);
  assert.equal(await page.locator("#models a").count(),29);
  await page.locator("#model-usage").selectOption("research");
  assert.equal(await restricted.isDisabled(),false);
  await restricted.check();
  await page.locator("#model-usage").selectOption("commercial");
  assert.equal(await restricted.isDisabled(),true);
  assert.equal(await restricted.isChecked(),false);
  await page.locator("#profile").selectOption("workstation_50h");
  await page.waitForFunction(()=>document.getElementById("cs-total-budget").value==="172800"&&document.getElementById("hours").value==="48");
  assert.equal(await page.locator("#hours").getAttribute("max"),"50");
  assert.equal(await page.locator("#cs-total-budget").getAttribute("max"),"180000");
  assert.equal(await page.locator("#cs-device").inputValue(),"cuda");
  assert.equal(await page.locator("#models input:checked").count(),8);
  await page.locator("#search-download-weights").uncheck();
  assert.equal(await page.locator("#cs-download-weights").isChecked(),false);
  await page.locator("#search-preset").selectOption("custom");
  const validate=async(seconds,usage="commercial",models=["eva02-small"])=>page.evaluate(async({seconds,usage,models})=>{
    const custom=InspectionV5.customPayload();custom.search.total_budget_seconds=seconds;custom.model_usage=usage;
    const response=await fetch("/api/v5/validate-search",{method:"POST",headers:{"Content-Type":"application/json","X-Inspection-Token":boot.token},body:JSON.stringify({...settings(),model_usage:usage,models,custom})});
    return {status:response.status,body:await response.json()};
  },{seconds,usage,models});
  let response=await validate(180000);
  assert.equal(response.status,200);assert.equal(response.body.resolved_config.download_missing_weights,false);
  response=await validate(180001);assert.equal(response.status,400);assert.match(response.body.error,/50 hours/);
  response=await validate(172800,"commercial",["convnextv2-atto"]);assert.equal(response.status,400);assert.match(response.body.error,/commercial/);
  response=await validate(172800,"research",["convnextv2-atto"]);assert.equal(response.status,200);
  await page.locator("#profile").selectOption("laptop");
  await page.waitForFunction(()=>document.getElementById("cs-device").value==="cpu");
  assert.equal(await page.locator("#hours").getAttribute("max"),null);
  assert.equal(await page.locator("#search-download-weights").isChecked(),true);
  assert.deepEqual(errors,[]);
  console.log("PASS: real browser dashboard exposes 29 new model cards, enforces weight purposes, synchronizes shared download controls, loads the 48-hour CUDA profile, validates 50-hour limits and preserves laptop behavior.");
}
main().catch(error=>{console.error(error);console.error(log);process.exitCode=1;}).finally(async()=>{if(browser)await browser.close();server.kill("SIGINT");fs.rmSync(temporary,{recursive:true,force:true});});
