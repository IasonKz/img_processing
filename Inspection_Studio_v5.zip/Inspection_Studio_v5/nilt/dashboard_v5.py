"""V5 workspace controls. Only explicit operator actions create artifacts.

All model/decision algorithms live outside the HTTP layer. This mixin validates
workspace boundaries, snapshots requested settings, and coordinates long actions.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import math
from pathlib import Path
import sys

from .common import DEFAULTS, PROFILES, MODEL_NAMES, merge_dict, read_json, write_json, validate_config


class V5DashboardMixin:
    def _v5_resolved_config(self, profile, task):
        if profile not in PROFILES or task not in self.raw.get("tasks", {}):
            raise ValueError("Choose a configured task and supported hardware profile.")
        options = self.raw["tasks"][task]
        cfg = merge_dict(DEFAULTS, PROFILES[profile])
        cfg = merge_dict(cfg, self.raw.get("defaults", {}))
        cfg = merge_dict(cfg, self.raw.get("profiles", {}).get(profile, {}))
        cfg = merge_dict(cfg, {k: v for k, v in options.items() if k not in ("dataset_root", "enabled")})
        paths = self.raw.get("paths", {})
        cfg.update(task=task, profile=profile, project_name=self.raw.get("project_name", "visual_inspection"),
                   project_file=str(self.config), data_root=str(self._configured_path(options.get("dataset_root", "data/" + task))))
        for key, source, fallback in (("output_root", "output_root", "results"),
                                      ("weights_dir", "weights_root", "weights"),
                                      ("incoming_root", "incoming_root", "incoming"),
                                      ("classification_output_root", "classification_output_root", "classified")):
            cfg[key] = str(self._configured_path(paths.get(source, fallback)))
        for key in ("groups_csv", "previous_run"):
            if cfg.get(key):
                cfg[key] = str(self._configured_path(cfg[key]))
        validate_config(cfg)
        return cfg

    def v5_defaults(self, data):
        from .custom_search import defaults_for
        cfg = self._v5_resolved_config(data.get("profile", "laptop"), data.get("task", "vig"))
        result = defaults_for(cfg)
        result.setdefault("image_strategy", cfg.get("image_strategy", "full_image"))
        result.setdefault("patches", cfg.get("patches", {}))
        return result

    def v5_search_config(self, data, *, persist=True):
        from .custom_search import apply_custom
        profile, task = data.get("profile", "laptop"), data.get("task", "vig")
        cfg = self._v5_resolved_config(profile, task)
        if not self.raw["tasks"][task].get("enabled", True):
            raise ValueError("Enable the task by saving its dataset settings first.")
        models = data.get("models")
        if not isinstance(models, list) or not models or any(m not in MODEL_NAMES for m in models):
            raise ValueError("Select at least one supported pretrained model.")
        if len(set(models)) != len(models):
            raise ValueError("Architectures must be distinct.")
        cfg["models"] = models
        if data.get("custom") is not None:
            cfg = apply_custom(cfg, data["custom"])
        if cfg.get("pretrained") is not True:
            raise ValueError("Studio 5 searches require pretrained image models. Enable pretrained weights in the project.")
        cap = {"laptop": 2, "workstation": 6, "workstation_large": 12}[profile]
        seconds = (float(cfg["search"]["total_budget_seconds"]) if data.get("custom") is not None else
                   float(data.get("hours", cap)) * 3600)
        if not math.isfinite(seconds) or seconds <= 0:
            raise ValueError("Time budget must be finite and positive; profiles supply defaults only.")
        cfg["search"]["total_budget_seconds"] = seconds
        cfg["search"]["enabled"] = True
        validate_config(cfg)
        from .search import search_settings
        search_settings(cfg)
        if not persist:
            return {"valid": True, "resolved_config": cfg,
                    "note": "Validated only. No training, filesystem snapshot, or image access occurred."}
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%f")
        target = self.logs_root / ("search_contract_" + stamp + ".json")
        write_json(target, cfg)
        return target

    @contextmanager
    def _v5_exclusive(self, name):
        with self.lock:
            self._refresh_recovered_jobs()
            if getattr(self, "_v5_operation", None) or any(j["status"] in ("running", "unverified") for j in self.jobs):
                raise ValueError("A job is active. Finish or pause it before this operation.")
            self._v5_operation = name
        try:
            yield
        finally:
            with self.lock:
                self._v5_operation = None

    def _v5_definition(self, data):
        definition = data.get("definition")
        if not isinstance(definition, dict):
            raise ValueError("A decision-system definition is required.")
        sources = definition.get("sources", [])
        if not isinstance(sources, list) or not 1 <= len(sources) <= 16:
            raise ValueError("Choose one to sixteen candidate sources.")
        for source in sources:
            if not isinstance(source, dict):
                raise ValueError("Each source must specify a recorded run and candidate.")
            self.run_path(source.get("run", ""))
        tuning = definition.get("tuning", {})
        if not isinstance(tuning, dict):
            raise ValueError("Tuning controls must be an object.")
        seconds = float(tuning.get("timeout_seconds", 60))
        if not math.isfinite(seconds) or seconds <= 0:
            raise ValueError("Decision tuning must have a budget greater than zero seconds.")
        return definition

    def v5_systems(self):
        root = self.config.parent / "decision_systems"
        records = []
        for path in sorted(root.glob("*/decision_system.json"), reverse=True):
            if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):
                continue
            try:
                record = read_json(path)
                records.append({**record, "path": str(path), "name": record.get("name", path.parent.name)})
            except (OSError, ValueError):
                continue
        return records[:200]

    def v5_system_preview(self, data):
        from .decision_lab import preview_system
        definition = self._v5_definition(data)
        with self._v5_exclusive("decision-preview"):
            return preview_system(definition)

    def v5_system_save(self, data):
        from .decision_lab import create_system
        definition = self._v5_definition(data)
        with self._v5_exclusive("decision-save"):
            path = Path(create_system(definition, self.config.parent / "decision_systems"))
            return {"path": str(path), "system": read_json(path)}

    def v5_review_export(self, data):
        from .review_dataset import export_review_dataset
        sessions = data.get("sessions", [])
        if not isinstance(sessions, list) or not 1 <= len(sessions) <= 100:
            raise ValueError("Select one to one hundred review sessions.")
        sessions = [self._review_session_path(path) for path in sessions]
        source_run = self.run_path(data["source_run"]) if data.get("source_run") else None
        replay = data.get("include_replay", True)
        if not isinstance(replay, bool):
            raise ValueError("include_replay must be true or false.")
        output = self.checked_output(data.get("output_root") or self.config.parent / "review_datasets")
        with self._v5_exclusive("review-export"):
            return export_review_dataset(sessions, output, source_run=source_run, include_replay=replay)

    def v5_command(self, action, data, project):
        command = [sys.executable, "-u", str(project / "inspection.py")]
        if action == "system-classify":
            path = self.checked_output(data.get("system", ""), exists=True)
            if path.name != "decision_system.json":
                raise ValueError("Select a frozen decision_system.json.")
            input_dir = Path(str(data.get("input", ""))).expanduser().resolve()
            if not str(data.get("input", "")).strip() or not input_dir.is_dir():
                raise ValueError("Input image folder does not exist.")
            output = self.checked_output(data.get("output") or self.config.parent / "classified")
            device = data.get("device", "cpu")
            if device not in ("cpu", "cuda", "auto"):
                raise ValueError("Choose cpu, cuda or auto.")
            command += ["system-run", "--system", str(path), "--input", str(input_dir),
                        "--output-root", str(output), "--device", device]
            if data.get("labeled"):
                command += ["--labeled"]
            if data.get("copy_images", True) is False:
                command += ["--no-copy-images"]
            return command
        if action == "review-finetune":
            path = self.checked_output(data.get("config", ""), exists=True)
            from .review_dataset import validate_update_config
            cfg = validate_update_config(path)
            self.run_path(cfg["previous_run"])
            profile = data.get("profile", cfg.get("profile", "laptop"))
            if profile not in PROFILES:
                raise ValueError("Choose a supported profile.")
            if profile != cfg.get("profile", "laptop"):
                raise ValueError("Use the exported configuration's recorded profile for fine-tuning.")
            return command + ["update", "--config", str(path), "--from-run", cfg["previous_run"],
                              "--profile", profile, "--task", cfg["task"]]
        if action == "system-evaluate":
            path = self.checked_output(data.get("system", ""), exists=True)
            if path.name != "decision_system.json" or data.get("confirm_final_test") is not True:
                raise ValueError("Confirm explicit final-test evaluation of the frozen system.")
            device = data.get("device", "cpu")
            if device not in ("cpu", "cuda", "auto"):
                raise ValueError("Choose cpu, cuda or auto.")
            return command + ["system-evaluate", "--system", str(path), "--device", device,
                              "--confirm-final-test"]
        return None
