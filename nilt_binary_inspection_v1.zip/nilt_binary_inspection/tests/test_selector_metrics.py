import numpy as np
import pytest

from binary_inspection.metrics import upper_binomial_bound, classification_metrics
from binary_inspection.selector import fit_monotone_sigmoid, apply_sigmoid, fit_thresholds, decide, combine


def test_zero_failure_confidence_bound():
    assert upper_binomial_bound(0, 100) == pytest.approx(1 - 0.05 ** (1 / 100))
    assert upper_binomial_bound(0, 0) is None
    assert upper_binomial_bound(100, 100) == 1


def test_calibrator_direction_and_finite_values():
    z = np.array([-5, -4, -3, 3, 4, 5])
    y = np.array([0, 0, 0, 1, 1, 1])
    fitted = fit_monotone_sigmoid(z, y)
    p = apply_sigmoid(z, fitted)
    assert np.isfinite(p).all() and np.all(np.diff(p) > 0)
    assert p[0] < 0.1 and p[-1] > 0.9


def test_thresholds_and_ties(config):
    settings = config["selector"]
    settings.update(max_bad_escape_rate=0.0, max_good_false_fail_rate=0.0)
    y = np.array([0, 0, 1, 1])
    p = np.array([0.02, 0.10, 0.10, 0.97])
    policy = fit_thresholds(y, p, p[:, None], settings)
    decisions, _ = decide(p, p[:, None], policy)
    assert decisions.tolist() == ["PASS", "REVIEW", "REVIEW", "FAIL"]


def test_anomaly_veto_does_not_mean_fail(config):
    settings = {**config["selector"], "use_anomaly_veto": True}
    policy = {"settings": settings, "pass_threshold": 0.1, "fail_threshold": 0.9,
              "anomaly_threshold": 10.0}
    p = np.array([0.01, 0.99])
    d, reasons = decide(p, p[:, None], policy, np.array([100., 1.]))
    assert d.tolist() == ["REVIEW", "FAIL"]
    assert "HIGH_ANOMALY" in reasons[0]
    with pytest.raises(ValueError, match="requires PatchCore"):
        decide(p, p[:, None], policy)


def test_disagreement_and_missing_scores_block_pass(config):
    policy = {"settings": config["selector"], "pass_threshold": 0.5, "fail_threshold": 0.9}
    score = np.array([0.2, np.nan])
    members = np.array([[0.01, 0.7], [np.nan, 0.1]])
    d, _ = decide(score, members, policy)
    assert d.tolist() == ["REVIEW", "REVIEW"]


def test_review_is_not_automatic_recall():
    metrics = classification_metrics([1, 1, 0, 0], [.1, .5, .2, .9], ["PASS", "REVIEW", "PASS", "FAIL"])
    assert metrics["bad_escape_rate"] == .5
    assert metrics["bad_auto_fail_recall"] == 0
    assert metrics["bad_not_pass_rate_includes_review"] == .5
    assert metrics["good_false_fail_rate"] == .5
    assert metrics["pass_contamination_rate"] == .5


def test_group_event_is_any_escape():
    stats = classification_metrics([1, 1, 1], [.1, .9, .9], ["PASS", "FAIL", "FAIL"], ["a", "a", "b"])
    assert stats["bad_groups"] == 2 and stats["bad_groups_with_any_escape"] == 1
