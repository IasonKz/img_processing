# Windows 11 installation

Use PowerShell from the extracted project folder, the one containing `inspection.py` and `project.yaml`. Commands below do not require virtual-environment activation. `PS` in the prompt simply identifies PowerShell.

## Reuse a working environment on the same computer

An existing environment may be reused if it passes the checks below. A separate environment is the recommended default for v5 because later package changes must not affect the old project. The following optional route only checks the old environment and records its interpreter; it does not reinstall or remove packages.

The following uses the earlier laptop environment at `%USERPROFILE%\venvs\vip3`; substitute your actual Python executable if it is elsewhere:

```powershell
$ExistingPython = "$env:USERPROFILE\venvs\vip3\Scripts\python.exe"
& $ExistingPython -m pip check
if ($LASTEXITCODE -ne 0) { throw 'The existing environment has a dependency issue.' }
& $ExistingPython -c "import sys, torch, torchvision, optuna, sklearn, scipy, matplotlib, yaml, psutil, numpy, PIL; assert sys.version_info[:2] == (3,12); assert torch.__version__.split('+')[0] == '2.7.1'; assert torchvision.__version__.split('+')[0] == '0.22.1'; assert optuna.__version__ == '4.5.0'; print(sys.executable); print(torch.cuda.is_available())"
if ($LASTEXITCODE -ne 0) { throw 'The existing environment does not match this release.' }
Set-Content .studio-python.txt $ExistingPython
.\Start.cmd
```

For an existing workstation installation, use its CUDA environment (for example `vip3gpu`) and confirm that the device check prints `True`. A CPU environment is suitable for the laptop profile. Run **Check installation** in the dashboard for the selected profile before training.

The path record is local to this project. `Start.cmd` can reuse it on subsequent launches. Do not copy a virtual environment to a different computer; set up the destination separately.

## Install Python

```powershell
py -0p
```

If Python 3.12 is absent, install it through your approved software channel. Where WinGet is available:

```powershell
winget install -e --id Python.Python.3.12 --source winget
```

Open a new terminal after installation, then check:

```powershell
py -3.12 -c "import sys, platform; print(sys.version); print(platform.machine()); print(64 if sys.maxsize > 2**32 else 32)"
```

The setup target is Python 3.12 x64 with the pinned PyTorch/torchvision pair. A different Python release may require a different compatible package set. Do not upgrade individual binary packages arbitrarily to resolve a version mismatch.

## Recommended setup

Run one alternative:

```powershell
.\Setup.cmd -Device cpu
```

```powershell
.\Setup.cmd -Device cuda
```

The default environments are `%USERPROFILE%\venvs\studio5-cpu` and `%USERPROFILE%\venvs\studio5-cuda`. Setup refuses to modify an existing unrecognized environment. It never deletes another project's environment. Re-running setup can repair the environment created by this setup script.

For ONNX export support, add `-WithExport`. For an alternative short environment path, add `-EnvironmentPath 'D:\venvs\studio5-cuda'`.

Setup installs the base requirements and the matched `torch==2.7.1` / `torchvision==0.22.1` pair. The CUDA variant uses the official `cu128` wheels and requires a compatible NVIDIA driver; the CPU variant uses the CPU wheel index. See the [official PyTorch version matrix](https://pytorch.org/get-started/previous-versions/).

The script imports the main dependencies, runs `pip check`, and executes a small model forward/backward pass on the requested device. CUDA setup fails when CUDA is unavailable; it does not silently select CPU. This validates basic execution, not every model or your dataset.

The `.cmd` launchers set the execution policy only for their PowerShell process. They do not change the user or machine policy. If centrally managed policy blocks scripts, use the manual route below or your approved IT installation process.

## Manual installation

Use this when scripts are unavailable. Choose a **new** short directory. Do not run the creation command on an existing unrelated environment.

```powershell
$StudioEnv = "$env:USERPROFILE\venvs\studio5-manual"
if (Test-Path $StudioEnv) { throw 'Choose a new environment directory.' }
py -3.12 -m venv $StudioEnv
if ($LASTEXITCODE -ne 0) { throw 'Python environment creation failed.' }
$StudioPython = "$StudioEnv\Scripts\python.exe"
& $StudioPython -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw 'pip upgrade failed.' }
& $StudioPython -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw 'Base dependency installation failed.' }
```

Install **one** PyTorch variant:

```powershell
# NVIDIA workstation
& $StudioPython -m pip install torch==2.7.1 torchvision==0.22.1 --index-url https://download.pytorch.org/whl/cu128
if ($LASTEXITCODE -ne 0) { throw 'PyTorch installation failed.' }
```

```powershell
# CPU laptop
& $StudioPython -m pip install torch==2.7.1 torchvision==0.22.1 --index-url https://download.pytorch.org/whl/cpu
if ($LASTEXITCODE -ne 0) { throw 'PyTorch installation failed.' }
```

Then:

```powershell
& $StudioPython -m pip check
if ($LASTEXITCODE -ne 0) { throw 'Dependency check failed.' }
& $StudioPython -c "import torch, torchvision, optuna, sklearn; print(torch.__version__); print(torchvision.__version__); print(torch.cuda.is_available())"
if ($LASTEXITCODE -ne 0) { throw 'Import check failed.' }
Set-Content .studio-python.txt $StudioPython
& $StudioPython inspection.py dashboard --config project.yaml
```

If workstation setup reports `False` for CUDA, stop before training and check `nvidia-smi`, the installed wheel variant, and the driver with IT. The automated setup performs the stronger actual model computation check.

After manual installation, `Start.cmd` uses the recorded interpreter. A virtual environment does not need to be activated when its Python executable is invoked directly; see the [Python venv documentation](https://docs.python.org/3.12/library/venv.html).

## First run and public weights

Open `Start.cmd`, set the intended profile in **Train & search**, then use **Download pretrained weights** and **Check installation** in **Dataset & setup**. The download is an explicit online action for public weights. It does not upload inspection images.

Equivalent commands:

```powershell
$StudioPython = (Get-Content .studio-python.txt -Raw).Trim()
& $StudioPython inspection.py download-weights --config project.yaml --profile workstation --task vig
& $StudioPython inspection.py doctor --config project.yaml --profile workstation --task vig
```

Use `laptop` for the supplied CPU defaults or `workstation_large` for the larger GPU defaults. These presets do not impose a device or time limit on Custom Optuna; select execution and budget explicitly there. With `pretrained: true`, missing required weights cause an explicit error rather than silently training from random initialization.

## Optional export dependencies

```powershell
$StudioPython = (Get-Content .studio-python.txt -Raw).Trim()
& $StudioPython -m pip install -r requirements-export.txt
& $StudioPython -m pip check
& $StudioPython inspection.py doctor --config project.yaml --profile workstation --task vig --deployment
```

## Offline installation

On an approved online Windows machine with Python 3.12, create separate CPU and CUDA wheelhouses. Do not mix the variants in one directory.

```powershell
py -3.12 -m pip download -r requirements.txt -d D:\studio5_wheels_cuda
py -3.12 -m pip download torch==2.7.1 torchvision==0.22.1 --index-url https://download.pytorch.org/whl/cu128 -d D:\studio5_wheels_cuda
py -3.12 -m pip download -r requirements-export.txt -d D:\studio5_wheels_cuda
```

Transfer the wheelhouse and project by your approved local process, then:

```powershell
.\Setup.cmd -Device cuda -OfflineWheelhouse D:\studio5_wheels_cuda -WithExport
```

For CPU, use the CPU index and a separate CPU wheelhouse, then `-Device cpu`. Public pretrained weights are separate from Python wheels; provision and transfer the configured `weights` directory as well. Downloading wheels on Linux does not automatically produce Windows-compatible wheels.

## Reopen, change port, or use PyCharm

```powershell
.\Start.cmd
```

If port 8765 is occupied:

```powershell
.\Start.cmd -Port 8766
```

In PyCharm, select the Python executable written in `.studio-python.txt` as the project interpreter. No change to the interpreter of another project is required. In a new terminal, restore the short command variable when needed:

```powershell
$StudioPython = (Get-Content .studio-python.txt -Raw).Trim()
& $StudioPython inspection.py --help
```

Source: [WinGet install command](https://learn.microsoft.com/en-us/windows/package-manager/winget/install).
