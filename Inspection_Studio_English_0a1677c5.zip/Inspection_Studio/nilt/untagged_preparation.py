"""Prepare raw tester captures for classification, without inventing labels.

Capture discovery follows tray_untagged_preprocess.py. Pixel processing is
shared with labelled preparation so future captures match the training data.
"""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys

import cv2

from . import dataset_preparation as engine


TASKS = ("vig", "top", "bottom")
IMAGE_EXTENSIONS = {".bmp", ".png", ".tif", ".tiff", ".jpg", ".jpeg"}
CAPTURE_PATTERNS = {
    "top": r"(?:^|_)ViTop[A-Za-z0-9]*(?=_|\.|$)",
    "bottom": r"(?:^|_)ViBottom[A-Za-z0-9]*(?=_|\.|$)",
    "vig": r"(?:^|_)(?:FlatFieldBright|ViVig[A-Za-z0-9]*)(?=_|\.|$)",
}


def find_scan_root(tray):
    """Prefer raw measurement data; never scan EvaluationResults."""
    measurement = [p for p in tray.iterdir()
                   if p.is_dir() and not p.is_symlink() and p.name.casefold() == "measurementdata"]
    if len(measurement) > 1:
        raise ValueError("Ambiguous MeasurementData directories")
    if measurement:
        results = [p for p in measurement[0].iterdir()
                   if p.is_dir() and not p.is_symlink() and p.name.casefold() == "results"]
        if len(results) > 1:
            raise ValueError("Ambiguous Results directories")
        return results[0] if results else measurement[0]
    return tray


def compile_patterns(overrides):
    try:
        return {task: re.compile(overrides.get(task) or CAPTURE_PATTERNS[task], re.IGNORECASE)
                for task in TASKS}
    except re.error as exc:
        raise ValueError(f"Invalid capture filename pattern: {exc}") from exc


def capture_stage(name, task):
    if task == "vig":
        return "not_applicable"
    match = re.search(r"(?:^|_)Vi(?:Top|Bottom)([A-Za-z0-9]*)(?=_|\.|$)", name, re.I)
    if not match:
        return "unknown"
    token = match.group(1).casefold()
    if "final" in token or "post" in token:
        return "final"
    if "start" in token or "pre" in token:
        return "start"
    return "unknown"


def detect_task(name, patterns):
    matches = [task for task, pattern in patterns.items() if pattern.search(name)]
    if len(matches) > 1:
        raise ValueError(f"Ambiguous capture name matches several tasks: {name}")
    return matches[0] if matches else None


def scan_images(tray, patterns, stage="final", stop_check=None):
    root = find_scan_root(tray)
    plan, skipped = [], []
    def scan_error(error):
        raise error
    for directory, dirs, files in os.walk(root, followlinks=False, onerror=scan_error):
        if stop_check and stop_check():
            break
        base = Path(directory)
        dirs[:] = sorted(d for d in dirs
                         if d.casefold() != "evaluationresults" and not (base / d).is_symlink())
        for name in sorted(files):
            if stop_check and stop_check():
                break
            source = base / name
            if source.suffix.casefold() not in IMAGE_EXTENSIONS:
                continue
            relative = str(source.relative_to(tray))
            if source.is_symlink():
                skipped.append(dict(source=relative, status="skipped", reason="symlink"))
                continue
            task = detect_task(name, patterns)
            if task is None:
                skipped.append(dict(source=relative, status="skipped", reason="unrecognized_capture"))
                continue
            actual_stage = capture_stage(name, task)
            if task != "vig" and stage != "all" and actual_stage != stage:
                skipped.append(dict(source=relative, task=task, status="skipped",
                                    reason="stage_filter", capture_stage=actual_stage))
                continue
            plan.append((task, source, actual_stage))
    plan.sort(key=lambda item: (TASKS.index(item[0]), str(item[1]).casefold()))
    return root, plan, skipped


def validate_output(tray, output, debug, require_empty=True):
    review = output.with_name(output.name + "__review").resolve()
    debug_root = output.with_name(output.name + "__debug").resolve()
    folders = [output, review] + ([debug_root] if debug else [])
    for index, folder in enumerate(folders):
        if folder == tray or folder.is_relative_to(tray) or tray.is_relative_to(folder):
            raise ValueError(f"Output and auxiliary folders must be OUTSIDE the input and must not contain it: {folder}")
        if any(folder.is_relative_to(other) or other.is_relative_to(folder) for other in folders[:index]):
            raise ValueError("Output, review and debug folders must not overlap.")
        if require_empty and folder.exists() and (not folder.is_dir() or any(folder.iterdir())):
            raise ValueError(f"Choose a NEW or EMPTY folder. Already contains files: {folder}")
    return review, debug_root


def allocate_names(plan, tray):
    names, reserved = [], set()
    for task, source, stage in plan:
        name = source.stem + ".png"
        key = (task, name.casefold())
        if key in reserved:
            relative = source.relative_to(tray).as_posix()
            digest = hashlib.sha256(relative.encode("utf-8")).hexdigest()[:12]
            name = f"{source.stem}__{digest}.png"
            number = 2
            while (task, name.casefold()) in reserved:
                name = f"{source.stem}__{digest}_{number}.png"
                number += 1
        reserved.add((task, name.casefold()))
        names.append((task, source, stage, name))
    return names


def export_images(plan, skipped, tray, scan_root, output, args, patterns, stop_check):
    review, debug_root = validate_output(tray, output, args.debug)
    output.mkdir(parents=True, exist_ok=True)
    for task in TASKS:
        (output / task).mkdir()
    settings = dict(
        format_version=1, dataset_kind="untagged", labels_present=False, uses_csv=False,
        original_tray=str(tray), scan_root=str(scan_root), stage=args.stage,
        capture_patterns={t: p.pattern for t, p in patterns.items()},
        spatial_resize=False, output_bit_depth=args.output_depth,
        vig_brightness=engine.VIG_BRIGHTNESS_ENABLED and not args.no_vig_brightness,
        vig_target=engine.VIG_TARGET_LEVEL, vig_percentile=engine.VIG_REFERENCE_PERCENTILE,
        uint16_white_level=args.white_level or 65535,
        top_margin=engine.TOP_OFFSET_RATIO, bottom_margin=engine.BOTTOM_OFFSET_RATIO,
        alignment_interpolation="linear", absolute_quarter_turn_orientation_normalization=False,
        review_folder=str(review), debug_folder=str(debug_root) if args.debug else None,
        engine_sha256=hashlib.sha256(Path(engine.__file__).read_bytes()).hexdigest(),
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    (output / "preparation.json").write_text(json.dumps(settings, indent=2), encoding="utf-8")
    counts, failures, review_copy_failures, black_images = Counter(), 0, 0, 0
    destinations = allocate_names(plan, tray)
    with (output / "processing.jsonl").open("x", encoding="utf-8") as log:
        for record in skipped:
            log.write(json.dumps(record) + "\n")
        for number, (task, source, stage, name) in enumerate(destinations, 1):
            if stop_check():
                print("STOPPED: remaining images were not processed.", flush=True)
                break
            record = dict(task=task, source=str(source.relative_to(tray)), capture_stage=stage,
                          destination=str(Path(task) / name))
            try:
                image, metadata, overlay = engine.prepare_one(
                    source, task, brightness=settings["vig_brightness"], white_level=args.white_level,
                    debug=args.debug, output_depth=args.output_depth)
                engine.write_png(output / task / name, image)
                record.update(status="ok", **metadata)
                counts[task] += 1
                if task == "vig" and metadata["all_black"]:
                    black_images += 1
                    print(f"WARNING all-black VIG image retained: {source.name}", flush=True)
                if overlay is not None:
                    try:
                        engine.write_png(debug_root / task / name, overlay)
                    except (ValueError, OSError, cv2.error) as exc:
                        record["debug_error"] = str(exc)
                        print(f"WARNING debug overlay could not be saved: {exc}", flush=True)
                print(f"[{number}/{len(destinations)}] {task}: {name} "
                      f"{image.shape[1]}x{image.shape[0]} {image.dtype}", flush=True)
            except (ValueError, OSError, cv2.error) as exc:
                failures += 1
                record.update(status="failed", error=str(exc))
                print(f"FAILED {task}: {source.name}: {exc}", flush=True)
                review_file = review / task / (Path(name).stem + source.suffix)
                try:
                    review_file.parent.mkdir(parents=True, exist_ok=True)
                    with source.open("rb") as src, review_file.open("xb") as dst:
                        shutil.copyfileobj(src, dst)
                    record["review_original"] = str(review_file)
                except OSError as copy_error:
                    review_copy_failures += 1
                    record["review_copy_error"] = str(copy_error)
            log.write(json.dumps(record) + "\n")
            log.flush()
    return counts, failures, review_copy_failures, black_images


def run(args):
    try:
        if args.tray is None:
            raise ValueError("Choose the original tester folder with --tray for untagged preparation.")
        tray = args.tray.expanduser().resolve()
        if not tray.is_dir():
            raise ValueError(f"Tester folder does not exist: {tray}")
        output = args.output.expanduser().resolve()
        review, debug_root = validate_output(tray, output, args.debug, require_empty=not args.dry_run)
        patterns = compile_patterns({task: getattr(args, task + "_pattern") for task in TASKS})
        stop_check = lambda: bool(args.stop_file and args.stop_file.exists())
        scan_root, plan, skipped = scan_images(tray, patterns, args.stage, stop_check)
        if not plan and not stop_check():
            raise ValueError("No matching tester captures. Check filenames, capture patterns and stage selection.")
        selected = Counter(task for task, _, _ in plan)
        print(f"Scan root: {scan_root}", flush=True)
        print(f"Selected captures: {dict(selected)}; skipped images: {len(skipped)}", flush=True)
        failures = review_copy_failures = black_images = 0
        if args.dry_run:
            counts = selected
            print("DRY RUN: filenames only; geometry and pixel conversion not evaluated. No images written.")
        else:
            counts, failures, review_copy_failures, black_images = export_images(
                plan, skipped, tray, scan_root, output, args, patterns, stop_check)
        cancelled = stop_check()
        summary = dict(
            dataset_kind="untagged", labels_present=False, counts={task: counts[task] for task in TASKS},
            failed_images=failures, review_copy_failures=review_copy_failures,
            all_black_vig_images=black_images, skipped_images=len(skipped),
            skipped_reasons=dict(Counter(r["reason"] for r in skipped)),
            total_images=len(plan), processed_images=0 if args.dry_run else sum(counts.values()) + failures,
            dry_run=args.dry_run, cancelled=cancelled, complete=not (failures or cancelled),
            output=str(output), original_tray=str(tray), scan_root=str(scan_root), stage=args.stage,
            review_folder=str(review), debug_folder=str(debug_root) if args.debug else None)
        if not args.dry_run:
            (output / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        if args.report:
            args.report.parent.mkdir(parents=True, exist_ok=True)
            args.report.write_text(json.dumps(summary, indent=2), encoding="utf-8")
        if cancelled:
            return 130
        if failures:
            print(f"INCOMPLETE: {failures} processing failures. Review originals in {review}.")
            return 2
        print("Completed. Originals were not modified. No good/bad labels were assigned.")
        return 0
    except (OSError, ValueError, cv2.error) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
