"""ONNX dependency checks in the exact interpreter running the exporter."""
from __future__ import annotations

import importlib
from pathlib import Path
import sys
import threading

_export_lock = threading.RLock()


def export_onnx(model, sample, path, **options):
    """Export fixed-geometry models, retaining ATen's antialiased resize kernel.

    The legacy exporter has no symbolic for bicubic/bilinear AA. A separable
    linear resampler can be represented by two standard ONNX MatMul nodes.
    We derive its constant axis weights from the installed ATen implementation,
    including boundary handling, align_corners and fractional scale factors.
    No model weights, forward methods or training preprocessing are changed.
    """
    import torch
    from torch.onnx import symbolic_helper as helper
    from torch.onnx._internal import registration

    opset = int(options.get("opset_version", 17))
    if options.get("dynamic_axes"):
        raise ValueError("This package exporter requires fixed input geometry.")
    resize_names = ("aten::_upsample_bicubic2d_aa", "aten::_upsample_bilinear2d_aa")
    reshape_names = ("aten::reshape", "aten::view", "aten::_unsafe_view")
    names = resize_names + reshape_names
    used = []
    reshapes = []
    fallbacks = {}
    geometry_tables = []

    def fixed_reshape(name):
        def reshape(g, value, shape):
            traced = helper._get_tensor_sizes(list(g.original_node.outputs())[0])
            if traced is not None and all(isinstance(d, int) and d > 0 for d in traced):
                reshapes.append(list(traced))
                return g.op("Reshape", value, g.op("Constant", value_t=torch.tensor(traced, dtype=torch.int64))).setType(
                    list(g.original_node.outputs())[0].type())
            if fallbacks[name] is None:
                raise ValueError("Cannot resolve reshape geometry for this fixed input.")
            return fallbacks[name](g, value, shape)
        return reshape

    def symbolic(name):
        def resize(g, value, output_size, align_corners, scales_h=None, scales_w=None):
            shape = helper._get_tensor_sizes(value)
            # EVA obtains the patch grid through Shape/Gather, even in a fixed
            # input export. The original ATen node retains its traced geometry.
            # Do not guess a grid or resize the input image to avoid this node.
            original = g.original_node
            if shape is None or any(d is None for d in shape[-2:]):
                shape = helper._get_tensor_sizes(list(original.inputs())[0])
            try:
                size = helper._parse_arg(output_size, "is")
            except torch.onnx.errors.SymbolicValueError:
                traced = helper._get_tensor_sizes(list(original.outputs())[0])
                if traced is None or len(traced) != 4 or any(d is None for d in traced[-2:]):
                    raise ValueError("Cannot resolve antialiased resize output geometry for this fixed input.") from None
                size = traced[-2:]
            align = helper._parse_arg(align_corners, "b")
            if size is None:
                sy, sx = helper._parse_arg(scales_h, "fs")
            else:
                sy, sx = (helper._parse_arg(s, "f") for s in (scales_h, scales_w))
            if shape is None or len(shape) != 4 or any(not isinstance(d, int) or d <= 0 for d in shape[-2:]):
                raise ValueError("Antialiased ONNX resize requires fixed positive spatial dimensions.")
            if size is None:
                size = [int(shape[-2] * sy), int(shape[-1] * sx)]
            if len(size) != 2 or any(d <= 0 for d in size):
                raise ValueError("Antialiased ONNX resize requires a fixed positive output size.")
            scalar = value.type().scalarType()
            dtype = {"Float": torch.float32, "Double": torch.float64}.get(scalar)
            if dtype is None:
                raise ValueError("Antialiased ONNX resize requires float32 or float64 inputs.")
            native = getattr(torch.ops.aten, name.split("::")[1]).default
            h, w = shape[-2:]
            with torch.inference_mode():
                # Channels encode unit impulses, one per coordinate on each axis.
                horizontal = native(torch.eye(w, dtype=dtype).reshape(1, w, 1, w),
                                    [1, size[1]], align, None, sx)[0, :, 0, :]
                vertical = native(torch.eye(h, dtype=dtype).reshape(1, h, 1, h),
                                  [1, size[0]], align, None, sy)[0, :, 0, :]
            used.append({"operator": name, "input_size": [h, w], "output_size": size,
                         "align_corners": align, "scale_factors": [sy, sx]})
            width_result = g.op("MatMul", value, g.op("Constant", value_t=horizontal.contiguous()))
            transposed = g.op("Transpose", width_result, perm_i=[0, 1, 3, 2])
            height_result = g.op("MatMul", transposed, g.op("Constant", value_t=vertical.contiguous()))
            return g.op("Transpose", height_result, perm_i=[0, 1, 3, 2]).setType(
                value.type().with_sizes([shape[0], shape[1], size[0], size[1]]))
        return resize

    # Registration is scoped and restored even after a failed export. The lock
    # serializes exports made through this entry point in the same process.
    with _export_lock:
        previous = {}
        for name in names:
            group = registration.registry.get_function_group(name)
            fallbacks[name] = group.get(opset) if group else None
            previous[name] = (group._functions.get(opset) if group and group._functions.overridden(opset) else None)
            torch.onnx.register_custom_op_symbolic(name, symbolic(name) if name in resize_names else fixed_reshape(name), opset)
        try:
            restored_methods = []
            seen = set()
            # EVA's RoPE table depends only on the patch grid and model state.
            # Compute it with native Torch for each traced grid, retaining its
            # exact frequencies instead of ONNX re-evaluating dynamic geometry.
            # This also supports a shared core seeing global and local patches.
            for module_name, module in model.named_modules():
                if not type(module).__module__.startswith("timm.models.eva"):
                    continue
                rope = getattr(module, "rope", None)
                if rope is None or id(rope) in seen or not callable(getattr(rope, "get_embed", None)):
                    continue
                seen.add(id(rope))
                original_method = rope.get_embed
                had_method = "get_embed" in rope.__dict__
                restored_methods.append((rope, original_method, had_method))

                def frozen_embed(shape=None, *, original=original_method, name=module_name):
                    tracing = torch._C._get_tracing_state()
                    torch._C._set_tracing_state(None)
                    try:
                        grid = tuple(int(d) for d in shape) if shape is not None else None
                        with torch.no_grad():
                            result = original(grid).detach()
                        entry = {"module": name, "grid": list(grid) if grid else None, "shape": list(result.shape)}
                        if entry not in geometry_tables:
                            geometry_tables.append(entry)
                        return result
                    finally:
                        torch._C._set_tracing_state(tracing)

                rope.get_embed = frozen_embed
            torch.onnx.export(model, sample, str(path), **options)
        finally:
            for rope, original_method, had_method in restored_methods:
                if had_method:
                    rope.get_embed = original_method
                else:
                    delattr(rope, "get_embed")
            for name in names:
                torch.onnx.unregister_custom_op_symbolic(name, opset)
                if previous[name] is not None:
                    torch.onnx.register_custom_op_symbolic(name, previous[name], opset)
    return {"antialias_export": "aten_separable_weights.v1", "antialias_resizes": used,
            "fixed_reshape_count": len(reshapes), "geometry_tables": geometry_tables, "opset": opset}


def export_dependencies():
    modules = []
    for name in ("onnx", "onnxruntime"):
        try:
            modules.append(importlib.import_module(name))
        except Exception as error:
            requirements = Path(__file__).resolve().parent.parent / "requirements-export.txt"
            missing = isinstance(error, ModuleNotFoundError) and error.name == name
            reason = "is missing" if missing else "is installed but cannot load"
            raise RuntimeError(
                f"ONNX dependency {name} {reason} in {sys.executable}. "
                f"Original error: {type(error).__name__}: {error}\n"
                "Close the dashboard, run Setup-Export.cmd from this extracted project, then restart Start.cmd. "
                "It repairs the environment recorded by Start.cmd, without reinstalling PyTorch. "
                f'Alternatively run: "{sys.executable}" -m pip install --upgrade -r "{requirements}". '
                "On Windows, a DLL load failure may require the Microsoft Visual C++ x64 runtime; "
                "see docs/EXPORT_AND_VIEWER_FIXES.md."
            ) from error
    modules[1].disable_telemetry_events()
    if "CPUExecutionProvider" not in modules[1].get_available_providers():
        raise RuntimeError("The installed ONNX Runtime has no CPUExecutionProvider. Run Setup-Export.cmd.")
    return tuple(modules)
