#!/usr/bin/env sh
set -eu
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$script_dir/.."
if [ -x .venv/bin/python ]; then
  exec .venv/bin/python segmentation.py annotate --config project.yaml "$@"
fi
exec python3 segmentation.py annotate --config project.yaml "$@"
