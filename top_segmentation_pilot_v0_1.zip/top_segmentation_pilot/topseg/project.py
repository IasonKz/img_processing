"""Working image copies, revisioned human review, and frozen training datasets."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import re
import shutil
import uuid

import numpy as np
from PIL import Image

from .common import (CLASSES, DEFAULTS, EXTENSIONS, atomic_json, merge, project_lock,
                     read_json, read_rgb, safe_path, sha256, utc_now)
from .classical import default_roi, suggest, validate_roi, validate_settings


class ConflictError(ValueError):
    """An annotation changed since the editor loaded its revision."""


class Project:
    def __init__(self, cfg):
        self.cfg = merge(DEFAULTS, cfg)
        self.root = Path(self.cfg['project_dir']).resolve()
        self.source = Path(self.cfg['input_dir']).resolve()
        if self.root.is_relative_to(self.source) or self.source.is_relative_to(self.root):
            raise ValueError('Input and project must be separate directory trees.')
        self.root.mkdir(parents=True, exist_ok=True)
        if not (self.root / 'project.json').exists():
            with project_lock(self.root):
                if not (self.root / 'project.json').exists():
                    atomic_json(self.root / 'project.json', {
                        'schema_version': 1, 'name': self.cfg['name'], 'task': 'top',
                        'created_at': utc_now(), 'classes': CLASSES,
                        'group_regex': self.cfg.get('group_regex'), 'images': []})
        self._manifest()

    def _manifest(self):
        manifest = read_json(self.root / 'project.json')
        if manifest['schema_version'] != 1 or manifest['classes'] != CLASSES:
            raise ValueError('Unsupported project schema or class mapping.')
        if manifest.get('group_regex') != self.cfg.get('group_regex'):
            raise ValueError('Changing group_regex requires a separate annotation project; existing unit assignments are fixed.')
        return manifest

    def _row(self, image_id):
        if not isinstance(image_id, str) or not re.fullmatch('[a-f0-9]{24}', image_id):
            raise ValueError('Invalid image identifier.')
        for row in self._manifest()['images']:
            if row['id'] == image_id:
                return row
        raise KeyError(f'Unknown image: {image_id}')

    def _annotation(self, image_id):
        path = self.root / 'annotations' / f'{image_id}.json'
        return read_json(path) if path.exists() else None

    def import_images(self):
        if not self.source.is_dir():
            raise FileNotFoundError(f'Input directory not found: {self.source}')
        with project_lock(self.root):
            manifest = self._manifest()
            known = {row['pixel_sha256']: row for row in manifest['images']}
            ids = {row['id'] for row in manifest['images']}
            aliases = {alias: row for row in manifest['images'] for alias in row.get('source_aliases', [row['relative_path']])}
            regex = re.compile(self.cfg['group_regex']) if self.cfg.get('group_regex') else None
            added, duplicate, invalid = [], [], []
            for path in sorted(self.source.rglob('*')):
                if not path.is_file() or path.suffix.lower() not in EXTENSIONS:
                    continue
                relative = path.relative_to(self.source).as_posix()
                try:
                    if not path.resolve().is_relative_to(self.source):
                        raise ValueError('Image symlink points outside the input directory.')
                    original_hash = sha256(path)
                    image = read_rgb(path, self.cfg['max_image_pixels'])
                    if sha256(path) != original_hash:
                        raise ValueError('Source changed during import; retry after acquisition finishes.')
                    pixel_hash = hashlib.sha256(f'{image.width}x{image.height}\0'.encode() + image.tobytes()).hexdigest()
                    image_id = pixel_hash[:24]
                    group = 'pixel:' + pixel_hash
                    if regex:
                        match = regex.search(relative)
                        if not match:
                            raise ValueError('group_regex did not match this relative path.')
                        group = match.groupdict().get('unit') or match.group(1)
                        if not group:
                            raise ValueError('group_regex produced an empty unit identifier.')
                    if relative in aliases and aliases[relative]['pixel_sha256'] != pixel_hash:
                        raise ValueError('A previously imported source path now contains different pixels. Use a new filename for a new acquisition.')
                    if pixel_hash in known:
                        row = known[pixel_hash]
                        if row['group'] != group:
                            raise ValueError('Identical pixels assigned to different units; resolve the duplicate before import.')
                        if relative not in row['source_aliases']:
                            row['source_aliases'].append(relative)
                        aliases[relative] = row
                        duplicate.append(relative)
                        continue
                    if image_id in ids:
                        raise ValueError('Image identifier collision; import aborted for this image.')
                    destination = self.root / 'images' / (image_id + '.png')
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    temp = destination.with_suffix('.png.tmp')
                    image.save(temp, format='PNG')
                    temp.replace(destination)
                    row = {'id': image_id, 'relative_path': relative, 'source_aliases': [relative],
                           'source_sha256': original_hash, 'pixel_sha256': pixel_hash,
                           'image': destination.relative_to(self.root).as_posix(),
                           'image_sha256': sha256(destination), 'width': image.width,
                           'height': image.height, 'group': group, 'imported_at': utc_now()}
                    manifest['images'].append(row)
                    known[pixel_hash], aliases[relative] = row, row
                    ids.add(image_id)
                    added.append(relative)
                except (ValueError, OSError, Image.DecompressionBombError) as exc:
                    invalid.append({'relative_path': relative, 'error': str(exc)})
            manifest['updated_at'] = utc_now()
            atomic_json(self.root / 'project.json', manifest)
            report = {'imported': len(added), 'duplicates_or_existing': len(duplicate),
                      'invalid': invalid, 'total_images': len(manifest['images']), 'at': utc_now()}
            atomic_json(self.root / 'import_report.json', report)
            return report

    def items(self):
        result = []
        for row in self._manifest()['images']:
            annotation = self._annotation(row['id'])
            result.append({**row, 'status': annotation['status'] if annotation else 'unannotated',
                           'revision': annotation['revision'] if annotation else 0,
                           'clean': annotation.get('clean', False) if annotation else False,
                           'statistics': annotation.get('statistics', {}) if annotation else {}})
        return result

    def image_path(self, image_id):
        row = self._row(image_id)
        path = safe_path(self.root, row['image'])
        if sha256(path) != row['image_sha256']:
            raise ValueError('Working image changed after import; restore its verified copy.')
        return path

    def mask_path(self, image_id):
        self._row(image_id)
        annotation = self._annotation(image_id)
        if annotation is None:
            return None
        path = safe_path(self.root, annotation['mask'])
        if sha256(path) != annotation['mask_sha256']:
            raise ValueError('Saved mask checksum mismatch; restore the annotation revision.')
        return path

    def open_image(self, image_id):
        row = self._row(image_id)
        self.image_path(image_id)
        if self._annotation(image_id) is None:
            try:
                self.propose(image_id, expected_revision=0)
            except ConflictError:
                pass
        annotation = self._annotation(image_id)
        self.mask_path(image_id)
        return {**row, **annotation}

    def save_annotation(self, image_id, mask, roi=None, expected_revision=0,
                        approved=False, clean=False, notes='', settings=None, origin='manual'):
        with project_lock(self.root):
            return self._save(image_id, mask, roi, expected_revision, approved, clean, notes, settings, origin)

    def _save(self, image_id, mask, roi, expected_revision, approved, clean, notes, settings, origin, proposal_statistics=None):
        row = self._row(image_id)
        self.image_path(image_id)
        previous = self._annotation(image_id)
        current_revision = previous['revision'] if previous else 0
        if isinstance(expected_revision, bool) or not isinstance(expected_revision, int) or expected_revision != current_revision:
            raise ConflictError('Annotation changed in another tab or process. Reload this image before saving.')
        if not isinstance(approved, bool) or not isinstance(clean, bool):
            raise ValueError('approved and clean must be booleans.')
        values = np.asarray(mask)
        if values.shape != (row['height'], row['width']) or values.dtype.kind not in ('i', 'u'):
            raise ValueError('Mask must be an integer array matching the native image dimensions.')
        if not np.isin(values, [0, 1, 2]).all():
            raise ValueError('Mask labels must be 0=background, 1=inner or 2=outer.')
        is_empty = not bool(np.any(values))
        if approved and is_empty and not clean:
            raise ValueError('Use Approve clean to explicitly confirm an image with no defects.')
        if clean and not is_empty:
            raise ValueError('A clean annotation must contain no defect pixels.')
        if not isinstance(notes, str) or len(notes) > 10000:
            raise ValueError('Annotation notes must be text with at most 10000 characters.')
        if origin not in ('manual', 'classical'):
            raise ValueError('Annotation origin must be manual or classical.')
        roi = validate_roi(roi if roi is not None else (previous or {}).get('roi'), row['width'], row['height'])
        settings = validate_settings(settings if settings is not None else (previous or {}).get('settings', self.cfg['classical']))
        revision = current_revision + 1
        revision_dir = self.root / 'history' / image_id / f'{revision:06d}'
        # A failed write can leave an unreferenced revision. Keep it for inspection
        # and allocate a new directory instead of overwriting any annotation history.
        while revision_dir.exists():
            revision += 1
            revision_dir = self.root / 'history' / image_id / f'{revision:06d}'
        revision_dir.mkdir(parents=True)
        mask_path = revision_dir / 'mask.png'
        Image.fromarray(values.astype(np.uint8)).save(mask_path)
        statistics = {'background_pixels': int((values == 0).sum()),
                      'inner_pixels': int((values == 1).sum()), 'outer_pixels': int((values == 2).sum())}
        if proposal_statistics:
            statistics['proposal'] = proposal_statistics
        annotation = {'id': image_id, 'revision': revision, 'status': 'approved' if approved else 'draft',
                      'approved': approved, 'clean': bool(clean and approved),
                      'mask': mask_path.relative_to(self.root).as_posix(), 'mask_sha256': sha256(mask_path),
                      'image_sha256': row['image_sha256'], 'roi': roi, 'settings': settings,
                      'statistics': statistics, 'origin': origin, 'notes': notes,
                      'updated_at': utc_now(), 'approved_at': utc_now() if approved else None}
        atomic_json(revision_dir / 'annotation.json', annotation)
        atomic_json(self.root / 'annotations' / f'{image_id}.json', annotation)
        return {**row, **annotation}

    def propose(self, image_id, roi=None, settings=None, expected_revision=0):
        row = self._row(image_id)
        previous = self._annotation(image_id) or {}
        selected_roi = validate_roi(roi if roi is not None else previous.get('roi'), row['width'], row['height'])
        selected_settings = validate_settings(settings if settings is not None else previous.get('settings', self.cfg['classical']))
        # Filtering happens outside the lock. Optimistic revision checking below
        # prevents a slow proposal from replacing edits saved in the meantime.
        mask, statistics = suggest(read_rgb(self.image_path(image_id), self.cfg['max_image_pixels']), selected_roi, selected_settings)
        with project_lock(self.root):
            return self._save(image_id, mask, selected_roi, expected_revision, False, False,
                              previous.get('notes', ''), selected_settings, 'classical', statistics)

    def snapshot(self, output):
        output = Path(output).resolve()
        if (output.is_relative_to(self.root) or self.root.is_relative_to(output) or
                output.is_relative_to(self.source) or self.source.is_relative_to(output)):
            raise ValueError('Dataset snapshot must be outside both input and annotation project trees.')
        if output.exists() and any(output.iterdir()):
            raise FileExistsError('Dataset output must be new or empty.')
        with project_lock(self.root):
            approved = [(row, self._annotation(row['id'])) for row in self._manifest()['images']]
            approved = [(row, annotation) for row, annotation in approved if annotation and annotation['status'] == 'approved']
            if not approved:
                raise ValueError('No reviewed annotations. Approve defects or explicitly approve clean images first.')
            output.mkdir(parents=True, exist_ok=True)
            records = []
            try:
                for row, annotation in approved:
                    image_path, mask_path = self.image_path(row['id']), self.mask_path(row['id'])
                    with Image.open(mask_path) as source:
                        mask = np.asarray(source)
                    if mask.shape != (row['height'], row['width']) or not np.isin(mask, [0, 1, 2]).all():
                        raise ValueError('Approved mask has invalid dimensions or labels.')
                    revision_path = safe_path(self.root, annotation['mask']).parent / 'annotation.json'
                    if read_json(revision_path) != annotation:
                        raise ValueError('Current annotation differs from its immutable revision record.')
                    if annotation['image_sha256'] != row['image_sha256']:
                        raise ValueError('Annotation belongs to a different image version.')
                    if not np.any(mask) and not annotation['clean']:
                        raise ValueError('Empty annotation lacks explicit clean approval.')
                    image_rel, mask_rel = f'images/{row["id"]}.png', f'masks/{row["id"]}.png'
                    for source, relative in ((image_path, image_rel), (mask_path, mask_rel)):
                        destination = output / relative
                        destination.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(source, destination)
                    records.append({'id': row['id'], 'group': row['group'], 'image': image_rel, 'mask': mask_rel,
                                    'width': row['width'], 'height': row['height'], 'annotation_revision': annotation['revision'],
                                    'clean': annotation['clean'], 'image_sha256': row['image_sha256'],
                                    'mask_sha256': annotation['mask_sha256'], 'pixel_sha256': row['pixel_sha256']})
                fingerprint = hashlib.sha256(json.dumps(records, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
                result = {'schema_version': 1, 'created_at': utc_now(), 'classes': CLASSES,
                          'task': 'top', 'fingerprint': fingerprint, 'records': records,
                          'grouping': 'regex' if self.cfg.get('group_regex') else 'pixel_identity',
                          'note': 'Only explicitly approved annotations; background-only images require clean approval.'}
                atomic_json(output / 'dataset.json', result)
                return output / 'dataset.json'
            except Exception as exc:
                atomic_json(output / 'snapshot_failed.json', {'error': str(exc), 'at': utc_now()})
                raise
