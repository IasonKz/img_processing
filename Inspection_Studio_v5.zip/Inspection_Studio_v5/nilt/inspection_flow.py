"""Frozen, ordered inspection workflows built from saved model decisions.

``create_workflow`` returns a workflow.json path. ``load_workflow`` returns
``(record, validated_stages)``. ``run_workflow`` returns a new result directory.
Stages vote using their own frozen thresholds; cross-model scores are never
averaged. Changing stage order, models, thresholds or the rule creates a new
workflow version. Referenced training runs must remain available.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import time

import numpy as np

from .common import read_json, sha_file, write_csv, write_json
from .decisions import UNQUALIFIED, _audit_inputs, _new_folder, load_decision
from .runtime import safe_asset

FORMAT = "inspection_workflow_v4"
RULES = ("any_bad", "all_bad", "majority")
MAX_STAGES = 32


def aggregate_votes(votes, rule):
    """Combine a complete list of binary stage decisions; ties reject."""
    if rule not in RULES:
        raise ValueError("Unknown workflow rule: " + str(rule))
    votes = list(votes)
    if not votes or any(v not in ("good", "bad") for v in votes):
        raise ValueError("Workflow votes must be a nonempty sequence of good/bad decisions.")
    bad = votes.count("bad")
    rejected = (bad > 0 if rule == "any_bad" else
                bad == len(votes) if rule == "all_bad" else bad * 2 >= len(votes))
    return "bad" if rejected else "good"


def _name(value, default):
    value = default if value is None else value
    if not isinstance(value, str) or not value.strip() or len(value) > 160 or any(ord(c) < 32 for c in value):
        raise ValueError("Workflow and stage names must be nonempty text of at most 160 characters.")
    return value.strip()


def _decision_path(value):
    if not isinstance(value, (str, Path)) or not str(value):
        raise ValueError("Each stage must reference a saved decision.json.")
    path = Path(value).resolve()
    return path / "decision.json" if path.is_dir() else path


def _reference(path, root):
    # A source run is an explicitly selected dependency, not a contained asset.
    # Keeping relative references allows the run/workflow tree to move together.
    try:
        return {"kind": "relative", "path": Path(os.path.relpath(path, root)).as_posix()}
    except ValueError:  # Different Windows drives.
        return {"kind": "absolute", "path": str(path)}


def _resolve_reference(reference, root):
    if not isinstance(reference, dict) or not isinstance(reference.get("path"), str) or not reference["path"]:
        raise ValueError("Invalid workflow source-run reference.")
    value = Path(reference["path"])
    if reference.get("kind") == "relative" and not value.is_absolute():
        return (root / value).resolve()
    if reference.get("kind") == "absolute" and value.is_absolute():
        return value.resolve()
    raise ValueError("Invalid workflow source-run reference kind.")


def create_workflow(definition, output_root="workflows"):
    """Validate a specification and save an immutable workflow in a new folder.

    Specification: ``{name, rule, task?, stages: [{name?, decision}]}``.
    ``decision`` paths identify existing frozen decisions. Their exact bytes and
    integrity sidecars are copied into contained assets; no checkpoint is copied.
    """
    if not isinstance(definition, dict) or set(definition) - {"name", "rule", "task", "stages"}:
        raise ValueError("Workflow fields are name, rule, task and stages.")
    rule = definition.get("rule")
    if rule not in RULES:
        raise ValueError("Choose one workflow rule: " + ", ".join(RULES))
    specifications = definition.get("stages")
    if not isinstance(specifications, list) or not 1 <= len(specifications) <= MAX_STAGES:
        raise ValueError(f"A workflow requires between 1 and {MAX_STAGES} stages.")
    loaded, protected, names, fingerprints = [], [], set(), set()
    for index, stage in enumerate(specifications):
        if not isinstance(stage, dict) or set(stage) - {"name", "decision"}:
            raise ValueError("Stage fields are name and decision; save a new decision to change its threshold.")
        name = _name(stage.get("name"), f"Stage {index + 1}")
        if name in names:
            raise ValueError("Stage names must be unique.")
        names.add(name)
        path = _decision_path(stage.get("decision"))
        record, run, cfg, chosen = load_decision(path)
        if record["mode"] == "scores_only":
            raise ValueError("scores_only decisions cannot vote in an inspection workflow.")
        fingerprint = sha_file(path)
        if fingerprint in fingerprints:
            raise ValueError("The same decision cannot be counted as two workflow stages.")
        fingerprints.add(fingerprint)
        loaded.append((name, path, record, run, cfg, chosen, fingerprint))
        protected.extend((run, path.parent, cfg.get("data_root")))
    tasks = {item[2]["task"] for item in loaded}
    if len(tasks) != 1 or (definition.get("task") is not None and definition["task"] not in tasks):
        raise ValueError("All workflow decisions must belong to the same inspection task.")
    name = _name(definition.get("name"), "Inspection workflow")
    out = _new_folder(output_root, protected)
    try:
        stages = []
        for index, (stage_name, source, decision, run, cfg, chosen, digest) in enumerate(loaded):
            folder = out / "stages" / f"{index:04d}"
            folder.mkdir(parents=True)
            copied = folder / "decision.json"
            shutil.copy2(source, copied)
            shutil.copy2(source.with_name("decision_integrity.json"), folder / "decision_integrity.json")
            if sha_file(copied) != digest:
                raise ValueError("Source decision changed while the workflow was being saved.")
            stages.append({"index": index, "name": stage_name,
                           "decision_file": copied.relative_to(out).as_posix(), "decision_sha256": digest,
                           "source_decision": str(source), "run_reference": _reference(run, out),
                           "candidate": chosen["name"], "task": decision["task"], "kind": decision["kind"],
                           "mode": decision["mode"], "threshold": decision["threshold"],
                           "score_type": decision["score_type"]})
        record = {"format": FORMAT, "created_utc": datetime.now(timezone.utc).isoformat(),
                  "name": name, "task": next(iter(tasks)), "rule": rule, "tie_break": "bad",
                  "stages": stages, "qualification_status": UNQUALIFIED,
                  "note": "Frozen decision workflow. Reference-label metrics are descriptive; the combined system requires independent validation."}
        path = out / "workflow.json"
        write_json(path, record)
        write_json(out / "workflow_integrity.json", {"format": FORMAT, "workflow_sha256": sha_file(path)})
        load_workflow(path)
        return path
    except BaseException:
        # Only this call's new directory is removed; never touch dependencies.
        shutil.rmtree(out, ignore_errors=True)
        raise


def load_workflow(path):
    """Verify the recipe, contained decisions, source fingerprints and models."""
    path = Path(path).resolve()
    if path.is_dir():
        path /= "workflow.json"
    integrity = read_json(safe_asset(path.parent, "workflow_integrity.json"))
    path = safe_asset(path.parent, path.name)
    if integrity.get("format") != FORMAT or sha_file(path) != integrity.get("workflow_sha256"):
        raise ValueError("Workflow checksum mismatch. Save a new version instead of editing workflow.json.")
    record = read_json(path)
    if (record.get("format") != FORMAT or record.get("rule") not in RULES or
            record.get("tie_break") != "bad" or record.get("qualification_status") != UNQUALIFIED):
        raise ValueError("Unsupported workflow format or decision rule.")
    stages = record.get("stages")
    if not isinstance(stages, list) or not 1 <= len(stages) <= MAX_STAGES:
        raise ValueError("Invalid workflow stage count.")
    verified, seen, names = [], set(), set()
    for index, stage in enumerate(stages):
        if not isinstance(stage, dict) or stage.get("index") != index:
            raise ValueError("Workflow stages have an invalid order.")
        name = _name(stage.get("name"), f"Stage {index + 1}")
        if name in names:
            raise ValueError("Stage names must be unique.")
        names.add(name)
        asset = safe_asset(path.parent, stage["decision_file"])
        if sha_file(asset) != stage.get("decision_sha256"):
            raise ValueError("Workflow stage decision checksum mismatch.")
        if stage["decision_sha256"] in seen:
            raise ValueError("Duplicate workflow decision.")
        seen.add(stage["decision_sha256"])
        run = _resolve_reference(stage["run_reference"], path.parent)
        decision, run, cfg, chosen = load_decision(asset, run_override=run)
        if decision["mode"] == "scores_only" or decision["task"] != record.get("task"):
            raise ValueError("Incompatible workflow decision mode or inspection task.")
        for key in ("task", "kind", "mode", "threshold", "score_type"):
            if stage.get(key) != decision.get(key):
                raise ValueError("Workflow stage metadata disagrees with its saved decision: " + key)
        if stage.get("candidate") != chosen["name"]:
            raise ValueError("Workflow candidate identity mismatch.")
        verified.append({"index": index, "name": name, "decision_path": asset,
                         "decision_sha256": stage["decision_sha256"],
                         "record": decision, "run": run, "cfg": cfg, "chosen": chosen})
    return record, verified


def _trace(stage, status="pending", score=None, predicted=None, reason=""):
    record = stage["record"]
    return {"index": stage["index"], "name": stage["name"], "candidate": stage["chosen"]["name"],
            "decision_sha256": stage["decision_sha256"], "mode": record["mode"],
            "threshold": record["threshold"], "score_type": record["score_type"],
            "score": score, "predicted_class": predicted, "status": status, "reason": reason}


def _reference_metrics(predictions):
    valid = [r for r in predictions if r["status"] == "ok" and r["true_class"] in ("good", "bad")]
    tp = sum(r["true_class"] == "bad" and r["predicted_class"] == "bad" for r in valid)
    fn = sum(r["true_class"] == "bad" and r["predicted_class"] == "good" for r in valid)
    fp = sum(r["true_class"] == "good" and r["predicted_class"] == "bad" for r in valid)
    tn = sum(r["true_class"] == "good" and r["predicted_class"] == "good" for r in valid)
    n, nb, ng = len(valid), tp + fn, tn + fp
    return {"n_images": n, "n_bad": nb, "n_good": ng, "bad_detected_TP": tp,
            "bad_passed_as_good_FN": fn, "good_rejected_as_bad_FP": fp, "good_accepted_TN": tn,
            "bad_escape_rate": fn / nb if nb else None, "good_reject_rate": fp / ng if ng else None,
            "bad_recall": tp / nb if nb else None, "good_accept_rate": tn / ng if ng else None,
            "accuracy": (tp + tn) / n if n else None,
            "balanced_accuracy": (tp / nb + tn / ng) / 2 if nb and ng else None,
            "accepted_contamination": fn / (fn + tn) if fn + tn else None,
            "bad_precision": tp / (tp + fp) if tp + fp else None,
            "majority_baseline_accuracy": max(nb, ng) / n if n else None,
            "always_good_accuracy": ng / n if n else None,
            "qualification_status": UNQUALIFIED,
            "note": "Descriptive image-level comparison against reference labels. No combined ranking score or independent qualification is inferred."}


def _source_overlap(rows, stages):
    from .data import read_manifest
    known = {}
    for run in {s["run"] for s in stages}:
        for row in read_manifest(run / "manifest.csv"):
            known.setdefault(row["pixel_hash"], set()).add(row["split"])
    counts = {name: 0 for name in ("train", "val", "threshold", "selection", "test")}
    matched = 0
    for row in rows:
        splits = known.get(row["pixel_sha256"], set())
        matched += bool(splits)
        for split in splits:
            counts[split] = counts.get(split, 0) + 1
    return {"matched_images": matched, "unmatched_images": len(rows) - matched, "by_split": counts,
            "holdout_status": "KNOWN_SOURCE_DATA_PRESENT" if matched else "INDEPENDENCE_NOT_ESTABLISHED",
            "note": "Exact decoded-pixel overlap only; unmatched images are not evidence of independent trays or units."}


def run_workflow(path, input_root, output_root="classified", labeled=False, device="cpu", copy_images=True):
    """Run a frozen recipe, returning a new output directory for review.

    Models are loaded one stage at a time. Resolved images are copied and streamed
    to review at stage boundaries; skipped stages have explicit trace records.
    Input failures never become good decisions. Originals are read but not edited.
    """
    from .workflow import predict_members
    from .review import initialize_session, append_prediction, update_progress, finish_session, input_fingerprint

    if device not in ("cpu", "cuda", "auto"):
        raise ValueError("Device must be cpu, cuda or auto.")
    workflow_path = Path(path).resolve()
    if workflow_path.is_dir():
        workflow_path /= "workflow.json"
    record, stages = load_workflow(workflow_path)
    source = Path(input_root).resolve()
    rows, invalid, duplicates = _audit_inputs(source, labeled, stages[0]["cfg"])
    if not rows:
        raise ValueError("No valid workflow input images. " + "; ".join(r["error"] for r in invalid[:3]))
    protected = [source, workflow_path.parent]
    for stage in stages:
        protected.extend((stage["run"], stage["cfg"].get("data_root")))
    out = _new_folder(output_root, protected)
    started = time.perf_counter()
    digest = sha_file(workflow_path)
    overlap = _source_overlap(rows, stages)
    for row in invalid:
        row["file_sha256"] = sha_file(row["path"])
    fingerprint = input_fingerprint(rows + invalid)
    metadata = {"workflow_name": record["name"], "workflow_sha256": digest,
                "workflow_path": str(workflow_path), "rule": record["rule"], "task": record["task"],
                "labeled": bool(labeled), "input_root": str(source), "input_fingerprint": fingerprint,
                "source_overlap": overlap,
                "qualification_status": UNQUALIFIED}
    initialize_session(out, kind="workflow", metadata=metadata, total=len(rows) + len(invalid))
    write_json(out / "applied_workflow.json", record)
    write_json(out / "summary.json", {**metadata, "status": "running"})
    traces = [[_trace(stage) for stage in stages] for _ in rows]
    votes = [[] for _ in rows]
    pending = list(range(len(rows)))
    predictions, stage_counts = [], []

    def publish(row, predicted, trace, *, status="ok", error=""):
        entry = {"relative_path": row["relative_path"], "true_class": row["true_class"],
                 "score": None, "score_type": "workflow_decision", "predicted_class": predicted,
                 "threshold": None, "decision_mode": "workflow_" + record["rule"],
                 "status": status, "error": error, "output_path": "", "stage_results": trace,
                 "file_sha256": row.get("file_sha256")}
        if status == "ok":
            if sha_file(row["path"]) != row["file_sha256"]:
                raise ValueError("Input changed during workflow inference: " + row["relative_path"])
            if copy_images:
                identity = hashlib.sha256(row["relative_path"].encode()).hexdigest()[:20]
                name = identity + "__" + Path(row["path"]).name[-100:]
                destination = out / "predicted" / predicted / name
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(row["path"], destination)
                if sha_file(destination) != row["file_sha256"]:
                    raise ValueError("Input changed while copying workflow result: " + row["relative_path"])
                entry["output_path"] = destination.relative_to(out).as_posix()
                if labeled and row["true_class"] != predicted:
                    errors = out / "errors" / (row["true_class"] + "_to_" + predicted)
                    errors.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(destination, errors / name)
        published = append_prediction(out, entry)
        predictions.append(entry)
        with (out / "stage_trace.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps({"relative_path": row["relative_path"], "predicted_class": predicted,
                                     "stage_results": trace}, ensure_ascii=False, allow_nan=False) + "\n")
        update_progress(out, completed=len(predictions))
        return published

    try:
        for row in invalid:
            publish(row, "", [_trace(s, "skipped", reason="invalid_input") for s in stages],
                    status="input_error", error=row["error"])
        for index, stage in enumerate(stages):
            update_progress(out, status="running", stage_index=index, stage_name=stage["name"],
                            stage_total=len(stages), pending_images=len(pending), phase="scoring_stage")
            if not pending:
                stage_counts.append({"index": index, "name": stage["name"], "evaluated": 0, "skipped": len(rows)})
                continue
            stage_rows = [rows[i] for i in pending]
            cfg = {**stage["cfg"], "device": device}
            scores, seconds = predict_members(stage["run"], stage["chosen"]["members"], stage_rows, cfg)
            scores = np.asarray(scores, dtype=float)
            if scores.shape != (len(pending),) or not np.isfinite(scores).all():
                raise ValueError("Workflow inference returned invalid scores: " + stage["name"])
            if stage["record"]["kind"] == "supervised" and np.any((scores < 0) | (scores > 1)):
                raise ValueError("Supervised bad scores must be in [0,1].")
            stage_predictions = ["bad" if score >= stage["record"]["threshold"] else "good" for score in scores]
            stage_result = {"index": index, "name": stage["name"], "evaluated": len(pending),
                            "skipped": len(rows) - len(pending), "inference_seconds": seconds,
                            "predicted_bad_rate": stage_predictions.count("bad") / len(pending),
                            "evaluation_scope": "Only images reaching this stage; not a full-dataset model comparison."}
            if labeled:
                stage_result["conditional_metrics"] = _reference_metrics([
                    {"status": "ok", "true_class": row["true_class"], "predicted_class": vote}
                    for row, vote in zip(stage_rows, stage_predictions)])
            stage_counts.append(stage_result)
            next_pending = []
            for row_index, score in zip(pending, scores):
                if sha_file(rows[row_index]["path"]) != rows[row_index]["file_sha256"]:
                    raise ValueError("Input changed during workflow inference: " + rows[row_index]["relative_path"])
                predicted = "bad" if score >= stage["record"]["threshold"] else "good"
                votes[row_index].append(predicted)
                traces[row_index][index] = _trace(stage, "evaluated", float(score), predicted)
                decisive = ((record["rule"] == "any_bad" and predicted == "bad") or
                            (record["rule"] == "all_bad" and predicted == "good"))
                if decisive or index == len(stages) - 1:
                    final = predicted if decisive else aggregate_votes(votes[row_index], record["rule"])
                    for later in range(index + 1, len(stages)):
                        traces[row_index][later] = _trace(stages[later], "skipped", reason="earlier_stage_resolved_decision")
                    publish(rows[row_index], final, traces[row_index])
                else:
                    next_pending.append(row_index)
            pending = next_pending
        if pending or len(predictions) != len(rows) + len(invalid):
            raise RuntimeError("Workflow did not resolve every input image.")
        # Deterministic final table; live stream retains completion order.
        predictions.sort(key=lambda r: r["relative_path"])
        flat = [{**r, "stage_results": json.dumps(r["stage_results"], ensure_ascii=False, allow_nan=False)} for r in predictions]
        write_csv(out / "predictions.csv", flat)
        write_csv(out / "invalid_images.csv", invalid, ["relative_path", "true_class", "error"])
        write_csv(out / "duplicate_images.csv", duplicates, ["original", "duplicate"])
        write_json(out / "scores.json", {"score_type": "workflow_decision", "aggregate_score": None,
                                        "predictions": predictions, "stage_counts": stage_counts})
        if labeled:
            met = _reference_metrics(predictions)
            met.update(invalid_excluded=len(invalid), exact_duplicate_count=len(duplicates), source_overlap=overlap)
            write_json(out / "metrics.json", met)
        status = "completed_with_input_errors" if invalid else "completed"
        elapsed = time.perf_counter() - started
        summary = {**metadata, "status": status, "created_utc": datetime.now(timezone.utc).isoformat(),
                   "valid_images": len(rows), "invalid_images": len(invalid), "exact_duplicate_count": len(duplicates),
                   "counts": {label: sum(p["predicted_class"] == label for p in predictions) for label in ("good", "bad")},
                   "stage_counts": stage_counts, "elapsed_seconds": elapsed,
                   "images_per_second": len(rows) / elapsed if elapsed else None,
                   "predictions_sha256": sha_file(out / "predictions.csv")}
        write_json(out / "summary.json", summary)
        finish_session(out, status=status, completed=len(predictions), summary=summary)
        return out
    except BaseException as error:
        status = "interrupted" if isinstance(error, (KeyboardInterrupt, SystemExit)) else "failed"
        failure = {**metadata, "status": status, "error": str(error), "error_type": type(error).__name__,
                   "completed_images": len(predictions), "elapsed_seconds": time.perf_counter() - started}
        write_json(out / "summary.json", failure)
        finish_session(out, status=status, completed=len(predictions), error=str(error))
        raise
