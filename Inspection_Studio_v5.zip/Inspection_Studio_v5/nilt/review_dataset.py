"""Versioned operator-confirmed exports with protected incremental lineage.

Prediction scores never become training labels. A fine-tuning export retains all
old partitions so the normal incremental audit can enforce their identities, but
only old TRAIN and new explicitly reviewed TRAIN images are used for fitting.
"""
from __future__ import annotations

import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import uuid

from .common import EXTENSIONS, read_csv, read_json, sha_file, write_csv, write_json
from .data import (EXCLUDED_TEST, _aliases, _group_scheme, _source_groups,
                   audit, make_manifest, pixel_signature, tray_unit_identity)
from .review import LABELS, _lock, _session, read_records, resolve_review_asset

FORMAT = "inspection_review_dataset_v5"
PROTECTED = {"val", "threshold", "selection", "test", EXCLUDED_TEST}


def _identities(row):
    identities = set()
    for key in ("group", "source_group", "unit_id"):
        if row.get(key):
            identities.add(str(row[key]))
    for key in ("source_groups", "group_aliases"):
        raw = row.get(key)
        if raw:
            values = json.loads(raw) if isinstance(raw, str) else raw
            if not isinstance(values, list) or not all(isinstance(x, str) for x in values):
                raise ValueError("Invalid physical-unit aliases in provenance.")
            identities.update(values)
    try:
        identities.add(tray_unit_identity(row.get("relative_path", ""))["unit_id"])
    except ValueError:
        pass
    return identities


def _derive_group(cfg, row, pixel, old_by_pixel, mappings):
    """Do not guess a missing external physical-unit mapping."""
    if pixel in old_by_pixel:
        return old_by_pixel[pixel].get("source_group") or old_by_pixel[pixel]["group"]
    method = _group_scheme(cfg)["method"]
    if method == "csv":
        group = row.get("source_group") or row.get("group") or mappings.get(row["relative_path"])
        if not group:
            raise ValueError("A new reviewed image has no physical-unit group. Supply its original groups_csv mapping before exporting for fine-tuning.")
        return str(group)
    if method == "regex":
        match = re.search(cfg["group_regex"], row["relative_path"])
        if not match or not match.group("group"):
            raise ValueError("A reviewed filename does not match the source run's group_regex.")
        return match.group("group")
    if method == "tray_unit":
        return tray_unit_identity(row["relative_path"])["unit_id"]
    return "pixel:" + pixel


def _relative(label, split, pixel, original):
    name = Path(str(original).replace("\\", "/")).name
    if not name or name in (".", "..") or ":" in name:
        raise ValueError("An exported image needs a safe original basename.")
    parts = (label, split, pixel[:20], name) if split else (label, pixel[:20], name)
    return Path(*parts).as_posix()


def _snapshot(session):
    path, marker = _session(session)
    with _lock(path / "review_write.lock"):
        reviews_path = path / "reviews.json"
        reviews = read_json(reviews_path) if reviews_path.exists() else {"items": {}, "history": []}
        review_hash = sha_file(reviews_path) if reviews_path.exists() else None
    return path, marker, reviews, review_hash, read_records(path)


def export_review_dataset(sessions, output_root, source_run=None, include_replay=True):
    """Export copies; never overwrite a session, source dataset, or old version.

    Returns ``ready_for_update`` only after ordinary audit + incremental manifest
    validation succeeds. Exporting without source_run is allowed for annotation
    hand-off but does NOT produce a train-ready config or claim leakage safety.
    """
    if not isinstance(sessions, (list, tuple)) or not sessions:
        raise ValueError("Select one or more review sessions.")
    paths = [Path(p).resolve() for p in sessions]
    if len(paths) != len(set(paths)):
        raise ValueError("Select each review session only once.")
    if not isinstance(include_replay, bool):
        raise ValueError("include_replay must be boolean.")
    if source_run and not include_replay:
        raise ValueError("Safe incremental fine-tuning requires replay and unchanged copies of every old partition. Enable include_replay.")

    cfg, old = None, []
    source = Path(source_run).resolve() if source_run else None
    protected_pixels, protected_files, protected_groups = set(), set(), set()
    old_by_pixel, mappings = {}, {}
    if source:
        from .workflow import external_history, open_run
        cfg, old = open_run(source)
        cfg = copy.deepcopy(cfg)
        if cfg.get("groups_csv"):
            mappings = {r["relative_path"]: r["group"] for r in read_csv(cfg["groups_csv"])}
        for row in old:
            old_by_pixel[row["pixel_hash"]] = row
            if row["split"] in PROTECTED:
                protected_pixels.add(row["pixel_hash"])
                protected_groups.update(_identities(row))
                if Path(row["path"]).is_file():
                    protected_files.add(sha_file(row["path"]))
        for ledger in external_history(source):
            protected_pixels.update(ledger["pixel_hashes"])
            protected_groups.update(ledger["groups"])

    snapshots, confirmed, observed_tasks = [], {}, set()
    protected_paths = list(paths)
    if source:
        protected_paths.extend((source, Path(cfg["data_root"]).resolve()))
    counts = {"sessions": len(paths), "records": 0, "operator_confirmed": 0,
              "excluded_unreviewed": 0, "excluded_unknown": 0,
              "deduplicated_reviews": 0, "new_training_images": 0,
              "new_confirmed_images": 0,
              "replayed_training_images": 0, "preserved_holdout_images": 0}
    for path in paths:
        session, marker, reviews, review_hash, records = _snapshot(path)
        task = marker.get("metadata", {}).get("task")
        if task:
            observed_tasks.add(task)
            if len(observed_tasks) > 1:
                raise ValueError("Review sessions from different inspection tasks cannot form one dataset.")
        if cfg and task and task != cfg["task"]:
            raise ValueError("Review session task differs from the source run.")
        if marker.get("metadata", {}).get("input_root"):
            protected_paths.append(Path(marker["metadata"]["input_root"]).resolve())
        snapshots.append({"session_id": marker["id"], "session_path": str(session),
                          "reviews_sha256": review_hash, "marker_sha256": sha_file(session / "review_session.json")})
        for row in records:
            counts["records"] += 1
            human = reviews.get("items", {}).get(row["id"], {})
            label = human.get("label", "unreviewed")
            if label not in LABELS:
                counts["excluded_unknown" if label == "unknown" else "excluded_unreviewed"] += 1
                continue
            if row.get("status", "ok") != "ok":
                raise ValueError("A confirmed image has a failed input record; resolve the image error before export.")
            asset = resolve_review_asset(session, row["id"])
            file_hash = sha_file(asset)
            recorded_hash = row.get("file_sha256", row.get("sha256"))
            if not recorded_hash or recorded_hash != file_hash:
                raise ValueError("A copied review image changed or has no original content hash; export refused.")
            pixel, _, _, _ = pixel_signature(asset)
            identities = _identities(row)
            group = _derive_group(cfg, row, pixel, old_by_pixel, mappings) if cfg else (row.get("source_group") or row.get("group") or "pixel:" + pixel)
            identities.add(group)
            if pixel in protected_pixels or file_hash in protected_files or identities & protected_groups:
                raise ValueError("A reviewed image overlaps a protected validation/calibration/selection/test unit or image. It cannot become training data: " + row["relative_path"])
            predecessor = old_by_pixel.get(pixel)
            if predecessor and predecessor["class_name"] != label:
                raise ValueError("An old training label was corrected. Incremental reuse is unsafe: create a new dataset lineage and a fresh independent holdout instead.")
            counts["operator_confirmed"] += 1
            evidence = {"session_id": marker["id"], "session_path": str(session), "item_id": row["id"],
                        "source_relative_path": row["relative_path"], "original_reference": row.get("reference_label"),
                        "prediction": row.get("prediction"), "review": human,
                        "history": [h for h in reviews.get("history", []) if h.get("item_id") == row["id"]],
                        "reviews_sha256": review_hash, "source_file_sha256": file_hash}
            if pixel in confirmed:
                prior = confirmed[pixel]
                if prior["label"] != label:
                    raise ValueError("Conflicting operator labels for identical decoded image content. Resolve the reviews before export.")
                if cfg and prior["group"] != group:
                    raise ValueError("Identical reviewed pixels have different physical-unit groups. Resolve their group mapping before export.")
                prior["provenance"].append(evidence)
                counts["deduplicated_reviews"] += 1
            else:
                confirmed[pixel] = {"asset": asset, "label": label, "pixel_hash": pixel,
                                    "file_sha256": file_hash, "group": group,
                                    "original_relative_path": row["relative_path"], "provenance": [evidence]}
    if not confirmed:
        raise ValueError("No explicitly operator-confirmed good/bad images are available. Unknown and unreviewed images are not training labels.")

    copies = []
    for row in old:
        asset = Path(row["path"])
        if pixel_signature(asset)[0] != row["pixel_hash"]:
            raise ValueError("An original source-run image changed; restore it before exporting replay.")
        if len(_source_groups(row)) > 1:
            raise ValueError("This source image represents multiple original group aliases. Export the full original duplicate/group mapping for replay; automatic compact replay is not safe.")
        split = "test" if row["split"] == EXCLUDED_TEST else row["split"]
        entry = {"asset": asset, "label": row["class_name"], "pixel_hash": row["pixel_hash"],
                 "file_sha256": sha_file(asset), "group": row.get("source_group") or row["group"],
                 "original_relative_path": row["relative_path"], "source_split": row["split"],
                 "split": split, "origin": "replay" if split == "train" else "preserved_holdout",
                 "provenance": confirmed.get(row["pixel_hash"], {}).get("provenance", [])}
        copies.append(entry)
        counts["replayed_training_images" if split == "train" else "preserved_holdout_images"] += 1
    for pixel, row in confirmed.items():
        if pixel not in old_by_pixel:
            copies.append({**row, "split": "train" if source else "", "source_split": None, "origin": "operator_confirmed"})
            counts["new_confirmed_images"] += 1
            if source:
                counts["new_training_images"] += 1

    # Keep regex grouping unchanged, or fail rather than silently changing the
    # physical identity of old examples after placing them in split directories.
    for item in copies:
        item["relative_path"] = _relative(item["label"], item["split"], item["pixel_hash"], item["original_relative_path"])
        if cfg and _group_scheme(cfg)["method"] == "regex":
            match = re.search(cfg["group_regex"], item["relative_path"])
            if not match or match.group("group") != item["group"]:
                raise ValueError("The source group_regex is path-dependent and cannot safely survive this copied layout. Use a reviewed export with an explicit fresh lineage.")

    root = Path(output_root).resolve()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
    version = root / ("review_dataset_" + stamp + "_" + uuid.uuid4().hex[:8])
    if any(version.is_relative_to(p) or p.is_relative_to(version) for p in protected_paths):
        raise ValueError("Review dataset output must be separate from original inputs, sessions and source runs.")
    version.mkdir(parents=True, exist_ok=False)
    dataset = version / "images"
    dataset.mkdir()
    for label in sorted(LABELS):
        (dataset / label).mkdir()
    metadata = {"format": FORMAT, "status": "exporting", "created_utc": datetime.now(timezone.utc).isoformat(),
                "source_run": str(source) if source else None, "include_replay": include_replay,
                "sessions": snapshots, "counts": counts, "operator_labels_only": True,
                "immutable_version": True, "ready_for_update": False,
                "partition_policy": "Old partitions unchanged; new confirmed units TRAIN only. Validation and all calibration/selection/test units are protected.",
                "qualification": "unqualified"}
    write_json(version / "dataset_version.json", metadata)
    try:
        exported = []
        for item in copies:
            target = dataset / item["relative_path"]
            target.parent.mkdir(parents=True, exist_ok=True)
            with item["asset"].open("rb") as src, target.open("xb") as dst:
                shutil.copyfileobj(src, dst)
            if sha_file(target) != item["file_sha256"]:
                raise ValueError("A source image changed during export; version is incomplete and cannot be trained.")
            exported.append({key: value for key, value in item.items() if key != "asset"})
        write_json(version / "provenance.json", {"format": FORMAT, "images": exported})
        config_path = None
        if cfg:
            cfg.update(data_root=str(dataset), previous_run=str(source), fine_tune_previous=True,
                       pretrained=True, dataset_version=version.name)
            if cfg.get("groups_csv"):
                groups = version / "groups.csv"
                write_csv(groups, [{"relative_path": r["relative_path"], "group": r["group"]} for r in exported])
                cfg["groups_csv"] = str(groups)
            # Record an integrity contract for root/API to check before launch.
            cfg["review_dataset"] = {"version": str(version), "provenance_sha256": sha_file(version / "provenance.json"),
                                      "source_manifest_sha256": sha_file(source / "manifest.csv")}
            if cfg.get("groups_csv"):
                cfg["review_dataset"]["groups_sha256"] = sha_file(cfg["groups_csv"])
            records = audit(cfg, version / "audit")
            make_manifest(cfg, records, version / "split_verification")
            config_path = version / "fine_tune_config.json"
            write_json(config_path, cfg)
            metadata.update(config_sha256=sha_file(config_path), ready_for_update=True)
        notes = ["Only explicit good/bad operator reviews are included; unknown and unreviewed are excluded.",
                 "Training on review-selected examples does not create an independent validation or test set."]
        if not source:
            notes.append("No source run supplied: protected holdouts and replay cannot be verified. This export is annotation hand-off only; create an explicitly audited lineage before training.")
        metadata.update(status="completed", notes=notes, provenance_sha256=sha_file(version / "provenance.json"))
        write_json(version / "dataset_version.json", metadata)
        result = {"path": str(version), "dataset_root": str(dataset),
                  "config_path": str(config_path) if config_path else None,
                  "ready_for_update": metadata["ready_for_update"], "counts": counts, "notes": notes}
        return result
    except Exception as error:
        metadata.update(status="failed", error=str(error), ready_for_update=False)
        write_json(version / "dataset_version.json", metadata)
        raise


def verify_review_dataset(config_path):
    """Verify the exported contract immediately before an update is launched."""
    cfg = read_json(config_path)
    contract = cfg.get("review_dataset")
    if not isinstance(contract, dict):
        raise ValueError("This config is not an operator-review export.")
    version = Path(contract["version"]).resolve()
    metadata = read_json(version / "dataset_version.json")
    if (metadata.get("status") != "completed" or not metadata.get("ready_for_update") or
            sha_file(config_path) != metadata.get("config_sha256") or
            sha_file(version / "provenance.json") != contract["provenance_sha256"]):
        raise ValueError("Review export is incomplete or changed; create a new immutable export.")
    source = Path(cfg["previous_run"])
    if sha_file(source / "manifest.csv") != contract["source_manifest_sha256"]:
        raise ValueError("Source-run manifest changed after review export.")
    if contract.get("groups_sha256") and sha_file(cfg["groups_csv"]) != contract["groups_sha256"]:
        raise ValueError("Exported physical-unit group mapping changed.")
    images = read_json(version / "provenance.json")["images"]
    dataset = Path(cfg["data_root"]).resolve()
    actual = {p.relative_to(dataset).as_posix() for p in dataset.rglob("*")
              if p.is_file() and p.suffix.lower() in EXTENSIONS}
    if actual != {r["relative_path"] for r in images}:
        raise ValueError("Exported dataset image inventory changed; create a new immutable export.")
    for item in images:
        relative = Path(item["relative_path"])
        asset = (Path(cfg["data_root"]) / relative).resolve()
        if not asset.is_relative_to(dataset) or sha_file(asset) != item["file_sha256"]:
            raise ValueError("An exported image changed; immutable dataset verification failed.")
    return cfg


def validate_update_config(config_path):
    """Public dashboard/CLI gate for an immutable review fine-tuning export."""
    return verify_review_dataset(config_path)
