"""ROI geometry, classification and deliberately conservative boundary detection."""
import math
import unittest
import numpy as np
from scipy import ndimage
from topseg.classical import (default_roi, validate_roi, roi_mask, reclassify_mask,
                              detect_inner_roi, suggest, _boundary_distance)


def polygon(points):
    return {'type': 'polygon', 'points': [{'x': x, 'y': y} for x, y in points]}


class RoiTests(unittest.TestCase):
    def test_default_is_bounded_clipped_corner_octagon(self):
        roi = validate_roi(default_roi(120, 100), 120, 100)
        self.assertEqual(roi['type'], 'polygon')
        self.assertEqual(len(roi['points']), 8)
        self.assertTrue(roi_mask(roi, 120, 100)[50, 60])
        self.assertFalse(roi_mask(roi, 120, 100)[22, 32])

    def test_polygon_matches_pixel_center_even_odd_rule(self):
        # Edges deliberately pass through pixel centres. Match the browser's
        # half-open ray-crossing convention exactly, including those pixels.
        points = [(.5, .5), (6.5, 1.5), (4.5, 4.5), (3.5, 2.5), (.5, 5.5)]
        actual = roi_mask(polygon(points), 8, 8)
        for y in range(8):
            for x in range(8):
                expected = False
                for (ax, ay), (bx, by) in zip(points, points[1:] + points[:1]):
                    if (ay > y + .5) != (by > y + .5) and x + .5 < (bx - ax) * (y + .5 - ay) / (by - ay) + ax:
                        expected = not expected
                self.assertEqual(actual[y, x], expected, (x, y))
        self.assertTrue(np.array_equal(actual, roi_mask(polygon(points[::-1]), 8, 8)))

    def test_invalid_polygons_rejected(self):
        invalid = [
            [(1, 1), (8, 8), (8, 1), (1, 8)],  # crossing
            [(1, 1), (8, 1), (4, 1)],          # no area
            [(1, 1), (8, 1), (8, 8), (1, 1)], # repeated first vertex
            [(1, 1), (11, 1), (8, 8)],         # outside
            [(1, 1), (math.nan, 1), (8, 8)],
            [(1, 1), (8, 1), (4, 1), (8, 8), (1, 8)], # backtracking
        ]
        for points in invalid:
            with self.subTest(points=points), self.assertRaises(ValueError):
                validate_roi(polygon(points), 10, 10)

    def test_reclassification_preserves_zero_and_input(self):
        mask = np.zeros((12, 12), dtype=np.uint8)
        mask[5, 1:11] = 2
        original = mask.copy()
        roi = polygon([(3, 3), (8, 3), (8, 8), (3, 8)])
        result = reclassify_mask(mask, roi)
        self.assertTrue(np.array_equal(mask, original))
        self.assertTrue(np.array_equal(result != 0, original != 0))
        self.assertTrue(np.all(result[5, 3:8] == 1))
        self.assertEqual(result[5, 2], 2)
        self.assertEqual(result[5, 8], 2)

    def test_legacy_ellipse_classification(self):
        ellipse = {'cx': 8, 'cy': 7, 'rx': 4, 'ry': 2}
        yy, xx = np.mgrid[:14, :16]
        expected = ((xx + .5 - 8) / 4) ** 2 + ((yy + .5 - 7) / 2) ** 2 <= 1
        self.assertTrue(np.array_equal(roi_mask(ellipse, 16, 14), expected))
        self.assertEqual(validate_roi({'type': 'ellipse', **ellipse}, 16, 14), ellipse)

    def test_polygon_guard_uses_distance_to_segments(self):
        roi = polygon([(4, 4), (16, 4), (16, 16), (4, 16)])
        distance = _boundary_distance(roi, 20, 20, roi_mask(roi, 20, 20))
        self.assertAlmostEqual(distance[4, 10], .5)
        self.assertAlmostEqual(distance[0, 0], math.hypot(3.5, 3.5))
        self.assertAlmostEqual(distance[10, 10], 5.5)
        image = np.full((20, 20, 3), 128, np.uint8)
        image[4:6, 10:12] = 250
        mask, _ = suggest(image, roi, {'boundary_guard': 2, 'min_area': 1})
        self.assertFalse(mask[distance <= 2].any())

    def test_detect_rotated_clipped_corner_polygon(self):
        width, height = 300, 260
        vertices = np.array([[-48, -72], [48, -72], [77, -43], [77, 43], [48, 72], [-48, 72], [-77, 43], [-77, -43]], dtype=float)
        angle = .27
        rotation = np.array([[math.cos(angle), -math.sin(angle)], [math.sin(angle), math.cos(angle)]])
        vertices = vertices @ rotation.T + [154, 126]
        expected = roi_mask(polygon(vertices.tolist()), width, height)
        rng = np.random.default_rng(42)
        gray = np.where(expected, 142., 90.) + rng.normal(0, .6, (height, width))
        image = np.repeat(np.clip(gray, 0, 255).astype(np.uint8)[..., None], 3, axis=2)
        detected, metadata = detect_inner_roi(image)
        self.assertTrue(metadata['found'], metadata)
        self.assertTrue(metadata['review_required'])
        self.assertEqual(len(detected['points']), 8)
        actual = roi_mask(detected, width, height)
        iou = (actual & expected).sum() / (actual | expected).sum()
        self.assertGreater(iou, .96)

    def test_thin_polygon_outline_can_be_found_without_filled_interior(self):
        expected = roi_mask(default_roi(220, 220), 220, 220)
        ring = expected ^ ndimage.binary_erosion(expected, iterations=2)
        gray = np.full((220, 220), 120., dtype=float)
        gray[ring] -= 20
        gray += np.random.default_rng(7).normal(0, .8, gray.shape)
        image = np.repeat(np.clip(gray, 0, 255).astype(np.uint8)[..., None], 3, axis=2)
        detected, metadata = detect_inner_roi(image)
        self.assertTrue(metadata['found'], metadata)
        self.assertEqual(len(detected['points']), 8)
        actual = roi_mask(detected, 220, 220)
        self.assertGreater((actual & expected).sum() / (actual | expected).sum(), .94)

    def test_flat_image_keeps_prior_without_claiming_detection(self):
        prior = polygon([(15, 15), (85, 15), (85, 70), (15, 70)])
        detected, metadata = detect_inner_roi(np.full((100, 110, 3), 100, np.uint8), prior)
        self.assertEqual(detected, prior)
        self.assertFalse(metadata['found'])
        self.assertEqual(metadata['confidence'], 0)
        self.assertTrue(metadata['review_required'])
        self.assertEqual(metadata['fallback'], 'prior')

    def test_circular_ring_is_not_claimed_to_be_polygon(self):
        yy, xx = np.mgrid[:220, :220]
        disk = (xx - 110) ** 2 + (yy - 110) ** 2 < 65 ** 2
        image = np.repeat(np.where(disk, 155, 80).astype(np.uint8)[..., None], 3, axis=2)
        _, metadata = detect_inner_roi(image)
        self.assertFalse(metadata['found'], metadata)


if __name__ == '__main__':
    unittest.main()
