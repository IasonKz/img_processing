"""Exercise loopback ROI APIs and real durable subprocess workers."""
from http.server import ThreadingHTTPServer
from contextlib import redirect_stderr
from io import StringIO
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import numpy as np
from PIL import Image
import yaml

from nilt.common import read_json, write_json
from nilt.dashboard import Dashboard, make_handler
from nilt.roi.geometry import default_template


class ROIDashboardTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source = self.root / "images"
        self.original = self.root / "whole_bottom"
        self.original.mkdir()
        self.base = self.root / "project.yaml"
        self.base.write_text(yaml.safe_dump({"schema_version": 3,
            "paths": {"output_root": "results", "weights_root": "weights"},
            "tasks": {"bottom": {"dataset_root": str(self.original)}}}), encoding="utf-8")
        self.app = Dashboard(self.base)
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(self.app))
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.url = f"http://127.0.0.1:{self.server.server_port}"

    def tearDown(self):
        for process in getattr(self.app, "_roi_processes", {}).values():
            if process.poll() is None:
                process.terminate()
            process.wait(timeout=10)
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=5)
        self.temp.cleanup()

    def image(self, relative="bad/unit1.png", seed=1):
        path = self.source / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        values = np.random.default_rng(seed).integers(15, 120, (120, 120, 3), dtype=np.uint8)
        Image.fromarray(values).save(path)
        return path

    def request(self, path, data=None, *, token=True, origin=None, host=None):
        headers = {}
        if data is not None:
            headers["Content-Type"] = "application/json"
            if token:
                headers["X-Inspection-Token"] = self.app.token
        if origin:
            headers["Origin"] = origin
        if host:
            headers["Host"] = host
        request = Request(self.url + path, data=json.dumps(data).encode() if data is not None else None, headers=headers)
        try:
            response = urlopen(request, timeout=15)
        except HTTPError as error:
            response = error
        with response:
            body = response.read()
            return response.status, json.loads(body) if "application/json" in response.headers.get("Content-Type", "") else body

    def start_and_wait(self, action, payload=None, expected="completed"):
        code, response = self.request("/api/roi/" + action, {"side": "bottom", **(payload or {})})
        self.assertEqual(code, 200, response)
        job = response["job"]
        self.assertIn(job["status"], ("starting", "running"))
        self.app._roi_processes[job["id"]].wait(timeout=30)
        code, result = self.request("/api/roi/job?side=bottom")
        self.assertEqual(code, 200, result)
        self.assertEqual(result["job"]["status"], expected, result)
        self.assertEqual(result["job"]["id"], job["id"])
        return result["job"]

    def import_one(self):
        self.image()
        return self.start_and_wait("import", {"folder": str(self.source), "unit_id_strategy": "stem", "split_ratios": [1, 0, 0]})

    def geometry(self):
        _, state = self.request("/api/roi/state?side=bottom")
        image_id = state["images"][0]["id"]
        template = default_template("bottom")
        template["reference_size"] = [120, 120]
        code, result = self.request("/api/roi/template", {"side": "bottom", "template": template, "reference_image_id": image_id})
        self.assertEqual(code, 200, result)
        return image_id

    def test_async_import_localize_review_export_and_classifier_handoff(self):
        original_bytes = self.base.read_bytes()
        job = self.import_one()
        self.assertEqual(job["result"]["summary"]["imported"], 1)
        image_id = self.geometry()
        job = self.start_and_wait("localize", {"method": "template"})
        self.assertEqual(job["result"]["summary"]["localized"], 1)
        _, state = self.request("/api/roi/state?side=bottom")
        annotation = state["images"][0]["annotation"]
        self.assertEqual(len(annotation["rois"]), 18)
        self.assertEqual(set(annotation["quality"].values()), {"unknown"})
        self.assertFalse(annotation["geometry_reviewed"])
        code, result = self.request("/api/roi/annotation", {"side": "bottom", "image_id": image_id,
            "geometry_reviewed": True, "quality": {"pin_r1_c1": "bad", "pin_r1_c2": "good"}})
        self.assertEqual(code, 200, result)
        code, pixels = self.request(f"/api/roi/crop?side=bottom&id={image_id}&roi=pin_r1_c1")
        self.assertEqual(code, 200)
        self.assertTrue(pixels.startswith(b"\x89PNG\r\n\x1a\n"))
        export = self.start_and_wait("export")["result"]
        dataset = next(item["path"] for item in export["classification"] if item["kind"] == "pins")
        code, handoff = self.request("/api/roi/classification", {"side": "bottom", "roi_scope": "pins", "dataset": dataset})
        self.assertEqual(code, 200, handoff)
        self.assertEqual(handoff["roi_scope"], "pins")
        self.assertEqual(handoff["dataset_info"]["n_crops"], 2)
        self.assertEqual(handoff["config"]["roi_scopes"]["bottom"], "pins")
        code, result = self.request("/api/roi/classification", {"side": "bottom", "roi_scope": "whole_image"})
        self.assertEqual(code, 200, result)
        self.assertEqual(result["dataset"], str(self.original))
        self.assertEqual(self.base.read_bytes(), original_bytes)
        # The completed job and reviewed annotations survive a dashboard restart.
        reopened = Dashboard(self.base)
        self.assertEqual(reopened.roi_job({"side": "bottom"})["job"]["status"], "completed")
        self.assertTrue(reopened.roi_state({"side": "bottom"})["images"][0]["annotation"]["geometry_reviewed"])

    def test_http_csrf_origin_host_and_side_validation(self):
        for route in ("import", "template", "annotation", "classification", "stop", "train", "evaluate"):
            code, _ = self.request("/api/roi/" + route, {"side": "bottom"}, token=False)
            self.assertEqual(code, 403, route)
        code, _ = self.request("/api/roi/import", {"side": "bottom"}, origin="https://foreign.example")
        self.assertEqual(code, 403)
        code, _ = self.request("/api/roi/state?side=bottom", host="foreign.example")
        self.assertEqual(code, 403)
        for path, data in (("/api/roi/state?side=vig", None), ("/api/roi/import", {"side": "vig"}),
                           ("/api/roi/classification", {"side": "bottom", "roi_scope": "label"})):
            code, _ = self.request(path, data)
            self.assertEqual(code, 400)
        self.assertFalse((self.root / "roi_detection" / "vig").exists())

    def test_failed_import_records_error_and_releases_blocker(self):
        result = self.start_and_wait("import", {"folder": str(self.root / "missing")}, expected="failed")
        self.assertIn("Input folder does not exist", result["error"])
        self.assertFalse(self.app.roi_busy())
        self.import_one()

    def test_partial_import_reports_errors_and_keeps_successful_images(self):
        self.image()
        (self.source / "bad" / "broken.png").write_bytes(b"not an image")
        result = self.start_and_wait("import", {"folder": str(self.source), "unit_id_strategy": "stem"})
        self.assertTrue(result["has_errors"])
        self.assertEqual(result["result"]["summary"]["imported"], 1)
        self.assertEqual(len(result["result"]["summary"]["errors"]), 1)
        self.assertFalse(self.app.roi_busy())
        self.assertEqual(len(self.app.roi_state({"side": "bottom"})["images"]), 1)

    def test_localization_all_errors_does_not_report_success(self):
        self.import_one()
        self.geometry()
        result = self.start_and_wait("localize", {"method": "segmentation"}, expected="failed")
        summary = result["result"]["summary"]
        self.assertEqual(summary["localized"], 0)
        self.assertEqual(len(summary["errors"]), 1)

    def test_mutations_block_while_roi_or_classification_work_is_active(self):
        payloads = {"import": {"folder": str(self.source)}, "template": {"template": default_template("bottom")},
                    "annotation": {"image_id": "unknown"}, "classification": {"roi_scope": "pins"}}
        for blocker in ("roi", "classification"):
            with patch.object(self.app, "roi_busy", return_value=blocker == "roi"):
                self.app._v5_operation = "active experiment" if blocker == "classification" else None
                for route, values in payloads.items():
                    code, result = self.request("/api/roi/" + route, {"side": "bottom", **values})
                    self.assertEqual(code, 400, result)
                    self.assertRegex(result["error"].lower(), "active|stop|wait")
        self.app._v5_operation = None
        self.assertFalse(hasattr(self.app, "_roi_processes"))

    def test_task_worker_stop_marker_retains_preexisting_progress(self):
        from nilt.roi.task_worker import run
        self.import_one()
        output = self.root / "cancelled_job"
        output.mkdir()
        (output / "STOP").touch()
        with redirect_stderr(StringIO()):
            with self.assertRaisesRegex(RuntimeError, "cancelled"):
                run({"action": "import", "root": str(self.app.roi_root), "side": "bottom", "output": str(output),
                     "payload": {"folder": str(self.source), "unit_id_strategy": "stem"}})
        self.assertEqual(read_json(output / "status.json")["status"], "stopped")
        self.assertEqual(len(self.app.roi_state({"side": "bottom"})["images"]), 1)


if __name__ == "__main__":
    unittest.main()
