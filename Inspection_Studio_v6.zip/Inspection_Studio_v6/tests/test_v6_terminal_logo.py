"""Terminal rendering must not interfere with dashboard diagnostics or shutdown."""
import io
import os
import sys
import time
import unittest
from unittest.mock import patch

from nilt.terminal_logo import ENTER, LEAVE, TerminalLogo, logo_points, render_logo


class FakeTerminal(io.StringIO):
    @property
    def encoding(self):
        return "utf-8"

    def isatty(self):
        return True


class TerminalLogoTests(unittest.TestCase):
    def test_logo_changes_with_rotation_and_stays_within_bounds(self):
        points = logo_points()
        self.assertGreater(len(points), 100)
        a = render_logo(points, 0, 60, 15)
        b = render_logo(points, 1, 60, 15)
        self.assertNotEqual(a, b)
        self.assertEqual(len(a), 15)
        self.assertTrue(all(len(row) == 60 for row in a))
        self.assertTrue(any("█" in row for row in a))

    def test_redirected_output_has_no_escape_sequences(self):
        stream = io.StringIO()
        with patch("sys.stdout", stream):
            logo = TerminalLogo("http://127.0.0.1:8765")
            self.assertFalse(logo.start())
            logo.stop()
        self.assertEqual(stream.getvalue(), "")

    def test_config_can_disable_animation_and_refresh_is_bounded(self):
        with patch.dict(os.environ, {"NILT_TERMINAL_SPINNER": "off", "NILT_SPINNER_FPS": "9999"}):
            logo = TerminalLogo("local")
            self.assertFalse(logo.enabled)
            self.assertEqual(logo.fps, 12)
            self.assertFalse(logo.start())
        self.assertEqual(TerminalLogo("local", fps="nan").fps, 8)

    def test_error_stops_animation_and_restores_streams_before_printing(self):
        stream, errors = FakeTerminal(), io.StringIO()
        with patch("sys.stdout", stream), patch("sys.stderr", errors), \
                patch.dict(os.environ, {"TERM": "xterm"}), \
                patch("nilt.terminal_logo.shutil.get_terminal_size", return_value=os.terminal_size((80, 24))), \
                patch("nilt.terminal_logo._windows_ansi", return_value=lambda: None):
            logo = TerminalLogo("http://127.0.0.1:8765", enabled=True)
            self.assertTrue(logo.start())
            print("important diagnostic", file=sys.stderr)
            self.assertIs(sys.stdout, stream)
            self.assertIs(sys.stderr, errors)
            self.assertFalse(logo._thread.is_alive())
            self.assertIn(ENTER, stream.getvalue())
            self.assertTrue(stream.getvalue().endswith(LEAVE))
            self.assertEqual(errors.getvalue(), "important diagnostic\n")
            logo.stop()
            self.assertEqual(stream.getvalue().count(LEAVE), 1)

    def test_small_terminal_uses_plain_text(self):
        with patch("sys.stdout", FakeTerminal()), patch.dict(os.environ, {"TERM": "xterm"}), \
                patch("nilt.terminal_logo.shutil.get_terminal_size", return_value=os.terminal_size((30, 10))):
            self.assertFalse(TerminalLogo("local").start())


if __name__ == "__main__":
    unittest.main()
