import gc
import importlib.util

import pytest
import torch

from binary_inspection.models import BinaryClassifier
from binary_inspection.patchcore import nearest_neighbors, image_anomaly_scores, greedy_coreset


@pytest.mark.parametrize("architecture", ["resnet50", "convnext_tiny", "swin_tiny"])
def test_real_architecture_forward_and_head_gradients(architecture):
    torch.set_num_threads(2)
    model = BinaryClassifier({"architecture": architecture, "input_size": 64, "strategy": "frozen"})
    model.set_training_stage(0, 1)
    out = model(torch.rand(2, 3, 64, 64))
    assert out.shape == (2,) and torch.isfinite(out).all()
    out.sum().backward()
    assert model.head.weight.grad is not None
    assert all(p.grad is None for p in model.backbone.parameters())
    del model
    gc.collect()


@pytest.mark.skipif(importlib.util.find_spec("timm") is None, reason="timm unavailable in offline test environment")
def test_dinov2_real_architecture_forward():
    torch.set_num_threads(2)
    model = BinaryClassifier({"architecture": "dinov2_small", "input_size": 56, "strategy": "frozen"})
    model.set_training_stage(0, 1)
    out = model(torch.rand(2, 3, 56, 56))
    assert out.shape == (2,) and torch.isfinite(out).all()
    assert model.feature_dim == 1152
    out.sum().backward()
    assert model.head.weight.grad is not None


def test_patchcore_exact_nearest_neighbors():
    torch.manual_seed(2)
    queries, bank = torch.randn(23, 7), torch.randn(12, 7)
    distances, indices = nearest_neighbors(queries, bank, chunk=5)
    expected, wanted = torch.cdist(queries, bank).min(1)
    assert torch.allclose(distances, expected, atol=1e-5)
    assert torch.equal(indices, wanted)
    scores = image_anomaly_scores(queries[:20].reshape(2, 10, 7), bank, 3, 5)
    assert scores.shape == (2,) and torch.isfinite(scores).all() and (scores >= 0).all()


def test_coreset_is_subset_and_deterministic():
    pool = torch.randn(30, 8)
    a = greedy_coreset(pool, 5, 4, torch.device("cpu"), 42)
    b = greedy_coreset(pool, 5, 4, torch.device("cpu"), 42)
    assert a.shape == (5, 8) and torch.equal(a, b)
    assert len(torch.unique(a, dim=0)) == 5
