"""Real small Optuna studies exercising sampler selection and continuation."""
from __future__ import annotations

import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from nilt.common import DEFAULTS, PROFILES, merge_dict
from nilt.custom_search import apply_custom
from nilt.samplers_v6 import SAMPLERS, sampler_options, check_sampler_dependencies
from nilt import search


def config(sampler="tpe", numeric=False, finite=False, **options):
    cfg = merge_dict(merge_dict(DEFAULTS, PROFILES["laptop"]), {
        "profile": "laptop", "task": "vig", "data_root": "/tmp/data",
        "weights_dir": "/tmp/weights", "output_root": "/tmp/results",
        "models": ["resnet18"]})
    space = {"mode": "head_only", "optimizer": "adamw", "scheduler": "constant",
             "imbalance": "none", "effective_batch_size": 4}
    if finite:
        space.update(head_learning_rate={"kind": "choices", "values": [.001, .003]}, weight_decay=0.)
    elif numeric:
        space.update(head_learning_rate={"kind": "range", "low": .0001, "high": .003, "log": True},
                     weight_decay={"kind": "range", "low": .00001, "high": .001, "log": True})
    return apply_custom(cfg, {"search": {"sampler": sampler, "sampler_options": options,
        "enqueue_presets": False, "startup_trials": 1, "max_trials_per_model": 20,
        "space": space}})


class SamplerContractTests(unittest.TestCase):
    def test_all_core_algorithm_names_are_explicit(self):
        self.assertEqual(set(SAMPLERS), {"tpe", "random", "grid", "cmaes", "gp", "nsgaii", "nsgaiii", "qmc", "brute_force"})

    def test_numeric_sampler_rejects_categorical_fallback(self):
        for name in ("qmc", "cmaes"):
            with self.subTest(name=name), self.assertRaisesRegex(ValueError, "categorical"):
                apply_custom(config("tpe", numeric=True), {"search": {"sampler": name,
                    "space": {"effective_batch_size": [4, 8]}}})
        cfg = config("cmaes", numeric=True)
        self.assertEqual(cfg["search"]["sampler"], "cmaes")

    def test_cmaes_requires_two_varying_dimensions(self):
        with self.assertRaisesRegex(ValueError, "at least 2"):
            apply_custom(config("tpe", numeric=True), {"search": {"sampler": "cmaes", "space": {
                "mode": "head_only", "optimizer": "adamw", "scheduler": "constant", "imbalance": "none",
                "effective_batch_size": 4, "weight_decay": 0.}}})

    def test_finite_exhaustive_space_is_checked_before_training(self):
        with self.assertRaisesRegex(ValueError, "finite"):
            config("brute_force", numeric=True)
        self.assertEqual(config("brute_force", finite=True)["search"]["sampler"], "brute_force")

    def test_invalid_options_and_deprecated_restart_are_rejected(self):
        cases = [("tpe", {"group": True}), ("cmaes", {"restart_strategy": "ipop"}),
                 ("nsgaii", {"population_size": 1}), ("nsgaiii", {"mutation_prob": 1.1}),
                 ("qmc", {"qmc_type": "other"}), ("qmc", {"scramble": "true"}),
                 ("cmaes", {"sigma0": float("nan")}),
                 ("cmaes", {"with_margin": True, "lr_adapt": True})]
        for name, options in cases:
            with self.subTest(name=name, options=options), self.assertRaises(ValueError):
                sampler_options(name, options)

    def test_dependency_failure_is_actionable_and_never_random(self):
        with patch("nilt.samplers_v6.importlib.import_module", side_effect=ImportError("missing")):
            with self.assertRaisesRegex(RuntimeError, "requirements-samplers.txt"):
                check_sampler_dependencies({"sampler": "cmaes"})
            with self.assertRaisesRegex(RuntimeError, "training requirements"):
                check_sampler_dependencies({"sampler": "gp"})

    def test_sampler_options_replace_previous_algorithm_options(self):
        first = config("nsgaii", numeric=True, population_size=4)
        second = apply_custom(first, {"search": {"sampler": "random", "sampler_options": {}}})
        self.assertEqual(second["search"]["sampler_options"], {})

    def test_custom_canvas_is_editable_without_downsampling(self):
        for size in ("auto", 8192):
            cfg = apply_custom(config(), {"image_size": size, "image_size_limit": 16384})
            self.assertEqual(cfg["image_size"], size)
            self.assertEqual(cfg["image_size_limit"], 16384)
            self.assertEqual(cfg["resize"], "pad")
            self.assertTrue(cfg["preserve_native_resolution"])
        for payload in ({"image_size": 31}, {"image_size": True}, {"image_size": "8192"},
                        {"image_size": 8192, "image_size_limit": 4096},
                        {"image_size_limit": 0}, {"image_size_limit": float("inf")}):
            with self.subTest(payload=payload), self.assertRaises(ValueError):
                apply_custom(config(), payload)


@unittest.skipUnless(importlib.util.find_spec("optuna"), "Optuna is not installed")
class RealSamplerTests(unittest.TestCase):
    def run_trials(self, cfg, count=8, study=None):
        import optuna
        study = study or optuna.create_study(direction="maximize", sampler=search._sampler("resnet18", cfg))
        for _ in range(count):
            if search._architecture_stop_reason(study, search.search_settings(cfg)):
                break
            trial = study.ask()
            proposed = search.suggest_config(trial, "resnet18", cfg)
            training = proposed["training"]
            value = 1 - abs(training["head_learning_rate"] - .001) - training["weight_decay"]
            study.tell(trial, value)
        return study

    def test_real_numerical_and_population_algorithms(self):
        names = ["tpe", "random", "qmc", "nsgaii", "nsgaiii"]
        if importlib.util.find_spec("cmaes"):
            names.append("cmaes")
        for name in names:
            with self.subTest(sampler=name):
                options = {"population_size": 2} if name in {"nsgaii", "nsgaiii"} else {}
                study = self.run_trials(config(name, numeric=True, **options))
                self.assertEqual(len(study.trials), 8)
                self.assertTrue(all(t.state.name == "COMPLETE" for t in study.trials))
                self.assertGreater(len({t.params["head_learning_rate"] for t in study.trials}), 1)

    def test_evolutionary_mixed_spaces_keep_static_union(self):
        cfg = apply_custom(config("nsgaii", numeric=True, population_size=2), {"search": {"space": {
            "mode": ["head_only", "full"], "optimizer": ["adamw", "sgd"],
            "scheduler": ["constant", "cosine"], "imbalance": ["none", "weighted_loss"]}}})
        study = self.run_trials(cfg)
        param_names = [set(trial.params) for trial in study.trials]
        self.assertTrue(all(names == param_names[0] for names in param_names))
        self.assertTrue({"learning_rate", "momentum", "max_class_weight"} <= param_names[0])

    def test_grid_and_brute_force_finish_without_optimize_stop_error(self):
        for name, reason in (("grid", "grid_exhausted"), ("brute_force", "brute_force_exhausted")):
            with self.subTest(sampler=name):
                cfg = config(name, finite=True)
                study = self.run_trials(cfg)
                self.assertEqual(len(study.trials), 2)
                self.assertEqual({trial.params["head_learning_rate"] for trial in study.trials}, {.001, .003})
                self.assertEqual(search._architecture_stop_reason(study, search.search_settings(cfg)), reason)

    def test_brute_force_exhaustion_is_persisted_on_resume(self):
        with tempfile.TemporaryDirectory() as directory:
            cfg = config("brute_force", finite=True)
            study = search._study("resnet18", cfg, Path(directory))
            self.run_trials(cfg, study=study)
            restored = search._study("resnet18", cfg, Path(directory))
            self.assertEqual(search._architecture_stop_reason(restored, search.search_settings(cfg)), "brute_force_exhausted")

    def test_qmc_scramble_sequence_continues_after_restart(self):
        import optuna
        cfg = config("qmc", numeric=True, scramble=True)
        whole = self.run_trials(cfg, count=6)
        with tempfile.TemporaryDirectory() as directory:
            study = search._study("resnet18", cfg, Path(directory))
            self.run_trials(cfg, count=3, study=study)
            study = search._study("resnet18", cfg, Path(directory))
            self.run_trials(cfg, count=3, study=study)
            self.assertEqual([t.params for t in whole.trials], [t.params for t in study.trials])

    def test_qmc_log_endpoint_does_not_fall_back_to_random(self):
        cfg = config("qmc", numeric=True)
        with patch("optuna.samplers.QMCSampler._log_independent_sampling") as warning:
            study = self.run_trials(cfg, count=3)
        warning.assert_not_called()
        self.assertEqual(study.trials[1].params["weight_decay"], 1e-5)

    @unittest.skipUnless(importlib.util.find_spec("torch"), "GP requires training torch dependency")
    def test_gp_past_startup_runs_real_acquisition(self):
        study = self.run_trials(config("gp", numeric=True), count=3)
        self.assertEqual(len(study.trials), 3)
        self.assertTrue(all(trial.value is not None for trial in study.trials))


if __name__ == "__main__":
    unittest.main()
