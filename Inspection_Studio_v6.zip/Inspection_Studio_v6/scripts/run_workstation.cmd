@echo off
setlocal
cd /d "%~dp0.."
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_windows.ps1" -Action run -Profile workstation %*
set "STUDIO_EXIT=%ERRORLEVEL%"
echo.
if not "%STUDIO_EXIT%"=="0" echo Operation failed. Read the error above.
pause
exit /b %STUDIO_EXIT%
