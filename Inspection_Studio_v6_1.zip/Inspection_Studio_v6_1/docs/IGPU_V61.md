# Experimental laptop iGPU training

The **Laptop iGPU** profile is an additional training preset, not an inference-only option. The existing **Laptop** profile remains CPU by default. Choosing either profile does not change the project data, labels, network policy or qualification criteria.

| Setting | Laptop | Laptop iGPU |
| --- | --- | --- |
| Training backend | CPU | DirectML adapter 0 |
| Intended use | Stable CPU baseline | Experimental native Windows laptop GPU training |
| Initial time budget | 2 hours | 2 hours |
| Training batch size | 1 | 1 |
| Gradient accumulation | 8 in the supplied project | 8 |
| Mixed precision | Off | Off |
| Worker processes | 0 | 0 |

These are starting defaults, not hard limits. The Custom Optuna panel can change the adapter, batch size, search space and time budget. A longer budget does not guarantee more successful trials if the selected architecture is incompatible with the backend.

## Windows setup

In the extracted project folder, run:

```powershell
.\Setup-DirectML.cmd
.\Start.cmd
```

The setup uses a separate environment for the pinned DirectML/PyTorch combination. Do not install `torch-directml` into an existing CUDA environment or copy a virtual environment from another computer. The setup checks package consistency, compares a deterministic weighted classification loss and its gradients against CPU, and performs a small ResNet forward/backward probe.

In **Train & search**, select **Laptop iGPU**. Start with one small architecture, for example `resnet18`. In **Custom Optuna**, confirm the DirectML adapter index. Adapter 0 is a starting choice, not a guarantee that the selected adapter is the Intel iGPU: inspect the adapter names shown by Doctor and the installation probe. Other graphics adapters may be listed.

Optional direct command, using the environment selected by setup:

```powershell
.\scripts\run_search_laptop_igpu.cmd -Task vig -Hours 2
```

The `-Hours` argument is optional and editable; for example `-Hours 5` does not violate a profile cap.

## Check that training uses the requested device

Run Doctor from **Dataset & setup** and inspect the resolved search contract before starting. The recorded configuration must show `profile: laptop_igpu` and `device: directml:0` (or your selected index). The saved run configuration records that request.

The training path explicitly resolves the DirectML device and tests a deterministic float32 weighted `CrossEntropyLoss(reduction="sum")`, matching the training loss family. It compares the loss, weight gradients and bias gradients against a CPU reference, checks finite values and requires nonzero gradients. The comparison uses `rtol=2e-4` and `atol=2e-5`. Missing packages, an invalid adapter or a failed probe produce an error; the application does not silently choose CPU. Some operations may still be handled by a backend fallback or use CPU preprocessing, so a device name alone is not proof of faster training. Compare the same model, data and batch settings against the CPU baseline using elapsed time and images per second.

If a model-specific operator fails after the initial probe, inspect the trial log. A successful installation probe is not a compatibility guarantee for every architecture, image size or training mode. Reduce batch size first for memory errors; reducing image resolution is not automatic.

## Existing project configurations

An older `project.yaml` without a `profiles.laptop_igpu` section can still select this preset: the built-in v6.1 profile supplies its starting settings. Existing project defaults and per-task overrides retain their usual precedence. Inspect the resolved contract if a saved override supplies a different device, batch size or budget. Add a `profiles.laptop_igpu` section to store project-specific defaults, or use Custom Optuna for an individual search.

DirectML is a native Windows option in this release. CPU and NVIDIA CUDA remain separate choices. The Intel iGPU path has not been hardware-validated on the user's ThinkPad; test a short run and compare predictions before adopting it for routine work. No speedup or production-readiness claim is made.

## Third-party data collection notice

The pinned `torch-directml` vendor notice states that the package collects GPU device information and information about operators falling back to CPU and may send information to Microsoft. This is separate from Inspection Studio's public-weight download setting. Turning off pretrained-weight downloads does **not** establish that the DirectML package makes no network requests.

The application does not upload inspection images or labels, but third-party DirectML telemetry has not been independently audited or disabled by this project. Check company policy before installing or using this optional backend. The setup prints this notice before installation and before the DirectML probe imports the package. Use the CPU option if the DirectML data-collection terms are not acceptable; obtain company guidance for any required network controls.

Vendor references:

- [torch-directml 0.2.5.dev240914 — Data Collection Notice](https://pypi.org/project/torch-directml/0.2.5.dev240914/#data-collection-notice)
- [Microsoft privacy statement](https://go.microsoft.com/fwlink/?LinkID=824704)
