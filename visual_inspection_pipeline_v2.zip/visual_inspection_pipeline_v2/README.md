# Visual Inspection Pipeline

Version 2.0.0 — source release

Local image classification, model comparison, checkpoint management, and portable inference for independent `top`, `bottom`, and `vig` inspection tasks. Input is a directory containing labeled `good` and `bad` image folders. Data remain local during audit, training, evaluation, and inference.

**Start with [START_HERE.md](START_HERE.md).** Software validation evidence and outstanding hardware checks are recorded in [docs/VALIDATION_REPORT.md](docs/VALIDATION_REPORT.md). This source release contains no trained production model, customer dataset, or bundled pretrained weights. Deployment suitability must be demonstrated on representative held-out data.

## Capabilities

- Independent per-task training, thresholds, reports, and release history.
- ResNet18, ResNet50, EfficientNet-B0, ConvNeXt-Tiny, Swin-T, and a PatchCore-style anomaly detector.
- CPU pilot and GPU workstation profiles sharing the same command interface.
- Content audit, explicit unit grouping, deterministic group-preserving splits, and immutable dataset manifests.
- Training-only class imbalance handling; defect-oriented threshold tuning and model selection.
- Actual good/bad prediction folders, error folders, CSV records, and HTML reports.
- Best-model and epoch-boundary continuation checkpoints; comparison with a frozen previous version.
- ONNX deployment bundles with a standalone folder-inference runner, preprocessing, decision policy, integrity checks, and export parity results.
- Training archives with verified dataset-root relocation; model activation and rollback.

Large images are supported through a fixed per-version square input envelope. `pad` preserves source pixels; `fit` explicitly resizes while preserving aspect ratio. No automatic 600×600 limit or implicit out-of-memory downscaling is applied. Tiling is not implemented in this release.

## Quick commands

Run from the project directory in the installed Python environment. Edit `project.yaml` before running against real data.

```bash
python inspection.py doctor --config project.yaml --profile laptop
python inspection.py audit --config project.yaml --task top
python inspection.py run --config project.yaml --profile laptop --task top
python inspection.py run --config project.yaml --profile workstation --task top
```

The application also installs the equivalent `inspection` console command when installed with `pip install -e .`. Use `python inspection.py --help` and `python inspection.py COMMAND --help` for the exact installed interface.

## Documentation

| Document | Purpose |
| --- | --- |
| [START_HERE.md](START_HERE.md) | Initial setup and first workflow |
| [Installation](docs/INSTALLATION.md) | CPU/GPU environments, local weights, offline provisioning |
| [Operator guide](docs/OPERATOR_GUIDE.md) | Routine commands and output interpretation |
| [Configuration reference](docs/CONFIGURATION_REFERENCE.md) | Paths, task settings, profiles, and decision policy |
| [Models and metrics](docs/MODELS_AND_METRICS.md) | Candidate methods, selection objective, uncertainty, and split roles |
| [Model management](docs/MODEL_MANAGEMENT.md) | Resume, update, compare, activation, rollback, and relocation |
| [Deployment](docs/DEPLOYMENT.md) | ONNX package transfer and standalone inference |
| [Troubleshooting](docs/TROUBLESHOOTING.md) | Error diagnosis and recovery |
| [Validation report](docs/VALIDATION_REPORT.md) | Executed checks and remaining acceptance work |
| [Changelog](docs/CHANGELOG.md) | Release changes and limitations |

## Scope

The decision concerns the quality of one image. A comparison of new damage between a start/final image pair requires a separate pairwise model and is outside this release. A PatchCore heatmap indicates unusual appearance; it is not a supervised defect-type segmentation label.

Stored class indices are `bad=0`, `good=1`; the positive event for performance reporting is **a defect**. A bad image accepted as good is a false negative, also reported explicitly as a defect escape.
