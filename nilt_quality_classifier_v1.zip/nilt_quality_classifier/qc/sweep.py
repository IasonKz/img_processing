from __future__ import annotations

import itertools
import traceback
from pathlib import Path
from typing import Any

import pandas as pd
import torch

from .config import clean_for_serialization, load_yaml, resolve_path, save_yaml
from .data import save_manifest
from .pipeline import _records_from_config, run_training
from .utils import make_run_dir, setup_logging, write_json


def _deep_set(config: dict[str, Any], dotted_key: str, value: Any) -> None:
    current = config
    parts = dotted_key.split(".")
    for part in parts[:-1]:
        current = current.setdefault(part, {})
    current[parts[-1]] = value


def run_sweep(config: dict[str, Any]) -> dict[str, Any]:
    base_config_path = resolve_path(
        config.get("sweep", {}).get("base_train_config"), config=config, must_exist=True
    )
    if base_config_path is None:
        raise ValueError("Set sweep.base_train_config")
    base_config = load_yaml(base_config_path)

    output_parent = resolve_path(
        config.get("sweep", {}).get("output_root", "sweeps"), config=config
    )
    assert output_parent is not None
    sweep_dir = make_run_dir(output_parent, str(config.get("sweep", {}).get("name", "sweep")))
    logger = setup_logging(sweep_dir / "sweep.log")
    save_yaml(config, sweep_dir / "sweep_config_resolved.yaml")
    save_yaml(base_config, sweep_dir / "base_train_config.yaml")

    records, _ = _records_from_config(base_config, logger)
    save_manifest(records, sweep_dir / "shared_split_manifest.csv")

    grid = config.get("sweep", {}).get("grid", {}) or {}
    if not grid:
        raise ValueError("sweep.grid is empty")
    keys = list(grid.keys())
    values = [value if isinstance(value, list) else [value] for value in grid.values()]
    combinations = list(itertools.product(*values))
    maximum = config.get("sweep", {}).get("max_experiments")
    if maximum is not None:
        combinations = combinations[: int(maximum)]
    logger.info("Running %d experiment(s) with a fixed split", len(combinations))

    rows: list[dict[str, Any]] = []
    for index, combination in enumerate(combinations, start=1):
        experiment = dict(zip(keys, combination))
        experiment_config = load_yaml(base_config_path)
        for key, value in experiment.items():
            _deep_set(experiment_config, key, value)
        experiment_config.setdefault("project", {})["output_root"] = str(sweep_dir / "runs")
        experiment_config["project"]["name"] = f"experiment_{index:03d}"
        experiment_config.setdefault("evaluation", {})["evaluate_test"] = False
        experiment_config["evaluation"]["export_error_images"] = False

        logger.info("Experiment %d/%d: %s", index, len(combinations), experiment)
        try:
            result = run_training(
                experiment_config,
                records_override=records,
                mode="sweep",
                run_name_override=f"experiment_{index:03d}",
            )
            metrics = result["validation_metrics"]
            rows.append(
                {
                    "experiment": index,
                    "status": "ok",
                    "run_dir": result["run_dir"],
                    **experiment,
                    "threshold_bad": result["selected_threshold_bad"],
                    "validation_false_pass": metrics["false_pass"],
                    "validation_false_pass_rate": metrics["false_pass_rate"],
                    "validation_bad_recall": metrics["bad_recall"],
                    "validation_false_reject": metrics["false_reject"],
                    "validation_false_reject_rate": metrics["false_reject_rate"],
                    "validation_good_recall": metrics["good_recall"],
                    "validation_average_precision_bad": metrics["average_precision_bad"],
                    "validation_balanced_accuracy": metrics["balanced_accuracy"],
                }
            )
        except Exception as error:
            logger.exception("Experiment %d failed", index)
            rows.append(
                {
                    "experiment": index,
                    "status": "failed",
                    "error": str(error),
                    "traceback": traceback.format_exc(),
                    **experiment,
                }
            )
        finally:
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

        pd.DataFrame(rows).to_csv(sweep_dir / "leaderboard_partial.csv", index=False, encoding="utf-8")

    leaderboard = pd.DataFrame(rows)
    successful = leaderboard[leaderboard["status"] == "ok"].copy()
    if not successful.empty:
        successful = successful.sort_values(
            [
                "validation_false_pass",
                "validation_false_reject",
                "validation_average_precision_bad",
            ],
            ascending=[True, True, False],
        )
        successful["safety_rank"] = range(1, len(successful) + 1)
        failed = leaderboard[leaderboard["status"] != "ok"]
        leaderboard = pd.concat([successful, failed], ignore_index=True)
    leaderboard.to_csv(sweep_dir / "leaderboard.csv", index=False, encoding="utf-8")

    best = None
    if not successful.empty:
        best = successful.iloc[0].to_dict()
        write_json(best, sweep_dir / "best_validation_experiment.json")

    summary = {
        "sweep_dir": str(sweep_dir),
        "experiments_requested": len(combinations),
        "experiments_successful": int((leaderboard["status"] == "ok").sum()),
        "experiments_failed": int((leaderboard["status"] != "ok").sum()),
        "best_validation_experiment": best,
        "important": (
            "The leaderboard is validation-only. After choosing hyperparameters, run one normal "
            "training job with evaluation.evaluate_test=true to evaluate the frozen test set once."
        ),
    }
    write_json(summary, sweep_dir / "sweep_summary.json")
    return summary
