"""Weight policy and safety tests; network access is always mocked."""
from __future__ import annotations

import hashlib
import io
from contextlib import ExitStack
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import MagicMock, patch

from nilt.common import DEFAULTS, merge_dict, read_json, write_json
from nilt.engine import TrainingStopped
from nilt.weights import (_OfficialRedirects, _official_url, download_policy,
                          ensure_pretrained_weights, weight_descriptor)


PAYLOAD = b"official-test-weight-payload"
DIGEST = hashlib.sha256(PAYLOAD).hexdigest()
DESCRIPTOR = {"model": "resnet18", "weight": "IMAGENET1K_V1",
              "filename": "resnet18__IMAGENET1K_V1.pth", "sha256_prefix": DIGEST[:8],
              "source": f"https://download.pytorch.org/models/resnet18-{DIGEST[:8]}.pth"}


class Response(io.BytesIO):
    def __init__(self, payload=PAYLOAD, content_length=None, url=None):
        super().__init__(payload)
        self.headers = {"Content-Length": str(len(payload) if content_length is None else content_length)}
        self.url = url or DESCRIPTOR["source"]

    def geturl(self):
        return self.url


class WeightPolicyTests(unittest.TestCase):
    def config(self, root, enabled=True, profile="laptop"):
        return {"models": ["resnet18"], "pretrained": True, "weights_dir": str(root),
                "profile": profile, "download_missing_weights": enabled}

    def run_download(self, cfg, response=None, **kwargs):
        opener = MagicMock()
        opener.open.return_value = response or Response()
        with patch("nilt.weights.weight_descriptor", return_value=DESCRIPTOR), \
             patch("nilt.weights.build_opener", return_value=opener):
            entries = ensure_pretrained_weights(cfg, **kwargs)
        return entries, opener

    def test_identical_policy_for_all_profiles_and_atomic_success(self):
        for profile in ("laptop", "laptop_igpu", "workstation", "workstation_large"):
            with self.subTest(profile=profile), tempfile.TemporaryDirectory() as temporary:
                entries, opener = self.run_download(self.config(temporary, profile=profile))
                root = Path(temporary)
                self.assertEqual((root / DESCRIPTOR["filename"]).read_bytes(), PAYLOAD)
                self.assertEqual(entries[0]["sha256"], DIGEST)
                self.assertFalse(list(root.glob("*.download")))
                self.assertEqual(read_json(root / "weights_manifest.json"), entries)
                request = opener.open.call_args.args[0]
                self.assertEqual(request.get_method(), "GET")
                self.assertIsNone(request.data)
                self.assertEqual(request.full_url, DESCRIPTOR["source"])

    def test_old_config_and_explicit_offline_do_not_download(self):
        for explicit in (True, False):
            with self.subTest(explicit=explicit), tempfile.TemporaryDirectory() as temporary:
                cfg = self.config(temporary, enabled=False)
                if not explicit:
                    cfg.pop("download_missing_weights")
                with patch("nilt.weights.weight_descriptor", return_value=DESCRIPTOR), \
                     patch("nilt.weights.build_opener") as network:
                    with self.assertRaisesRegex(FileNotFoundError, "disabled"):
                        ensure_pretrained_weights(cfg)
                    network.assert_not_called()
                self.assertEqual(list(Path(temporary).iterdir()), [])

    def test_doctor_override_is_read_only(self):
        with tempfile.TemporaryDirectory() as temporary:
            cfg = self.config(temporary)
            target = Path(temporary) / DESCRIPTOR["filename"]
            target.write_bytes(PAYLOAD)
            with patch("nilt.weights.weight_descriptor", return_value=DESCRIPTOR), \
                 patch("nilt.weights.build_opener") as network:
                ensure_pretrained_weights(cfg, allow_download=False)
                network.assert_not_called()
            self.assertEqual(list(Path(temporary).iterdir()), [target])

    def test_explicit_manual_download_overrides_offline_configuration(self):
        with tempfile.TemporaryDirectory() as temporary:
            self.run_download(self.config(temporary, enabled=False), allow_download=True)
            self.assertTrue((Path(temporary) / DESCRIPTOR["filename"]).is_file())

    def test_verified_local_weights_are_reused_without_network(self):
        with tempfile.TemporaryDirectory() as temporary:
            target = Path(temporary) / DESCRIPTOR["filename"]
            target.write_bytes(PAYLOAD)
            with patch("nilt.weights.weight_descriptor", return_value=DESCRIPTOR), \
                 patch("nilt.weights.build_opener") as network:
                entries = ensure_pretrained_weights(self.config(temporary))
                network.assert_not_called()
            self.assertEqual(entries[0]["sha256"], DIGEST)

    def test_corrupt_existing_file_is_preserved_and_not_silently_replaced(self):
        with tempfile.TemporaryDirectory() as temporary:
            target = Path(temporary) / DESCRIPTOR["filename"]
            target.write_bytes(b"unverified-existing-data")
            with patch("nilt.weights.weight_descriptor", return_value=DESCRIPTOR), \
                 patch("nilt.weights.build_opener") as network:
                with self.assertRaisesRegex(ValueError, "Checksum mismatch"):
                    ensure_pretrained_weights(self.config(temporary))
                network.assert_not_called()
            self.assertEqual(target.read_bytes(), b"unverified-existing-data")

    def test_corrupt_download_is_never_installed(self):
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaisesRegex(RuntimeError, "Checksum mismatch"):
                self.run_download(self.config(temporary), Response(b"corrupted"))
            self.assertFalse(list(Path(temporary).iterdir()))

    def test_truncated_download_is_never_installed(self):
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaisesRegex(RuntimeError, "Incomplete download"):
                self.run_download(self.config(temporary), Response(content_length=1000))
            self.assertFalse(list(Path(temporary).iterdir()))

    def test_cancel_during_download_cleans_temporary_files(self):
        with tempfile.TemporaryDirectory() as temporary:
            calls = []

            def stop():
                calls.append(True)
                return "operator_cancel" if len(calls) == 4 else None

            with self.assertRaisesRegex(TrainingStopped, "operator_cancel"):
                self.run_download(self.config(temporary), stop_check=stop)
            self.assertFalse(list(Path(temporary).iterdir()))

    def test_deadline_prevents_network_access(self):
        with tempfile.TemporaryDirectory() as temporary:
            with patch("nilt.weights.weight_descriptor", return_value=DESCRIPTOR), \
                 patch("nilt.weights.build_opener") as network:
                with self.assertRaisesRegex(TrainingStopped, "budget_exhausted"):
                    ensure_pretrained_weights(self.config(temporary), deadline=time.time() - 1)
                network.assert_not_called()

    def test_previous_manifest_models_are_retained(self):
        with tempfile.TemporaryDirectory() as temporary:
            other = {"model": "resnet50", "sha256": "recorded"}
            write_json(Path(temporary) / "weights_manifest.json", [other])
            self.run_download(self.config(temporary))
            actual = read_json(Path(temporary) / "weights_manifest.json")
            self.assertEqual(actual[0], other)
            self.assertEqual(actual[1]["model"], "resnet18")

    def test_other_urls_and_redirects_are_rejected(self):
        for url in ("https://example.com/models/model-abcdef12.pth",
                    "http://download.pytorch.org/models/model-abcdef12.pth",
                    "https://download.pytorch.org.evil.test/models/model-abcdef12.pth",
                    "https://download.pytorch.org/models/model-abcdef12.pth?images=private",
                    "https://user:pass@download.pytorch.org/models/model-abcdef12.pth",
                    "https://download.pytorch.org/models/../model-abcdef12.pth"):
            with self.subTest(url=url), self.assertRaises(ValueError):
                _official_url(url)
        with self.assertRaises(ValueError):
            _OfficialRedirects().redirect_request(None, None, 302, "", {}, "https://example.com/file")

    def test_unexpected_final_response_url_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaisesRegex(RuntimeError, "official HTTPS"):
                self.run_download(self.config(temporary), Response(url="https://example.com/file"))
            self.assertFalse(list(Path(temporary).iterdir()))

    def test_policy_validation(self):
        for cfg in ({"download_missing_weights": "true"},
                    {"weight_download_timeout_seconds": 0},
                    {"weight_download_timeout_seconds": True},
                    {"weight_download_timeout_seconds": float("inf")}):
            with self.subTest(cfg=cfg), self.assertRaises(ValueError):
                download_policy(cfg)

    def test_descriptor_is_bound_to_supported_torchvision_metadata(self):
        tv = MagicMock()
        tv.models.get_model_weights.return_value = {
            "IMAGENET1K_V1": type("OfficialWeight", (), {"url": DESCRIPTOR["source"]})()}
        with patch("nilt.engine.torch_modules", return_value=(None, tv)):
            actual = weight_descriptor("resnet18")
            self.assertEqual(actual, DESCRIPTOR)
            tv.models.get_model_weights.assert_called_once_with("resnet18")
            with self.assertRaisesRegex(ValueError, "Unsupported"):
                weight_descriptor("user_supplied_model")

    def test_descriptor_requires_published_hash_prefix(self):
        tv = MagicMock()
        tv.models.get_model_weights.return_value = {
            "IMAGENET1K_V1": type("OfficialWeight", (), {"url": "https://download.pytorch.org/models/resnet18.pth"})()}
        with patch("nilt.engine.torch_modules", return_value=(None, tv)):
            with self.assertRaisesRegex(ValueError, "no verifiable"):
                weight_descriptor("resnet18")

    def test_search_download_stop_is_not_a_failed_trial(self):
        from nilt.search import run_search
        for reason, expected in (("operator_cancel", "SEARCH_CANCELLED"),
                                 ("operator_pause", "SEARCH_PAUSED"),
                                 ("budget_exhausted", "SEARCH_PAUSED")):
            with self.subTest(reason=reason), tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
                run = Path(temporary)
                cfg = merge_dict(DEFAULTS, {"models": ["resnet18"], "previous_run": None})
                stack.enter_context(patch("nilt.workflow.open_run", return_value=(cfg, [])))
                stack.enter_context(patch("nilt.search.preflight_sampler"))
                stack.enter_context(patch("nilt.search._persist_contract"))
                stack.enter_context(patch("nilt.search._study", return_value=object()))
                stack.enter_context(patch("nilt.search._budget_start", return_value=(time.time(), {}, time.time() + 100)))
                stack.enter_context(patch("nilt.search._budget_finish"))
                published = stack.enter_context(patch("nilt.search._publish"))
                state = stack.enter_context(patch("nilt.workflow.write_state"))
                weights = stack.enter_context(patch("nilt.engine.check_weights", side_effect=TrainingStopped(reason)))
                trial = stack.enter_context(patch("nilt.search._run_trial"))
                self.assertEqual(run_search(run), run)
                self.assertEqual(published.call_args.args[2], expected)
                self.assertEqual(state.call_args.args[1], expected)
                self.assertIn("deadline", weights.call_args.kwargs)
                trial.assert_not_called()


if __name__ == "__main__":
    unittest.main()
