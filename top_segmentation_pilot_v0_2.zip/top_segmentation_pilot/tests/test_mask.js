/* Run with: node tests/test_mask.js. No npm installation is needed. */
'use strict';
const assert = require('node:assert/strict');
const path = require('node:path');
require(path.join(__dirname, '..', 'topseg', 'web', 'mask.js'));
const M = globalThis.TopsegMask;
let mask = new Uint8Array(100);
M.ellipse(mask, 10, 10, 5, 5, 3, 3, 1);
assert(mask[5 + 5 * 10] === 1 && mask[0] === 0);
M.rectangle(mask, 10, 10, {x: 0, y: 0}, {x: 2, y: 2}, 2);
assert.equal(M.counts(mask)[2], 4);
assert.deepEqual(M.decode(M.encode(mask), mask.length), mask);
assert.throws(() => M.decode([[0, 99]], 100));
assert.throws(() => M.decode([[3, 100]], 100));
mask = new Uint8Array(100);
M.polygon(mask, 10, 10, [{x: 1, y: 1}, {x: 6, y: 1}, {x: 1, y: 6}], 2);
assert.equal(mask[2 + 2 * 10], 2); assert.equal(mask[6 + 6 * 10], 0);
M.stroke(mask, 10, 10, {x: 2, y: 2}, {x: 2, y: 2}, 1, 0);
assert.equal(mask[2 + 2 * 10], 0);
mask.fill(0);
M.stroke(mask, 10, 10, {x: 1, y: 1}, {x: 8, y: 1}, 1, 1);
for (let x = 1; x <= 8; x++) assert.equal(mask[x + 10], 1);
assert.deepEqual(M.counts(mask), [92, 8, 0]);
mask.fill(0);
M.rectangle(mask, 10, 10, {x: -100, y: -100}, {x: 100, y: 100}, 2);
assert.deepEqual(M.counts(mask), [0, 0, 100]);
console.log('PASS: discrete circle/ellipse, rectangle, polygon, eraser, single-pixel brush, clipping, RLE integrity.');

// One footprint spanning the boundary must become two classes; background stays 0.
const boundary = {type: 'polygon', points: [{x: 0, y: 0}, {x: 5, y: 0}, {x: 5, y: 10}, {x: 0, y: 10}]};
const region = M.regionMask(10, 10, boundary);
const footprint = new Uint8Array(100); M.rectangle(footprint, 10, 10, {x: 3, y: 3}, {x: 7, y: 7}, 1);
const objects = [{id: 'one', mask: M.compact(footprint), visible: true}];
assert.deepEqual(M.counts(M.compose(objects, region)), [84, 8, 8]);
objects[0].visible = false;
assert.deepEqual(M.counts(M.compose(objects, region)), [84, 8, 8]);
assert.deepEqual(M.counts(M.compose(objects, region, true)), [100, 0, 0]);
objects.push({id: 'two', mask: M.compact(footprint), visible: true});
assert.deepEqual(M.compose(objects, region), M.compose(objects.slice(1), region), 'Deleting an overlapping object preserves the remaining footprint');
assert.deepEqual(M.counts(M.compose(objects, M.regionMask(10, 10, {type: 'polygon', points: [{x: 0, y: 0}, {x: 10, y: 0}, {x: 10, y: 10}, {x: 0, y: 10}]}))), [84, 16, 0]);
const octagon = M.octagon({x: 1, y: 1}, {x: 9, y: 9});
assert.equal(octagon.points.length, 8); assert(M.validPolygon(octagon.points));
assert.equal(M.regionMask(10, 10, octagon)[1 + 10], 0); assert.equal(M.regionMask(10, 10, octagon)[5 + 50], 1);
assert(!M.validPolygon([{x: 1, y: 1}, {x: 8, y: 8}, {x: 1, y: 8}, {x: 8, y: 1}]));
assert(!M.validPolygon([{x: 1, y: 1}, {x: 2, y: 2}, {x: 3, y: 3}]));
assert(!M.validPolygon([{x: 1, y: 1}, {x: 8, y: 1}, {x: 8, y: 8}, {x: 8, y: 1}]));
assert.deepEqual(M.bounds(M.compact(footprint), 10, 10), {left: 3, right: 6, top: 3, bottom: 6, area: 16});
assert.deepEqual(M.dense(M.sparseDecode(M.encode(M.compact(footprint)), 100)), footprint);
assert.throws(() => M.sparseDecode([[1, 101]], 100));

// Seeded independent dense-oracle checks catch span splitting/merging/edge clipping.
let seed = 937511;
function random() { seed = (1664525 * seed + 1013904223) >>> 0; return seed / 4294967296; }
for (let trial = 0; trial < 120; trial++) {
  const original = Uint8Array.from({length: 713}, () => random() < 0.35 ? 1 : 0);
  const eraser = Uint8Array.from({length: 713}, () => random() < 0.25 ? 1 : 0);
  const compact = M.compact(original), before = JSON.stringify(compact);
  assert.deepEqual(M.decode(M.encode(compact), original.length), original);
  assert.deepEqual(M.dense(M.subtract(compact, M.compact(eraser))), original.map((v, i) => eraser[i] ? 0 : v));
  assert.equal(JSON.stringify(compact), before, 'Erasing must not mutate a history snapshot');
  const a = {x: random() * 60 - 15, y: random() * 50 - 10}, b = {x: random() * 60 - 15, y: random() * 50 - 10}, size = 1 + random() * 14;
  const dense = new Uint8Array(31 * 23); M.stroke(dense, 31, 23, a, b, size, 1);
  assert.deepEqual(M.dense(M.strokeFootprint(31, 23, a, b, size)), dense);
}
// Tiny objects in a large image allocate occupied spans, never one dense image each.
const tiny = M.sparseDecode([[0, 4000000], [1, 1], [0, 194303]], 2048 * 2048);
assert.deepEqual(tiny.spans, [[4000000, 1]]); assert.equal(tiny.length, 4194304);
console.log('PASS: auto inner/outer split, hidden display-only union, overlap deletion, polygon validation, sparse object storage, immutable erase, clipped strokes, RLE round trips.');
