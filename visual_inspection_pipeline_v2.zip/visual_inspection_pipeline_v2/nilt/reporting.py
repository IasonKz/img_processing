from __future__ import annotations

import hashlib
import html
from pathlib import Path
import shutil

import numpy as np

from .common import write_csv, write_json
from .policy import metrics


def export_predictions(rows, scores, threshold, out, *, copy_images=True, labeled=True, confidence=.95,
                       score_type="bad_probability_uncalibrated", model_version=""):
    """Copy untouched input files. Probability-like scores are explicitly uncalibrated."""
    out = Path(out)
    scores = np.asarray(scores, dtype=float)
    if scores.ndim != 1 or len(rows) != len(scores) or not np.isfinite(scores).all():
        raise ValueError("Invalid scores or mismatched row count; no classification folders created.")
    if not np.isscalar(threshold) or not np.isfinite(threshold):
        raise ValueError("Threshold must be finite.")
    if out.exists() and any(out.iterdir()):
        raise FileExistsError(f"Refusing to mix old/new classifications in {out}; choose a new output folder.")
    out.mkdir(parents=True, exist_ok=True)
    if copy_images:
        for label in ("good", "bad"):
            (out / "predicted" / label).mkdir(parents=True, exist_ok=True)
        if labeled:
            for kind in ("bad_passed_as_good_FN", "good_rejected_as_bad_FP"):
                (out / "errors" / kind).mkdir(parents=True, exist_ok=True)
    reports, wrong = [], []
    for row, score in zip(rows, scores):
        prediction = "bad" if score >= threshold else "good"
        key = hashlib.sha256(row["relative_path"].encode()).hexdigest()[:24]
        source = Path(row["path"])
        filename = f"{key}__{source.stem[:65]}{source.suffix.lower()}"
        error = ""
        if labeled:
            truth = "bad" if int(row["label"]) == 0 else "good"
            if truth != prediction:
                error = "bad_passed_as_good_FN" if truth == "bad" else "good_rejected_as_bad_FP"
        item = {"source_path": row["path"], "relative_path": row["relative_path"],
                "group": row.get("group", ""), "true_class": truth if labeled else "",
                "predicted_class": prediction, "score": float(score), "score_type": score_type,
                "bad_score": float(score) if score_type == "bad_probability_uncalibrated" else "",
                "good_score": float(1 - score) if score_type == "bad_probability_uncalibrated" else "", "threshold": threshold,
                "model_version": model_version,
                "distance_to_threshold": float(abs(score - threshold)), "error_type": error,
                "copied_filename": filename if copy_images else ""}
        reports.append(item)
        if error:
            wrong.append(item)
        if copy_images:
            shutil.copy2(source, out / "predicted" / prediction / filename)
            if error:
                shutil.copy2(source, out / "errors" / error / filename)
    columns = ["source_path", "relative_path", "group", "true_class", "predicted_class", "score", "score_type", "model_version", "bad_score",
               "good_score", "threshold", "distance_to_threshold", "error_type", "copied_filename"]
    write_csv(out / "predictions.csv", reports, columns)
    write_csv(out / "wrong_predictions.csv", wrong, columns)
    write_csv(out / "review_priority.csv", sorted(reports, key=lambda r: (not bool(r["error_type"]), r["distance_to_threshold"])), columns)
    met = None
    if labeled and rows:
        met = metrics([r["label"] for r in rows], scores, threshold,
                      [r.get("group", str(i)) for i, r in enumerate(rows)], confidence)
        write_json(out / "metrics.json", met)
        plot_metrics(met, out / "confusion_matrix.png")
    write_json(out / "decision_rule.json", {
        "rule": "score >= threshold => bad; otherwise good", "threshold": threshold, "score_type": score_type,
        "stored_labels": {"bad": 0, "good": 1}, "positive_event_for_metrics": "bad",
        "scores_are_calibrated_probabilities": False,
        "interpretation": "Decision support; qualification status is in selected.json/final_test_summary.json."})
    write_json(out / "export_complete.json", {"n_images": len(rows)})
    return met


def plot_metrics(m, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    matrix = np.array([[m["bad_detected_TP"], m["bad_passed_as_good_FN"]],
                       [m["good_rejected_as_bad_FP"], m["good_accepted_TN"]]])
    fig, ax = plt.subplots(figsize=(5, 4), layout="constrained")
    ax.imshow(matrix, cmap="Blues")
    for (i, j), value in np.ndenumerate(matrix):
        ax.text(j, i, str(value), ha="center", va="center",
                color="white" if value > matrix.max() * .5 else "black", fontsize=18)
    ax.set(xticks=[0, 1], yticks=[0, 1], xticklabels=["bad", "good"], yticklabels=["bad", "good"],
           xlabel="Predicted", ylabel="True", title="Bad is the positive event")
    fig.savefig(path, dpi=150)
    plt.close(fig)


def leaderboard(candidates, selected, out):
    columns = ["name", "threshold", "n_members", "bad_passed_as_good_FN", "bad_escape_rate",
               "bad_recall", "good_rejected_as_bad_FP", "good_reject_rate", "accepted_contamination",
               "pr_auc_bad", "accuracy", "n_bad_units", "bad_unit_escape_upper", "selection_seconds",
               "empirical_target_met", "selected"]
    rows = []
    for c in candidates:
        rows.append({"name": c["name"], "threshold": c["threshold"], "n_members": len(c["members"]),
                     **c["selection_metrics"], "selection_seconds": c["selection_seconds"],
                     "empirical_target_met": c["empirical_target_met"], "selected": c["name"] == selected["name"]})
    write_csv(Path(out) / "leaderboard.csv", rows, columns)
    table = "<tr>" + "".join(f"<th>{html.escape(k)}</th>" for k in columns) + "</tr>"
    for row in rows:
        table += "<tr>" + "".join(f"<td>{html.escape(str(row[k]))}</td>" for k in columns) + "</tr>"
    page = """<!doctype html><html lang="en"><meta charset="utf-8"><title>Model comparison</title>
<style>body{font:15px system-ui;margin:32px;color:#182738}table{border-collapse:collapse;font-size:13px}
th,td{border:1px solid #cdd6df;padding:9px;text-align:left}th{background:#eaf0f6}p{max-width:950px}</style>
<h1>Selection-set comparison</h1><p>Bad = event of interest. Select models here; final test is kept separate.
Scores are uncalibrated. Unit confidence bounds assume independent units. Selection estimates are subject to model-selection bias;
the fixed winner needs an independent final test and later production monitoring.</p>"""
    page += f"<p><strong>Selected: {html.escape(selected['name'])}</strong></p><table>{table}</table></html>"
    (Path(out) / "comparison.html").write_text(page, encoding="utf-8")


def html_table(mapping):
    import json
    return "<table>" + "".join("<tr><th>" + html.escape(str(k)) + "</th><td><pre>" +
                               html.escape(json.dumps(v, ensure_ascii=False, indent=2) if isinstance(v, (dict, list)) else str(v)) +
                               "</pre></td></tr>" for k, v in mapping.items()) + "</table>"


def render_run_report(run):
    """Generate a portable operational report using recorded evidence only."""
    from .common import read_json
    run = Path(run)
    documents = {}
    for filename in ("model_state.json", "config.json", "split_summary.json", "selected.json",
                     "final_test_summary.json", "environment.json", "comparison_with_previous.json"):
        path = run / filename
        if path.exists():
            documents[filename] = read_json(path)
    title = f"Visual Inspection — {run.parent.name} / {run.name}"
    body = f"<h1>{html.escape(title)}</h1><p>Bad is the event of interest. Unmeasured performance is not inferred.</p>"
    for filename, value in documents.items():
        if filename == "selected.json":
            value = {k: v for k, v in value.items() if k not in ("members", "threshold_metrics")}
        body += f"<h2>{html.escape(filename)}</h2>" + html_table(value)
    progress = {}
    for path in sorted((run / "models").glob("*/progress.json")):
        progress[path.parent.name] = read_json(path)
    if progress:
        body += "<h2>Model training progress</h2>" + html_table(progress)
    page = '<!doctype html><html lang="en"><meta charset="utf-8"><title>' + html.escape(title) + "</title>"
    page += '<style>body{font:15px system-ui;margin:30px;color:#1c2c39;max-width:1250px}table{border-collapse:collapse;width:100%}th,td{padding:9px;border:1px solid #ccd5dd;text-align:left;vertical-align:top}th{width:25%;background:#edf2f5}pre{white-space:pre-wrap;overflow-wrap:anywhere;margin:0;font-size:12px}h2{margin-top:32px}</style>'
    (run / "model_report.html").write_text(page + body + "</html>", encoding="utf-8")
