"""Integration checks for persistent templates, search isolation and deployment."""
from pathlib import Path
import json
import numpy as np
import pytest
from PIL import Image
from topseg.common import load_config, sha256, read_json
from topseg.project import Project, ConflictError
from topseg.classical import default_roi
from topseg.search import run_search, settings, prepare_study
from topseg.operations import evaluate_trial, export_model, export_dataset
from topseg.inference import load_model


def fixture(tmp_path,count=9):
    source=tmp_path/'source';source.mkdir()
    for i in range(count):
        a=np.full((64,96,3),80+i,np.uint8);a[25:34,43:52]=220;a[7:14,7:16]=30
        Image.fromarray(a).save(source/f'unit_{i}.png')
    config=tmp_path/'project.yaml'
    config.write_text('input_dir: source\nproject_dir: annotations\noutput_dir: results\ngroup_regex: "(unit_[0-9]+)"\n')
    cfg=load_config(config);p=Project(cfg);p.import_images()
    for item in p.items():
        opened=p.open_image(item['id']);mask=np.zeros((64,96),np.uint8);mask[25:34,43:52]=1;mask[7:14,7:16]=2
        p.save_annotation(item['id'],mask,default_roi(96,64),expected_revision=opened['revision'],approved=True)
    return cfg,p


def test_persistent_polygon_and_reapproval(tmp_path):
    cfg,p=fixture(tmp_path)
    row=p.items()[0];roi=default_roi(96,64);roi['points'][0]['x']+=3
    old_hash=sha256(p.mask_path(row['id']));source_hash=sha256(Path(cfg['input_dir'])/'unit_0.png')
    p.save_polygon_template(row['id'],roi,0)
    reloaded=Project(cfg)
    assert reloaded.template_roi(192,128)['points'][0]['x']==pytest.approx(roi['points'][0]['x']*2)
    assert reloaded.apply_polygon_template()['changed']==0
    assert sha256(p.mask_path(row['id']))==old_hash
    assert reloaded.apply_polygon_template(True)['changed']==9
    assert all(r['status']=='draft' for r in p.items())
    assert sha256(Path(cfg['input_dir'])/'unit_0.png')==source_hash
    assert (p.root/'history'/row['id']/f"{row['revision']:06d}"/'mask.png').exists()
    with pytest.raises(ConflictError):p.save_polygon_template(row['id'],roi,0)
    im=Image.new('RGB',(192,128),(111,112,113));im.save(Path(cfg['input_dir'])/'unit_20.png');p.import_images()
    new=next(r for r in p.items() if r['relative_path']=='unit_20.png')
    assert p.open_image(new['id'])['roi']==p.template_roi(192,128)


def test_optuna_resume_native_evaluation_and_exports(tmp_path):
    cfg,p=fixture(tmp_path)
    raw={'models':['small_unet'],'image_sizes':[64],'batch_sizes':[2],'losses':['ce_dice'],
         'epochs':1,'trials':1,'device':'cpu','cpu_threads':2,'study_name':'smoke'}
    job=tmp_path/'job';job.mkdir()
    result=run_search(cfg,raw,job)
    assert result['best'] is not None
    second=run_search(cfg,raw,job)
    assert len(second['trials'])==2
    root=Path(result['output_dir']);split=read_json(root/'split.json')
    roles=[set(split[k+'_ids']) for k in ('train','validation','test')]
    assert all(roles) and not (roles[0]&roles[1] or roles[0]&roles[2] or roles[1]&roles[2])
    with pytest.raises(ValueError,match='different search space'):
        prepare_study(cfg,settings({**raw,'image_sizes':[128]}))
    req={'study_name':'smoke','trial':result['best']['number'],'device':'cpu'}
    out=evaluate_trial(cfg,req,job)
    assert out['metrics']['images']==len(roles[1])
    mask=next(Path(out['output_dir']).glob('*.mask.png'))
    assert Image.open(mask).size==(96,64)
    evaluate_trial(cfg,{**req,'split':'test'},job)
    other=1 if req['trial']==0 else 0
    with pytest.raises(ValueError,match='locked'):
        evaluate_trial(cfg,{**req,'trial':other,'split':'test'},job)
    exported=export_model(cfg,{**req,'format':'package'},job)
    assert Path(exported['file']).is_file()
    model,state,device=load_model(root/'trials'/f"{req['trial']:05d}"/'best.pt')
    import torch
    with torch.inference_mode():assert model(torch.zeros(1,3,64,64)).shape==(1,3,64,64)
    data=export_dataset(cfg,{},job)
    assert data['images']==9


def test_invalid_controls_rejected():
    for change in [{'trials':-1},{'hours':float('nan')},{'val_fraction':.9,'test_fraction':.2},{'models':[]},{'learning_rate':[.1,.01]}]:
        with pytest.raises(ValueError):settings(change)
