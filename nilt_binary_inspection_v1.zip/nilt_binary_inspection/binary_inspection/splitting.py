from __future__ import annotations

from collections import defaultdict
from pathlib import Path

import numpy as np
from sklearn.model_selection import GroupShuffleSplit

from .audit import audit
from .common import LOG, SPLITS, file_sha256, object_hash, output_dir, read_csv, read_json, write_csv, write_json


def data_signature(rows: list[dict]) -> str:
    fields = ("path", "relpath", "file_sha256", "pixel_sha256", "input_sha256", "unit_id", "tray_id", "batch_id", "physical_group", "group_id", "split")
    return object_hash(sorted(tuple(str(r.get(k, "")) for k in fields) + (int(r["label"]),) for r in rows))


def _validate_splits(rows: list[dict], minimum: int) -> None:
    groups, pixels = defaultdict(set), defaultdict(set)
    for row in rows:
        if row["split"] not in SPLITS:
            raise ValueError(f"Invalid split: {row['split']}")
        groups[row["group_id"]].add(row["split"])
        pixels[row["input_sha256"]].add(row["split"])
    if any(len(s) > 1 for s in groups.values()) or any(len(s) > 1 for s in pixels.values()):
        raise ValueError("Leakage: same group or same model input occurs in multiple splits")
    for split in SPLITS:
        for label in (0, 1):
            count = sum(r["split"] == split and int(r["label"]) == label for r in rows)
            if count < minimum:
                raise ValueError(f"{split} has only {count} examples of class {label}; need >= {minimum}. Add independent data or supply feasible explicit splits")


def allocate_splits(rows: list[dict], cfg: dict) -> list[dict]:
    if any(r.get("requested_split") for r in rows):
        if not all(r.get("requested_split") for r in rows):
            raise ValueError("When using metadata.split, assign every image to train/tune/calibration/selection/test")
        result = [{**r, "split": r["requested_split"]} for r in rows]
        _validate_splits(result, int(cfg["split"]["min_per_class_per_split"]))
        return result
    fractions = cfg["split"]["fractions"]
    rng_seed = int(cfg["project"]["seed"])
    labels = np.array([int(r["label"]) for r in rows])
    groups = np.array([r["group_id"] for r in rows])
    if len(np.unique(groups)) < len(SPLITS):
        raise ValueError("Fewer than five independent groups: cannot make five non-overlapping sets. Check duplicate chains / group IDs; do not silently random-split correlated images")
    best, best_score = None, float("inf")
    for attempt in range(int(cfg["split"]["attempts"])):
        remaining = np.arange(len(rows))
        assigned = np.full(len(rows), "train", dtype=object)
        remaining_fraction = 1.0
        try:
            for k, split in enumerate(("test", "selection", "calibration", "tune")):
                relative = fractions[split] / remaining_fraction
                gss = GroupShuffleSplit(n_splits=1, test_size=relative, random_state=rng_seed + attempt * 7 + k)
                a, b = next(gss.split(remaining, labels[remaining], groups[remaining]))
                assigned[remaining[b]] = split
                remaining = remaining[a]
                remaining_fraction -= fractions[split]
            candidate = [{**row, "split": str(assigned[i])} for i, row in enumerate(rows)]
            _validate_splits(candidate, int(cfg["split"]["min_per_class_per_split"]))
        except ValueError:
            continue
        score = 0.0
        for split in SPLITS:
            for label in (0, 1):
                target = max(1.0, sum(labels == label) * fractions[split])
                observed = sum((assigned == split) & (labels == label))
                score += ((observed - target) / target) ** 2
        if score < best_score:
            best, best_score = candidate, float(score)
    if best is None:
        raise ValueError("Cannot make a valid grouped split with both classes in every subset. See audit group counts; add groups or use metadata.split. Never bypass this using duplicate images")
    return best


def prepare(cfg: dict) -> dict:
    folder = output_dir(cfg)
    if (folder / "manifest.csv").exists():
        # Reuse immutable splits; do not silently repartition a previous run.
        verify_manifest(cfg)
        LOG.info("Existing manifest verified and reused. New data require a NEW output_dir")
        return read_json(folder / "dataset.json")
    rows, audit_summary = audit(cfg)
    if not audit_summary["passed"]:
        raise ValueError("Audit stopped preparation: " + ", ".join(audit_summary["fatal_errors"]) + ". See audit/*.csv")
    rows = allocate_splits(rows, cfg)
    warm = cfg["paths"].get("warm_start_run")
    if warm:
        old_path = Path(warm) / "manifest.csv"
        if not old_path.exists():
            raise ValueError("warm_start_run must point to a previous run containing manifest.csv")
        old = read_csv(old_path)
        old_hash_split = {r["input_sha256"]: r["split"] for r in old}
        old_group_split = {r["physical_group"]: r["split"] for r in old if not r["physical_group"].startswith("image:")}
        leak = []
        for row in rows:
            old_splits = {old_hash_split.get(row["input_sha256"]), old_group_split.get(row["physical_group"])} - {None}
            if any(previous != row["split"] for previous in old_splits):
                leak.append(row)
        if leak:
            raise ValueError("Warm-start would reassign previously seen examples/groups to a different split (including old TRAIN to new TEST). Use explicit metadata.split to preserve ALL old split roles, or a genuinely new independent dataset")
    counts = {s: {"good": sum(r["split"] == s and r["label"] == 0 for r in rows),
                   "bad": sum(r["split"] == s and r["label"] == 1 for r in rows),
                   "groups": len({r["group_id"] for r in rows if r["split"] == s})} for s in SPLITS}
    info = {"signature": data_signature(rows), "task": cfg["project"]["task"], "dataset_root": cfg["paths"]["dataset_root"],
            "audit": audit_summary, "counts": counts, "class_map": {"good": 0, "bad": 1},
            "preparation_signature": object_hash({k: cfg[k] for k in ("data", "audit", "split")}),
            "metadata_sha256": file_sha256(Path(cfg["paths"]["metadata_csv"])) if cfg["paths"].get("metadata_csv") else None}
    write_csv(folder / "manifest.csv", rows)
    write_json(folder / "dataset.json", info)
    write_json(folder / "config_snapshot.json", cfg)
    LOG.info("Saved immutable manifest. Counts: %s", counts)
    return info


def read_manifest(cfg: dict) -> list[dict]:
    rows = read_csv(output_dir(cfg) / "manifest.csv")
    for row in rows:
        row["label"] = int(row["label"])
    info = read_json(output_dir(cfg) / "dataset.json")
    if data_signature(rows) != info["signature"]:
        raise ValueError("manifest.csv changed. Create a new run instead of editing an existing split")
    if cfg["project"]["task"] != info["task"]:
        raise ValueError("Task mismatch: do not reuse TOP weights/manifests for VIG or BOTTOM")
    return rows


def verify_manifest(cfg: dict) -> None:
    folder = output_dir(cfg)
    rows = read_manifest(cfg)
    info = read_json(folder / "dataset.json")
    if Path(cfg["paths"]["dataset_root"]).resolve() != Path(info["dataset_root"]).resolve():
        raise ValueError("dataset_root changed for this run. Use a new output_dir")
    if object_hash({k: cfg[k] for k in ("data", "audit", "split")}) != info["preparation_signature"]:
        raise ValueError("Audit/data/split configuration changed. Use a new output_dir")
    metadata_digest = file_sha256(Path(cfg["paths"]["metadata_csv"])) if cfg["paths"].get("metadata_csv") else None
    if metadata_digest != info.get("metadata_sha256"):
        raise ValueError("Metadata CSV changed after preparation. Use a new output_dir")
    audited = read_csv(folder / "audit" / "manifest_audit.csv")
    for row in audited:
        path = Path(row["path"])
        if not path.exists() or file_sha256(path) != row["file_sha256"]:
            raise ValueError(f"Dataset changed since audit: {path}")
    root = Path(cfg["paths"]["dataset_root"])
    expected = {Path(r["path"]).resolve() for r in audited}
    invalid = read_csv(folder / "audit" / "invalid_images.csv")
    expected |= {Path(r["path"]).resolve() for r in invalid}
    actual = set()
    ext = {s.lower() for s in cfg["data"]["extensions"]}
    for key in ("good_folder", "bad_folder"):
        sub = root / cfg["data"][key]
        candidates = sub.rglob("*") if cfg["data"].get("recursive", True) else sub.glob("*")
        actual |= {p.resolve() for p in candidates if p.is_file() and p.suffix.lower() in ext}
    if actual != expected:
        raise ValueError("Images were added/removed after preparation. Create a new versioned output_dir")
    _validate_splits(rows, int(cfg["split"]["min_per_class_per_split"]))
