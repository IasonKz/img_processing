"""Pinned, checksum-verified safetensors provisioning from curated model cards."""
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
import time
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

from cvtester.catalog import select_model
from .common import _replace_file_with_retry, read_json


def _hub_url(url):
    parsed = urlsplit(url)
    host = parsed.hostname or ""
    if (parsed.scheme != "https" or parsed.username or parsed.password or parsed.port not in (None, 443)
            or not (host == "huggingface.co" or host.endswith(".huggingface.co") or host.endswith(".hf.co"))):
        raise ValueError("Only official Hugging Face HTTPS API and storage destinations are allowed.")
    return url


class HubRedirects(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        _hub_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _request_json(url, timeout, stop_check, deadline):
    from .weights import _check_stop
    _check_stop(stop_check, deadline)
    remaining = timeout if deadline is None else min(timeout, max(.001, deadline - time.time()))
    request = Request(_hub_url(url), headers={"User-Agent": "Inspection-Studio"})
    with build_opener(HubRedirects()).open(request, timeout=remaining) as response:
        _hub_url(response.geturl())
        data = response.read(2 * 1024 * 1024 + 1)
    _check_stop(stop_check, deadline)
    if len(data) > 2 * 1024 * 1024:
        raise ValueError("Model metadata exceeds the allowed size.")
    return json.loads(data)


def descriptor_for(name, cfg, timeout, stop_check=None, deadline=None):
    spec = select_model(name, cfg.get("model_usage", "commercial"))
    metadata = _request_json(f"https://huggingface.co/api/models/{spec.repo_id}?blobs=true",
                             timeout, stop_check, deadline)
    if metadata.get("cardData", {}).get("license") != spec.license:
        raise ValueError(f"{name}: pretrained weight license changed or is missing; review {spec.card_url}.")
    revision = metadata.get("sha", "")
    if not re.fullmatch(r"[a-f0-9]{40}", revision):
        raise ValueError("Missing pinned checkpoint revision.")
    files = {row["rfilename"]: row for row in metadata.get("siblings", [])}
    digest = files.get("model.safetensors", {}).get("lfs", {}).get("sha256", "")
    if not re.fullmatch(r"[a-f0-9]{64}", digest):
        raise ValueError(f"{name}: no published SHA-256 for model.safetensors; pickle fallback is disabled.")
    return {"model": name, "weight": spec.checkpoint, "filename": f"{name}__IMAGENET1K.safetensors",
            "source": f"https://huggingface.co/{spec.repo_id}/resolve/{revision}/model.safetensors",
            "revision": revision, "license": spec.license, "sha256_prefix": digest}


def validate_descriptor(descriptor, name, cfg):
    spec = select_model(name, cfg.get("model_usage", "commercial"))
    revision, digest = descriptor.get("revision", ""), descriptor.get("sha256_prefix", "")
    expected_source = f"https://huggingface.co/{spec.repo_id}/resolve/{revision}/model.safetensors"
    if (descriptor.get("model") != name or descriptor.get("weight") != spec.checkpoint
            or descriptor.get("filename") != f"{name}__IMAGENET1K.safetensors"
            or descriptor.get("license") != spec.license or descriptor.get("source") != expected_source
            or not re.fullmatch(r"[a-f0-9]{40}", revision) or not re.fullmatch(r"[a-f0-9]{64}", digest)):
        raise ValueError(f"Invalid pinned weight manifest entry for {name}.")


def _download(descriptor, target, timeout, stop_check, deadline):
    from .weights import _check_stop
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, filename = tempfile.mkstemp(prefix=target.name + ".", suffix=".download", dir=target.parent)
    temporary = Path(filename)
    try:
        _check_stop(stop_check, deadline)
        remaining = timeout if deadline is None else min(timeout, max(.001, deadline - time.time()))
        request = Request(_hub_url(descriptor["source"]), headers={"User-Agent": "Inspection-Studio"})
        digest, received = hashlib.sha256(), 0
        print(f"Downloading safetensors: {descriptor['model']} ({descriptor['license']})", flush=True)
        with os.fdopen(fd, "wb") as stream:
            fd = None
            with build_opener(HubRedirects()).open(request, timeout=remaining) as response:
                _hub_url(response.geturl())
                expected = response.headers.get("Content-Length")
                while True:
                    _check_stop(stop_check, deadline)
                    chunk = response.read(1024 * 1024)
                    if not chunk:
                        break
                    stream.write(chunk)
                    digest.update(chunk)
                    received += len(chunk)
            stream.flush()
            os.fsync(stream.fileno())
        _check_stop(stop_check, deadline)
        if expected and expected.isdigit() and received != int(expected):
            raise ValueError("Incomplete safetensors download.")
        if digest.hexdigest() != descriptor["sha256_prefix"]:
            raise ValueError("Checksum mismatch; safetensors weights were not installed.")
        _replace_file_with_retry(temporary, target)
        return digest.hexdigest()
    finally:
        if fd is not None:
            os.close(fd)
        temporary.unlink(missing_ok=True)


def ensure_hub_weights(cfg, names, enabled, timeout, stop_check=None, deadline=None):
    from .weights import _check_stop, _digest
    manifest = Path(cfg["weights_dir"]) / "weights_manifest.json"
    recorded = read_json(manifest) if manifest.is_file() else []
    if not isinstance(recorded, list):
        raise ValueError("Invalid weight manifest format.")
    existing = {item.get("model"): item for item in recorded if isinstance(item, dict)}
    entries = []
    for name in names:
        _check_stop(stop_check, deadline)
        select_model(name, cfg.get("model_usage", "commercial"))
        descriptor = existing.get(name)
        if descriptor is None:
            if not enabled:
                raise FileNotFoundError(f"Missing verified weights/provenance for {name}; automatic downloads are disabled. "
                                        "Use Download weights on a connected machine and copy weights_manifest.json too.")
            descriptor = descriptor_for(name, cfg, timeout, stop_check, deadline)
        validate_descriptor(descriptor, name, cfg)
        target = Path(cfg["weights_dir"]) / descriptor["filename"]
        if not target.is_file() and not enabled:
            raise FileNotFoundError(f"Missing local weights {target}; automatic downloads are disabled.")
        digest = _digest(target, stop_check, deadline) if target.is_file() else _download(
            descriptor, target, timeout, stop_check, deadline)
        if digest != descriptor["sha256_prefix"]:
            raise ValueError(f"Checksum mismatch for {target}; the existing file was preserved.")
        entries.append({**descriptor, "sha256": digest})
    return entries
