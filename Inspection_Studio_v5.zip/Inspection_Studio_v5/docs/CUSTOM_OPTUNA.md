# Custom Optuna search

The GUI exposes a validated search contract rather than arbitrary executable configuration. Use **Train & search → Configuration mode → Custom Optuna**. Start with **Load profile defaults**, make deliberate changes, then **Validate & preview contract** before starting.

## Two different searches

| Search | Training involved | Data role | Objective |
| --- | --- | --- | --- |
| Model hyperparameter search | Image-model training for each trial | Train and validation | Maximize the selected validation objective |
| Decision Lab tuning | Fixed model scores; optional small fit on held-out data | Calibration fit/tune only | Error/review targets and costs |

Changing a decision threshold cannot change AP or repair an image model that does not separate the classes. Model search never receives final-test feedback. Optuna chooses among the choices you declare; it does not invent a new architecture or guarantee a global optimum.

## Choose the model-search objective

| `search.objective` | What it measures | Operating implication |
| --- | --- | --- |
| `validation_ap` | Bad-class average precision across score thresholds | Default; useful when bad examples are the minority |
| `validation_roc_auc` | How often a bad example ranks above a good example | Measures ranking, without selecting an operating threshold |
| `validation_balanced_accuracy` | Mean of the two class recalls at the fixed 0.5 boundary | Rewards that particular binary operating point; limited to supervised classifiers |

All three objectives are maximized. The chosen objective drives supervised checkpoint selection, early stopping, pruning, and trial ranking. AP is still recorded separately so a displayed objective value is not mislabeled as AP. PatchCore searches currently require `validation_ap`.

These objectives are alternatives for separate experiments, not objectives averaged together. Final candidate comparison still uses the configured production error policy on its separate data role. Use Decision Lab to tune error/review trade-offs after model fitting. Changing the model-search objective does not guarantee that a requested bad-escape limit will be achievable.

## Strategy and time controls

- **Sampler:** TPE, Random, or Grid. TPE uses startup trials before guided sampling. Random is a simple baseline; finite Grid exhausts only the declared combinations if time permits.
- **Architectures:** selected independently at the top of the view. Each family has its own study and trial ceiling. New families are not automatically enabled.
- **Total budget, seconds:** any positive finite cumulative allowance, shared across data preparation, studies, confirmation, and finalization. Profiles suggest 7,200/21,600/43,200 seconds; they impose no maximum. For example, `86400` means 24 hours. This is the authoritative budget for Custom Optuna.
- **Execution device:** CPU, CUDA, or Auto, independent of the profile. Auto uses an available supported GPU, otherwise CPU. Explicit CUDA fails visibly if CUDA is unavailable. CPU threads and data-loader workers are also editable.
- **Trial timeout, seconds:** `0` uses the automatic fair-share slice. A positive value is a cumulative cooperative per-trial allowance, still limited by overall remaining time.
- **Maximum trials/architecture:** a ceiling, not a target or a promise of successful trials.
- **Minimum automatic trial, seconds:** lower bound for the automatic slice when enough total time remains; it does not create time beyond the overall deadline.
- **Shortlist/architecture:** number of leading completed candidates retained for later stages.
- **Reserves:** fractions of the allowance for seed confirmation and finalization, leaving time for trial training. Validation rejects incompatible settings.

Pause preserves resumable checkpoint state. An exhausted per-trial timeout ends that trial rather than repeatedly giving it a new allowance. A total timeout may leave insufficient time for comparison; explicitly requested finalization can evaluate an already frozen shortlist without training more trials.

The per-trial timeout is checked at safe batch/epoch boundaries. The overall supervisor can terminate an unresponsive worker at the operation deadline. Neither setting is a real-time guarantee during a native/GPU operation, disk flush, or OS process teardown. A hard stop can lose work after the last committed checkpoint.

## Stopping conditions are not interchangeable

| Control/outcome | Meaning |
| --- | --- |
| Epoch patience | Stop one training run after insufficient validation improvement |
| Pruner | End a trial because its intermediate performance is not promising |
| Minimum fine-tuning epochs | Do not prune a backbone before it has had the declared opportunity after warmup |
| Study patience | Stop an architecture after a run of completed trials without the required objective improvement; `0` disables it |
| Minimum objective improvement | Improvement counted for the architecture-level patience |
| Failure count | Stop an architecture after the configured true execution failures; `0` disables the cap |
| `PRUNED` | Deliberately stopped by pruning, not an execution error |
| `FAILED` / OOM | Recorded exception or memory exhaustion; inspect the actual error |
| `TIMEOUT` | Time allowance exhausted; not an AP score of zero |
| Paused/interrupted | Resume from a committed state when remaining allowance permits |
| `COMPLETE` | Completed objective result, including a run that ended normally through early stopping |

Storage state and operator outcome can differ: Optuna can store a timed-out trial as `FAIL` because it has no completed objective, while the recorded outcome is `TIMEOUT`. Such timeouts are excluded from the true technical-failure cap. Inspect both fields.

## Pruner controls

Supported choices are None, Median, Successive Halving, and Hyperband. Controls include pruning startup trials, warm-up steps, check interval, and reduction factor. These are method-specific: not every pruner consumes every field. The additional fine-tuning guard still prevents pruning during an inadequate warm-up-only opportunity.

Aggressive pruning is not necessarily useful in a two-hour search with only a handful of trials. Use None for a controlled baseline/debugging run, or the supplied conservative Median defaults before making pruning more aggressive.

## Searchable parameters

| Parameter | Meaning / restrictions |
| --- | --- |
| `mode` | `head_only`, `last_block`, or `full` |
| `optimizer` | `adamw` or `sgd` |
| `scheduler` | `cosine`, `plateau`, or `constant` |
| `learning_rate` | Trainable backbone rate; not active for a frozen backbone |
| `head_learning_rate` | New classification-head learning rate |
| `weight_decay` | Optimizer regularization |
| `momentum` | SGD momentum; inactive for AdamW |
| `imbalance` | `none`, `weighted_loss`, or `sampler` |
| `max_class_weight` | Cap for the class-weight strategy |
| `effective_batch_size` | Microbatch times gradient accumulation; must be divisible by fixed microbatch size |
| `warmup_epochs` | Warm-up duration, leaving the configured minimum fine-tuning epochs |
| `coreset_size` | PatchCore only; cannot exceed its configured reservoir |
| `projection_dim` | PatchCore only |

Fixed controls include maximum epochs, epoch patience, microbatch size, evaluation batch size, and AMP. Image strategy, patch geometry, and quarter-turn augmentation are fixed within a search; their changes create a new controlled experiment. Brightness/contrast and arbitrary rotations are not reintroduced.

All image backbones require declared pretrained weights. A newly trained classification head or logistic decision combiner is expected; it is not a randomly initialized image backbone.

## Parameter specifications

The GUI supports **Fixed**, **Choices**, and numerical **Range** forms. JSON equivalents are:

```json
{
  "mode": {"kind": "choices", "values": ["head_only", "full"]},
  "optimizer": {"kind": "fixed", "value": "adamw"},
  "learning_rate": {"kind": "range", "low": 0.000001, "high": 0.0001, "log": true},
  "head_learning_rate": {"kind": "choices", "values": [0.0001, 0.0003, 0.001]},
  "effective_batch_size": {"kind": "choices", "values": [8, 16]},
  "warmup_epochs": {"kind": "fixed", "value": 2}
}
```

This is a `search.space` fragment, not a whole project file. The live contract preview is the authoritative complete shape for GUI import/export. Numerical values must be finite; logarithmic bounds must be positive; categorical options must be supported. Fixed values need not be represented as a one-item search.

Per-architecture overrides use `search.model_spaces`:

```json
{
  "efficientnet_b0": {
    "learning_rate": {"kind": "range", "low": 0.000001, "high": 0.00003, "log": true}
  },
  "resnet18": {
    "effective_batch_size": {"kind": "choices", "values": [8, 16]}
  }
}
```

Only selected architectures may be named. Grid accepts fixed values, explicit finite choices, or linear stepped ranges; continuous/log ranges must be converted to explicit choices. `search.max_grid_combinations` is an editable enumeration guard, initially 10,000 combinations. Raise it deliberately for a larger finite grid. Materializing an exhaustive grid consumes memory; TPE or Random can explore a large space without enumerating every combination. A small grid can still take more time than the declared overall budget.

## Reproducibility and continuation

Use the JSON preview/download to preserve exact requested settings, and keep the run's resolved configuration, data manifest, study database, checkpoints, and logs. Search and training seeds are recorded separately. The first training seed drives trial search; further seeds consume the confirmation allowance.

Resume uses the recorded contract and cumulative remaining allowance. Changing a control does not mutate that contract or extend its original clock. To allocate additional time beyond an exhausted original budget, create a new experiment with the desired budget; do not edit ledger records. Start a new experiment to change the model list, parameter ranges, stopping policy, image strategy, or seed plan. Compare results only on compatible data roles; do not select a lucky test set or split seed.
