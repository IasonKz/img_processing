# Validation Record

Add-on version: 1.0.0  
Date: 2026-09-16  
Target: Visual Inspection Pipeline 2.0.0

## Completed checks

- 17 Python unittest checks passed. Coverage includes score ties, threshold equality, confusion counts, invalid/mismatched arrays, anomaly scores outside [0,1], average precision and ROC AUC against scikit-learn, output escaping, selection-record identity, altered selected-record detection, missing/incomplete runs and non-overwriting report creation.
- Confirmed that report generation leaves all input run files byte-for-byte unchanged and succeeds without any original image files.
- Confirmed that generated laptop/workstation configurations load through the original project's `nilt.common.load_project`. Laptop resolves to CPU/ResNet18/15 epochs; workstation resolves to CUDA/six architectures/two seeds/30 epochs. Quality policy is preserved.
- Generated a report from an existing v2 audit fixture, retaining its audit-only status and missing-metrics notices.
- Verified observed-loader forwarding, completed-window counting, partial final windows, interruption exclusion, epoch counters, CPU telemetry record serialization and restoration of runtime hooks using deterministic test doubles.
- JavaScript behavior checks passed under Node using a minimal DOM substitute: initial report render, known example rates, SVG creation, small learning-rate formatting, threshold-control updates, tab navigation, switching between selected and audit-only runs, and missing history handling.
- Python source compilation passed.

## Limits of this validation

PyTorch/Torchvision and CUDA hardware were unavailable in the build environment. A real training run through the observed wrapper and CUDA telemetry were not executed here. Telemetry correctness checks used deterministic loader/engine test doubles; they do not constitute model-training validation. Run an initial ResNet18 experiment in the installed environment before the full workstation roster.

A browser executable was unavailable. A bounded attempt to obtain the headless browser timed out. JavaScript rendering behavior was tested, but browser layout and PDF printing were not visually verified. `VISUAL_REPORT_DEMO.html` provides a clearly marked synthetic demonstration for local review.

No production images, inspection labels, model predictions or measured hardware benchmarks were available. Demo values are synthetic and do not establish achievable model performance.

## Reproduction

From the project root after adding the files:

```powershell
python -m unittest discover -s tests -p "test_visual_addon.py" -v
```

Optional JavaScript logic checks, when Node is installed:

```powershell
node tests/check_dashboard_js.cjs VISUAL_REPORT_DEMO.html
```

The original project's validation requirements remain in force. This reporting add-on does not authorize a release, alter a selected threshold, or replace independent final-test evidence.
