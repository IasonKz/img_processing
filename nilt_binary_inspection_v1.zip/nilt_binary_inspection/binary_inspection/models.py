from __future__ import annotations

from pathlib import Path
import os

os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")

import torch
from torch import nn
from torchvision import models as tv

from .common import LOG, file_sha256, torch_load, torch_save, write_json

DINO_NAME = "vit_small_patch14_dinov2.lvd142m"
DEFAULT_MEAN = [0.485, 0.456, 0.406]
DEFAULT_STD = [0.229, 0.224, 0.225]


def torchvision_factory(architecture: str, pretrained: bool = False):
    factories = {
        "resnet18": (tv.resnet18, tv.ResNet18_Weights.IMAGENET1K_V1),
        "resnet50": (tv.resnet50, tv.ResNet50_Weights.IMAGENET1K_V2),
        "convnext_tiny": (tv.convnext_tiny, tv.ConvNeXt_Tiny_Weights.IMAGENET1K_V1),
        "swin_tiny": (tv.swin_t, tv.Swin_T_Weights.IMAGENET1K_V1),
        "wide_resnet50_2": (tv.wide_resnet50_2, tv.Wide_ResNet50_2_Weights.IMAGENET1K_V2),
    }
    if architecture not in factories:
        raise ValueError(f"Unsupported architecture: {architecture}")
    builder, weights = factories[architecture]
    return builder(weights=weights if pretrained else None), str(weights)


def _dino(pretrained: bool):
    try:
        import timm
    except ImportError as exc:
        raise RuntimeError("DINOv2 requires timm. Install requirements.txt, or explicitly disable dinov2_small") from exc
    # Keep native positional embedding shape (518 / 14); interpolate dynamically
    # for other configured multiples of 14. No Torch Hub code execution.
    model = timm.create_model(DINO_NAME, pretrained=pretrained, num_classes=0, dynamic_img_size=True)
    return model


def download_weights(cfg: dict) -> None:
    """Explicit network operation: public weights download only; no dataset access."""
    cache = Path(cfg["paths"]["pretrained_dir"])
    cache.mkdir(parents=True, exist_ok=True)
    architectures = {s["architecture"] for s in cfg["models"].values() if s.get("enabled", True)}
    if cfg["anomaly"]["enabled"]:
        architectures.add(cfg["anomaly"]["backbone"])
    for architecture in sorted(architectures):
        path = cache / f"{architecture}.pt"
        if path.exists():
            LOG.info("Weights already cached: %s", path)
            continue
        LOG.info("Downloading public pretrained weights: %s", architecture)
        if architecture == "dinov2_small":
            model = _dino(pretrained=True)
            source = "timm/" + DINO_NAME
            mean = list(model.pretrained_cfg.get("mean", DEFAULT_MEAN))
            std = list(model.pretrained_cfg.get("std", DEFAULT_STD))
        else:
            model, source = torchvision_factory(architecture, pretrained=True)
            mean, std = DEFAULT_MEAN, DEFAULT_STD
        torch_save(path, {"architecture": architecture, "state_dict": model.cpu().state_dict(),
                          "source": source, "mean": mean, "std": std})
        write_json(path.with_suffix(".json"), {"architecture": architecture, "source": source, "sha256": file_sha256(path),
                                              "mean": mean, "std": std})
        del model
    LOG.info("Weights cached. Training/inference do not download or upload images")


class BinaryClassifier(nn.Module):
    def __init__(self, spec: dict):
        super().__init__()
        self.spec = dict(spec)
        self.architecture = spec["architecture"]
        if self.architecture == "dinov2_small":
            self.backbone = _dino(pretrained=False)
            # Retain CLS + mean/max patch evidence instead of relying only on CLS.
            self.feature_dim = int(self.backbone.num_features) * 3
        else:
            self.backbone, _ = torchvision_factory(self.architecture, pretrained=False)
            if self.architecture.startswith("resnet"):
                self.feature_dim = self.backbone.fc.in_features
                self.backbone.fc = nn.Identity()
            elif self.architecture == "convnext_tiny":
                self.feature_dim = self.backbone.classifier[-1].in_features
                self.backbone.classifier[-1] = nn.Identity()
            elif self.architecture == "swin_tiny":
                self.feature_dim = self.backbone.head.in_features
                self.backbone.head = nn.Identity()
            else:
                raise ValueError("Use a supported classifier architecture")
        self.head = nn.Linear(self.feature_dim, 1)

    def features(self, x: torch.Tensor) -> torch.Tensor:
        if self.architecture == "dinov2_small":
            tokens = self.backbone.forward_features(x)
            if not isinstance(tokens, torch.Tensor) or tokens.ndim != 3:
                raise RuntimeError("Unexpected timm DINOv2 forward_features result; check the pinned timm version")
            prefix = int(getattr(self.backbone, "num_prefix_tokens", 1))
            patches = tokens[:, prefix:]
            return torch.cat((tokens[:, 0], patches.mean(1), patches.amax(1)), dim=1)
        return self.backbone(x)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.head(self.features(x)).squeeze(-1)

    def set_training_stage(self, epoch: int, head_epochs: int) -> None:
        self.train()
        strategy = self.spec.get("strategy", "finetune")
        if strategy not in {"frozen", "partial", "finetune"}:
            raise ValueError("strategy must be frozen / partial / finetune")
        for p in self.backbone.parameters():
            p.requires_grad_(False)
        self.backbone.eval()
        if strategy != "frozen" and epoch >= head_epochs:
            if strategy == "partial":
                if self.architecture != "dinov2_small":
                    raise ValueError("partial strategy is implemented for DINOv2 only")
                number = int(self.spec.get("unfreeze_last_blocks", 2))
                if not 1 <= number <= len(self.backbone.blocks):
                    raise ValueError("Invalid unfreeze_last_blocks")
                for block in self.backbone.blocks[-number:]:
                    block.train()
                    for p in block.parameters():
                        p.requires_grad_(True)
                for p in self.backbone.norm.parameters():
                    p.requires_grad_(True)
            else:
                self.backbone.train()
                for p in self.backbone.parameters():
                    p.requires_grad_(True)
        # Stable pretrained BatchNorm statistics with small inspection batches.
        for module in self.backbone.modules():
            if isinstance(module, nn.modules.batchnorm._BatchNorm):
                module.eval()
        self.head.train()
        for p in self.head.parameters():
            p.requires_grad_(True)


def initialize_classifier(spec: dict, cfg: dict) -> tuple[BinaryClassifier, dict]:
    model = BinaryClassifier(spec)
    path = Path(cfg["paths"]["pretrained_dir"]) / f"{spec['architecture']}.pt"
    if not path.exists():
        if not cfg["training"].get("allow_random_initialization", False):
            raise FileNotFoundError(f"Missing pretrained weights {path}. Run download-weights explicitly, or copy its weights/ folder from an approved connected machine")
        LOG.warning("RANDOM INITIALIZATION: software testing only. Not a pretrained inspection model")
        return model, {"source": "RANDOM_TEST_ONLY", "sha256": "", "mean": DEFAULT_MEAN, "std": DEFAULT_STD}
    payload = torch_load(path)
    if payload.get("architecture") != spec["architecture"]:
        raise ValueError(f"Wrong pretrained architecture in {path}")
    state = dict(payload["state_dict"])
    arch = spec["architecture"]
    if arch.startswith("resnet"):
        ignored = [k for k in state if k.startswith("fc.")]
    elif arch == "convnext_tiny":
        ignored = [k for k in state if k.startswith("classifier.2.")]
    elif arch == "swin_tiny":
        ignored = [k for k in state if k.startswith("head.")]
    else:
        ignored = []
    for key in ignored:
        state.pop(key)
    model.backbone.load_state_dict(state, strict=True)
    return model, {"source": payload["source"], "sha256": file_sha256(path),
                   "mean": payload.get("mean", DEFAULT_MEAN), "std": payload.get("std", DEFAULT_STD)}


def load_classifier(path: Path, device="cpu") -> tuple[BinaryClassifier, dict]:
    payload = torch_load(path)
    if payload.get("class_map") != {"good": 0, "bad": 1}:
        raise ValueError("Checkpoint class mapping mismatch. BAD must be 1")
    model = BinaryClassifier(payload["spec"])
    model.load_state_dict(payload["state_dict"], strict=True)
    return model.to(device).eval(), payload
