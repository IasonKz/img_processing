# Start here

## 1. Extract the project

Extract the complete archive to a short local path, for example `C:\Users\YOUR_NAME\InspectionStudio`. The folder must contain `Setup.cmd`, `Start.cmd`, `inspection.py`, and `project.yaml`.

Keep your previous project and virtual environment. This version uses a separate environment outside the project tree to avoid long Windows package paths.

## 2. Install once on this computer

If the previous `vip3` environment already works on this computer, use the short [reuse existing environment](docs/INSTALLATION.md#reuse-a-working-v3-environment) route instead. Reinstalling packages is not required merely because the project folder changed.

Install **Python 3.12, 64-bit** if it is not present. Detailed commands are in [INSTALLATION.md](docs/INSTALLATION.md).

Double-click **Setup.cmd** and choose:

- **1:** laptop / CPU.
- **2:** workstation with an NVIDIA GPU / CUDA.

Wait for **Setup complete**. An error keeps the console visible. Setup downloads public software packages, checks their dependencies, and runs an actual model forward/backward device check. It does not train on your images.

If company policy prevents script execution, use the manual installation commands in the installation guide or request the approved Python/package setup from IT. No global execution-policy change is needed.

## 3. Set the data path

In `project.yaml`, edit the existing `tasks.vig.dataset_root` value:

```yaml
dataset_root: 'D:/InspectionData/vig'
```

This is one field, not a replacement for the whole configuration. The folder contains the original `good` and `bad` folders. Keep results, classified copies, and generated files outside the source dataset.

## 4. Open the workspace

Double-click **Start.cmd**. The browser opens the local workspace. Leave its console open.

1. In **Train & search**, select the correct profile and model list.
2. In **Dataset & setup**, use **Download pretrained weights** once while online, then **Check installation**.
3. Use **Audit dataset** and inspect group counts and any reported issues.
4. In **Train & search**, start the Optuna search once.
5. After candidates complete, open **Compare models** and **Decision explorer**.
6. Save a decision, classify a local folder, and inspect its copies in **Image review**.

The default profiles are laptop: **2 hours**, workstation: **6 hours**, and workstation_large: **12 hours**. These are maximum total search allowances, not promises of completed trials or model quality.

## 5. Open it again later

Double-click **Start.cmd**. Packages and weights do not need to be installed again. Select an existing experiment to inspect its results. Resume a paused search to use its remaining budget, or start a new search for a new model selection or budget.

Before ending training, use **Pause active search** and wait for the operation to stop. Closing the browser does not stop the worker. Closing the dashboard console may also leave a previously started worker running independently.

For ordered model filtering, see [WORKFLOWS.md](docs/WORKFLOWS.md). For failure messages, see [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md).
