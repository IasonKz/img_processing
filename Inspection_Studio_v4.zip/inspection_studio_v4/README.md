# Inspection Studio 4

Local visual inspection software for training, comparing, and reviewing image classifiers. The browser workspace manages dataset audits, budgeted Optuna searches, saved decisions, image classification, and ordered inspection workflows.

**Start on Windows:** read [START_HERE.md](START_HERE.md), run `Setup.cmd` once, then open `Start.cmd`. The interface, source documentation, and operator messages are in English.

## Operating workspace

| View | Purpose |
| --- | --- |
| Dataset & setup | Configure folders, check dependencies and weights, audit source data |
| Train & search | Choose models and a resource profile; monitor trials, learning curves, memory, timing, and failures |
| Compare models | Compare completed candidates on the recorded selection split |
| Decision explorer | Inspect calibration trade-offs; save policy, manual, argmax, or scores-only decisions |
| Classify images | Load a saved decision and classify a local image folder |
| Inspection workflow | Order saved decisions and choose the final acceptance rule |
| Image review | Inspect copied images, predictions, original tags, disagreements, and operator review tags |
| Models & reports | Load experiments and assets; inspect reports and manage portable packages |

## Resource profiles

| Profile | Device | Total search allowance | Default model families |
| --- | --- | ---: | --- |
| `laptop` | CPU | 2 hours | ResNet18, EfficientNet-B0 |
| `workstation` | NVIDIA CUDA GPU | 6 hours | ResNet18/50, EfficientNet-B0, ConvNeXt-Tiny, Swin-T, PatchCore |
| `workstation_large` | NVIDIA CUDA GPU | 12 hours | Same families, larger search and confirmation allowance |

The allowance is shared across models. More architectures leave less time per architecture. Resume uses the remaining original allowance. Hardware, native image dimensions, and candidate complexity determine how many trials can complete.

## Data and decision controls

- The VIG task is enabled initially; top and bottom are configured separately.
- Native source pixels are preserved with padding. There is no silent crop or downsampling fallback.
- VIG training augmentation uses only exact quarter-turn rotations; image labels are unchanged.
- Captures of the same tray/row/column unit stay together in the split.
- Training, validation, calibration, selection, and final test have separate roles.
- Saved decisions and workflow recipes are separate from trained checkpoints.
- Classification copies and review tags never overwrite the original dataset.
- Failed trials are reported with their errors. Pruned trials and timeouts have distinct states.
- Windows file publishing uses unique temporary files and bounded retries for transient access/sharing failures.

Training and inference run locally after public packages and model weights have been provisioned. The dashboard binds to loopback and has no external CDN requirement.

## Guides

- [Windows installation and repair](docs/INSTALLATION.md)
- [Daily operator workflow](docs/OPERATOR_GUIDE.md)
- [Model training and evaluation](docs/EXPERIMENT_GUIDE.md)
- [Ordered inspection workflows](docs/WORKFLOWS.md)
- [Image review and operator tags](docs/IMAGE_REVIEW.md)
- [Command reference](docs/CLI_REFERENCE.md)
- [Troubleshooting](docs/TROUBLESHOOTING.md)
- [Portable deployment](docs/DEPLOYMENT.md)
- [Validation scope](docs/VALIDATION_REPORT.md)
- [Release verification record](docs/RELEASE_VERIFICATION.md)

## Release boundary

This application provides inspection development and local batch operation. It is not a certified production-line controller. Release suitability requires independent representative data, agreed error limits, destination-machine verification, and an operational response for invalid images and equipment failures. A selected model, a saved workflow, or an exported package does not itself establish production qualification.

Use a new project folder for this version. Existing v3 experiments can be loaded when their source artifacts are intact. Do not overlay old patch files onto this release.
