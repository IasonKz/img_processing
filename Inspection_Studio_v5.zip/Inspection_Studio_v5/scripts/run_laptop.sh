#!/usr/bin/env bash
set -euo pipefail
inspection_project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd -- "$inspection_project_dir"
inspection_python="${STUDIO_PYTHON:-$inspection_project_dir/.venv-studio5/bin/python}"
if [[ ! -x "$inspection_python" ]]; then
    printf '%s\n' 'Python environment not found. See docs/INSTALLATION_LINUX.md.' >&2
    exit 1
fi
exec "$inspection_python" inspection.py run --config project.yaml --profile laptop "$@"
