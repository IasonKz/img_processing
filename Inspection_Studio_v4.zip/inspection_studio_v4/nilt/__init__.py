"""Local, defect-oriented image classification. Fixed labels: bad=0, good=1."""
__version__ = "4.0.0"
