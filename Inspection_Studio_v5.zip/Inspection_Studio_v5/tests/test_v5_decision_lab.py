"""Decision development uses synthetic caches; neural inference is mocked."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
from PIL import Image

from nilt.common import read_json, sha_file, write_csv, write_json
from nilt.decision_lab import (apply_system, create_system, evaluate_system, fit_logistic, load_system,
    logistic_scores, normalize_definition, partition_development, preview_system,
    run_system, sweep_thresholds, triage, triage_metrics)
from test_integration_v2 import fixture_run


class DecisionMathTests(unittest.TestCase):
    def test_tuning_budget_and_trials_have_no_profile_ceiling(self):
        actual = normalize_definition({"kind": "triage", "sources": [{"run": "."}],
            "tuning": {"method": "optuna", "n_trials": 50000, "timeout_seconds": 48 * 3600}})
        self.assertEqual(actual["tuning"]["n_trials"], 50000)
        self.assertEqual(actual["tuning"]["timeout_seconds"], 48 * 3600)
        for field, value in (("n_trials", 0), ("n_trials", 1.5), ("timeout_seconds", 0),
                             ("timeout_seconds", float("inf")), ("timeout_seconds", float("nan"))):
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                normalize_definition({"kind": "triage", "sources": [{"run": "."}],
                    "tuning": {field: value}})

    def test_triage_boundaries_and_binary_tie(self):
        self.assertEqual(triage([.1, .2, .79, .8], .2, .8).tolist(), ["good", "review", "review", "bad"])
        self.assertEqual(triage([.49, .5], .5, .5).tolist(), ["good", "bad"])
        for low, high in ((.8, .2), (float("nan"), .2)):
            with self.assertRaises(ValueError):
                triage([.5], low, high)

    def test_review_is_not_correct_or_rejected_and_rates_use_all_class_images(self):
        m = triage_metrics([0, 0, 0, 1, 1, 1], ["good", "review", "bad", "good", "review", "bad"])
        self.assertAlmostEqual(m["bad_escape_rate"], 1/3)
        self.assertAlmostEqual(m["good_reject_rate"], 1/3)
        self.assertAlmostEqual(m["review_rate"], 1/3)
        self.assertEqual(m["automatic_accuracy"], .5)
        self.assertIsNone(triage_metrics([0, 1], ["review", "review"])["automatic_accuracy"])

    def test_coefficients_roundtrip_json_and_score_direction(self):
        X = np.array([[.1, 1], [.2, 2], [.8, 8], [.9, 9]])
        fit = fit_logistic(X, [1, 1, 0, 0])
        fit = json.loads(json.dumps(fit, allow_nan=False))
        scores = logistic_scores(X, fit)
        self.assertTrue(np.all(np.diff(scores) > 0))
        self.assertLess(scores[0], .5)
        self.assertGreater(scores[-1], .5)

    def test_connected_group_aliases_are_never_split(self):
        rows = [{"label": i % 2, "group": str(i), "pixel_hash": str(i)} for i in range(12)]
        rows[0]["group_aliases"] = json.dumps(["shared"])
        rows[1]["group_aliases"] = json.dumps(["shared"])
        fit, tune, groups = partition_development(rows)
        self.assertFalse(set(groups[fit]) & set(groups[tune]))
        self.assertEqual(groups[0], groups[1])
        self.assertEqual(set(fit) | set(tune), set(range(12)))

    def test_sweep_matches_exhaustive_and_has_endpoints(self):
        definition = normalize_definition({"kind": "triage", "sources": [{"run": "."}],
                                         "tuning": {"method": "sweep", "max_bad_escape_rate": 0,
                                                    "max_good_reject_rate": 0, "max_review_rate": 1}})
        choice, detail = sweep_thresholds([0, 0, 1, 1], [.3, .9, .1, .7], definition["tuning"])
        m = triage_metrics([0, 0, 1, 1], triage([.3, .9, .1, .7], **choice))
        self.assertEqual(m["bad_escape_rate"], 0)
        self.assertEqual(m["good_reject_rate"], 0)
        self.assertEqual(m["review_rate"], .5)
        self.assertTrue(detail["complete"])

    def test_cascade_accept_reject_disable_and_residual_review(self):
        d = normalize_definition({"kind": "cascade", "sources": [{"run": "."}, {"run": ".."}],
            "stages": [{"source": 0, "good": .2, "bad": .8, "accept": False},
                       {"source": 1, "good": .2, "bad": .8, "reject": False}]})
        prediction, score, stages = apply_system(np.array([[.1,.1],[.9,.1],[.5,.9]]), d, {})
        self.assertEqual(prediction.tolist(), ["good", "bad", "review"])
        self.assertIsNone(score)
        self.assertEqual(stages[1]["evaluated"], 2)

    def test_sweep_user_bounds_between_scores_are_feasible(self):
        d = normalize_definition({"kind": "triage", "sources": [{"run": "."}],
                                  "tuning": {"method": "sweep", "good_range": [.3, .4], "bad_range": [.3, .4]}})
        pair, _ = sweep_thresholds([1, 0], [.1, .9], d["tuning"])
        self.assertTrue(.3 <= pair["good"] <= pair["bad"] <= .4)

    def test_impossible_threshold_ranges_rejected_before_search(self):
        for method in ("sweep", "optuna"):
            with self.assertRaisesRegex(ValueError, "cannot satisfy"):
                normalize_definition({"kind": "triage", "sources": [{"run": "."}],
                    "tuning": {"method": method, "good_range": [.8, .9], "bad_range": [.1, .7]}})

    def test_sweep_bounds_match_brute_force_attainable_decisions(self):
        from nilt.decision_lab import _quality
        scores = np.array([.1, .3, .3, .6, .7, .9])
        labels = np.array([1, 0, 1, 1, 0, 0])
        d = normalize_definition({"kind": "triage", "sources": [{"run": "."}],
            "tuning": {"method": "sweep", "good_range": [.2, .65], "bad_range": [.45, .8],
                       "max_bad_escape_rate": 0, "max_good_reject_rate": .1, "max_review_rate": .5}})
        tuning = d["tuning"]
        pair, _ = sweep_thresholds(labels, scores, tuning)
        candidates = sorted(set(scores.tolist() + [.2, .65, .45, .8]))
        brute = min(_quality(triage_metrics(labels, triage(scores, low, high)), tuning)
                    for low in candidates for high in candidates
                    if .2 <= low <= .65 and .45 <= high <= .8 and low <= high)
        self.assertEqual(_quality(triage_metrics(labels, triage(scores, **pair)), tuning), brute)


class DecisionSystemTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.run, self.data, self.rows = fixture_run(self.root)
        self.candidates = []
        for i, kind in enumerate(("supervised", "supervised", "patchcore")):
            checkpoint = self.run / f"model{i}.pt"
            checkpoint.write_bytes(f"Opaque fake checkpoint {i}".encode())
            candidate = {"name": f"candidate{i}", "members": [{"checkpoint": checkpoint.name,
                           "sha256": sha_file(checkpoint), "kind": kind,
                           "architecture": "patchcore" if kind == "patchcore" else "resnet18"}]}
            self.candidates.append(candidate)
            folder = self.run / "scores" / candidate["name"]
            folder.mkdir(parents=True)
            values = [.8, .9, .1, .2] if kind == "supervised" else [8., 9., 1., 2.]
            for split in ("threshold", "selection"):
                np.save(folder / (split + ".npy"), values)
            write_json(folder / "provenance.json", {"candidate": candidate["name"],
                       "manifest_sha256": sha_file(self.run / "manifest.csv"),
                       "files": {name + ".npy": sha_file(folder / (name + ".npy")) for name in ("threshold", "selection")}})
        write_json(self.run / "candidates.json", self.candidates)
        self.definition = {"kind": "triage", "sources": [{"run": str(self.run), "candidate": "candidate0"}],
                           "thresholds": {"good": .3, "bad": .7}}

    def definition_for(self, kind):
        d = deepcopy(self.definition)
        d["kind"] = kind
        if kind != "triage":
            d["sources"].append({"run": str(self.run), "candidate": "candidate1"})
        if kind == "cascade":
            d["stages"] = [{"source": 0, "good": .2, "bad": .8}, {"source": 1, "good": .3, "bad": .7}]
        return d

    def test_preview_never_reads_selection_or_final_test(self):
        real = np.load
        opened = []
        def read(path, **kwargs):
            opened.append(Path(path).name)
            return real(path, **kwargs)
        for kind in ("triage", "weighted", "stacking", "cascade"):
            with patch("nilt.decision_lab.np.load", side_effect=read):
                result = preview_system(self.definition_for(kind))
            self.assertEqual(result["tune_metrics"]["bad_escape_rate"], 0)
        self.assertEqual(set(opened), {"threshold.npy"})

    def test_fit_and_tune_are_disjoint_and_learned_model_uses_only_fit(self):
        real = fit_logistic
        calls = []
        def fit(X, labels, c):
            calls.append((X.copy(), labels.copy()))
            return real(X, labels, c)
        with patch("nilt.decision_lab.fit_logistic", side_effect=fit):
            result = preview_system(self.definition_for("stacking"))
        partition = result["partition"]
        self.assertFalse(set(partition["fit_groups"]) & set(partition["tune_groups"]))
        self.assertFalse(set(partition["fit_pixel_hashes"]) & set(partition["tune_pixel_hashes"]))
        self.assertEqual(len(calls[0][0]), partition["fit_images"])
        self.assertEqual(partition["fit_images"] + partition["tune_images"], 4)

    def test_score_calibrators_fit_only_fit_rows(self):
        d = self.definition_for("weighted")
        d["calibrate_scores"] = True
        real = fit_logistic
        observed = []
        def fit(X, labels, c):
            observed.append((X.copy(), labels.copy()))
            return real(X, labels, c)
        with patch("nilt.decision_lab.fit_logistic", side_effect=fit):
            result = preview_system(d)
        self.assertEqual(len(observed), 2)
        fit_indices = result["partition"]["fit_indices"]
        original = np.array([.8, .9, .1, .2])
        for values, labels in observed:
            np.testing.assert_array_equal(values[:, 0], original[fit_indices])
            self.assertEqual(len(labels), len(fit_indices))

    def test_mixed_scores_require_calibration_or_stacking(self):
        d = self.definition_for("weighted")
        d["sources"][1]["candidate"] = "candidate2"
        with self.assertRaisesRegex(ValueError, "calibration"):
            preview_system(d)
        d["calibrate_scores"] = True
        self.assertEqual(len(preview_system(d)["model"]["calibrators"]), 2)
        d["kind"] = "stacking"
        d["calibrate_scores"] = False
        self.assertIn("stacker", preview_system(d)["model"])

    def test_recipe_integrity_selection_after_freeze_and_no_final_test(self):
        original = {p: sha_file(p) for p in self.run.rglob("*") if p.is_file()}
        real = np.load
        opened = []
        def read(path, **kwargs):
            opened.append(Path(path).name)
            if Path(path).name == "selection.npy":
                self.assertTrue(list((self.root / "systems").rglob("decision_system_integrity.json")))
            return real(path, **kwargs)
        with patch("nilt.decision_lab.np.load", side_effect=read):
            path = create_system(self.definition_for("stacking"), self.root / "systems")
        record, sources = load_system(path)
        self.assertEqual(record["format"], "decision_system_v5")
        self.assertEqual(set(opened), {"threshold.npy", "selection.npy"})
        self.assertEqual(original, {p: sha_file(p) for p in self.run.rglob("*") if p.is_file()})
        report = read_json(path.parent / "selection_report.json")
        self.assertEqual(report["status"], "evaluated")
        record["definition"]["thresholds"]["bad"] = .9
        write_json(path, record)
        with self.assertRaisesRegex(ValueError, "checksum"):
            load_system(path)

    def test_changed_scores_and_models_rejected(self):
        path = create_system(self.definition, self.root / "systems")
        folder = self.run / "scores" / "candidate0"
        np.save(folder / "threshold.npy", [.1, .2, .3, .4])
        with self.assertRaisesRegex(ValueError, "scores changed"):
            load_system(path)
        with self.assertRaisesRegex(ValueError, "provenance"):
            preview_system(self.definition)

    def test_manifest_group_leakage_rejected_before_learning(self):
        self.rows[2]["group"] = self.rows[4]["group"]  # val/threshold collision
        write_csv(self.run / "manifest.csv", self.rows)
        write_json(self.run / "integrity.json", {"config_sha256": sha_file(self.run / "config.json"),
                   "manifest_sha256": sha_file(self.run / "manifest.csv")})
        with self.assertRaisesRegex(ValueError, "Group leakage"):
            preview_system(self.definition)

    def test_optuna_trials_use_tune_and_honor_basic_controls(self):
        d = self.definition_for("weighted")
        d["tuning"] = {"method": "optuna", "n_trials": 4, "timeout_seconds": 5,
                       "sampler": "random", "search_weights": True}
        result = preview_system(d)
        self.assertEqual(result["tuning"]["evaluations"], 5)
        self.assertAlmostEqual(sum(result["definition"]["weights"]), 1)
        self.assertTrue(result["tuning"]["targets_feasible"])

    def test_optuna_baseline_cannot_escape_custom_bounds(self):
        d = deepcopy(self.definition)
        d["tuning"] = {"method": "optuna", "n_trials": 4, "sampler": "random",
                       "good_range": [.8, .8], "bad_range": [.9, .9]}
        result = preview_system(d)
        self.assertFalse(result["tuning"]["baseline_evaluated"])
        self.assertEqual(result["definition"]["thresholds"], {"good": .8, "bad": .9})

    def test_final_test_requires_acknowledgement_and_is_idempotent(self):
        path = create_system(self.definition, self.root / "systems")
        with self.assertRaisesRegex(ValueError, "confirmation"):
            evaluate_system(path)
        with patch("nilt.workflow.predict_members", return_value=(np.array([.8, .9, .1, .2]), .01)) as predict:
            report = evaluate_system(path, confirm_final_test=True)
            again = evaluate_system(path, confirm_final_test=True)
        self.assertEqual(predict.call_count, 1)
        self.assertEqual(report, again)
        self.assertEqual(read_json(report)["metrics"]["bad_escape_rate"], 0)
        self.assertFalse(read_json(report)["prior_test_exposure"])
        self.assertEqual(len(read_json(self.run / "decision_lab_test_ledger.json")), 1)

    def test_failed_final_test_is_still_exposure_and_cannot_restart(self):
        path = create_system(self.definition, self.root / "systems")
        with patch("nilt.workflow.predict_members", side_effect=RuntimeError("mock failure")):
            with self.assertRaisesRegex(RuntimeError, "mock failure"):
                evaluate_system(path, confirm_final_test=True)
        with self.assertRaisesRegex(ValueError, "already began"):
            evaluate_system(path, confirm_final_test=True)

    def test_previous_recipe_test_is_disclosed(self):
        first = create_system(self.definition, self.root / "systems")
        second = create_system(self.definition, self.root / "systems")
        with patch("nilt.workflow.predict_members", return_value=(np.array([.8, .9, .1, .2]), .01)):
            evaluate_system(first, confirm_final_test=True)
            report = evaluate_system(second, confirm_final_test=True)
        self.assertTrue(read_json(report)["prior_test_exposure"])

    def images(self):
        source = self.root / "incoming"
        for label, color in (("good", "white"), ("bad", "black")):
            (source / label).mkdir(parents=True)
            Image.new("RGB", (32, 32), color).save(source / label / "image.png")
        return source

    def test_inference_copies_review_and_preserves_originals(self):
        path = create_system(self.definition, self.root / "systems")
        source = self.images()
        before = {p: sha_file(p) for p in source.rglob("*.png")}
        with patch("nilt.workflow.predict_members", return_value=(np.array([.5, .9]), .01)):
            out = run_system(path, source, self.root / "outputs", labeled=True)
        entries = [json.loads(line) for line in (out / "predictions.jsonl").read_text().splitlines()]
        self.assertEqual({e["prediction"] for e in entries}, {"review", "bad"})
        self.assertEqual(before, {p: sha_file(p) for p in source.rglob("*.png")})
        self.assertEqual(read_json(out / "summary.json")["counts"]["review"], 1)
        self.assertTrue(all((out / e["copied_path"]).is_file() for e in entries))

    def test_weighted_review_retains_thresholds_and_source_disagreement(self):
        from nilt.review import session_detail
        path = create_system(self.definition_for("weighted"), self.root / "systems")
        with patch("nilt.workflow.predict_members", side_effect=[
                (np.array([.1, .8]), .01), (np.array([.9, .9]), .01)]):
            out = run_system(path, self.images(), self.root / "outputs", labeled=True)
        entries = [json.loads(line) for line in (out / "predictions.jsonl").read_text().splitlines()]
        deferred = next(e for e in entries if e["prediction"] == "review")
        self.assertEqual((deferred["good_threshold"], deferred["bad_threshold"]), (.3, .7))
        self.assertEqual({s["predicted_class"] for s in deferred["stage_results"]}, {"good", "bad"})
        detail = session_detail(out, sort="priority")
        row = next(row for row in detail["items"] if row["prediction"] == "review")
        self.assertTrue(row["model_disagreement"])
        self.assertAlmostEqual(row["threshold_distance"], .2)

    def test_cascade_runtime_skips_resolved_and_retains_trace(self):
        path = create_system(self.definition_for("cascade"), self.root / "systems")
        with patch("nilt.workflow.predict_members", side_effect=[(np.array([.1, .5]), .01), (np.array([.5]), .01)]) as predict:
            out = run_system(path, self.images(), self.root / "outputs", labeled=True)
        self.assertEqual(len(predict.call_args_list[1].args[2]), 1)
        entries = [json.loads(line) for line in (out / "predictions.jsonl").read_text().splitlines()]
        accepted = next(e for e in entries if e["prediction"] == "good")
        self.assertEqual(accepted["stage_results"][1]["status"], "skipped")
        self.assertEqual(read_json(out / "summary.json")["counts"], {"good": 1, "bad": 0, "review": 1})

    def test_final_source_streams_before_inference_finishes(self):
        path = create_system(self.definition_for("weighted"), self.root / "systems")
        def predict(run, members, rows, cfg, on_scores=None):
            scores = np.array([.5, .9])
            if on_scores:
                on_scores(0, scores[:1])
                folder = next((self.root / "outputs").iterdir())
                self.assertEqual(len((folder / "predictions.jsonl").read_text().splitlines()), 1)
                on_scores(1, scores[1:])
            return scores, .01
        with patch("nilt.workflow.predict_members", side_effect=predict):
            out = run_system(path, self.images(), self.root / "outputs", labeled=True)
        self.assertEqual(len((out / "predictions.jsonl").read_text().splitlines()), 2)

    def test_inference_failure_never_becomes_good(self):
        path = create_system(self.definition, self.root / "systems")
        with patch("nilt.workflow.predict_members", return_value=(np.array([np.nan, .5]), .01)):
            with self.assertRaisesRegex(ValueError, "Invalid inference"):
                run_system(path, self.images(), self.root / "outputs", labeled=True)
        folder = next((self.root / "outputs").iterdir())
        self.assertEqual(read_json(folder / "summary.json")["status"], "failed")
        self.assertEqual((folder / "predictions.jsonl").read_text(), "")


if __name__ == "__main__":
    unittest.main()
