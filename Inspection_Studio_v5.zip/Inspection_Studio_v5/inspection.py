"""Visual Inspection command-line application."""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import sys
import traceback


def build_parser():
    parser = argparse.ArgumentParser(prog="inspection", description="Local visual inspection: training, version management and portable inference.")
    parser.add_argument("--version", action="version", version="Inspection Studio 5.0.0")
    sub = parser.add_subparsers(dest="command", required=True)
    def project_args(p, required=True):
        p.add_argument("--config", required=required)
        p.add_argument("--profile", choices=["laptop", "workstation", "workstation_large"], default="laptop")
        p.add_argument("--task", choices=["top", "bottom", "vig"])
    for command, description in (("audit", "Audit data and prepare immutable grouped splits."),
                                 ("run", "Train, tune, compare and select candidates."),
                                 ("download-weights", "Provision public pretrained weights; explicitly online.")):
        p = sub.add_parser(command, help=description)
        project_args(p)
        if command == "download-weights":
            p.add_argument("--models", nargs="+", help="Override profile models for weight provisioning.")
    p = sub.add_parser("doctor", help="Check local installation, configuration and resources.")
    project_args(p, required=False)
    p.add_argument("--deployment", action="store_true", help="Also require ONNX export dependencies.")
    p = sub.add_parser("resume", help="Continue a prepared/interrupted run at a saved epoch boundary.")
    p.add_argument("--run", required=True)
    p.add_argument("--device", choices=["cpu", "cuda", "auto"])
    p.add_argument("--recover-lock", action="store_true", help="Remove an abandoned lock after verifying no operation is running.")
    p = sub.add_parser("update", help="Create a new generation with old and new labeled data.")
    project_args(p)
    p.add_argument("--from-run", required=True)
    p = sub.add_parser("status", help="Read state and regenerate human-readable model reports.")
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--run")
    src.add_argument("--config")
    p.add_argument("--task", choices=["top", "bottom", "vig"])
    p = sub.add_parser("compare", help="Compare fixed versions on common selection records.")
    p.add_argument("--old-run", required=True)
    p.add_argument("--new-run", required=True)
    p.add_argument("--output")
    p = sub.add_parser("evaluate", help="Evaluate the frozen selected system on a final or fresh external holdout.")
    p.add_argument("--run", required=True)
    p.add_argument("--split", choices=["final-test", "external"], default="final-test")
    p.add_argument("--input")
    p.add_argument("--groups-csv")
    p = sub.add_parser("activate", help="Set current release after configured qualification checks.")
    p.add_argument("--run", required=True)
    p.add_argument("--config")
    p = sub.add_parser("predict", help="Classify folders with a model package, source run or active release.")
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--model", help="Portable inference package directory.")
    src.add_argument("--run", help="Source training run (requires PyTorch).")
    src.add_argument("--config", help="Project with activated per-task releases.")
    p.add_argument("--input")
    p.add_argument("--output")
    p.add_argument("--device", choices=["cpu", "cuda", "auto"], default="cpu")
    p.add_argument("--profile", choices=["laptop", "workstation", "workstation_large"], default="laptop")
    p.add_argument("--task", choices=["top", "bottom", "vig"])
    p.add_argument("--labeled", action="store_true")
    p = sub.add_parser("export", help="Create image comparison folders from saved selection scores.")
    p.add_argument("--run", required=True)
    p.add_argument("--candidate", default="selected")
    p.add_argument("--output", required=True)
    p = sub.add_parser("package", help="Build an ONNX inference or training continuation package.")
    p.add_argument("--run", required=True)
    p.add_argument("--kind", choices=["inference", "training"], default="inference")
    p.add_argument("--format", choices=["onnx"], default="onnx")
    p.add_argument("--output", required=True)
    p.add_argument("--decision", help="Frozen decision.json for ONNX inference export.")
    p = sub.add_parser("restore", help="Restore training state against matching relocated image data.")
    p.add_argument("--package", required=True)
    p.add_argument("--data-root", required=True)
    p.add_argument("--output", required=True)
    p = sub.add_parser("smoke", help="Run synthetic workflow checks without using inspection data.")
    p.add_argument("--output", required=True)
    p.add_argument("--with-models", action="store_true")
    p.add_argument("--with-onnx", action="store_true")
    p = sub.add_parser("search", help="Optuna search within the user-defined cumulative wall-clock budget.")
    source = p.add_mutually_exclusive_group(required=True)
    source.add_argument("--config")
    source.add_argument("--run", help="Resume the remaining budget of an existing search.")
    p.add_argument("--profile", choices=["laptop", "workstation", "workstation_large"], default="laptop")
    p.add_argument("--task", choices=["vig", "top", "bottom"], default="vig")
    p.add_argument("--models", nargs="+")
    p.add_argument("--hours", type=float, help="Total hours for a new search; any finite positive value. Resume retains the original cumulative budget.")
    p.add_argument("--device", choices=["cpu", "cuda", "auto"], help="Compute device override, independent of profile.")
    p.add_argument("--recover-lock", action="store_true")
    p.add_argument("--no-finalize", action="store_true")
    p = sub.add_parser("finalize-search", help="Explicitly compare saved finalists after a search; no new training.")
    p.add_argument("--run", required=True)
    p.add_argument("--hours", type=float, default=.5)
    p.add_argument("--device", choices=["cpu", "cuda", "auto"])
    p.add_argument("--recover-lock", action="store_true")
    p = sub.add_parser("_search-worker", help=argparse.SUPPRESS)
    p.add_argument("--session", required=True)
    p = sub.add_parser("dashboard", help="Open the local offline monitoring and control interface.")
    p.add_argument("--config", default="project.yaml")
    p.add_argument("--port", type=int, default=8765)
    p.add_argument("--no-browser", action="store_true")
    p = sub.add_parser("decision", help="Save a new immutable decision for any trained candidate.")
    p.add_argument("--run", required=True)
    p.add_argument("--mode", choices=["policy", "manual", "argmax", "scores_only"], default="policy")
    p.add_argument("--threshold", type=float)
    p.add_argument("--candidate", default="selected")
    p.add_argument("--output-root", default="decisions")
    p = sub.add_parser("classify", help="Predict new images with an explicit frozen decision.")
    p.add_argument("--decision", required=True)
    p.add_argument("--input", required=True)
    p.add_argument("--output-root", default="classified")
    p.add_argument("--labeled", action="store_true")
    p.add_argument("--copy-images", action="store_true")
    p.add_argument("--device", choices=["cpu", "cuda", "auto"], default="cpu")
    p.add_argument("--run", help="Verified relocated source run for an existing decision.")
    p = sub.add_parser("workflow-create", help="Save an immutable ordered workflow from frozen model decisions.")
    p.add_argument("--spec", required=True, help="JSON specification containing name, rule and ordered stages.")
    p.add_argument("--output-root", default="workflows")
    p = sub.add_parser("workflow-run", help="Inspect images with an ordered multi-model decision workflow.")
    p.add_argument("--workflow", required=True, help="Saved workflow.json path or its directory.")
    p.add_argument("--input", required=True)
    p.add_argument("--output-root", default="classified")
    p.add_argument("--labeled", action="store_true", help="Read reference labels from good/ and bad/ subfolders.")
    p.add_argument("--device", choices=["cpu", "cuda", "auto"], default="cpu")
    p.add_argument("--no-copy-images", action="store_true", help="Write results without copied images; visual review will have no previews.")
    p = sub.add_parser("threshold-review", help="Compare thresholds on saved calibration scores.")
    p.add_argument("--run", required=True)
    p.add_argument("--thresholds", type=float, nargs="+")
    p.add_argument("--candidate", default="selected")
    p.add_argument("--output-root", default="threshold_review")
    p = sub.add_parser("report", help="Generate the integrated standalone visual HTML report.")
    source = p.add_mutually_exclusive_group(required=True)
    source.add_argument("--run")
    source.add_argument("--config")
    p.add_argument("--task", choices=["vig", "top", "bottom"], default="vig")
    p = sub.add_parser("system-preview", help="Preview triage/ensemble/stacking/cascade on calibration data only.")
    p.add_argument("--spec", required=True)
    p = sub.add_parser("system-create", help="Freeze a decision system and report its separate selection performance.")
    p.add_argument("--spec", required=True)
    p.add_argument("--output-root", default="decision_systems")
    p = sub.add_parser("system-run", help="Classify copied images with a frozen v5 decision system.")
    p.add_argument("--system", required=True)
    p.add_argument("--input", required=True)
    p.add_argument("--output-root", default="classified")
    p.add_argument("--device", choices=["cpu", "cuda", "auto"], default="cpu")
    p.add_argument("--labeled", action="store_true")
    p.add_argument("--no-copy-images", action="store_true")
    p = sub.add_parser("system-evaluate", help="Explicitly evaluate a frozen v5 system on its locked final test.")
    p.add_argument("--system", required=True)
    p.add_argument("--device", choices=["cpu", "cuda", "auto"], default="cpu")
    p.add_argument("--confirm-final-test", action="store_true",
                   help="Acknowledge final-test exposure; do not use this result to tune the recipe.")
    p = sub.add_parser("review-export", help="Export operator-confirmed labels into a new dataset version.")
    p.add_argument("--sessions", nargs="+", required=True)
    p.add_argument("--output-root", default="review_datasets")
    p.add_argument("--source-run")
    p.add_argument("--no-replay", action="store_true")
    return parser


class Tee:
    def __init__(self, original, handle):
        self.original, self.handle = original, handle
    def write(self, value):
        self.original.write(value)
        self.handle.write(value)
    def flush(self):
        self.original.flush()
        self.handle.flush()


@contextmanager
def log_to(run):
    path = Path(run) / "operation.log"
    old_out, old_err = sys.stdout, sys.stderr
    with path.open("a", encoding="utf-8") as handle:
        sys.stdout, sys.stderr = Tee(old_out, handle), Tee(old_err, handle)
        try:
            yield
        except BaseException:
            traceback.print_exc(file=handle)
            raise
        finally:
            sys.stdout, sys.stderr = old_out, old_err


def doctor(config=None, profile="laptop", task=None, deployment=False):
    from nilt.common import load_project
    import importlib.metadata
    dependencies = {}
    for name, module in (("numpy", "numpy"), ("Pillow", "PIL"), ("PyYAML", "yaml"),
                         ("scikit-learn", "sklearn"), ("scipy", "scipy"), ("matplotlib", "matplotlib"),
                         ("torch", "torch"), ("torchvision", "torchvision"),
                         ("onnx", "onnx"), ("onnxruntime", "onnxruntime"),
                         ("optuna", "optuna"), ("psutil", "psutil")):
        dependencies[name] = importlib.metadata.version(name) if importlib.util.find_spec(module) else None
    report = {"python": sys.version.split()[0], "dependencies": dependencies, "tasks": []}
    ready = all(dependencies[x] for x in ("numpy", "Pillow", "PyYAML", "scikit-learn", "scipy", "matplotlib", "torch", "torchvision", "optuna", "psutil"))
    if dependencies["psutil"]:
        import psutil
        report["hardware"] = {"logical_cpus": psutil.cpu_count(), "ram_gib": round(psutil.virtual_memory().total / 2**30, 1)}
    if dependencies["torch"]:
        import torch
        report["cuda"] = [{"name": torch.cuda.get_device_name(i), "vram_gib": round(torch.cuda.get_device_properties(i).total_memory / 2**30, 1)} for i in range(torch.cuda.device_count())]
    if deployment:
        ready = ready and bool(dependencies["onnx"] and dependencies["onnxruntime"])
    configs = load_project(config, profile, task) if config else []
    for cfg in configs:
        item = {"task": cfg["task"], "data_root": cfg["data_root"],
                "dataset_exists": Path(cfg["data_root"]).is_dir(), "device": cfg["device"],
                "profile": profile, "image_size": cfg["image_size"], "models": cfg["models"]}
        try:
            from nilt.engine import check_weights, device_for
            check_weights(cfg)
            item["resolved_device"] = str(device_for(cfg))
            item["resources_ready"] = True
        except Exception as exc:
            item["resources_ready"] = False
            item["issue"] = str(exc)
        ready = ready and item["dataset_exists"] and item["resources_ready"]
        report["tasks"].append(item)
    report["ready"] = bool(ready)
    print(json.dumps(report, indent=2))
    return report


def smoke(output, with_models=False, with_onnx=False):
    from nilt.common import merge_dict, DEFAULTS, write_json
    from nilt.workflow import new_run, run_training, open_run, final_test, predict_folder, write_state
    from nilt.reporting import export_predictions
    import numpy as np
    from PIL import Image
    output = Path(output).resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError("Smoke output must be a new or empty directory.")
    if with_onnx and not with_models:
        raise ValueError("--with-onnx requires --with-models.")
    rng = np.random.default_rng(431)
    for label in ("good", "bad"):
        target = output / "data" / label
        target.mkdir(parents=True, exist_ok=True)
        for i in range(40):
            arr = rng.integers(30, 80, (64, 64, 3), dtype=np.uint8)
            if label == "bad":
                arr[22:40, 22:40] = 230
            Image.fromarray(arr).save(target / f"{label}_{i:04d}.png")
    cfg = merge_dict(DEFAULTS, {"task": "top", "profile": "laptop", "pilot": True,
        "dataset_version": "SYNTHETIC_SMOKE_ONLY", "data_root": str(output / "data"),
        "output_root": str(output / "results"), "weights_dir": str(output / "weights"),
        "image_size": "auto", "pretrained": False, "device": "cpu", "cpu_threads": 2,
        "models": ["resnet18", "patchcore"], "seeds": [42], "ensembles": False,
        "near_duplicate_distance": -1, "training": {"epochs": 1, "warmup_epochs": 0, "batch_size": 4,
        "eval_batch_size": 4, "accumulation_steps": 1, "amp": False},
        "patchcore": {"reservoir_size": 256, "coreset_size": 32, "projection_dim": 16}})
    run = new_run(cfg)
    cfg, rows = open_run(run)
    if with_models:
        run_training(run)
        final_test(run)
        predict_folder(run, output / "data", output / "predictions", labeled=True, device="cpu")
        if with_onnx:
            from nilt.deployment import export_package, predict_package
            package = export_package(run, output / "onnx_package")
            predict_package(package, output / "data", output / "onnx_predictions", device="cpu", labeled=True)
    else:
        heldout = [r for r in rows if r["split"] == "selection"]
        # Diagnostic scores test decision/export plumbing; these are not model predictions.
        scores = np.linspace(.1, .9, len(heldout))
        export_predictions(heldout, scores, .5, output / "diagnostic_exports", model_version="SYNTHETIC_NON_MODEL_SCORES")
        write_state(run, "CORE_SMOKE_ONLY", note="Synthetic data/decision plumbing passed. No model trained or evaluated.")
    report = {"status": "passed", "with_models": with_models, "with_onnx": with_onnx,
              "run": str(run), "data": "synthetic", "industrial_performance_evidence": False}
    write_json(output / "smoke_result.json", report)
    print(json.dumps(report, indent=2))
    return report


def dispatch(args):
    if args.command in ("system-preview", "system-create", "system-run", "system-evaluate"):
        from nilt.decision_lab import preview_system, create_system, run_system
        if args.command in ("system-preview", "system-create"):
            from nilt.common import read_json
            spec_path = Path(args.spec).resolve()
            definition = read_json(spec_path)
            for source in definition.get("sources", []):
                value = Path(source["run"])
                if not value.is_absolute():
                    source["run"] = str((spec_path.parent / value).resolve())
            if args.command == "system-preview":
                print(json.dumps(preview_system(definition), indent=2, allow_nan=False))
                return 0
            result = create_system(definition, args.output_root)
        elif args.command == "system-run":
            result = run_system(args.system, args.input, args.output_root, labeled=args.labeled,
                                device=args.device, copy_images=not args.no_copy_images)
        else:
            from nilt.decision_lab import evaluate_system
            result = evaluate_system(args.system, device=args.device, confirm_final_test=args.confirm_final_test)
            print(f"OUTPUT: {result}", flush=True)
            return 0
        print(f"OUTPUT: {result}", flush=True)
        return 0
    if args.command == "review-export":
        from nilt.review_dataset import export_review_dataset
        result = export_review_dataset(args.sessions, args.output_root,
                                       source_run=args.source_run, include_replay=not args.no_replay)
        print(json.dumps(result, indent=2, allow_nan=False))
        return 0
    if args.command in ("workflow-create", "workflow-run"):
        from nilt.inspection_flow import create_workflow, run_workflow
        if args.command == "workflow-create":
            from nilt.common import read_json
            spec_path = Path(args.spec).resolve()
            specification = read_json(spec_path)
            # CLI paths in a spec are relative to that spec, not shell CWD.
            stages = specification.get("stages", []) if isinstance(specification, dict) else []
            for stage in stages if isinstance(stages, list) else []:
                if isinstance(stage, dict) and isinstance(stage.get("decision"), str):
                    value = Path(stage["decision"])
                    if not value.is_absolute():
                        stage["decision"] = str(spec_path.parent / value)
            result = create_workflow(specification, args.output_root)
        else:
            result = run_workflow(args.workflow, args.input, args.output_root,
                                  labeled=args.labeled, device=args.device, copy_images=not args.no_copy_images)
        print(f"OUTPUT: {result}", flush=True)
        return 0
    if args.command == "dashboard":
        from nilt.dashboard import serve_dashboard
        serve_dashboard(args.config, port=args.port, open_browser=not args.no_browser)
        return 0
    if args.command in ("search", "finalize-search", "_search-worker"):
        from nilt.control import supervise_search, search_worker
        if args.command == "_search-worker":
            search_worker(args.session)
            return 0
        if args.command == "finalize-search":
            return supervise_search(run=args.run, hours=args.hours, recover=args.recover_lock,
                                    device=args.device, finalize_only=True)
        if args.run:
            if args.models:
                raise ValueError("A resumed search retains its models/configuration. Start a new run for changes.")
            return supervise_search(run=args.run, hours=args.hours, finalize=not args.no_finalize,
                                    recover=args.recover_lock, device=args.device)
        from nilt.common import load_project, validate_config
        cfg = load_project(args.config, args.profile, args.task)[0]
        if args.device:
            cfg["device"] = args.device
        cfg.setdefault("search", {})["enabled"] = True
        if args.models:
            cfg["models"] = args.models
        if args.hours is not None:
            cfg.setdefault("search", {})["total_budget_seconds"] = args.hours * 3600
        validate_config(cfg)
        return supervise_search(cfg=cfg, hours=args.hours, finalize=not args.no_finalize)
    if args.command in ("decision", "classify", "threshold-review"):
        from nilt.decisions import create_decision, predict_decision, review_decisions
        if args.command == "decision":
            result = create_decision(args.run, args.mode, args.threshold, args.candidate, args.output_root)
        elif args.command == "classify":
            result = predict_decision(args.decision, args.input, args.output_root, args.labeled,
                                      args.copy_images, args.device, run_override=args.run)
        else:
            result = review_decisions(args.run, args.thresholds, args.candidate, args.output_root)
        print(f"OUTPUT: {result}", flush=True)
        return 0
    if args.command == "report":
        import visual_report
        return visual_report.main((["--run", args.run] if args.run else ["--config", args.config, "--task", args.task]))
    # Portable package inference does not import the training stack.
    if args.command == "predict" and args.model:
        if not args.input or not args.output:
            raise ValueError("--model prediction requires --input and --output.")
        from nilt.runtime import predict_package
        return predict_package(args.model, args.input, args.output, device=args.device, labeled=args.labeled)
    from nilt.common import load_project, read_json, write_json
    from nilt.workflow import new_run, open_run, run_training, final_test, predict_folder, export_again
    if args.command == "doctor":
        return 0 if doctor(args.config, args.profile, args.task, args.deployment)["ready"] else 3
    if args.command in ("audit", "run"):
        for cfg in load_project(args.config, args.profile, args.task):
            if args.command == "run":
                from nilt.control import supervise_search
                code = supervise_search(cfg=cfg)
                if code:
                    return code
            else:
                new_run(cfg)
    elif args.command == "resume":
        run = Path(args.run).resolve()
        open_run(run)
        if args.recover_lock and (run / "operation.lock").exists():
            from nilt.control import recover_lock
            recover_lock(run)
        if args.device:
            write_json(run / "runtime_overrides.json", {"device": args.device})
        with log_to(run):
            if (run / "search_status.json").exists() or (run / "budget.json").exists():
                from nilt.control import supervise_search
                return supervise_search(run=run, device=args.device)
            run_training(run)
    elif args.command == "update":
        old_cfg, _ = open_run(args.from_run)
        if args.task and args.task != old_cfg["task"]:
            raise ValueError("Update task must match predecessor task.")
        cfg = load_project(args.config, args.profile, old_cfg["task"])[0]
        cfg["previous_run"] = str(Path(args.from_run).resolve())
        cfg.setdefault("search", {})["enabled"] = False
        from nilt.control import supervise_search
        return supervise_search(cfg=cfg)
    elif args.command == "status":
        from nilt.reporting import render_run_report
        runs = [Path(args.run)] if args.run else []
        if args.config:
            for cfg in load_project(args.config, task=args.task):
                runs.extend(p.parent for p in sorted((Path(cfg["output_root"]) / cfg["task"]).glob("*/model_state.json")))
        result = []
        for run in runs:
            render_run_report(run)
            state = read_json(run / "model_state.json")
            result.append({"run": str(run), "status": state["status"], "updated_at": state.get("updated_at"),
                           "current_candidate": state.get("current_candidate"), "selected_candidate": state.get("selected_candidate"),
                           "report": str(run / "model_report.html")})
        print(json.dumps(result, indent=2))
    elif args.command == "compare":
        from nilt.registry import compare_runs
        result = compare_runs(args.old_run, args.new_run, args.output)
        print(json.dumps(result, indent=2))
    elif args.command == "evaluate":
        if args.split == "external" and not args.input:
            raise ValueError("External evaluation requires --input with labeled good/bad folders.")
        if args.split == "final-test" and (args.input or args.groups_csv):
            raise ValueError("--input/--groups-csv are only valid with --split external.")
        result = final_test(args.run, args.input, args.groups_csv)
        return 0 if result["empirical_target_met"] else 5
    elif args.command == "activate":
        from nilt.registry import activate_run
        print(json.dumps(activate_run(args.run, args.config), indent=2))
    elif args.command == "predict":
        if args.run:
            if not args.input or not args.output:
                raise ValueError("--run prediction requires --input and --output.")
            predict_folder(args.run, args.input, args.output, args.labeled, args.device)
        else:
            from nilt.registry import current_run
            configs = load_project(args.config, args.profile, args.task)
            if len(configs) > 1 and (args.input or args.output):
                raise ValueError("Explicit --input/--output require one selected --task.")
            for cfg in configs:
                stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
                src = args.input or Path(cfg["incoming_root"]) / cfg["task"]
                dst = args.output or Path(cfg["classification_output_root"]) / cfg["task"] / stamp
                predict_folder(current_run(cfg), src, dst, args.labeled, args.device)
    elif args.command == "export":
        export_again(args.run, args.candidate, args.output)
    elif args.command == "package":
        if args.kind == "training":
            if args.decision:
                raise ValueError("--decision applies to inference packages only.")
            from nilt.registry import create_training_package
            print(create_training_package(args.run, args.output))
        else:
            from nilt.deployment import export_package
            print(export_package(args.run, args.output, kind=args.kind, format=args.format, **({"decision": args.decision} if args.decision else {})))
    elif args.command == "restore":
        from nilt.registry import restore_training_package
        print(restore_training_package(args.package, args.data_root, args.output))
    elif args.command == "download-weights":
        from nilt.engine import required_weight_names
        import download_weights
        old_argv = sys.argv
        try:
            for cfg in load_project(args.config, args.profile, args.task):
                if args.models:
                    cfg["models"] = args.models
                sys.argv = ["download_weights.py", "--output", cfg["weights_dir"], "--models", *required_weight_names(cfg)]
                download_weights.main()
        finally:
            sys.argv = old_argv
    elif args.command == "smoke":
        smoke(args.output, args.with_models, args.with_onnx)
    return 0


def main(argv=None):
    args = build_parser().parse_args(argv)
    try:
        result = dispatch(args)
        return result if isinstance(result, int) else 0
    except KeyboardInterrupt:
        print("INTERRUPTED: completed-epoch state is retained where available.", file=sys.stderr)
        return 130
    except (ValueError, FileNotFoundError, FileExistsError, KeyError) as exc:
        print(f"INPUT_ERROR: {exc}", file=sys.stderr)
        return 2
    except (ImportError, RuntimeError, OSError) as exc:
        print(f"EXECUTION_ERROR: {exc}", file=sys.stderr)
        return 3


if __name__ == "__main__":
    sys.exit(main())
