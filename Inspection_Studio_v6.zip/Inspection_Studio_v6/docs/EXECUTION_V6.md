# Devices, cancellation and interrupted checkpoints

## Windows laptop graphics with DirectML

DirectML is an optional, experimental execution backend for a compatible Windows DirectX 12 adapter, including supported Intel integrated graphics. It is a separate choice from NVIDIA CUDA. Integrated graphics are not guaranteed to run a given model faster than the CPU; compare measured images/second and completed validation runs on your computer.

1. Install 64-bit Python 3.12 and the current graphics driver supplied for your computer.
2. Extract this release into its own project folder.
3. Open `Setup-DirectML.cmd`. It creates `%USERPROFILE%\venvs\studio6-directml`, installs the matched packages and runs an actual ResNet forward/backward probe on the local adapter. An error stops setup.
4. Open `Start.cmd`, then choose `DirectML` in the Custom search device selector. Other settings, architecture choices and time budgets remain independent of the device.

For a different adapter, use the setup option below. The setup output lists adapter names and indices. Use `directml:1` in the project configuration or CLI to select index 1; plain `directml` selects index 0.

```powershell
.\Setup-DirectML.cmd -Adapter 1
```

An offline wheel directory is supported:

```powershell
.\Setup-DirectML.cmd -OfflineWheelhouse "D:\StudioWheels"
```

DirectML uses its own environment because the published package requires a different PyTorch pair:

| Environment | PyTorch | torchvision | Additional package |
|---|---|---|---|
| Existing CPU/CUDA setup | 2.7.1 | 0.22.1 | No DirectML package |
| Optional DirectML setup | 2.4.1 | 0.19.1 | torch-directml 0.2.5.dev240914 |

`requirements-directml.txt` also constrains NumPy to the 1.x line for this older backend. Do not install it into the CPU/CUDA environment and do not combine it with `requirements-training.txt`. Setup refuses to alter an unrelated environment. It records the chosen interpreter for `Start.cmd`; run the normal `Setup.cmd` again to select a CPU/CUDA environment.

DirectML execution uses FP32, without CUDA AMP or CUDA pinned-memory transfers. The application checks adapter availability and a small forward/backward computation before use. An explicit DirectML failure is an error, not an application-level switch to CPU. The DirectML provider itself may warn about operators implemented through CPU fallback; inspect the operation log and actual throughput. A successful small probe does not qualify every architecture, image size or operator on that adapter. Full-resolution images may still exceed available memory.

`auto` selects CUDA when available and otherwise CPU. Select DirectML explicitly when you want it. The native Windows DirectML integration is not used on Arch Linux. CPU and CUDA remain available there.

Package references: [Microsoft DirectML setup](https://learn.microsoft.com/en-us/windows/ai/directml/pytorch-windows), [published package](https://pypi.org/project/torch-directml/0.2.5.dev240914/), [exact package dependency metadata](https://pypi.org/pypi/torch-directml/0.2.5.dev240914/json). The package metadata specifies the PyTorch/torchvision pair above; some older setup prose on Microsoft's website describes an earlier pair.

## Pause and cancel

| Action | Active trial | Saved state | Next action |
|---|---|---|---|
| Pause | Remains resumable | Last committed epoch, best checkpoint, provisional current snapshot when possible | Resume the same search and epoch checkpoint |
| Cancel | Ends the active trial with application outcome `CANCELLED` | Same committed files and provisional current snapshot when possible | Inspect partial predictions or explicitly start/resume additional trials |
| Trial timeout | Ends the trial with outcome `TIMEOUT` | Committed files and cooperative provisional snapshot when possible | Other scheduled trials can continue |
| Process failure | Outcome `FAILED` or `OOM` | Previous committed files; current snapshot attempted if the training loop can handle the error | Inspect the error and checkpoints |

Optuna has no built-in `CANCELLED` state. A cancelled trial has Optuna state `FAIL` and the explicit application outcome `CANCELLED`. The dashboard reports cancelled trials separately from failed trials. It receives no fabricated zero score and is not considered a completed candidate.

Cancellation is cooperative: the worker checks the request between batches, during validation and before moving to another trial. The supervisor permits up to 30 seconds for a cancellation checkpoint before stopping an unresponsive worker. A driver hang, force kill, power loss, full disk or denied file write can prevent a new save. Only a successfully committed checkpoint can be recovered.

Closing the browser does not cancel training. Use the dashboard action. Closing a terminal with Ctrl+C remains a pause request for supervised CLI search; avoid killing the process while it writes.

## What is retained

| File | Meaning |
|---|---|
| `best.pt` | Best checkpoint from an evaluated epoch, when one exists |
| `last.pt` | Last fully committed epoch and optimizer state for training recovery |
| `partial.pt` | Current finite weights after interruption; usable for provisional inference, not a completed trial |
| `partial.json` | Reason, checksum, completed epochs, current batch and inference status |
| `partial_checkpoints.json` | Run-level index of available interrupted trial snapshots |

For supervised training, `partial.pt` contains model parameters after completed optimizer updates and current buffers. Pending accumulated gradients are not applied or persisted. It does not replace `last.pt`, so resuming training retains the existing epoch-boundary recovery contract. If cancellation occurs before any update, the snapshot is marked as having no observed trained updates. It may only reflect the initialization.

For interrupted PatchCore fitting, a provisional snapshot is possible once good-image features have been collected. It contains a bounded partial feature bank, or the completed coreset if already available. It is identified as `bounded_partial_reservoir` or `completed_coreset`. It is not a fully fitted, calibrated detector. No bank is usable if the cancellation occurred before features were collected. A resumed PatchCore fit restarts deterministically from the good training images.

All snapshot tensors are stored on CPU for portability. Use only checkpoints from a trusted project, especially in the older optional DirectML environment.

## Inspect a partial model

Use the dashboard's partial-checkpoint diagnostic action when available, or the CLI. Keep `partial.json` beside `partial.pt`; their checksum is verified. Use a new output folder outside the input images.

```powershell
python inspection.py partial-predict --checkpoint "results\vig\RUN\search\resnet18\trial_00000\partial.pt" --input "D:\InspectionImages" --output "D:\InspectionPreview" --device cpu --threshold 0.5
```

Run the command with the project interpreter. For a saved launch interpreter in PowerShell:

```powershell
$StudioPython = (Get-Content .studio-python.txt -Raw).Trim()
& $StudioPython inspection.py partial-predict --checkpoint "results\vig\RUN\search\resnet18\trial_00000\partial.pt" --input "D:\InspectionImages" --output "D:\InspectionPreview" --device cpu
```

`predictions.csv` reports the bad score and provisional prediction. Every copied image goes to `human_review`, with an empty `operator_label`, and the summary is labelled `PARTIAL_UNVALIDATED`. This operation does not select, calibrate, release or overwrite a model. A threshold of 0.5 is only a diagnostic starting point for supervised bad scores; PatchCore uses nonnegative anomaly distances on a different scale.

## Verification scope

Automated checks exercise device routing and visible DirectML failures using mocked adapters, real CPU forward/backward training, cooperative first-epoch cancellation, epoch recovery, finite-weight protection, cancelled Optuna state handling and provisional inference. Windows/Intel adapter execution must pass the installation probe and a representative local trial. This build was not benchmarked or qualified on the user's physical Intel GPU.
