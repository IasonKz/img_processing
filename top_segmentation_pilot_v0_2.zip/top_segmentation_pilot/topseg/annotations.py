"""Lossless annotation objects and bounded native-resolution mask encoding.

Object visibility is an editor-only preference. Every object participates in the
training mask; deleting or erasing its footprint is the way to remove labels.
"""
from __future__ import annotations

import re
import numpy as np
from scipy import ndimage

MAX_ANNOTATION_PIXELS = 40_000_000
MAX_OBJECTS = 10000
MAX_OBJECT_RUNS = 2_000_000
OBJECT_KINDS = {'brush', 'circle', 'ellipse', 'polygon', 'rectangle', 'proposal', 'legacy'}


def _dimensions(width, height):
    if type(width) is not int or type(height) is not int or min(width, height) < 1:
        raise ValueError('Image dimensions must be positive integers.')
    total = width * height
    if total > MAX_ANNOTATION_PIXELS:
        raise ValueError('Image exceeds the annotation limit of 40 million pixels.')
    return total


def _runs(pairs, total, labels=(0, 1, 2)):
    if not isinstance(pairs, list) or not pairs or len(pairs) > total:
        raise ValueError('mask_rle must contain [label, count] pairs.')
    offset = 0
    for pair in pairs:
        if not isinstance(pair, list) or len(pair) != 2:
            raise ValueError('Invalid mask RLE pair.')
        value, count = pair
        if type(value) is not int or value not in labels:
            raise ValueError('Mask labels must be integer values ' + ', '.join(map(str, labels)) + '.')
        if type(count) is not int or count < 1 or count > total - offset:
            raise ValueError('Invalid mask RLE count.')
        yield value, offset, count
        offset += count
    if offset != total:
        raise ValueError('Mask RLE does not cover the complete image.')


def decode_rle(pairs, width: int, height: int) -> np.ndarray:
    """Decode row-major runs, rejecting coercion and partial masks."""
    total = _dimensions(width, height)
    output = np.empty(total, dtype=np.uint8)
    for value, start, count in _runs(pairs, total):
        output[start:start + count] = value
    return output.reshape(height, width)


def encode_rle(mask: np.ndarray) -> list[list[int]]:
    values = np.asarray(mask, dtype=np.uint8).ravel()
    if not len(values):
        return []
    edges = np.flatnonzero(values[1:] != values[:-1]) + 1
    starts = np.concatenate(([0], edges))
    ends = np.concatenate((edges, [len(values)]))
    return [[int(values[a]), int(b - a)] for a, b in zip(starts, ends)]


def validate_objects(objects, width, height):
    """Return normalized objects and their union, using only one full mask."""
    total = _dimensions(width, height)
    if not isinstance(objects, list) or len(objects) > MAX_OBJECTS:
        raise ValueError(f'objects must be a list of at most {MAX_OBJECTS} annotation objects.')
    result, identifiers, union = [], set(), np.zeros(total, dtype=np.uint8)
    run_count = 0
    # A fully fragmented legacy union can intrinsically require one run per
    # image pixel. Permit that baseline while bounding additional object data.
    run_limit = max(MAX_OBJECT_RUNS, total)
    for item in objects:
        if not isinstance(item, dict) or set(item) != {'id', 'name', 'kind', 'visible', 'mask_rle'}:
            raise ValueError('Every annotation object requires id, name, kind, visible and mask_rle.')
        identifier = item['id']
        if not isinstance(identifier, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}', identifier):
            raise ValueError('Object id must contain 1–128 letters, numbers, underscores or hyphens.')
        if identifier in identifiers:
            raise ValueError('Annotation object ids must be unique.')
        if not isinstance(item['name'], str) or not 1 <= len(item['name']) <= 200:
            raise ValueError('Object names require 1–200 characters.')
        if not isinstance(item['kind'], str) or item['kind'] not in OBJECT_KINDS:
            raise ValueError('Unknown annotation object kind.')
        if type(item['visible']) is not bool:
            raise ValueError('Object visible must be a boolean.')
        runs = item['mask_rle']
        if not isinstance(runs, list):
            raise ValueError('Object mask_rle must be a list.')
        run_count += len(runs)
        if run_count > run_limit:
            raise ValueError(f'Annotation objects exceed the {run_limit} total RLE-run limit.')
        normalized, nonempty = [], False
        for value, start, count in _runs(runs, total, labels=(0, 1)):
            if normalized and normalized[-1][0] == value:
                normalized[-1][1] += count
            else:
                normalized.append([value, count])
            if value:
                union[start:start + count] = 1
                nonempty = True
        if not nonempty:
            raise ValueError('Empty annotation objects must be removed from the object list.')
        identifiers.add(identifier)
        result.append({key: item[key] for key in ('id', 'name', 'kind', 'visible')} | {'mask_rle': normalized})
    return result, union.reshape(height, width)


def _encode_indices(indices, total):
    """Encode one component from sorted flat pixel indices, without a full mask."""
    breaks = np.flatnonzero(np.diff(indices) > 1)
    starts = indices[np.concatenate(([0], breaks + 1))]
    ends = indices[np.concatenate((breaks, [len(indices) - 1]))] + 1
    result, position = [], 0
    for start, end in zip(starts, ends):
        if start > position:
            result.append([0, int(start - position)])
        result.append([1, int(end - start)])
        position = end
    if position < total:
        result.append([0, int(total - position)])
    return result


def objects_from_mask(mask, kind='legacy'):
    """Split a legacy semantic mask into lossless connected defect objects.

    Extremely fragmented masks are grouped in one object when object/run bounds
    would otherwise make an existing annotation impossible to open. No support
    pixels are discarded and the group name makes this fallback explicit.
    """
    support = np.asarray(mask) > 0
    height, width = support.shape
    total = _dimensions(width, height)
    labels, count = ndimage.label(support, structure=np.ones((3, 3), dtype=bool))
    if not count:
        return []
    prefix = 'Proposal' if kind == 'proposal' else 'Legacy annotation'
    if count > MAX_OBJECTS:
        return [{'id': 'legacy-all', 'name': f'{prefix} (grouped components)', 'kind': kind,
                 'visible': True, 'mask_rle': encode_rle(support)}]
    result, run_count = [], 0
    for value, slices in enumerate(ndimage.find_objects(labels), start=1):
        yy, xx = np.nonzero(labels[slices] == value)
        indices = (yy + slices[0].start) * width + xx + slices[1].start
        runs = _encode_indices(indices, total)
        run_count += len(runs)
        if run_count > MAX_OBJECT_RUNS:
            return [{'id': 'legacy-all', 'name': f'{prefix} (grouped components)', 'kind': kind,
                     'visible': True, 'mask_rle': encode_rle(support)}]
        result.append({'id': f'{kind}-{value}', 'name': f'{prefix} {value}', 'kind': kind,
                       'visible': True, 'mask_rle': runs})
    return result
