"""DirectML routing mocks and real CPU interruption/checkpoint integration."""
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch, Mock

import numpy as np
from PIL import Image
import torch

from nilt import engine, devices, search
from nilt.common import DEFAULTS, merge_dict, read_json, sha_file, write_json
from nilt.partial_checkpoints import classify_partial, list_partial_checkpoints


def tiny_model(*args, **kwargs):
    model = torch.nn.Sequential(torch.nn.Conv2d(3, 4, 3, padding=1), torch.nn.ReLU(),
        torch.nn.AdaptiveAvgPool2d(1), torch.nn.Flatten(), torch.nn.Linear(4, 2))
    return model, model[-1]


def fixture(root):
    data = root / "images"
    data.mkdir()
    rows = []
    for i in range(8):
        path = data / f"{i}.png"
        Image.fromarray(np.full((32, 32, 3), 30 + 150 * (i % 2), dtype=np.uint8)).save(path)
        rows.append({"path": str(path), "relative_path": path.name, "pixel_hash": sha_file(path),
                     "group": str(i), "label": i % 2, "split": "train" if i < 4 else "val"})
    cfg = merge_dict(DEFAULTS, {"task": "vig", "device": "cpu", "cpu_threads": 1, "image_size": 32,
        "pretrained": False, "models": ["resnet18"], "seeds": [42], "weights_dir": str(root / "weights"),
        "output_root": str(root), "data_root": str(data), "profile": "laptop",
        "training": {"epochs": 2, "warmup_epochs": 0, "mode": "head_only", "batch_size": 1,
            "eval_batch_size": 2, "accumulation_steps": 1, "optimizer": "sgd", "momentum": 0,
            "scheduler": "constant", "amp": False},
        "search": {"enqueue_presets": False, "minimum_trial_seconds": .001,
            "space": {"mode": ["head_only"], "scheduler": ["constant"], "effective_batch_size": [1]}}})
    return cfg, rows, data


class DirectMLTests(unittest.TestCase):
    def test_device_names_and_adapter_indices(self):
        for value in ("auto", "cpu", "cuda", "cuda:2", "directml", "directml:0", "directml:3"):
            self.assertEqual(devices.validate_device_name(value), value)
        for value in ("directml:-1", "directml:foo", "mps", "cpu:1", "cuda:x"):
            with self.assertRaises(ValueError):
                devices.validate_device_name(value)

    def test_explicit_missing_backend_fails_instead_of_cpu_fallback(self):
        with patch("nilt.devices.platform.system", return_value="Windows"), \
             patch("nilt.devices.importlib.import_module", side_effect=ImportError("not installed")):
            with self.assertRaisesRegex(RuntimeError, "Setup-DirectML"):
                engine.device_for({"device": "directml"})

    def test_backend_routing_and_forward_backward_probe(self):
        dml = Mock()
        dml.device.return_value = torch.device("cpu")
        adapters = [{"index": 0, "name": "Intel Graphics", "device": "directml:0"}]
        with patch("nilt.devices.directml_devices", return_value=(dml, adapters)):
            resolved = engine.device_for({"device": "directml:0"})
            self.assertEqual(resolved.type, "cpu")  # Mock adapter runs the probe on real CPU tensors.
            dml.device.assert_called_once_with(0)
            with self.assertRaisesRegex(ValueError, "adapter 1"):
                engine.device_for({"device": "directml:1"})

    def test_directml_probe_failure_is_visible(self):
        dml = Mock()
        dml.device.return_value = torch.device("cpu")
        with patch("nilt.devices.directml_devices", return_value=(dml, [{"name": "Intel Graphics"}])):
            broken_torch = Mock()
            broken_torch.tensor.side_effect = RuntimeError("adapter failed")
            with self.assertRaisesRegex(RuntimeError, "has not switched to CPU"):
                devices.resolve_directml("directml", broken_torch)


class PartialCheckpointTests(unittest.TestCase):
    def test_cancel_mid_first_epoch_saves_current_inference_weights_and_predictions(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            cfg, rows, data = fixture(root)
            target = root / "search" / "resnet18" / "trial_00000"
            calls = 0
            def stop():
                nonlocal calls
                calls += 1
                return "operator_cancel" if calls >= 4 else None
            with patch.object(engine, "make_model", tiny_model):
                with self.assertRaisesRegex(engine.TrainingStopped, "operator_cancel"):
                    engine.train_one("resnet18", 42, rows, cfg, target, stop_check=stop)
                record = read_json(target / "partial.json")
                self.assertTrue(record["usable_for_inference"])
                self.assertEqual(record["completed_epochs"], 0)
                self.assertEqual(record["current_process_optimizer_steps"], 1)
                self.assertFalse((target / "completed.json").exists())
                self.assertFalse((target / "last.pt").exists())
                self.assertIsNone(record["validation_ap"])
                records = list_partial_checkpoints(root)
                self.assertTrue(records[0]["integrity_verified"])
                summary = classify_partial(target / "partial.pt", data, root / "predictions")
                self.assertEqual(summary["status"], "PARTIAL_UNVALIDATED")
                self.assertEqual(len(list((root / "predictions" / "human_review").glob("*.png"))), 8)
                self.assertFalse((root / "selected.json").exists())

    def test_pause_keeps_epoch_recovery_and_partial_is_not_training_resume(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            cfg, rows, _ = fixture(root)
            epochs = []
            with patch.object(engine, "make_model", tiny_model):
                with self.assertRaises(engine.TrainingStopped):
                    engine.train_one("resnet18", 42, rows, cfg, root / "model",
                        progress_callback=lambda p: epochs.append(p["epoch"]),
                        stop_check=lambda: "operator_pause" if epochs else None)
                self.assertTrue((root / "model" / "last.pt").is_file())
                engine.train_one("resnet18", 42, rows, cfg, root / "model")
                self.assertTrue((root / "model" / "completed.json").is_file())

    def test_cancel_trial_is_terminal_but_not_failed_quality_or_zero_score(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            cfg, rows, _ = fixture(root)
            study = search._study("resnet18", cfg, root)
            def cancel(*args, **kwargs):
                write_json(root / "control.json", {"action": "cancel", "stop": True})
                raise engine.TrainingStopped("operator_cancel")
            with patch.object(engine, "train_one", side_effect=cancel):
                result = search._run_trial(root, "resnet18", study, rows, cfg,
                                          {"resnet18": study}, time.time() + 20, time.time() + 30)
            self.assertEqual(result, "operator_cancel")
            trial = study.trials[0]
            self.assertEqual(trial.state.name, "FAIL")
            self.assertEqual(trial.user_attrs["outcome"], "CANCELLED")
            self.assertIsNone(trial.value)
            status = search._publish(root, {"resnet18": study}, "SEARCH_CANCELLED")
            self.assertEqual(status["failed_trials"], 0)
            self.assertEqual(status["cancelled_trials"], 1)

    def test_nonfinite_current_state_does_not_replace_last_committed_checkpoint(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            cfg, rows, _ = fixture(root)
            target = root / "trial"
            target.mkdir()
            (target / "last.pt").write_bytes(b"previous committed checkpoint")
            previous = sha_file(target / "last.pt")
            model, _ = tiny_model()
            with torch.no_grad():
                next(model.parameters()).fill_(float("nan"))
            record = engine._save_partial_checkpoint(target, model, cfg, "resnet18", 42,
                1, 1, [], 1, "RuntimeError", {})
            self.assertFalse(record["usable_for_inference"])
            self.assertEqual(sha_file(target / "last.pt"), previous)
            self.assertFalse((target / "partial.pt").exists())

    def test_forced_cancel_reconciles_only_running_trials_without_a_score(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            cfg, _, _ = fixture(root)
            study = search._study("resnet18", cfg, root)
            completed = study.ask()
            study.tell(completed, .8)
            study.ask()
            result = search.reconcile_forced_cancel(root)
            self.assertEqual(result["status"], "SEARCH_CANCELLED")
            self.assertEqual(result["completed_trials"], 1)
            self.assertEqual(result["cancelled_trials"], 1)
            self.assertEqual(study.trials[0].value, .8)
            self.assertIsNone(study.trials[1].value)

    def test_patchcore_cancel_retains_provisional_memory_for_diagnostic_inference(self):
        from nilt import patchcore
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            cfg, rows, data = fixture(root)
            cfg["models"] = ["patchcore"]
            cfg["patchcore"].update(reservoir_size=20, coreset_size=5, query_chunk_size=32, memory_chunk_size=5)
            calls = 0
            def stop():
                nonlocal calls
                calls += 1
                return "operator_cancel" if calls >= 3 else None
            def extractor(*args, **kwargs):
                return torch.nn.Sequential(torch.nn.Conv2d(3, 4, 3, stride=4, padding=1))
            target = root / "patchcore"
            with patch.object(patchcore, "make_patchcore_extractor", extractor):
                with self.assertRaises(engine.TrainingStopped):
                    patchcore.fit_patchcore(42, rows, cfg, target, stop_check=stop)
                metadata = read_json(target / "partial.json")
                self.assertTrue(metadata["usable_for_inference"])
                self.assertEqual(metadata["processed_good_images"], 1)
                self.assertFalse((target / "completed.json").exists())
                summary = classify_partial(target / "partial.pt", data, root / "preview", threshold=2.)
                self.assertEqual(summary["n_images"], 8)


if __name__ == "__main__":
    unittest.main()
