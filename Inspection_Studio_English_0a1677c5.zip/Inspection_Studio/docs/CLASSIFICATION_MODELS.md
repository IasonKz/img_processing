# Pretrained classification model catalog

Compare pretrained image classifiers locally with PyTorch and timm. Models
are downloaded on demand, not bundled in Git. CPU and CUDA are supported.

All entries are also available in the dashboard for bad/good training,
search and comparison. See [dashboard models and extended GPU search](WORKSTATION_50H.md).
The commands below describe the separate ImageNet classification CLI.

## Model catalog

| Family | Sizes | Expected pretrained weight license | Use |
| --- | --- | --- | --- |
| ConvNeXt V2 | atto, femto, pico, nano, tiny, base, large, huge | CC BY-NC 4.0 | Noncommercial research |
| ConvNeXt | tiny, small, base, large, xlarge | Apache 2.0 | Research / commercial |
| DeiT III | small, medium, base, large, huge | Apache 2.0 | Research / commercial |
| Swin V2 | tiny, small, base, large | MIT | Research / commercial |
| EVA-02 | tiny, small, base, large | MIT | Research / commercial |
| EfficientNet V2 | s, m, l | Apache 2.0 | Research / commercial |

EVA-02 large, ConvNeXt large/xlarge and DeiT III large are strong accuracy
candidates; start with smaller variants to measure memory and speed on the target
hardware. This is a curated comparison set, not a claim that any model is
universally best. Larger models and EVA's 448-pixel inputs need more memory.
ConvNeXt V2 has no pretrained small classifier in the selected timm family.

All selected heads predict the **1,000 ImageNet classes**. Arbitrary custom
classes need a fine-tuned classifier head; these checkpoints do not predict
new classes by assigning names to their outputs.

## Installation

Python 3.10+:

```bash
python -m venv .venv
source .venv/bin/activate
export HF_HOME="$PWD/.cache/huggingface"
export HF_HUB_DISABLE_XET=1
python -m pip install torch==2.7.1 torchvision==0.22.1 --index-url https://download.pytorch.org/whl/cpu
python -m pip install -e '.[classification]'
cvtester list
```

For an NVIDIA GPU, install a matching torch/torchvision CUDA build using
[PyTorch's installer](https://pytorch.org/get-started/locally/) instead of the
CPU installation command, then pass `--device cuda`.

## Try an image

```bash
cvtester list --purpose commercial
cvtester predict --model eva02-small --image /path/to/image.jpg
cvtester predict --model convnextv2-base --purpose research --image /path/to/image.jpg --device cuda
```

Inference defaults to `--purpose commercial`. ConvNeXt V2 is rejected in
that mode. `--purpose research` means noncommercial use for restricted
weights; research performed commercially does not automatically qualify.

## Compare models on a dataset

Use an ImageFolder directory with ImageNet synset names:

```text
validation/
  n01440764/
    image1.jpg
  n01443537/
    image2.jpg
```

```bash
cvtester benchmark --models convnext-small deit3-small eva02-small --dataset /path/to/validation --batch-size 8 --output results/comparison.json
cvtester benchmark --models convnextv2-tiny convnextv2-base --purpose research --dataset /path/to/validation --device cuda --batch-size 4
```

For named folders, supply `--class-map /path/to/classes.json` mapping each
folder to its actual ImageNet output index, for example
`{"tench": 0, "goldfish": 1}`. The tool does not assume alphabetical folder
order matches ImageNet output order. Every folder must have a unique mapping.

Results include top-1/top-5 accuracy, sample count, parameter count, input
size, batch size, device, weight license and exact checkpoint revision.
Throughput measures model forward passes after warmup; it excludes disk I/O,
preprocessing, transfers and downloads. Compare with the same dataset and
hardware. Models use their own checkpoint preprocessing and resolution.
Each model is loaded separately. Failed models are reported and make the
command exit nonzero; successful model results are retained. Reduce batch
size when GPU memory is insufficient.

## Weights, licenses and loading

The catalog distinguishes source-code licenses from pretrained-weight
licenses. ConvNeXt V2's MIT code does not make its pretrained weights
commercially usable. Each entry links to its model card in `cvtester list`.
Before loading, the tool checks the current card's license against the
catalog, checks for safetensors, and pins config and weights to the same
commit. Missing or changed license metadata stops loading.

Only `model.safetensors` is loaded. There is no pickle checkpoint fallback,
no remote Python model code, and no `trust_remote_code` option. Implementations
come from the installed timm package. This reduces loading risk, but model
accuracy and suitability still depend on the inspection data and task.

License labels describe model terms, not a clearance of training-data,
trademark or privacy rights. Preserve required notices and attribution when
redistributing models. The CLI's [Apache 2.0 code license](../cvtester/LICENSE) does not relicense model weights.

Official sources:

- [ConvNeXt V2 licenses](https://github.com/facebookresearch/ConvNeXt-V2/blob/main/LICENSE)
- [ConvNeXt](https://github.com/facebookresearch/ConvNeXt)
- [DeiT III](https://github.com/facebookresearch/deit)
- [Swin Transformer](https://github.com/microsoft/Swin-Transformer)
- [EVA / EVA-02](https://github.com/baaivision/EVA)
- [timm model cards](https://huggingface.co/timm)

## Runtime and network requirements

Run commands from the repository root with the project Python environment
activated. The classification CLI requires no application server or API key.

Model downloads require access to `huggingface.co` and its Hugging Face CDN
or Xet storage destinations. Package installation requires PyPI; CPU PyTorch
packages also require `download.pytorch.org`. Keep datasets, caches, model
weights and results outside version control.

Use a writable cache location, for example `HF_HOME="$PWD/.cache/huggingface"`.
`HF_HUB_DISABLE_XET=1` selects the Hub's HTTPS download path. Where network
access is restricted, permit the required weights CDN destinations, including
`us.aws.cdn.hf.co`. A proxy 403 response requires review of the applicable
network access configuration. Retain TLS verification.

```bash
python -m unittest discover -s tests -p 'test_classification.py' -v
```

Tests run offline and exercise license restrictions, safe-loader metadata,
dataset class mapping and evaluation metrics. Pretrained inference additionally
requires downloading the selected weights before use.
