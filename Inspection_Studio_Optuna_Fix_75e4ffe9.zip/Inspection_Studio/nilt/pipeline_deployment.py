"""Frozen local pipeline recipes and concise production-run history."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import html
import json
from pathlib import Path, PurePosixPath
import shutil
import uuid
from zipfile import ZipFile

from .common import read_json, sha_file, write_json, write_csv, EXTENSIONS


def source_details(kind, path):
    if kind == "decision":
        from .decisions import load_decision
        record, run, cfg, chosen = load_decision(path)
        models = [{"candidate": chosen["name"], "run": str(run), **member} for member in chosen["members"]]
    elif kind == "system":
        from .decision_lab import load_system
        record, sources = load_system(path)
        models = [{"candidate": source["chosen"]["name"], "run": str(source["run"]), **member}
                  for source in sources for member in source["chosen"]["members"]]
    elif kind == "workflow":
        from .inspection_flow import load_workflow
        record, stages = load_workflow(path)
        models = [{"candidate": stage["chosen"]["name"], "run": str(stage["run"]), **member}
                  for stage in stages for member in stage["chosen"]["members"]]
    else:
        raise ValueError("Choose a saved decision, decision system or workflow.")
    return record, models


def create_pipeline(name, kind, source, target):
    source, target = Path(source).resolve(), Path(target).resolve()
    record, models = source_details(kind, source)
    if kind == "decision" and record.get("mode") == "scores_only":
        raise ValueError("Save a classification decision with thresholds before deployment.")
    if record.get("task") != "vig":
        raise ValueError("This deployment workspace currently accepts VIG pipelines.")
    thresholds = record.get("definition", {}).get("thresholds", {}) if kind == "system" else {}
    target.mkdir(parents=True, exist_ok=False)
    pipeline = {"format": "nilt_local_pipeline_v1", "name": str(name).strip() or target.name,
                "task": "vig", "kind": kind, "source": str(source), "source_sha256": sha_file(source),
                "models": models, "created_utc": datetime.now(timezone.utc).isoformat(),
                "decision_mode": record.get("mode") or record.get("rule") or record.get("definition", {}).get("kind"),
                "threshold": record.get("threshold"), "good_threshold": thresholds.get("good", record.get("good_threshold")),
                "bad_threshold": thresholds.get("bad", record.get("bad_threshold")),
                "stages": [{key: stage.get(key) for key in ("name", "candidate", "mode", "threshold", "good_threshold", "bad_threshold")}
                           for stage in record.get("stages", record.get("definition", {}).get("stages", []))],
                "qualification_status": record.get("qualification_status")}
    write_json(target / "pipeline.json", pipeline)
    write_json(target / "integrity.json", {"sha256": sha_file(target / "pipeline.json")})
    return pipeline


def load_pipeline(path):
    path = Path(path).resolve()
    if path.is_dir():
        path /= "pipeline.json"
    if sha_file(path) != read_json(path.with_name("integrity.json")).get("sha256"):
        raise ValueError("The saved pipeline changed. Create a new pipeline version.")
    record = read_json(path)
    if record.get("format") != "nilt_local_pipeline_v1" or record.get("task") != "vig":
        raise ValueError("Choose a VIG deployment pipeline.")
    if sha_file(record["source"]) != record["source_sha256"]:
        raise ValueError("The pipeline's frozen decision changed.")
    source_details(record["kind"], record["source"])
    return record


def _input(source, output):
    source = Path(source).expanduser().resolve()
    if source.is_dir():
        return source
    if not source.is_file() or source.suffix.lower() != ".zip":
        raise ValueError("Deployment input must be an image folder or ZIP archive.")
    target = output / "archive_input"
    total = 0
    with ZipFile(source) as zipped:
        images = []
        for item in zipped.infolist():
            relative = PurePosixPath(item.filename.replace("\\", "/"))
            if relative.is_absolute() or ".." in relative.parts or any(":" in p for p in relative.parts):
                raise ValueError("Archive contains a path outside its input folder.")
            if item.is_dir() or relative.suffix.lower() not in EXTENSIONS:
                continue
            if ((item.external_attr >> 16) & 0o170000) == 0o120000:
                raise ValueError("Archive image links are unsupported.")
            total += item.file_size
            if total > 20 * 1024 ** 3:
                raise ValueError("Archive images exceed the 20 GiB extraction limit.")
            images.append((item, relative))
        target.mkdir(parents=True)
        for item, relative in images:
            destination = target.joinpath(*relative.parts)
            destination.parent.mkdir(parents=True, exist_ok=True)
            with zipped.open(item) as original, destination.open("xb") as image:
                shutil.copyfileobj(original, image)
    return target


def deploy(request, output, stop_check=None):
    from .review import read_records
    pipeline = load_pipeline(request["pipeline"])
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    brief = {"status": "running", "pipeline": pipeline, "pipeline_sha256": sha_file(request["pipeline"]),
             "input": request["input"], "started_utc": datetime.now(timezone.utc).isoformat(), "counts": {}}
    write_json(output / "report.json", brief)
    source = _input(request["input"], output)
    if output.is_relative_to(source) or source.is_relative_to(output) and source != output / "archive_input":
        raise ValueError("Deployment results must be outside the input folder.")
    device = request.get("device", "cpu")
    from .inspection_identity import capture_view
    files = [path for path in sorted(source.rglob("*")) if path.is_file() and path.suffix.lower() in EXTENSIONS]
    views = [(path, capture_view(path.relative_to(source))) for path in files]
    inference_input = source
    if any(view in ("top", "bottom") for _, view in views):
        vig_files = [path for path, view in views if view == "vig"]
        if not vig_files:
            raise ValueError("The mixed-view folder contains no identified VIG captures for this pipeline.")
        inference_input = output / "inspection_input"
        for path in vig_files:
            if stop_check and stop_check():
                raise InterruptedError("Deployment stopped while selecting VIG captures.")
            if path.is_symlink() or not path.resolve().is_relative_to(source):
                raise ValueError("Deployment images must remain inside the input folder.")
            destination = inference_input / path.relative_to(source)
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, destination)
    brief["resolved_input"] = str(source)
    tray_options = {"tray_roles": request["tray_roles"]} if "tray_roles" in request else {}
    if stop_check and stop_check():
        raise InterruptedError("Deployment stopped before inference.")
    if pipeline["kind"] == "decision":
        from .decisions import predict_decision
        session = predict_decision(pipeline["source"], inference_input, output_root=output / "sessions", device=device,
                                   copy_images=True, stop_check=stop_check, **tray_options)
    elif pipeline["kind"] == "system":
        from .decision_lab import run_system
        session = run_system(pipeline["source"], inference_input, output_root=output / "sessions", device=device,
                             copy_images=True, stop_check=stop_check, **tray_options)
    else:
        from .inspection_flow import run_workflow
        session = run_workflow(pipeline["source"], inference_input, output_root=output / "sessions", device=device,
                               copy_images=True, stop_check=stop_check, **tray_options)
    entries, counts = [], Counter({"good": 0, "bad": 0, "review": 0, "unsuitable": 0})
    for row in read_records(session):
        if stop_check and stop_check():
            raise InterruptedError("Deployment stopped while copying output images.")
        label = row.get("prediction") or "unsuitable"
        if row.get("status") != "ok":
            label = "unsuitable"
        counts[label] += 1
        if row.get("copied_path"):
            asset = Path(session) / row["copied_path"]
            destination = output / label / Path(row["relative_path"]).name
            destination.parent.mkdir(exist_ok=True)
            if destination.exists():
                digest = hashlib.sha256(row["relative_path"].encode()).hexdigest()[:12]
                destination = destination.with_name(destination.stem + "__" + digest + destination.suffix)
            with asset.open("rb") as original, destination.open("xb") as image:
                shutil.copyfileobj(original, image)
        entries.append({"image": row["relative_path"], "result": label, "score": row.get("bad_score"),
                        "threshold": row.get("threshold"), "error": row.get("error", "")})
    for label in ("good", "bad", "review"):
        (output / label).mkdir(exist_ok=True)
    brief.update(status="completed", counts=dict(counts), images=sum(counts.values()),
                 session=str(session), completed_utc=datetime.now(timezone.utc).isoformat())
    write_json(output / "report.json", brief)
    write_csv(output / "images.csv", entries)
    models = ", ".join(sorted({m.get("model") or m["candidate"] for m in pipeline["models"]}))
    body = (f"<!doctype html><html><head><meta charset='utf-8'><title>NILT deployment run</title></head>"
            f"<body style='font:15px Arial;color:#17354a;max-width:850px;margin:40px auto'>"
            f"<h1>NILT · VIG inspection</h1><p>{html.escape(brief['started_utc'])}</p>"
            f"<p><b>Pipeline:</b> {html.escape(pipeline['name'])}</p><p><b>Models:</b> {html.escape(models)}</p>"
            f"<p><b>Input:</b> {html.escape(str(request['input']))}</p>"
            f"<p><b>Results:</b> {counts['good']} good · {counts['bad']} bad · {counts['review']} review · {counts['unsuitable']} unavailable</p>"
            f"<p><b>Decision:</b> {html.escape(str(pipeline['decision_mode']))} · threshold {pipeline['threshold']}"
            f" · lower {pipeline['good_threshold']} · upper {pipeline['bad_threshold']}</p>"
            f"<p style='font:11px monospace'>Pipeline SHA-256: {brief['pipeline_sha256']}</p>"
            f"<p>Detailed image records: images.csv</p></body></html>")
    (output / "report.html").write_text(body, encoding="utf-8")
    from .deployment_review import build_review
    review = output / "quality_review" / "snapshots" / (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%f") + "_" + uuid.uuid4().hex[:8])
    index = build_review({"run": str(output)}, review, stop_check=stop_check)
    brief["quality_review"] = {"snapshot": index["snapshot"], "units": len(index["units"]), "counts": index["counts"]}
    write_json(output / "report.json", brief)
    print(f"DEPLOYMENT: {output}", flush=True)
    return brief
