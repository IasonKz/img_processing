from __future__ import annotations

import contextlib
import gc
from pathlib import Path
import time

import numpy as np
import torch
from torch import nn
from sklearn.metrics import average_precision_score

from .common import (LOG, CLASS_MAP, choose_device, file_sha256, object_hash, output_dir, read_json,
                     seed_everything, torch_load, torch_save, write_csv, write_json)
from .images import ImageTransform, make_loader
from .models import initialize_classifier, load_classifier
from .splitting import read_manifest, verify_manifest


def transform_for(cfg: dict, spec: dict, preprocessing_info: dict, train: bool = False) -> ImageTransform:
    return ImageTransform(int(spec["input_size"]), preprocessing_info["mean"], preprocessing_info["std"],
                          cfg["preprocessing"], cfg["augmentation"] if train else None)


def amp_context(device, enabled: bool):
    return torch.autocast(device_type="cuda", dtype=torch.float16) if device.type == "cuda" and enabled else contextlib.nullcontext()


@torch.inference_mode()
def predict_logits(model, loader, device, amp: bool = True) -> dict[str, float]:
    model.eval()
    result = {}
    for images, _, ids in loader:
        with amp_context(device, amp):
            logits = model(images.to(device, non_blocking=True))
        values = logits.float().cpu().numpy()
        if not np.all(np.isfinite(values)):
            raise RuntimeError("Non-finite model scores. No silent PASS is allowed")
        result.update({sample_id: float(value) for sample_id, value in zip(ids, values)})
    return result


def checkpoint_payload(model, cfg, name, spec, norm, data_sig, training_sig, epoch, history):
    return {"format_version": 1, "name": name, "spec": spec, "class_map": CLASS_MAP,
            "task": cfg["project"]["task"], "state_dict": {k: v.detach().cpu() for k, v in model.state_dict().items()},
            "normalization": norm, "data_cfg": cfg["data"], "preprocessing": cfg["preprocessing"],
            "dataset_signature": data_sig, "training_signature": training_sig, "epoch": epoch,
            "history": history}


def training_signature(cfg: dict, spec: dict, data_sig: str) -> str:
    """Identity of the training experiment; also checked before selection."""
    return object_hash({"spec": spec, "training": cfg["training"], "augmentation": cfg["augmentation"],
                        "preprocessing": cfg["preprocessing"], "data": cfg["data"], "dataset": data_sig,
                        "seed": cfg["project"]["seed"], "warm_start": cfg["paths"].get("warm_start_run")})


def train_one(cfg: dict, name: str, spec: dict, rows: list[dict], device) -> None:
    folder = output_dir(cfg) / "models" / name
    folder.mkdir(parents=True, exist_ok=True)
    data_sig = read_json(output_dir(cfg) / "dataset.json")["signature"]
    training_sig = training_signature(cfg, spec, data_sig)
    status_path = folder / "status.json"
    if status_path.exists():
        status = read_json(status_path)
        if status["training_signature"] != training_sig:
            raise ValueError(f"Training configuration changed for {name}. Use a new output_dir")
        if status.get("completed"):
            if not (folder / "best.pt").exists() or file_sha256(folder / "best.pt") != status["checkpoint_sha256"]:
                raise ValueError(f"Checkpoint integrity check failed: {name}")
            LOG.info("Skipping already-completed model %s", name)
            return
    seed_everything(int(cfg["project"]["seed"]), cfg["runtime"]["deterministic"])
    model, norm = initialize_classifier(spec, cfg)
    warm_run = cfg["paths"].get("warm_start_run")
    if warm_run:
        warm_path = Path(warm_run) / "models" / name / "best.pt"
        warm = torch_load(warm_path)
        if warm["task"] != cfg["project"]["task"] or warm["spec"]["architecture"] != spec["architecture"]:
            raise ValueError("Warm-start task/architecture mismatch")
        if warm["data_cfg"] != cfg["data"] or warm["preprocessing"] != cfg["preprocessing"]:
            raise ValueError("Warm-start preprocessing changed; explicitly review this in a separate experiment")
        model.load_state_dict(warm["state_dict"], strict=True)
        norm = warm["normalization"]
        norm = {**norm, "warm_start_sha256": file_sha256(warm_path)}
    model.to(device)
    train_rows = [r for r in rows if r["split"] == "train"]
    tune_rows = [r for r in rows if r["split"] == "tune"]
    batch_size = int(cfg["training"]["batch_size"])
    loader = make_loader(train_rows, cfg, transform_for(cfg, spec, norm, train=True), batch_size, shuffle=True)
    tune_loader = make_loader(tune_rows, cfg, transform_for(cfg, spec, norm), batch_size)
    positives = sum(r["label"] == 1 for r in train_rows)
    negatives = len(train_rows) - positives
    weight = cfg["training"]["positive_weight"]
    if weight == "auto":
        weight = max(1.0, min(float(cfg["training"]["max_positive_weight"]), negatives / positives))
    weight = float(weight)
    if weight <= 0:
        raise ValueError("positive_weight must be positive")
    criterion = nn.BCEWithLogitsLoss(pos_weight=torch.tensor(weight, device=device), reduction="sum")
    opt = torch.optim.AdamW([
        {"params": model.backbone.parameters(), "lr": float(cfg["training"]["backbone_lr"])},
        {"params": model.head.parameters(), "lr": float(cfg["training"]["head_lr"])}],
        weight_decay=float(cfg["training"]["weight_decay"]))
    epochs = int(cfg["training"]["epochs"])
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    amp = bool(cfg["runtime"]["amp"] and device.type == "cuda")
    scaler = torch.amp.GradScaler("cuda", enabled=amp)
    accumulation = int(cfg["training"]["gradient_accumulation"])
    if accumulation < 1:
        raise ValueError("gradient_accumulation must be >= 1")
    best_ap, best_loss, no_improvement = -1.0, float("inf"), 0
    history = []
    started = time.perf_counter()
    write_json(status_path, {"completed": False, "training_signature": training_sig})
    for epoch in range(epochs):
        model.set_training_stage(epoch, int(cfg["training"]["head_epochs"]))
        opt.zero_grad(set_to_none=True)
        summed_loss, seen, window_seen = 0.0, 0, 0
        for step, (images, labels, _) in enumerate(loader):
            images = images.to(device, non_blocking=True)
            labels = labels.to(device, dtype=torch.float32)
            with amp_context(device, amp):
                logits = model(images)
                loss_sum = criterion(logits, labels)
            if not torch.isfinite(loss_sum):
                raise RuntimeError("Non-finite training loss. Check images, learning rate and AMP")
            # Accumulate sums; normalize gradients by actual images in this
            # accumulation window, including the final partial window.
            scaler.scale(loss_sum).backward()
            count = labels.numel()
            seen += count
            window_seen += count
            summed_loss += float(loss_sum.detach())
            if (step + 1) % accumulation == 0 or step + 1 == len(loader):
                scaler.unscale_(opt)
                for parameter in model.parameters():
                    if parameter.grad is not None:
                        parameter.grad.div_(window_seen)
                nn.utils.clip_grad_norm_(model.parameters(), float(cfg["training"]["grad_clip_norm"]))
                scaler.step(opt)
                scaler.update()
                opt.zero_grad(set_to_none=True)
                window_seen = 0
            if (step + 1) % int(cfg["training"]["log_every_batches"]) == 0:
                LOG.info("%s epoch %s/%s batch %s/%s loss %.5f", name, epoch + 1, epochs, step + 1, len(loader), summed_loss / seen)
        logits_by_id = predict_logits(model, tune_loader, device, amp)
        y = np.array([r["label"] for r in tune_rows])
        z = np.array([logits_by_id[r["sample_id"]] for r in tune_rows])
        # Stable unweighted BCE for validation; no tuning on calibration/test.
        tune_loss = float(np.mean(np.logaddexp(0, z) - y * z))
        ap = float(average_precision_score(y, z))
        entry = {"epoch": epoch + 1, "train_loss": summed_loss / seen, "tune_bce": tune_loss,
                 "tune_average_precision": ap, "lr_backbone": opt.param_groups[0]["lr"],
                 "elapsed_seconds": time.perf_counter() - started}
        history.append(entry)
        improved = ap > best_ap + 1e-6 or (abs(ap - best_ap) <= 1e-6 and tune_loss < best_loss - 1e-5)
        if improved:
            best_ap, best_loss, no_improvement = ap, tune_loss, 0
            torch_save(folder / "best.pt", checkpoint_payload(model, cfg, name, spec, norm, data_sig, training_sig, epoch + 1, history))
        else:
            no_improvement += 1
        write_csv(folder / "history.csv", history)
        LOG.info("%s epoch %s: train %.5f | tune AP %.5f | tune BCE %.5f", name, epoch + 1, entry["train_loss"], ap, tune_loss)
        scheduler.step()
        if no_improvement >= int(cfg["training"]["patience"]):
            LOG.info("Early stopping: %s", name)
            break
    write_json(status_path, {"completed": True, "training_signature": training_sig, "best_tune_ap": best_ap,
                             "best_tune_bce": best_loss, "epochs_run": len(history),
                             "checkpoint_sha256": file_sha256(folder / "best.pt"), "pretraining": norm})
    del model, opt, loader, tune_loader
    gc.collect()
    if device.type == "cuda":
        torch.cuda.empty_cache()


def train_all(cfg: dict, only_model: str | None = None) -> None:
    verify_manifest(cfg)
    rows = read_manifest(cfg)
    device = choose_device(cfg)
    if cfg["runtime"].get("require_gpu_for_training") and device.type != "cuda":
        raise RuntimeError("A GPU is required by this configuration, but CUDA is unavailable")
    if device.type == "cpu":
        LOG.warning("Training on CPU. Full-resolution multi-model training is intended for the GPU workstation")
    names = [only_model] if only_model else [name for name, spec in cfg["models"].items() if spec.get("enabled", True)]
    for name in names:
        if name not in cfg["models"]:
            raise ValueError(f"Unknown model selector: {name}")
        LOG.info("Training model %s on %s", name, device)
        train_one(cfg, name, cfg["models"][name], rows, device)


def score_checkpoint(path: Path, rows: list[dict], cfg: dict, device) -> tuple[dict[str, float], dict]:
    model, payload = load_classifier(path, device)
    inference_cfg = {**cfg, "data": payload["data_cfg"], "preprocessing": payload["preprocessing"]}
    transform = transform_for(inference_cfg, payload["spec"], payload["normalization"])
    loader = make_loader(rows, inference_cfg, transform, int(cfg["prediction"]["batch_size"]))
    scores = predict_logits(model, loader, device, cfg["runtime"]["amp"])
    del model
    gc.collect()
    if device.type == "cuda":
        torch.cuda.empty_cache()
    return scores, {k: payload[k] for k in ("name", "spec", "task", "dataset_signature", "training_signature", "normalization")}
