"use strict";
// Actual local servers and native browser gestures. Images/curves are synthetic.
const fs=require("node:fs"),path=require("node:path"),os=require("node:os"),assert=require("node:assert/strict");
const {spawn}=require("node:child_process");
const {chromium}=require("playwright");
const repo=path.resolve(__dirname,".."),root=fs.mkdtempSync(path.join(os.tmpdir(),"cv-viewer-browser-"));
const evidence=path.resolve(process.argv[2]||path.join(root,"evidence"));fs.mkdirSync(evidence,{recursive:true});
let worker,browser,page,log="";
const fixture=String.raw`
import json,sys,threading,time
from pathlib import Path
import numpy as np, cv2
from PIL import Image
from nilt.dashboard import Dashboard, make_handler
from http.server import ThreadingHTTPServer
from nilt.review import initialize_session, append_prediction, finish_session
from topseg.common import load_config
from topseg.project import Project
from topseg.server import make_server
root=Path(sys.argv[1]);config=root/'project.yaml'
config.write_text('paths:\n  output_root: ./results\n  classification_output_root: ./classified\ntasks:\n  vig:\n    dataset_root: ./data\n')
session=root/'classified/session1';initialize_session(session,metadata={'task':'vig'},total=1)
image=session/'predicted/good/native16.png';image.parent.mkdir(parents=True)
array=np.repeat(np.arange(1001,1201,dtype=np.uint16)[None,:],120,axis=0)
ok,encoded=cv2.imencode('.png',array);assert ok;image.write_bytes(encoded.tobytes())
append_prediction(session,{'relative_path':'native16.png','reference_label':'good','prediction':'good','score':.2,'copied_path':'predicted/good/native16.png'})
finish_session(session)
sources=root/'annotation_sources';sources.mkdir();Image.new('RGB',(200,120),(90,90,90)).save(sources/'unit.png')
segcfg=root/'seg.yaml';segcfg.write_text('input_dir: annotation_sources\nproject_dir: annotations\noutput_dir: segmentation_results\n')
cfg=load_config(segcfg);project=Project(cfg);project.import_images()
app=Dashboard(config);server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(app));annotation=make_server(cfg)
for s in (server,annotation):threading.Thread(target=s.serve_forever,daemon=True).start()
print(json.dumps({'dashboard':server.server_port,'annotation':annotation.server_port,'session':str(session)}),flush=True)
while True:time.sleep(1)
`;
async function main(){
  worker=spawn(process.env.STUDIO_PYTHON||"python",["-u","-c",fixture,root],{cwd:repo,stdio:["ignore","pipe","pipe"]});
  const ports=await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(Error(log)),20000);worker.stdout.on("data",chunk=>{log+=chunk;const line=log.split("\n").find(line=>line.startsWith('{"dashboard"'));if(line){clearTimeout(timeout);resolve(JSON.parse(line));}});worker.stderr.on("data",chunk=>log+=chunk);worker.once("exit",code=>{clearTimeout(timeout);reject(Error("Server exited "+code+": "+log));});});
  browser=await chromium.launch({headless:true,args:["--no-sandbox"],...(process.env.STUDIO_BROWSER_EXECUTABLE?{executablePath:process.env.STUDIO_BROWSER_EXECUTABLE}:{})});
  page=await browser.newPage({viewport:{width:1536,height:1000}});
  const errors=[];page.on("pageerror",error=>errors.push(error.message));
  await page.goto(`http://127.0.0.1:${ports.dashboard}`);
  await page.waitForFunction(()=>document.querySelector('#connection')?.textContent.includes('Connected'));
  await page.locator('#nav-review').click();await page.locator('#review-session').selectOption(ports.session);
  await page.locator('[data-review-index="0"]').click();
  await page.waitForFunction(()=>document.querySelector('#image-dialog [data-viewer=levels]').textContent.includes('16-bit'));
  assert.match(await page.locator('#image-dialog [data-viewer=levels]').innerText(),/min 1001 · max 1200/);
  const imageControls=page.locator('#image-dialog .viewer-controls');
  await imageControls.locator('[data-viewer=low-mode]').selectOption('min');
  await imageControls.locator('[data-viewer=normalize]').check();
  await page.waitForFunction(()=>document.querySelector('#image-large').src.includes('window=1')&&document.querySelector('#image-large').complete);
  const url=await page.locator('#image-large').getAttribute('src');
  const pixel=await page.evaluate(async url=>{const bitmap=await createImageBitmap(await(await fetch(url)).blob());const c=document.createElement('canvas');c.width=bitmap.width;c.height=bitmap.height;const x=c.getContext('2d');x.drawImage(bitmap,0,0);return [x.getImageData(0,0,1,1).data[0],x.getImageData(199,0,1,1).data[0]];},url);
  // Allow one display level in browser canvas readback; Python tests assert exact encoded pixels.
  const previewResponse=await page.request.get(new URL(url,page.url()).href);fs.writeFileSync(path.join(evidence,"SYNTHETIC-normalized.png"),await previewResponse.body());assert(pixel[0]<=1 && pixel[1]>=254,JSON.stringify({url,pixel}));
  await imageControls.locator('[data-viewer=low-mode]').selectOption('custom');await imageControls.locator('[data-viewer=low]').fill('1100');
  await imageControls.locator('[data-viewer=high-mode]').selectOption('custom');await imageControls.locator('[data-viewer=high]').fill('1150');
  await imageControls.locator('[data-viewer=apply]').click();
  await page.waitForFunction(()=>document.querySelector('#image-large').src.includes('black=1100')&&document.querySelector('#image-large').src.includes('white=1150'));
  await imageControls.locator('[data-viewer=high]').fill('1000');await imageControls.locator('[data-viewer=apply]').click();
  assert.match(await imageControls.locator('[data-viewer=levels]').innerText(),/lower < upper/);
  await imageControls.locator('[data-viewer=reset]').click();
  await imageControls.locator('[data-viewer=low-mode]').selectOption('min');await imageControls.locator('[data-viewer=normalize]').check();
  await imageControls.locator('[data-viewer=fullscreen]').click();
  await page.waitForFunction(()=>document.fullscreenElement?.id==='image-dialog'||document.querySelector('#image-dialog').classList.contains('viewer-expanded'));
  await page.locator('#image-fit').click();
  const geometry=await page.evaluate(()=>{const v=document.querySelector('#image-viewport').getBoundingClientRect(),i=document.querySelector('#image-large').getBoundingClientRect();return {vh:v.height,vw:v.width,ih:i.height,iw:i.width,side:getComputedStyle(document.querySelector('.image-detail-panel')).display};});
  assert(geometry.vh>650,JSON.stringify(geometry));assert.equal(geometry.side,'none');
  assert(Math.abs(geometry.ih-geometry.vh)<2||Math.abs(geometry.iw-geometry.vw)<2,JSON.stringify(geometry));
  await page.screenshot({path:path.join(evidence,'SYNTHETIC-fullscreen.png')});
  await page.locator('#image-native').click();assert.equal(await page.locator('#image-large').evaluate(el=>el.style.width),'200px');
  await imageControls.locator('[data-viewer=in]').click();assert.equal(await page.locator('#image-large').evaluate(el=>el.style.width),'250px');
  const viewport=await page.locator('#image-viewport').boundingBox(),before=await page.locator('#image-large').evaluate(el=>parseFloat(el.style.left));
  await page.mouse.move(viewport.x+viewport.width/2,viewport.y+viewport.height/2);await page.mouse.down({button:'right'});await page.mouse.move(viewport.x+viewport.width/2+80,viewport.y+viewport.height/2+40);await page.mouse.up({button:'right'});
  assert.equal(await page.locator('#image-large').evaluate(el=>parseFloat(el.style.left)),before+80);
  await imageControls.locator('[data-viewer=fullscreen]').click();await page.locator('#image-close').click();
  await page.locator('#nav-search').click();
  await page.evaluate(()=>{window.testCurves=[{name:'Train loss',color:'#1682dc',points:[[1,.9],[2,.7],[3,.5]]},{name:'Validation loss',color:'#e49b40',points:[[1,.7],[2,.8],[3,.9]]}];plot('loss-chart',window.testCurves);});
  await page.locator('#loss-chart').scrollIntoViewIfNeeded();
  const point=await page.locator('#loss-chart').evaluate(svg=>{const p=svg.querySelector('polyline').points.getItem(1),q=svg.createSVGPoint();q.x=p.x;q.y=p.y;const screen=q.matrixTransform(svg.getScreenCTM());return {x:screen.x,y:screen.y};});
  await page.mouse.move(point.x,point.y);await page.locator('.chart-value-tooltip').waitFor({state:'visible'});
  assert.match(await page.locator('.chart-value-tooltip').innerText(),/Train loss\nEpoch: 2\nValue: 0.7/);
  await page.mouse.click(point.x,point.y);
  assert.equal(await page.locator('#loss-chart .chart-selected').getAttribute('data-chart-series'),'Train loss');
  assert.equal(await page.locator('#loss-chart').evaluate(svg=>svg.lastElementChild.dataset.chartSeries),'Train loss');
  await page.evaluate(()=>plot('loss-chart',window.testCurves));
  assert.equal(await page.locator('#loss-chart .chart-selected').getAttribute('data-chart-series'),'Train loss');
  await page.screenshot({path:path.join(evidence,'SYNTHETIC-chart-selection.png')});
  await page.goto(`http://127.0.0.1:${ports.annotation}`);
  await page.waitForFunction(()=>document.querySelector('#image-canvas').width===200&&document.querySelector('#image-name').textContent.includes('unit.png'));
  const canvas=await page.locator('#image-canvas').boundingBox(),transform=await page.locator('#canvas-wrap').getAttribute('style');
  const objectCount=await page.locator('#object-count').innerText();
  await page.mouse.move(canvas.x+canvas.width/2,canvas.y+canvas.height/2);await page.mouse.down({button:'right'});await page.mouse.move(canvas.x+canvas.width/2+65,canvas.y+canvas.height/2+35);await page.mouse.up({button:'right'});
  assert.notEqual(await page.locator('#canvas-wrap').getAttribute('style'),transform);
  assert.equal(await page.locator('#object-count').innerText(),objectCount);
  // The next ordinary brush gesture still creates an annotation.
  const moved=await page.locator('#image-canvas').boundingBox();await page.mouse.move(moved.x+moved.width/2,moved.y+moved.height/2);await page.mouse.down();await page.mouse.move(moved.x+moved.width/2+30,moved.y+moved.height/2+10);await page.mouse.up();
  assert.notEqual(await page.locator('#object-count').innerText(),objectCount);
  const annotationControls=page.locator('.editor-panel .viewer-controls');
  await page.waitForFunction(()=>document.querySelector('.editor-panel [data-viewer=levels]').textContent.includes('8-bit'));
  const maskBefore=await page.locator('#mask-canvas').evaluate(canvas=>canvas.toDataURL());
  const viewBefore=await page.locator('#canvas-wrap').getAttribute('style');
  await annotationControls.locator('[data-viewer=low-mode]').selectOption('min');
  await annotationControls.locator('[data-viewer=normalize]').check();
  await page.waitForFunction(()=>{const x=document.querySelector('#image-canvas').getContext('2d');return x.getImageData(0,0,1,1).data[0]===0;});
  assert.equal(await page.locator('#mask-canvas').evaluate(canvas=>canvas.toDataURL()),maskBefore);
  assert.equal(await page.locator('#canvas-wrap').getAttribute('style'),viewBefore);
  await annotationControls.locator('[data-viewer=fullscreen]').click();
  await page.waitForFunction(()=>document.fullscreenElement?.classList.contains('editor-panel')||document.querySelector('.editor-panel').classList.contains('viewer-expanded'));
  await page.screenshot({path:path.join(evidence,'SYNTHETIC-annotation-display.png')});
  await annotationControls.locator('[data-viewer=fullscreen]').click();
  assert.deepEqual(errors,[]);
  console.log('PASS: native 16-bit display levels, custom limits, fullscreen fit, zoom, right-drag image pan, curve hover values and persistent foreground selection, annotation right-drag without mask edits, subsequent brush gesture, shared annotation brightness/fullscreen preserving masks and view.');
}
main().catch(async error=>{console.error(error);if(page)await page.screenshot({path:path.join(evidence,'SYNTHETIC-failure.png')}).catch(()=>{});process.exitCode=1;}).finally(async()=>{if(browser)await browser.close();if(worker)worker.kill();fs.writeFileSync(path.join(evidence,'server.log'),log);fs.rmSync(root,{recursive:true,force:true});});
