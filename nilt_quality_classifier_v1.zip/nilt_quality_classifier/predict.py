from __future__ import annotations

import argparse
import multiprocessing as mp

from qc.config import load_yaml
from qc.inference import run_folder_prediction


def main() -> None:
    parser = argparse.ArgumentParser(description="Predict GOOD/BAD for a new image folder.")
    parser.add_argument("--config", required=True, help="Path to a prediction YAML file")
    args = parser.parse_args()
    result = run_folder_prediction(load_yaml(args.config))
    print(f"\nPredictions: {result['output_folder']}/predictions.csv")


if __name__ == "__main__":
    mp.freeze_support()
    main()
