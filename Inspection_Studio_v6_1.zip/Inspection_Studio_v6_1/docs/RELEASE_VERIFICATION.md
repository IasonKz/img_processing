# Release verification — Inspection Studio 6.1.0

Verification date: 28 September 2026.

## Executed checks

Environment: Linux, Python 3.12.14, PyTorch 2.7.1+cpu, torchvision 0.22.1+cpu,
Optuna 4.5.0, Node.js and Firefox. No physical Windows GPU was available.

| Check | Result |
| --- | --- |
| Local Python regression subset | 467 tests run; 466 passed; 1 Windows-specific file-lock test skipped; no failures. Native ONNX test modules were excluded. |
| Final v6.1 focused suite | 72 passed: profiles, public-weight provisioning, training-loss device probes, quality aggregation, reports and HTTP integration. This overlaps the broader subset. |
| Additional DirectML probe checks | 5 fault-injection tests and 4 existing routing tests passed using CPU mocks. |
| JavaScript behavior harnesses | 6 passed: existing interface, custom search, analytics, radars, review metrics and quality reporting. |
| Firefox interface checks | Desktop and 1024-pixel laptop layouts passed without page errors or horizontal overflow. |
| Real quality-report API workflow | On-disk synthetic evidence: 24 image records, 4 session/tray records, 12 matched inputs and 1 disagreement; HTML plus all exported files downloaded successfully. No API-response interception. |
| Standalone HTML | Offline vector charts, escaping, CSV formula safety, exact dataset membership and separate recorded test evidence checked. |
| Public weights | Official URL restrictions, redirects, checksum verification, offline opt-out, cancellation and atomic publication tested with mocked downloads. No claim of a live workstation download. |
| CPU training and native 16-bit | Existing training, checkpoint, native decoding, preparation and image-identity regressions passed in the local subset. |
| Windows Intel GPU / NVIDIA CUDA | Configuration and failure routes checked; actual hardware execution remains a destination-machine test. |

Browser records and model scores were synthetic fixtures, not production model
measurements. The real-API browser check validates integration and arithmetic,
not defect-detection quality. The installer performs an actual device probe on
the destination Windows machine; it was not executed on an Intel GPU here.

Current logs: `validation/v61_local_regression.txt`,
`validation/v61_focused_tests.txt`, `validation/v61_interface_tests.txt`, and
`validation/SYNTHETIC-e2e-verification.json`. The older files in `validation/`
and [RELEASE_VERIFICATION_V6.md](RELEASE_VERIFICATION_V6.md) document v6.0 only;
they do not establish a fresh full-suite pass for v6.1.

## Incomplete full-suite check

An attempted full discovery run was interrupted by the execution review after
an unexpected external Microsoft telemetry request. Its payload and source were
not established. The blocked operation was not retried or bypassed. The local
regression subset above excludes `test_deployment` and `test_v3_decisions`, the
modules that execute native ONNX Runtime exports, and does not claim that the
complete ONNX export path was revalidated for this release.

The application requests ONNX Runtime's telemetry opt-out before constructing
inference sessions. This is not an audit of every dependency or a guarantee of
system-wide network isolation. The optional DirectML package separately
discloses vendor diagnostics; see [IGPU_V61.md](IGPU_V61.md). Review company IT
policy before enabling an optional backend or repeating tests with third-party
diagnostic egress.

## Practical limits

- Windows launchers, native file locking and process behavior require a destination-machine check. Linux results do not establish them.
- The separate DirectML installer performs a real forward/backward probe on the selected Windows adapter. A successful probe still does not qualify all architectures, image sizes or driver versions.
- CUDA/DirectML throughput, memory capacity and numerical behavior require target-hardware measurements.
- Uncertainty routing is a configurable heuristic; review cases remain abstentions. Conditional accuracy must be read alongside coverage and review workload.
- An unfinished checkpoint is diagnostic and is not promoted to a fully evaluated model. A forced kill can only retain already committed files.
- No production images were available for this release check. Defect detection quality, crop/alignment acceptance and operating thresholds require representative labelled images and a reserved final test.

## Repeat checks

PowerShell, from the extracted project folder:

```powershell
$StudioPython = (Get-Content .studio-python.txt -Raw).Trim()
& $StudioPython -m unittest discover -s tests -p 'test_v61*.py'
```

Linux:

```bash
.venv-studio6/bin/python -m unittest discover -s tests -p 'test_v61*.py'
```

Optional interface checks with Node.js:

```bash
node tests/test_v4_ui.cjs
node tests/test_v5_ui.cjs
node tests/test_v5_analytics.cjs
node tests/test_v6_radars.cjs
node tests/test_v6_review_metrics.cjs
node tests/test_v61_quality_ui.cjs
```

`tests/browser_v61_quality.cjs` and `tests/browser_v61_quality_e2e.cjs` require
Playwright and Firefox for development verification. Node.js and Playwright are
not runtime requirements for operators. A full `test_*.py` run also exercises
optional deployment dependencies; it is not equivalent to the focused command
above.
