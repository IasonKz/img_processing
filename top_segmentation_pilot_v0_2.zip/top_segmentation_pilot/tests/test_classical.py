"""Classical proposal behavior on controlled synthetic inputs."""
import unittest
import numpy as np
from topseg.classical import suggest, validate_roi

class ProposalTests(unittest.TestCase):
    def test_uniform_image_does_not_force_defects(self):
        mask, stats = suggest(np.full((100, 120, 3), 100, dtype=np.uint8))
        self.assertEqual(mask.shape, (100, 120))
        self.assertFalse(mask.any())
        self.assertTrue(stats['low_contrast'])
        self.assertTrue(stats['review_required'])
    def test_bright_and_dark_defects_get_region_specific_labels(self):
        image = np.full((160, 160, 3), 128, dtype=np.uint8)
        image[76:82, 76:82] = 235
        image[22:28, 22:28] = 15
        mask, _ = suggest(image, {'cx': 80, 'cy': 80, 'rx': 40, 'ry': 40}, {'min_area': 3})
        self.assertEqual(mask[79, 79], 1)
        self.assertEqual(mask[25, 25], 2)
        yy, xx = np.mgrid[:160, :160]
        inner = ((xx + .5 - 80) / 40) ** 2 + ((yy + .5 - 80) / 40) ** 2 <= 1
        self.assertFalse(np.any((mask == 1) & ~inner))
        self.assertFalse(np.any((mask == 2) & inner))
    def test_polarity_changes_proposed_defect_center(self):
        image = np.full((100, 100, 3), 128, dtype=np.uint8)
        image[47:53, 47:53] = 240
        bright, _ = suggest(image, settings={'polarity': 'bright'})
        dark, _ = suggest(image, settings={'polarity': 'dark'})
        self.assertEqual(bright[50, 50], 1)
        self.assertEqual(dark[50, 50], 0)
    def test_nonfinite_and_degenerate_rois_rejected(self):
        for roi in ({'cx': float('nan'), 'cy': 5, 'rx': 3, 'ry': 3}, {'cx': 5, 'cy': 5, 'rx': 0, 'ry': 3}):
            with self.assertRaises(ValueError):
                validate_roi(roi, 10, 10)

if __name__ == '__main__':
    unittest.main()
