"""CPU-only reference and fault-injection tests; DirectML is never imported."""
import unittest
from unittest.mock import Mock, patch

import torch

from nilt import devices


class DirectMLTrainingProbeTests(unittest.TestCase):
    def test_weighted_loss_cpu_mock_passes_without_changing_rng(self):
        before = torch.get_rng_state().clone()
        with patch("nilt.devices.importlib.import_module", side_effect=AssertionError("No DirectML imports")):
            with torch.no_grad():
                devices._training_parity_probe(torch, torch.device("cpu"))
        self.assertTrue(torch.equal(before, torch.get_rng_state()))

    def fault_criterion(self, transform):
        original = torch.nn.CrossEntropyLoss
        calls = []

        def factory(*args, **kwargs):
            calls.append(kwargs)
            criterion = original(*args, **kwargs)
            if len(calls) == 1:
                return criterion
            return lambda logits, labels: transform(criterion(logits, labels))

        return calls, factory

    def test_device_loss_mismatch_is_rejected(self):
        calls, factory = self.fault_criterion(lambda loss: loss + 1.)
        with patch.object(torch.nn, "CrossEntropyLoss", side_effect=factory):
            with self.assertRaisesRegex(RuntimeError, "loss differs from the CPU reference"):
                devices._training_parity_probe(torch, torch.device("cpu"))
        self.assertEqual(len(calls), 2)
        self.assertTrue(all(c["reduction"] == "sum" for c in calls))
        self.assertTrue(all(torch.equal(c["weight"].cpu(), torch.tensor([1.5, .75])) for c in calls))

    def test_zero_device_gradients_are_rejected(self):
        _, factory = self.fault_criterion(lambda loss: loss * 0. + loss.detach())
        with patch.object(torch.nn, "CrossEntropyLoss", side_effect=factory):
            with self.assertRaisesRegex(RuntimeError, "zero weight gradient"):
                devices._training_parity_probe(torch, torch.device("cpu"))

    def test_nonfinite_device_loss_is_rejected(self):
        _, factory = self.fault_criterion(lambda loss: loss * float("nan"))
        with patch.object(torch.nn, "CrossEntropyLoss", side_effect=factory):
            with self.assertRaisesRegex(RuntimeError, "nonfinite loss"):
                devices._training_parity_probe(torch, torch.device("cpu"))

    def test_gradient_mismatch_stops_routing_instead_of_silent_cpu_fallback(self):
        _, factory = self.fault_criterion(lambda loss: loss * 2. - loss.detach())
        dml = Mock()
        dml.device.return_value = torch.device("cpu")  # Simulated adapter, not a backend fallback.
        adapters = [{"index": 0, "name": "Mock Intel Graphics", "device": "directml:0"}]
        with patch.object(torch.nn, "CrossEntropyLoss", side_effect=factory), \
             patch("nilt.devices.directml_devices", return_value=(dml, adapters)), \
             patch("nilt.devices.importlib.import_module", side_effect=AssertionError("No DirectML imports")):
            with self.assertRaisesRegex(RuntimeError, "weight gradient differs.*has not switched to CPU"):
                devices.resolve_directml("directml:0", torch)
        dml.device.assert_called_once_with(0)


if __name__ == "__main__":
    unittest.main()
