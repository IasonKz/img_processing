"""The budget is enforced outside the training process, including stuck work."""
from pathlib import Path
import os
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

from nilt.common import read_json, write_json
from nilt.control import PROFILE_CAPS, recover_lock, supervise_search


class SupervisorTests(unittest.TestCase):
    def test_profile_caps_and_reject_excess_before_process(self):
        self.assertEqual(PROFILE_CAPS, {"laptop": 7200, "workstation": 21600, "workstation_large": 43200})
        with patch("nilt.control.subprocess.Popen", side_effect=AssertionError("must not start")):
            with self.assertRaisesRegex(ValueError, "at most 2"):
                supervise_search(cfg={"profile": "laptop"}, hours=3)

    def test_real_uncooperative_child_is_killed_at_deadline(self):
        actual_popen = subprocess.Popen
        children = []
        def blocked(*args, **kwargs):
            process = actual_popen([sys.executable, "-c", "import time; time.sleep(30)"])
            children.append(process)
            return process
        with tempfile.TemporaryDirectory() as tmp:
            cfg = {"profile": "laptop", "output_root": tmp, "search": {"total_budget_seconds": .3}}
            started = time.monotonic()
            with patch("nilt.control.subprocess.Popen", side_effect=blocked):
                code = supervise_search(cfg=cfg)
            self.assertEqual(code, 4)
            self.assertLess(time.monotonic() - started, 4)
            self.assertIsNotNone(children[0].poll())
            session = read_json(next((Path(tmp) / "_sessions").glob("*.json")))
            self.assertAlmostEqual(session["deadline"] - session["session_started_at"], .3, places=4)

    def test_live_run_lock_cannot_be_recovered(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "operation.lock"
            write_json(path, {"pid": os.getpid()})
            with self.assertRaisesRegex(RuntimeError, "still exists"):
                recover_lock(tmp)
            self.assertTrue(path.exists())

    def test_resume_does_not_reset_consumed_budget(self):
        with tempfile.TemporaryDirectory() as tmp:
            run = Path(tmp)
            cfg = {"profile": "laptop", "output_root": tmp, "search": {"total_budget_seconds": 7200}}
            write_json(run / "budget.json", {"total_budget_seconds": 60, "consumed_seconds": 60, "session_active": False})
            with patch("nilt.workflow.open_run", return_value=(cfg, [])), patch("nilt.control.subprocess.Popen", side_effect=AssertionError("must not start")):
                with self.assertRaisesRegex(ValueError, "exhausted"):
                    supervise_search(run=run)


if __name__ == "__main__":
    unittest.main()
