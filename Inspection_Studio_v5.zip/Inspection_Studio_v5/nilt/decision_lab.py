"""Held-out decision development: triage, score fusion, stacking and cascades.

Preview and tuning never evaluate final-test data. Final testing is a separate,
explicit operation on a frozen recipe. Fitted coefficients are JSON, not pickles.
Development results never qualify a production release. A recipe is frozen
before its separate selection report is computed.
"""
from __future__ import annotations

from copy import deepcopy
from contextlib import ExitStack
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import shutil
import time

import numpy as np

from .common import read_json, run_lock, safe_relative, sha_file, write_csv, write_json
from .decisions import UNQUALIFIED, _audit_inputs, _candidate, _new_folder, _validate_candidate
from .inspection_flow import _reference, _resolve_reference, _source_overlap
from .runtime import safe_asset

FORMAT = "decision_system_v5"
KINDS = ("triage", "weighted", "stacking", "cascade")
CLASSES = ("good", "review", "bad")


def _number(value, name, lo=None, hi=None, integer=False):
    if isinstance(value, (bool, str)) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(name + " must be a finite number.")
    if integer and int(value) != value:
        raise ValueError(name + " must be an integer.")
    if (lo is not None and value < lo) or (hi is not None and value > hi):
        raise ValueError(name + " is outside its allowed range.")
    return int(value) if integer else float(value)


def _pair(value, name="thresholds"):
    if not isinstance(value, dict) or set(value) != {"good", "bad"}:
        raise ValueError(name + " must contain good and bad thresholds.")
    low, high = (_number(value[key], name + "." + key) for key in ("good", "bad"))
    if low > high:
        raise ValueError("The good threshold must not exceed the bad threshold.")
    return {"good": low, "bad": high}


def normalize_definition(definition):
    allowed = {"name", "kind", "sources", "thresholds", "weights", "calibrate_scores", "stacking_c",
               "fit_fraction", "seed", "stages", "tuning"}
    if not isinstance(definition, dict) or set(definition) - allowed:
        raise ValueError("Unsupported decision definition fields.")
    d = deepcopy(definition)
    d.setdefault("name", "Inspection decision system")
    if not isinstance(d["name"], str) or not d["name"].strip() or len(d["name"]) > 160:
        raise ValueError("A system needs a name of 1 to 160 characters.")
    if d.get("kind") not in KINDS:
        raise ValueError("Choose triage, weighted, stacking or cascade.")
    sources = d.get("sources")
    if not isinstance(sources, list) or not 1 <= len(sources) <= 16:
        raise ValueError("Choose 1 to 16 candidate sources.")
    for source in sources:
        if not isinstance(source, dict) or set(source) - {"run", "candidate"} or not source.get("run"):
            raise ValueError("Every source needs run and candidate fields.")
        source["run"] = str(Path(source["run"]).resolve())
        source.setdefault("candidate", "selected")
    if d["kind"] == "triage" and len(sources) != 1:
        raise ValueError("Triage uses one source. Choose weighted or stacking for multiple sources.")
    d["thresholds"] = _pair(d.get("thresholds", {"good": .2, "bad": .8}))
    d["calibrate_scores"] = d.get("calibrate_scores", False)
    if not isinstance(d["calibrate_scores"], bool):
        raise ValueError("calibrate_scores must be true or false.")
    d["stacking_c"] = _number(d.get("stacking_c", 1.), "stacking_c", 1e-6, 1e6)
    d["fit_fraction"] = _number(d.get("fit_fraction", .5), "fit_fraction", .1, .9)
    d["seed"] = _number(d.get("seed", 42), "seed", 0, 2**32 - 1, True)
    weights = d.get("weights", [1.] * len(sources))
    if not isinstance(weights, list) or len(weights) != len(sources):
        raise ValueError("Supply one weight per source.")
    weights = [_number(w, "weight", 0) for w in weights]
    if not sum(weights) > 0:
        raise ValueError("At least one weight must be positive.")
    d["weights"] = (np.array(weights) / sum(weights)).tolist()
    d.setdefault("stages", [])
    if d["kind"] == "cascade":
        if not isinstance(d["stages"], list) or not 1 <= len(d["stages"]) <= 16:
            raise ValueError("A cascade needs 1 to 16 ordered stages.")
        for i, stage in enumerate(d["stages"]):
            if not isinstance(stage, dict) or set(stage) - {"source", "name", "good", "bad", "accept", "reject"}:
                raise ValueError("Unsupported cascade stage fields.")
            stage["source"] = _number(stage.get("source"), "stage source", 0, len(sources) - 1, True)
            stage.update(_pair({key: stage.get(key) for key in ("good", "bad")}, "stage thresholds"))
            stage.setdefault("name", f"Stage {i + 1}")
            if not isinstance(stage["name"], str) or not stage["name"] or len(stage["name"]) > 160:
                raise ValueError("Stage name must be 1 to 160 characters.")
            for key in ("accept", "reject"):
                stage.setdefault(key, True)
                if not isinstance(stage[key], bool):
                    raise ValueError("Stage accept/reject controls must be booleans.")
        if len({s["source"] for s in d["stages"]}) != len(d["stages"]):
            raise ValueError("Use each source once in a cascade.")
    tuning = d.setdefault("tuning", {})
    if not isinstance(tuning, dict) or set(tuning) - {"method", "n_trials", "timeout_seconds", "sampler",
            "max_bad_escape_rate", "max_good_reject_rate", "max_review_rate", "search_weights",
            "bad_cost", "reject_cost", "review_cost", "good_range", "bad_range"}:
        raise ValueError("Unsupported decision tuning fields.")
    defaults = {"method": "manual", "n_trials": 50, "timeout_seconds": 60., "sampler": "tpe",
                "max_bad_escape_rate": .01, "max_good_reject_rate": .2, "max_review_rate": 1.,
                "search_weights": False, "bad_cost": 100., "reject_cost": 1., "review_cost": .2}
    for key, value in defaults.items():
        tuning.setdefault(key, value)
    if tuning["method"] not in ("manual", "sweep", "optuna") or tuning["sampler"] not in ("tpe", "random"):
        raise ValueError("Tuning supports manual, sweep or optuna with tpe/random sampling.")
    for key in ("max_bad_escape_rate", "max_good_reject_rate", "max_review_rate"):
        tuning[key] = _number(tuning[key], key, 0, 1)
    for key in ("bad_cost", "reject_cost", "review_cost"):
        tuning[key] = _number(tuning[key], key, 0, 1e9)
    tuning["n_trials"] = _number(tuning["n_trials"], "n_trials", 1, integer=True)
    tuning["timeout_seconds"] = _number(tuning["timeout_seconds"], "timeout_seconds", 1e-6)
    if not isinstance(tuning["search_weights"], bool):
        raise ValueError("search_weights must be a boolean.")
    if tuning["search_weights"] and (d["kind"] != "weighted" or tuning["method"] != "optuna"):
        raise ValueError("Weight search requires a weighted system and Optuna tuning.")
    if d["kind"] == "cascade" and tuning["method"] == "sweep":
        raise ValueError("Use manual or optuna tuning for a cascade.")
    for key in ("good_range", "bad_range"):
        if key in tuning:
            values = tuning[key]
            if not isinstance(values, list) or len(values) != 2:
                raise ValueError(key + " must be [minimum, maximum].")
            tuning[key] = [_number(v, key) for v in values]
            if values[0] > values[1]:
                raise ValueError(key + " minimum exceeds maximum.")
    if (tuning["method"] != "manual" and "good_range" in tuning and "bad_range" in tuning
            and tuning["good_range"][0] > tuning["bad_range"][1]):
        raise ValueError("The requested threshold ranges cannot satisfy good <= bad.")
    return d


def _load_sources(d):
    from .workflow import open_run
    from .data import _validate_manifest
    sources, manifest, identity, seen = [], None, None, set()
    for spec in d["sources"]:
        run = Path(spec["run"]).resolve()
        cfg, rows = open_run(run)
        _validate_manifest(rows, require_all=False)
        fingerprint = sha_file(run / "manifest.csv")
        if identity is not None and fingerprint != identity:
            raise ValueError("Decision sources must use exactly the same audited manifest and split assignments.")
        chosen = _candidate(run, spec["candidate"])
        kind = _validate_candidate(run, chosen)
        model_key = tuple(sorted(member["sha256"] for member in chosen["members"]))
        if model_key in seen:
            raise ValueError("The same model cannot be counted twice in one system.")
        seen.add(model_key)
        if sources and cfg["task"] != sources[0]["cfg"]["task"]:
            raise ValueError("All sources must use the same inspection task.")
        sources.append({"run": run, "cfg": cfg, "chosen": chosen, "kind": kind})
        identity, manifest = fingerprint, rows
    if d["kind"] == "weighted" and not d["calibrate_scores"] and any(s["kind"] != "supervised" for s in sources):
        raise ValueError("Mixed anomaly/probability averaging requires fit-only score calibration.")
    return sources, manifest


def _scores(source, manifest, split):
    if split not in ("threshold", "selection"):
        raise ValueError("Decision Lab cannot read final-test scores.")
    run, chosen = source["run"], source["chosen"]
    folder = safe_relative(run, "scores/" + chosen["name"])
    path = safe_asset(folder, split + ".npy")
    provenance = read_json(safe_asset(folder, "provenance.json"))
    digest = sha_file(path)
    if (provenance.get("candidate") != chosen["name"] or
            provenance.get("manifest_sha256") != sha_file(run / "manifest.csv") or
            provenance.get("files", {}).get(split + ".npy") != digest):
        raise ValueError("Decision score provenance mismatch: " + split)
    rows = [r for r in manifest if r["split"] == split]
    values = np.load(path, allow_pickle=False).astype(float)
    if not rows or values.shape != (len(rows),) or not np.isfinite(values).all():
        raise ValueError("Empty or invalid " + split + " scores.")
    if source["kind"] == "supervised" and np.any((values < 0) | (values > 1)):
        raise ValueError("Supervised scores must be in [0,1].")
    return values, {"relative_path": path.relative_to(run).as_posix(), "sha256": digest}


def partition_development(rows, fit_fraction=.5, seed=42):
    """Disjoint fit/tune groups, including aliases connecting physical units."""
    from sklearn.model_selection import GroupShuffleSplit
    from .data import _aliases
    parent = {}
    def find(key):
        parent.setdefault(key, key)
        if parent[key] != key:
            parent[key] = find(parent[key])
        return parent[key]
    for row in rows:
        group = find(str(row["group"]))
        for alias in _aliases(row):
            parent[find(str(alias))] = group
    groups = np.array([find(str(r["group"])) for r in rows])
    labels = np.array([int(r["label"]) for r in rows])
    if len(set(groups)) < 4:
        raise ValueError("Learned decision fitting needs at least four independent development groups and both classes in fit/tune. Add data; never split a physical unit.")
    splitter = GroupShuffleSplit(n_splits=256, train_size=fit_fraction, random_state=seed)
    valid = []
    for fit, tune in splitter.split(np.zeros(len(rows)), labels, groups):
        if len(set(labels[fit])) == len(set(labels[tune])) == 2:
            distance = abs(float(np.mean(labels[fit])) - float(np.mean(labels[tune])))
            valid.append((distance, fit, tune))
    if not valid:
        raise ValueError("Cannot form group-disjoint fit/tune subsets containing both classes. Add independent labeled groups.")
    _, fit, tune = min(valid, key=lambda item: item[0])
    return fit, tune, groups


def fit_logistic(X, labels, c=1.):
    from sklearn.linear_model import LogisticRegression
    X = np.asarray(X, dtype=float)
    y = (np.asarray(labels, dtype=int) == 0).astype(int)
    if X.ndim != 2 or len(X) != len(y) or len(set(y)) != 2 or not np.isfinite(X).all():
        raise ValueError("Logistic fitting requires finite features and both good/bad classes.")
    mean, scale = X.mean(axis=0), X.std(axis=0)
    scale[scale < 1e-12] = 1.
    model = LogisticRegression(C=c, solver="lbfgs", max_iter=2000, class_weight=None)
    model.fit((X - mean) / scale, y)
    if int(model.n_iter_[0]) >= 2000:
        raise ValueError("Logistic fitting failed to converge; check calibration data or regularization.")
    return {"type": "regularized_logistic", "mean": mean.tolist(), "scale": scale.tolist(),
            "coefficients": model.coef_[0].tolist(), "intercept": float(model.intercept_[0]), "c": c,
            "target": "bad_is_one", "fit_class_counts": {"good": int(sum(y == 0)), "bad": int(sum(y == 1))}}


def logistic_scores(X, fit):
    X = np.asarray(X, dtype=float)
    mean, scale, coef = (np.asarray(fit[key], dtype=float) for key in ("mean", "scale", "coefficients"))
    if (X.ndim != 2 or mean.shape != (X.shape[1],) or scale.shape != mean.shape or coef.shape != mean.shape
            or not np.isfinite(X).all() or not np.isfinite(mean).all() or not np.isfinite(scale).all()
            or not np.isfinite(coef).all() or np.any(scale <= 0) or not math.isfinite(fit["intercept"])):
        raise ValueError("Invalid logistic coefficients or score features.")
    z = (X - mean) / scale @ coef + fit["intercept"]
    return 1. / (1. + np.exp(-np.clip(z, -700, 700)))


def triage(scores, good, bad):
    _pair({"good": good, "bad": bad})
    scores = np.asarray(scores, dtype=float)
    if scores.ndim != 1 or not np.isfinite(scores).all():
        raise ValueError("Scores must be a finite vector.")
    # At equal thresholds this is ordinary binary classification; ties reject.
    return np.where(scores >= bad, "bad", np.where(scores < good, "good", "review"))


def triage_metrics(labels, predictions):
    labels, predictions = np.asarray(labels, dtype=int), np.asarray(predictions)
    if (labels.ndim != 1 or labels.shape != predictions.shape or not len(labels)
            or not np.isin(labels, [0, 1]).all() or not np.isin(predictions, CLASSES).all()):
        raise ValueError("Invalid labels or triage decisions.")
    nb, ng = int(sum(labels == 0)), int(sum(labels == 1))
    cells = {f"{truth}_to_{pred}": int(sum((labels == index) & (predictions == pred)))
             for truth, index in (("bad", 0), ("good", 1)) for pred in CLASSES}
    accepted = int(sum(predictions == "good"))
    automatic = int(sum(predictions != "review"))
    return {"n_images": len(labels), "n_bad": nb, "n_good": ng, **cells,
            "bad_escape_rate": cells["bad_to_good"] / nb if nb else None,
            "good_reject_rate": cells["good_to_bad"] / ng if ng else None,
            "review_rate": float(np.mean(predictions == "review")),
            "bad_review_rate": cells["bad_to_review"] / nb if nb else None,
            "good_review_rate": cells["good_to_review"] / ng if ng else None,
            "automation_rate": automatic / len(labels),
            "automatic_accuracy": (cells["good_to_good"] + cells["bad_to_bad"]) / automatic if automatic else None,
            "accepted_contamination": cells["bad_to_good"] / accepted if accepted else None,
            "qualification_status": UNQUALIFIED,
            "note": "REVIEW is abstention, not a correct prediction or verified rejection. Image-level descriptive rates; no independent qualification."}


def _transform(X, model):
    X = np.asarray(X, dtype=float)
    if model.get("calibrators"):
        return np.column_stack([logistic_scores(X[:, i:i+1], fit) for i, fit in enumerate(model["calibrators"])])
    return X


def apply_system(X, definition, model):
    """Pure score-level evaluation, also used for held-out selection reports."""
    X = np.asarray(X, dtype=float)
    if X.ndim != 2 or X.shape[1] != len(definition["sources"]) or not np.isfinite(X).all():
        raise ValueError("System score matrix has invalid shape or values.")
    transformed = _transform(X, model)
    kind = definition["kind"]
    if kind == "cascade":
        prediction = np.full(len(X), "review", dtype="U6")
        pending = np.ones(len(X), dtype=bool)
        stages = []
        for stage in definition["stages"]:
            reached = pending.copy()
            score = transformed[:, stage["source"]]
            accept = pending & (score < stage["good"]) & stage["accept"]
            reject = pending & (score >= stage["bad"]) & stage["reject"]
            prediction[accept], prediction[reject] = "good", "bad"
            pending &= ~(accept | reject)
            stages.append({"name": stage["name"], "evaluated": int(sum(reached)), "accepted": int(sum(accept)),
                           "rejected": int(sum(reject)), "deferred": int(sum(pending))})
        return prediction, None, stages
    scores = (logistic_scores(X, model["stacker"]) if kind == "stacking" else
              transformed[:, 0] if kind == "triage" else transformed @ np.asarray(definition["weights"]))
    return triage(scores, **definition["thresholds"]), scores, []


def _quality(m, tuning):
    if m["bad_escape_rate"] is None or m["good_reject_rate"] is None:
        raise ValueError("Tuning requires both classes.")
    violation = sum(max(0., m[key] - tuning["max_" + key]) for key in
                    ("bad_escape_rate", "good_reject_rate", "review_rate"))
    cost = sum(m[key] * tuning[cost] for key, cost in (("bad_escape_rate", "bad_cost"),
               ("good_reject_rate", "reject_cost"), ("review_rate", "review_cost")))
    return violation, cost, m["bad_escape_rate"], m["review_rate"]


def _threshold_values(scores):
    values = np.unique(np.asarray(scores, dtype=float))
    upper = np.nextafter(values[-1], np.inf)
    return np.r_[values, upper] if np.isfinite(upper) else values


def sweep_thresholds(labels, scores, tuning):
    """Exact empirical sweep of attainable pairs; no arbitrary threshold grid."""
    labels, scores = np.asarray(labels), np.asarray(scores, dtype=float)
    values = _threshold_values(scores)
    # Range boundaries inside a score gap are valid attainable decisions too.
    boundaries = [x for key in ("good_range", "bad_range") for x in tuning.get(key, [])]
    if boundaries:
        values = np.unique(np.r_[values, boundaries])
    order = np.argsort(scores)
    sorted_scores, sorted_labels = scores[order], labels[order]
    indices = np.searchsorted(sorted_scores, values, side="left")
    nb, ng = sum(labels == 0), sum(labels == 1)
    if not nb or not ng:
        raise ValueError("Threshold tuning requires both classes.")
    prefix_bad = np.r_[0, np.cumsum(sorted_labels == 0)]
    prefix_good = np.r_[0, np.cumsum(sorted_labels == 1)]
    best, choice, count = None, None, 0
    start = time.monotonic()
    exhausted = True
    for i, low in enumerate(values):
        if i and time.monotonic() - start >= tuning["timeout_seconds"]:
            exhausted = False
            break
        if "good_range" in tuning and not tuning["good_range"][0] <= low <= tuning["good_range"][1]:
            continue
        high_values = values[i:]
        allowed = np.ones(len(high_values), dtype=bool)
        if "bad_range" in tuning:
            allowed &= (high_values >= tuning["bad_range"][0]) & (high_values <= tuning["bad_range"][1])
        highs = np.flatnonzero(allowed) + i
        if not len(highs):
            continue
        escape = float(prefix_bad[indices[i]] / nb)
        reject = (ng - prefix_good[indices[highs]]) / ng
        review = (indices[highs] - indices[i]) / len(labels)
        violation = (max(0., escape - tuning["max_bad_escape_rate"]) +
                     np.maximum(0., reject - tuning["max_good_reject_rate"]) +
                     np.maximum(0., review - tuning["max_review_rate"]))
        cost = escape * tuning["bad_cost"] + reject * tuning["reject_cost"] + review * tuning["review_cost"]
        k = int(np.lexsort((review, cost, violation))[0])
        quality = (float(violation[k]), float(cost[k]), escape, float(review[k]))
        count += len(highs)
        if best is None or quality < best:
            best, choice = quality, {"good": float(low), "bad": float(values[highs[k]])}
    if choice is None:
        raise ValueError("No attainable threshold pair falls in the requested ranges.")
    return choice, {"method": "sweep", "evaluations": count, "complete": exhausted,
                    "elapsed_seconds": time.monotonic() - start}


def _tune(d, model, X, labels):
    tuning, details = d["tuning"], {"method": d["tuning"]["method"], "evaluations": 1}
    if tuning["method"] == "sweep":
        _, scores, _ = apply_system(X, d, model)
        d["thresholds"], details = sweep_thresholds(labels, scores, tuning)
    elif tuning["method"] == "optuna":
        import optuna
        sampler = (optuna.samplers.TPESampler(seed=d["seed"]) if tuning["sampler"] == "tpe" else
                   optuna.samplers.RandomSampler(seed=d["seed"]))
        study = optuna.create_study(direction="minimize", sampler=sampler)
        transformed = _transform(X, model)
        def propose_pair(trial, prefix, scores):
            values = _threshold_values(scores)
            low_range = tuning.get("good_range", [float(values[0]), float(values[-1])])
            high_range = tuning.get("bad_range", [float(values[0]), float(values[-1])])
            # Fixed distributions avoid dynamic categorical search-space errors.
            low = trial.suggest_float(prefix + "good", *low_range)
            high = trial.suggest_float(prefix + "bad", *high_range)
            return {"good": low, "bad": high}
        best_definition, best_quality = deepcopy(d), None
        def objective(trial):
            nonlocal best_definition, best_quality
            proposal = deepcopy(d)
            if tuning["search_weights"]:
                weights = np.array([trial.suggest_float(f"weight_{i}", 1e-4, 1., log=True) for i in range(X.shape[1])])
                proposal["weights"] = (weights / sum(weights)).tolist()
            if d["kind"] == "cascade":
                for i, stage in enumerate(proposal["stages"]):
                    stage.update(propose_pair(trial, f"stage_{i}_", transformed[:, stage["source"]]))
                valid = all(s["good"] <= s["bad"] for s in proposal["stages"])
            else:
                _, score, _ = apply_system(X, proposal, model)
                proposal["thresholds"] = propose_pair(trial, "", score)
                valid = proposal["thresholds"]["good"] <= proposal["thresholds"]["bad"]
            if not valid:
                raise optuna.TrialPruned("good threshold exceeds bad threshold")
            prediction, _, _ = apply_system(X, proposal, model)
            quality = _quality(triage_metrics(labels, prediction), tuning)
            if best_quality is None or quality < best_quality:
                best_definition, best_quality = proposal, quality
            return quality[0] * (1 + sum(tuning[key] for key in ("bad_cost", "reject_cost", "review_cost"))) + quality[1]
        # An existing rule outside user-specified bounds cannot win the search.
        pairs = d["stages"] if d["kind"] == "cascade" else [d["thresholds"]]
        baseline_allowed = all(tuning.get(key + "_range", [-math.inf, math.inf])[0] <= pair[key] <=
                               tuning.get(key + "_range", [-math.inf, math.inf])[1]
                               for pair in pairs for key in ("good", "bad"))
        if baseline_allowed:
            baseline, _, _ = apply_system(X, d, model)
            best_quality = _quality(triage_metrics(labels, baseline), tuning)
        study.optimize(objective, n_trials=tuning["n_trials"], timeout=tuning["timeout_seconds"], show_progress_bar=False)
        if best_quality is None:
            raise ValueError("No valid threshold proposal completed within the requested bounds/budget.")
        d = best_definition
        details = {"method": "optuna", "sampler": tuning["sampler"], "evaluations": len(study.trials) + int(baseline_allowed),
                   "baseline_evaluated": baseline_allowed,
                   "trials": [{"number": t.number, "state": t.state.name, "value": t.value, "params": t.params}
                              for t in study.trials],
                   "note": "Timeout checked between fast cached-score trials; not a hard process deadline."}
    prediction, _, stages = apply_system(X, d, model)
    metrics = triage_metrics(labels, prediction)
    details.update(targets_feasible=_quality(metrics, tuning)[0] <= 1e-12,
                   source="threshold/tune only", stage_counts=stages)
    return d, metrics, details


def _prepare(definition):
    d = normalize_definition(definition)
    sources, manifest = _load_sources(d)
    rows = [r for r in manifest if r["split"] == "threshold"]
    columns, provenance = zip(*[_scores(s, manifest, "threshold") for s in sources])
    X = np.column_stack(columns)
    labels = np.array([int(r["label"]) for r in rows])
    if set(labels) != {0, 1}:
        raise ValueError("Development tuning requires both classes.")
    learns = d["kind"] == "stacking" or d["calibrate_scores"]
    if learns:
        fit, tune, groups = partition_development(rows, d["fit_fraction"], d["seed"])
    else:
        fit, tune, groups = np.array([], dtype=int), np.arange(len(rows)), np.array([r["group"] for r in rows])
    model = {"calibrators": []}
    if d["kind"] == "stacking":
        model["stacker"] = fit_logistic(X[fit], labels[fit], d["stacking_c"])
    elif d["calibrate_scores"]:
        model["calibrators"] = [fit_logistic(X[fit, i:i+1], labels[fit], d["stacking_c"]) for i in range(X.shape[1])]
    d, metrics, details = _tune(d, model, X[tune], labels[tune])
    partition = {"source_split": "threshold", "fit_indices": fit.tolist(), "tune_indices": tune.tolist(),
                 "fit_groups": sorted(set(groups[fit])), "tune_groups": sorted(set(groups[tune])),
                 "fit_pixel_hashes": [rows[i]["pixel_hash"] for i in fit],
                 "tune_pixel_hashes": [rows[i]["pixel_hash"] for i in tune],
                 "fit_images": len(fit), "tune_images": len(tune),
                 "fit_method": "group-disjoint heldout stacking, not OOF" if learns else "no fitted meta-model"}
    warnings = ["Development results are descriptive; final-test data has not been read.",
                "REVIEW does not count as a correct decision. Monitor review workload separately.",
                "Grouping follows the source audit. Independence across new trays is not established by these rates."]
    if learns:
        warnings.append("Heldout fitting consumes part of the calibration set. Small class/group counts can make coefficients and thresholds unstable.")
    if d["kind"] == "stacking":
        warnings.append("The small score combiner is fitted from scratch; all image feature extractors remain the frozen pretrained models.")
    if not details["targets_feasible"]:
        warnings.append("Requested empirical error/review limits are NOT met by the selected rule.")
    return {"definition": d, "model": model, "partition": partition, "tune_metrics": metrics, "metrics": metrics,
            "tuning": details, "warnings": warnings, "qualification_status": UNQUALIFIED}, sources, manifest, provenance


def preview_system(definition):
    """Fit/tune on development only. This function never reads selection/test scores."""
    return _prepare(definition)[0]


def create_system(definition, output_root="decision_systems"):
    result, sources, manifest, provenance = _prepare(definition)
    protected = [s["run"] for s in sources] + [s["cfg"].get("data_root") for s in sources]
    out = _new_folder(output_root, protected)
    records = []
    for source, score_file in zip(sources, provenance):
        run = source["run"]
        records.append({"run_reference": _reference(run, out), "source_run_id": run.name,
                        "source_config_sha256": sha_file(run / "config.json"),
                        "source_manifest_sha256": sha_file(run / "manifest.csv"),
                        "candidate": deepcopy(source["chosen"]), "kind": source["kind"], "score_files": [score_file]})
    # Recipe is fixed before separate selection scores are opened.
    record = {"format": FORMAT, "created_utc": datetime.now(timezone.utc).isoformat(),
              "task": sources[0]["cfg"]["task"], "class_to_index": {"bad": 0, "good": 1},
              "rule": "good_if_score_below_good;bad_if_score_at_least_bad;otherwise_review",
              **result, "sources": records}
    path = out / "decision_system.json"
    write_json(path, record)
    write_json(out / "decision_system_integrity.json", {"format": FORMAT, "sha256": sha_file(path)})
    selection_rows = [r for r in manifest if r["split"] == "selection"]
    if not selection_rows:
        report = {"status": "unavailable", "reason": "No separate selection partition.", "qualification_status": UNQUALIFIED}
    else:
        columns, hashes = zip(*[_scores(s, manifest, "selection") for s in sources])
        predictions, scores, stages = apply_system(np.column_stack(columns), result["definition"], result["model"])
        report = {"status": "evaluated", "source_split": "selection", "recipe_sha256": sha_file(path),
                  "metrics": triage_metrics([r["label"] for r in selection_rows], predictions),
                  "stage_counts": stages, "score_files": list(hashes), "qualification_status": UNQUALIFIED,
                  "note": "Frozen rule evaluated after fitting/tuning. Selection may already have selected base candidates; this is NOT an independent final test."}
    write_json(out / "selection_report.json", report)
    write_json(out / "selection_report_integrity.json", {"sha256": sha_file(out / "selection_report.json")})
    load_system(path)
    return path


def load_system(path):
    from .workflow import open_run
    path = Path(path).resolve()
    if path.is_dir():
        path /= "decision_system.json"
    integrity = read_json(safe_asset(path.parent, "decision_system_integrity.json"))
    if integrity.get("format") != FORMAT or sha_file(path) != integrity.get("sha256"):
        raise ValueError("Decision system checksum mismatch. Save a new version instead of editing a recipe.")
    record = read_json(path)
    if record.get("format") != FORMAT or record.get("class_to_index") != {"bad": 0, "good": 1}:
        raise ValueError("Unsupported decision-system format or class mapping.")
    normalize_definition(record["definition"])
    sources = []
    for item in record["sources"]:
        run = _resolve_reference(item["run_reference"], path.parent)
        for filename, field in (("config.json", "source_config_sha256"), ("manifest.csv", "source_manifest_sha256")):
            if sha_file(run / filename) != item[field]:
                raise ValueError("Source run fingerprint changed: " + filename)
        cfg, _ = open_run(run)
        kind = _validate_candidate(run, item["candidate"])
        if kind != item["kind"] or cfg["task"] != record["task"]:
            raise ValueError("Source candidate task or score-kind mismatch.")
        for score_file in item["score_files"]:
            if sha_file(safe_asset(run, score_file["relative_path"])) != score_file["sha256"]:
                raise ValueError("Source development scores changed.")
        sources.append({"run": run, "cfg": cfg, "chosen": item["candidate"], "kind": kind})
    if len(sources) != len(record["definition"]["sources"]):
        raise ValueError("Source count differs from the frozen rule.")
    apply_system(np.zeros((1, len(sources))), record["definition"], record["model"])
    return record, sources


def evaluate_system(path, device="cpu", confirm_final_test=False):
    """Explicit, one-shot test of the frozen system; never performs tuning.

    A begin ledger is saved before inference. Failed or interrupted attempts are
    still test exposure and are not silently repeated. Existing completed reports
    are returned unchanged. Prior base-model/system test use is disclosed.
    """
    from .workflow import open_run, predict_members, verify_sources
    from .data import _validate_manifest
    if confirm_final_test is not True:
        raise ValueError("Explicit confirmation is required: this consumes the final test holdout.")
    if device not in ("cpu", "cuda", "auto"):
        raise ValueError("Device must be cpu, cuda or auto.")
    path = Path(path).resolve()
    if path.is_dir():
        path /= "decision_system.json"
    record, sources = load_system(path)
    report_path = path.parent / "final_test_report.json"
    digest = sha_file(path)
    with ExitStack() as stack:
        # Stable ordering avoids cross-run lock inversion.
        for run in sorted({s["run"] for s in sources}, key=str):
            stack.enter_context(run_lock(run))
        if report_path.exists():
            integrity = read_json(path.parent / "final_test_report_integrity.json")
            if sha_file(report_path) != integrity.get("sha256") or read_json(report_path).get("recipe_sha256") != digest:
                raise ValueError("Final-test report integrity mismatch.")
            return report_path
        attempt_path = path.parent / "final_test_attempt.json"
        if attempt_path.exists():
            raise ValueError("A final-test attempt already began. Its exposure is retained; do not rerun tuning against this holdout.")
        _, manifest = open_run(sources[0]["run"])
        _validate_manifest(manifest, require_all=False)
        rows = [r for r in manifest if r["split"] == "test"]
        if {int(r["label"]) for r in rows} != {0, 1}:
            raise ValueError("Final test requires both classes in its separate frozen partition.")
        fingerprint = hashlib.sha256(json.dumps(sorted(r["pixel_hash"] for r in rows)).encode()).hexdigest()
        exposure = []
        for run in sorted({s["run"] for s in sources}, key=str):
            ledger_path = run / "decision_lab_test_ledger.json"
            previous = read_json(ledger_path) if ledger_path.exists() else []
            exposure.append({"run": str(run), "prior_decision_tests": len(previous),
                             "base_model_test_present": (run / "final_test_summary.json").exists() or (run / "final_test").exists()})
        attempt = {"created_utc": datetime.now(timezone.utc).isoformat(), "recipe_sha256": digest,
                   "test_fingerprint": fingerprint, "test_images": len(rows), "prior_exposure": exposure}
        write_json(attempt_path, attempt)
        for run in sorted({s["run"] for s in sources}, key=str):
            ledger_path = run / "decision_lab_test_ledger.json"
            previous = read_json(ledger_path) if ledger_path.exists() else []
            write_json(ledger_path, previous + [attempt])
        # No score cache is assumed: calculate scores for this frozen recipe.
        verify_sources(rows)
        columns = []
        for source in sources:
            values, _ = predict_members(source["run"], source["chosen"]["members"], rows,
                                        {**source["cfg"], "device": device})
            values = np.asarray(values, dtype=float)
            if values.shape != (len(rows),) or not np.isfinite(values).all():
                raise ValueError("Invalid final-test inference scores.")
            if source["kind"] == "supervised" and np.any((values < 0) | (values > 1)):
                raise ValueError("Invalid supervised final-test score range.")
            columns.append(values)
        verify_sources(rows)
        predictions, scores, stages = apply_system(np.column_stack(columns), record["definition"], record["model"])
        met = triage_metrics([r["label"] for r in rows], predictions)
        previously_seen = any(e["prior_decision_tests"] or e["base_model_test_present"] for e in exposure)
        report = {**attempt, "status": "completed", "source_split": "test", "metrics": met,
                  "stage_counts": stages, "prior_test_exposure": previously_seen,
                  "qualification_status": UNQUALIFIED,
                  "note": "Explicit frozen-system test. Reused holdouts are descriptive only. Image/group count, independent-tray coverage and statistical evidence require separate release review."}
        write_csv(path.parent / "final_test_predictions.csv", [{"relative_path": row["relative_path"],
                  "true_class": "bad" if int(row["label"]) == 0 else "good", "predicted_class": str(pred),
                  "score": None if scores is None else float(scores[i])} for i, (row, pred) in enumerate(zip(rows, predictions))])
        write_json(report_path, report)
        write_json(path.parent / "final_test_report_integrity.json", {"sha256": sha_file(report_path)})
        return report_path


def run_system(path, input_root, output_root="classified", labeled=False, device="cpu", copy_images=True):
    """Score copies, stream review records, and never auto-accept inference failures."""
    from .workflow import predict_members
    from .review import initialize_session, append_prediction, update_progress, finish_session, input_fingerprint
    if device not in ("cpu", "cuda", "auto"):
        raise ValueError("Device must be cpu, cuda or auto.")
    path = Path(path).resolve()
    if path.is_dir():
        path /= "decision_system.json"
    record, sources = load_system(path)
    d, model = record["definition"], record["model"]
    source_root = Path(input_root).resolve()
    rows, invalid, duplicates = _audit_inputs(source_root, labeled, sources[0]["cfg"])
    if not rows:
        raise ValueError("No valid input images.")
    out = _new_folder(output_root, [source_root, path.parent] + [s["run"] for s in sources] +
                      [s["cfg"].get("data_root") for s in sources])
    for row in invalid:
        row["file_sha256"] = sha_file(row["path"])
    metadata = {"system_name": d["name"], "system_path": str(path), "system_sha256": sha_file(path),
                "task": record["task"], "mode": d["kind"], "input_root": str(source_root), "labeled": labeled,
                "qualification_status": UNQUALIFIED, "input_fingerprint": input_fingerprint(rows + invalid),
                "source_overlap": _source_overlap(rows, sources)}
    initialize_session(out, kind="workflow", metadata=metadata, total=len(rows) + len(invalid))
    write_json(out / "applied_system.json", record)
    predictions, stage_counts, started = [], [], time.perf_counter()
    def publish(row, predicted, score, trace, status="ok", error=""):
        entry = {"relative_path": row["relative_path"], "true_class": row["true_class"],
                 "predicted_class": predicted, "score": score, "score_type": "decision_system_score",
                 "decision_mode": "decision_system_" + d["kind"], "status": status, "error": error,
                 "output_path": "", "stage_results": trace, "file_sha256": row["file_sha256"]}
        if d["kind"] != "cascade":
            entry.update(good_threshold=d["thresholds"]["good"], bad_threshold=d["thresholds"]["bad"])
        if status == "ok":
            if sha_file(row["path"]) != row["file_sha256"]:
                raise ValueError("Input changed during decision-system inference.")
            if copy_images:
                name = hashlib.sha256(row["relative_path"].encode()).hexdigest()[:20] + "__" + Path(row["path"]).name[-100:]
                target = out / "predicted" / predicted / name
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(row["path"], target)
                if sha_file(target) != row["file_sha256"]:
                    raise ValueError("Copied image differs from its audited original.")
                entry["output_path"] = target.relative_to(out).as_posix()
        predictions.append(append_prediction(out, entry))
        update_progress(out, completed=len(predictions), elapsed_seconds=time.perf_counter() - started)
    def score_source(index, indices, on_scores=None):
        source = sources[index]
        options = {"on_scores": on_scores} if on_scores is not None else {}
        scores, seconds = predict_members(source["run"], source["chosen"]["members"], [rows[i] for i in indices],
                                         {**source["cfg"], "device": device}, **options)
        scores = np.asarray(scores, dtype=float)
        if scores.shape != (len(indices),) or not np.isfinite(scores).all():
            raise ValueError("Invalid inference scores.")
        if source["kind"] == "supervised" and np.any((scores < 0) | (scores > 1)):
            raise ValueError("Supervised score outside [0,1].")
        return scores, seconds
    try:
        for row in invalid:
            publish(row, "", None, [], "input_error", row["error"])
        if d["kind"] == "cascade":
            pending = list(range(len(rows)))
            traces = [[{"index": j, "name": s["name"], "status": "skipped", "reason": "earlier_stage_resolved"}
                       for j, s in enumerate(d["stages"])] for _ in rows]
            for j, stage in enumerate(d["stages"]):
                update_progress(out, stage_index=j, stage_name=stage["name"], pending_images=len(pending))
                if not pending:
                    stage_counts.append({"index": j, "name": stage["name"], "evaluated": 0, "skipped": len(rows)})
                    continue
                scores, seconds = score_source(stage["source"], pending)
                processed = (logistic_scores(scores[:, None], model["calibrators"][stage["source"]])
                             if model.get("calibrators") else scores)
                votes = triage(processed, stage["good"], stage["bad"])
                votes = np.where(((votes == "good") & ~np.bool_(stage["accept"])) |
                                 ((votes == "bad") & ~np.bool_(stage["reject"])), "review", votes)
                met = {"index": j, "name": stage["name"], "evaluated": len(pending), "skipped": len(rows)-len(pending),
                       "inference_seconds": seconds, "deferred": int(sum(votes == "review"))}
                if labeled:
                    met["conditional_metrics"] = triage_metrics([0 if rows[i]["true_class"] == "bad" else 1 for i in pending], votes)
                stage_counts.append(met)
                remaining = []
                for i, raw, score, vote in zip(pending, scores, processed, votes):
                    traces[i][j] = {"index": j, "name": stage["name"], "status": "evaluated", "source": stage["source"],
                                    "raw_score": float(raw), "score": float(score), "good_threshold": stage["good"],
                                    "bad_threshold": stage["bad"], "predicted_class": str(vote)}
                    if vote != "review" or j == len(d["stages"]) - 1:
                        publish(rows[i], str(vote), None, traces[i])
                    else:
                        remaining.append(i)
                pending = remaining
        else:
            X = np.empty((len(rows), len(sources)))
            published = {}
            def publish_scores(offset, chunk):
                chunk = np.asarray(chunk, dtype=float)
                if (chunk.ndim != 1 or offset < 0 or offset + len(chunk) > len(rows) or not np.isfinite(chunk).all()):
                    raise ValueError("Invalid live decision-system scores.")
                if sources[-1]["kind"] == "supervised" and np.any((chunk < 0) | (chunk > 1)):
                    raise ValueError("Invalid supervised live score range.")
                X[offset:offset+len(chunk), -1] = chunk
                block = X[offset:offset+len(chunk)]
                votes, scores, _ = apply_system(block, d, model)
                transformed = _transform(block, model)
                for local, raw in enumerate(chunk):
                    i = offset + local
                    if i in published:
                        if published[i] != float(raw):
                            raise ValueError("Previously streamed prediction changed.")
                        continue
                    trace = [{"index": j, "name": s["chosen"]["name"], "status": "evaluated",
                              "raw_score": float(X[i, j]), "score": float(transformed[local, j])} for j, s in enumerate(sources)]
                    for j, source in enumerate(sources):
                        threshold = source["chosen"].get("threshold", .5 if source["kind"] == "supervised" else None)
                        if threshold is not None and math.isfinite(float(threshold)):
                            trace[j].update(source_threshold=float(threshold),
                                            predicted_class="bad" if X[i, j] >= threshold else "good",
                                            note="Source vote uses its original raw-score threshold, not a calibrated confidence claim.")
                    publish(rows[i], str(votes[local]), float(scores[local]), trace)
                    published[i] = float(raw)
            for i, source in enumerate(sources):
                update_progress(out, stage_index=i, stage_name=source["chosen"]["name"], phase="scoring_source")
                X[:, i], seconds = score_source(i, list(range(len(rows))), publish_scores if i == len(sources)-1 else None)
                stage_counts.append({"index": i, "name": source["chosen"]["name"], "evaluated": len(rows), "inference_seconds": seconds})
            publish_scores(0, X[:, -1].copy())
        flat = [{**p, "stage_results": json.dumps(p["stage_results"], allow_nan=False)} for p in predictions]
        write_csv(out / "predictions.csv", flat)
        write_csv(out / "invalid_images.csv", invalid, ["relative_path", "error"])
        write_csv(out / "duplicate_images.csv", duplicates, ["original", "duplicate"])
        status = "completed_with_input_errors" if invalid else "completed"
        summary = {**metadata, "status": status, "valid_images": len(rows), "invalid_images": len(invalid),
                   "counts": {label: sum(p["predicted_class"] == label for p in predictions) for label in CLASSES},
                   "stage_counts": stage_counts, "elapsed_seconds": time.perf_counter() - started,
                   "predictions_sha256": sha_file(out / "predictions.csv")}
        if labeled:
            valid = [p for p in predictions if p["status"] == "ok"]
            summary["metrics"] = triage_metrics([0 if p["true_class"] == "bad" else 1 for p in valid],
                                                  [p["predicted_class"] for p in valid])
            summary["metrics"].update(invalid_excluded=len(invalid),
                                       denominator_note="Only valid scored images enter rates; invalid inputs remain unavailable in review.")
            write_json(out / "metrics.json", summary["metrics"])
        write_json(out / "summary.json", summary)
        finish_session(out, status=status, completed=len(predictions), summary=summary)
        return out
    except BaseException as error:
        status = "interrupted" if isinstance(error, (KeyboardInterrupt, SystemExit)) else "failed"
        write_json(out / "summary.json", {**metadata, "status": status, "error": str(error)})
        finish_session(out, status=status, completed=len(predictions), error=str(error))
        raise
