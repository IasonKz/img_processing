from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

from nilt.quality_render import export_quality_report, render_quality_report


def fixture():
    metrics = {
        "n_total": 5, "n_labeled": 4, "n_bad": 2, "n_good": 2,
        "n_automatic": 3, "n_review": 2, "n_unavailable": 0,
        "bad_escape_rate": .5, "good_reject_rate": 0., "review_rate": .4,
        "decision_coverage": .6, "selective_accuracy": 2 / 3,
        "bad_detected_TP": 1, "bad_passed_as_good_FN": 1,
        "good_rejected_as_bad_FP": 0, "good_accepted_TN": 1,
        "bad_sent_to_review": 0, "good_sent_to_review": 1,
        "confusion": {"rows": ["bad", "good"], "columns": ["bad", "good", "review"],
                      "matrix": [[1, 1, 0], [0, 1, 1]]},
    }
    return {"format": "inspection_quality_report_v1", "generated_utc": "2026-09-28T10:00:00Z",
            "title": 'Quality <script>alert("x")</script>', "notes": "<img src=x onerror=alert(1)>\nDo not fetch https://example.invalid",
            "runs": [{"id": "r1", "task": "vig", "status": "complete", "config": {"device": "cpu"},
                      "dataset": {"n_images": 12, "n_units": 12, "split_counts": {"train": 8, "validation": 4},
                                  "tray_counts": {"C0000083": 12}, "fingerprint": "abc"},
                      "models": [{"name": "resnet18", "completed": True, "progress": {"status": "complete", "best_val_pr_auc_bad": .75}}],
                      "selection": {"candidates": [{"name": "resnet18", "threshold": .5, "selection_metrics": {"pr_auc_bad": .70}}]},
                      "final_test": {"available": True, "summary": {"name": "resnet18", "metrics": {"pr_auc_bad": .68}}}}],
            "sessions": [{"id": "s1", "task": "vig", "status": "completed", "provisional": False,
                          "metrics_reference": metrics, "metrics_operator": {
                              **metrics, "n_labeled": 0, "n_bad": 0, "n_good": 0,
                              "bad_escape_rate": None, "good_reject_rate": None, "selective_accuracy": None,
                              "bad_detected_TP": 0, "bad_passed_as_good_FN": 0,
                              "good_rejected_as_bad_FP": 0, "good_accepted_TN": 0,
                              "bad_sent_to_review": 0, "good_sent_to_review": 0,
                              "confusion": {"rows": ["bad", "good"], "columns": ["bad", "good", "review"], "matrix": [[0, 0, 0], [0, 0, 0]]}}}],
            "trays": [{"session_id": "s1", "task": "vig", "tray": "C0000083", "quality_status": "Human review pending",
                       "metrics_reference": metrics, "counts": {"total": 5, "good": 2, "bad": 1, "review": 2}}],
            "comparisons": [{"session_a": "s1", "session_b": "s2", "task": "vig", "common_images": 5,
                             "decision_disagreements": 1, "disagreement_rate": .2}],
            "images": [{"session_id": "s1", "task": "vig", "tray": "C0000083", "unit_id": "Rc01Cc02",
                        "relative_path": "inspection/café-sample.png", "prediction": "review", "reference_label": "bad",
                        "operator_label": "review", "review_reason": '=HYPERLINK("https://malicious.invalid")', "score": .5}],
            "disagreements": [], "artifacts": [], "issues": [], "summary": {}, "definitions": {"review": "Abstention"}}


class QualityRenderTests(unittest.TestCase):
    def test_html_is_offline_escaped_and_has_charts(self):
        page = render_quality_report(fixture())
        self.assertIn('&lt;script&gt;alert(&quot;x&quot;)&lt;/script&gt;', page)
        self.assertNotIn('<script', page.lower())
        self.assertNotIn('<img src=x', page)
        self.assertNotIn('src="http', page)
        self.assertNotIn('href="http', page)
        self.assertIn('data:image/png;base64,', page)
        self.assertIn('Content-Security-Policy', page)
        self.assertIn('Manual bad', page)
        self.assertIn('Human review', page)
        self.assertIn('Matched-image model comparison', page)
        self.assertGreaterEqual(page.count('<svg'), 6)
        self.assertIn('Not available', page)
        self.assertIn('inspection/café-sample.png', page)

    def test_export_has_full_evidence_and_hashes(self):
        report = fixture()
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "quality-report"
            result = export_quality_report(report, output)
            self.assertEqual(json.loads((output / "report.json").read_text(encoding="utf-8")), report)
            manifest = json.loads((output / "export_manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(len(manifest["files"]), 14)
            self.assertEqual(len(result["csv_files"]), 12)
            for item in manifest["files"]:
                artifact = output / item["name"]
                self.assertEqual(item["sha256"], hashlib.sha256(artifact.read_bytes()).hexdigest())
                self.assertEqual(item["bytes"], artifact.stat().st_size)
            with (output / "images.csv").open(encoding="utf-8-sig", newline="") as stream:
                image = next(csv.DictReader(stream))
            self.assertEqual(image["relative_path"], "inspection/café-sample.png")
            self.assertTrue(image["review_reason"].startswith("'="))

    def test_csv_formula_and_header_safety(self):
        report = fixture()
        report["images"] = [{"relative_path": "  +SUM(1,2)", "operator_label": "@evil", "=heading": "\t=evil", "score": -.5}]
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "report"
            export_quality_report(report, output)
            with (output / "images.csv").open(encoding="utf-8-sig", newline="") as stream:
                row = next(csv.DictReader(stream))
            self.assertEqual(row["relative_path"], "'  +SUM(1,2)")
            self.assertEqual(row["operator_label"], "'@evil")
            self.assertEqual(row["'=heading"], "'\t=evil")
            self.assertEqual(row["score"], "-0.5")

    def test_existing_files_never_overwritten(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "report"
            output.mkdir()
            original = output / "report.html"
            original.write_text("keep me", encoding="utf-8")
            with self.assertRaises(FileExistsError):
                export_quality_report(fixture(), output)
            self.assertEqual(original.read_text(), "keep me")

    def test_empty_output_supported(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "report"
            output.mkdir()
            export_quality_report(fixture(), output)
            self.assertTrue((output / "report.html").is_file())

    def test_symlink_output_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / "real"
            target.mkdir()
            output = Path(directory) / "link"
            try:
                output.symlink_to(target, target_is_directory=True)
            except OSError:
                self.skipTest("Symlinks are not permitted on this platform")
            with self.assertRaises(ValueError):
                export_quality_report(fixture(), output)
            self.assertFalse(any(target.iterdir()))

    def test_staging_failure_does_not_publish_partial_report(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "report"
            with mock.patch("nilt.quality_render._write_csv", side_effect=OSError("disk full")):
                with self.assertRaises(OSError):
                    export_quality_report(fixture(), output)
            self.assertFalse(output.exists())
            self.assertEqual(list(Path(directory).iterdir()), [])

    def test_invalid_numeric_snapshot_rejected(self):
        report = fixture()
        report["images"][0]["score"] = float("nan")
        with self.assertRaises(ValueError):
            render_quality_report(report)

    def test_empty_report_has_no_fabricated_measurements(self):
        page = render_quality_report({"format": "inspection_quality_report_v1"})
        self.assertIn('No training run was included', page)
        self.assertIn('No inspection sessions were included', page)
        self.assertNotIn('100.0%', page)

    def test_recorded_training_and_final_test_graphs(self):
        report = fixture()
        report["runs"][0]["models"][0]["history"] = [
            {"epoch": "1", "val_pr_auc_bad": "0.51", "train_loss": "0.8", "val_loss": "0.7"},
            {"epoch": "2", "val_pr_auc_bad": "0.74", "train_loss": "0.65", "val_loss": "0.6"},
        ]
        report["runs"][0]["final_test"]["summary"]["metrics"].update(
            bad_detected_TP=10, bad_passed_as_good_FN=2, good_rejected_as_bad_FP=3, good_accepted_TN=21,
            bad_escape_rate=2/12, good_reject_rate=3/24, accuracy=31/36)
        page = render_quality_report(report)
        self.assertIn('Recorded learning curves', page)
        self.assertIn('polyline points=', page)
        self.assertIn('Training loss; epoch 1: 0.8', page)
        self.assertIn('Recorded final test', page)
        self.assertIn('Previously recorded final-test confusion', page)
        self.assertIn('Binary', page.replace('binary', 'Binary'))
        self.assertIn('16.7%', page)

    def test_learning_history_graph_limit_is_explicit(self):
        report = fixture()
        report["runs"][0]["models"] = [{"name": f"model_{i}", "history": [{"epoch": 1, "val_pr_auc_bad": .5}]} for i in range(13)]
        page = render_quality_report(report)
        self.assertIn('Showing 12 of 13 model/trial histories', page)
        self.assertEqual(page.count('polyline points='), 12)

    def test_recorded_evaluation_trays_and_predictions_keep_source_identity(self):
        report = fixture()
        tray = {"tray": "C0000084", "task": "vig", "n_units": 5,
                "counts": {"total": 5, "review": 2, "no_decision": 0},
                "metrics_reference": report["sessions"][0]["metrics_reference"]}
        prediction = {"relative_path": "bad/C0000084_Rc01Cc01.png", "prediction": "good", "reference_label": "bad", "task": "vig"}
        final = report["runs"][0]["final_test"]
        final.update(role="recorded final test", per_tray=[tray], prediction_rows=[prediction])
        report["runs"][0]["external_evaluations"] = [{
            "id": "holdout_20260928", "available": True, "role": "recorded external evaluation",
            "summary": {"candidate": "resnet18", "metrics": {"pr_auc_bad": .72}},
            "per_tray": [{**tray, "tray": "C0000085"}], "prediction_rows": [{**prediction, "relative_path": "bad/C0000085_Rc01Cc01.png"}]}]
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "report"
            export_quality_report(report, output)
            page = (output / "report.html").read_text(encoding="utf-8")
            self.assertIn("Final-test tray evidence", page)
            self.assertIn("Recorded external evaluation", page)
            self.assertIn("holdout_20260928", page)
            self.assertIn("C0000085", page)
            self.assertIn("Labeled auto coverage", page)
            with (output / "recorded_evaluation_predictions.csv").open(encoding="utf-8-sig", newline="") as stream:
                predictions = list(csv.DictReader(stream))
            self.assertEqual([row["evaluation_id"] for row in predictions], ["final_test", "holdout_20260928"])
            self.assertEqual([row["run_id"] for row in predictions], ["r1", "r1"])
            self.assertEqual(predictions[1]["evaluation_role"], "recorded external evaluation")
            with (output / "images.csv").open(encoding="utf-8-sig", newline="") as stream:
                self.assertEqual(len(list(csv.DictReader(stream))), 1)

    def test_all_image_rows_retained_when_html_preview_is_limited(self):
        report = fixture()
        report["images"] = [{"relative_path": f"image_{i:04d}.png", "prediction": "good"} for i in range(260)]
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "report"
            export_quality_report(report, output)
            page = (output / "report.html").read_text(encoding="utf-8")
            self.assertIn("Showing 250 of 260 rows", page)
            self.assertNotIn("image_0259.png", page)
            with (output / "images.csv").open(encoding="utf-8-sig", newline="") as stream:
                self.assertEqual(len(list(csv.DictReader(stream))), 260)


if __name__ == "__main__":
    unittest.main()
