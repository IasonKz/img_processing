"use strict";
const SegmentationStudio=window.SegmentationStudio=(()=>{
  $("seg-localizer-host").innerHTML=`<div class="localizer-controls"><div class="two-columns"><article class="card"><h2>Train ROI geometry localization</h2><label>Geometry-mask export<select id="seg-localizer-export"></select></label><p class="hint">This model learns where ROI are. Good / Bad quality models are trained in Classification. Templates and geometric checks remain active during localization.</p><label>ROI segmentation dataset<input id="roi-training-dataset" spellcheck="false" placeholder="Path from a geometry-mask export"></label><div class="three-fields"><label>Epochs<input id="roi-train-epochs" type="number" min="1" max="500" value="20"></label><label>Image size<input id="roi-train-size" type="number" min="64" max="2048" step="32" value="384"></label><label>Batch size<input id="roi-train-batch" type="number" min="1" max="64" value="4"></label></div><label>Device<select id="roi-train-device"><option value="cpu">CPU</option><option value="cuda">CUDA GPU</option><option value="auto">Automatic</option></select></label><div class="actions"><button id="roi-train" class="primary">Train ROI localizer</button><button id="seg-localizer-stop" class="secondary">Stop localizer worker</button><button id="seg-localizer-annotations" class="secondary">Edit geometry annotations → ROI Detection</button></div></article><article class="card"><h2>Evaluate and reuse</h2><label>Recorded training experiment<select id="roi-experiment-selection"></select></label><label>ROI localizer checkpoint<input id="roi-evaluate-model" spellcheck="false"></label><button id="roi-evaluate" class="secondary">Evaluate held-out test masks</button><button id="roi-use-model" class="secondary">Use model in localization</button><div id="roi-training-result" class="empty">Training and evaluation results appear here.</div><p class="hint">Mask metrics measure localization. Qualify the complete ROI inspection chain separately on independent captures with automatically produced crops.</p></article></div></div>`;
  let side="top",target="whole_image",active=null,sequence=0,roiSide="top",roiSequence=0,operationSide=null;
  const choices=new Map(),catalogs=new Map(),roiFrames=new Map();
  const on=(id,fn)=>$(id).addEventListener("click",()=>Promise.resolve().then(fn).catch(e=>notify(e.message,true)));
  const key=row=>row?row.export_id+":"+row.kind:"";
  async function catalog(view){const result=await api("/api/segmentation/catalog?"+new URLSearchParams({side:view}));catalogs.set(view,result);return result;}
  function pickers(data,exportId,kindId,previous){
    const exports=[...new Set(data.crops.map(row=>row.export_id))];
    selectOptions(exportId,exports.map(value=>({value,label:value})),"Export reviewed ROI geometry first",previous?.export_id);
    const rows=data.crops.filter(row=>row.export_id===$(exportId).value);
    selectOptions(kindId,rows.map(row=>({value:row.kind,label:row.kind.replaceAll("_"," ")+" · "+row.count+" crops"})),"No ROI crops",previous?.kind);
    return rows.find(row=>row.kind===$(kindId).value)||null;
  }
  function chosen(data,exportId,kindId){return data?.crops.find(row=>row.export_id===$(exportId).value&&row.kind===$(kindId).value)||null;}
  function title(){return side.toUpperCase()+" / "+(target==="whole_image"?"Whole image":target==="roi_localizer"?"ROI localization":"ROI "+(active?.kind||"crops").replaceAll("_"," "));}
  function layout(){
    $("seg-task-title").textContent=title();
    $("seg-crop-controls").hidden=target!=="roi_crops";$("seg-localizer-host").hidden=target!=="roi_localizer";
    for(const id of ['seg-crop-open','seg-crop-return'])$(id).disabled=!chosen(catalogs.get(side),"seg-crop-export","seg-crop-kind");
    $("segmentation-host").hidden=target==="roi_localizer"||!active;$("seg-empty").hidden=target!=="roi_crops"||!!active;
    $("seg-context-note").textContent=target==="roi_localizer"?"Train where ROI features are on the original image, then reuse the checkpoint in ROI Detection. Defect segmentation on crops has its own target.":target==="roi_crops"?"Annotate and segment defects inside exported crops. ROI Detection and Segmentation share this project's annotations, native pixels and original unit splits.":"TOP whole-image defect annotations and studies retain their existing project. BOTTOM supports ROI segmentation only.";
    WorkspaceStudio.syncSegmentation();
    $("page-title").textContent=title();$("page-eyebrow").textContent="SEGMENTATION / DEVELOPMENT";
    if(activeTab==="segmentation"){
      if(active)WorkspaceStudio.mountSegmentation(active.context,active.prefix);
      WorkspaceStudio.syncSegmentationNavigation();
    }
  }
  async function open(view,options={}){
    const version=++sequence,changed=side!==view;side=view;
    const saved=choices.get(view)||{};
    target=options.target||saved.target||(view==="top"?"whole_image":"roi_crops");
    if(view==="bottom"&&target==="whole_image")target="roi_crops";
    selectOptions("segmentation-target",[...(view==="top"?[{value:"whole_image",label:"Whole image · TOP defects"}]:[]),{value:"roi_crops",label:"ROI crops · defects"},{value:"roi_localizer",label:"ROI localization · geometry masks"}],"Select segmentation target",target);
    if(changed||target!==saved.target)active=null;
    choices.set(view,{...saved,target});
    if(target==="whole_image")active={context:view,prefix:"/segmentation/"+view};
    layout();
    const data=await catalog(view);if(version!==sequence)return;
    const preferred={...saved,...options};
    const selected=pickers(data,"seg-crop-export","seg-crop-kind",preferred);
    if(target==="roi_crops"){
      active=selected?.prepared?selected:null;
      $("seg-crop-info").textContent=selected?`${selected.count} crops · ${Object.entries(selected.splits).map(([role,n])=>role+": "+n).join(" · ")} · Original unit roles are preserved.`:"Build a reviewed ROI export in ROI Detection first.";
    }
    selectOptions("seg-localizer-export",data.localizers.map(row=>({value:row.export_id,label:row.export_id+" · "+row.samples+" original images"})),"Export geometry masks first",preferred.export_id);
    if(target==="roi_localizer"){
      const dataset=data.localizers.find(row=>row.export_id===$("seg-localizer-export").value);
      $("roi-training-dataset").value=dataset?.path||"";
    }
    selectOptions("roi-experiment-selection",data.experiments.map(ex=>({value:ex.id,label:ex.id+" · "+(ex.status?.status||"recorded")})),"No localizer experiment yet");
    const experiment=data.experiments.find(ex=>ex.id===$("roi-experiment-selection").value)||data.experiments.find(ex=>ex.status?.status==="completed");
    $("roi-evaluate-model").value=experiment?.model_path||"";
    $("roi-training-result").textContent=data.job.status==="idle"?"Localizer training and evaluation results appear here.":JSON.stringify(data.job,null,2);
    choices.set(view,{target,export_id:target==="roi_localizer"?$("seg-localizer-export").value:selected?.export_id,kind:selected?.kind});layout();
  }
  async function prepare(row,statusId){
    if(!row)throw Error("Choose an exported ROI kind first.");
    const result=await api("/api/segmentation/roi-crops",{side:row.side||side,export_id:row.export_id,kind:row.kind});
    for(;;){
      const response=await fetch(result.prefix+"/api/studio/state",{headers:{"X-Session-Token":result.session_token}});
      const state=await response.json();if(!response.ok)throw Error(state.error||"Cannot inspect the crop import.");
      $(statusId).textContent=`${result.count} crops · import ${state.job.status} · ${state.total} imported`;
      if(!["starting","running","unverified"].includes(state.job.status)){
        if(!["idle","completed"].includes(state.job.status))throw Error(state.job.error||state.job.log||"Crop import did not complete.");
        if(!state.total)throw Error("No usable crops were imported. Inspect the import log.");
        if(state.job.result?.invalid?.length)notify("Some ROI crops were excluded; inspect the import report before training.",true);
        break;
      }
      await new Promise(resolve=>setTimeout(resolve,300));
    }
    row.prepared=true;return {...row,...result};
  }
  async function openRoi(view,previous){
    const version=++roiSequence;roiSide=view;const data=await catalog(view);if(roiSide!==view||version!==roiSequence)return;
    const row=pickers(data,"roi-seg-export","roi-seg-kind",previous);
    $("roi-crop-annotate").disabled=!row;$("roi-crop-train").disabled=!row;
    $("roi-crop-status").textContent=row?`${row.count} crops · ${Object.entries(row.splits).map(([role,n])=>role+": "+n).join(" · ")} · Choose Open crop annotations.`:"Export reviewed geometry to prepare ROI crops first.";
    for(const [context,frame]of roiFrames)frame.hidden=context!==row?.context;
  }
  async function annotateRoi(){
    const view=roiSide,row=chosen(catalogs.get(view),"roi-seg-export","roi-seg-kind");
    const prepared=await prepare({...row,side:view},"roi-crop-status");
    if(view!==roiSide||key(row)!==key(chosen(catalogs.get(view),"roi-seg-export","roi-seg-kind")))return;
    if(!roiFrames.has(prepared.context)){
      const frame=document.createElement("iframe");frame.title=view.toUpperCase()+" "+prepared.kind+" defect annotation";frame.setAttribute("allow","fullscreen");frame.src=prepared.prefix+"/annotate";$("roi-crop-annotation-host").appendChild(frame);roiFrames.set(prepared.context,frame);
    }
    for(const [context,frame]of roiFrames)frame.hidden=context!==prepared.context;
    $("roi-crop-status").textContent="Crop annotations are shared with Segmentation. Save and approve defects or explicitly approve clean crops before training.";
  }
  async function switchTo(view,options){
    if(WorkspaceStudio.family()!=="segmentation")WorkspaceStudio.selectFamily("segmentation");
    if(WorkspaceStudio.task()!==view)WorkspaceStudio.selectTask(view);
    tab("segmentation");await open(view,options);
  }
  async function showRoi(view,row){
    if(WorkspaceStudio.family()!=="roi")WorkspaceStudio.selectFamily("roi");
    if(WorkspaceStudio.task()!==view)WorkspaceStudio.selectTask(view);
    tab("roi");await RoiStudio.open(view);RoiStudio.showStep("annotations");await openRoi(view,row);
  }
  async function localizerOperation(action){
    const view=side;
    const payload={side:view,dataset:$("roi-training-dataset").value,model_path:$("roi-evaluate-model").value,
      epochs:Number($("roi-train-epochs").value),size:Number($("roi-train-size").value),batch_size:Number($("roi-train-batch").value),device:$("roi-train-device").value};
    const result=await api("/api/segmentation/localizer/"+action,payload);operationSide=view;
    for(;;){
      const {job}=await api("/api/roi/job?"+new URLSearchParams({side:view}));
      if(side===view)$("roi-training-result").textContent=JSON.stringify(job,null,2);
      if(!["starting","running","unverified"].includes(job.status)){
        operationSide=null;
        if(job.status!=="completed")throw Error(job.error||"Localizer operation did not complete.");
        if(side===view&&job.model_path)$("roi-evaluate-model").value=job.model_path;
        notify("ROI localizer "+action+" completed. Mask metrics measure localization.");
        break;
      }
      await new Promise(resolve=>setTimeout(resolve,600));
    }
  }
  $("segmentation-target").addEventListener("change",()=>open(WorkspaceStudio.task(),{target:$("segmentation-target").value}).catch(e=>notify(e.message,true)));
  for(const id of ["seg-crop-export","seg-crop-kind"])$(id).addEventListener("change",()=>open(side,{export_id:$("seg-crop-export").value,kind:$("seg-crop-kind").value}).catch(e=>notify(e.message,true)));
  for(const id of ["roi-seg-export","roi-seg-kind"])$(id).addEventListener("change",()=>openRoi(roiSide,{export_id:$("roi-seg-export").value,kind:$("roi-seg-kind").value}).catch(e=>notify(e.message,true)));
  on("seg-crop-open",async()=>{const view=side,row=chosen(catalogs.get(view),"seg-crop-export","seg-crop-kind");if(!row)throw Error("Choose a crop export.");const prepared=await prepare({...row,side:view},"seg-crop-info");if(side!==view||target!=="roi_crops"||key(row)!==key(chosen(catalogs.get(view),"seg-crop-export","seg-crop-kind")))return;active=prepared;layout();WorkspaceStudio.selectSegmentation("annotation");});
  on("seg-crop-refresh",()=>open(side));on("roi-crop-refresh",()=>openRoi(roiSide));on("roi-crop-annotate",annotateRoi);
  on("roi-crop-train",async()=>{const view=roiSide,row=chosen(catalogs.get(view),"roi-seg-export","roi-seg-kind");if(!row)throw Error("Choose a crop export.");await switchTo(view,{target:"roi_crops",export_id:row.export_id,kind:row.kind});if(!active)active=await prepare({...row,side:view},"seg-crop-info");layout();WorkspaceStudio.selectSegmentation("search");});
  on("seg-crop-return",()=>showRoi(side,chosen(catalogs.get(side),"seg-crop-export","seg-crop-kind")));
  on("roi-crop-fullscreen",async()=>{if(document.fullscreenElement)await document.exitFullscreen();else await $("main-content").requestFullscreen();for(const frame of roiFrames.values())frame.contentWindow.NiltEmbedded?.layout();});
  document.addEventListener("fullscreenchange",()=>{for(const frame of roiFrames.values())frame.contentWindow.NiltEmbedded?.layout();});
  $("seg-localizer-export").addEventListener("change",()=>{const row=catalogs.get(side)?.localizers.find(row=>row.export_id===$("seg-localizer-export").value);$("roi-training-dataset").value=row?.path||"";choices.set(side,{...choices.get(side),export_id:row?.export_id});});
  $("roi-experiment-selection").addEventListener("change",()=>{const ex=catalogs.get(side)?.experiments.find(ex=>ex.id===$("roi-experiment-selection").value);if(ex){$("roi-evaluate-model").value=ex.model_path;$("roi-training-result").textContent=JSON.stringify(ex,null,2);}});
  on("roi-train",()=>localizerOperation("train"));on("roi-evaluate",()=>localizerOperation("evaluate"));
  on("seg-localizer-stop",async()=>{const result=await api("/api/roi/stop",{side:operationSide||side});notify(result.message);});
  on("roi-use-model",async()=>{const view=side,path=$("roi-evaluate-model").value;if(!path)throw Error("Choose a trained localizer checkpoint.");if(WorkspaceStudio.family()!=="roi")WorkspaceStudio.selectFamily("roi");if(WorkspaceStudio.task()!==view)WorkspaceStudio.selectTask(view);tab("roi");await RoiStudio.useLocalizer(view,path);});
  on("seg-localizer-annotations",async()=>{const view=side;if(WorkspaceStudio.family()!=="roi")WorkspaceStudio.selectFamily("roi");if(WorkspaceStudio.task()!==view)WorkspaceStudio.selectTask(view);tab("roi");await RoiStudio.open(view);RoiStudio.showStep("review");});
  for(const id of ["roi-training-dataset","roi-evaluate-model"]){const input=$(id),row=document.createElement("div");row.className="browse-row";input.parentNode.insertBefore(row,input);row.appendChild(input);const button=document.createElement("button");button.className="secondary";button.textContent="Browse…";row.appendChild(button);button.addEventListener("click",async()=>{try{const result=await api("/api/pick-path",{kind:id==="roi-evaluate-model"?"file":"folder",initial:input.value,mustexist:true});if(result.path)input.value=result.path;}catch(e){notify(e.message,true);}});}
  return {open,openRoi,title,selection:()=>active,switchTo};
})();
