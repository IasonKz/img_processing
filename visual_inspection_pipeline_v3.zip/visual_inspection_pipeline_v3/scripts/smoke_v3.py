"""Synthetic end-to-end installation check, not industrial model validation.

python scripts/smoke_v3.py --output C:/inspection-smoke --with-onnx
Optionally --weights PATH uses already downloaded ResNet18 weights; never downloads.
"""
from pathlib import Path
import argparse
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True)
    parser.add_argument("--weights")
    parser.add_argument("--with-onnx", action="store_true")
    args = parser.parse_args()
    import numpy as np
    import yaml
    from PIL import Image
    from nilt.common import read_json, write_json
    output = Path(args.output).resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError("Use a new or empty smoke output directory.")
    rng = np.random.default_rng(812)
    for label in ("good", "bad"):
        folder = output / "data" / label
        folder.mkdir(parents=True, exist_ok=True)
        for i in range(40):
            pixels = rng.integers(35, 100, (64, 80, 3), dtype=np.uint8)
            if label == "bad":
                # Deterministically varied corner/edge defects survive rotation.
                y, x = (i * 7) % 48, (i * 11) % 64
                pixels[y:y+16, x:x+16] = [240, 25, 25]
            tray, row, col = 83 + i % 3, i // 10 + (10 if label == "bad" else 0), i % 10
            extension = "png" if i % 2 else "bmp"
            Image.fromarray(pixels).save(folder / f"C{tray:08d}_Rc{row:02d}Cc{col:02d}_FlatField_20260101T105522.{extension}")
    config = {
        "schema_version": 3, "project_name": "SYNTHETIC_INSTALLATION_CHECK",
        "paths": {"output_root": str(output / "results"), "weights_root": str(Path(args.weights).resolve() if args.weights else output / "weights")},
        "defaults": {"pretrained": bool(args.weights), "grouping": "tray_unit", "resize": "pad", "image_size": "auto",
                     "preserve_native_resolution": True, "near_duplicate_distance": -1, "export_images": False,
                     "search": {"enabled": True, "total_budget_seconds": 300, "max_trials_per_model": 1,
                                "startup_trials": 1, "minimum_trial_seconds": 1, "min_finetune_epochs": 1,
                                "space": {"mode": ["head_only"], "scheduler": ["constant"], "optimizer": ["adamw"],
                                          "imbalance": ["weighted_loss"], "max_class_weight": [4.], "effective_batch_size": [4],
                                          "head_learning_rate": [0.001, 0.001], "weight_decay": [0.0001, 0.0001]}}},
        "profiles": {"laptop": {"models": ["resnet18"], "seeds": [42], "device": "cpu", "cpu_threads": 2,
                                  "num_workers": 0, "ensembles": False,
                                  "training": {"epochs": 2, "warmup_epochs": 0, "patience": 2, "batch_size": 4,
                                               "eval_batch_size": 4, "accumulation_steps": 1, "amp": False}}},
        "tasks": {"vig": {"dataset_root": str(output / "data"), "augmentation": {"rotation90": True}}},
    }
    config_file = output / "smoke.yaml"
    config_file.write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")
    def command(*values):
        subprocess.run([sys.executable, str(ROOT / "inspection.py"), *map(str, values)], check=True, cwd=ROOT)
    command("search", "--config", config_file, "--profile", "laptop", "--task", "vig")
    selected_files = list((output / "results" / "vig").glob("*/selected.json"))
    if len(selected_files) != 1:
        raise RuntimeError("Smoke search did not finish selecting one run; inspect its diagnostics.")
    run = selected_files[0].parent
    from nilt.decisions import create_decision, predict_decision
    decisions = {}
    for mode, threshold in (("policy", None), ("manual", .6), ("argmax", None), ("scores_only", None)):
        decision = create_decision(run, mode=mode, threshold=threshold, output_root=output / "decisions")
        predictions = predict_decision(decision, output / "data", output / "predictions", labeled=True, copy_images=False)
        decisions[mode] = {"decision": str(decision), "predictions": str(predictions)}
    command("report", "--run", run)
    if args.with_onnx:
        from nilt.deployment import export_package
        from nilt.runtime import predict_package
        for mode in ("argmax", "scores_only"):
            package = export_package(run, output / ("onnx_" + mode), decision=decisions[mode]["decision"])
            predict_package(package, output / "data", output / ("onnx_predictions_" + mode), labeled=True)
    if (run / "final_test_summary.json").exists():
        raise AssertionError("Search must not evaluate final-test data.")
    write_json(output / "smoke_result.json", {"status": "passed", "run": str(run), "synthetic": True,
               "pretrained_weights_loaded": bool(args.weights), "with_onnx": args.with_onnx,
               "industrial_performance_evidence": False, "decision_modes": decisions,
               "selected_candidate": read_json(run / "selected.json")["name"]})
    print(f"SMOKE PASSED: {output / 'smoke_result.json'}")


if __name__ == "__main__":
    main()
