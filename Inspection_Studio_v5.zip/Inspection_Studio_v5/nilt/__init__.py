"""Local, defect-oriented image classification. Fixed labels: bad=0, good=1."""
__version__ = "5.0.0"
