"use strict";
/* Descriptive development analytics. These views never request test data. */
const Analytics = (() => {
  const palette = ['#0076bd','#008779','#955cc0','#c77e13','#c14866','#50677d','#725d3c','#346842'];
  const labels = {validation_ap:'Validation average precision',validation_roc_auc:'Validation ROC AUC',validation_balanced_accuracy:'Validation balanced accuracy'};
  const state = {run:null,objective:'',model:'',parameter:'',log:true,dimensions:[],data:null};
  const finite = value => value !== null && value !== undefined && value !== '' && typeof value !== 'boolean' && Number.isFinite(Number(value));
  const esc = value => escapeHtml(value);
  const valueOf = value => finite(value) ? Number(value) : null;
  function params(row) {
    try { const p = typeof row.params_json === 'string' ? JSON.parse(row.params_json) : row.params_json || row.params; return p && typeof p === 'object' && !Array.isArray(p) ? p : {}; } catch { return {}; }
  }
  function trials(data) {
    return (data.trials || []).map(row => ({...row,model:String(row.model || 'Unknown'),objective:row.objective || 'validation_ap',value:valueOf(row.value),trial:valueOf(row.trial),seconds:valueOf(row.seconds),parameters:params(row)}));
  }
  const complete = rows => rows.filter(row => row.state === 'COMPLETE' && row.value !== null && row.trial !== null);
  const colorFor = (model,models) => palette[Math.max(0,models.indexOf(model)) % palette.length];
  function options(values,selected,allLabel) { return (allLabel ? `<option value="">${allLabel}</option>` : '') + values.map(value => `<option value="${esc(value)}"${value===selected?' selected':''}>${esc(labels[value] || value)}</option>`).join(''); }
  function svg(id,label) { return `<svg id="${id}" class="chart analytics-chart" viewBox="0 0 560 225" role="img" aria-label="${esc(label)}"></svg>`; }
  function card(id,title,body,wide=false) { return `<article id="${id}" class="card analytics-card${wide?' analytics-wide':''}"><h2>${title}</h2>${body}</article>`; }
  function legend(models,allModels) { return `<div class="analytics-legend">${models.map(model=>`<span><i style="background:${colorFor(model,allModels)}"></i>${esc(model)}</span>`).join('')}</div>`; }
  function empty(message) { return `<p class="empty">${esc(message)}</p>`; }
  function line(id,sets,xLabel) {
    plot(id,sets.map(s=>({...s,name:''})),xLabel,[0,1]);
    // The shared helper's SVG is followed by a wrapping HTML legend for long lists.
  }
  function axes(xmin,xmax,xlabel,ylabel,xformat=null,xticks=null) {
    const X=v=>48+(v-xmin)/(xmax-xmin||1)*488, Y=v=>181-v*157;
    let markup='';
    for(let i=0;i<5;i++) { const y=i/4; markup+=`<line x1="48" y1="${Y(y)}" x2="536" y2="${Y(y)}" stroke="#e0e7ed"/><text x="40" y="${Y(y)+4}" text-anchor="end">${number(y,2)}</text>`; }
    for(const x of xticks || Array.from({length:5},(_,i)=>xmin+(xmax-xmin)*i/4))markup+=`<text x="${X(x)}" y="199" text-anchor="middle">${esc(xformat?xformat(x):number(x,1))}</text>`;
    markup+=`<text x="292" y="221" text-anchor="middle">${esc(xlabel)}</text><text x="48" y="13">${esc(ylabel)}</text>`;
    return {markup,X,Y};
  }
  function dots(id,rows,models,key,logScale=false,categories=null) {
    const valid=rows.filter(row=>key==='minutes'?row.seconds!==null&&row.seconds>=0:row.parameters[key]!==undefined&&row.parameters[key]!==null);
    const raw=row=>key==='minutes'?row.seconds/60:categories?categories.indexOf(String(row.parameters[key])):Number(row.parameters[key]);
    const eligible=valid.filter(row=>Number.isFinite(raw(row))&&(!logScale||raw(row)>0));
    if(!eligible.length) { $(id).innerHTML='<text x="280" y="110" text-anchor="middle">No matching completed trials</text>';return; }
    const xvalue=row=>logScale?Math.log10(raw(row)):raw(row);
    let xmin=Math.min(...eligible.map(xvalue)),xmax=Math.max(...eligible.map(xvalue));
    if(xmin===xmax){xmin-=.5;xmax+=.5;}
    const formatter=categories?v=>Number.isInteger(v)?categories[v]||'':'' : logScale?v=>Number(10**v).toExponential(1):null;
    const a=axes(xmin,xmax,key==='minutes'?'Recorded training minutes':key+(logScale?' · log scale':''),'Objective score',formatter,categories?categories.map((_,index)=>index):null);
    $(id).innerHTML=a.markup+eligible.map(row=>`<circle tabindex="0" cx="${a.X(xvalue(row))}" cy="${a.Y(row.value)}" r="5" fill="${colorFor(row.model,models)}" fill-opacity=".8" stroke="#fff" stroke-width="1"><title>${esc(row.model)} · trial ${row.trial}\n${esc(key)}: ${esc(key==='minutes'?number(raw(row),2):row.parameters[key])}\n${esc(labels[row.objective]||row.objective)}: ${number(row.value)}</title></circle>`).join('');
  }
  function parallel(id,rows,dimensions,models) {
    const usable=rows.filter(row=>dimensions.every(key=>row.parameters[key]!==undefined&&row.parameters[key]!==null&&row.parameters[key]!==''));
    if(!dimensions.length||!usable.length){$(id).innerHTML='<text x="280" y="110" text-anchor="middle">Select parameters shared by completed trials</text>';return;}
    const domains=dimensions.map(key=>{
      const values=usable.map(row=>row.parameters[key]),numeric=values.every(finite);
      return {key,numeric,min:numeric?Math.min(...values.map(Number)):0,max:numeric?Math.max(...values.map(Number)):1,categories:numeric?[]:[...new Set(values.map(String))]};
    });
    domains.push({key:'Objective',numeric:true,min:0,max:1});
    const X=index=>50+index/(domains.length-1)*470,Y=(row,d)=>{
      const v=d.key==='Objective'?row.value:row.parameters[d.key];
      const fraction=d.numeric?(d.max===d.min?0.5:(Number(v)-d.min)/(d.max-d.min)):(d.categories.length===1?0.5:d.categories.indexOf(String(v))/(d.categories.length-1));
      return 177-fraction*133;
    };
    const short=(text,max=19)=>text.length>max?text.slice(0,max-1)+'…':text;
    const axisNumber=value=>value!==0 && (Math.abs(value)<.001||Math.abs(value)>=10000)?value.toExponential(1):number(value,3);
    let markup=domains.map((d,i)=>`<line x1="${X(i)}" y1="44" x2="${X(i)}" y2="177" stroke="#b9c8d4"/><text x="${X(i)}" y="20" text-anchor="middle">${esc(short(d.key))}<title>${esc(d.key)}</title></text><text x="${X(i)}" y="37" text-anchor="middle">${esc(d.numeric?axisNumber(d.max):short(d.categories.at(-1)||'',13))}</text><text x="${X(i)}" y="194" text-anchor="middle">${esc(d.numeric?axisNumber(d.min):short(d.categories[0]||'',13))}</text>`).join('');
    markup+=usable.map(row=>`<polyline tabindex="0" points="${domains.map((d,i)=>`${X(i)},${Y(row,d)}`).join(' ')}" fill="none" stroke="${colorFor(row.model,models)}" stroke-opacity=".28" stroke-width="1.5"><title>${esc(row.model)} · trial ${row.trial}\n${dimensions.map(key=>`${esc(key)}: ${esc(row.parameters[key])}`).join('\n')}\nObjective: ${number(row.value)}</title></polyline>`).join('');
    $(id).innerHTML=markup;
  }
  function search(data) {
    const target=$('analytics-search');if(!target)return;
    const all=trials(data),models=[...new Set(all.map(row=>row.model))],objectives=[...new Set(all.map(row=>row.objective))];
    if(!objectives.includes(state.objective))state.objective=objectives[0]||'validation_ap';
    if(state.model&&!models.includes(state.model))state.model='';
    const scoped=all.filter(row=>row.objective===state.objective&&(!state.model||row.model===state.model)),done=complete(scoped),shownModels=models.filter(m=>!state.model||m===state.model);
    const keys=[...new Set(done.flatMap(row=>Object.keys(row.parameters)))].sort();
    if(!keys.includes(state.parameter))state.parameter=keys.includes('learning_rate')?'learning_rate':keys[0]||'';
    state.dimensions=state.dimensions.filter(key=>keys.includes(key));
    if(!state.dimensions.length)state.dimensions=keys.slice(0,4);
    const values=done.filter(row=>row.parameters[state.parameter]!==undefined&&row.parameters[state.parameter]!==null).map(row=>row.parameters[state.parameter]);
    const numeric=values.length>0&&values.every(finite),positive=numeric&&values.every(value=>Number(value)>0),categories=numeric?null:[...new Set(values.map(String))];
    target.innerHTML=`<div class="analytics-heading"><div><span class="eyebrow">SEARCH ANALYTICS</span><h2>Understand the search</h2><p class="hint">Development data only. Hover or focus a point for its recorded values.</p></div><div class="analytics-controls"><label>Architecture<select id="analytics-model">${options(models,state.model,'All architectures')}</select></label><label>Objective<select id="analytics-objective">${options(objectives,state.objective)}</select></label></div></div>`+
      `<div class="analytics-grid">`+
      card('search-overview','Completed trial objectives',svg('search-history-chart','Completed trial objective by architecture')+legend(shownModels,models)+'<p class="hint">Trial number is local to each architecture. A completed score is a validation result; failures and timeouts never become zero scores.</p>')+
      card('search-efficiency','Training time and score',svg('search-efficiency-chart','Training duration versus validation objective')+legend(shownModels,models)+'<p class="hint">Recorded training duration, not inference latency. Only completed trials with recorded duration are shown.</p>')+
      card('search-learning-overlay','Validation learning curves',svg('search-learning-chart','Validation average precision by epoch')+legend(shownModels,models)+'<p class="hint">Average precision for the bad class. One line per recorded trial; architecture colors are shared across charts.</p>')+
      card('search-status-breakdown','Trial outcomes',`<div class="analytics-outcomes">${['COMPLETE','PRUNED','FAILED','TIMEOUT','PAUSED','RUNNING','WAITING'].map(status=>{const count=scoped.filter(row=>outcome(row)===status).length;return `<div><strong>${count}</strong><span>${status}</span><div class="analytics-track"><i style="width:${scoped.length?100*count/scoped.length:0}%"></i></div></div>`;}).join('')}</div><p class="hint">Counts use the active architecture and objective filters. A timeout records a budget stop, not poor predictive performance.</p>`)+
      card('search-parameter','Parameter and score',`<div class="analytics-controls"><label>Parameter<select id="analytics-parameter">${options(keys,state.parameter)}</select></label><label class="checkbox"><input id="analytics-log" type="checkbox"${state.log&&positive?' checked':''}${positive?'':' disabled'}>Logarithmic x-axis</label></div>`+svg('search-parameter-chart','Chosen hyperparameter versus validation objective')+'<p class="hint">Observed associations depend on the other parameters and trial budget. This chart is not causal parameter importance.</p>')+
      card('search-parallel','Parameter combinations',`<fieldset class="analytics-dimensions"><legend>Axes · select up to five</legend>${keys.map(key=>`<label><input type="checkbox" data-analytics-dimension="${esc(key)}"${state.dimensions.includes(key)?' checked':''}>${esc(key)}</label>`).join('')||'<p class="hint">Parameters appear after completed trials are recorded.</p>'}</fieldset>`+svg('search-parallel-chart','Parallel coordinates of actual trial parameters')+'<p class="hint">Each line is one completed trial with all selected parameters. Numeric axes use independent linear scales; categorical positions are arbitrary. Hover a line for exact values.</p>')+
      '</div>';
    line('search-history-chart',shownModels.map(model=>({name:model,color:colorFor(model,models),points:done.filter(row=>row.model===model).sort((a,b)=>a.trial-b.trial).map(row=>[row.trial,row.value])})),'Trial');
    dots('search-efficiency-chart',done,models,'minutes');
    const histories=(data.histories||[]).filter(item=>{const model=historyModel(item.name,models);return model&&(!state.model||model===state.model);});
    line('search-learning-chart',histories.map(item=>({name:item.name,color:colorFor(historyModel(item.name,models),models),points:(item.history||[]).filter(row=>finite(row.epoch)&&finite(row.val_pr_auc_bad)).map(row=>[Number(row.epoch),Number(row.val_pr_auc_bad)])})),'Epoch');
    dots('search-parameter-chart',done,models,state.parameter,state.log&&positive,categories);
    parallel('search-parallel-chart',done,state.dimensions,models);
    for(const [id,key]of [['analytics-model','model'],['analytics-objective','objective'],['analytics-parameter','parameter']])$(id).addEventListener('change',event=>{state[key]=event.target.value;search(state.data);});
    $('analytics-log').addEventListener('change',event=>{state.log=event.target.checked;search(state.data);});
    target.querySelectorAll('[data-analytics-dimension]').forEach(input=>input.addEventListener('change',event=>{const key=event.target.dataset.analyticsDimension;if(event.target.checked){if(state.dimensions.length>=5){event.target.checked=false;return;}state.dimensions.push(key);}else state.dimensions=state.dimensions.filter(value=>value!==key);parallel('search-parallel-chart',done,state.dimensions,models);}));
  }
  function historyModel(name,models) { return models.find(model=>String(name).split('/').includes(model)||String(name).split('/').some(part=>part.startsWith(model+'_seed')))||null; }
  function outcome(row) {
    const value=String(row.outcome||row.state||'').toUpperCase();
    if(value.includes('TIMEOUT'))return 'TIMEOUT';if(value.includes('PAUSE'))return 'PAUSED';if(row.state==='FAIL'||value==='FAILED')return 'FAILED';return ['COMPLETE','PRUNED','RUNNING','WAITING'].includes(value)?value:String(row.state||'WAITING');
  }
  function comparison(data) {
    const host=$('analytics-compare');if(!host)return;
    const candidates=(data.candidates||[]).filter(candidate=>candidate.selection_metrics),metrics=[['pr_auc_bad','AP · bad',false],['balanced_accuracy','Balanced accuracy',false],['bad_escape_rate','Bad escape',true],['good_reject_rate','Good rejection',true]];
    host.innerHTML=`<div class="analytics-heading"><div><span class="eyebrow">SELECTION SPLIT</span><h2>Compare candidate decisions</h2><p class="hint">All values below come from the recorded selection split. AP describes ranking; escape and rejection depend on the saved decision threshold.</p></div></div>`+
      card('model-comparison','Performance across candidates',candidates.length?`<div class="analytics-comparison">${metrics.map(([key,label,lower])=>`<div><h3>${label}</h3><p class="hint">${lower?'Lower is better':'Higher is better'}</p>${candidates.map((candidate,index)=>{const value=valueOf(candidate.selection_metrics[key]);return `<div class="analytics-row"><span title="${esc(candidate.name)}">${esc(candidate.name)}</span><div class="analytics-track">${value===null?'':`<i style="width:${Math.max(0,Math.min(1,value))*100}%;background:${palette[index%palette.length]}"></i>`}</div><strong>${value===null?'Not available':number(value)}</strong></div>`;}).join('')}</div>`).join('')}</div>`:empty('Completed and evaluated candidates will appear here.'))+
      card('model-confusions','Confusion matrices · every candidate',`<div class="analytics-matrices">${candidates.map(candidate=>matrix(candidate)).join('')||empty('No candidate confusion matrices are available.')}</div><p class="hint">Counts and percentages within each true class are shown. Bad is the positive class. Repeated use of selection results for development does not provide independent test qualification.</p>`);
  }
  function matrix(candidate) {
    const m=candidate.selection_metrics,keys=['bad_detected_TP','bad_passed_as_good_FN','good_rejected_as_bad_FP','good_accepted_TN'];
    if(!m||!keys.every(key=>finite(m[key])))return '';
    const values=keys.map(key=>Number(m[key])),[tp,fn,fp,tn]=values;
    const cell=(value,total,label,correct)=>`<div class="${correct?'correct':'wrong'}"><strong>${value}</strong>${label}<small>${total?number(value/total*100,1)+'% of true '+(label==='TP'||label==='FN'?'bad':'good'):'No reference images'}</small></div>`;
    return `<section><h3>${esc(candidate.name)}</h3><div class="cm"><div class="axis">Reference / prediction</div><div class="axis">Bad</div><div class="axis">Good</div><div class="axis">Bad</div>${cell(tp,tp+fn,'TP',true)}${cell(fn,tp+fn,'FN',false)}<div class="axis">Good</div>${cell(fp,fp+tn,'FP',false)}${cell(tn,fp+tn,'TN',true)}</div><p class="hint">${tp+fn} bad / ${fp+tn} good reference images</p></section>`;
  }
  function render(data) {if(!data)return;if(state.run!==data.path){state.run=data.path;state.model='';state.objective='';state.parameter='';state.dimensions=[];}state.data=data;search(data);comparison(data);}
  return {render};
})();
