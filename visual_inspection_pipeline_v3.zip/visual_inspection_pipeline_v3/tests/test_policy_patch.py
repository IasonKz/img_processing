"""Regression tests for the excessive-rejection policy bug and cached-score review.

Synthetic scores deliberately include difficult and degenerate classifiers.
These tests are not measurements of the user's images or neural checkpoints.
"""
import copy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

from nilt.common import read_json, write_json, sha_file
from nilt.policy import (metrics, tune_threshold, tune_threshold_details, threshold_curve,
                         empirical_pass, selection_key)
from test_integration_v2 import fixture_run
from review_thresholds import review

POLICY = {'max_bad_escape_rate': .01, 'max_good_reject_rate': .20, 'threshold_margin': True}


class ThresholdPatchTests(unittest.TestCase):
    def test_old_normalized_penalty_rejects_everything_but_balanced_fallback_does_not(self):
        y = [0] * 10 + [1] * 40
        s = np.array([.1] * 2 + [.9] * 8 + [.2] * 40)
        curve = threshold_curve(y, s)
        old_penalty = np.maximum(curve['bad_escape_rate'] / .01 - 1, 0) ** 2
        old_penalty += np.maximum(curve['good_reject_rate'] / .2 - 1, 0) ** 2
        old = metrics(y, s, curve['threshold'][np.argmin(old_penalty)])
        self.assertEqual(old['good_reject_rate'], 1.)
        tuned = tune_threshold_details(y, s, POLICY)
        actual = metrics(y, s, tuned['threshold'])
        self.assertFalse(tuned['targets_feasible'])
        self.assertFalse(empirical_pass(actual, POLICY))
        self.assertEqual(actual['good_reject_rate'], 0.)
        self.assertAlmostEqual(actual['bad_escape_rate'], .2)
        self.assertAlmostEqual(actual['balanced_accuracy'], .9)

    def test_feasible_targets_preserved_and_margin_does_not_change_labels(self):
        y = [0, 0, 0, 1, 1, 1]
        s = np.array([.6, .8, .9, .1, .2, .3])
        policy = {**POLICY, 'max_bad_escape_rate': 0., 'max_good_reject_rate': 0.}
        decision = tune_threshold_details(y, s, policy)
        self.assertTrue(decision['targets_feasible'])
        self.assertTrue(empirical_pass(metrics(y, s, decision['threshold']), policy))
        exact = tune_threshold(y, s, {**policy, 'threshold_margin': False})
        np.testing.assert_array_equal(s >= exact, s >= decision['threshold'])

    def test_constant_scores_are_flagged_without_fabricating_separation(self):
        details = tune_threshold_details([0, 0, 1, 1], [7.] * 4, POLICY)
        self.assertFalse(details['targets_feasible'])
        self.assertFalse(details['better_than_constant_on_calibration'])
        self.assertEqual(details['best_balanced_accuracy_on_calibration'], .5)

    def test_extreme_endpoints_and_adjacent_float_midpoints(self):
        y, s = [0, 1], np.array([.2, .8])
        t = tune_threshold(y, s, {'max_bad_escape_rate': 1., 'max_good_reject_rate': 0., 'threshold_margin': True})
        self.assertTrue(np.all(s < t))
        lower = .5
        upper = np.nextafter(lower, np.inf)
        for margin in (False, True):
            t = tune_threshold([1, 0], [lower, upper], {**POLICY, 'threshold_margin': margin})
            self.assertTrue(lower < t <= upper)

    def test_anomaly_scale_and_row_order_invariance(self):
        y = np.array([0, 0, 0, 1, 1, 1])
        s = np.array([.1, .8, .9, .2, .5, .7])
        t = tune_threshold(y, s, POLICY)
        scaled = tune_threshold(y, s * 37 + 12, POLICY)
        np.testing.assert_array_equal(s >= t, s * 37 + 12 >= scaled)
        self.assertEqual(t, tune_threshold(y[::-1], s[::-1], POLICY))

    def test_matches_exhaustive_independent_decision_enumeration(self):
        rng = np.random.default_rng(731)
        for _ in range(100):
            y = np.r_[np.zeros(7, dtype=int), np.ones(31, dtype=int)]
            s = rng.integers(0, 12, len(y)).astype(float)
            policy = {'max_bad_escape_rate': float(rng.choice([0, .01, .2, 1.])),
                      'max_good_reject_rate': float(rng.choice([0, .2, .5, 1.]))}
            possible = np.r_[np.unique(s), np.nextafter(s.max(), np.inf)]
            outcomes = []
            for threshold in possible:
                bad = s >= threshold
                be = np.mean(~bad[y == 0])
                gr = np.mean(bad[y == 1])
                outcomes.append((threshold, be, gr, 1 - (be + gr) / 2))
            feasible = [r for r in outcomes if r[1] <= policy['max_bad_escape_rate'] + 1e-12 and r[2] <= policy['max_good_reject_rate'] + 1e-12]
            details = tune_threshold_details(y, s, policy)
            if feasible:
                self.assertTrue(details['targets_feasible'])
                self.assertEqual(details['threshold'], max(r[0] for r in feasible))
            else:
                self.assertFalse(details['targets_feasible'])
                self.assertAlmostEqual(details['balanced_accuracy'], max(r[3] for r in outcomes))

    def test_selector_prefers_useful_fallback_to_all_bad_and_never_calls_it_feasible(self):
        def candidate(name, be, gr):
            return {'name': name, 'members': [1], 'selection_metrics': {'bad_escape_rate': be, 'good_reject_rate': gr, 'pr_auc_bad': .5}}
        useless = candidate('all_bad', 0., 1.)
        useful = candidate('useful', .2, .1)
        feasible = candidate('feasible', 0., .2)
        self.assertLess(selection_key(useful, POLICY), selection_key(useless, POLICY))
        self.assertLess(selection_key(feasible, POLICY), selection_key(useful, POLICY))
        feasible['threshold_metrics'] = useless['selection_metrics']
        self.assertEqual(selection_key(feasible, POLICY)[0], 1)

    def test_baselines_and_label_direction_match_reported_counts(self):
        # These scores reproduce the screenshot's confusion counts only.
        y = [0] * 50 + [1] * 198
        s = [.8] * 49 + [.1] + [.3] * 175 + [.05] * 23
        m = metrics(y, s, .1437)
        self.assertEqual((m['bad_detected_TP'], m['bad_passed_as_good_FN'], m['good_rejected_as_bad_FP'], m['good_accepted_TN']), (49, 1, 175, 23))
        self.assertAlmostEqual(m['accuracy'], 72 / 248)
        self.assertAlmostEqual(m['majority_baseline_accuracy'], 198 / 248)
        self.assertAlmostEqual(m['balanced_accuracy'], (.98 + 23 / 198) / 2)

    def test_invalid_policy_values_are_rejected(self):
        for value in (float('nan'), float('inf'), -.1, 1.1, True, '0.1'):
            with self.subTest(value=value), self.assertRaises(ValueError):
                tune_threshold([0, 1], [.9, .1], {**POLICY, 'max_good_reject_rate': value})


class CachedReviewTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.run, self.data, self.rows = fixture_run(self.root, threshold=.1)
        self.score_root = self.run / 'scores' / 'patchcore_seed42'
        self.score_root.mkdir(parents=True)
        for split in ('threshold', 'selection'):
            np.save(self.score_root / (split + '.npy'), [.1, .9, .2, .3])

    def tearDown(self):
        self.temp.cleanup()

    def hashes(self):
        return {p.relative_to(self.run): sha_file(p) for p in self.run.rglob('*') if p.is_file()}

    def test_review_is_read_only_and_no_model_call_or_test_scores(self):
        before = self.hashes()
        with patch('nilt.workflow.predict_members', side_effect=AssertionError('No inference allowed')):
            first = review(self.run, self.root / 'reviews', True)
            second = review(self.run, self.root / 'reviews')
        self.assertNotEqual(first, second)
        self.assertEqual(before, self.hashes())
        summary = read_json(first / 'review_summary.json')
        self.assertFalse(summary['targets_met_on_calibration_and_selection'])
        self.assertEqual(summary['qualification'], 'NOT_INDEPENDENTLY_VALIDATED')
        self.assertEqual(sum(1 for p in (first / 'revised_predictions' / 'predicted').rglob('*.png')), 4)
        self.assertEqual(read_json(first / 'decision.json')['selected_sha256'], sha_file(self.run / 'selected.json'))

    def test_selection_scores_cannot_change_fitted_threshold(self):
        first = review(self.run, self.root / 'reviews')
        np.save(self.score_root / 'selection.npy', [.9, .1, .9, .1])
        second = review(self.run, self.root / 'reviews')
        a, b = read_json(first / 'decision.json'), read_json(second / 'decision.json')
        self.assertEqual(a['threshold'], b['threshold'])

    def test_new_cache_provenance_detects_score_tampering(self):
        write_json(self.score_root / 'provenance.json', {'manifest_sha256': sha_file(self.run / 'manifest.csv'),
                  'candidate': 'patchcore_seed42', 'files': {n: sha_file(self.score_root / n) for n in ('threshold.npy', 'selection.npy')}})
        np.save(self.score_root / 'selection.npy', [.1, .1, .2, .2])
        with self.assertRaisesRegex(ValueError, 'hash mismatch'):
            review(self.run, self.root / 'reviews')

    def test_nested_output_rejected(self):
        for output in (self.data / 'outputs', self.run / 'outputs'):
            with self.assertRaisesRegex(ValueError, 'outside'):
                review(self.run, output)

    def test_interrupted_selection_replaces_stale_exports_without_overwriting_them(self):
        from contextlib import ExitStack
        from types import SimpleNamespace
        import importlib.metadata
        from nilt.workflow import run_training
        # These are disposable synthetic fixtures, not user result files.
        (self.run / 'selected.json').unlink()
        (self.run / 'selection_integrity.json').unlink()
        model = self.run / 'models' / 'patchcore_seed42'
        write_json(model / 'completed.json', {'checkpoint_sha256': sha_file(model / 'best.pt'), 'best_val_pr_auc_bad': 1.})
        export = self.run / 'comparison_folders' / 'patchcore_seed42'
        export.mkdir(parents=True)
        write_json(export / 'export_complete.json', {'n_images': 4})
        write_json(export / 'decision_rule.json', {'threshold': .1})
        write_json(export / 'metrics.json', {'accuracy': .5})
        fake_torch = SimpleNamespace(__version__='mock', version=SimpleNamespace(cuda=None), cuda=SimpleNamespace(is_available=lambda: False))
        fake_tv = SimpleNamespace(__version__='mock')
        real_version = importlib.metadata.version
        def predict(run, members, rows, cfg):
            return np.array([.9 if r['label'] == 0 else .1 for r in rows]), .01
        with ExitStack() as stack:
            stack.enter_context(patch('nilt.engine.check_weights'))
            stack.enter_context(patch('nilt.engine.torch_modules', return_value=(fake_torch, fake_tv)))
            stack.enter_context(patch('nilt.workflow.predict_members', side_effect=predict))
            stack.enter_context(patch('importlib.metadata.version', side_effect=lambda name: 'mock' if name in ('torch', 'torchvision') else real_version(name)))
            run_training(self.run)
        revised = read_json(export / 'decision_rule.json')
        self.assertNotEqual(revised['threshold'], .1)
        archived = list(export.parent.glob('patchcore_seed42_superseded_*'))
        self.assertEqual(len(archived), 1)
        self.assertEqual(read_json(archived[0] / 'decision_rule.json')['threshold'], .1)
        self.assertIn('balanced_accuracy', read_json(export / 'metrics.json'))


if __name__ == '__main__':
    unittest.main()
