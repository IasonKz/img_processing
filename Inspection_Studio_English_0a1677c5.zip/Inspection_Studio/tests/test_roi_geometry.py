from __future__ import annotations

import math
import tempfile
import unittest
from pathlib import Path

import numpy as np
from PIL import Image
import cv2

from nilt.roi.geometry import default_template, normalize_template, template_to_rois, transform_points, roi_bounds
from nilt.roi.localization import localize
from nilt.roi.crops import crop_roi, mask_for_roi


class ROIGeometryTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.directory=Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def image(self,name,pixels):
        path=self.directory/name
        if pixels.dtype==np.uint16:
            encoded=cv2.imencode(path.suffix,pixels[:,:,::-1] if pixels.ndim==3 else pixels)[1]
            path.write_bytes(encoded.tobytes())
        else:
            Image.fromarray(pixels).save(path)
        return path

    def synthetic(self,asymmetric=True):
        template=default_template("bottom")
        template["starter"]=False
        template["reference_size"]=[320,320]
        pixels=np.full((320,320,3),20,np.uint8)
        cv2.rectangle(pixels,(25,25),(294,294),(90,90,90),-1)
        for roi in template_to_rois(template,[320,320]):
            if not asymmetric and roi["kind"]!="pins":
                continue
            mask=mask_for_roi(roi,[320,320])
            pixels[mask>0]=220
        return template,pixels

    def test_default_stable_ids_and_nested_shapes(self):
        bottom=normalize_template(default_template("bottom"))
        self.assertEqual(len(bottom["rois"]),18)
        self.assertEqual({r["id"] for r in bottom["rois"] if r["kind"]=="pins"},
                         {f"pin_r{r}_c{c}" for r in range(1,5) for c in range(1,5)})
        top=template_to_rois(default_template("top"),[600,600])
        masks={r["id"]:mask_for_roi(r,[600,600]) for r in top}
        self.assertTrue(np.logical_and(masks["inner_area"],masks["lens"]).any())
        self.assertEqual(next(r for r in top if r["id"]=="lens_center")["shape"],"point")

    def test_legacy_import_uses_image_coordinates_not_rectified_die(self):
        original={"schema":"camera_geometry_annotation.v1","side":"TOP",
                  "source_image":{"width_pixels":101,"height_pixels":201},
                  "rois":[{"name":"camera_center","shape":"Point / center",
                            "image_pixel_points":[[25,150]],"die_frame_normalized_points":[[.5,.5]]},
                          {"name":"inner_octagon","shape":"Polygon ROI",
                           "image_normalized_points":[[.2,.2],[.8,.2],[.8,.8],[.2,.8]]}]}
        result=normalize_template(original)
        self.assertEqual(result["rois"][0]["points"],[[.25,.75]])
        self.assertEqual(result["rois"][1]["id"],"inner_area")
        result["version"]="revision-a123"
        self.assertEqual(normalize_template(result)["version"],"revision-a123")
        with self.assertRaises(ValueError):
            normalize_template(original,"bottom")

    def test_template_transform_preserves_missing_slots(self):
        template=default_template("bottom")
        matrix=np.array([[0.,-1.,610.],[1.,0.,5.],[0.,0.,1.]])
        rois=template_to_rois(template,[650,650],matrix)
        self.assertEqual(len(rois),18)
        pin=next(r for r in rois if r["id"]=="pin_r2_c3")
        self.assertEqual(pin["source"],"inferred")
        self.assertIsNone(pin["observed_points"])
        self.assertEqual(pin["points"],pin["expected_points"])
        self.assertAlmostEqual(pin["points"][0][0],610-.425*599)

    def test_native_depth_crop_keeps_context_and_masks_independent(self):
        pixels=np.arange(30*40*3,dtype=np.uint16).reshape(30,40,3)*13
        path=self.image("native.png",pixels)
        roi={"id":"pin","kind":"pins","shape":"circle","points":[[20.,15.],[24.,15.]],"margin":.5}
        crop,mask,metadata=crop_roi(path,roi)
        self.assertEqual(crop.dtype,np.uint16)
        self.assertEqual(crop[8,8].tolist(),pixels[15,20].tolist())
        self.assertEqual(mask[0,0],0)
        self.assertTrue(np.any(crop[mask==0]>0))
        self.assertFalse(metadata["clipped"])
        masked,mask2,_=crop_roi(path,roi,{"masked":True})
        self.assertTrue(np.array_equal(mask,mask2))
        self.assertTrue(np.all(masked[mask==0]==0))

    def test_crop_boundary_padded_and_flagged(self):
        path=self.image("edge.png",np.full((20,20,3),99,np.uint8))
        roi={"id":"edge","kind":"pins","shape":"circle","points":[[2.,2.],[6.,2.]],"margin":0}
        crop,mask,metadata=crop_roi(path,roi)
        self.assertTrue(metadata["clipped"])
        self.assertTrue(metadata["needs_review"])
        self.assertLess(metadata["valid_fraction"],1.)
        self.assertEqual(crop[0,0,0],0)

    def test_canonical_crop_preserves_bit_depth_and_inverse_mapping(self):
        pixels=np.zeros((60,60,3),np.uint16); pixels[25:36,20:41]=50123
        path=self.image("rotated.png",pixels)
        roi={"id":"label","kind":"label","shape":"polygon","points":[[20,25],[40,25],[40,35],[20,35]],"margin":.1}
        matrix=np.array([[0,-1,59],[1,0,0],[0,0,1]],float)
        crop,mask,meta=crop_roi(path,roi,{"canonical":True},matrix)
        self.assertEqual(crop.dtype,np.uint16)
        self.assertGreater(crop.max(),50000)
        np.testing.assert_allclose(np.array(meta["crop_to_image"])@np.array(meta["image_to_crop"]),np.eye(3),atol=1e-8)
        self.assertEqual(mask.dtype,np.uint8)

    def test_corner_normalization_rotates_without_mirroring(self):
        pixels=np.zeros((80,80,3),np.uint16)
        patch=(np.arange(11*11*3,dtype=np.uint16).reshape(11,11,3)+1)*100
        pixels[10:21,50:61]=patch
        pixels[50:61,10:21]=patch[::-1,::-1]
        path=self.image("corners.png",pixels)
        tr={"id":"corner_TR","kind":"corners","shape":"polygon","points":[[50,10],[60,10],[60,20],[50,20]],"margin":0}
        bl={"id":"corner_BL","kind":"corners","shape":"polygon","points":[[10,50],[20,50],[20,60],[10,60]],"margin":0}
        settings={"canonical":True,"normalize_corners":True}
        crop_tr,_,meta_tr=crop_roi(path,tr,settings,np.eye(3))
        crop_bl,_,meta_bl=crop_roi(path,bl,settings,np.eye(3))
        np.testing.assert_array_equal(crop_tr,patch)
        np.testing.assert_array_equal(crop_bl,crop_tr)
        self.assertEqual(meta_bl["applied_rotation_degrees"],180.)
        self.assertEqual(meta_tr["applied_rotation_degrees"],0.)
        self.assertGreater(np.linalg.det(np.array(meta_bl["image_to_crop"])[:2,:2]),0.)
        np.testing.assert_allclose(transform_points([[0,0]],meta_bl["crop_to_image"]),[[20,60]])
        unrotated,_,_=crop_roi(path,bl,{"canonical":True},np.eye(3))
        np.testing.assert_array_equal(unrotated,patch[::-1,::-1])

    def test_blank_input_never_confident(self):
        path=self.image("blank.png",np.zeros((120,120,3),np.uint8))
        output=localize(path,default_template("bottom"))
        self.assertTrue(output["needs_review"])
        self.assertEqual(len(output["rois"]),18)
        self.assertLess(output["confidence"],.7)
        self.assertIn("insufficient_image_contrast",output["reasons"])

    def test_rotated_reference_registration_keeps_missing_pin(self):
        template,pixels=self.synthetic()
        reference=self.image("reference.png",pixels)
        missing=template_to_rois(template,[320,320])[0]
        broken=pixels.copy(); broken[mask_for_roi(missing,[320,320])>0]=90
        matrix=np.vstack([cv2.getRotationMatrix2D((159.5,159.5),-94,1.02),[0,0,1]])
        matrix[:2,2]+=[3,-2]
        target=cv2.warpAffine(broken,matrix[:2],(320,320),borderValue=(20,20,20))
        target_path=self.image("target.png",target)
        output=localize(target_path,template,reference)
        self.assertEqual(len(output["rois"]),18)
        expected=transform_points([[159.5,159.5]],matrix)[0]
        actual=transform_points([[159.5,159.5]],output["transform"])[0]
        np.testing.assert_allclose(actual,expected,atol=3.)
        self.assertLess(abs(output["orientation_degrees"]-94),3.)
        pin=next(r for r in output["rois"] if r["id"]=="pin_r1_c1")
        self.assertEqual(pin["source"],"inferred")
        self.assertIsNone(pin["observed_points"])

    def test_symmetric_grid_requires_orientation_review(self):
        template,pixels=self.synthetic(asymmetric=False)
        path=self.image("symmetric.png",pixels)
        output=localize(path,template,path)
        self.assertTrue(output["needs_review"])
        self.assertIn("ambiguous_quarter_turn",output["reasons"])

    def test_invalid_geometry_rejected(self):
        template=default_template("top")
        template["rois"][0]["points"][0][0]=float("nan")
        with self.assertRaises(ValueError):
            normalize_template(template)


if __name__=="__main__":
    unittest.main()
