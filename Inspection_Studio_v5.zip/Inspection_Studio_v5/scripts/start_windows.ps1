[CmdletBinding()]
param(
    [string]$Config = 'project.yaml',
    [ValidateRange(1024, 65535)]
    [int]$Port = 8765,
    [switch]$NoBrowser
)

$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$InterpreterRecord = Join-Path $ProjectRoot '.studio-python.txt'
if (-not (Test-Path -LiteralPath $InterpreterRecord)) {
    throw 'This computer has not been set up for this project. Run Setup.cmd first.'
}
$PythonExe = (Get-Content -LiteralPath $InterpreterRecord -Raw).Trim()
if (-not (Test-Path -LiteralPath $PythonExe -PathType Leaf)) {
    throw 'The recorded Python environment is unavailable. Run Setup.cmd on this computer.'
}
Push-Location $ProjectRoot
try {
    if (-not (Test-Path -LiteralPath $Config -PathType Leaf)) { throw "Configuration not found: $Config" }
    $LaunchArguments = @('inspection.py', 'dashboard', '--config', $Config, '--port', "$Port")
    if ($NoBrowser) { $LaunchArguments += '--no-browser' }
    & $PythonExe @LaunchArguments
    if ($LASTEXITCODE -ne 0) { throw "Dashboard exited with code $LASTEXITCODE. Read the error above." }
}
finally {
    Pop-Location
}
