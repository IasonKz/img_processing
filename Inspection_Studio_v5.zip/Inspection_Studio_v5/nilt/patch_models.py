"""Native-resolution global + patch multiple-instance supervised classifier.

Each image remains one labelled training example. The shared pretrained core
sees the complete image and every overlapping patch. There are no patch labels,
no automatic localization claims, and no random dropping of image evidence.
"""
from __future__ import annotations

import torch
from torch.utils.checkpoint import checkpoint

from .preprocessing import patch_boxes, validate_patch_settings


class GlobalPatchClassifier(torch.nn.Module):
    def __init__(self, core, cfg):
        super().__init__()
        self.core = core
        self.settings = validate_patch_settings(cfg)
        self.image_strategy = "global_patches"

    def _run(self, images):
        # Recompute intermediate activations during backward, retaining only
        # one patch-chunk's intermediates at a time. Frozen BN is enforced by
        # configuration; checkpoint preserves dropout RNG for recomputation.
        if torch.is_grad_enabled() and any(p.requires_grad for p in self.core.parameters()):
            return checkpoint(self.core, images, use_reentrant=False)
        return self.core(images)

    def forward(self, images):
        if images.ndim != 4 or images.shape[1] != 3:
            raise ValueError("GlobalPatchClassifier expects normalized NCHW RGB images.")
        _, _, height, width = images.shape
        boxes = patch_boxes(int(width), int(height), self.settings)
        global_logits = self._run(images)
        global_margin = global_logits[:, 0] - global_logits[:, 1]
        margins = []
        size = self.settings["size"]
        # Chunk across patches for each image; this never multiplies the given
        # chunk_size by a possibly large inference batch size.
        for image in images:
            patch_margins = []
            for start in range(0, len(boxes), self.settings["chunk_size"]):
                tensors = []
                for x0, y0, x1, y1 in boxes[start:start + self.settings["chunk_size"]]:
                    crop = image[:, y0:y1, x0:x1]
                    # Zero in normalized space is the pretrained RGB mean.
                    crop = torch.nn.functional.pad(crop, (0, size - (x1-x0), 0, size - (y1-y0)))
                    tensors.append(crop)
                values = self._run(torch.stack(tensors))
                patch_margins.append(values[:, 0] - values[:, 1])
            values = torch.cat(patch_margins)
            if self.settings["aggregation"] == "max":
                pooled = values.max()
            else:
                pooled = values.topk(min(self.settings["topk"], len(values))).values.mean()
            margins.append(pooled)
        local_margin = torch.stack(margins)
        alpha = self.settings["global_weight"]
        margin = alpha * global_margin + (1 - alpha) * local_margin
        # Softmax[:,0] == sigmoid(margin); symmetrical logits eliminate any
        # arbitrary common offset. One loss is applied per original image.
        return torch.stack((margin * .5, -margin * .5), dim=1)
