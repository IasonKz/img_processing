"use strict";
const PreprocessingStudio = (() => {
  let jobs=[], selectedJob="", submitting=false, workspaceBusy=false;
  const currentJob=()=>jobs.find(job=>job.id===$("prep-job").value);
  function payload(){
    const mode=$("prep-mode").value,csv_files=mode==="labelled"?$("prep-csv").value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean):[];
    if(mode==="labelled"&&!csv_files.length)throw Error("Enter at least one local CSV path.");
    if(mode==="untagged"&&!$("prep-folder").value.trim())throw Error("Choose an original tester folder.");
    const white=$("prep-white").value.trim(),white_level=white?Number(white):null;
    if(white&&(!Number.isInteger(white_level)||white_level<1||white_level>65535))throw Error("Sensor white level must be an integer from 1 to 65535.");
    return {mode,csv_files,output:$("prep-output").value.trim(),tray:$(mode==="untagged"?"prep-folder":"prep-tray").value.trim(),
      stage:$("prep-stage").value,top_pattern:$("prep-top-pattern").value,bottom_pattern:$("prep-bottom-pattern").value,vig_pattern:$("prep-vig-pattern").value,
      output_depth:$("prep-depth").value,white_level,vig_brightness:$("prep-brightness").checked,debug:$("prep-debug").checked};
  }
  function modeChanged(){
    const untagged=$("prep-mode").value==="untagged";
    $("prep-labelled").hidden=untagged;$("prep-untagged").hidden=!untagged;
    $("prep-tree-labelled").hidden=untagged;$("prep-tree-untagged").hidden=!untagged;
    $("prep-mode-tag").textContent=untagged?"UNTAGGED":"LABELLED";
    $("prep-check").textContent=untagged?"Scan capture names":"Check CSV references";
    $("prep-start").textContent=untagged?"Prepare classification images":"Prepare dataset";
    render();
  }
  function render(){
    const job=currentJob(),report=job?.report||{},running=job?.status==="running";
    const untagged=(job?.mode||report.dataset_kind)==="untagged";
    for(const id of ["prep-check","prep-start"])$(id).disabled=submitting||workspaceBusy;
    $("prep-stop").disabled=!running||job?.stop_requested||submitting;
    $("prep-open").disabled=!job||job.action!=="preprocess"||!report.output;
    const task=$("prep-task").value,counts=report.counts||{};
    $("prep-use").textContent=untagged?"Use prepared images → classify":"Use prepared dataset → setup";
    $("prep-use").disabled=!job||job.action!=="preprocess"||!report.complete||report.dry_run||
      !["finished","ended"].includes(job.status)||!(untagged?counts[task]:((counts[task+"/good"]||0)+(counts[task+"/bad"]||0)));
    if(!job)return;
    const label=untagged?(job.action==="preprocess-check"?"Capture name scan":"Untagged preparation"):(job.action==="preprocess-check"?"CSV reference check":"Dataset preparation");
    const progress=[...(job.lines||[])].reverse().find(line=>/^\[\d+\/\d+\]/.test(line))||"";
    $("prep-status").textContent=`${label} · ${job.status}${job.stop_requested?" · stop requested":""}${running&&progress?" · "+progress:""}`;
    const results=$("prep-results");
    if(!report.counts){
      results.className="empty";
      results.textContent=running?"Reading inputs and processing images. Live details appear in the operation log below.":
        (job.lines||[]).slice(-4).join("\n")||"Read the operation log for this result.";
      return;
    }
    results.className="";
    const rows=["vig","top","bottom"].map(task=>`<tr><th scope="row">${task.toUpperCase()}</th>${untagged?`<td>${counts[task]||0}</td>`:`<td>${counts[task+"/good"]||0}</td><td>${counts[task+"/bad"]||0}</td><td>${(counts[task+"/good"]||0)+(counts[task+"/bad"]||0)}</td>`}</tr>`).join("");
    const issues=Object.entries(untagged?(report.skipped_reasons||{}):(report.csv_issues||{})).filter(([,count])=>count).map(([key,count])=>`${escapeHtml(key)}: ${count}`).join(" · ");
    results.innerHTML=`<div class="preparation-kpis"><div><strong>${report.dry_run?report.total_images:report.processed_images}</strong><span>${report.dry_run?"SELECTED IMAGES":"PROCESSED IMAGES"}</span></div><div><strong>${report.failed_images||0}</strong><span>PROCESSING FAILURES</span></div><div><strong>${untagged?(report.skipped_images||0):(report.omitted_references||0)}</strong><span>${untagged?"SKIPPED CAPTURES":"CSV OMISSIONS"}</span></div><div><strong>${report.cancelled?"Stopped":report.complete?"Complete":"Review"}</strong><span>${report.dry_run?"INPUT CHECK ONLY":"PREPARATION STATUS"}</span></div></div><div class="table-scroll"><table><thead><tr><th>Task</th>${untagged?"<th>Untagged images</th>":"<th>Good</th><th>Bad</th><th>Total</th>"}</tr></thead><tbody>${rows}</tbody></table></div>${issues?`<p class="hint">${untagged?"Skipped":"CSV"} details: ${issues}</p>`:""}${untagged&&!report.dry_run?`<p class="hint">No labels assigned · ${escapeHtml(report.stage)} captures. Failed originals: ${escapeHtml(report.review_folder)}${report.debug_folder?` · Overlays: ${escapeHtml(report.debug_folder)}`:""}</p>`:""}<p class="hint">${report.dry_run?"Geometry and pixel conversion have not been evaluated. No dataset images were written.":escapeHtml(report.output)}</p>`;
  }
  function stateChanged(state){
    jobs=state.preprocessing?.jobs||[];
    workspaceBusy=Boolean(state.workspace_operation)||(state.jobs||[]).some(j=>["running","unverified"].includes(j.status));
    const previous=selectedJob||$("prep-job").value;
    selectOptions("prep-job",[...jobs].reverse().map(job=>({value:job.id,label:`${job.mode==="untagged"?"Untagged":"Labelled"} ${job.action==="preprocess-check"?"check":"prepare"} · ${job.status} · ${new Date(job.started*1000).toLocaleString()}`})),"No preparation yet",previous);
    selectedJob="";render();
  }
  async function start(action){
    submitting=true;render();
    try{const result=await api("/api/action",{action,...payload()});selectedJob=result.job;notify(action==="preprocess-check"?"Input check started.":"Image preparation started. See progress and the operation log.");await refresh();}
    finally{submitting=false;render();}
  }
  const bindLocal=(id,fn)=>$(id).addEventListener("click",()=>Promise.resolve().then(fn).catch(error=>notify(error.message,true)));
  bindLocal("prep-check",()=>start("preprocess-check"));bindLocal("prep-start",()=>start("preprocess"));
  bindLocal("prep-refresh",refresh);
  bindLocal("prep-stop",async()=>{const result=await api("/api/preprocessing/stop",{job:currentJob()?.id});notify(result.message);await refresh();});
  bindLocal("prep-open",async()=>{const result=await api("/api/open-folder",{path:currentJob()?.preprocessing_output});notify(result.message);});
  bindLocal("prep-use",async()=>{
    const task=$("prep-task").value,job=currentJob();
    if(job?.mode==="untagged"){
      const data=await api("/api/preprocessing/use-classification",{job:job.id,task});
      if(WorkspaceStudio.family()!=="classification")WorkspaceStudio.selectFamily("classification");
      if(WorkspaceStudio.task()!==task)WorkspaceStudio.selectTask(task);
      if(WorkspaceStudio.roiScope()!==data.roi_scope)await WorkspaceStudio.setScope(data.roi_scope);
      $("predict-input").value=data.input;$("labeled").checked=false;
      $("workflow-input").value=data.input;$("workflow-labeled").checked=false;
      tab("predict");notify("Untagged images connected. Select a saved decision or system for this task and classify.");
    }else{
      const data=await api("/api/preprocessing/use-dataset",{job:job?.id,task});setup(data);
      if(WorkspaceStudio.task()!==task)WorkspaceStudio.selectTask(task);
      $("task").value=task;$("dataset").value=data.datasets[task];tab("setup");notify("Prepared dataset connected. Audit it before training.");
    }
    await refresh();
  });
  $("prep-job").addEventListener("change",render);$("prep-task").addEventListener("change",render);
  $("prep-mode").addEventListener("change",modeChanged);modeChanged();
  return {stateChanged};
})();
