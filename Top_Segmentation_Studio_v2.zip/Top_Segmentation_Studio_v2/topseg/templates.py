"""Persistent, versioned inner-boundary templates. Never label an entire ROI."""
from pathlib import Path
import numpy as np
from PIL import Image
from .common import atomic_json, read_json, project_lock, utc_now
from .classical import validate_roi


class PolygonTemplates:
    def polygon_template(self):
        path = self.root / 'polygon_template.json'
        return read_json(path) if path.exists() else {'revision': 0, 'enabled': False}

    def save_polygon_template(self, image_id, roi, expected_revision, mode='normalized', enabled=True):
        if mode not in ('normalized', 'pixels') or type(enabled) is not bool:
            raise ValueError('Choose normalized or pixels coordinates and a boolean enabled flag.')
        row = self._row(image_id)
        roi = validate_roi(roi, row['width'], row['height'])
        if roi.get('type') != 'polygon':
            raise ValueError('Draw a Boundary or Octagon before saving a custom polygon.')
        with project_lock(self.root):
            current = self.polygon_template()
            if type(expected_revision) is not int or current['revision'] != expected_revision:
                from .project import ConflictError
                raise ConflictError('The saved polygon changed. Reload before replacing it.')
            result = dict(revision=current['revision']+1, enabled=enabled, mode=mode,
                          width=row['width'], height=row['height'], roi=roi,
                          source_image_id=image_id, updated_at=utc_now())
            atomic_json(self.root / 'polygon_templates' / f"{result['revision']:06d}.json", result)
            atomic_json(self.root / 'polygon_template.json', result)
        return result

    def template_roi(self, width, height, template=None):
        template = self.polygon_template() if template is None else template
        if not template.get('enabled'):
            return None
        if template['mode'] == 'pixels':
            if (width, height) != (template['width'], template['height']):
                raise ValueError('Saved pixel polygon requires equal image dimensions. Use normalized coordinates for mixed sizes.')
            return validate_roi(template['roi'], width, height)
        points = [{'x': p['x'] * (width/template['width']), 'y': p['y'] * (height/template['height'])}
                  for p in template['roi']['points']]
        return validate_roi({'type': 'polygon', 'points': points}, width, height)

    def apply_polygon_template(self, include_approved=False):
        if type(include_approved) is not bool:
            raise ValueError('include_approved must be boolean.')
        changed = []
        with project_lock(self.root):
            template = self.polygon_template()
            if not template.get('enabled'):
                raise ValueError('Save and enable a custom polygon first.')
            selected = []
            for row in self._manifest()['images']:
                old = self._annotation(row['id'])
                if old and old['status'] != 'rejected' and (include_approved or old['status'] != 'approved'):
                    roi = self.template_roi(row['width'], row['height'], template)
                    selected.append((row, old, roi))
            for row, old, roi in selected:
                if roi == old['roi']:
                    continue
                with Image.open(self.mask_path(row['id'])) as im:
                    mask = np.array(im)
                self._save(row['id'], mask, roi, old['revision'], False, False,
                           old.get('notes', ''), old['settings'], 'manual', objects=old.get('objects'), status='draft')
                changed.append(row['id'])
        return {'changed': len(changed), 'ids': changed, 'note': 'Changed annotations are drafts and require review. Defect footprints and revision history are preserved.'}
