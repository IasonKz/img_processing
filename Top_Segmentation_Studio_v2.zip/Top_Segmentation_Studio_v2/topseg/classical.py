"""Classical local-contrast proposals and reviewable lens-boundary suggestions.

Coordinates are continuous image coordinates (image edges are 0 and width /
height); raster decisions use pixel centres. No network or pretrained weights.
"""
from __future__ import annotations
import math
import numpy as np
from scipy import ndimage
from scipy.optimize import least_squares
from scipy.spatial import ConvexHull, QhullError
from .common import DEFAULTS


def default_roi(width, height):
    """A conservative clipped-square lens outline, ready for manual adjustment."""
    radius = .28 * min(width, height)
    cx, cy, cut = width / 2, height / 2, .28 * radius * 2
    return {'type': 'polygon', 'points': [
        {'x': cx + x, 'y': cy + y} for x, y in (
            (-radius + cut, -radius), (radius - cut, -radius),
            (radius, -radius + cut), (radius, radius - cut),
            (radius - cut, radius), (-radius + cut, radius),
            (-radius, radius - cut), (-radius, -radius + cut))]}


def _cross(a, b, c):
    return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])


def _segments_intersect(a, b, c, d):
    eps = 1e-8
    ab_c, ab_d, cd_a, cd_b = _cross(a, b, c), _cross(a, b, d), _cross(c, d, a), _cross(c, d, b)
    if ((ab_c > eps and ab_d < -eps) or (ab_c < -eps and ab_d > eps)) and (
            (cd_a > eps and cd_b < -eps) or (cd_a < -eps and cd_b > eps)):
        return True
    def on_segment(p, q, r, cross):
        return abs(cross) <= eps and min(p[0], q[0]) - eps <= r[0] <= max(p[0], q[0]) + eps and min(p[1], q[1]) - eps <= r[1] <= max(p[1], q[1]) + eps
    return (on_segment(a, b, c, ab_c) or on_segment(a, b, d, ab_d) or
            on_segment(c, d, a, cd_a) or on_segment(c, d, b, cd_b))


def validate_roi(roi, width, height):
    """Normalize a simple polygon or a legacy ellipse without changing its shape."""
    if not (isinstance(width, (int, np.integer)) and isinstance(height, (int, np.integer)) and width > 0 and height > 0):
        raise ValueError('Image width and height must be positive integers.')
    if roi is None:
        roi = default_roi(width, height)
    if not isinstance(roi, dict):
        raise ValueError('Lens ROI must be an object.')
    roi = dict(roi)
    if roi.get('type') == 'polygon':
        if set(roi) != {'type', 'points'} or not isinstance(roi['points'], (list, tuple)) or not 3 <= len(roi['points']) <= 128:
            raise ValueError('Polygon ROI requires 3 to 128 points.')
        points = []
        for point in roi['points']:
            if not isinstance(point, dict) or set(point) != {'x', 'y'}:
                raise ValueError('Each polygon vertex requires x and y.')
            try:
                x, y = float(point['x']), float(point['y'])
            except (TypeError, ValueError, OverflowError) as exc:
                raise ValueError('Polygon coordinates must be finite numbers.') from exc
            if not (math.isfinite(x) and math.isfinite(y) and 0 <= x <= width and 0 <= y <= height):
                raise ValueError('Polygon vertices must be finite and inside the image.')
            points.append((x, y))
        count = len(points)
        if any(math.dist(points[i], points[j]) < 1e-7 for i in range(count) for j in range(i + 1, count)):
            raise ValueError('Polygon vertices must be distinct; do not repeat the first point at the end.')
        for i in range(count):
            # Collinear forward vertices are harmless, but backtracking overlaps an edge.
            a, b, c = points[i - 1], points[i], points[(i + 1) % count]
            if abs(_cross(a, b, c)) <= 1e-8 and np.dot(np.subtract(a, b), np.subtract(c, b)) > 0:
                raise ValueError('Polygon edges must not overlap or backtrack.')
            for j in range(i + 1, count):
                if j == i + 1 or (i == 0 and j == count - 1):
                    continue
                if _segments_intersect(points[i], points[(i + 1) % count], points[j], points[(j + 1) % count]):
                    raise ValueError('Polygon edges must not cross or touch each other.')
        twice_area = abs(sum(points[i][0] * points[(i + 1) % count][1] - points[(i + 1) % count][0] * points[i][1] for i in range(count)))
        if twice_area < 2:
            raise ValueError('Polygon ROI must enclose at least one square pixel.')
        return {'type': 'polygon', 'points': [{'x': x, 'y': y} for x, y in points]}
    if roi.get('type') == 'ellipse':
        roi.pop('type')
    if set(roi) != {'cx', 'cy', 'rx', 'ry'}:
        raise ValueError('Lens ROI requires polygon points or cx, cy, rx, ry.')
    try:
        roi = {key: float(value) for key, value in roi.items()}
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError('Lens ROI values must be finite numbers.') from exc
    if not all(math.isfinite(value) for value in roi.values()):
        raise ValueError('Lens ROI values must be finite.')
    if not (0 <= roi['cx'] <= width and 0 <= roi['cy'] <= height and
            1 <= roi['rx'] <= width and 1 <= roi['ry'] <= height):
        raise ValueError('Lens center must be inside the image; radii must be at least one pixel and no larger than the image.')
    return roi


def roi_mask(roi, width, height):
    """Boolean inside mask using the same pixel-centre even/odd rule as the UI."""
    roi = validate_roi(roi, width, height)
    yy, xx = np.ogrid[:height, :width]
    x, y = xx + .5, yy + .5
    if roi.get('type') != 'polygon':
        return ((x - roi['cx']) / roi['rx']) ** 2 + ((y - roi['cy']) / roi['ry']) ** 2 <= 1
    inside = np.zeros((height, width), dtype=bool)
    points = roi['points']
    for a, b in zip(points, points[1:] + points[:1]):
        ax, ay, bx, by = a['x'], a['y'], b['x'], b['y']
        dx, dy = bx - ax, by - ay
        if dy:
            inside ^= ((ay > y) != (by > y)) & (x < ax + (y - ay) * dx / dy)
    return inside


def reclassify_mask(mask, roi):
    """Classify annotated pixels by location; never annotate clean pixels."""
    values = np.asarray(mask)
    if values.ndim != 2 or not (np.issubdtype(values.dtype, np.number) or values.dtype == np.bool_) or not np.isfinite(values).all():
        raise ValueError('Annotation mask must be a finite two-dimensional numeric array.')
    height, width = values.shape
    inside = roi_mask(roi, width, height)
    return np.where(values != 0, np.where(inside, 1, 2), 0).astype(np.uint8)


def _boundary_distance(roi, width, height, inside):
    """Euclidean distance to polygon segments, or to the raster ellipse boundary.

    A distance transform for ellipses replaces the former normalized-radius
    approximation, which substantially under-guarded elongated ellipses.
    """
    if roi.get('type') != 'polygon':
        boundary = inside ^ ndimage.binary_erosion(inside, border_value=0)
        # The continuous boundary falls within half a pixel diagonal of this band.
        return np.maximum(0., ndimage.distance_transform_edt(~boundary) - math.sqrt(.5))
    yy, xx = np.ogrid[:height, :width]
    x, y = xx + .5, yy + .5
    distance2 = np.full((height, width), np.inf)
    points = roi['points']
    for a, b in zip(points, points[1:] + points[:1]):
        dx, dy = b['x'] - a['x'], b['y'] - a['y']
        t = np.clip(((x - a['x']) * dx + (y - a['y']) * dy) / (dx * dx + dy * dy), 0, 1)
        distance2 = np.minimum(distance2, (x - a['x'] - t * dx) ** 2 + (y - a['y'] - t * dy) ** 2)
    return np.sqrt(distance2)


def _simplify_hull(points):
    """Remove raster stair steps, retaining between four and eight corners."""
    polygon = np.asarray(points, dtype=float)
    tolerance = max(1., .007 * min(np.ptp(polygon[:, 0]), np.ptp(polygon[:, 1])))
    while len(polygon) > 4:
        a, c = np.roll(polygon, 1, axis=0), np.roll(polygon, -1, axis=0)
        delta = c - a
        distance = np.abs(delta[:, 0] * (polygon[:, 1] - a[:, 1]) - delta[:, 1] * (polygon[:, 0] - a[:, 0])) / np.maximum(1e-12, np.linalg.norm(delta, axis=1))
        index = int(np.argmin(distance))
        if len(polygon) <= 8 and distance[index] > tolerance:
            break
        polygon = np.delete(polygon, index, axis=0)
    return polygon



def _refine_edge_positions(polygon, smooth):
    """Snap fitted straight sides to nearby gradient peaks before intersecting them."""
    equations = []
    for a, b in zip(polygon, np.roll(polygon, -1, axis=0)):
        vector = b - a
        length = np.linalg.norm(vector)
        normal = np.array([-vector[1], vector[0]]) / max(length, 1e-12)
        t = np.linspace(.18, .82, max(12, int(length / 2)))
        xy = a[None] + t[:, None] * vector[None]
        offsets = np.linspace(-4., 4., 33)
        strengths = []
        for offset in offsets:
            before, after = xy + (offset - .8) * normal, xy + (offset + .8) * normal
            contrast = np.abs(ndimage.map_coordinates(smooth, [before[:, 1], before[:, 0]], order=1, mode='nearest') - ndimage.map_coordinates(smooth, [after[:, 1], after[:, 0]], order=1, mode='nearest'))
            strengths.append(float(np.median(contrast)))
        offset = offsets[int(np.argmax(strengths))]
        equations.append((normal, float(normal @ a + offset)))
    result = []
    for index, (normal, value) in enumerate(equations):
        previous_normal, previous_value = equations[index - 1]
        matrix = np.array([previous_normal, normal])
        if abs(np.linalg.det(matrix)) < 1e-6:
            return polygon
        point = np.linalg.solve(matrix, [previous_value, value])
        if np.linalg.norm(point - polygon[index]) > 8:
            return polygon
        result.append(point)
    result = np.array(result)
    if (result[:, 0] < 0).any() or (result[:, 0] > smooth.shape[1]).any() or (result[:, 1] < 0).any() or (result[:, 1] > smooth.shape[0]).any():
        return polygon
    return result


def _sample_boundary_contrast(smooth, xy, normal, distance=2.):
    """Sample original pixel centres across an edge, without resizing an image."""
    before, after = xy - distance * normal, xy + distance * normal
    return np.abs(ndimage.map_coordinates(smooth, [before[..., 1] - .5, before[..., 0] - .5], order=1, mode='nearest') -
                  ndimage.map_coordinates(smooth, [after[..., 1] - .5, after[..., 0] - .5], order=1, mode='nearest'))


def _guided_inner_roi(gray, fallback, metadata):
    """Fit a bounded similarity transform to straight edges near a saved shape.

    Each side is searched independently first; a robust, joint fit then retains
    the exact corner proportions. Sustained evidence on *every* fitted side is
    required, so a few strong intersections with circular rings are insufficient.
    """
    if fallback.get('type') != 'polygon':
        metadata['note'] = 'Guided fitting requires a polygon. Draw or save a polygon, or choose automatic detection.'
        return fallback, metadata
    points = np.array([[p['x'], p['y']] for p in fallback['points']], dtype=float)
    # A deliberately concave custom region is valid annotation geometry, but is
    # not a lens-outline template for this straight-side detector.
    turns = np.array([_cross(a, b, c) for a, b, c in zip(points, np.roll(points, -1, axis=0), np.roll(points, -2, axis=0))])
    if np.any(turns > 1e-7) and np.any(turns < -1e-7):
        metadata['note'] = 'Guided fitting requires a convex polygon. The current custom outline was kept.'
        return fallback, metadata
    height, width = gray.shape
    center = points.mean(axis=0)
    span = float(min(np.ptp(points[:, 0]), np.ptp(points[:, 1])))
    max_shift = min(48., max(4., .08 * span))
    max_angle = math.radians(6.)
    max_scale_change = .06
    radius = float(np.max(np.linalg.norm(points - center, axis=1)))
    band = max_shift + max_angle * radius + max_scale_change * radius + 3.
    # Crop only, never resample: every original pixel in the search band remains.
    x0 = max(0, int(np.floor(points[:, 0].min() - band - 5)))
    y0 = max(0, int(np.floor(points[:, 1].min() - band - 5)))
    x1 = min(width, int(np.ceil(points[:, 0].max() + band + 5)))
    y1 = min(height, int(np.ceil(points[:, 1].max() + band + 5)))
    local = gray[y0:y1, x0:x1]
    smooth = ndimage.gaussian_filter(local, .8, mode='reflect')
    noise = max(.75, 1.4826 * float(np.median(np.abs(local - ndimage.median_filter(local, size=3)))))
    minimum_contrast = max(3., 2.5 * noise)
    origin = np.array([x0, y0])
    angles = np.linspace(-max_angle, max_angle, 25)
    # One-native-pixel steps still inspect the complete continuous search band.
    offsets = np.linspace(-band, band, int(math.ceil(2 * band)) + 1)
    equations, samples = [], []
    for a, b in zip(points, np.roll(points, -1, axis=0)):
        vector, midpoint = b - a, (a + b) / 2
        length = float(np.linalg.norm(vector))
        if length < 8:
            metadata['note'] = 'A polygon side is too short for reliable guided fitting. The current outline was kept.'
            return fallback, metadata
        t = np.linspace(-.35, .35, max(16, min(160, int(length / 2))))
        best = None
        for angle in angles:
            cosine, sine = math.cos(angle), math.sin(angle)
            rotated = np.array([cosine * vector[0] - sine * vector[1], sine * vector[0] + cosine * vector[1]])
            normal = np.array([-rotated[1], rotated[0]]) / length
            xy = midpoint - origin + t[None, :, None] * rotated + offsets[:, None, None] * normal
            differences = _sample_boundary_contrast(smooth, xy, normal, 1.5)
            # Lower quartile, rather than maximum, rewards long straight edges.
            strength = np.percentile(differences, 25, axis=1)
            strength -= .002 * minimum_contrast * np.abs(offsets) / max(1., band)
            index = int(np.argmax(strength))
            score = float(strength[index])
            if best is None or score > best[0]:
                best = (score, normal, float(normal @ midpoint + offsets[index]),
                        float(np.mean(differences[index] >= minimum_contrast)))
        if best[0] < minimum_contrast or best[3] < .72:
            metadata['note'] = 'Not every expected side has a reliable nearby straight edge. The saved/current outline was kept.'
            return fallback, metadata
        equations.append((best[1], best[2]))
        samples.append(a + np.linspace(.15, .85, 12)[:, None] * vector)
    base = np.concatenate(samples) - center
    normals = np.repeat(np.array([normal for normal, _ in equations]), 12, axis=0)
    values = np.repeat(np.array([value for _, value in equations]), 12)

    def transform(parameters, xy):
        tx, ty, angle, scale = parameters
        cosine, sine = math.cos(angle), math.sin(angle)
        rotation = np.array([[cosine, -sine], [sine, cosine]])
        return scale * (xy @ rotation.T) + center + [tx, ty]

    def residual(parameters):
        return np.sum(transform(parameters, base) * normals, axis=1) - values

    fitted = least_squares(residual, [0., 0., 0., 1.],
                           bounds=([-max_shift, -max_shift, -max_angle, 1 - max_scale_change],
                                   [max_shift, max_shift, max_angle, 1 + max_scale_change]),
                           loss='soft_l1', f_scale=1.5, max_nfev=80)
    result = transform(fitted.x, points - center)
    # Inconsistent independently fitted sides imply the expected geometry does
    # not explain the image. Retain it rather than silently reshaping corners.
    residual_error = float(np.percentile(np.abs(residual(fitted.x)), 90))
    if residual_error > 2.5 or np.any(result < 0) or np.any(result[:, 0] > width) or np.any(result[:, 1] > height):
        metadata['note'] = 'Nearby edges do not consistently match the saved polygon within the allowed movement. The current outline was kept.'
        return fallback, metadata
    supports, contrasts = [], []
    for a, b in zip(result, np.roll(result, -1, axis=0)):
        vector = b - a
        length = np.linalg.norm(vector)
        normal = np.array([-vector[1], vector[0]]) / length
        xy = a - origin + np.linspace(.12, .88, max(16, min(192, int(length / 2))))[:, None] * vector
        differences = _sample_boundary_contrast(smooth, xy, normal, 1.5)
        supports.append(float(np.mean(differences >= minimum_contrast)))
        contrasts.append(float(np.median(differences)))
    if min(supports) < .72 or min(contrasts) < minimum_contrast:
        metadata['note'] = 'The fitted outline lacks sustained edge evidence on every side. The current outline was kept.'
        return fallback, metadata
    detected = {'type': 'polygon', 'points': [{'x': float(x), 'y': float(y)} for x, y in result]}
    detected = validate_roi(detected, width, height)
    metadata.update(found=True, confidence=round(min(.95, .65 * np.mean(supports) + .3 * min(1., np.median(contrasts) / 20)), 3),
                    fallback=None, vertex_count=len(points), edge_support=round(float(np.mean(supports)), 3),
                    edge_contrast=round(float(np.median(contrasts)), 2), fit_residual_pixels=round(residual_error, 3),
                    translation_pixels=[round(float(v), 3) for v in fitted.x[:2]],
                    rotation_degrees=round(math.degrees(float(fitted.x[2])), 3), scale=round(float(fitted.x[3]), 5),
                    note='Nearby straight edges support this adjustment of the saved polygon. Corner proportions were preserved. Check every corner before accepting.')
    return detected, metadata


def detect_inner_roi(image, prior_roi=None, mode='auto'):
    """Suggest a central polygon only when closed, straight edges are supported.

    Intensity components and closed gradient rings supply candidates. Convex
    hulls are simplified to 4–8 sides, checked against the actual region, and
    checked for contrast along every side. Circular rings, missing boundaries,
    and uniform images return the unchanged prior (or default) with found=False.
    Guided mode fits the current polygon to nearby edges while retaining its
    proportions. All computations use native image pixels. This is an assistive
    classical detector: every result requires human review.
    """
    rgb = np.asarray(image)
    if rgb.ndim != 3 or rgb.shape[2] != 3 or rgb.dtype != np.uint8:
        raise ValueError('Boundary detection input must be an 8-bit RGB image.')
    if mode not in ('auto', 'guided'):
        raise ValueError('Boundary detection mode must be auto or guided.')
    height, width = rgb.shape[:2]
    fallback = validate_roi(prior_roi, width, height)
    metadata = {'method': 'guided_polygon_edges' if mode == 'guided' else 'central_convex_polygon_edges',
                'mode': mode, 'native_resolution': True, 'analysis_width': width, 'analysis_height': height,
                'found': False, 'confidence': 0.,
                'review_required': True, 'fallback': 'prior' if prior_roi is not None else 'default',
                'note': 'No reliable polygon boundary found. The previous/default outline was kept; adjust it manually.'}
    gray = rgb.astype(np.float32) @ np.array([.299, .587, .114], dtype=np.float32)
    # Percentile contrast can erase a genuine one-pixel outline in a large
    # image. Reject only uniformly low contrast here; side support rejects
    # isolated bright/noisy pixels later.
    if min(width, height) < 24 or float(gray.max() - gray.min()) < 5:
        metadata['note'] = 'Image contrast is too low for reliable boundary detection. The previous/default outline was kept.'
        return fallback, metadata
    if mode == 'guided':
        return _guided_inner_roi(gray, fallback, metadata)
    h, w = gray.shape
    if fallback.get('type') == 'polygon':
        prior_points = np.array([[p['x'], p['y']] for p in fallback['points']])
        center = prior_points.mean(axis=0)
        prior_area = .5 * abs(np.dot(prior_points[:, 0], np.roll(prior_points[:, 1], 1)) - np.dot(prior_points[:, 1], np.roll(prior_points[:, 0], 1)))
    else:
        center = np.array([fallback['cx'], fallback['cy']])
        prior_area = math.pi * fallback['rx'] * fallback['ry']
    smooth = ndimage.gaussian_filter(gray, 1., mode='reflect')
    noise = max(.75, 1.4826 * float(np.median(np.abs(gray - ndimage.median_filter(gray, size=3)))))
    minimum_contrast = max(3., 2.5 * noise)
    expected_area = max(1., prior_area)
    seeds = [(int(np.clip(center[1] + dy * h, 0, h - 1)), int(np.clip(center[0] + dx * w, 0, w - 1)))
             for dx, dy in ((0, 0), (.025, 0), (-.025, 0), (0, .025), (0, -.025))]
    seen, candidates = set(), []

    def consider(binary):
        labels, _ = ndimage.label(binary)
        for label in {int(labels[y, x]) for y, x in seeds} - {0}:
            selected = labels == label
            # Keep component work at native resolution, but restrict expensive
            # filling and raster agreement to its bounding box.
            columns = np.flatnonzero(selected.any(axis=0))
            rows = np.flatnonzero(selected.any(axis=1))
            if not len(columns) or not len(rows):
                continue
            x0, x1, y0, y1 = int(columns[0]), int(columns[-1]) + 1, int(rows[0]), int(rows[-1]) + 1
            if x0 < 2 or y0 < 2 or x1 >= w - 1 or y1 >= h - 1:
                continue
            component = ndimage.binary_fill_holes(selected[y0:y1, x0:x1])
            area = int(component.sum())
            if not max(32, .035 * w * h, .3 * expected_area) <= area <= min(.62 * w * h, 2.25 * expected_area):
                continue
            signature = (area, x0, x1, y0, y1)
            if signature in seen:
                continue
            seen.add(signature)
            boundary = component ^ ndimage.binary_erosion(component)
            by, bx = np.nonzero(boundary)
            coords = np.column_stack((bx + .5 + x0, by + .5 + y0))
            try:
                hull = ConvexHull(coords)
            except QhullError:
                continue
            polygon = _simplify_hull(coords[hull.vertices])
            if len(polygon) < 4 or not y0 <= seeds[0][0] < y1 or not x0 <= seeds[0][1] < x1:
                continue
            polygon_roi = {'type': 'polygon', 'points': [{'x': float(x - x0), 'y': float(y - y0)} for x, y in polygon]}
            fitted = roi_mask(polygon_roi, x1 - x0, y1 - y0)
            if not fitted[seeds[0][0] - y0, seeds[0][1] - x0]:
                continue
            intersection = int((fitted & component).sum())
            iou = intersection / max(1, int((fitted | component).sum()))
            # A circle forced into an octagon loses about 10% of its area.
            if iou < .965:
                continue
            polygon = _refine_edge_positions(polygon, smooth)
            side_support, side_contrast = [], []
            for a, b in zip(polygon, np.roll(polygon, -1, axis=0)):
                vector = b - a
                length = np.linalg.norm(vector)
                if length < 3:
                    break
                normal = np.array([-vector[1], vector[0]]) / length
                t = np.linspace(.15, .85, max(8, int(length / 3)))
                xy = a[None] + t[:, None] * vector[None]
                # Keep the maximum across a small band to tolerate half-pixel fitting shifts.
                contrasts = []
                for offset in (-1., 0., 1.):
                    before, after = xy + (offset - 2.5) * normal, xy + (offset + 2.5) * normal
                    contrasts.append(np.abs(ndimage.map_coordinates(smooth, [before[:, 1], before[:, 0]], order=1, mode='nearest') - ndimage.map_coordinates(smooth, [after[:, 1], after[:, 0]], order=1, mode='nearest')))
                differences = np.max(contrasts, axis=0)
                side_support.append(float(np.mean(differences >= minimum_contrast)))
                side_contrast.append(float(np.median(differences)))
            if len(side_support) != len(polygon) or min(side_support) < .55:
                continue
            support = float(np.mean(side_support))
            contrast = float(np.median(side_contrast))
            size_match = math.exp(-abs(math.log(area / expected_area)))
            centered = math.exp(-np.linalg.norm(polygon.mean(axis=0) - center) / max(1., .12 * min(w, h)))
            score = .35 * iou + .25 * support + .15 * min(1., contrast / max(12., minimum_contrast * 3)) + .15 * size_match + .1 * centered
            candidates.append((score, polygon, iou, support, contrast))

    low, high = np.percentile(smooth, [2, 98])
    thresholds = np.unique(np.concatenate((np.percentile(smooth, np.linspace(5, 95, 11)), np.linspace(low, high, 9))))
    # Thresholds separated by less than the estimated noise floor produce the
    # same meaningful candidates while repeatedly scanning millions of pixels.
    _, keep = np.unique(np.floor(thresholds / max(1., minimum_contrast / 2)), return_index=True)
    thresholds = thresholds[np.sort(keep)]
    for threshold in thresholds:
        consider(smooth > threshold)
        consider(smooth < threshold)
    gx, gy = ndimage.sobel(smooth, axis=1) / 8., ndimage.sobel(smooth, axis=0) / 8.
    gradient = np.hypot(gx, gy)
    positive_edges = gradient[gradient > max(.5, noise)]
    if positive_edges.size:
        for threshold in np.unique(np.percentile(positive_edges, [35, 55, 70, 85])):
            edges = ndimage.binary_closing(gradient >= threshold, iterations=1)
            consider(ndimage.binary_fill_holes(edges))
    if not candidates:
        return fallback, metadata
    score, polygon, iou, support, contrast = max(candidates, key=lambda row: row[0])
    detected = {'type': 'polygon', 'points': [{'x': float(x), 'y': float(y)} for x, y in polygon]}
    metadata.update(found=True, confidence=round(min(.95, score), 3), fallback=None,
                    vertex_count=len(polygon), shape_agreement=round(iou, 3),
                    edge_support=round(support, 3), edge_contrast=round(contrast, 2),
                    note='A polygon boundary was suggested from visible edges. Check every corner before accepting; confidence is a heuristic, not a calibrated probability.')
    return validate_roi(detected, width, height), metadata


def validate_settings(settings):
    cfg = dict(DEFAULTS['classical'])
    if settings:
        if set(settings) - set(cfg):
            raise ValueError('Unknown classical detector setting.')
        cfg.update(settings)
    for key, lower, upper in (('background_sigma', 1, 100), ('sensitivity', .5, 20),
                              ('max_area_fraction', .000001, 1)):
        cfg[key] = float(cfg[key])
        if not math.isfinite(cfg[key]) or not lower <= cfg[key] <= upper:
            raise ValueError(f'{key} must be finite in [{lower},{upper}].')
    for key, lower, upper in (('min_area', 1, 1000000), ('boundary_guard', 0, 100)):
        if isinstance(cfg[key], bool) or int(cfg[key]) != cfg[key] or not lower <= cfg[key] <= upper:
            raise ValueError(f'{key} must be an integer in [{lower},{upper}].')
        cfg[key] = int(cfg[key])
    if cfg['polarity'] not in ('both', 'dark', 'bright'):
        raise ValueError('polarity must be both, dark or bright.')
    return cfg


def suggest(image, roi=None, settings=None):
    rgb = np.asarray(image)
    if rgb.ndim != 3 or rgb.shape[2] != 3 or rgb.dtype != np.uint8:
        raise ValueError('Classical proposal input must be an 8-bit RGB image.')
    height, width = rgb.shape[:2]
    roi = validate_roi(roi, width, height)
    cfg = validate_settings(settings)
    gray = rgb.astype(np.float32) @ np.array([.299, .587, .114], dtype=np.float32)
    smooth = ndimage.gaussian_filter(gray, .6, mode='reflect')
    background = ndimage.gaussian_filter(smooth, cfg['background_sigma'], mode='reflect')
    residual = smooth - background
    inner = roi_mask(roi, width, height)
    valid = np.ones((height, width), dtype=bool)
    guard = cfg['boundary_guard']
    if guard:
        valid &= _boundary_distance(roi, width, height, inner) > guard
        valid[:guard] = valid[-guard:] = False
        valid[:, :guard] = valid[:, -guard:] = False
    mask = np.zeros((height, width), dtype=np.uint8)
    thresholds, components = {}, {}
    for value, region in ((1, inner), (2, ~inner)):
        eligible = valid & region
        values = residual[eligible]
        name = 'inner' if value == 1 else 'outer'
        if not values.size:
            thresholds[name], components[name] = None, 0
            continue
        center = float(np.median(values))
        noise = max(1., 1.4826 * float(np.median(np.abs(values - center))))
        threshold = cfg['sensitivity'] * noise
        difference = residual - center
        selected = np.abs(difference) >= threshold if cfg['polarity'] == 'both' else (
            difference <= -threshold if cfg['polarity'] == 'dark' else difference >= threshold)
        labels, _ = ndimage.label(selected & eligible, structure=np.ones((3, 3), dtype=bool))
        counts = np.bincount(labels.ravel())
        keep = (counts >= cfg['min_area']) & (counts <= max(cfg['min_area'], cfg['max_area_fraction'] * height * width))
        keep[0] = False
        mask[keep[labels]] = value
        thresholds[name], components[name] = threshold, int(keep.sum())
    return mask, {'method': 'local_gaussian_residual_mad_components', 'automatic_proposal': True,
                  'review_required': True, 'thresholds_gray_levels': thresholds,
                  'components': components, 'inner_pixels': int((mask == 1).sum()),
                  'outer_pixels': int((mask == 2).sum()),
                  'low_contrast': bool(np.percentile(gray, 99) - np.percentile(gray, 1) < 8),
                  'note': 'Appearance anomalies are suggestions. Lens edges, markings and accepted texture can cause false positives; broad or low-contrast damage can be missed.'}
