"""ROI datasets use the existing classifier, with isolated scope/configuration.

The project keeps the last settings for each scope; switching never replaces
the original whole-image dataset. Crop exports carry physical-unit grouping
and their train/val/test assignment. The existing manifest builder subdivides
validation *units* into validation/threshold/selection, without touching test.
"""
from __future__ import annotations

import copy
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from ..common import EXTENSIONS, read_csv, read_json, safe_relative, write_json

SCOPES = {
    "top": ("whole_image", "corners", "label", "inner_area", "lens"),
    "bottom": ("whole_image", "pins", "triangle", "square"),
    "vig": ("whole_image",),
}


def validate_scope(side, scope):
    if side not in SCOPES or scope not in SCOPES[side]:
        raise ValueError("Choose a supported classification side and ROI scope.")
    return scope


def scoped_output_root(root, scope="whole_image"):
    """Retain the historical layout for full images and isolate ROI runs."""
    root = Path(root)
    if scope != "whole_image":
        if scope not in {s for scopes in SCOPES.values() for s in scopes}:
            raise ValueError("Unknown ROI classification scope.")
        root = root / "roi_classification" / scope
    return root


def inspect_dataset(dataset, side, scope):
    """Check an exported dataset's identity/grouping without changing it."""
    validate_scope(side, scope)
    root = Path(dataset).expanduser().resolve()
    metadata_path = root / "roi_dataset.json"
    if not root.is_dir() or not metadata_path.is_file():
        raise ValueError("Choose a labelled ROI classification export containing roi_dataset.json.")
    metadata = read_json(metadata_path)
    if metadata.get("side") != side or metadata.get("roi_scope") != scope:
        raise ValueError("ROI dataset side/scope differs from the selected classifier.")
    groups_path = root / "groups.csv"
    if not groups_path.is_file():
        raise ValueError("ROI export is missing groups.csv; export again from ROI Detection.")
    mappings = read_csv(groups_path)
    paths, group_splits, counts = set(), defaultdict(set), defaultdict(lambda: defaultdict(int))
    for row in mappings:
        relative, group = row.get("relative_path", "").replace("\\", "/"), row.get("group", "").strip()
        path = safe_relative(root, relative)
        parts = Path(relative.replace("\\", "/")).parts
        if not group or not relative or relative in paths or not path.is_file():
            raise ValueError("ROI groups.csv has duplicate, missing or invalid crop/unit mappings.")
        if len(parts) < 3 or parts[0] not in ("train", "val", "threshold", "selection", "test") or parts[1] not in ("good", "bad"):
            raise ValueError("ROI crops must use split/good|bad directories with explicit labels.")
        paths.add(relative.replace("\\", "/"))
        group_splits[group].add(parts[0])
        counts[parts[0]][parts[1]] += 1
    if any(len(splits) != 1 for splits in group_splits.values()):
        raise ValueError("A physical unit occurs in multiple ROI dataset splits.")
    if not paths:
        raise ValueError("This ROI export has no confirmed Good/Bad crops. Label ROI quality and export again.")
    images = {path.relative_to(root).as_posix() for path in root.rglob("*")
              if path.is_file() and path.suffix.lower() in EXTENSIONS}
    if images != paths:
        raise ValueError("groups.csv must cover every crop exactly; export again from ROI Detection.")
    return {"path": str(root), "groups_csv": str(groups_path), "metadata": metadata,
            "counts": {split: dict(labels) for split, labels in counts.items()},
            "n_crops": len(paths), "n_units": len(group_splits),
            "split_note": "Training preserves train/test; validation units are subdivided into val, threshold and selection."}


def select_classification_scope(raw, side, scope, base, dataset=None):
    """Update an in-memory project copy; never publish a partial switch."""
    validate_scope(side, scope)
    tasks = raw.setdefault("tasks", {})
    current = copy.deepcopy(tasks.get(side, {}))
    current_scope = current.get("roi_scope", "whole_image")
    validate_scope(side, current_scope)
    saved = raw.setdefault("roi_classification", {}).setdefault(side, {})
    # Normalize saved paths while their original config-relative base is known.
    for key in ("dataset_root", "groups_csv", "previous_run"):
        if current.get(key):
            current[key] = str((Path(base) / Path(current[key]).expanduser()).resolve())
    saved[current_scope] = current
    if scope in saved:
        target = copy.deepcopy(saved[scope])
    else:
        target = copy.deepcopy(saved.get("whole_image", current))
        for key in ("dataset_root", "groups_csv", "group_regex", "previous_run", "tray_roles", "review_dataset", "roi_dataset"):
            target.pop(key, None)
        target.update(dataset_root="", enabled=False)
    target["roi_scope"] = scope
    if dataset is not None:
        target["dataset_root"] = str(Path(dataset).expanduser().resolve())
        target["enabled"] = True
    dataset_info = None
    if scope != "whole_image":
        if target.get("dataset_root"):
            dataset_info = inspect_dataset(target["dataset_root"], side, scope)
            target.update(groups_csv=dataset_info["groups_csv"], group_regex=None,
                          grouping="pixel_hash", tray_roles={}, previous_run=None,
                          independent_units_confirmed=True, roi_dataset=dataset_info["metadata"])
        # ROI exports already define their crop geometry; any whole-image patch
        # aggregation choice is a separate experiment and is not inherited.
        if scope not in saved:
            target.update(image_strategy="full_image", image_size="auto")
    tasks[side] = target
    saved[scope] = copy.deepcopy(target)
    return dataset_info


def remember_classification_scope(raw, side):
    """Keep edits made by the existing settings form in their active scope."""
    cfg = raw["tasks"][side]
    scope = cfg.get("roi_scope", "whole_image")
    if "roi_classification" in raw or scope != "whole_image":
        raw.setdefault("roi_classification", {}).setdefault(side, {})[scope] = copy.deepcopy(cfg)


def configure_classification(app, payload):
    """Dashboard handoff from ROI Detection or classification scope selection."""
    import yaml
    side = payload.get("side", payload.get("task", "top"))
    scope = payload.get("roi_scope", "whole_image")
    validate_scope(side, scope)
    with app.lock:
        raw = copy.deepcopy(app.raw)
        info = select_classification_scope(raw, side, scope, app.config.parent, payload.get("dataset") or None)
        app._validate_config(raw)
        target = app.config.parent / ("project.dashboard." + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%f") + ".yaml")
        with target.open("x", encoding="utf-8") as handle:
            yaml.safe_dump(raw, handle, sort_keys=False)
        app._read_config(target)
        write_json(app.base_config.parent / "studio_settings.json", {
            "base_config": str(app.base_config), "base_sha256": app.base_config_sha256,
            "snapshot": target.name})
        app.config = target
        app._load_config()
        return {"config": app.bootstrap(), "side": side, "roi_scope": scope,
                "dataset": raw["tasks"][side].get("dataset_root", ""), "dataset_info": info}
