import argparse
import gc
import json
import sys
from pathlib import Path

from .catalog import MODELS, select_model


def main(argv=None):
    parser = argparse.ArgumentParser(description="Compare pretrained ImageNet classifiers")
    commands = parser.add_subparsers(dest="command", required=True)
    listing = commands.add_parser("list", help="List curated checkpoints and weight licenses")
    listing.add_argument("--purpose", choices=["all", "research", "commercial"], default="all")
    prediction = commands.add_parser("predict", help="Classify a local image")
    prediction.add_argument("--model", required=True)
    prediction.add_argument("--image", required=True, type=Path)
    prediction.add_argument("--top-k", type=int, default=5)
    evaluation = commands.add_parser("benchmark", help="Compare accuracy and model forward speed")
    evaluation.add_argument("--models", nargs="+", required=True)
    evaluation.add_argument("--dataset", required=True, type=Path)
    evaluation.add_argument("--class-map", type=Path)
    evaluation.add_argument("--batch-size", type=int, default=8)
    evaluation.add_argument("--workers", type=int, default=0)
    for command in (prediction, evaluation):
        command.add_argument("--purpose", choices=["commercial", "research"], default="commercial")
        command.add_argument("--device", default="cpu")
        command.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    if args.command == "list":
        for spec in MODELS:
            if args.purpose == "commercial" and not spec.commercial:
                continue
            print(f"{spec.name:23} {spec.family:15} {spec.size:7} "
                  f"{spec.license:15} {spec.card_url}")
        return 0
    try:
        # Check every requested license before loading dependencies or models.
        names = args.models if args.command == "benchmark" else [args.model]
        for name in names:
            select_model(name, args.purpose)
        from .runner import benchmark, predict
        if args.command == "predict":
            result = predict(args.model, args.image, args.purpose, args.device, args.top_k)
            failed = False
        else:
            mapping = json.loads(args.class_map.read_text()) if args.class_map else None
            if mapping is not None and not isinstance(mapping, dict):
                raise ValueError("Class map must be a JSON object")
            result = {"results": [], "errors": []}
            for name in names:
                try:
                    result["results"].append(benchmark(name, args.dataset, args.purpose,
                        args.device, args.batch_size, mapping, args.workers))
                except Exception as error:
                    result["errors"].append({"model": name, "error": str(error)})
                finally:
                    gc.collect()
                    import torch
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()
            failed = bool(result["errors"])
        rendered = json.dumps(result, indent=2)
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(rendered + "\n")
        print(rendered)
        return 1 if failed else 0
    except Exception as error:
        print(f"cvtester: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
