from __future__ import annotations

import hashlib
from pathlib import Path
import random

import numpy as np
from PIL import Image, ImageOps
from scipy.fft import dctn


class InvalidImage(ValueError):
    pass


def load_image(path: Path | str, data_cfg: dict) -> tuple[Image.Image, str]:
    """Return the reproducible 8-bit RGB model input and native-pixel hash.

    High-bit-depth images use a declared fixed range, not per-image contrast
    stretching. Multi-page TIFFs are rejected unless explicitly allowed.
    """
    with Image.open(path) as source:
        if data_cfg.get("reject_multiframe", True) and getattr(source, "n_frames", 1) != 1:
            raise InvalidImage("Multi-frame image: export the required frame explicitly")
        source.load()
        image = ImageOps.exif_transpose(source)
        if min(image.size) < int(data_cfg.get("min_side", 32)):
            raise InvalidImage(f"Image too small: {image.size}")
        arr = np.asarray(image)
        native = hashlib.sha256(str((image.mode, arr.shape, str(arr.dtype))).encode() + arr.tobytes()).hexdigest()
        if image.mode == "F":
            raise InvalidImage("Floating-point image: define a fixed conversion upstream")
        if arr.dtype == np.uint16 or image.mode.startswith("I;16") or image.mode == "I":
            low, high = map(float, data_cfg.get("uint16_range", [0, 65535]))
            if high <= low or arr.min() < low or arr.max() > high:
                raise InvalidImage("Pixel values outside configured uint16_range")
            arr8 = np.rint((arr.astype(np.float32) - low) * (255.0 / (high - low))).astype(np.uint8)
            rgb = Image.fromarray(arr8).convert("RGB")
        elif "A" in image.getbands() or "transparency" in image.info:
            rgba = image.convert("RGBA")
            base = Image.new("RGBA", rgba.size, (127, 127, 127, 255))
            rgb = Image.alpha_composite(base, rgba).convert("RGB")
        else:
            rgb = image.convert("RGB")
        return rgb.copy(), native


def input_hash(image: Image.Image) -> str:
    return hashlib.sha256(str(image.size).encode() + image.tobytes()).hexdigest()


def image_qc(image: Image.Image, rules: dict) -> tuple[dict, list[str]]:
    from scipy.ndimage import laplace
    gray = np.asarray(image.convert("L"), dtype=np.float32)
    info = {"mean": float(gray.mean()), "std": float(gray.std()),
            "laplacian_variance": float(laplace(gray).var())}
    issues = []
    for option, key, compare in (("min_mean", "mean", "min"), ("max_mean", "mean", "max"),
                                 ("min_std", "std", "min"), ("min_laplacian_variance", "laplacian_variance", "min")):
        threshold = rules.get(option)
        if threshold is not None and ((info[key] < threshold) if compare == "min" else (info[key] > threshold)):
            issues.append(option.upper())
    return info, issues


def perceptual_signature(image: Image.Image) -> tuple[int, np.ndarray]:
    thumb = np.asarray(image.convert("L").resize((32, 32), Image.Resampling.BILINEAR), dtype=np.float32)
    coeff = dctn(thumb, type=2, norm="ortho")[:8, :8].ravel()
    bits = coeff > np.median(coeff[1:])
    bits[0] = False
    value = 0
    for bit in bits:
        value = (value << 1) | int(bit)
    return value, thumb.astype(np.uint8)


def letterbox(image: Image.Image, size: int, pad_value: int = 127) -> Image.Image:
    width, height = image.size
    scale = size / max(width, height)
    new_size = (max(1, round(width * scale)), max(1, round(height * scale)))
    resized = image.resize(new_size, Image.Resampling.BILINEAR)
    output = Image.new("RGB", (size, size), (pad_value,) * 3)
    output.paste(resized, ((size - new_size[0]) // 2, (size - new_size[1]) // 2))
    return output


class ImageTransform:
    """Picklable transform for Windows multiprocessing. No random center crops."""
    def __init__(self, size: int, mean: list, std: list, preprocessing: dict, aug: dict | None = None):
        self.size, self.mean, self.std = size, mean, std
        self.preprocessing, self.aug = preprocessing, aug

    def __call__(self, image: Image.Image):
        import torch
        from PIL import ImageEnhance
        if self.aug:
            if self.aug.get("horizontal_flip") and random.random() < 0.5:
                image = ImageOps.mirror(image)
            if self.aug.get("vertical_flip") and random.random() < 0.5:
                image = ImageOps.flip(image)
            if self.aug.get("rotations_90"):
                turns = random.randrange(4)
                if turns:
                    image = image.rotate(90 * turns, expand=True)
            for key, enhancer in (("brightness", ImageEnhance.Brightness), ("contrast", ImageEnhance.Contrast)):
                amount = float(self.aug.get(key, 0))
                if amount:
                    image = enhancer(image).enhance(random.uniform(1 - amount, 1 + amount))
        if self.preprocessing.get("mode", "letterbox") != "letterbox":
            raise ValueError("Only letterbox preprocessing is supported: avoid an unvalidated hidden crop")
        image = letterbox(image, self.size, int(self.preprocessing.get("pad_value", 127)))
        array = np.array(image, dtype=np.float32).transpose(2, 0, 1) / 255.0
        tensor = torch.from_numpy(array)
        return (tensor - torch.tensor(self.mean)[:, None, None]) / torch.tensor(self.std)[:, None, None]


class ImageRows:
    def __init__(self, rows: list[dict], data_cfg: dict, transform: ImageTransform):
        self.rows, self.data_cfg, self.transform = rows, data_cfg, transform

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index: int):
        row = self.rows[index]
        image, _ = load_image(row["path"], self.data_cfg)
        return self.transform(image), int(row.get("label", -1)), str(row["sample_id"])


def seed_worker(worker_id: int) -> None:
    import torch
    seed = torch.initial_seed() % (2**32)
    random.seed(seed)
    np.random.seed(seed)


def make_loader(rows: list[dict], cfg: dict, transform: ImageTransform, batch_size: int, shuffle: bool = False):
    import torch
    from torch.utils.data import DataLoader
    generator = torch.Generator().manual_seed(int(cfg["project"]["seed"]))
    return DataLoader(ImageRows(rows, cfg["data"], transform), batch_size=batch_size, shuffle=shuffle,
                      num_workers=int(cfg["runtime"]["num_workers"]), pin_memory=torch.cuda.is_available(),
                      worker_init_fn=seed_worker, generator=generator, persistent_workers=False, drop_last=False)
