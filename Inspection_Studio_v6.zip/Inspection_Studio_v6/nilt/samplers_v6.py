"""Optuna 4.5 sampler contracts and factories for the local ask/tell runner.

Only serializable options are accepted. No executable callbacks, automatic
algorithm substitution, remote modules, or test-set observations are loaded.
"""
from __future__ import annotations

import importlib
import math


SAMPLERS = {
    "tpe": "TPE (Bayesian)", "random": "Random", "grid": "Grid",
    "gp": "Gaussian process (Bayesian)", "cmaes": "CMA-ES (evolutionary)",
    "nsgaii": "NSGA-II (evolutionary)", "nsgaiii": "NSGA-III (evolutionary)",
    "qmc": "Quasi Monte Carlo", "brute_force": "Brute force",
}
STATIC_SAMPLERS = {"gp", "cmaes", "nsgaii", "nsgaiii", "qmc"}
OPTION_DEFAULTS = {
    "tpe": {"multivariate": False, "group": False, "constant_liar": False, "n_ei_candidates": 24},
    "random": {}, "grid": {},
    "gp": {"deterministic_objective": False},
    "cmaes": {"sigma0": None, "popsize": None, "use_separable_cma": False,
              "with_margin": False, "lr_adapt": False, "consider_pruned_trials": False},
    "nsgaii": {"population_size": 50, "mutation_prob": None,
               "crossover_prob": .9, "swapping_prob": .5},
    "nsgaiii": {"population_size": 50, "mutation_prob": None,
                "crossover_prob": .9, "swapping_prob": .5, "dividing_parameter": 3},
    "qmc": {"qmc_type": "sobol", "scramble": False},
    "brute_force": {"avoid_premature_stop": True},
}


def sampler_options(name, raw):
    """Validate and normalize JSON options for the explicitly selected sampler."""
    if name not in SAMPLERS:
        raise ValueError("Sampler must be one of: " + ", ".join(SAMPLERS) + ".")
    if not isinstance(raw, dict):
        raise ValueError("search.sampler_options must be an object.")
    unknown = set(raw) - set(OPTION_DEFAULTS[name])
    if unknown:
        raise ValueError(f"Unsupported {name} sampler options: {sorted(unknown)}. Clear options when changing the sampler.")
    result = {**OPTION_DEFAULTS[name], **raw}
    booleans = {"multivariate", "group", "constant_liar", "deterministic_objective",
                "use_separable_cma", "with_margin", "lr_adapt", "consider_pruned_trials",
                "scramble", "avoid_premature_stop"}
    integers = {"n_ei_candidates": 1, "population_size": 2, "popsize": 2, "dividing_parameter": 1}
    for key, value in result.items():
        if key in booleans:
            if type(value) is not bool:
                raise ValueError(f"search.sampler_options.{key} must be boolean.")
        elif key == "qmc_type":
            if value not in {"sobol", "halton"}:
                raise ValueError("QMC qmc_type must be sobol or halton.")
        elif value is None and key in {"mutation_prob", "sigma0", "popsize"}:
            continue
        else:
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                raise ValueError(f"search.sampler_options.{key} must be a finite number.")
            if key in integers:
                if int(value) != value or value < integers[key]:
                    raise ValueError(f"search.sampler_options.{key} must be an integer >= {integers[key]}.")
                result[key] = int(value)
            elif key == "sigma0" and value <= 0:
                raise ValueError("CMA-ES sigma0 must be positive or null for automatic initialization.")
            elif key in {"mutation_prob", "crossover_prob", "swapping_prob"} and not 0 <= value <= 1:
                raise ValueError(f"search.sampler_options.{key} must be between 0 and 1.")
    if name == "tpe" and result["group"] and not result["multivariate"]:
        raise ValueError("TPE group=true requires multivariate=true.")
    if name == "cmaes" and sum(result[key] for key in ("use_separable_cma", "with_margin", "lr_adapt")) > 1:
        raise ValueError("Choose at most one CMA-ES variant: use_separable_cma, with_margin, lr_adapt.")
    return result


def validate_sampler_space(name, space, active, model, limit):
    """Fail early where Optuna would otherwise independently sample categories."""
    from .custom_search import INTEGER_PARAMS, finite_choices

    if name in {"cmaes", "qmc"}:
        categorical = [key for key in sorted(active)
                       if space[key]["kind"] == "choices" and len(space[key]["values"]) > 1]
        if categorical:
            raise ValueError(f"{SAMPLERS[name]} for {model} cannot search categorical choices: {', '.join(categorical)}. "
                             "Fix these values or use numerical ranges for numeric parameters; choose TPE, GP or NSGA-II for mixed spaces. "
                             "No random fallback is applied.")
        variable = [key for key in active if space[key]["kind"] == "range" and space[key]["low"] < space[key]["high"]]
        minimum = 2 if name == "cmaes" else 1
        if len(variable) < minimum:
            raise ValueError(f"{SAMPLERS[name]} for {model} requires at least {minimum} varying numeric range(s).")
    if name == "brute_force":
        # BruteForce enumerates each distribution. Reject unbounded supports
        # and use the same explicitly adjustable allocation guard as Grid.
        size = 1
        for key in sorted(active):
            spec = space[key]
            if spec["kind"] == "range" and key in INTEGER_PARAMS and not spec.get("log"):
                spec = {**spec, "step": spec.get("step", 1)}
            try:
                size *= len(finite_choices(spec, limit=limit))
            except ValueError as exc:
                raise ValueError(f"Brute force requires finite choices or linear ranges with step ({model}.{key}): {exc}") from exc
            if size > limit:
                raise ValueError(f"Brute-force support exceeds max_grid_combinations={limit:,}; increase that setting or choose another sampler.")


def check_sampler_dependencies(settings):
    name = settings["sampler"]
    modules = {"cmaes": ("cmaes",), "gp": ("torch", "scipy"), "qmc": ("scipy",)}.get(name, ())
    for module in modules:
        try:
            importlib.import_module(module)
        except (ImportError, OSError) as exc:
            instruction = ("Install requirements-samplers.txt using the same Python environment as the dashboard."
                           if module == "cmaes" else "Install the project training requirements with the CPU/CUDA wheel choice for this computer.")
            raise RuntimeError(f"{SAMPLERS[name]} requires a working {module} installation. {instruction} Details: {exc}") from exc


def make_sampler(optuna, settings, space, active, count=0):
    """Build the named algorithm; exhaustive samplers support ask/tell safely."""
    from .custom_search import finite_choices

    name = settings["sampler"]
    options = sampler_options(name, settings.get("sampler_options", {}))
    check_sampler_dependencies(settings)
    seed = (int(settings["seed"]) + int(count) * 1009) % 2**32
    startup = int(settings["startup_trials"])
    if name == "random":
        return optuna.samplers.RandomSampler(seed=seed)
    if name == "tpe":
        return optuna.samplers.TPESampler(seed=seed, n_startup_trials=startup, **options)
    if name == "grid":
        class AskTellGridSampler(optuna.samplers.GridSampler):
            def after_trial(self, study, trial, state, values):
                # The application checks is_exhausted before the next ask.
                return None
        grid = {key: finite_choices(space[key], limit=settings["max_grid_combinations"]) for key in sorted(active)}
        return AskTellGridSampler(grid, seed=int(settings["seed"]))
    if name == "gp":
        return optuna.samplers.GPSampler(seed=seed, n_startup_trials=startup, **options)
    if name == "cmaes":
        return optuna.samplers.CmaEsSampler(seed=seed, n_startup_trials=startup, **options)
    if name == "nsgaii":
        return optuna.samplers.NSGAIISampler(seed=seed, **options)
    if name == "nsgaiii":
        return optuna.samplers.NSGAIIISampler(seed=seed, **options)
    if name == "qmc":
        # Preserve the scramble seed across restarts: Optuna persists the QMC
        # sequence index, and changing the scramble would break its sequence.
        class BoundedQMCSampler(optuna.samplers.QMCSampler):
            def sample_relative(self, study, trial, search_space):
                values = super().sample_relative(study, trial, search_space)
                # Sobol's zero endpoint with a log range can round a fraction
                # below low during exp(log(low)). Optuna then rejects the
                # relative value and silently independently samples it. Keep
                # numeric endpoints inside their declared closed interval.
                return {key: min(search_space[key].high, max(search_space[key].low, value))
                        for key, value in values.items()}
        return BoundedQMCSampler(seed=int(settings["seed"]), **options)
    if name == "brute_force":
        class AskTellBruteForceSampler(optuna.samplers.BruteForceSampler):
            def after_trial(self, study, trial, state, values):
                class StopAdapter:
                    def __getattr__(self, key):
                        return getattr(study, key)

                    def stop(self):
                        study.set_user_attr("nilt_brute_force_exhausted", True)
                # Keep Optuna's real tree/exhaustion calculation, adapting only
                # its optimize-only stop signal to the durable ask/tell loop.
                super().after_trial(StopAdapter(), trial, state, values)

            def is_exhausted(self, study):
                return bool(study.user_attrs.get("nilt_brute_force_exhausted", False))
        return AskTellBruteForceSampler(seed=seed, **options)
    raise ValueError(f"Unsupported sampler: {name}.")
