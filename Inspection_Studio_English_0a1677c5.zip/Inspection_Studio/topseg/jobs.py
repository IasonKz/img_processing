"""One background worker per output workspace; restart-safe process locking."""
import json
import os
import subprocess
import sys
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from .common import atomic_json, read_json, project_lock


class JobManager:
    def __init__(self,cfg):
        self.cfg=cfg
        self.root=Path(cfg['output_dir'])/'jobs'
        self.root.mkdir(parents=True,exist_ok=True)
        self.guard=threading.RLock()
        self.process=None

    def current(self):
        marker=self.root/'active.json'
        if not marker.exists(): return {'status':'idle'}
        job=read_json(marker); folder=self.root/job['id']
        state=read_json(folder/'status.json') if (folder/'status.json').exists() else {'status':'starting'}
        if state.get('status') in ('running','starting','unverified'):
            # psutil works on Windows and Unix, including stale PID detection.
            import psutil
            try:
                proc=psutil.Process(job['pid'])
                expected=[sys.executable,'-m','topseg.worker',str(folder)]
                alive=proc.is_running() and proc.status()!=psutil.STATUS_ZOMBIE and abs(proc.create_time()-job['create_time'])<.01 and proc.cmdline()==expected
            except psutil.NoSuchProcess: alive=False
            except psutil.AccessDenied:
                alive=True
                state={**state,'status':'unverified','error':'Worker identity could not be verified; inspect the process before starting another operation.'}
            if not alive:
                state={**state,'status':'interrupted','error':'Worker ended before completion. Check its log; restart the search to continue with new trials.'}
                atomic_json(folder/'status.json',state)
        log=folder/'worker.log'
        if log.exists():
            with log.open('rb') as f:
                f.seek(max(0,log.stat().st_size-10000)); tail=f.read().decode('utf-8',errors='replace')
        else:tail=''
        return {**state,'job_id':job['id'],'action':job['action'],'log':tail}

    def start(self,action,payload):
        if action not in ('search','preflight','evaluate','predict','export','dataset','import','report'):
            raise ValueError('Unknown operation.')
        with self.guard, project_lock(self.root):
            if self.current().get('status') in ('running','starting','unverified'):raise ValueError('An operation is already running. Stop it or wait for completion.')
            job_id=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')+'_'+uuid.uuid4().hex[:8]
            folder=self.root/job_id; folder.mkdir()
            atomic_json(folder/'request.json',{'cfg':self.cfg,'action':action,'payload':payload})
            atomic_json(folder/'status.json',{'status':'starting','action':action})
            with (folder/'worker.log').open('wb') as log:
                self.process=subprocess.Popen([sys.executable,'-m','topseg.worker',str(folder)],cwd=str(Path(__file__).parent.parent),stdout=log,stderr=subprocess.STDOUT)
            import psutil
            try: created=psutil.Process(self.process.pid).create_time()
            except psutil.NoSuchProcess:created=0
            atomic_json(self.root/'active.json',{'id':job_id,'pid':self.process.pid,'create_time':created,'action':action})
            return {'job_id':job_id,'status':'starting'}

    def stop(self):
        with self.guard:
            current=self.current()
            if current.get('job_id') and current.get('status') in ('starting','running'):
                (self.root/current['job_id']/'stop').touch()
                return {'status':'stop_requested','note':'The worker will stop at its next safe checkpoint. A running GPU operation must finish first.'}
            return {'status':'idle'}

    def force_stop(self):
        """Terminate only the recorded worker and its still-owned descendants."""
        import psutil
        with self.guard:
            current = self.current()
            if current.get('status') not in ('starting', 'running', 'unverified'):
                return {'status': 'idle'}
            job = read_json(self.root / 'active.json')
            try:
                process = psutil.Process(job['pid'])
                expected = [sys.executable, '-m', 'topseg.worker', str(self.root / job['id'])]
                if abs(process.create_time() - job['create_time']) > .01 or process.cmdline() != expected:
                    raise ValueError('Segmentation worker identity could not be verified.')
                children = process.children(recursive=True) + [process]
                identities = [(child, child.create_time()) for child in children]
                for child, created in identities:
                    try:
                        if child.create_time() == created:
                            child.terminate()
                    except psutil.NoSuchProcess:
                        pass
                _, alive = psutil.wait_procs(children, timeout=2)
                for child in alive:
                    try:
                        if any(child.pid == original.pid and child.create_time() == created for original, created in identities):
                            child.kill()
                    except psutil.NoSuchProcess:
                        pass
            except psutil.NoSuchProcess:
                pass
            atomic_json(self.root / job['id'] / 'status.json', {'status': 'interrupted', 'action': job['action'],
                        'error': 'Stopped by operator; committed checkpoints are retained.'})
            return {'status': 'stopped', 'job_id': job['id']}
