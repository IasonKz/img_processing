// Dependency-free JavaScript behavior check with a minimal DOM substitute.
// This validates render logic and event wiring, not browser layout.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(process.argv[2],'utf8');
class Element {
  constructor(id){this.id=id;this.value='0';this.hidden=false;this.events={};this.dataset={};this._html='';this.textContent='';this.classList={toggle:()=>{}};}
  set innerHTML(s){this._html=s;}
  get innerHTML(){return this._html;}
  addEventListener(k,f){this.events[k]=f;}
}
const ids=['run','candidate','context','overview','quality','training','benchmarks','threshold','records','scenario','cutoff','demo','footer','report-data'];
const elements=Object.fromEntries(ids.map(id=>[id,new Element(id)]));
elements['report-data'].textContent=html.match(/<script type="application\/json" id="report-data">([\s\S]*?)<\/script>/)[1];
const sections=['overview','quality','training','benchmarks','threshold','records'].map(id=>elements[id]);
const buttons=sections.map(s=>{let e=new Element('button_'+s.id);e.dataset.tab=s.id;return e});
const document={getElementById:id=>elements[id],querySelectorAll:q=>q==='[data-tab]'?buttons:sections};
const sandbox={document,window:{print:()=>{}},console};
vm.createContext(sandbox);
const code=html.match(/<script>\s*([\s\S]*?)<\/script>/)[1];
vm.runInContext(code,sandbox);
assert(elements.overview.innerHTML.includes('24.60%'));
assert(elements.overview.innerHTML.includes('93.94%'));
assert(elements.overview.innerHTML.includes('49'));
assert(elements.training.innerHTML.includes('Training throughput'));
assert(elements.training.innerHTML.includes('1.00e-4')||elements.training.innerHTML.includes('e-5'));
assert(elements.quality.innerHTML.includes('<svg'));
assert(elements.demo.innerHTML.includes('SYNTHETIC DEMONSTRATION'));
elements.cutoff.value='0';elements.cutoff.events.input();
assert(elements.scenario.innerHTML.includes('Hypothetical')||elements.scenario.innerHTML.includes('Threshold'));
const initialScenario=elements.scenario.innerHTML;
elements.cutoff.value='3';elements.cutoff.events.input();
assert.notEqual(elements.scenario.innerHTML,initialScenario);
buttons[2].events.click();assert.equal(elements.training.hidden,false);assert.equal(elements.overview.hidden,true);
elements.run.value='0';elements.run.events.change();assert(elements.overview.innerHTML.includes('No candidate selected'));
assert(elements.threshold.innerHTML.includes('unavailable'));
elements.run.value='1';elements.run.events.change();assert(elements.training.innerHTML.includes('No model history'));
elements.run.value='2';elements.run.events.change();
assert(elements.benchmarks.innerHTML.includes('Same selection records'));
console.log('Dashboard JavaScript checks passed: initial render, metrics, charts, LR scale, scenario control, tabs, audit/selected runs and missing histories. Layout is not covered.');
