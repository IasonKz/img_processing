"""Dashboard/model integration; deterministic fixtures do not download weights."""
import copy
import hashlib
import io
import json
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import MagicMock, patch

import numpy as np
import torch

from cvtester.catalog import CATALOG
from nilt.backbones import normalization
from nilt.common import DEFAULTS, MODEL_NAMES, PROFILES, load_project, merge_dict, read_json, write_json
from nilt.dashboard import Dashboard
from nilt.engine import (TrainingStopped, configure_training_stage, load_checkpoint,
                         make_model, save_checkpoint, weight_path)
from nilt.hub_weights import descriptor_for, ensure_hub_weights, _hub_url
from nilt.weights import ensure_pretrained_weights


class DashboardIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.config = Path(self.temp.name) / "project.yaml"
        self.config.write_text("tasks:\n  vig:\n    dataset_root: ./images\n")
        self.app = Dashboard(self.config)

    def tearDown(self):
        self.temp.cleanup()

    def test_all_models_and_licenses_are_exposed_in_dashboard(self):
        boot = self.app.bootstrap()
        self.assertTrue(set(CATALOG).issubset(boot["models"]))
        self.assertEqual(len(boot["model_details"]), 29)
        self.assertFalse(boot["model_details"]["convnextv2-base"]["commercial"])
        self.assertTrue(boot["model_details"]["eva02-large"]["commercial"])

    def test_identical_download_permission_for_every_profile(self):
        for profile in PROFILES:
            with self.subTest(profile=profile):
                custom = self.app.v5_defaults({"profile": profile})
                self.assertTrue(custom["download_missing_weights"])
                result = self.app.v5_search_config({"profile": profile, "models": ["resnet18"],
                    "download_missing_weights": False, "hours": 1}, persist=False)
                self.assertFalse(result["resolved_config"]["download_missing_weights"])

    def test_noncommercial_models_need_research_usage_on_every_profile(self):
        for profile in PROFILES:
            data = {"profile": profile, "models": ["convnextv2-atto"], "hours": 1}
            with self.subTest(profile=profile):
                with self.assertRaisesRegex(ValueError, "prohibits commercial"):
                    self.app.v5_search_config(data, persist=False)
                cfg = self.app.v5_search_config(dict(data, model_usage="research"), persist=False)["resolved_config"]
                self.assertEqual(cfg["model_usage"], "research")

    def test_preset_controls_are_frozen_in_search_snapshot(self):
        command = self.app.command("search", {"models": ["convnextv2-atto"], "hours": 1,
                                              "model_usage": "research", "download_missing_weights": False})
        cfg = read_json(command[command.index("--config") + 1])
        self.assertEqual(cfg["model_usage"], "research")
        self.assertFalse(cfg["download_missing_weights"])
        self.assertEqual(cfg["models"], ["convnextv2-atto"])

    def test_weight_button_passes_usage_to_cli_and_blocks_commercial(self):
        data = {"models": ["convnextv2-atto"]}
        with self.assertRaisesRegex(ValueError, "prohibits commercial"):
            self.app.command("prepare-weights", data)
        command = self.app.command("prepare-weights", dict(data, model_usage="research"))
        self.assertEqual(command[command.index("--model-usage") + 1], "research")

    def test_extended_profile_defaults_and_limits(self):
        cfg = load_project(self.config, "workstation_50h")[0]
        self.assertEqual(cfg["device"], "cuda")
        self.assertEqual(cfg["search"]["total_budget_seconds"], 48 * 3600)
        self.assertEqual(cfg["training"]["epochs"], 100)
        self.assertTrue(cfg["training"]["amp"])
        self.assertEqual(len(cfg["seeds"]), 3)
        self.assertEqual(self.app.bootstrap()["profile_max_hours"]["workstation_50h"], 50)
        data = {"profile": "workstation_50h", "models": ["eva02-small"], "hours": 50}
        self.assertTrue(self.app.v5_search_config(data, persist=False)["valid"])
        with self.assertRaisesRegex(ValueError, "50 hours"):
            self.app.v5_search_config(dict(data, hours=50.01), persist=False)
        custom = self.app.v5_defaults(data)
        custom["search"]["total_budget_seconds"] = 180001
        with self.assertRaisesRegex(ValueError, "50 hours"):
            self.app.v5_search_config(dict(data, custom=custom), persist=False)

    def test_supervisor_rejects_over_limit_before_starting_process(self):
        from nilt.control import supervise_search
        cfg = load_project(self.config, "workstation_50h")[0]
        with patch("nilt.control.subprocess.Popen") as launch:
            with self.assertRaisesRegex(ValueError, "50 hours"):
                supervise_search(cfg=cfg, hours=51)
            launch.assert_not_called()


class BackboneTests(unittest.TestCase):
    def test_every_catalog_model_builds_a_binary_head_without_allocating_weights(self):
        for name in CATALOG:
            with self.subTest(name=name), torch.device("meta"):
                model, head = make_model(name, {"model_usage": "research"}, pretrained=False)
                self.assertEqual(head.out_features, 2)
                self.assertEqual(model.inspection_architecture, name)
                del model, head

    def test_representative_families_support_native_canvas_training_scopes(self):
        from nilt.backbones import last_block
        for name in ("convnextv2-atto", "convnext-tiny", "deit3-small", "swinv2-tiny", "eva02-tiny", "efficientnetv2-s"):
            with self.subTest(name=name):
                model, head = make_model(name, {"model_usage": "research"})
                stage = configure_training_stage(model, head, name,
                    {"mode": "head_only", "warmup_epochs": 0}, 0)
                self.assertEqual(stage["trainable_parameters"], sum(p.numel() for p in head.parameters()))
                configure_training_stage(model, head, name,
                    {"mode": "last_block", "warmup_epochs": 0}, 0)
                output = model(torch.zeros(1, 3, 64, 64))
                self.assertEqual(tuple(output.shape), (1, 2))
                output.sum().backward()
                self.assertTrue(any(p.grad is not None for p in last_block(model, name).parameters()))
                self.assertTrue(all(p.grad is not None for p in head.parameters()))
                del model, head, output

    def test_checkpoint_retains_model_specific_normalization_and_usage(self):
        with tempfile.TemporaryDirectory() as directory:
            cfg = merge_dict(DEFAULTS, {"task": "vig", "models": ["eva02-tiny"], "image_size": 64,
                                       "model_usage": "research"})
            model, _ = make_model("eva02-tiny", cfg)
            model.eval()
            filename = Path(directory) / "checkpoint.pt"
            save_checkpoint(filename, model, cfg, "eva02-tiny", 42, 1)
            restored, metadata = load_checkpoint(filename, cfg, torch.device("cpu"))
            self.assertEqual(metadata["mean"], normalization("eva02-tiny")[0])
            self.assertEqual(metadata["model_config"]["model_usage"], "research")
            with torch.inference_mode():
                inputs = torch.zeros(1, 3, 65, 65)
                self.assertTrue(torch.equal(model(inputs), restored(inputs)))


PAYLOAD = b"synthetic-safetensors-download-fixture"
DIGEST = hashlib.sha256(PAYLOAD).hexdigest()


class HubWeightTests(unittest.TestCase):
    def descriptor(self):
        name = "convnextv2-atto"
        spec = CATALOG[name]
        return {"model": name, "weight": spec.checkpoint, "filename": f"{name}__IMAGENET1K.safetensors",
                "source": f"https://huggingface.co/{spec.repo_id}/resolve/{'a' * 40}/model.safetensors",
                "revision": "a" * 40, "license": spec.license, "sha256_prefix": DIGEST}

    def config(self, root, enabled=True):
        return {"models": ["convnextv2-atto"], "model_usage": "research",
                "weights_dir": str(root), "pretrained": True, "download_missing_weights": enabled}

    def test_metadata_requires_license_and_full_published_hash(self):
        metadata = {"cardData": {"license": "cc-by-nc-4.0"}, "sha": "a" * 40,
                    "siblings": [{"rfilename": "model.safetensors", "lfs": {"sha256": DIGEST}}]}
        with patch("nilt.hub_weights._request_json", return_value=metadata):
            descriptor = descriptor_for("convnextv2-atto", self.config("unused"), 15)
            self.assertEqual(descriptor["sha256_prefix"], DIGEST)
            metadata["cardData"]["license"] = "mit"
            with self.assertRaisesRegex(ValueError, "license changed"):
                descriptor_for("convnextv2-atto", self.config("unused"), 15)

    def test_cached_weights_are_verified_offline_without_api_access(self):
        with tempfile.TemporaryDirectory() as directory:
            descriptor = self.descriptor()
            Path(directory, descriptor["filename"]).write_bytes(PAYLOAD)
            write_json(Path(directory, "weights_manifest.json"), [descriptor])
            with patch("nilt.hub_weights._request_json") as network:
                result = ensure_pretrained_weights(self.config(directory, False))
                network.assert_not_called()
            self.assertEqual(result[0]["sha256"], DIGEST)
            self.assertEqual(weight_path(self.config(directory), "convnextv2-atto").suffix, ".safetensors")

    def test_missing_offline_weights_and_provenance_do_not_request_network(self):
        with tempfile.TemporaryDirectory() as directory, patch("nilt.hub_weights._request_json") as network:
            with self.assertRaisesRegex(FileNotFoundError, "disabled"):
                ensure_pretrained_weights(self.config(directory, False))
            network.assert_not_called()

    def test_wrong_manifest_and_corrupted_weights_are_preserved(self):
        with tempfile.TemporaryDirectory() as directory:
            descriptor = self.descriptor()
            target = Path(directory, descriptor["filename"])
            target.write_bytes(b"corrupt")
            write_json(Path(directory, "weights_manifest.json"), [descriptor])
            with self.assertRaisesRegex(ValueError, "Checksum mismatch"):
                ensure_pretrained_weights(self.config(directory, False))
            self.assertEqual(target.read_bytes(), b"corrupt")
            descriptor["source"] = "https://example.com/weights"
            write_json(Path(directory, "weights_manifest.json"), [descriptor])
            with self.assertRaisesRegex(ValueError, "Invalid pinned"):
                ensure_pretrained_weights(self.config(directory, False))

    def test_atomic_download_checks_hash_and_length(self):
        for payload in (PAYLOAD, b"corrupt"):
            with self.subTest(payload=payload), tempfile.TemporaryDirectory() as directory:
                descriptor = self.descriptor()
                response = io.BytesIO(payload)
                response.headers = {"Content-Length": str(len(payload))}
                response.geturl = lambda: "https://us.aws.cdn.hf.co/public-fixture"
                opener = MagicMock()
                opener.open.return_value = response
                with patch("nilt.hub_weights.descriptor_for", return_value=descriptor), \
                     patch("nilt.hub_weights.build_opener", return_value=opener):
                    if payload == PAYLOAD:
                        ensure_pretrained_weights(self.config(directory))
                        self.assertEqual(Path(directory, descriptor["filename"]).read_bytes(), PAYLOAD)
                        self.assertEqual(read_json(Path(directory, "weights_manifest.json"))[0]["sha256"], DIGEST)
                    else:
                        with self.assertRaisesRegex(ValueError, "Checksum mismatch"):
                            ensure_pretrained_weights(self.config(directory))
                        self.assertFalse(Path(directory, descriptor["filename"]).exists())
                self.assertFalse(list(Path(directory).glob("*.download")))

    def test_budget_and_cancel_stop_provisioning(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(TrainingStopped):
                ensure_pretrained_weights(self.config(directory), deadline=time.time() - 1)
            with self.assertRaisesRegex(TrainingStopped, "operator_cancel"):
                ensure_pretrained_weights(self.config(directory), stop_check=lambda: "operator_cancel")

    def test_untrusted_http_or_redirect_destinations_are_rejected(self):
        for url in ("http://huggingface.co/file", "https://huggingface.co.evil.test/file",
                    "https://user:password@huggingface.co/file", "https://example.com/file"):
            with self.assertRaises(ValueError):
                _hub_url(url)


class RuntimeNormalizationTests(unittest.TestCase):
    def test_each_exported_member_gets_its_own_normalization(self):
        from nilt.runtime import PackageRunner
        runner = PackageRunner.__new__(PackageRunner)
        runner.preprocessing = {"mean": [0.485, 0.456, 0.406], "std": [0.229, 0.224, 0.225]}
        standard, eva = MagicMock(), MagicMock()
        standard.run.return_value = eva.run.return_value = np.array([.5], dtype=np.float32)
        a = {"input_name": "images", "output_name": "bad_score"}
        b = {**a, "mean": [.5, .5, .5], "std": [.5, .5, .5]}
        runner.sessions = [(a, standard), (b, eva)]
        tensor = np.zeros((1, 3, 2, 2), dtype=np.float32)
        self.assertEqual(runner.score_tensor(tensor), .5)
        self.assertTrue(np.array_equal(standard.run.call_args.args[1]["images"], tensor))
        actual = eva.run.call_args.args[1]["images"]
        expected = (np.asarray(runner.preprocessing["mean"], dtype=np.float32) - .5) / .5
        np.testing.assert_allclose(actual[0, :, 0, 0], expected)


if __name__ == "__main__":
    unittest.main()
