# Configuration Reference

> The shipped `project.yaml` and [EXPERIMENT_GUIDE.md](EXPERIMENT_GUIDE.md)
> define current profiles. Schema version 3 is retained for compatibility.

For the v5 GUI search-contract schema, see [CUSTOM_OPTUNA.md](CUSTOM_OPTUNA.md). For independently versioned Good/Review/Bad systems, see [DECISION_LAB.md](DECISION_LAB.md). A project schema version is not the application release number.

## Project file

The supplied `project.yaml` is the primary operator interface. Top-level sections are `schema_version`, `project_name`, `paths`, `defaults`, `profiles`, and `tasks`. Each task may override the common model, training, preprocessing, grouping, or policy settings. The resolved run configuration records the effective values.

Relative paths resolve from the project file directory. Use local absolute paths or project-relative paths; a Windows drive path cannot be used directly on Linux. To relocate an existing run, use `restore --data-root` instead of editing its frozen manifest or configuration.

| Project path | Meaning |
| --- | --- |
| `paths.output_root` | Parent of per-task run directories and local registry |
| `paths.weights_root` | Locally provisioned pretrained weights |
| `paths.incoming_root` | Parent of incoming per-task image directories |
| `paths.classification_output_root` | Parent of generated prediction batch directories |
| `tasks.<task>.dataset_root` | Dataset directory containing `good` and `bad` |
| `tasks.<task>.enabled` | Whether the task participates in project commands |

For configuration-driven inference, the incoming task directory is derived from the configured incoming root. Explicit `--input` and `--output` arguments select a particular batch.

## Configuration precedence

Effective settings are merged in this order, with later values overriding earlier ones:

1. Application defaults.
2. Built-in selected profile.
3. Project `defaults`.
4. Project `profiles.<selected_profile>`.
5. Task-specific settings.

This permits explicit task choices to override profile presets. Review `resolved_config.yaml` when diagnosing a surprising value. A workstation profile does not override a task's explicit smaller model roster or image-size choice.

Legacy flat single-task configurations containing `task`, `data_root`, `output_root`, and `weights_dir` are also accepted. Prefer the project schema for multi-task operations and the current-model registry.

`configs/top_only.yaml` provides a minimal top-only project, and `configs/patchcore_only.yaml` selects a single PatchCore-style candidate. Their paths resolve relative to `configs`, as shown by the supplied `../data` and `../weights` values.

## Profiles

| Shipped project setting | Laptop | Workstation | Large workstation |
| --- | --- | --- | --- |
| Profile key | `laptop` | `workstation` | `workstation_large` |
| Device | `cpu` | `cuda` | `cuda` |
| Candidate models | ResNet18, EfficientNet-B0 | EfficientNet-B0, ConvNeXt-Tiny | EfficientNet-B0, ConvNeXt-Tiny, EfficientNetV2-S |
| Initial search budget | 2 hours | 6 hours | 12 hours |
| Maximum trials per family | 8 | 16 | 32 |
| Seeds | `[42]` | `[42, 123]` | `[42, 123, 2026]` |
| Maximum epochs | 15 | 30 | 40 |
| Warm-up epochs | 2 | 2 | 2 |
| Early-stop patience | 5 | 7 | 8 |
| Training/evaluation microbatch | 1 / 1 | 2 / 2 | 2 / 2 |
| Gradient accumulation | 8 | 8 | 8 |
| Mixed precision | Disabled | CUDA training | CUDA training |
| Ensembles | Disabled | Enabled | Enabled |

These are initial budgets, not ceilings or universally optimal settings. In Custom Optuna the top-level `device`, `cpu_threads`, and `num_workers` fields override the execution defaults. `search.total_budget_seconds` accepts any positive finite value independent of the selected profile. The contract preview records the exact effective settings. The default high-resolution batch is intentionally small. Increase it only after measuring target-machine memory. No profile silently changes image resolution or an existing package's decision rule.

To include PatchCore in a CPU pilot, set the laptop profile's `models` to `[resnet18, patchcore]` and use explicit smaller PatchCore budgets. This is still a pilot experiment.

## General model and data fields

| Field | Default | Meaning |
| --- | --- | --- |
| `models` | Profile shortlist | Unique subset of `resnet18`, `resnet50`, `efficientnet_b0`, `efficientnet_b2`, `efficientnet_v2_s`, `mobilenet_v3_large`, `densenet121`, `convnext_tiny`, `swin_t`, `patchcore` |
| `seeds` | `[42, 123]` | Unique training seeds; overridden by laptop profile |
| `pretrained` | `true` | Require local pretrained backbone files |
| `image_strategy` | `full_image` | `full_image` or supervised `global_patches`; fixed within a search |
| `patches` | See project defaults | Patch size, overlap, maximum count, chunk size, max/top-k pooling, global margin weight |
| `split_seed` | `42` | Deterministic grouped allocation seed |
| `split_fractions` | `.55/.10/.10/.10/.15` | `train/val/threshold/selection/test`; positive fractions summing to one |
| `dataset_version` | Optional | Operator-assigned source revision identifier |
| `groups_csv` | `null` | Complete relative-path to physical-unit mapping |
| `group_regex` | `null` | Alternative relative-path extraction rule with named `group` capture |
| `independent_units_confirmed` | `false` | Explicit confirmation that reported groups represent independent units |
| `near_duplicate_distance` | `2` | Perceptual-hash distance for review candidates |
| `near_duplicate_report_limit` | `10000` | Maximum review pairs written by the bounded near-duplicate audit |
| `export_images` | `true` | Copy prediction/error images alongside CSV reports |
| `ensembles` | `true` | Add compatible supervised score-mean candidates |
| `fine_tune_previous` | `true` | Include fine-tuned previous supervised members in update runs |
| `continue_on_model_error` | `false` | Stop on a candidate failure rather than silently completing a partial roster |
| `device` | Profile suggestion | `cpu`, `cuda`, or `auto`; an explicit CUDA request does not silently fall back |
| `cpu_threads` | `4` | PyTorch CPU execution threads |
| `num_workers` | `0` | Data-loader worker processes |

Split fractions are targets subject to indivisible groups and any valid existing split hints. The audit and split summary report actual counts. Five development/test roles require enough independent good and bad groups; the software does not replace them with automatic cross-validation.

Existing class-first (`good/train`, `bad/train`) and split-first (`train/good`, `train/bad`) layouts are supported when the entire input uses one consistent layout. Mixing split and unsplit images, or combining class-first and split-first trees under one root, is rejected. Unit groups and content-identical images cannot straddle existing split boundaries.

## Physical-unit mapping

Use either `groups_csv` or `group_regex`, not both. CSV columns are exactly `relative_path` and `group`. Paths are relative to the task dataset root and use forward slashes:

```csv
relative_path,group
good/tray_A/unit_001_start.png,tray_A_unit_001
good/tray_A/unit_001_final.png,tray_A_unit_001
bad/tray_B/unit_007_start.png,tray_B_unit_007
bad/tray_B/unit_007_final.png,tray_B_unit_007
```

Every input image must have a nonempty mapping. Unit names must include tray identity if unit identifiers restart in each tray. A physical unit can contain both good and bad image labels; its whole group still stays together.

For filenames of the form `tray_A_unit_001_start.png` and `tray_A_unit_001_final.png`, a suitable extraction pattern may be:

```yaml
group_regex: '(?P<group>tray_[A-Za-z0-9]+_unit_[0-9]+)_(?:start|final)'
```

Adapt this to the actual naming convention and inspect the audit output. A regex that matches only an image counter can silently encode the wrong independence assumption. The generated `groups_template.csv` is a starting mapping, not proof that the groups are physical units.

The shipped `grouping: tray_unit` derives a physical-unit key from tray, row, and column filename tokens when no explicit mapping is supplied. This keeps repeat captures together but does not hold out an entire tray. If this naming convention does not identify the true physical unit, supply an explicit mapping. The `independent_units_confirmed` field must not be used to hide uncertainty about independence.

## Supported inputs and geometry

Supported extensions are PNG, JPEG, BMP, TIFF, and WebP. Images must be single-frame and compatible with the documented 8-bit RGB conversion. EXIF orientation is applied before identity and dimensions are calculated. Integer high-bit-depth or floating-point images require explicit upstream intensity conversion; multi-frame files require explicit frame extraction. These operations are not performed silently.

| Field | Default | Meaning |
| --- | --- | --- |
| `image_size` | `auto` | Integer square envelope of at least 32 pixels, or resolve maximum input width/height |
| `image_size_limit` | `4096` | Maximum allowed envelope; an explicit resource guard rather than a resize target |
| `resize` | `pad` | `pad` preserves pixels; `fit` scales explicitly then pads |

`pad` centers images using an RGB background of `(124, 116, 104)`. `fit` uses aspect-preserving bilinear resizing into the square envelope and then the same padding. Normalization uses RGB means `[0.485, 0.456, 0.406]` and standard deviations `[0.229, 0.224, 0.225]`.

An explicit source envelope above `image_size_limit` fails before training. Set a higher limit only after assessing memory, or specify `fit` plus an explicit evaluated target size. Keeping `auto` does not guarantee the resolved native resolution fits GPU memory. Automatic die cropping is not supported. The optional `global_patches` image strategy processes exhaustive overlapping local windows alongside the complete image; it does not replace the global branch or downsample it.

## Training fields

All fields below are nested under `training` in `defaults`, a profile, or a task override.

| Field | Default | Meaning |
| --- | --- | --- |
| `epochs` | `30` | Maximum supervised epochs |
| `warmup_epochs` | `2` | Initial head-focused training before full fine-tuning |
| `patience` | `7` | Validation non-improvement patience |
| `batch_size` | `2` | Training images per forward batch |
| `eval_batch_size` | `2` | Evaluation images per batch |
| `accumulation_steps` | `8` | Gradient accumulation factor |
| `learning_rate` | `0.0001` | Backbone learning rate |
| `head_learning_rate` | `0.001` | Classification-head learning rate |
| `weight_decay` | `0.0001` | Optimizer weight decay |
| `fine_tune_lr_factor` | `0.2` | Learning-rate multiplier when initialized from a previous candidate |
| `amp` | `true` | CUDA mixed precision when applicable |
| `freeze_batch_norm` | `true` | Keep BatchNorm running statistics fixed for small batches |
| `imbalance` | `auto` | `auto`, `none`, `weighted_loss`, or `sampler` |
| `imbalance_trigger` | `1.5` | Training majority/minority ratio triggering automatic weighted loss |
| `max_class_weight` | `20.0` | Cap on minority weighting/sampling correction |

The best supervised checkpoint is selected by validation PR-AUC for bad. `last.pt` preserves continuation state. Gradient accumulation changes effective optimization batching; it does not reduce the memory required by a single large image. The final smaller accumulation window is handled by the backend.

`training.amp` applies to supervised training only. Validation, threshold tuning, candidate selection, testing, and inference use the canonical float32 scoring path. There is no reduced-precision inference option in this release.

## Augmentation

The shipped project sets `augmentation.brightness`, `contrast`, and `rotation_degrees` to zero. Only `tasks.vig.augmentation.rotation90` is enabled. Training uses exact 0, 90, 180, or 270 degree rotations without interpolation or label changes. Validation, calibration, selection, and test are not randomly augmented. Top and bottom augmentation remains off. No transformed files are added to the source dataset.

## PatchCore fields

| Field under `patchcore` | Project default | Meaning |
| --- | --- | --- |
| `backbone` | `resnet18` | `resnet18` or `resnet50`; local pretrained weights required when enabled |
| `reservoir_size` | `10000` | Maximum retained normal patch features before coreset selection |
| `coreset_size` | `512` | Maximum memory-bank features; must not exceed reservoir size |
| `projection_dim` | `32` | Projection size used by greedy coreset selection |
| `query_chunk_size` | `1024` | Query-feature batch size during distance calculation |
| `memory_chunk_size` | `1024` | Bank-feature batch size during distance calculation |

The laptop profile overrides the reservoir and coreset to `4000` and `256` if PatchCore is explicitly enabled. The reservoir and bank budgets control representativeness as well as memory. Bank reduction creates a new model version. Query/memory chunking bounds a distance calculation but does not eliminate feature-extractor memory requirements at high resolution.

## Decision and release policy

| Field | Default | Meaning |
| --- | --- | --- |
| `policy.max_bad_escape_rate` | `0.01` | Maximum bad-image escape rate used by the empirical policy |
| `policy.max_good_reject_rate` | `0.20` | Maximum permitted good-image rejection rate |
| `policy.confidence` | `0.95` | One-sided independent-unit confidence level |
| `policy.threshold_margin` | `true` | Place the fitted threshold inside an interval preserving fitted decisions, away from observed score boundaries |
| `release.require_statistical_evidence` | `true` | Require the bad-unit upper confidence bound to satisfy the target |
| `release.require_complete_comparison` | `true` | Disallow activation after an incomplete intended candidate roster |

The example one-percent target is not proof that any trained model can achieve it. Counts and confidence intervals determine the evidence available. Even zero escapes among 100 independent bad units is insufficient for a 95% upper bound below one percent.

Threshold margins reduce sensitivity to a cutoff that lies exactly on an observed score. They do not calibrate scores, guarantee robust unseen decisions, or replace the mandatory ONNX numerical and decision parity checks.

## Deployment tolerance fields

The `deployment` section records export settings and accepted numerical differences. `opset` defaults to 17. Export validation compares PyTorch and ONNX scores using `score_atol` and `score_rtol` and records threshold decision disagreements. The default tolerances are `1e-5` absolute and `1e-4` relative, with zero permitted decision disagreements. The exporter implementation's supported opset and validation requirements remain authoritative.

Tolerance changes do not repair a semantically different graph. Review why differences occur before altering a parity threshold. CPU-export verification does not imply destination GPU-provider qualification.
