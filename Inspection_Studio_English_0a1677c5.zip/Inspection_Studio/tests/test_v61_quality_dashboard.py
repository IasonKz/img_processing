"""Quality evidence routes keep image data and file writes within the workspace."""
from http.server import ThreadingHTTPServer
import json
from pathlib import Path
import tempfile
import threading
import unittest
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from unittest.mock import patch

from nilt.common import write_json
from nilt.dashboard import Dashboard, make_handler
from nilt.review import initialize_session, append_prediction


class QualityDashboardTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.config = self.root / "project.yaml"
        self.config.write_text("tasks:\n  vig:\n    enabled: true\n    dataset_root: ./images\n", encoding="utf-8")
        self.app = Dashboard(self.config)
        self.run = self.root / "results" / "vig" / "run"
        write_json(self.run / "config.json", {"task": "vig", "models": ["resnet18"], "device": "cpu"})
        write_json(self.run / "model_state.json", {"status": "TRAINED"})
        self.session = self.root / "classified" / "batch1"
        initialize_session(self.session, metadata={"task": "vig"}, total=1)
        append_prediction(self.session, {"relative_path": "C0000083_Rc09Cc17.png", "prediction": "review",
                                         "reference_label": "bad", "bad_score": .5, "file_sha256": "a" * 64})

    def tearDown(self):
        self.tmp.cleanup()

    def test_catalog_contains_runs_sessions_and_local_report_root(self):
        catalog = self.app.quality_catalog()
        self.assertIn(str(self.run), [r["path"] for r in catalog["runs"]])
        self.assertIn(str(self.session), [r["path"] for r in catalog["sessions"]])
        self.assertEqual(catalog["report_root"], str(self.root / "quality_reports"))

    def test_preview_does_not_write_or_infer(self):
        with patch("nilt.quality.build_quality_report", return_value={"schema_version": 1}) as build:
            result = self.app.quality_preview({"runs": [str(self.run)], "sessions": [str(self.session)], "title": "Tray comparison"})
        self.assertEqual(result["report"]["schema_version"], 1)
        self.assertFalse(self.app.quality_root.exists())
        self.assertEqual(build.call_args.args[:2], ([self.run], [self.session]))

    def test_report_requests_require_recorded_evidence_and_bounded_text(self):
        for payload in ({}, {"runs": "wrong"}, {"sessions": [str(self.root)]},
                        {"runs": [str(self.run)], "title": " "},
                        {"runs": [str(self.run)], "notes": "x" * 20001},
                        {"runs": [str(self.run)], "sessions": [str(self.root / "other")]}):
            with self.assertRaises((ValueError, FileNotFoundError)):
                self.app._quality_request(payload)

    def test_historical_session_registration_uses_exact_folder_and_survives_restart(self):
        external = self.root / "previous_release" / "inspected_tray83"
        initialize_session(external, metadata={"task": "vig"}, total=0)
        result = self.app.quality_load_session({"path": str(external)})
        self.assertIn(str(external), [r["path"] for r in result["sessions"]])
        self.assertIn(external, self.app.output_roots)
        self.assertNotIn(external.parent, self.app.output_roots)
        reopened = Dashboard(self.config)
        self.assertIn(str(external), [r["path"] for r in reopened.quality_catalog()["sessions"]])
        with self.assertRaises(ValueError):
            self.app.quality_load_session({"path": str(self.root)})

    def test_real_preview_and_export_keep_provisional_evidence_visible(self):
        payload = {"runs": [str(self.run)], "sessions": [str(self.session)], "title": "Tray quality", "notes": "Pilot batch"}
        report = self.app.quality_preview(payload)["report"]
        self.assertTrue(report["sessions"])
        result = self.app.quality_export(payload)
        self.assertTrue(Path(result["html"]).is_file())
        self.assertTrue(Path(result["directory"]).is_relative_to(self.app.quality_root))
        self.assertTrue(result["html_url"].startswith("/results/"))
        self.assertTrue(result["file_links"])
        second = self.app.quality_export(payload)
        self.assertNotEqual(result["directory"], second["directory"])

    def test_http_quality_routes_require_session_token_and_serve_assets(self):
        server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(self.app))
        worker = threading.Thread(target=server.serve_forever, daemon=True)
        worker.start()
        base = f"http://127.0.0.1:{server.server_port}"
        try:
            with urlopen(base + "/api/quality/catalog") as response:
                self.assertIn("runs", json.load(response))
            payload = json.dumps({"runs": [str(self.run)]}).encode()
            req = Request(base + "/api/quality/preview", data=payload, headers={"Content-Type": "application/json"})
            with self.assertRaises(HTTPError) as error:
                urlopen(req)
            self.assertEqual(error.exception.code, 403)
            req.add_header("X-Inspection-Token", self.app.token)
            with urlopen(req) as response:
                self.assertIn("report", json.load(response))
        finally:
            server.shutdown()
            server.server_close()
            worker.join(timeout=2)


if __name__ == "__main__":
    unittest.main()
