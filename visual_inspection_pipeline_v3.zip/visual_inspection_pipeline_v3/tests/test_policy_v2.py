"""Decision-policy regression tests independent of the training runtime."""
from __future__ import annotations

import unittest

import numpy as np

from nilt.policy import evidence_pass, escape_upper_bound, metrics, tune_threshold


class PolicyV2Tests(unittest.TestCase):
    def test_raw_patchcore_scores_use_the_same_bad_event_orientation(self):
        labels = [0, 0, 1, 1]
        scores = [9.0, 2.5, 4.0, 0.2]
        result = metrics(labels, scores, 3.0)
        self.assertEqual(result["bad_detected_TP"], 1)
        self.assertEqual(result["bad_passed_as_good_FN"], 1)
        self.assertEqual(result["good_rejected_as_bad_FP"], 1)
        self.assertEqual(result["good_accepted_TN"], 1)
        self.assertEqual(result["accepted_contamination"], 0.5)

    def test_raw_patchcore_threshold_can_exceed_one(self):
        threshold = tune_threshold([0, 0, 1, 1], [8.2, 11.3, 1.1, 3.6],
                                   {"max_bad_escape_rate": 0.0})
        self.assertGreater(threshold, 1.0)
        report = metrics([0, 0, 1, 1], [8.2, 11.3, 1.1, 3.6], threshold)
        self.assertEqual(report["bad_passed_as_good_FN"], 0)
        self.assertEqual(report["good_rejected_as_bad_FP"], 0)

    def test_scale_changes_threshold_without_changing_decisions(self):
        y = np.array([0, 0, 0, 1, 1, 1])
        scores = np.array([0.6, 0.7, 0.9, 0.1, 0.4, 0.65])
        policy = {"max_bad_escape_rate": 0.0}
        small = tune_threshold(y, scores, policy)
        large = tune_threshold(y, scores * 37.0, policy)
        np.testing.assert_array_equal(scores >= small, scores * 37.0 >= large)

    def test_optional_threshold_margin_preserves_tuned_decisions(self):
        y = [0, 0, 1, 1]
        s = np.array([8.0, 11.0, 1.0, 3.0])
        exact = tune_threshold(y, s, {"max_bad_escape_rate": 0.0})
        margin = tune_threshold(y, s, {"max_bad_escape_rate": 0.0, "threshold_margin": True})
        self.assertGreater(margin, 3.0)
        self.assertLess(margin, 8.0)
        np.testing.assert_array_equal(s >= exact, s >= margin)

    def test_optional_margin_handles_a_single_distinct_score(self):
        y, s = [0, 1], np.array([4.0, 4.0])
        threshold = tune_threshold(y, s, {"max_bad_escape_rate": 0.0, "threshold_margin": True})
        self.assertTrue(np.isfinite(threshold))
        self.assertTrue(np.all(s >= threshold))

    def test_tied_scores_are_rejected_at_the_threshold(self):
        report = metrics([0, 1], [12.0, 12.0], 12.0)
        self.assertEqual(report["bad_detected_TP"], 1)
        self.assertEqual(report["good_rejected_as_bad_FP"], 1)

    def test_independent_units_determine_confidence_support(self):
        policy = {"max_bad_escape_rate": 0.01, "max_good_reject_rate": 0.1}
        labels, scores = [0] * 300 + [1] * 10, [0.9] * 300 + [0.1] * 10
        repeated_units = [f"bad{i // 10}" for i in range(300)] + [f"good{i}" for i in range(10)]
        repeated = metrics(labels, scores, 0.5, repeated_units)
        independent = metrics(labels, scores, 0.5, [str(i) for i in range(310)])
        self.assertEqual(repeated["n_bad_units"], 30)
        self.assertFalse(evidence_pass(repeated, policy))
        self.assertTrue(evidence_pass(independent, policy))

    def test_absent_bad_support_never_qualifies(self):
        report = metrics([1, 1], [0.1, 0.2], 0.5)
        self.assertFalse(evidence_pass(report, {"max_bad_escape_rate": 0.01,
                                               "max_good_reject_rate": 0.1}))
        self.assertIsNone(report["bad_unit_escape_upper"])

    def test_rejecting_everything_has_no_defined_accepted_contamination(self):
        report = metrics([0, 1], [0.2, 0.8], 0.0)
        self.assertIsNone(report["accepted_contamination"])
        self.assertEqual(report["good_reject_rate"], 1.0)

    def test_group_length_mismatch_is_an_error(self):
        with self.assertRaises(ValueError):
            metrics([0, 0, 1], [0.9, 0.2, 0.1], 0.5, ["only_one"])

    def test_nonfinite_scores_and_thresholds_are_rejected(self):
        for invalid in (float("nan"), float("inf"), -float("inf")):
            with self.subTest(score=invalid):
                with self.assertRaises(ValueError):
                    metrics([0, 1], [invalid, 0.1], 0.5)
            with self.subTest(threshold=invalid):
                with self.assertRaises(ValueError):
                    metrics([0, 1], [0.9, 0.1], invalid)

    def test_group_unit_escape_is_conservative_across_views(self):
        report = metrics([0, 0, 0, 1], [0.9, 0.1, 0.9, 0.1], 0.5,
                         ["unit_a", "unit_a", "unit_b", "unit_c"])
        self.assertEqual(report["n_escaped_bad_units"], 1)
        self.assertEqual(report["n_bad_units"], 2)
        self.assertEqual(report["bad_passed_as_good_FN"], 1)

    def test_zero_misses_confidence_bound_matches_binomial_identity(self):
        expected = 1.0 - 0.05 ** (1.0 / 100)
        self.assertAlmostEqual(escape_upper_bound(0, 100, confidence=0.95), expected, places=12)


if __name__ == "__main__":
    unittest.main()
