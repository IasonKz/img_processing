"""Native ROI crop pixels; RGB previews are separate from model input."""
from pathlib import Path

import numpy as np


def read_native(path, max_pixels=25_000_000):
    from nilt.image_io import load_rgb
    image = load_rgb(path)
    if image.width * image.height > max_pixels:
        raise ValueError(f"Image exceeds the configured {max_pixels} pixel limit.")
    return image


def display(image):
    from nilt.image_io import display_image
    return display_image(image)


def save_png(path, image):
    from nilt.image_io import NativeImage
    if not isinstance(image, NativeImage):
        image.save(path, format="PNG")
        return
    import cv2
    success, encoded = cv2.imencode(".png", np.asarray(image)[:, :, ::-1])
    if not success:
        raise ValueError("Native ROI crop PNG encoding failed.")
    Path(path).write_bytes(encoded.tobytes())
