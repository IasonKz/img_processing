# Validation scope

Automated verification exercises the training/search lifecycle, decisions, data grouping, report generation, model packaging, workflow composition, and image review behavior. The final counts, execution environment, and limitations are recorded in [RELEASE_VERIFICATION.md](RELEASE_VERIFICATION.md); retain it with the archive.

Software checks use synthetic or controlled fixtures. They do not establish defect-detection performance on a customer's image dataset. Windows launchers and CUDA training must also be exercised on the destination hardware; a Linux test does not validate Windows process, filesystem, driver, or endpoint-control behavior.

## Installation acceptance on each computer

1. Run `Setup.cmd` and retain `environment-installed.txt`.
2. Confirm the requested CPU or CUDA model forward/backward check passes.
3. Run **Check installation** with the intended profile and all required weights.
4. Audit a representative dataset and review conflicts and group counts.
5. Complete a short training/classification/review operation locally.
6. Check copied images, original/reference tags, decisions, and output locations.
7. For an inspection workflow, confirm known examples produce the expected per-stage trace and final rule.

## Model and workflow acceptance

Freeze model artifacts, preprocessing, thresholds, stage order, and final decision rule before an independent evaluation. Measure both error classes, denominators, uncertainty, throughput, and invalid-input handling. Include conditions and defect types representative of deployment.

Unit grouping by tray/row/column does not hold out an entire tray. Data from three trays can support development, but cannot by itself establish performance on unseen batches or future drift. Evaluate new trays or batches independently before making that claim.

No certification, PLC integration, unattended service guarantee, or site-specific production qualification is asserted by this software release.
