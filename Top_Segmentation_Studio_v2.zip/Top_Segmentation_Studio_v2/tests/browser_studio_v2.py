"""Real Chromium workflow, same-window Studio and annotation preview/persistence."""
from pathlib import Path
import json, re, sys, threading, shutil, tempfile
import numpy as np
from PIL import Image, ImageDraw
from playwright.sync_api import sync_playwright, expect
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE))
from topseg.studio_server import StudioServer
from topseg.common import load_config, sha256
from topseg.project import Project
from topseg.annotations import decode_rle
temporary=tempfile.TemporaryDirectory(prefix='topseg-v2-browser-')
root=Path(temporary.name)/'project'
output=BASE/'docs'/'screenshots'
output.mkdir(parents=True,exist_ok=True)
(root/'input').mkdir(parents=True)
w,h=720,640
im=Image.new('RGB',(w,h),(30,31,34));d=ImageDraw.Draw(im)
d.rectangle((145,90,575,550),fill=(127,129,130),outline=(160,161,163),width=3)
points=[(245,160),(480,160),(515,194),(515,459),(484,490),(245,490),(208,454),(208,192)]
d.polygon(points,fill=(119,121,123));d.line(points+[points[0]],fill=(155,155,155),width=2)
d.text((163,102),'NILT 04',fill=(213,213,213));d.line([(549,112),(549,135),(526,112),(549,112)],fill=(197,197,197),width=3)
d.line([(164,523),(164,500),(185,523),(164,523)],fill=(197,197,197),width=3)
arr=np.asarray(im).copy(); yy,xx=np.ogrid[:h,:w];r=np.hypot(xx-360,yy-324);eye=r<65
rings=(119+26*np.cos(r*.5)).astype(np.uint8)
arr[eye]=np.repeat(rings[eye,None],3,axis=1)
for i in range(3):
 a=arr.copy()
 if i==0: a[278:282,347:371]=32;a[188:193,289:300]=25
 if i==2:a[220:225,410:420]=30
 Image.fromarray(a).save(root/'input'/f'top_{i:02d}.png')
config=root/'project.yaml';config.write_text('input_dir: input\nproject_dir: annotations\noutput_dir: results\n')
cfg=load_config(config);project=Project(cfg);project.import_images()
originals={x.name:sha256(x) for x in (root/'input').glob('*.png')}
srv=StudioServer(cfg,config,0);threading.Thread(target=srv.serve_forever,daemon=True).start()
url=f'http://127.0.0.1:{srv.server_port}'
errors=[]; requests=[]
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,args=['--no-sandbox'])
  page=browser.new_page(viewport={'width':1600,'height':1040})
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('dialog',lambda d:d.accept())
  page.goto(url);expect(page.locator('#count-total')).to_have_text('3')
  page.click('[data-tab="annotation"]')
  frame=page.frame_locator('#annotation-frame')
  expect(frame.locator('#image-name')).to_have_text('top_00.png')
  expect(frame.locator('#regenerate')).to_be_enabled()
  f=page.locator('#annotation-frame').element_handle().content_frame()
  def req(path,payload=None):
   return f.evaluate('''async ({path,payload})=>{const token=document.querySelector('meta[name="session-token"]').content;const r=await fetch(path,{method:payload===null?'GET':'POST',headers:{'X-Session-Token':token,'Content-Type':'application/json'},...(payload===null?{}:{body:JSON.stringify(payload)})});return {status:r.status,data:await r.json()}}''',{'path':path,'payload':payload})
  image_id=project.items()[0]['id'];path=f'/api/image/{image_id}'
  first=req(path)['data'];revision=first['revision']
  def show_details(selector):
   frame.locator(selector).evaluate('(e)=>{for(let n=e.parentElement;n;n=n.parentElement)if(n.tagName==="DETAILS")n.open=true;}')
  def point(x,y):
   canvas=frame.locator('#image-canvas').bounding_box()
   return canvas['x']+x*canvas['width']/w,canvas['y']+y*canvas['height']/h
  def drag(x0,y0,x1,y1):
   page.mouse.move(*point(x0,y0));page.mouse.down();page.mouse.move(*point(x1,y1),steps=6);page.mouse.up()
  def poly(button,coords):
   frame.locator(button).click()
   for x,y in coords: page.mouse.click(*point(x,y))
   page.keyboard.press('Enter')
  def save():
   show_details('#save-draft');frame.locator('#save-draft').click()
   expect(frame.locator('#save-state')).to_have_text(re.compile('Saved revision'))
   return req(path)['data']
  def reload():
   with page.expect_response(lambda r:r.url.endswith('/proposal-preview'),timeout=30000) as pending:
    frame.locator('#regenerate').click()
   response=pending.value
   assert response.status==200,response.text()
   expect(frame.locator('#regenerate')).to_be_enabled(timeout=30000)
  # Custom non-equilateral polygon with independent cuts, stored for all images.
  show_details('#chamfer-width')
  for key,val in {'chamfer-cx':360,'chamfer-cy':325,'chamfer-width':308,'chamfer-height':330,'chamfer-rotation':0,
     'cut-tl-x':39,'cut-tl-y':32,'cut-tr-x':34,'cut-tr-y':35,'cut-br-x':31,'cut-br-y':33,'cut-bl-x':37,'cut-bl-y':36}.items():
   frame.locator('#'+key).fill(str(val))
  frame.locator('#apply-chamfer').click();frame.locator('#save-template').click()
  expect(frame.locator('#template-info')).to_contain_text('revision 1')
  rec=save();assert len(rec['roi']['points'])==8;roi=rec['roi'];revision=rec['revision']
  # Draw label and eye once; new methods remain freely switchable.
  frame.locator('#annotation-method').select_option('exclusions')
  show_details('#draw-zone')
  frame.locator('#zone-category').select_option('label')
  poly('#draw-zone',[(157,97),(229,97),(229,126),(157,126)])
  expect(frame.locator('.zone-row')).to_have_count(1)
  show_details('#draw-eye');frame.locator('#draw-eye').click();drag(291,255,429,393)
  show_details('#save-profile');frame.locator('#save-profile').click()
  expect(frame.locator('#profile-info')).to_contain_text('revision 1')
  # Add manual box and erase a native patch, keep them across three methods.
  frame.locator('[data-tool="rectangle"]').click();drag(287,187,303,199)
  frame.locator('[data-tool="eraser"]').click();frame.locator('#brush-size').fill('16');drag(352,278,366,278)
  frame.locator('#notes').fill('Retain manual defect and erasure across methods')
  before=save();manual=[o for o in before['objects'] if o['kind']!='proposal'];assert manual
  erased=decode_rle(before['manual_edits']['erase_rle'],w,h);assert erased.any()
  revision=before['revision']
  frame.locator('#annotation-method').select_option('structure');reload()
  assert req(path)['data']['revision']==revision # reload is a preview, not saved
  structure=save();assert structure['roi']==roi
  assert [o for o in structure['objects'] if o['kind']!='proposal']==manual
  assert structure['manual_edits']==before['manual_edits']
  frame.locator('#annotation-method').select_option('basic');reload()
  # Dedicated undo restores pre-reload state without an HTTP write.
  frame.locator('#undo-reload').click()
  assert req(path)['data']['revision']==structure['revision']
  reload();basic=save();assert basic['roi']==roi
  assert [o for o in basic['objects'] if o['kind']!='proposal']==manual
  assert basic['manual_edits']==before['manual_edits']
  # Custom scope is independent of the inner lens boundary.
  frame.locator('#detection-scope').select_option('custom')
  poly('#draw-scope',[(144,89),(576,89),(576,551),(144,551)])
  reload();scoped=save();assert scoped['roi']==roi and scoped['automation']['scope']=='custom'
  # A reference-method request with no reference must not lose any annotations.
  frame.locator('#annotation-method').select_option('reference')
  frame.locator('#regenerate').click();expect(frame.locator('#regenerate')).to_be_enabled()
  expect(frame.locator('#toast')).to_contain_text('reference')
  assert req(path)['data']==scoped
  # Select the good second image and run actual aligned comparison.
  reference_id=next(r['id'] for r in project.items() if r['relative_path']=='top_01.png')
  frame.locator('#reference-list input').first.check()
  reload();referenced=save();assert referenced['automation']['method']=='reference'
  assert len(referenced['automation']['reference_ids'])==1
  assert referenced['roi']==roi
  # Save settings before navigating, load template/profile in next image.
  page.screenshot(path=str(output/'v2_methods.png'),full_page=True)
  frame.locator('#next').click();expect(frame.locator('#image-name')).to_have_text('top_01.png')
  next_id=next(r['id'] for r in project.items() if r['relative_path']=='top_01.png')
  next_record=req('/api/image/'+next_id)['data']
  assert next_record['roi']==roi
  assert next_record['automation']['method']=='exclusions'
  assert next_record['automation']['zones']==before['automation']['zones']
  # Return shows saved native edits and selected method after a browser reload.
  page.reload();page.click('[data-tab="annotation"]')
  frame=page.frame_locator('#annotation-frame');expect(frame.locator('#image-name')).to_have_text('top_00.png')
  expect(frame.locator('#annotation-method')).to_have_value('reference')
  expect(frame.locator('#notes')).to_have_value('Retain manual defect and erasure across methods')
  assert not errors,errors
  page.screenshot(path=str(output/'v2_reopened.png'),full_page=True)
  page.set_viewport_size({'width':1366,'height':768})
  frame.locator('#fit').click()
  layout=page.locator('#annotation-frame').element_handle().content_frame().evaluate('({scroll:scrollY,height:innerHeight,documentHeight:document.documentElement.scrollHeight})')
  assert layout['scroll']==0 and layout['documentHeight']==layout['height'],layout
  expect(frame.locator('#regenerate')).to_be_visible()
  page.screenshot(path=str(output/'v2_laptop.png'),full_page=True)
  browser.close()
 assert originals=={x.name:sha256(x) for x in (root/'input').glob('*.png')}
 print(json.dumps({'browser_errors':errors,'native_size':[w,h],'checks':'four methods, preview not saved, manual edits, failure preserved, polygon/profile reuse, restart, originals'}))
finally:
 srv.shutdown();srv.server_close();temporary.cleanup()
