"""Decision-version regression tests. Synthetic images; neural scoring mocked."""
import copy
import importlib.util
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
from PIL import Image

from nilt.common import read_json, sha_file, write_json
from nilt.decisions import (calibration_preview, create_decision, decision_metrics,
                            list_candidates, load_decision, predict_decision, review_decisions)
from nilt.deployment import parity_result
from nilt.runtime import PackageRunner, predict_package
from test_integration_v2 import fixture_run
from test_deployment import fake_package, fake_ort


class DecisionVersions(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.run, self.data, self.rows = fixture_run(self.root, threshold=.5)
        candidate = read_json(self.run / "selected.json")
        candidate["name"] = "resnet18_seed42"
        candidate["score_type"] = "bad_probability_uncalibrated"
        candidate["members"][0].update(architecture="resnet18", kind="supervised")
        alternate = copy.deepcopy(candidate)
        alternate["name"] = "alternate"
        write_json(self.run / "selected.json", candidate)
        write_json(self.run / "selection_integrity.json", {"sha256": sha_file(self.run / "selected.json")})
        write_json(self.run / "candidates.json", [candidate, alternate])
        for item in (candidate, alternate):
            folder = self.run / "scores" / item["name"]
            folder.mkdir(parents=True)
            np.save(folder / "threshold.npy", [.5, .9, .2, .6])
            write_json(folder / "provenance.json", {"candidate": item["name"],
                      "manifest_sha256": sha_file(self.run / "manifest.csv"),
                      "files": {"threshold.npy": sha_file(folder / "threshold.npy")}})
        self.original = {p.relative_to(self.run): sha_file(p) for p in self.run.rglob("*") if p.is_file()}

    def create(self, mode="manual", threshold=.6, **kwargs):
        return create_decision(self.run, mode=mode, threshold=threshold, output_root=self.root / "decisions", **kwargs)

    def images(self, both=True):
        source = self.root / "incoming"
        for name, color in (("good", "white"), ("bad", "black")):
            (source / name).mkdir(parents=True)
            if both or name == "good":
                Image.new("RGB", (32, 32), color).save(source / name / "same.png")
        return source

    def test_versions_preserve_original_run_and_choose_alternate(self):
        first = self.create(candidate="alternate")
        second = self.create(candidate="alternate")
        self.assertNotEqual(first, second)
        record, _, _, chosen = load_decision(first)
        self.assertEqual(chosen["name"], "alternate")
        self.assertEqual(record["qualification_status"], "NOT_INDEPENDENTLY_VALIDATED")
        self.assertEqual(self.original, {p.relative_to(self.run): sha_file(p) for p in self.run.rglob("*") if p.is_file()})

    def test_policy_and_argmax_do_not_train_or_read_final_test(self):
        real_load = np.load
        paths = []
        def tracked(path, *args, **kwargs):
            paths.append(Path(path).name)
            return real_load(path, *args, **kwargs)
        with patch("nilt.decisions.np.load", side_effect=tracked):
            policy = self.create(mode="policy", threshold=None)
            preview = calibration_preview(self.run)
            argmax = self.create(mode="argmax", threshold=None)
            review = review_decisions(self.run, [.3, .5, .7], output_root=self.root / "review")
        self.assertTrue(paths and set(paths) == {"threshold.npy"})
        self.assertEqual(read_json(argmax)["threshold"], .5)
        self.assertEqual(read_json(argmax)["argmax_tie_break"], "bad")
        self.assertEqual(read_json(policy)["calibration_split"], "threshold")
        self.assertEqual(preview["source_split"], "threshold")
        self.assertTrue((review / "comparison.html").exists())

    def test_invalid_modes_and_thresholds(self):
        for value in (float("nan"), float("inf"), None, True, ".5"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.create(threshold=value)
        with self.assertRaises(ValueError):
            self.create(mode="scores_only", threshold=.5)
        with self.assertRaises(ValueError):
            self.create(mode="policy", threshold=.5)
        with self.assertRaises(ValueError):
            self.create(mode="argmax", threshold=.6)

    def test_patchcore_argmax_rejected_but_raw_manual_threshold_allowed(self):
        selected = read_json(self.run / "selected.json")
        selected["members"][0].update(architecture="patchcore", kind="patchcore")
        write_json(self.run / "selected.json", selected)
        write_json(self.run / "selection_integrity.json", {"sha256": sha_file(self.run / "selected.json")})
        with self.assertRaisesRegex(ValueError, "PatchCore"):
            self.create(mode="argmax", threshold=None)
        path = self.create(threshold=19.)
        self.assertEqual(read_json(path)["threshold"], 19.)

    def test_relocate_run_checks_content_not_absolute_path(self):
        path = self.create()
        moved = self.root / "moved" / self.run.name
        shutil.copytree(self.run, moved)
        self.assertEqual(load_decision(path, run_override=moved)[1], moved.resolve())
        checkpoint = next(moved.rglob("best.pt"))
        checkpoint.write_bytes(b"different")
        with self.assertRaisesRegex(ValueError, "checksum"):
            load_decision(path, run_override=moved)

    def test_tampered_decision_and_scores_rejected(self):
        path = self.create()
        record = read_json(path)
        record["threshold"] = .7
        write_json(path, record)
        with self.assertRaisesRegex(ValueError, "Decision checksum"):
            load_decision(path)
        np.save(self.run / "scores" / "resnet18_seed42" / "threshold.npy", [.1, .2, .3, .4])
        with self.assertRaisesRegex(ValueError, "provenance"):
            calibration_preview(self.run)

    def test_argmax_ties_are_bad_and_labeled_metrics_match(self):
        path = self.create(mode="argmax", threshold=None)
        source = self.images()
        with patch("nilt.workflow.predict_members", return_value=(np.array([.49, .5]), 0.)):
            out = predict_decision(path, source, self.root / "outputs", labeled=True)
        met = read_json(out / "metrics.json")
        self.assertEqual((met["bad_detected_TP"], met["good_accepted_TN"]), (1, 1))
        self.assertEqual(read_json(out / "summary.json")["counts"], {"good": 1, "bad": 1})
        self.assertTrue((source / "good" / "same.png").is_file())

    def test_scores_only_has_no_classes_or_confusion_metrics(self):
        path = self.create(mode="scores_only", threshold=None)
        source = self.images()
        with patch("nilt.workflow.predict_members", return_value=(np.array([.2, .8]), 0.)):
            out = predict_decision(path, source, self.root / "outputs", labeled=True)
        met = read_json(out / "metrics.json")
        self.assertEqual(met["pr_auc_bad"], 1.)
        self.assertNotIn("accuracy", met)
        self.assertNotIn("bad_detected_TP", met)
        self.assertFalse((out / "predicted").exists())
        self.assertIsNone(read_json(out / "summary.json")["counts"])

    def test_unlabeled_produces_no_metrics(self):
        path = self.create()
        source = self.images()
        with patch("nilt.workflow.predict_members", return_value=(np.array([.8, .2]), 0.)):
            out = predict_decision(path, source, self.root / "outputs", labeled=False, copy_images=False)
        self.assertFalse((out / "metrics.json").exists())

    def test_cross_label_duplicates_detected_across_file_encodings(self):
        path = self.create()
        source = self.images()
        Image.open(source / "good" / "same.png").save(source / "bad" / "copy.bmp")
        with patch("nilt.workflow.predict_members") as backend:
            with self.assertRaisesRegex(ValueError, "both good and bad"):
                predict_decision(path, source, self.root / "outputs", labeled=True)
            backend.assert_not_called()

    def test_invalid_inputs_recorded_and_missing_class_metrics_null(self):
        path = self.create()
        source = self.images(both=False)
        (source / "bad" / "broken.png").write_bytes(b"broken")
        with patch("nilt.workflow.predict_members", return_value=(np.array([.2]), 0.)):
            out = predict_decision(path, source, self.root / "outputs", labeled=True)
        self.assertIsNone(read_json(out / "metrics.json")["bad_escape_rate"])
        self.assertEqual(read_json(out / "summary.json")["invalid_images"], 1)

    def test_output_overlap_rejected_before_inference(self):
        path = self.create()
        source = self.images()
        with patch("nilt.workflow.predict_members") as backend:
            with self.assertRaisesRegex(ValueError, "separate"):
                predict_decision(path, source, source / "output")
            backend.assert_not_called()

    def test_input_change_during_inference_rejected(self):
        path = self.create()
        source = self.images()
        def changes(*args):
            Image.new("RGB", (32, 32), "blue").save(source / "good" / "same.png")
            return np.array([.8, .2]), .1
        with patch("nilt.workflow.predict_members", side_effect=changes):
            with self.assertRaisesRegex(ValueError, "changed during"):
                predict_decision(path, source, self.root / "outputs")


class PortableDecisionModes(unittest.TestCase):
    @unittest.skipUnless(all(importlib.util.find_spec(name) for name in ("torch", "torchvision", "onnx", "onnxruntime")),
                         "Requires optional training/export dependencies")
    def test_real_onnx_exports_frozen_manual_argmax_and_scores_only(self):
        """Real tensor inference/export, synthetic random checkpoint; no quality claim."""
        import torch
        from nilt.engine import make_model, save_checkpoint, predict_checkpoint
        from nilt.deployment import export_package
        from nilt.workflow import open_run
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            run, _, _ = fixture_run(root, threshold=.5)
            cfg, rows = open_run(run)
            cfg["cpu_threads"] = 1
            torch.set_num_threads(1)
            model, _ = make_model("resnet18")
            model.eval()
            checkpoint = run / "models" / "patchcore_seed42" / "best.pt"
            save_checkpoint(checkpoint, model, cfg, "resnet18", 42, 0)
            candidate = read_json(run / "selected.json")
            candidate["members"][0].update(architecture="resnet18", kind="supervised", sha256=sha_file(checkpoint))
            candidate["score_type"] = "bad_probability_uncalibrated"
            write_json(run / "selected.json", candidate)
            write_json(run / "selection_integrity.json", {"sha256": sha_file(run / "selected.json")})
            write_json(run / "candidates.json", [candidate])
            write_json(run / "model_state.json", {"status": "QUALIFIED_ORIGINAL_DECISION"})
            folder = run / "scores" / candidate["name"]
            folder.mkdir(parents=True)
            for split in ("threshold", "selection"):
                scores, _ = predict_checkpoint(checkpoint, [r for r in rows if r["split"] == split], cfg, device="cpu")
                np.save(folder / (split + ".npy"), scores)
            write_json(folder / "provenance.json", {"candidate": candidate["name"],
                      "manifest_sha256": sha_file(run / "manifest.csv"),
                      "files": {name: sha_file(folder / name) for name in ("threshold.npy", "selection.npy")}})
            before = sha_file(run / "selected.json")
            for mode, threshold in (("manual", .6), ("argmax", None), ("scores_only", None)):
                with self.subTest(mode=mode):
                    decision = create_decision(run, mode, threshold, output_root=root / "decisions")
                    package = export_package(run, root / ("package_" + mode), decision=decision)
                    runner = PackageRunner(package)
                    self.assertEqual(runner.mode, mode)
                    self.assertEqual(runner.metadata["qualification_status"], "NOT_INDEPENDENTLY_VALIDATED")
                    self.assertIsNone(read_json(package / "model_metadata.json")["latest_evaluation"])
                    self.assertEqual(read_json(package / "export_validation.json")["status"], "passed")
                    self.assertTrue(0 <= runner.score(rows[0]["path"]) <= 1)
            self.assertEqual(sha_file(run / "selected.json"), before)

    def test_scores_only_export_parity_compares_scores_without_decisions(self):
        result = parity_result([.499999], [.500001], None, atol=1e-4)
        self.assertEqual(result["status"], "passed")
        self.assertIsNone(result["decision_mismatches"])

    def test_standalone_runtime_scores_only_has_no_class_folders(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            package = fake_package(root / "package")
            policy = read_json(package / "decision_policy.json")
            policy.update(mode="scores_only", threshold=None, rule="scores_only")
            write_json(package / "decision_policy.json", policy)
            write_json(package / "integrity.json", {"files": {p.name: sha_file(p) for p in package.iterdir() if p.name != "integrity.json"}})
            images = root / "images"
            images.mkdir()
            Image.new("RGB", (32, 32), "white").save(images / "a.png")
            with patch.dict(sys.modules, {"onnxruntime": fake_ort()}):
                out = predict_package(package, images, root / "out")
            self.assertFalse((out / "predicted").exists())
            self.assertIsNone(read_json(out / "inference_summary.json")["counts"])


if __name__ == "__main__":
    unittest.main()
