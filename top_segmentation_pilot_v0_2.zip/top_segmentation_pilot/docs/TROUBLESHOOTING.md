# Troubleshooting

| Symptom | Action |
| --- | --- |
| Python or a dependency is missing | Use the project's virtual environment and run `python segmentation.py doctor` |
| The browser does not open | Keep the command running and open the printed local URL manually |
| The annotation port is in use | Stop the earlier server or run `annotate --config project.yaml --port 8766` |
| No images are imported | Check `input_dir`, file readability, and the import summary; use prepared top images |
| The lens edge is labeled as a defect | Adjust the inner polygon and boundary guard, rerun proposals, then correct manually |
| Too many candidates | Increase sensitivity or minimum area, then inspect the remaining proposals |
| Faint defects are missed | Lower sensitivity, try the appropriate polarity, and label missed defects manually |
| Boundary detection cannot find the inner region | Draw its corners manually; low contrast or markings can prevent a reliable detection |
| A hidden annotation still appears in exported data | Hiding is for inspection only; delete the annotation to remove its labeled pixels |
| A rejected image is absent from training | Restore it to draft and approve it again; then create a new dataset export |
| A save reports a revision conflict | Another tab/session changed the annotation; reload and reconcile the current revision |
| Training reports too few approved images | Approve additional images; drafts and rejected images are excluded and duplicate copies do not add independent examples |
| Training reports a missing defect class | Annotate real examples for that class; do not fill the whole lens or outer region to satisfy the check |
| Small defects disappear during training preprocessing | Increase `training.image_size` and inspect masks at model resolution |
| CPU training is slow | Start with fewer epochs and a smaller trial dataset; reduce input size only if defects remain visible |
| GPU allocation fails | Reduce batch size or model input size, or select CPU; confirm that the installed Torch build supports the device |
| A label mask appears black | This is expected for integer values 0/1/2; view the colored overlay |
| Validation is unexpectedly excellent | Inspect grouping, duplicates, class support, and overlays; many background pixels can conceal missed defects |

To continue annotations, use the same `project.yaml` and `project_dir`:

```bash
python segmentation.py annotate --config project.yaml
```

Do not delete the working project to fix an environment problem. It contains annotation revisions and approval state. If relocating it, copy the complete project directory and update the configuration paths.

The interface is intended for local use. Keep its terminal running until current work is saved. Unsaved browser edits are not a dataset record.

## Command exit codes

| Code | Meaning |
| ---: | --- |
| `0` | Command completed successfully |
| `2` | Invalid input/configuration/path, or an import with rejected files; inspect its report |
| `3` | Dependency, runtime, or operating-system failure |
| `130` | Stopped with `Ctrl+C` |

An import can retain valid images while reporting invalid ones. Inspect `import_report.json` in the working project before deciding whether that dataset is ready for annotation.
