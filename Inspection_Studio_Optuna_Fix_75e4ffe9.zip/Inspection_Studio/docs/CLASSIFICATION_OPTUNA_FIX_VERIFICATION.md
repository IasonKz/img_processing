# Classification Optuna configuration verification — 2026-10-05

## Reproduced failure

The dashboard writes resolved Optuna settings to `dashboard_logs/search_contract_<timestamp>.json` and passes this file to the classification CLI. The old project/single-task loaders used `yaml.safe_load` for these JSON files. PyYAML interpreted JSON scientific-notation numbers without a decimal point, such as `1e-05`, as strings. Configuration validation then rejected `training.learning_rate` before starting training.

This failure was reproduced with the unchanged laptop, workstation and workstation_50h profiles. It was independent of GPU hardware and the validity of the original numeric learning rate.

## Correction

Configuration loading now reads JSON with `json.loads` and retains the existing YAML reader for YAML documents. The dashboard, project loader and single-task loader share this behavior. JSON content in a YAML-named file and UTF-8 BOM files are supported. Malformed `.json` files do not fall back to YAML.

Numeric values remain numeric through the dashboard → saved contract → CLI → worker boundary. Quoted strings are not silently converted. Zero, negative, nonfinite and boolean learning rates remain invalid. No package/dependency change is required.

## Regression checks

```bash
python -m pytest -q tests/test_config_formats.py tests/test_v5_dashboard.py \
  tests/test_v5_search.py tests/test_v3_dashboard.py tests/test_v61_profiles.py \
  tests/test_v3_search.py tests/test_v6_execution.py tests/test_v6_dashboard_execution.py \
  tests/test_v6_samplers.py tests/test_v4_dashboard.py tests/test_roi_classification.py
```

**131 passed, 78 subtests passed.** Checks include every built-in profile in profile/custom mode, JSON exponent round trips, YAML compatibility, BOM support, invalid-rate rejection, persisted search contracts, actual CPU gradient execution, sampler lifecycle and classifier routing.

```bash
python -m pytest -q tests/test_core.py tests/test_v3_engine_data.py \
  tests/test_v3_control.py tests/test_v61_weights.py tests/test_v61_directml_probe.py \
  tests/test_v61_quality_dashboard.py tests/test_dashboard_preprocessing.py \
  tests/test_roi_dashboard.py tests/test_deployment_review.py tests/test_workspace_studio.py
```

**117 passed, 42 subtests passed.** This additional suite covers core/data/control behavior, weight policy, dashboard/preprocessing, ROI, deployment review and workspace behavior. The four existing JavaScript behavior suites also pass; no frontend controls or dependency declarations changed.

## Real dashboard-to-worker training

```bash
python tests/smoke_classification_dashboard.py \
  --output NEW_OUTPUT_DIRECTORY --weights-dir WEIGHTS_CACHE
```

The output directory must be new. Add `--allow-download` when verified public pretrained weights may be downloaded. The check uses real loopback HTTP requests, the normal dashboard job supervisor, classification CLI, Optuna, pretrained TorchVision ResNet18 and synthetic labelled images. It does not mock the model or training.

| Profile | Search mode | Execution | Result |
| --- | --- | --- | --- |
| laptop | Profile defaults | CPU | One trial completed, one epoch trained |
| laptop | Custom Optuna | CPU | One trial completed, one epoch trained |
| workstation | Profile defaults | CPU override | One trial completed, one epoch trained |
| workstation | Custom Optuna | CPU override | One trial completed, one epoch trained |

All four searches produced finite training loss, positive numeric learning rates, a completed trial, a verified checkpoint and selected development results. The smoke fixture constrains training to one epoch and one trial; it does not run the full production profile budget. `verification.json` records each result. Existing pretrained weights were SHA-256 verified.

The environment was Linux with Python 3.12 and CPU PyTorch. Windows, CUDA and DirectML execution were not tested. Synthetic results verify execution and configuration integrity, not production defect accuracy or operating targets.

## Apply the update

Update the source checkout or extract the corrected source release, restart the dashboard and start a new classification search. Existing datasets and experiment outputs do not need to be recreated. No manual increase to the learning rate is required for the JSON parsing defect.
