# Software Validation Report

Release: 2.0.0

## Verification environment

| Component | Observed version/status |
| --- | --- |
| Operating system | Linux |
| Python | 3.12.14 |
| NumPy | 2.3.5 |
| Pillow | 12.3.0 |
| SciPy | 1.17.0 |
| scikit-learn | 1.8.0 |
| PyYAML | 6.0.3 |
| Matplotlib | 3.10.8 |
| PyTorch / torchvision | Not installed in the verification environment |
| ONNX / ONNX Runtime | Not installed in the verification environment |

The environment had no usable local model-runtime wheels, and one bounded CPU-wheel index query returned no matching distribution. Real neural-network training, ONNX export/inference, and target-workstation acceptance were therefore not executed in this environment. Tests that require those runtimes are explicitly skipped, not counted as passed model validation.

## Executed software checks

Verification date: 2026-09-15.

| Check | Executed result |
| --- | --- |
| `python -m unittest discover -s tests -v` | 99 tests discovered; 91 passed, 8 skipped, 0 failures/errors; 4.988 seconds |
| Default CLI smoke | Passed, exit 0, on 80 synthetic images; no model training or ONNX execution |
| Advertised command help | All 16 root/subcommand help checks passed; an unknown command returned exit 2 |
| Source compilation | `compileall` completed successfully |
| TOML packaging metadata | Parsed successfully |
| Project profile resolution | Laptop and workstation configurations resolved as expected |
| Missing-resource diagnostics | `doctor` correctly returned exit 3 for absent model dependencies |
| Documentation command examples | 42 documented application commands parsed against the delivered CLI |
| Documentation links | No broken relative Markdown document links |
| Bash launchers | Both scripts passed `bash -n` syntax checks |

The complete unit-test transcript is retained in [validation/unit_tests.txt](validation/unit_tests.txt). Temporary paths in that log identify synthetic test fixtures, not production data.

The eight skipped tests comprise three real PyTorch backend tests (continuation parity, distance calculations, and PatchCore fitting), three real ONNX tests (single model, ensemble, and PatchCore), and two broader PyTorch integration tests (architecture forward/backward coverage and full training lifecycle). They are present in the source for execution on the target system with the required runtimes installed.

The passing orchestration tests include a mocked audit → selection → image-folder export → held-out evaluation → incremental-incumbent lifecycle. Additional mocked lifecycle checks confirm that previously inspected external holdouts cannot be reused as fresh evidence in a descendant run or added to its development dataset. Those checks verify software routing, state management, and holdout lineage. They do not execute neural-network training, establish defect detection accuracy, or replace the skipped real-runtime tests.

The CLI smoke report records `with_models: false`, `with_onnx: false`, and `industrial_performance_evidence: false`. Its synthetic scores test data/decision/export behavior only. No customer-dataset accuracy, GPU throughput, production yield, or ONNX numeric parity is claimed by these results. Windows launcher execution remains a target-machine acceptance item.

## Scope of software checks

The release verification process exercises data discovery, label conflicts, duplicate handling, group-preserving splits, defect-oriented thresholding, metrics, fixed-version comparison, artifact persistence, and the public command interface. Synthetic fixtures verify software behavior and do not measure industrial defect detection quality.

## Required target-machine acceptance

| Check | Acceptance record |
| --- | --- |
| CPU environment and one complete pilot | Record dependency versions, command, report, and result |
| GPU workstation full roster | Record architecture coverage, seeds, failures, memory, and timing |
| Representative images larger than 600×600 | Verify source detail preservation under pad and explicit behavior under fit |
| Interrupted run and epoch-boundary continuation | Compare dataset/config identity and persisted training state |
| Prior/new version comparison | Verify identical comparison images and unchanged previous threshold |
| ONNX export | Record score parity and threshold decision disagreement counts |
| Destination CPU inference | Compare a fixed reference set with the exporter result |
| Destination CUDA inference, if used | Record provider identity and compare reference decisions |
| Training-package relocation | Verify hashes after remapping data to a different root |
| Good/bad/error folder export | Verify source-image preservation and filename collision handling |
| Release selection and rollback | Verify the active pointer and retained version history |
| Final domain qualification | Evaluate an independent representative holdout against the actual site targets |

CPU or GPU timing cannot be inferred from unit-test duration. A dependency lock from one platform is not a guarantee of another platform's compatibility. Final domain qualification requires the real data and operating criteria and is separate from software tests.
