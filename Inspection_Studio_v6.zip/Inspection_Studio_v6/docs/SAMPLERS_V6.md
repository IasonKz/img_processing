# Search algorithms

In **Train & search**, choose **Custom**, select a sampler, edit the parameter
space, and set the trial count and time budget. The selected algorithm is saved
with the experiment. Resuming uses that saved contract; changing an algorithm or
its space requires a new experiment.

The application supports the nine algorithm samplers built into Optuna 4.5.
`PartialFixedSampler` is a wrapper rather than a separate optimization algorithm:
use **Fixed** parameter specifications to hold parameters constant with any
supported sampler. OptunaHub plugins, executable callbacks, and the separate
BoTorch integration are not loaded by this application.

| Selection | Method | Space and practical use |
| --- | --- | --- |
| TPE | Bayesian tree-structured Parzen estimator | Mixed categorical and numerical spaces; a practical starting point for neural-network searches. |
| Random | Independent random sampling | Simple baseline; does not learn from earlier trial outcomes. |
| Grid | Exhaustive rectangular grid | Explicit choices or linear stepped ranges; stops when the grid is exhausted. |
| Gaussian process | Bayesian Gaussian process | Mixed numeric/categorical spaces; surrogate fitting can become expensive as trial history grows. |
| CMA-ES | Evolutionary covariance adaptation | At least two varying numeric ranges; fix categorical controls first. Its `cmaes` backend is included in the standard setup. |
| NSGA-II | Evolutionary population search | Mixed spaces; population size and mutation/crossover probabilities are editable. |
| NSGA-III | Evolutionary population search | Mixed spaces and editable reference-direction density. Its many-objective design does not turn this application's single-objective study into a multi-objective study. |
| Quasi Monte Carlo | Sobol or Halton sequence | At least one varying numeric range; fix categorical controls. The first trial initializes the numerical space. |
| Brute force | Exhaustive finite tree search | Finite choices or linear stepped ranges; supports conditional branches and stops after enumeration. |

All searches in this release maximize one chosen **validation** metric. NSGA-II
and NSGA-III can operate on that single objective, but they still need enough
completed trials to build a population. Selecting an evolutionary sampler with
a population of 50 and a budget for only five trials gives it no opportunity to
evolve. This is a budget tradeoff, not a reason to treat incomplete trials as
zero-quality models.

## Algorithm options

The **Sampler options** JSON field accepts only the settings below. An empty
object `{}` selects Optuna-compatible defaults. Clear this object when changing
the sampler; unknown options are rejected rather than ignored.

| Sampler | Options and defaults |
| --- | --- |
| TPE | `multivariate: false`, `group: false`, `constant_liar: false`, `n_ei_candidates: 24` |
| Random, Grid | `{}` |
| GP | `deterministic_objective: false` |
| CMA-ES | `sigma0: null`, `popsize: null`, `use_separable_cma: false`, `with_margin: false`, `lr_adapt: false`, `consider_pruned_trials: false` |
| NSGA-II | `population_size: 50`, `mutation_prob: null`, `crossover_prob: 0.9`, `swapping_prob: 0.5` |
| NSGA-III | Same as NSGA-II, plus `dividing_parameter: 3` |
| QMC | `qmc_type: "sobol"`, `scramble: false` |
| Brute force | `avoid_premature_stop: true` |

**Seed** and **Startup trials** remain separate controls. TPE, GP, and CMA-ES
use startup observations before their adaptive algorithm. QMC uses one initial
independent trial. NSGA-II/III use `population_size`, not the startup-trial field,
for their initial population. Grid, brute force, and random do not use the
startup-trial field. Enqueued baseline presets also consume trial and time
budgets; disable them when comparing sampling strategies. Exhaustive samplers
ignore the baseline-preset option.

TPE `group: true` requires `multivariate: true`. For CMA-ES, choose at most one
of `use_separable_cma`, `with_margin`, and `lr_adapt`. Deprecated Optuna restart
options are not exposed because Optuna 4.5 no longer applies those settings.

Evolutionary example:

```json
{
  "population_size": 8,
  "mutation_prob": null,
  "crossover_prob": 0.9,
  "swapping_prob": 0.5
}
```

Eight is an example for a small trial budget, not an automatic recommendation.
Allow several populations' worth of completed trials before judging adaptation.
Pruning, trial timeouts, and search time budgets remain independent controls.

## Numeric-only searches

CMA-ES and QMC do not optimize varying categorical distributions. The application
rejects incompatible spaces before training rather than replacing those
coordinates with random suggestions. Fix `mode`, `optimizer`, `scheduler`, and
`imbalance`. Fix effective batch size and warmup, or express those numeric
parameters as valid integer ranges. An explicit numeric **Choices** list is
still categorical to Optuna; use **Range** for numeric optimization.

For example, a CMA-ES head-only search can fix all controls except:

```json
{
  "head_learning_rate": {
    "kind": "range", "low": 0.0001, "high": 0.003, "log": true
  },
  "weight_decay": {
    "kind": "range", "low": 0.00001, "high": 0.001, "log": true
  }
}
```

GP, CMA-ES, NSGA-II/III, and QMC sample the union of the active parameter space
at the start of each trial. This keeps their relative search space consistent
when modes change. A sampled backbone learning rate has no training effect in
a head-only trial; a sampled SGD momentum has no effect when AdamW is selected.
The recorded configuration identifies which parameters were applicable. TPE,
random, and brute force keep conditional suggestions.

For Grid and Brute force, `max_grid_combinations` is an editable allocation
guard. Exhaustive ranges must have finite support; logarithmic enumeration is
represented as explicit choices. Brute force also accepts ordinary integer
ranges with their implicit step of one. Neither sampler promises to enumerate
its whole space when the separate time or trial budget is smaller.

## Dependencies and restart behavior

Standard setup installs the dependencies for all nine samplers. CMA-ES uses
`cmaes`, included in the base requirements; GP uses `torch` and `scipy` from the
training setup. GP does not require BoTorch.

If reusing an older environment that lacks CMA-ES, use the Python executable
belonging to the dashboard environment to install the backend:

```powershell
python -m pip install -r requirements-samplers.txt
```

The command assumes `python` is that environment's interpreter. On installations
that use a launcher-managed environment, select that interpreter in PyCharm or
use its full executable path. A missing or broken dependency produces a preflight
error naming the package, rather than a replacement sampler. External OptunaHub
plugins and BoTorch remain outside the supported sampler catalog.

Completed observations and Optuna algorithm metadata are stored in SQLite.
For stochastic samplers, restarting derives a continuation seed from the saved
trial count rather than replaying the first random suggestions. This is a
reproducible continuation rule, not a guarantee that an interrupted run is
bit-identical to an uninterrupted one. Grid preserves its ordering seed. QMC
preserves its scramble seed and persisted sequence index. Brute-force exhaustion
is persisted and respected after restart.

## Reference

- [Optuna 4.5 sampler reference](https://optuna.readthedocs.io/en/v4.5.0/reference/samplers/index.html)
- [CMA-ES restrictions and options](https://optuna.readthedocs.io/en/v4.5.0/reference/samplers/generated/optuna.samplers.CmaEsSampler.html)
- [QMC search-space and sequence behavior](https://optuna.readthedocs.io/en/v4.5.0/reference/samplers/generated/optuna.samplers.QMCSampler.html)
