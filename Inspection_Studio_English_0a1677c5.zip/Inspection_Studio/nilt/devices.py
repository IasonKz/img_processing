"""Explicit device selection and the optional Windows DirectML backend."""
from __future__ import annotations

import importlib
import platform
import re


def validate_device_name(value):
    value = str(value).lower().strip()
    if not re.fullmatch(r"(?:auto|cpu|cuda(?::\d+)?|directml(?::\d+)?)", value):
        raise ValueError("Device must be auto, cpu, cuda[:index] or directml[:index].")
    return value


def directml_devices():
    """Read adapters without choosing one or silently changing backend."""
    if platform.system() != "Windows":
        raise RuntimeError("This release's DirectML integration requires native Windows. Select cpu or cuda here.")
    try:
        dml = importlib.import_module("torch_directml")
    except (ImportError, OSError, RuntimeError) as exc:
        raise RuntimeError("DirectML is not installed in this interpreter. Run Setup-DirectML.cmd and restart with Start.cmd. "
                           "Keep DirectML separate from the CPU/CUDA environment. " + str(exc)) from exc
    count = int(dml.device_count())
    if count < 1:
        raise RuntimeError("DirectML found no adapters. Update the GPU driver or explicitly select cpu.")
    return dml, [{"index": i, "name": str(dml.device_name(i)), "device": f"directml:{i}"} for i in range(count)]


def _training_parity_probe(torch, device):
    """Compare the weighted classification loss and gradients with a CPU reference.

    Fixed float32 inputs avoid changes to the training RNG. This is a small
    backend correctness check, not a substitute for model-specific validation.
    """
    def evaluate(target):
        with torch.enable_grad():
            x = torch.tensor([[1., -.5, .25], [-.25, .75, 1.], [.5, 1., -.75]],
                             dtype=torch.float32, device=target)
            weights = torch.tensor([[.3, -.2], [-.4, .6], [.2, .1]],
                                   dtype=torch.float32, device=target, requires_grad=True)
            bias = torch.tensor([.1, -.15], dtype=torch.float32, device=target, requires_grad=True)
            labels = torch.tensor([0, 1, 0], dtype=torch.long, device=target)
            class_weights = torch.tensor([1.5, .75], dtype=torch.float32, device=target)
            criterion = torch.nn.CrossEntropyLoss(weight=class_weights, reduction="sum")
            loss = criterion(x @ weights + bias, labels)
            loss.backward()
            if weights.grad is None or bias.grad is None:
                raise RuntimeError("Weighted CrossEntropyLoss produced no training gradients")
            return (loss.detach().cpu(), weights.grad.detach().cpu(), bias.grad.detach().cpu())

    expected = evaluate("cpu")
    actual = evaluate(device)
    for label, reference, observed in zip(("loss", "weight gradient", "bias gradient"), expected, actual):
        if not bool(torch.isfinite(observed).all()):
            raise RuntimeError(f"Weighted CrossEntropyLoss produced nonfinite {label}")
        if label != "loss" and not bool((observed.abs() > 0).any()):
            raise RuntimeError(f"Weighted CrossEntropyLoss produced a zero {label}")
        if not torch.allclose(observed, reference, rtol=2e-4, atol=2e-5):
            raise RuntimeError(f"Weighted CrossEntropyLoss {label} differs from the CPU reference")


def resolve_directml(value, torch, probe=True):
    value = validate_device_name(value)
    dml, adapters = directml_devices()
    index = int(value.split(":", 1)[1]) if ":" in value else 0
    if index >= len(adapters):
        raise ValueError(f"DirectML adapter {index} is unavailable. Available adapters: {adapters}")
    device = dml.device(index)
    if probe:
        try:
            _training_parity_probe(torch, device)
        except Exception as exc:
            raise RuntimeError(f"DirectML adapter {index} ({adapters[index]['name']}) failed its forward/backward probe: {exc}. "
                               "The application has not switched to CPU.") from exc
    return device


def device_report():
    """Optional doctor information; absence is reported rather than fatal."""
    try:
        _, adapters = directml_devices()
        return {"available": True, "adapters": adapters, "experimental": True,
                "note": "Adapter discovery is not a model-specific compatibility or speed guarantee."}
    except Exception as exc:
        return {"available": False, "adapters": [], "experimental": True, "reason": str(exc)}
