# Changelog

## 3.0.0

- Integrated the prior threshold, policy-review, visual-report and telemetry additions.
- Added per-model Optuna studies, profile-specific search spaces, bounded seed
  confirmations, resumable SQLite studies and cumulative 2/6/12-hour budgets.
- Added a local browser dashboard for configuration, search, comparison, decisions,
  classification, reports and export.
- Preserved native image pixels with padding and exact quarter-turn VIG training
  augmentation; grouped tray/row/column units remain in a single split.
- Corrected weighted-loss normalization across microbatches; added explicit
  head-only/full/last-block training and fine-tuning-aware stopping/pruning.
- Added versioned policy/manual/argmax/scores-only decisions and portable runtime
  support without modifying original model results.
- Made missing targets, incomplete comparisons and outstanding independent tests
  visible; included constant-class baselines and both class error rates.
- Added Windows CPU/CUDA setup, three launch profiles and a reproducible synthetic
  end-to-end smoke check. ONNX Runtime telemetry is disabled before session creation.

Optuna searches a bounded set of candidates; no customer-dataset performance is
guaranteed. See [VALIDATION_REPORT.md](VALIDATION_REPORT.md) for executed checks and
remaining Windows/GPU acceptance work. The older notes below describe v2 only.

## 2.0.0

- Added project-level task configuration with CPU pilot and GPU workstation profiles.
- Added PatchCore-style normal-feature memory banks alongside the supervised roster.
- Added automatic image-envelope discovery without a fixed 600×600 assumption.
- Added tracked model state, immutable manifests, continuation checkpoints, and frozen-version comparison.
- Added ONNX packages with independent runtime scripts, package integrity, and parity verification.
- Added training-package relocation, current-model registration, and rollback support.
- Added English operator, installation, model-management, and deployment documentation.
- Retained defect-oriented decision policy, separate development/test roles, and image-folder exports.

### Scope limits

This release does not implement pairwise new-damage classification, camera-die cropping/alignment, tiled training, grouped cross-validation, automatic hyperparameter search, probability calibration, quantization, a graphical interface, or machine/PLC control. The PatchCore-style implementation differs from the published reference scoring method as documented in [MODELS_AND_METRICS.md](MODELS_AND_METRICS.md).

Actual test coverage and hardware acceptance status are recorded in [VALIDATION_REPORT.md](VALIDATION_REPORT.md). No accuracy or throughput is asserted for a customer dataset before the relevant experiment has run.
