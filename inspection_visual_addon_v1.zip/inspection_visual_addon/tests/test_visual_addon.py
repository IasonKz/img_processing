import csv
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from inspection_visual.report import (score_summary, selection_signature, build_report,
                                       load_run, discover_runs, main)
from inspection_visual.telemetry import ObservedLoader, Session
from configure_visual_profiles import configure


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value), encoding="utf-8")


def write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def fixture(root, name="run_01", threshold=.58):
    run = root / "vig" / name
    labels = np.array([0]*50 + [1]*198)
    scores = np.array([.75]*49 + [.30] + [.65]*186 + [.20]*12)
    rows = [dict(relative_path=f"image_{i}.png", pixel_hash=f"pixel_{i}", group=f"unit_{i}",
                 label=int(y), split=split) for split in ("threshold", "selection") for i,y in enumerate(labels)]
    # Splits use distinct units/pixels in the fixture as well as the real workflow.
    for row in rows:
        for key in ("pixel_hash", "group", "relative_path"):
            row[key] = row["split"] + "_" + row[key]
    write_csv(run / "manifest.csv", rows)
    write_json(run / "config.json", dict(task="vig", profile="laptop", independent_units_confirmed=False,
        policy=dict(max_bad_escape_rate=.01, max_good_reject_rate=.20), training=dict(batch_size=1)))
    write_json(run / "model_state.json", dict(status="TARGET_NOT_MET"))
    entry = dict(name="resnet18_seed42", threshold=threshold, members=[{}], selection_seconds=25.4,
        empirical_target_met=False, selection_metrics=dict(n_images=248,n_bad=50,n_good=198,
            bad_detected_TP=49,bad_passed_as_good_FN=1,good_rejected_as_bad_FP=186,good_accepted_TN=12,
            accuracy=61/248,bad_escape_rate=.02,bad_recall=.98,good_reject_rate=186/198,
            accepted_contamination=1/13,pr_auc_bad=.39,bad_unit_escape_upper=.0914,confidence=.95))
    write_json(run / "selected.json", entry)
    write_json(run / "candidates.json", [entry])
    write_json(run / "selection_integrity.json",dict(sha256=hashlib.sha256((run/"selected.json").read_bytes()).hexdigest()))
    for split in ("selection", "threshold"):
        p=run/"scores"/entry["name"]/(split+".npy")
        p.parent.mkdir(parents=True,exist_ok=True)
        np.save(p,scores)
    return run


class ReportTests(unittest.TestCase):
    def test_operating_point_reconstructs_confusion(self):
        q=score_summary([0,0,1,1],[.9,.3,.8,.2],.5)
        x=next(x for x in q["sweep"] if x["threshold"]==.5)
        self.assertEqual((x["tp"],x["fn"],x["fp"],x["tn"]),(1,1,1,1))

    def test_ranking_matches_sklearn_with_ties(self):
        from sklearn.metrics import average_precision_score, roc_auc_score
        rng=np.random.default_rng(12)
        for _ in range(15):
            labels=rng.integers(0,2,100)
            scores=np.round(rng.random(100),1)
            q=score_summary(labels,scores,.5)
            self.assertAlmostEqual(q["ap"],average_precision_score(labels==0,scores))
            self.assertAlmostEqual(q["roc_auc"],roc_auc_score(labels==0,scores))

    def test_equal_threshold_is_bad(self):
        q=score_summary([0,1],[.5,.5],.5)
        x=next(x for x in q["sweep"] if x["threshold"]==.5)
        self.assertEqual((x["tp"],x["fp"]),(1,1))
        self.assertEqual((q["ap"],q["roc_auc"]),(.5,.5))

    def test_invalid_scores_rejected(self):
        for labels,scores in [([0,1],[1]),([0,1],[float("nan"),1]),([0,0],[1,2]),([0,2],[1,2])]:
            with self.assertRaises(ValueError):score_summary(labels,scores,.5)

    def test_anomaly_score_range_not_clamped(self):
        q=score_summary([0,1],[17,8],12)
        self.assertGreater(max(x["threshold"] for x in q["sweep"]),17)

    def test_report_keeps_runs_unchanged_and_does_not_require_images(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);run=fixture(root)
            before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in run.rglob("*") if p.is_file()}
            report=build_report([run],root/"report.html")
            after={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in run.rglob("*") if p.is_file()}
            self.assertEqual(before,after)
            self.assertIn('resnet18_seed42',report.read_text())
            self.assertNotIn('src="https://',report.read_text())
            with self.assertRaises(FileExistsError):build_report([run],report)

    def test_incomplete_and_changed_runs(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);run=fixture(root)
            (run/"selected.json").write_text((run/"selected.json").read_text()+" ")
            q=load_run(run)
            self.assertTrue(any('changed after selection' in w for w in q['warnings']))
            (run/"candidates.json").unlink();(run/"selected.json").unlink()
            q=load_run(run)
            self.assertEqual(q['candidates'],[])
            self.assertIsNone(q['final_test'])

    def test_invalid_score_order_length_does_not_show_false_curve(self):
        with tempfile.TemporaryDirectory() as temp:
            run=fixture(Path(temp))
            np.save(run/'scores/resnet18_seed42/selection.npy',np.array([.2]))
            q=load_run(run)
            self.assertIsNone(q['candidates'][0]['selection_plot'])
            self.assertTrue(q['warnings'])

    def test_signatures_check_labels_and_groups_ignore_absolute_paths(self):
        rows=[dict(split='selection',pixel_hash='p',label=0,group='g',path='old')]
        sig=selection_signature(rows)
        rows[0]['path']='new'
        self.assertEqual(sig,selection_signature(rows))
        rows[0]['label']=1
        self.assertNotEqual(sig,selection_signature(rows))

    def test_json_script_escape(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);run=fixture(root)
            write_json(run/'model_state.json',dict(status='</script><script>alert(1)</script>'))
            report=build_report([run],root/'report.html')
            self.assertNotIn('</script><script>alert(1)',report.read_text())

    def test_config_profiles_preserve_paths_and_quality_policy(self):
        import yaml
        with tempfile.TemporaryDirectory() as temp:
            source=Path(temp)/'project.yaml'
            raw=dict(schema_version=2,paths=dict(output_root='./results'),defaults=dict(policy=dict(max_bad_escape_rate=.01)),tasks=dict(vig=dict(dataset_root='./data/vig')))
            source.write_text(yaml.safe_dump(raw))
            before=source.read_bytes();target=configure(source);data=yaml.safe_load(target.read_text())
            self.assertEqual(source.read_bytes(),before)
            self.assertEqual(data['paths'],raw['paths']);self.assertEqual(data['defaults'],raw['defaults'])
            self.assertEqual(data['profiles']['workstation']['device'],'cuda')
            self.assertEqual(data['profiles']['laptop']['training']['epochs'],15)
            with self.assertRaises(FileExistsError):configure(source)

    def test_cli_discovery(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);run=fixture(root)
            self.assertEqual(discover_runs(root,'vig'),[run])
            self.assertEqual(main(['--results',str(root),'--task','vig','--output',str(root/'out.html')]),0)


class FakeSession:
    interval=2
    epoch=0
    def __init__(self):self.records=[]
    def sync(self):pass
    def window(self,first,last,images,start):self.records.append((self.epoch,first,last,images))


class TelemetryTests(unittest.TestCase):
    def test_observer_delegates_restores_hooks_and_records_run(self):
        from types import ModuleType, SimpleNamespace
        from unittest.mock import patch
        from inspection_visual.telemetry import observe_training
        fake = ModuleType('nilt.engine')
        package = ModuleType('nilt');package.engine=fake
        def loader(rows,cfg,training=False,seed=42,sampler=None,generator=None):return rows
        def train_one(name,seed,rows,cfg,out,init_checkpoint=None):
            return [batch for batch in fake.loader(rows,cfg,training=True)]
        fake.train_one=train_one;fake.loader=loader
        fake.torch_modules=lambda:(SimpleNamespace(__version__='stub'),None)
        fake.device_for=lambda cfg:SimpleNamespace(type='cpu')
        with tempfile.TemporaryDirectory() as temp, patch.dict(sys.modules,{'nilt':package,'nilt.engine':fake}):
            out=Path(temp)/'run/models/resnet18_seed42'
            data=[('a',[1,0]),('b',[0])]
            with observe_training(1) as runs:
                result=fake.train_one('resnet18',42,data,dict(training=dict(batch_size=1,accumulation_steps=4)),out)
                self.assertEqual(result,data)
                self.assertEqual(runs,{Path(temp)/'run'})
                self.assertTrue(list(out.glob('visual_telemetry/*/batch_windows.csv')))
            self.assertIs(fake.train_one,train_one);self.assertIs(fake.loader,loader)

    def test_observed_loader_preserves_batches_and_partial_final_window(self):
        base=[('inputs',[1,0]),('more',[0,0]),('last',[1])]
        session=FakeSession();observed=ObservedLoader(base,session)
        self.assertEqual(list(observed),base)
        self.assertEqual(session.records,[(1,1,2,4),(1,3,3,1)])
        list(observed)
        self.assertEqual(session.epoch,2)
        self.assertEqual(len(observed),3)

    def test_interrupted_step_not_recorded_as_completed(self):
        session=FakeSession();iterator=iter(ObservedLoader([('x',[1]),('y',[0])],session))
        next(iterator);iterator.close()
        self.assertEqual(session.records,[])

    def test_no_empty_window_for_exact_interval(self):
        session=FakeSession();list(ObservedLoader([('x',[1]),('y',[0])],session))
        self.assertEqual(session.records,[(1,1,2,2)])

    def test_session_records_cpu_metadata_without_cuda_calls(self):
        from types import SimpleNamespace
        with tempfile.TemporaryDirectory() as temp:
            session=Session(temp,dict(training=dict(batch_size=1,accumulation_steps=4)),
                            'stub',1,SimpleNamespace(__version__='stub'),SimpleNamespace(type='cpu'))
            session.epoch=1;list(ObservedLoader([('x',[1])],session));session.close('completed')
            meta=json.loads((session.folder/'session.json').read_text())
            self.assertFalse(meta['amp']);self.assertEqual(meta['status'],'completed')
            self.assertTrue((session.folder/'batch_windows.csv').read_text().count('\n')>=2)


if __name__=='__main__':unittest.main()
