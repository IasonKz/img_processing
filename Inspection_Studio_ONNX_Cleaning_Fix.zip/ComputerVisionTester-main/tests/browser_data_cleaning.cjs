"use strict";
// Real local HTTP endpoints, synthetic captures and saved synthetic model scores.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),assert=require('node:assert/strict');
const {spawn}=require('node:child_process'),{chromium}=require('playwright');
const repo=path.resolve(__dirname,'..'),root=fs.mkdtempSync(path.join(os.tmpdir(),'studio-cleaning-'));
const output=path.resolve(process.argv[2]||path.join(root,'evidence'));fs.mkdirSync(output,{recursive:true});
let worker,browser,page,log='';
const fixture=String.raw`
import json,sys,threading,time
from pathlib import Path
import numpy as np,cv2
from PIL import Image
from nilt.dashboard import Dashboard,make_handler
from nilt.common import write_json,sha_file
from nilt.decisions import create_decision
from http.server import ThreadingHTTPServer
sys.path.insert(0,str(Path.cwd()/'tests'))
from test_integration_v2 import fixture_run
root=Path(sys.argv[1]);run,unused,_=fixture_run(root)
decision=create_decision(run,mode='manual',threshold=5,output_root=root/'decisions')
data=root/'clean_data'
for label in ('good','bad'): (data/label).mkdir(parents=True)
entries=[]
for label,name,prediction,score in [('bad','a_fn.png','good',2),('good','b_fp.png','bad',8),('good','c_match.png','good',2),('bad','d_match.png','bad',8)]:
 path=data/label/name
 cv2.imwrite(str(path),np.repeat(np.arange(1001,1201,dtype=np.uint16)[None,:],120,axis=0))
 stat=path.stat();entries.append({'relative_path':path.relative_to(data).as_posix(),'initial_label':label,'file_sha256':sha_file(path),'bytes':stat.st_size,'mtime_ns':stat.st_mtime_ns,'status':'ok','prediction':prediction,'bad_score':score,'score_type':'anomaly_score','threshold':5,'stage_results':[{'name':'Synthetic model','score':score,'predicted_class':prediction,'score_type':'anomaly_score','threshold':5,'status':'evaluated'}]})
out=root/'cleaning_assessments'/'saved1';out.mkdir(parents=True)
write_json(out/'report.json',{'format':'dataset_cleaning_assessment.v1','status':'completed','root':str(data),'task':'top','roi_scope':'whole_image','kind':'decision','source':str(decision),'source_sha256':sha_file(decision),'name':'Synthetic model','created_utc':'2026-10-08T00:00:00Z','total':4,'completed':4})
write_json(out/'predictions.json',entries)
config=root/'project.yaml';config.write_text('paths:\n  output_root: results\ntasks:\n  top:\n    dataset_root: clean_data\n')
app=Dashboard(config);server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(app));threading.Thread(target=server.serve_forever,daemon=True).start()
print(json.dumps({'port':server.server_port,'data':str(data),'decision':str(decision)}),flush=True)
while True:time.sleep(1)
`;
async function main(){
 worker=spawn(process.env.STUDIO_PYTHON||'python',['-u','-c',fixture,root],{cwd:repo,stdio:['ignore','pipe','pipe']});
 const info=await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(Error(log)),20000);worker.stdout.on('data',chunk=>{log+=chunk;const line=log.split('\n').find(s=>s.startsWith('{"port"'));if(line){clearTimeout(timeout);resolve(JSON.parse(line));}});worker.stderr.on('data',chunk=>log+=chunk);worker.once('exit',code=>{clearTimeout(timeout);reject(Error('Fixture failed '+code+' '+log));});});
 browser=await chromium.launch({headless:true,args:['--no-sandbox'],...(process.env.STUDIO_BROWSER_EXECUTABLE?{executablePath:process.env.STUDIO_BROWSER_EXECUTABLE}:{})});
 page=await browser.newPage({viewport:{width:1536,height:1100}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto(`http://127.0.0.1:${info.port}`);await page.waitForFunction(()=>document.querySelector('#connection').textContent.includes('Connected'));
 await page.locator('[data-workspace="top"]').click();await page.locator('#nav-cleaning').click();await page.locator('#clean-root').fill(info.data);await page.locator('#clean-open').click();
 await page.waitForFunction(()=>document.querySelectorAll('[data-clean-index]').length===4);
 await page.locator('[data-clean-index]').filter({hasText:'a_fn.png'}).click();
 await page.waitForFunction(()=>document.querySelector('#clean-title').textContent.includes('a_fn.png')&&document.querySelector('#clean-viewport').getAttribute('aria-busy')==='false');
 assert.equal(await page.locator('#clean-model').inputValue(),'');
 await page.locator('#clean-viewport').click();await page.keyboard.press('d');assert.match(await page.locator('#clean-pending-label').innerText(),/GOOD/);
 assert(fs.existsSync(path.join(info.data,'bad/a_fn.png')));assert(!fs.existsSync(path.join(info.data,'good/a_fn.png')));
 await page.keyboard.press('Escape');assert(await page.locator('#clean-pending-label').isHidden());
 await page.keyboard.press('f');assert.match(await page.locator('#clean-pending-label').innerText(),/BAD/);await page.keyboard.press('d');
 await page.keyboard.press('Enter');await page.waitForFunction(()=>document.querySelector('#clean-status').textContent.includes('Saved GOOD'));
 assert(fs.existsSync(path.join(info.data,'good/a_fn.png')));assert(!fs.existsSync(path.join(info.data,'bad/a_fn.png')));
 await page.locator('#clean-undo').click();await page.waitForFunction(()=>document.querySelector('#clean-status').textContent.includes('undone'));assert(fs.existsSync(path.join(info.data,'bad/a_fn.png')));
 await page.locator('#clean-model').selectOption(JSON.stringify({kind:'decision',source:info.decision}));
 await page.waitForFunction(()=>document.querySelector('#clean-assessment').value==='saved1'&&document.querySelector('#clean-model-label').textContent.includes('GOOD'));
 assert.match(await page.locator('#clean-model-label').innerText(),/bad score 2/);assert.match(await page.locator('#clean-model-evidence').innerText(),/threshold 5/);
 await page.locator('#clean-comparison').selectOption('fn');await page.waitForFunction(()=>document.querySelectorAll('[data-clean-index]').length===1&&document.querySelector('#clean-title').textContent.includes('a_fn.png'));
 await page.locator('#clean-comparison').selectOption('fp');await page.waitForFunction(()=>document.querySelectorAll('[data-clean-index]').length===1&&document.querySelector('#clean-title').textContent.includes('b_fp.png'));
 await page.locator('#clean-comparison').selectOption('mismatch');await page.waitForFunction(()=>document.querySelectorAll('[data-clean-index]').length===2);
 const controls=page.locator('#clean-editor .viewer-controls');await page.waitForFunction(()=>document.querySelector('#clean-editor [data-viewer=levels]').textContent.includes('16-bit'));
 await controls.locator('[data-viewer=low-mode]').selectOption('min');await controls.locator('[data-viewer=normalize]').check();
 await page.waitForFunction(()=>document.querySelector('#clean-image').src.includes('window=1')&&document.querySelector('#clean-image').complete);
 await controls.locator('[data-viewer=fullscreen]').click();await page.locator('#clean-native').click();assert.equal(await page.locator('#clean-image').evaluate(el=>el.style.width),'200px');
 await controls.locator('[data-viewer=in]').click();assert.equal(await page.locator('#clean-image').evaluate(el=>el.style.width),'250px');
 const bounds=await page.locator('#clean-viewport').boundingBox(),before=await page.locator('#clean-image').evaluate(el=>parseFloat(el.style.left));await page.mouse.move(bounds.x+bounds.width/2,bounds.y+bounds.height/2);await page.mouse.down({button:'right'});await page.mouse.move(bounds.x+bounds.width/2+60,bounds.y+bounds.height/2+25);await page.mouse.up({button:'right'});assert.equal(await page.locator('#clean-image').evaluate(el=>parseFloat(el.style.left)),before+60);
 await page.keyboard.press('p');assert.match(await page.locator('#clean-pending-label').innerText(),/REVIEW/);assert(fs.existsSync(path.join(info.data,'bad/a_fn.png')));await page.keyboard.press('x');assert.match(await page.locator('#clean-pending-label').innerText(),/UNSUITABLE/);
 await page.screenshot({path:path.join(output,'SYNTHETIC-cleaning-fullscreen.png')});await page.keyboard.press('Escape');
 // Commit remains explicit in full screen and retains model evidence after quarantine/undo.
 await page.locator('#clean-viewport').click();await page.keyboard.press('x');await page.keyboard.press('Enter');await page.waitForFunction(()=>document.querySelector('#clean-status').textContent.includes('Saved UNSUITABLE'));
 assert(fs.existsSync(path.join(info.data,'unsuitable/a_fn.png')));await page.locator('#clean-undo').click();await page.waitForFunction(()=>document.querySelector('#clean-status').textContent.includes('undone'));
 await page.locator('#clean-model').selectOption('');await page.waitForFunction(()=>document.querySelectorAll('[data-clean-index]').length===4);assert(await page.locator('#clean-model-label').isHidden());assert(await page.locator('#clean-comparison').isDisabled());
 await page.locator('#clean-viewport').click();await page.keyboard.press('p');await page.reload();await page.waitForFunction(()=>document.querySelector('#connection').textContent.includes('Connected'));await page.locator('[data-workspace="top"]').click();await page.locator('#nav-cleaning').click();await page.locator('#clean-open').click();await page.waitForFunction(()=>document.querySelector('#clean-pending-label').textContent.includes('REVIEW'));
 assert.deepEqual(errors,[]);console.log('PASS: pending D/F/X/P tags, Enter commit, Escape cancellation, undo, persisted progress, optional model/manual modes, FN/FP/mismatch filters, score evidence, native 16-bit levels, fullscreen, zoom and right-drag pan.');
}
main().catch(error=>{console.error(error);process.exitCode=1;}).finally(async()=>{if(browser)await browser.close();if(worker)worker.kill('SIGTERM');});
