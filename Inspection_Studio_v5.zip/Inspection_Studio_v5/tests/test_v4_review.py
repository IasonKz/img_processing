"""Image review provenance, live publication, and copied-image access regression tests."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
from PIL import Image

from nilt.common import read_json, sha_file, write_json
from nilt.review import (initialize_session, append_prediction, list_sessions, session_detail,
                         save_review, resolve_review_asset, read_records, input_fingerprint)


class ReviewGallery(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.session = self.root / "outputs" / "one"
        initialize_session(self.session, total=3)

    def append(self, name="good/one.png", reference="good", prediction="bad"):
        copied = "predicted/" + (prediction or "good") + "/" + hashlib.sha256(name.encode()).hexdigest()[:8] + ".png"
        asset = self.session / copied
        asset.parent.mkdir(parents=True, exist_ok=True)
        Image.new("RGB", (6, 4), "white").save(asset)
        return append_prediction(self.session, {"relative_path": name, "true_class": reference,
            "predicted_class": prediction, "score": .6, "status": "ok", "output_path": copied,
            "file_sha256": sha_file(asset)})

    def test_label_overrides_never_mutate_predictions_or_original_reference(self):
        record = self.append()
        before = (self.session / "predictions.jsonl").read_bytes()
        immutable = (self.session / "records" / (record["id"] + ".json")).read_bytes()
        save_review(self.session, record["id"], "BAD", "Visible defect")
        detail = session_detail(self.session)
        self.assertEqual(detail["items"][0]["reference_label"], "good")
        self.assertEqual(detail["items"][0]["prediction"], "bad")
        self.assertEqual(detail["metrics"]["dataset_reference"]["accuracy"], 0.)
        self.assertEqual(detail["metrics"]["reviewed_only"]["accuracy"], 1.)
        self.assertEqual(detail["metrics"]["effective_reference"]["accuracy"], 1.)
        save_review(self.session, record["id"], "unreviewed")
        self.assertIsNone(session_detail(self.session)["metrics"]["reviewed_only"]["accuracy"])
        self.assertEqual((self.session / "predictions.jsonl").read_bytes(), before)
        self.assertEqual((self.session / "records" / (record["id"] + ".json")).read_bytes(), immutable)
        self.assertEqual(len(read_json(self.session / "reviews.json")["history"]), 2)

    def test_unknown_and_scores_only_have_no_fake_accuracy(self):
        self.append(reference="", prediction="bad")
        self.append("two.png", reference="bad", prediction="")
        details = session_detail(self.session)
        for metric in details["metrics"].values():
            self.assertEqual(metric["n"], 0)
            self.assertIsNone(metric["accuracy"])

    def test_pagination_filters_and_metrics_are_session_wide(self):
        first = self.append()
        self.append("bad/two.png", "bad", "bad")
        self.append("unknown.png", "", "good")
        save_review(self.session, first["id"], "bad")
        detail = session_detail(self.session, page=2, page_size=1)
        self.assertEqual(detail["pagination"]["total"], 3)
        self.assertEqual(len(detail["items"]), 1)
        self.assertEqual(detail["metrics"]["dataset_reference"]["n"], 2)
        self.assertEqual(session_detail(self.session, errors_only=True)["pagination"]["total"], 1)
        self.assertEqual(session_detail(self.session, reference="unknown")["pagination"]["total"], 1)
        self.assertEqual(session_detail(self.session, prediction="bad", review="reviewed")["items"][0]["id"], first["id"])
        self.assertEqual(session_detail(self.session, search="two", offset=0, limit=1)["pagination"]["total"], 1)

    def test_copied_assets_only_and_traversal_rejected(self):
        row = self.append()
        self.assertEqual(resolve_review_asset(self.session, row["id"]), self.session / row["copied_path"])
        for identity in ("../reviews", ".." + "0" * 22, "x" * 24):
            with self.assertRaises(ValueError):
                resolve_review_asset(self.session, identity)
        for copied in ("../outside.png", "C:\\outside.png", "review_session.json"):
            with self.assertRaises(ValueError):
                append_prediction(self.session, {"relative_path": "new.png", "copied_path": copied})
        entry = read_json(self.session / "records" / (row["id"] + ".json"))
        entry["copied_path"] = "../../outside.png"
        write_json(self.session / "records" / (row["id"] + ".json"), entry)
        with self.assertRaises(ValueError):
            resolve_review_asset(self.session, row["id"])

    @unittest.skipIf(os.name == "nt", "Windows symlink creation may require elevated privileges")
    def test_symlink_asset_cannot_escape_session(self):
        row = self.append()
        copied = self.session / row["copied_path"]
        external = self.root / "outside.png"
        copied.replace(external)
        copied.symlink_to(external)
        with self.assertRaises(ValueError):
            resolve_review_asset(self.session, row["id"])

    def test_invalid_review_does_not_write(self):
        row = self.append()
        for label, note in (("maybe", ""), ("good", "x" * 4001)):
            with self.assertRaises(ValueError):
                save_review(self.session, row["id"], label, note)
        self.assertFalse((self.session / "reviews.json").exists())

    def test_concurrent_records_and_reviews_keep_all_updates(self):
        rows = [self.append("image" + str(i) + ".png") for i in range(8)]
        with ThreadPoolExecutor(max_workers=4) as pool:
            list(pool.map(lambda row: save_review(self.session, row["id"], "good", row["relative_path"]), rows))
        self.assertEqual(len(read_json(self.session / "reviews.json")["items"]), 8)
        with self.assertRaisesRegex(ValueError, "already been committed"):
            append_prediction(self.session, rows[0])
        self.assertEqual(len(read_records(self.session)), 8)

    def test_transient_polling_read_failure_is_reported_not_crash(self):
        self.append()
        original = read_json
        def transient(path):
            if Path(path).name == "review_progress.json":
                raise PermissionError("Brief reader contention")
            return original(path)
        with patch("nilt.review.read_json", side_effect=transient):
            result = session_detail(self.session)
        self.assertTrue(result["read_warning"])
        self.assertEqual(len(result["items"]), 1)

    def test_sessions_marker_and_atomic_records_survive_partial_journal(self):
        self.append()
        with (self.session / "predictions.jsonl").open("a", encoding="utf-8") as handle:
            handle.write('{"interrupted":')
        self.assertEqual(len(read_records(self.session)), 1)
        self.assertEqual(len(list_sessions(self.root / "outputs")), 1)
        with self.assertRaises((FileNotFoundError, ValueError)):
            session_detail(self.root)

    def test_input_fingerprint_is_order_invariant_and_content_sensitive(self):
        a = {"relative_path": "one", "file_sha256": "a"}
        b = {"relative_path": "two", "file_sha256": "b"}
        self.assertEqual(input_fingerprint([a, b]), input_fingerprint([b, a]))
        self.assertNotEqual(input_fingerprint([a, b]), input_fingerprint([a, {**b, "file_sha256": "c"}]))


class LiveDecisionReview(unittest.TestCase):
    def test_copy_and_record_visible_before_inference_completes(self):
        from nilt.decisions import create_decision, predict_decision
        from test_integration_v2 import fixture_run
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            run, _, _ = fixture_run(root, threshold=.5)
            decision = create_decision(run, mode="manual", threshold=.5, output_root=root / "decisions")
            source = root / "inputs"
            for label, color in (("good", "white"), ("bad", "black")):
                (source / label).mkdir(parents=True)
                Image.new("RGB", (8, 8), color).save(source / label / "image.png")
            before = {str(p): sha_file(p) for p in source.rglob("*.png")}
            decision_hash = sha_file(decision)
            def inference(run, members, rows, cfg, on_scores=None):
                on_scores(0, np.array([.2]))
                session = list_sessions(root / "outputs")[0]["path"]
                detail = session_detail(session)
                self.assertEqual(len(detail["items"]), 1)
                self.assertEqual(detail["progress"]["completed"], 1)
                row = detail["items"][0]
                self.assertEqual(sha_file(resolve_review_asset(session, row["id"])), rows[0]["file_sha256"])
                on_scores(1, np.array([.8]))
                return np.array([.2, .8]), .1
            with patch("nilt.workflow.predict_members", side_effect=inference):
                out = predict_decision(decision, source, root / "outputs", labeled=True)
            self.assertEqual(sha_file(decision), decision_hash)
            self.assertEqual(before, {str(p): sha_file(p) for p in source.rglob("*.png")})
            self.assertEqual(len(read_records(out)), 2)
            self.assertEqual(session_detail(out)["progress"]["status"], "completed")

    def test_failure_retains_committed_live_copies(self):
        from nilt.decisions import create_decision, predict_decision
        from test_integration_v2 import fixture_run
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            run, _, _ = fixture_run(root, threshold=.5)
            decision = create_decision(run, mode="manual", threshold=.5, output_root=root / "decisions")
            source = root / "inputs"
            source.mkdir()
            Image.new("RGB", (8, 8), "white").save(source / "one.png")
            def inference(run, members, rows, cfg, on_scores=None):
                on_scores(0, np.array([.2]))
                raise RuntimeError("Later inference failure")
            with patch("nilt.workflow.predict_members", side_effect=inference):
                with self.assertRaisesRegex(RuntimeError, "Later inference"):
                    predict_decision(decision, source, root / "outputs")
            session = list_sessions(root / "outputs")[0]
            self.assertEqual(session["progress"]["status"], "failed")
            self.assertEqual(len(read_records(session["path"])), 1)


class StreamingBackend(unittest.TestCase):
    def test_ensemble_publishes_only_completed_average_on_last_member(self):
        from nilt.workflow import predict_members
        from nilt.common import DEFAULTS
        import copy
        with tempfile.TemporaryDirectory() as tmp:
            run = Path(tmp)
            members = []
            for i in range(2):
                path = run / f"model{i}.pt"
                path.write_bytes(str(i).encode())
                members.append({"checkpoint": path.name, "sha256": sha_file(path)})
            cfg = copy.deepcopy(DEFAULTS)
            cfg["device"] = "cpu"
            calls = []
            def score(path, rows, cfg, device, **options):
                chunk = np.array([.2, .8]) if Path(path).name == "model0.pt" else np.array([.4, .6])
                if "on_scores" in options:
                    options["on_scores"](0, chunk[:1])
                    options["on_scores"](1, chunk[1:])
                return chunk, .1
            with patch("nilt.engine.predict_checkpoint", side_effect=score):
                scores, _ = predict_members(run, members, [{}, {}], cfg,
                                            on_scores=lambda offset, chunk: calls.append((offset, chunk.copy())))
            self.assertEqual([c[0] for c in calls], [0, 1])
            np.testing.assert_array_equal(np.concatenate([c[1] for c in calls]), scores)
            np.testing.assert_allclose(scores, [.3, .7])

    def test_real_cpu_callbacks_match_complete_scores(self):
        import torch
        from nilt.engine import predict_model
        from nilt.common import DEFAULTS
        import copy
        with tempfile.TemporaryDirectory() as tmp:
            rows = []
            for i in range(3):
                image = Path(tmp) / f"{i}.png"
                Image.new("RGB", (32, 32), (i * 40, 30, 50)).save(image)
                rows.append({"path": str(image), "label": i % 2})
            cfg = copy.deepcopy(DEFAULTS)
            cfg.update(image_size=32, num_workers=0)
            cfg["training"]["eval_batch_size"] = 2
            model = torch.nn.Sequential(torch.nn.AdaptiveAvgPool2d(1), torch.nn.Flatten(), torch.nn.Linear(3, 2))
            calls = []
            scores, _, _ = predict_model(model, rows, cfg, "cpu", on_scores=lambda offset, chunk: calls.append((offset, chunk)))
            self.assertEqual([x[0] for x in calls], [0, 2])
            np.testing.assert_array_equal(np.concatenate([x[1] for x in calls]), scores)

    def test_checkpoint_write_retries_transient_windows_replace_error(self):
        import torch
        from nilt.engine import _atomic_torch_save
        original = os.replace
        count = []
        def briefly_locked(source, target):
            count.append(str(source))
            if len(count) < 3:
                error = PermissionError("Sharing denied")
                error.winerror = 5
                raise error
            return original(source, target)
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "best.pt"
            with patch("nilt.common.os.replace", side_effect=briefly_locked), patch("nilt.common.time.sleep"):
                _atomic_torch_save({"tensor": torch.tensor([3.])}, target)
            self.assertEqual(torch.load(target, weights_only=True)["tensor"].item(), 3.)
            self.assertEqual(len(count), 3)
            self.assertNotEqual(Path(count[0]).name, "best.pt.tmp")
            self.assertEqual(list(Path(tmp).glob("*.tmp")), [])

    def test_checkpoint_permanent_failure_preserves_previous_checkpoint(self):
        import torch
        from nilt.engine import _atomic_torch_save
        error = PermissionError("Permanent denied permission")
        error.winerror = 5
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "best.pt"
            _atomic_torch_save({"tensor": torch.tensor([1.])}, path)
            before = path.read_bytes()
            with patch("nilt.common.os.replace", side_effect=error) as replace, patch("nilt.common.time.sleep"):
                with self.assertRaises(PermissionError):
                    _atomic_torch_save({"tensor": torch.tensor([2.])}, path)
            self.assertEqual(replace.call_count, 16)
            self.assertEqual(path.read_bytes(), before)
            self.assertEqual(list(Path(tmp).glob("*.tmp")), [])


if __name__ == "__main__":
    unittest.main()
