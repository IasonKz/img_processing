"""Versioned automatic-annotation profiles and persistent manual corrections.

Profiles store geometry in the source image's coordinates. Loading scales only
the geometry, never the image or mask. Existing per-image annotations are not
rewritten when a project profile changes.
"""
from copy import deepcopy

import numpy as np

from .annotations import decode_rle, encode_rle
from .common import atomic_json, project_lock, read_json, utc_now
from .proposals import AUTOMATION_DEFAULTS, validate_automation


def validate_manual_edits(value, width, height):
    if value is None:
        return {'erase_rle': [[0, width * height]]}
    if not isinstance(value, dict) or set(value) != {'erase_rle'}:
        raise ValueError('Manual corrections require erase_rle only.')
    erased = decode_rle(value['erase_rle'], width, height)
    if np.any(erased > 1):
        raise ValueError('Manual erasures must be a binary mask.')
    return {'erase_rle': encode_rle(erased)}


def scale_roi(roi, sx, sy):
    if roi is None:
        return None
    if roi.get('type') == 'polygon':
        return {'type': 'polygon', 'points': [
            {'x': p['x'] * sx, 'y': p['y'] * sy} for p in roi['points']]}
    return {'cx': roi['cx'] * sx, 'cy': roi['cy'] * sy,
            'rx': roi['rx'] * sx, 'ry': roi['ry'] * sy}


class AnnotationProfiles:
    def automation_profile(self):
        path = self.root / 'automation_profile.json'
        return read_json(path) if path.exists() else {
            'revision': 0, 'enabled': False,
            'automation': deepcopy(AUTOMATION_DEFAULTS)}

    def save_automation_profile(self, image_id, automation, expected_revision, enabled=True):
        if type(enabled) is not bool:
            raise ValueError('Profile enabled must be boolean.')
        row = self._row(image_id)
        automation = validate_automation(automation, row['width'], row['height'])
        for reference_id in automation['reference_ids']:
            self._row(reference_id)
        with project_lock(self.root):
            current = self.automation_profile()
            if type(expected_revision) is not int or current['revision'] != expected_revision:
                from .project import ConflictError
                raise ConflictError('The annotation profile changed. Reload its latest version before replacing it.')
            result = {'revision': current['revision'] + 1, 'enabled': enabled,
                      'automation': automation, 'width': row['width'], 'height': row['height'],
                      'source_image_id': image_id, 'updated_at': utc_now()}
            atomic_json(self.root / 'automation_profiles' / f"{result['revision']:06d}.json", result)
            atomic_json(self.root / 'automation_profile.json', result)
        return result

    def profile_automation(self, width, height, force=False):
        profile = self.automation_profile()
        if not profile.get('revision') or not (profile.get('enabled') or force):
            return validate_automation(None, width, height)
        result = deepcopy(profile['automation'])
        sx, sy = width / profile['width'], height / profile['height']
        result['scope_roi'] = scale_roi(result['scope_roi'], sx, sy)
        result['eye'] = scale_roi(result['eye'], sx, sy)
        for zone in result['zones']:
            zone['roi'] = scale_roi(zone['roi'], sx, sy)
        return validate_automation(result, width, height)
