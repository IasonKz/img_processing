/* Optional real-browser integration. Requires local Playwright + Chromium.
 * Run from the project root: node tests/test_ui_browser.js
 * PLAYWRIGHT_MODULE: installed Playwright module path, if not on Node's path.
 * PLAYWRIGHT_CHROMIUM_EXECUTABLE: optional existing Chromium executable.
 * TOPSEG_UI_SCREENSHOT: optional PNG filename for a verified screenshot.
 * Synthetic data only; the test never opens an operator's project.
 */
'use strict';
const assert = require('node:assert/strict');
const {spawn} = require('node:child_process');
const readline = require('node:readline');
const path = require('node:path');
const fs = require('node:fs');
const crypto = require('node:crypto');
let chromium;
try { ({chromium} = require(process.env.PLAYWRIGHT_MODULE || 'playwright')); }
catch (_) { console.log('SKIP: Playwright is not installed.'); process.exit(77); }
(async () => {
  let browser, fixture;
  try {
    browser = await chromium.launch({headless: true, args: ['--no-sandbox'],
      ...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE ? {executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE} : {})});
    fixture = spawn(process.env.PYTHON || 'python', [path.join(__dirname, 'browser_fixture.py')], {cwd: path.join(__dirname, '..'), stdio: ['ignore', 'pipe', 'pipe']});
    fixture.stderr.on('data', x => process.stderr.write(x));
    const info = await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('Synthetic annotation server did not start.')), 15000);
      readline.createInterface({input: fixture.stdout}).once('line', line => {
        clearTimeout(timer); try { resolve(JSON.parse(line)); } catch (exc) { reject(exc); }
      });
      fixture.once('exit', code => { clearTimeout(timer); reject(new Error(`Fixture exited (${code}).`)); });
    });
    const page = await browser.newPage({viewport: {width: 1700, height: 1100}});
    const errors = []; page.on('pageerror', exc => errors.push(exc.message));
    page.on('dialog', dialog => dialog.accept());
    async function loaded(name) {
      await page.waitForFunction(expected => document.querySelector('#image-name').textContent === expected &&
        document.querySelector('#image-canvas').width === 720 && document.querySelector('#loading').classList.contains('hidden'), name);
    }
    const counts = async () => page.evaluate(() => ['inner-count', 'outer-count'].map(id => Number(document.getElementById(id).textContent.replaceAll(',', ''))));
    const transform = async () => page.locator('#canvas-wrap').evaluate(el => el.style.transform);
    const rows = () => page.locator('#object-list .object-row');
    async function expandObjects() {
      if (!(await page.locator('#objects-section').evaluate(el => el.open))) await page.locator('#objects-section > summary').click();
    }
    async function imagePoint(x, y) {
      const b = await page.locator('#image-canvas').boundingBox(); return {x: b.x + x * b.width / 720, y: b.y + y * b.height / 640};
    }
    async function drag(x0, y0, x1, y1) {
      const a = await imagePoint(x0, y0), b = await imagePoint(x1, y1);
      await page.mouse.move(a.x, a.y); await page.mouse.down(); await page.mouse.move(b.x, b.y, {steps: 8}); await page.mouse.up();
    }
    async function overlayAlpha(x, y) { return page.locator('#mask-canvas').evaluate((el, point) => el.getContext('2d').getImageData(point[0], point[1], 1, 1).data[3], [x, y]); }
    async function record(name) {
      return page.evaluate(async target => {
        const headers = {'X-Session-Token': document.querySelector('meta[name="session-token"]').content};
        const project = await (await fetch('/api/project', {headers})).json();
        const item = project.items.find(x => x.relative_path === target);
        return (await fetch(`/api/image/${item.id}`, {headers})).json();
      }, name);
    }
    async function saveDraft() {
      const finished = page.waitForResponse(r => /\/annotation$/.test(r.url()) && r.request().method() === 'POST');
      await page.locator('#save-draft').click(); assert.equal((await finished).status(), 200);
      await page.waitForFunction(() => /^Saved revision /.test(document.querySelector('#save-state').textContent));
    }
    await page.goto(info.url); await loaded('top_unit_01.png');
    assert.equal(await page.locator('.image-item').count(), 3);
    assert.match(await page.locator('#image-status').textContent(), /Draft/i);
    await page.locator('#clear-mask').click(); assert.deepEqual(await counts(), [0, 0]);
    await expandObjects(); assert.equal(await rows().count(), 0);

    // Deterministic ROI and one circle retained at native resolution.
    await page.locator('[data-tool="octagon"]').click(); await drag(170, 130, 550, 510);
    await page.locator('[data-tool="circle"]').click(); await drag(312, 260, 337, 260);
    const circlePixels = (await counts())[0]; assert(circlePixels > 1800 && circlePixels < 2100);
    assert.equal(await rows().count(), 1);
    const firstObjectID = await rows().first().getAttribute('data-object-id');
    assert(await rows().first().locator('canvas, svg, img').count(), 'Each layer needs a shape thumbnail.');
    await page.locator('#undo').click(); assert.deepEqual(await counts(), [0, 0]); assert.equal(await rows().count(), 0);
    await page.locator('#redo').click(); assert.equal((await counts())[0], circlePixels);

    // Deleting an overlapping shape must restore the earlier shape's pixels.
    await drag(332, 260, 357, 260); assert.equal(await rows().count(), 2);
    const secondObject = rows().filter({has: page.locator('.object-label', {hasText: 'Circle 2'})});
    await secondObject.locator('.object-select').click();
    assert.equal(await overlayAlpha(350, 260) > 0, true);
    await secondObject.locator('.object-delete').click(); assert.equal(await rows().count(), 1);
    assert.equal((await counts())[0], circlePixels);
    assert(await overlayAlpha(320, 260) > 0); assert.equal(await overlayAlpha(350, 260), 0);
    await page.locator('#undo').click(); assert.equal(await rows().count(), 2);
    await page.locator('#redo').click(); assert.equal(await rows().count(), 1);

    // Visibility changes display only; it is undoable and persists on reload.
    const beforeHide = await counts();
    await rows().first().locator('.object-visible').uncheck(); assert.deepEqual(await counts(), beforeHide);
    assert.equal(await overlayAlpha(312, 260), 0);
    await page.locator('#undo').click(); assert(await rows().first().locator('.object-visible').isChecked());
    await page.locator('#redo').click(); assert.equal(await rows().first().locator('.object-visible').isChecked(), false);
    await page.locator('#notes').fill('Synthetic browser integration review.'); await saveDraft();
    const hiddenRecord = await record('top_unit_01.png');
    assert.equal(hiddenRecord.objects[0].id, firstObjectID); assert.equal(hiddenRecord.objects[0].visible, false);
    assert(hiddenRecord.mask_rle.some(x => x[0] === 1), 'Hidden objects must remain in the training mask.');
    await page.reload(); await loaded('top_unit_01.png'); await expandObjects();
    assert.equal(await rows().first().getAttribute('data-object-id'), firstObjectID);
    assert.equal(await rows().first().locator('.object-visible').isChecked(), false);
    assert.deepEqual(await counts(), beforeHide); assert.equal(await overlayAlpha(312, 260), 0);
    await rows().first().locator('.object-visible').check();

    // Every marked pixel is reclassified when the lens boundary changes.
    await page.locator('[data-tool="octagon"]').click(); await drag(420, 360, 650, 590);
    assert.deepEqual(await counts(), [0, circlePixels]);
    await page.locator('#undo').click(); assert.deepEqual(await counts(), [circlePixels, 0]);
    await page.locator('#redo').click(); assert.deepEqual(await counts(), [0, circlePixels]);
    await page.locator('#undo').click();
    await page.locator('[data-tool="rectangle"]').click(); await drag(145, 280, 205, 340);
    const crossing = await counts(); assert(crossing[0] > circlePixels && crossing[1] > 0);

    // Automatic border detection yields a local preview without saving a revision.
    const beforeDetect = await record('top_unit_01.png');
    const detectionResponse = page.waitForResponse(r => /\/detect-roi$/.test(r.url()));
    await page.locator('#detect-roi').click(); const detection = await detectionResponse;
    assert.equal(detection.status(), 200); assert.equal((await detection.json()).roi.type, 'polygon');
    await page.waitForFunction(() => document.querySelector('#loading').classList.contains('hidden'));
    assert.equal((await record('top_unit_01.png')).revision, beforeDetect.revision);

    // A gesture that starts on the checkerboard pans, for BOTH drawing tools.
    await page.locator('#fit').click();
    for (const tool of ['brush', 'circle']) {
      await page.locator(`[data-tool="${tool}"]`).click();
      const originalTransform = await transform(), originalCounts = await counts(), originalObjects = await rows().count();
      const viewport = await page.locator('#viewport').boundingBox();
      const canvas = await page.locator('#image-canvas').boundingBox();
      const start = {x: viewport.x + 5, y: viewport.y + 5};
      assert(start.x < canvas.x || start.y < canvas.y, 'Test gesture must start outside the image.');
      await page.mouse.move(start.x, start.y); await page.mouse.down();
      await page.mouse.move(start.x + 35, start.y + 30, {steps: 5}); await page.mouse.up();
      assert.notEqual(await transform(), originalTransform); assert.deepEqual(await counts(), originalCounts);
      assert.equal(await rows().count(), originalObjects); await page.locator('#fit').click();
    }
    // Starting inside and moving into checkerboard must remain a drawing gesture.
    await page.locator('[data-tool="brush"]').click();
    const drawingTransform = await transform(); await drag(700, 500, 725, 500);
    assert.equal(await transform(), drawingTransform); await page.locator('#undo').click();

    // A closed polygon crossing the border receives automatic inner/outer labels.
    await page.locator('[data-tool="polygon"]').click();
    for (const [x, y] of [[535, 300], [575, 300], [575, 350], [535, 350]]) {
      const p = await imagePoint(x, y); await page.mouse.click(p.x, p.y);
    }
    await page.keyboard.press('Enter'); assert.equal(await rows().count(), 3);
    await saveDraft();
    if (process.env.TOPSEG_UI_SCREENSHOT) await page.screenshot({path: process.env.TOPSEG_UI_SCREENSHOT, fullPage: true});
    await page.locator('#approve').click(); await loaded('top_unit_02.png');
    await page.locator('#reject-next').click(); await loaded('top_unit_03.png');
    const excluded = await record('top_unit_02.png'); assert.equal(excluded.status, 'rejected');
    await page.locator('#clear-mask').click(); await page.locator('#approve-clean').click();
    await page.waitForFunction(() => /2 \/ 2 approved.*1 excluded/.test(document.querySelector('#progress-text').textContent));
    assert.equal(await page.locator('#image-name').textContent(), 'top_unit_03.png', 'Finished navigation must skip rejected images.');
    if (await page.locator('#hide-rejected').isChecked()) await page.locator('#hide-rejected').uncheck();
    await page.locator('.image-item').filter({hasText: 'top_unit_02.png'}).click(); await loaded('top_unit_02.png');
    await page.locator('#restore-image').click();
    await page.waitForFunction(() => /Draft/i.test(document.querySelector('#image-status').textContent));
    assert.equal((await record('top_unit_02.png')).status, 'draft');
    const annotated = await record('top_unit_01.png'), clean = await record('top_unit_03.png');
    assert.equal(annotated.status, 'approved'); assert.equal(annotated.notes, 'Synthetic browser integration review.');
    assert.equal(annotated.objects.length, 3); assert(annotated.mask_rle.some(x => x[0] === 1)); assert(annotated.mask_rle.some(x => x[0] === 2));
    assert.equal(clean.clean, true); assert.deepEqual(clean.mask_rle, [[0, 720 * 640]]);
    for (const [name, hash] of Object.entries(info.sources)) assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(info.root, 'source', name))).digest('hex'), hash);
    assert.deepEqual(errors, []);
    console.log('PASS: real Chromium UI; polygon ROI/detection; automatic classes; circle/polygon layers, thumbnails, overlapping deletion, visibility, undo/redo, save/reload; background panning; exclusion/restore; approval/navigation; unchanged originals; no page errors.');
  } catch (exc) {
    console.error(exc.stack || exc.message);
    if (/Executable doesn't exist|executable doesn't exist/.test(exc.message)) { console.log('SKIP: Chromium browser binary is not installed.'); process.exitCode = 77; } else process.exitCode = 1;
  } finally {
    if (fixture) fixture.kill('SIGINT');
    if (browser) await browser.close();
  }
})();
