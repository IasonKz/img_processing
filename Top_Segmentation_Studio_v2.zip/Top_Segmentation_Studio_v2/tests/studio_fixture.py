from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from segmentation import demo
from topseg.common import load_config,atomic_json
from topseg.project import Project
from topseg.studio_server import StudioServer
from topseg.classical import default_roi
import numpy as np
root=Path(sys.argv[1]).resolve()
if not root.exists():demo(root)
cfg=load_config(root/'project.yaml');p=Project(cfg);p.import_images()
for row in p.items():
 if row['status']=='approved':continue
 a=p.open_image(row['id']);mask=np.zeros((row['height'],row['width']),np.uint8)
 mask[280:302,330:351]=1;mask[105:135,100:125]=2
 p.save_annotation(row['id'],mask,default_roi(row['width'],row['height']),a['revision'],approved=True)
server=StudioServer(cfg,root/'project.yaml',0)
atomic_json(root/'server.json',{'port':server.server_port,'token':server.session_token})
print(f'http://127.0.0.1:{server.server_port}',flush=True)
server.serve_forever()
