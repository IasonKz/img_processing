# Windows 11 installation — Inspection Studio 6

Use PowerShell in the extracted folder containing `inspection.py` and
`project.yaml`. `PS` identifies PowerShell; virtual-environment activation is not
required because the launchers invoke the selected Python executable directly.

## Python and project location

Keep the project and its new environment at short local paths. Keep the old
project and environment intact. Check installed Python versions:

```powershell
py -0p
```

If Python 3.12 x64 is absent, install it through the software channel available
on your computer. Where WinGet is available:

```powershell
winget install -e --id Python.Python.3.12 --source winget
```

Open a new terminal after installation and verify:

```powershell
py -3.12 -c "import sys, platform; print(sys.version); print(platform.machine()); assert sys.maxsize > 2**32"
```

## Choose one environment

| Target | Setup command | Default environment |
| --- | --- | --- |
| CPU | `.\Setup.cmd -Device cpu` | `%USERPROFILE%\venvs\studio6-cpu` |
| NVIDIA CUDA | `.\Setup.cmd -Device cuda` | `%USERPROFILE%\venvs\studio6-cuda` |
| Windows Intel/AMD graphics, experimental | `.\Setup-DirectML.cmd` | `%USERPROFILE%\venvs\studio6-directml` |

Run one of the commands from the project folder. Setup installs dependencies,
checks imports and package consistency, and exercises the selected device. A
small device test is not a guarantee that every model fits memory or supports
every operator. Setup does not remove an unrelated environment.

For CPU/CUDA, `-WithExport` installs the optional ONNX packages.
`-EnvironmentPath 'D:\venvs\studio6-cuda'` selects another short environment path.

The regular environments use matched `torch==2.7.1` and `torchvision==0.22.1`.
CUDA uses `cu128` wheels and requires a compatible NVIDIA driver. The base
requirements include the core Optuna dependencies and CMA-ES support; there is
no separate sampler setup for the standard installation.

### Intel laptop graphics through DirectML

DirectML has a different dependency set: `torch==2.4.1`,
`torchvision==0.19.1`, `torch-directml==0.2.5.dev240914`, and NumPy below 2.
`Setup-DirectML.cmd` installs these in its own environment. Do not add
`torch-directml` to the CPU/CUDA environment or mix the two torch pairs.

After setup, select **DirectML** explicitly in Custom Optuna. The execution name
is `directml`; `directml:N` selects an adapter index where supported. **Auto**
does not opt into experimental DirectML. An Intel(R) Graphics adapter does not
guarantee adequate memory, complete operator support, or a speed increase over
CPU. The DirectML provider may warn that a particular operation executes on CPU;
inspect its actual messages. Start with a small representative trial.

If installation or device checks fail, the error is reported rather than silently
launching a search on another backend. Check the installed Windows graphics
driver and the device name. CPU remains available through its separate setup.

## Open and reopen

```powershell
.\Start.cmd
```

The launcher reads `.studio-python.txt` created by the successful setup. It uses
the most recently selected environment for this project. Reopening does not
reinstall packages. The GUI can be inspected without a dataset.

To choose another port:

```powershell
.\Start.cmd -Port 8766
```

In PyCharm, select the interpreter path stored in `.studio-python.txt`. No other
project interpreter needs to change. Keep the terminal open. The NILT animation
is optional; see [TERMINAL_V6.md](TERMINAL_V6.md).

## Checks and public weights

In the dashboard, choose the task/model list, then **Download pretrained weights**
and **Check installation**. This explicit provisioning action is available for every profile. New searches can also download missing official weights automatically when `download_missing_weights` is enabled; no inspection images are uploaded. Newly selected architectures may
require additional weights. Missing weights do not trigger random-backbone
training.

For regular CPU/CUDA defaults, equivalent commands are:

```powershell
$StudioPython = (Get-Content .studio-python.txt -Raw).Trim()
& $StudioPython -m pip check
& $StudioPython inspection.py download-weights --config project.yaml --profile laptop --task vig
& $StudioPython inspection.py doctor --config project.yaml --profile laptop --task vig
```

Use `workstation` for the CUDA preset. For DirectML, select the explicit device
in the saved Custom Optuna contract and inspect its device check; the unmodified
`laptop` preset above still specifies CPU.

Presets do not impose time or device caps. Model weights, search contracts, and
dataset locations are separate from the Python environment.

## Manual CPU/CUDA setup

Use this if script execution is unavailable. Choose a new directory; do not
create over an existing unrelated environment.

```powershell
$StudioEnv = "$env:USERPROFILE\venvs\studio6-manual"
if (Test-Path $StudioEnv) { throw 'Choose a new environment directory.' }
py -3.12 -m venv $StudioEnv
if ($LASTEXITCODE -ne 0) { throw 'Environment creation failed.' }
$StudioPython = "$StudioEnv\Scripts\python.exe"
& $StudioPython -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw 'pip upgrade failed.' }
& $StudioPython -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw 'Base dependency installation failed.' }
```

Install **one** matched torch variant:

```powershell
# CPU
& $StudioPython -m pip install torch==2.7.1 torchvision==0.22.1 --index-url https://download.pytorch.org/whl/cpu
if ($LASTEXITCODE -ne 0) { throw 'CPU package installation failed.' }
```

```powershell
# NVIDIA CUDA
& $StudioPython -m pip install torch==2.7.1 torchvision==0.22.1 --index-url https://download.pytorch.org/whl/cu128
if ($LASTEXITCODE -ne 0) { throw 'CUDA package installation failed.' }
```

Then verify imports and record the interpreter:

```powershell
& $StudioPython -m pip check
if ($LASTEXITCODE -ne 0) { throw 'Package consistency check failed.' }
& $StudioPython -c "import torch, torchvision, optuna, sklearn, cv2, cmaes; print(torch.__version__); print(torchvision.__version__); print('CUDA:', torch.cuda.is_available())"
if ($LASTEXITCODE -ne 0) { throw 'Dependency import failed.' }
Set-Content .studio-python.txt $StudioPython
.\Start.cmd
```

Before CUDA training, `torch.cuda.is_available()` must be true. Check
`nvidia-smi` and the driver/wheel combination if it is false. The automated setup
also checks actual model forward/backward computation.

For DirectML, use its dedicated script and requirements; do not substitute it in
the CPU/CUDA commands above.

## Optional export and sampler repair

```powershell
$StudioPython = (Get-Content .studio-python.txt -Raw).Trim()
& $StudioPython -m pip install -r requirements-export.txt
& $StudioPython -m pip check
```

The selected architecture/decision must support the requested export, and parity
checks must pass. Global-plus-patches or a multi-model decision is not automatically
one ONNX graph.

`requirements-samplers.txt` is provided for manual CMA-ES dependency repair. Normal
setup already installs it. GP sampling uses the environment's torch and scipy.

## Offline CPU/CUDA installation

Create a wheelhouse on an online Windows machine using Python 3.12. Keep CPU and
CUDA variants separate. Example for CUDA:

```powershell
py -3.12 -m pip download -r requirements.txt -d D:\studio6_wheels_cuda
py -3.12 -m pip download torch==2.7.1 torchvision==0.22.1 --index-url https://download.pytorch.org/whl/cu128 -d D:\studio6_wheels_cuda
py -3.12 -m pip download -r requirements-export.txt -d D:\studio6_wheels_cuda
```

Transfer the complete project and wheelhouse, then:

```powershell
.\Setup.cmd -Device cuda -OfflineWheelhouse D:\studio6_wheels_cuda -WithExport
```

For CPU use the CPU wheel index, a separate directory, and `-Device cpu`. Public
pretrained weights must also be provisioned in the configured weights folder.
Linux wheels cannot simply be reused on Windows. DirectML needs its own matched
wheelhouse and a verified installation process; do not mix it with these variants.

Windows launchers, CUDA, and DirectML require checks on the destination machine.
Read [RELEASE_VERIFICATION.md](RELEASE_VERIFICATION.md) for what was actually tested.
