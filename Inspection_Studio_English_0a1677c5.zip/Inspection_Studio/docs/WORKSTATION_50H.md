# Extended GPU search and dashboard model catalog

## Upgrade and open

From the repository folder, update and install the model dependencies into
the existing Python 3.12 environment:

```bash
git pull --ff-only
.venv-studio6/bin/python -m pip install -r requirements-models.txt
.venv-studio6/bin/python -m pip check
bash Start.sh
```

For a new environment, follow [Linux installation](INSTALLATION_LINUX.md)
or run `Setup.cmd` on Windows. Workstation execution needs a compatible
NVIDIA driver and CUDA-enabled PyTorch; a CPU wheel cannot execute CUDA.

## Models in the dashboard

The **Train & search** model selector includes all 29 curated classifiers in
addition to the existing 10 architectures. Choose small, base, large or huge
variants independently. Each new entry shows its pretrained-weight license
and links to its model card. The same models participate in training, Optuna
search, checkpoint recovery, selection, comparison and saved-model inference.
Their ImageNet heads are replaced with the application's `bad` / `good` head.
The separate `cvtester` CLI continues to predict the 1,000 ImageNet classes.

Choose **Research / commercial-compatible weights** for MIT / Apache 2.0
checkpoints. **Noncommercial research** additionally enables all ConvNeXt V2
variants, whose weights are CC BY-NC 4.0. Hardware profiles do not change model
license terms. Research done for a commercial purpose is not automatically
noncommercial. Usage purpose is recorded in each search and checkpoint.

New models use pinned timm implementations, safetensors weights, model-card
license checks and full published SHA-256 verification. Offline reuse verifies
local hashes against `weights_manifest.json`; copy that manifest with weights
when provisioning another machine. No model-repository Python code is executed.

## Downloads on every profile

**Allow missing public weights to download** is available in preset search
and Custom search, using the same policy on laptop and GPU workstation.
Enable it to provision missing weights during a new search. Disable it to
require verified local weights. **Download weights** remains an explicit
provisioning action even when automatic downloading is disabled.

Images, labels and reports stay local. Inference uses saved local models and
does not provision weights. Downloads and integrity checks consume the search
budget. Pause/cancel and the deadline apply during provisioning too.

## Workstation extended profile

Select **Workstation extended · 48 hours · maximum 50** in the dashboard.
The preset name in YAML and CLI is `workstation_50h`.

| Setting | Default |
| --- | --- |
| Device | CUDA |
| Total cumulative budget | 48 hours; maximum 50 hours |
| Initial candidates | EfficientNet V2 S/M, ConvNeXt base/large, DeiT III base/large, Swin V2 base, EVA-02 base |
| Sampler / pruner | TPE / median |
| Trials per architecture | Up to 120; time and failure limits may stop earlier |
| Trial time limit | 2 hours within the remaining shared training budget |
| Maximum epochs / epoch patience | 100 / 15 |
| Initial physical / effective batch | 2 / 32 |
| Effective batch search | 32, 64, 128 via gradient accumulation |
| Mixed precision | Enabled for CUDA training |
| Fine-tuning scopes | Head only, last block, full backbone |
| Learning rate search | Backbone 1e-6 to 3e-4; head 1e-5 to 3e-3 |
| Weight decay search | 1e-6 to 0.1 |
| Training / confirmation seeds | 42, 123, 2026 |
| Shortlist | Up to 2 candidates per architecture |
| Budget reserves | 15% for confirmation; 20% for calibration/selection |
| Loader workers / CPU threads | 2 / 8 |

The 50-hour ceiling is validated in preset hours, Custom seconds, YAML/CLI
and the process supervisor. Resume retains consumed time and does not grant
another 48 hours. Existing profiles retain their editable budgets.

Select additional large/huge candidates when the target GPU has sufficient memory.
The preset is a practical starting search, not a universal optimal configuration.
More candidates leave less time for each model. The chosen winner is the best
eligible result among the trials actually completed on the development data;
final-test data does not drive search or threshold tuning.

Native image pixels remain preserved. The tool pads the shared canvas for
convolution/window backbones; DeiT and EVA interpolate positional embeddings
and pad patch grids rather than resizing the inspection images. Attention cost
can grow sharply on large native images. Memory errors remain explicit; lower
the physical batch size in Custom settings while keeping effective batch sizes
divisible by it. No automatic resolution reduction or device fallback occurs.

Example CLI equivalent:

```bash
.venv-studio6/bin/python inspection.py search --config project.yaml --profile workstation_50h --task vig --hours 48
```

Keep the machine powered and awake for the run. Start with a short run on the
target dataset and GPU before scheduling a two-day experiment.
