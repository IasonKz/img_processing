# Start Here

## 1. Install the annotation environment

Extract the project to a writable folder. Use Python 3.10 or newer with a compatible dependency build; Python 3.11 or 3.12 is a practical starting point. Open a terminal in the extracted project folder.

Windows PowerShell:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe segmentation.py doctor
```

Linux/macOS:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python segmentation.py doctor
```

The remaining examples use `python`. In PyCharm, select this project's `.venv` interpreter. In an ordinary terminal, activate that environment or replace `python` with its full path as above.

## 2. Set the paths

Edit `project.yaml`. The input folder may contain nested folders; it should contain the prepared **top** images to annotate.

```yaml
input_dir: 'C:/inspection/input/top'
project_dir: 'C:/inspection/work/top_annotations'
output_dir: 'C:/inspection/output/top_segmentation'
```

On Linux, use paths such as `/home/operator/inspection/input/top`. Relative paths are resolved against the configuration file's folder. Use a separate working project folder outside the input tree. Originals are read for import; image copies, annotations, and training outputs are written elsewhere.

If several images show the same physical unit, configure `group_regex` before import so that they remain together in the train/validation split. See [Configuration](docs/CONFIGURATION_REFERENCE.md).

## 3. Annotate one image at a time

```bash
python segmentation.py annotate --config project.yaml
```

The command imports copies and opens the local browser interface. Keep the terminal running. If the browser does not open, use the address printed in the terminal.

For an existing project, import subsequently added image files with `python segmentation.py init --config project.yaml` before continuing annotation.

For each image:

1. Check the yellow inner polygon. Try **Detect inner boundary**, or define it manually with the boundary tools.
2. Inspect the proposed defects. If needed, adjust detection settings and generate proposals again before manual correction.
3. Correct defect pixels using the drawing tools and eraser. Inner/Outer is assigned automatically from the yellow boundary. Use the annotation list to inspect, hide or delete individual shapes.
4. Approve the corrected image. For a defect-free image, use the explicit clean approval action.
5. Continue to the next image. Use **Exclude image & next** to exclude an unsuitable image while retaining its original and saved annotations.

Save a draft when an annotation is unfinished. Only approved revisions are included in a training dataset. Re-running automatic proposals replaces the current proposal/mask being edited, so use it before detailed manual work or save that work first.

Close the interface and press `Ctrl+C` in the terminal to stop the server. Run the same command to continue later. The current approved/draft state is retained in the working project.

## 4. Check and export the dataset

```bash
python segmentation.py status --config project.yaml
python segmentation.py dataset --config project.yaml --output outputs/top_dataset_v1
```

Use a new export folder for each snapshot. Review the masks and include real clean examples as well as inner and outer defects. The default minimum of five approved images is only a software guard, not evidence that the dataset is sufficient. Each defect class should have multiple independent examples on both sides of the split.

## 5. Install training support

For CPU testing on Windows or Linux:

```bash
python -m pip install "torch>=2.5,<3" --index-url https://download.pytorch.org/whl/cpu
python -m pip install -r requirements-training.txt
python segmentation.py doctor --training
```

For another platform or CUDA, use the appropriate installation command from the [official PyTorch selector](https://pytorch.org/get-started/locally/), then install `requirements-training.txt`. Only `torch` is required; this project does not use torchvision or pretrained weights.

## 6. Train and inspect results

The default configuration is a CPU pilot with a small U-Net. Training snapshots the approved annotations automatically:

```bash
python segmentation.py train --config project.yaml
```

The command prints the new run directory. Inspect its report, per-class metrics, validation overlays, and `model_state.json`. Record that exact run path; `best.pt` is the checkpoint selected by validation performance. See [Training and results](docs/TRAINING_AND_RESULTS.md).

## 7. Predict new images

Replace the checkpoint placeholder with the path printed after training:

```bash
python segmentation.py predict --checkpoint outputs/runs/RUN_ID/best.pt --input data/new_top --output outputs/predictions_v1 --device cpu
```

Predictions are written as class-index masks, colored overlays, and a CSV summary. The originals remain unchanged. Prediction results do not automatically become approved annotations.

## Optional: try the interface with synthetic images

```bash
python segmentation.py demo --output demo_project
```

Use the configuration path printed by the command with `annotate`. Synthetic data is a functional demonstration and must not be used to claim real inspection performance.
