# Operator Guide

## Operating convention

Use one project configuration and the same application release on both computers. Change folder paths in `project.yaml`; do not edit Python source files. Run commands from the project directory with its Python environment active. All examples use `top`; substitute `bottom` or `vig` as appropriate.

The development workflow audits data, freezes split assignments, trains candidates, tunes thresholds, selects a candidate, and writes reports plus prediction folders. Final test evaluation and release activation are separate commands. The latest run does not automatically become the active model.

## Initial configuration

1. Set `paths.output_root` and `paths.weights_root` in `project.yaml`.
2. Set `tasks.top.dataset_root` to the directory containing `good` and `bad`.
3. Enable the tasks to be processed and configure their incoming/output folders if using configuration-driven inference.
4. Define grouping through a mapping or extraction rule. Confirm physical-unit independence only after reviewing the mapping.
5. Review the quality policy and input geometry. The example policy values are starting configuration, not an externally certified production requirement.

Pretrained files must already be local. See [INSTALLATION.md](INSTALLATION.md) for provisioning. Keep output directories outside the labeled dataset and incoming folders.

## Environment and data checks

```bash
python inspection.py doctor --config project.yaml --profile laptop --task top
python inspection.py audit --config project.yaml --task top
```

`doctor` checks the local configuration and resources. `audit` inspects source images and reports data problems before training. Neither modifies original image bytes. Resolve conflicting labels, unusable input, insufficient split support, and uncertain grouping before interpreting quality metrics.

## Development run

CPU pilot:

```bash
python inspection.py run --config project.yaml --profile laptop --task top
```

GPU full roster:

```bash
python inspection.py run --config project.yaml --profile workstation --task top
```

Omit `--task` to run all enabled tasks in sequence. The command prints a distinct run directory per task. Keep that path for subsequent operations. Laptop pilot results are marked as pilot and cannot be activated as qualified production releases.

The input envelope is resolved from the dataset when `image_size: auto`. It is not reduced merely because the laptop profile is selected. The workstation profile requires its configured GPU; a missing GPU must be diagnosed explicitly.

Windows launchers, from the application directory:

```bat
scripts\run_laptop.cmd --task top
scripts\run_workstation.cmd --task top
```

The launchers only wrap the command-line interface. They do not create or activate an environment.

## Read the results

| Run artifact | Use |
| --- | --- |
| `model_report.html` | Current lifecycle state, data identity, and available model results |
| `model_state.json` | Machine-readable state and transition history |
| `comparison.html` | Candidate comparison on the fixed selection split |
| `leaderboard.csv` | Candidate metrics for spreadsheet analysis |
| `selected.json` | Selected members, threshold, score type, policy, and development status |
| `manifest.csv` | Image identity, labels, groups, and immutable split assignments |
| `split_summary.json` | Counts by split and class |
| `resolved_config.yaml` | Effective configuration after profile and input-size resolution |
| `environment.json` | Available runtime and model-weight provenance |
| `requirements_snapshot.txt` | Recorded installed package versions |
| `failed_candidates.json` | Candidate errors, if any |
| `comparison_folders/` | Per-candidate predictions, metrics, and image exports |

Focus first on `bad_passed_as_good_FN`, its denominator, and the false-rejection rate. Check whether the intended candidate roster completed; a failed architecture is not a successful comparison result. Open the error folders to review actual mistakes.

Each candidate export includes `predictions.csv`, `wrong_predictions.csv`, `review_priority.csv`, and available metrics. Image copies are organized into `predicted/good`, `predicted/bad`, and defect-oriented error folders. Filenames preserve traceability while avoiding collisions across trays.

The training application's error folders are `errors/bad_passed_as_good_FN` and `errors/good_rejected_as_bad_FP`. The standalone ONNX runner uses the shorter equivalent names `errors/bad_to_good` and `errors/good_to_bad` described in [DEPLOYMENT.md](DEPLOYMENT.md).

## Regenerate comparison image folders

The following command uses saved selection predictions and does not retrain models:

```bash
python inspection.py export --run ./results/top/RUN_ID --candidate selected --output ./review/top_selected
```

Use `--candidate all` for every candidate, or supply a name from `candidates.json`. Source images must still match the saved manifest. Select a new output location to avoid mixing exports.

## Final evaluation and activation

After freezing the candidate and threshold:

```bash
python inspection.py evaluate --run ./results/top/RUN_ID --split final-test
python inspection.py activate --config project.yaml --run ./results/top/RUN_ID
```

Inspect the final report before activation. The default release gate requires the configured empirical targets, completed candidate comparison, sufficient independent-unit statistical evidence, and a non-pilot run. A failed gate retains the current active release. An operator cannot make a pilot qualified merely by renaming its directory.

Do not repeat final-test inspection as part of routine threshold tuning. Repeated use is recorded as reused benchmark evidence; plan new independent holdout data after substantial development.

For a fresh labeled holdout after further development:

```bash
python inspection.py evaluate --run ./results/top/RUN_ID --split external --input ./holdout/top --groups-csv ./holdout/top_groups.csv
```

The mapping is optional only when the saved grouping rule or confirmed one-image-per-unit assumption correctly applies. External holdout images and physical units must be absent from the known dataset and previous external evaluations. Its evaluation ledger prevents the same inspected records from being silently reused as fresh evidence.

## Classify incoming images

Using active per-task releases and incoming/output paths configured in the project:

```bash
python inspection.py predict --config project.yaml --task top --device cpu
```

Using a particular source run for a local diagnostic batch:

```bash
python inspection.py predict --run ./results/top/RUN_ID --input ./incoming/top --output ./classified/top_batch_001 --device cpu
```

Using a portable ONNX package:

```bash
python inspection.py predict --model ./packages/top_release --input ./incoming/top --output ./classified/top_batch_001 --device cpu
```

Add `--labeled` only when the input is genuinely ground-truth-labeled under `good` and `bad`. Predictions are not labels for future training until reviewed. Invalid images are routed to review and are not implicitly accepted.

For ONNX-only computers, use the package's standalone `predict.py` described in [DEPLOYMENT.md](DEPLOYMENT.md).

## Resume or update

To continue an interrupted run without changing its experiment:

```bash
python inspection.py resume --run ./results/top/RUN_ID --device cpu
```

To train a new generation with the updated configured data:

```bash
python inspection.py update --config project.yaml --from-run ./results/top/PREVIOUS_RUN --profile workstation
```

The update infers the task from the previous run. Its dataset must retain the old records and include the reviewed new data; prior held-out groups remain held out. See [MODEL_MANAGEMENT.md](MODEL_MANAGEMENT.md) for checkpoint and data-version requirements.

## Status and diagnostics

```bash
python inspection.py status --config project.yaml
python inspection.py smoke --output ./smoke_results
```

The default smoke command is a synthetic software check. Where the complete model dependencies are available:

```bash
python inspection.py smoke --output ./smoke_models --with-models
python inspection.py smoke --output ./smoke_onnx --with-models --with-onnx
```

Synthetic smoke metrics are not reported as customer-data model performance. Use a fresh output directory for each smoke run.

## Exit codes

| Code | Meaning |
| --- | --- |
| `0` | Command completed; inspect the recorded quality/qualification state |
| `2` | Invalid arguments, configuration, paths, data, or failed activation gate |
| `3` | Missing dependency, runtime/resource failure, I/O failure, or unsuccessful doctor check |
| `5` | Final/external evaluation completed but empirical quality targets were not met |
| `130` | Operator interruption |

A successful `run` exit means the experiment executed, including the possibility of a recorded `TARGET_NOT_MET`. An `evaluate` exit of zero indicates empirical target compliance; it does not imply statistical sufficiency or activation eligibility. Inspect `model_state.json`, the evaluation summary, and the activation result. Use the explicit `activate` command to apply the full configured release gate.

## Full command index

| Command | Purpose |
| --- | --- |
| `doctor` | Configuration, dependency, device, and local-resource checks |
| `audit` | Data discovery, identity, dimensions, duplicate/group review |
| `run` | New development run for configured tasks |
| `resume` | Continue recorded experiment from saved state |
| `update` | New generation with old-plus-new reviewed data |
| `compare` | Paired old/new fixed-system comparison |
| `evaluate` | Fixed-system held-out evaluation |
| `activate` | Change active release after checks |
| `status` | Inspect project release state |
| `predict` | Classify an image directory |
| `export` | Rebuild image folders from stored candidate predictions |
| `package` | Portable inference or training archive |
| `restore` | Restore a training package and remap matching source data |
| `download-weights` | Explicit online public-weight provisioning |
| `smoke` | Synthetic workflow validation |

The installed interface is authoritative. Run `python inspection.py COMMAND --help` for accepted arguments and defaults.
