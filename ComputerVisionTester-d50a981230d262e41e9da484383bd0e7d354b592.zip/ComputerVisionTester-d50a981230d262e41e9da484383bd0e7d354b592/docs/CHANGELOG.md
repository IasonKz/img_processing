# Changelog

## SwinV2 pretrained checkpoint compatibility — 2026-10-05

- Apply the official timm SwinV2 checkpoint filter before strict safetensors loading in Studio training and the standalone classifier.
- Rebuild derived attention masks and position buffers rather than treating them as learned checkpoint parameters. Keep missing/unexpected parameter and shape checks strict.
- Cover the reported attention-buffer failure, binary-head gradient execution, standalone inference and incompatible parameter rejection with real local SwinV2 safetensors fixtures.
- Verified the official SHA-256-checked SwinV2 Tiny pretrained checkpoint with a real binary-head CPU optimizer step on synthetic inputs. CUDA and production accuracy were not evaluated.

## Classification Optuna configuration fix — 2026-10-05

- Read dashboard JSON search contracts with the JSON parser so scientific-notation learning rates remain numeric across the CLI/worker boundary.
- Share format-aware configuration loading between the dashboard, project loader and single-task loader, retaining YAML and UTF-8 BOM support.
- Keep zero, negative, nonfinite, boolean and quoted-string learning rates invalid.
- Regression coverage for every hardware profile in profile/custom mode, plus a real pretrained ResNet18 CPU dashboard-to-worker smoke check for laptop/workstation.
- [Verification and repeatable smoke check](CLASSIFICATION_OPTUNA_FIX_VERIFICATION.md).

## Deployment quality review — 2026-10-05

- Per-unit TOP/BOTTOM/VIG evidence review after folder/ZIP inspection, with explicit links to completed classification and segmentation runs.
- Native originals/crops, model masks/overlays, ROI geometry, prediction boundaries, evaluated stage agreement and comparable cohort distributions.
- Optional selected-unit or batch HTML/CSV/JSON/ZIP reports with native evidence and provenance checksums.
- Immutable review snapshots, conservative missing-view routing, paginated unit browsing and managed worker cancellation.
- Mixed-view input selection prevents TOP/BOTTOM captures from entering a VIG-only deployment model.
- [Quality review operating guide](DEPLOYMENT_QUALITY_REVIEW.md).

## ROI segmentation and documentation update — 2026-10-05

- Shared TOP/BOTTOM crop annotation projects between ROI Detection and Segmentation, with frozen crop provenance, native uint8/uint16 pixels and inherited physical-unit splits.
- Segmentation target selection for TOP whole-image defects, TOP/BOTTOM ROI crop defects and geometric ROI localizer training.
- English ROI operator guides, a general VIG development plan and documented contribution standards.
- Neutral technical wording across documentation and interface messages; portable paths in bundled segmentation configurations.

## Dashboard workspaces update

- Reversible good/bad/review/unsuitable data cleaning, keyboard image navigation and tray membership roles.
- Exact single/double threshold tuning on multiple labelled datasets and saved VIG deployment pipelines for folders/ZIPs.
- Native path pickers, global owned-worker termination and prominent per-model score/threshold evidence.
- Independent TOP/BOTTOM annotation and segmentation projects from Studio v2, with local assets and optional model dependencies.
- [Operating and update guide](WORKSPACE_STUDIO.md).

## 6.1.0

- Experimental Intel laptop DirectML training preset, independent of the CPU preset.
- Shared explicit automatic-public-weight-download policy for all profiles.
- Historical training and tray-quality documentation with separate original and operator labels, exposure warnings and matched-image comparisons.
- Local HTML, CSV and JSON report bundles with provenance hashes and charts.


## 6.0.0

- Nine core Optuna samplers with validated custom options and explicit parameter domains.
- Native uint16 PNG/TIFF decoding and fixed float32 intensity conversion across training, inference, audit and ONNX exports.
- Editable native canvas and memory guard; no silent spatial downsampling.
- Optional Windows DirectML adapter routing with separate setup and hardware probe.
- Two-threshold triage, multi-model disagreement review, consensus workflow and independent operator review tags.
- Cooperative cancellation, retained unfinished checkpoints, diagnostic human-review inference and forced-stop reconciliation.
- Winning-parameter and selection-performance radars with exact values and disclosed normalization.
- NILT terminal animation and updated Windows/Linux operating guides.
- Integrated good/bad dataset preparation tool retains native depth by default.


## 5.0.0

- Removed profile-specific time ceilings. Presets supply editable defaults; Custom Optuna selects CPU/CUDA/Auto, CPU threads, data-loader workers, and an independently defined total budget.
- Added combined learning/search analytics, parameter relationship plots, candidate comparison charts, and confusion-matrix grids with explicit evidence roles.

- Added validated Custom Optuna contracts: fixed/choices/range specifications, per-model overrides, validation-objective selection, TPE/Random/finite Grid, selectable pruners, trial allowances, improvement patience, and failure caps.
- Added pretrained EfficientNet-B2, EfficientNetV2-S, MobileNetV3-Large, and DenseNet121 while keeping focused profile shortlists. Image-model searches require pretrained initialization.
- Added optional shared global-plus-overlapping-patch classification with image-level supervision, complete spatial coverage, and explicit memory/coverage limits.
- Corrected weighted-loss normalization so minority weights remain effective with single-image microbatches. Old resumable optimizer states are not assumed compatible; old checkpoints retain inference use.
- Added Decision Lab for triage, weighted ensembles, regularized held-out stacking, and confidence cascades. Score calibration/combiner fitting uses protected calibration-fit groups, with threshold tuning on separate groups and a frozen-system selection report.
- Added threshold-pair sweep and bounded Optuna decision tuning, with separate error/review targets and no automatic final-test access.
- Added reviewed-data revision export with explicit human labels, content/group checks, unchanged old holdouts, and training replay for controlled fine-tuning.
- Added a short Linux launcher and Windows v5-specific environment defaults. Previous project folders and virtual environments are retained.

Full grouped OOF stacking, DINOv2 integration, segmentation, arbitrary nested systems, and automatic whole-system ONNX export are not implemented. See [V5_DESIGN_AND_LIMITS.md](V5_DESIGN_AND_LIMITS.md) and the release verification record.

## 4.0.0

- Reworked the local workspace for model development, inspection sequences, and image review.
- Added immutable ordered workflow recipes with any-bad, all-bad, and majority rules, short-circuit traces, and labeled batch metrics.
- Added live copied-image review with original reference tags, separate operator tags and notes, and explicit metric scopes.
- Added dedicated Windows setup/start launchers, separate short-path environments, and a real requested-device computation check.
- Integrated atomic output publishing with bounded retry for transient Windows access and sharing failures.
- Replaced legacy operator material with English setup, workflow, review, and troubleshooting guides.
- Retained profile budgets, full-image preprocessing, quarter-turn VIG augmentation, decision modes, and portable model operations.

## 3.0.0

- Integrated the prior threshold, policy-review, visual-report and telemetry additions.
- Added per-model Optuna studies, profile-specific search spaces, bounded seed
  confirmations, resumable SQLite studies and cumulative 2/6/12-hour budgets.
- Added a local browser dashboard for configuration, search, comparison, decisions,
  classification, reports and export.
- Preserved native image pixels with padding and exact quarter-turn VIG training
  augmentation; grouped tray/row/column units remain in a single split.
- Corrected weighted-loss normalization across microbatches; added explicit
  head-only/full/last-block training and fine-tuning-aware stopping/pruning.
- Added versioned policy/manual/argmax/scores-only decisions and portable runtime
  support without modifying original model results.
- Made missing targets, incomplete comparisons and outstanding independent tests
  visible; included constant-class baselines and both class error rates.
- Added Windows CPU/CUDA setup, three launch profiles and a reproducible synthetic
  end-to-end smoke check. ONNX Runtime telemetry is disabled before session creation.

Optuna searches a bounded set of candidates; no customer-dataset performance is
guaranteed. See [VALIDATION_REPORT.md](VALIDATION_REPORT.md) for executed checks and
remaining Windows/GPU acceptance work. The older notes below describe v2 only.

## 2.0.0

- Added project-level task configuration with CPU pilot and GPU workstation profiles.
- Added PatchCore-style normal-feature memory banks alongside the supervised roster.
- Added automatic image-envelope discovery without a fixed 600×600 assumption.
- Added tracked model state, immutable manifests, continuation checkpoints, and frozen-version comparison.
- Added ONNX packages with independent runtime scripts, package integrity, and parity verification.
- Added training-package relocation, current-model registration, and rollback support.
- Added English operator, installation, model-management, and deployment documentation.
- Retained defect-oriented decision policy, separate development/test roles, and image-folder exports.

### Scope limits

This release does not implement pairwise new-damage classification, camera-die cropping/alignment, tiled training, grouped cross-validation, automatic hyperparameter search, probability calibration, quantization, a graphical interface, or machine/PLC control. The PatchCore-style implementation differs from the published reference scoring method as documented in [MODELS_AND_METRICS.md](MODELS_AND_METRICS.md).

Actual test coverage and hardware acceptance status are recorded in [VALIDATION_REPORT.md](VALIDATION_REPORT.md). No accuracy or throughput is asserted for a customer dataset before the relevant experiment has run.
