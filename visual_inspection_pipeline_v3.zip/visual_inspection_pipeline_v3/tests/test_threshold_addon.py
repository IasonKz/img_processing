"""Threshold and file-lifecycle tests. Neural inference is mocked explicitly."""
import argparse
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
from PIL import Image

import threshold_addon as addon
from nilt.common import sha_file
from test_integration_v2 import fixture_run


def args(**kwargs):
    values = dict(run=None, from_results=None, decision=None, input=None, split=None,
                  thresholds=[.5, .65], labeled=False, copy_images=False, device=None, output_root=None)
    values.update(kwargs)
    return argparse.Namespace(**values)


class ThresholdTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.run, self.data, _ = fixture_run(self.root, threshold=.5)
        folder = self.run / "scores" / "patchcore_seed42"
        folder.mkdir(parents=True)
        np.save(folder / "threshold.npy", [.5, .9, .2, .6])
        self.before = {p.relative_to(self.run): sha_file(p) for p in self.run.rglob("*") if p.is_file()}

    def tearDown(self):
        after = {p.relative_to(self.run): sha_file(p) for p in self.run.rglob("*") if p.is_file()}
        self.assertEqual(self.before, after, "Original run was changed")
        self.temp.cleanup()

    def test_archive_comparison_equality_replay_and_copies(self):
        out = addon.execute(args(run=str(self.run), output_root=str(self.root / "outputs"), copy_images=True))
        folders = sorted(out.glob("threshold_*"))
        first = addon.read_json(folders[0] / "metrics.json")
        second = addon.read_json(folders[1] / "metrics.json")
        self.assertEqual((first["bad_detected_TP"], first["good_rejected_as_bad_FP"]), (2, 1))
        self.assertEqual((second["bad_passed_as_good_FN"], second["good_rejected_as_bad_FP"]), (1, 0))
        self.assertEqual(len(list((folders[0] / "predicted" / "bad").iterdir())), 3)
        replay = addon.execute(args(from_results=str(out), output_root=str(self.root / "outputs"), thresholds=[.65]))
        self.assertNotEqual(out, replay)
        self.assertEqual(addon.read_json(next(replay.glob("threshold_*")) / "metrics.json"), second)

    def test_new_labeled_invalid_and_saved_decision(self):
        source = self.root / "new"
        for label in ("good", "bad"):
            (source / label).mkdir(parents=True)
            Image.new("RGB", (32, 32), "red" if label == "good" else "blue").save(source / label / "same_name.png")
        (source / "bad" / "broken.png").write_bytes(b"not an image")
        with patch("nilt.workflow.predict_members", return_value=(np.array([.6, .8]), .01)) as backend:
            out = addon.execute(args(run=str(self.run), input=str(source), labeled=True,
                                     output_root=str(self.root / "outputs"), copy_images=True))
            backend.assert_called_once()
        self.assertEqual(len(list((out / "review").iterdir())), 1)
        decision = sorted(out.glob("threshold_*/decision.json"))[1]
        with patch("nilt.workflow.predict_members", return_value=(np.array([.6, .8]), .01)):
            new = addon.execute(args(decision=str(decision), input=str(source), labeled=False,
                                     thresholds=None, output_root=str(self.root / "outputs")))
        self.assertEqual(addon.read_json(new / "summary.json")["thresholds"], [.65])
        self.assertEqual(list(new.rglob("metrics.json")), [])

    def test_changed_image_and_tampered_cache_rejected(self):
        out = addon.execute(args(run=str(self.run), output_root=str(self.root / "outputs")))
        Image.new("RGB", (32, 32), "black").save(self.data / "bad" / "threshold_0.png")
        with self.assertRaisesRegex(ValueError, "Source image changed"):
            addon.execute(args(from_results=str(out), output_root=str(self.root / "outputs"), copy_images=True))
        (out / "scores.json").write_text("{}")
        with self.assertRaisesRegex(ValueError, "Cached scores changed"):
            addon.execute(args(from_results=str(out), output_root=str(self.root / "outputs")))

    def test_nested_output_and_nonfinite_threshold_rejected(self):
        with self.assertRaisesRegex(ValueError, "separate"):
            addon.execute(args(run=str(self.run), output_root=str(self.data / "out")))
        with self.assertRaisesRegex(ValueError, "finite"):
            addon.execute(args(run=str(self.run), output_root=str(self.root / "outputs"), thresholds=[float("nan")]))

    def test_anomaly_scale_and_missing_class_denominator(self):
        stats = addon.describe([{"true_class": "bad"}], np.array([5.]), 5.)
        self.assertEqual(stats["bad_detected_TP"], 1)
        self.assertIsNone(stats["good_reject_rate"])


if __name__ == "__main__":
    unittest.main()
