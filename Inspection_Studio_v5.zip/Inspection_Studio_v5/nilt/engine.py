"""Local-only supervised training, epoch-boundary recovery, and generic inference."""
from __future__ import annotations

from contextlib import nullcontext
import hashlib
import json
import csv
import copy
import os
from pathlib import Path
import random
import re
import shutil
import tempfile
import time
import uuid

import numpy as np
from PIL import Image

from .common import LABELS, sha_file, write_csv, write_json, _replace_file_with_retry
from .data import load_rgb
from .preprocessing import MEAN, STD, prepare_image, rotate_quarter_turn, validate_patch_settings

WEIGHTS = {
    "resnet18": "IMAGENET1K_V1", "resnet50": "IMAGENET1K_V2",
    "efficientnet_b0": "IMAGENET1K_V1", "convnext_tiny": "IMAGENET1K_V1",
    "swin_t": "IMAGENET1K_V1", "efficientnet_b2": "IMAGENET1K_V1",
    "efficientnet_v2_s": "IMAGENET1K_V1", "mobilenet_v3_large": "IMAGENET1K_V2",
    "densenet121": "IMAGENET1K_V1",
}
BACKEND_FORMAT_VERSION = 2
VALIDATION_OBJECTIVES = {"validation_ap": "pr_auc_bad", "validation_roc_auc": "roc_auc_bad",
                         "validation_balanced_accuracy": "balanced_accuracy"}


class TrainingStopped(RuntimeError):
    """Cooperative budget/pause stop. The last committed epoch remains resumable."""
    def __init__(self, reason="stopped"):
        self.reason = str(reason)
        super().__init__(self.reason)


def check_stop(stop_check=None):
    if stop_check is not None:
        reason = stop_check()
        if reason:
            raise TrainingStopped(reason if isinstance(reason, str) else "stopped")


def resource_sample(device=None):
    """Cheap sampled process RAM and current/peak allocator VRAM, in bytes."""
    result = {"ram_bytes": None, "vram_bytes": None, "peak_vram_bytes": None}
    try:
        import psutil
        result["ram_bytes"] = psutil.Process().memory_info().rss
    except ImportError:
        pass
    if device is not None and getattr(device, "type", None) == "cuda":
        torch, _ = torch_modules()
        result["vram_bytes"] = torch.cuda.memory_allocated(device)
        result["peak_vram_bytes"] = torch.cuda.max_memory_allocated(device)
    return result


def append_telemetry(path, row):
    path = Path(path)
    fresh = not path.exists() or path.stat().st_size == 0
    with path.open("a", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(row))
        if fresh:
            writer.writeheader()
        writer.writerow(row)


def torch_modules():
    try:
        import torch
        import torchvision
        return torch, torchvision
    except (ImportError, RuntimeError, OSError) as exc:
        raise RuntimeError("Install compatible torch and torchvision builds; see docs/INSTALLATION.md. " + str(exc)) from exc


def device_for(cfg):
    torch, _ = torch_modules()
    torch.set_num_threads(int(cfg.get("cpu_threads", 4)))
    # FP32 scoring must not silently use TF32's reduced input mantissa on GPUs.
    # Explicit training autocast remains available independently.
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.set_float32_matmul_precision("highest")
    value = str(cfg.get("device", "auto"))
    if value == "auto":
        value = "cuda" if torch.cuda.is_available() else "cpu"
    device = torch.device(value)
    if device.type not in ("cpu", "cuda"):
        raise ValueError("This release supports CPU and NVIDIA CUDA execution.")
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable. Install a matching NVIDIA PyTorch build or select cpu.")
    return device


def seed_everything(seed):
    torch, _ = torch_modules()
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def required_weight_names(cfg):
    names = []
    for name in cfg["models"]:
        if name == "patchcore":
            name = cfg.get("patchcore", {}).get("backbone", "resnet18")
            if name not in ("resnet18", "resnet50"):
                raise ValueError("PatchCore backbone must be resnet18 or resnet50.")
        if name not in WEIGHTS:
            raise ValueError(f"Unsupported model: {name}; supported: {list(WEIGHTS) + ['patchcore']}")
        if name not in names:
            names.append(name)
    return names


def weight_path(cfg, name):
    if name == "patchcore":
        name = cfg.get("patchcore", {}).get("backbone", "resnet18")
    return Path(cfg["weights_dir"]) / f"{name}__{WEIGHTS[name]}.pth"


def check_weights(cfg):
    torch_modules()
    names = required_weight_names(cfg)
    if not cfg.get("pretrained", True):
        print("WARNING: pretrained=false is a random-feature smoke experiment, not a validated pretrained model.", flush=True)
        return
    missing = [str(weight_path(cfg, name)) for name in names if not weight_path(cfg, name).is_file()]
    if missing:
        raise FileNotFoundError("Missing LOCAL pretrained weights:\n" + "\n".join(missing)
                                + "\nUse the documented download-weights command on a connected machine and copy the weights folder. Training never downloads.")


def make_model(name, cfg=None, pretrained=False):
    torch, tv = torch_modules()
    if name not in WEIGHTS:
        raise ValueError(f"Unsupported supervised model: {name}")
    model = tv.models.get_model(name, weights=None)
    if pretrained:
        state = torch.load(weight_path(cfg, name), map_location="cpu", weights_only=True)
        if name.startswith("densenet"):
            # Official DenseNet ImageNet weights retain the old `norm.1` key
            # spelling. Match TorchVision's loader migration without download.
            legacy = re.compile(r"^(.*denselayer\d+\.(?:norm|relu|conv))\.((?:[12])\.(?:weight|bias|running_mean|running_var|num_batches_tracked))$")
            state = {legacy.sub(r"\1\2", key): value for key, value in state.items()}
        model.load_state_dict(state, strict=True)
    if name.startswith("resnet"):
        model.fc = torch.nn.Linear(model.fc.in_features, 2)
        head = model.fc
    elif name.startswith(("efficientnet", "convnext", "mobilenet")):
        model.classifier[-1] = torch.nn.Linear(model.classifier[-1].in_features, 2)
        head = model.classifier
    elif name.startswith("densenet"):
        model.classifier = torch.nn.Linear(model.classifier.in_features, 2)
        head = model.classifier
    else:
        model.head = torch.nn.Linear(model.head.in_features, 2)
        head = model.head
    if cfg and cfg.get("image_strategy", "full_image") == "global_patches":
        from .patch_models import GlobalPatchClassifier
        model = GlobalPatchClassifier(model, cfg)
    return model, head


class Transform:
    def __init__(self, cfg, training=False):
        _, tv = torch_modules()
        self.cfg = cfg
        aug = cfg.get("augmentation", {})
        if training and any(float(aug.get(key, 0)) != 0 for key in ("brightness", "contrast", "rotation_degrees")):
            raise ValueError("Only exact 90-degree augmentation is supported; disable photometric and arbitrary-angle augmentation.")
        self.rotation90 = bool(training and aug.get("rotation90", False))
        self.tensor = tv.transforms.Compose([tv.transforms.ToTensor(), tv.transforms.Normalize(MEAN, STD)])

    def __call__(self, image):
        if self.rotation90:
            image = rotate_quarter_turn(image, random.randrange(4))
        return self.tensor(prepare_image(image, self.cfg))


class ImageDataset:
    def __init__(self, rows, cfg, training=False):
        self.rows = rows
        self.transform = Transform(cfg, training)

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, idx):
        row = self.rows[idx]
        return self.transform(load_rgb(row["path"])), int(row.get("label", 0))


def worker_seed(worker_id):
    torch, _ = torch_modules()
    seed = torch.initial_seed() % 2 ** 32
    np.random.seed(seed)
    random.seed(seed)


def loader(rows, cfg, training=False, seed=42, sampler=None, generator=None):
    torch, _ = torch_modules()
    generator = generator if generator is not None else torch.Generator().manual_seed(seed)
    settings = cfg["training"]
    batch = settings["batch_size"] if training else settings.get("eval_batch_size", settings["batch_size"])
    return torch.utils.data.DataLoader(
        ImageDataset(rows, cfg, training), batch_size=batch, shuffle=training and sampler is None,
        sampler=sampler, num_workers=cfg.get("num_workers", 0),
        pin_memory=str(cfg.get("device")) != "cpu" and torch.cuda.is_available(),
        worker_init_fn=worker_seed, generator=generator, drop_last=False,
        persistent_workers=False,
    )


def imbalance_setup(rows, cfg, seed):
    torch, _ = torch_modules()
    labels = np.asarray([int(row["label"]) for row in rows])
    counts = np.bincount(labels, minlength=2)
    if len(counts) != 2 or min(counts) == 0:
        raise ValueError("Supervised training requires both bad=0 and good=1.")
    ratio = max(counts) / min(counts)
    settings = cfg["training"]
    mode = settings.get("imbalance", "auto")
    if mode == "auto":
        mode = "weighted_loss" if ratio >= settings.get("imbalance_trigger", 1.5) else "none"
    if mode not in ("none", "weighted_loss", "sampler"):
        raise ValueError("imbalance must be auto, none, weighted_loss, or sampler.")
    class_weights = np.minimum(max(counts) / counts, settings.get("max_class_weight", 20.0))
    loss_weights, sampler = None, None
    normalization = 1.0
    if mode == "weighted_loss":
        # Use a fixed training-population normalization. Dividing each update
        # by its sum of class weights cancels weighting for singleton updates.
        normalization = float(np.dot(class_weights, counts) / counts.sum())
        loss_weights = torch.tensor(class_weights / normalization, dtype=torch.float32)
    elif mode == "sampler":
        sampler = torch.utils.data.WeightedRandomSampler(
            torch.as_tensor(class_weights[labels], dtype=torch.double), num_samples=len(rows),
            replacement=True, generator=torch.Generator().manual_seed(seed))
    return loss_weights, sampler, {"mode": mode, "class_counts": counts.tolist(),
                                  "class_weights": class_weights.tolist() if mode != "none" else [1, 1],
                                  "loss_weight_normalization": normalization,
                                  "effective_loss_weights": loss_weights.tolist() if loss_weights is not None else [1., 1.],
                                  "loss_reduction": "fixed_population_weight_normalization_then_sample_mean",
                                  "ratio": float(ratio), "class_to_index": LABELS}


def autocast_context(device, enabled):
    torch, _ = torch_modules()
    return torch.autocast(device_type="cuda", dtype=torch.float16) if enabled and device.type == "cuda" else nullcontext()


def predict_model(model, rows, cfg, device, stop_check=None, on_scores=None):
    torch, _ = torch_modules()
    device = torch.device(device)
    model.eval()
    if not rows:
        return np.empty(0, dtype=float), torch.empty((0, 2)), 0.0
    logits = []
    offset = 0
    batches = loader(rows, cfg)
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    start = time.perf_counter()
    with torch.inference_mode():
        for inputs, _ in batches:
            check_stop(stop_check)
            # Inference runs in FP32 on both source and ONNX reference; training AMP
            # must not silently alter a selected threshold on a different device.
            values = model(inputs.to(device, non_blocking=True)).float()
            batch_logits = values.cpu()
            if not torch.isfinite(batch_logits).all():
                raise RuntimeError("Nonfinite logits; inspect the input and checkpoint.")
            logits.append(batch_logits)
            if on_scores is not None:
                on_scores(offset, batch_logits.softmax(1)[:, 0].numpy().astype(float))
            offset += len(batch_logits)
    check_stop(stop_check)
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    seconds = time.perf_counter() - start
    values = torch.cat(logits)
    if not torch.isfinite(values).all():
        raise RuntimeError("Nonfinite logits; inspect the input and checkpoint.")
    return values.softmax(1)[:, 0].numpy().astype(float), values, seconds


def backend_fingerprints(name, seed, rows, cfg, parent=None):
    """Portable fingerprints exclude machine paths but include all model semantics."""
    def digest(value):
        return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                         allow_nan=False).encode()).hexdigest()
    semantics = {key: cfg.get(key) for key in
                 ("task", "image_size", "resize", "pretrained", "training", "augmentation", "patchcore")}
    if cfg.get("image_strategy", "full_image") != "full_image":
        semantics.update(image_strategy=cfg["image_strategy"], patches=validate_patch_settings(cfg))
    semantics["loss_weighting_version"] = 2
    semantics["validation_objective"] = cfg.get("search", {}).get("objective", "validation_ap")
    semantics.update(architecture=name, seed=int(seed), parent_sha256=sha_file(parent) if parent else None,
                     backend_format_version=BACKEND_FORMAT_VERSION, inference_precision="float32", tf32=False)
    data = sorted([(str(r.get("relative_path", Path(r["path"]).name)), str(r["pixel_hash"]),
                    int(r["label"]), str(r.get("group", "")), str(r["split"])) for r in rows])
    return {"config_fingerprint": digest(semantics), "data_fingerprint": digest(data)}


def _atomic_torch_save(value, path):
    torch, _ = torch_modules()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, filename = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    temporary = Path(filename)
    try:
        with os.fdopen(fd, "wb") as handle:
            torch.save(value, handle)
            handle.flush()
            os.fsync(handle.fileno())
        _replace_file_with_retry(temporary, path)
    finally:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass


def checkpoint_metadata(cfg, name, seed, epoch, parent=None):
    _, tv = torch_modules()
    torch, _ = torch_modules()
    return {"format_version": BACKEND_FORMAT_VERSION, "architecture": name, "kind": "supervised",
            "task": cfg["task"], "class_to_index": LABELS, "image_size": cfg["image_size"],
            "resize": cfg.get("resize", "pad"), "mean": MEAN, "std": STD, "seed": int(seed),
            "epoch": int(epoch), "torch_version": str(torch.__version__),
            "torchvision_version": str(tv.__version__), "parent_sha256": sha_file(parent) if parent else None,
            "score_type": "bad_probability_uncalibrated", "inference_precision": "float32",
            "tf32": False,
            "image_strategy": cfg.get("image_strategy", "full_image"),
            "patches": validate_patch_settings(cfg) if cfg.get("image_strategy") == "global_patches" else None,
            "loss_weighting_version": 2,
            "objective_metric": cfg.get("search", {}).get("objective", "validation_ap"),
            "initialization": "parent_checkpoint" if parent else ("local_imagenet_weights" if cfg.get("pretrained", True) else "random"),
            "pretrained": bool(cfg.get("pretrained", True)),
            "model_config": {key: copy.deepcopy(cfg[key]) for key in
                             ("task", "image_size", "resize", "training", "patchcore",
                              "preserve_native_resolution", "image_strategy", "patches") if key in cfg}}


def save_checkpoint(path, model, cfg, name, seed, epoch, parent=None, extra=None):
    payload = checkpoint_metadata(cfg, name, seed, epoch, parent)
    payload["state_dict"] = {key: value.detach().cpu() for key, value in model.state_dict().items()}
    payload.update(extra or {})
    _atomic_torch_save(payload, path)


def verify_checkpoint_configuration(checkpoint, cfg):
    for key, expected in (("task", cfg["task"]), ("class_to_index", LABELS),
                          ("image_size", cfg["image_size"]), ("resize", cfg.get("resize", "pad")),
                          ("mean", MEAN), ("std", STD)):
        if checkpoint.get(key) != expected:
            raise ValueError(f"Checkpoint {key} mismatch: {checkpoint.get(key)!r} vs {expected!r}.")
    if checkpoint.get("image_strategy", "full_image") != cfg.get("image_strategy", "full_image"):
        raise ValueError("Checkpoint image_strategy mismatch; use the checkpoint's recorded input strategy.")
    if cfg.get("image_strategy") == "global_patches" and checkpoint.get("patches") != validate_patch_settings(cfg):
        raise ValueError("Checkpoint patches mismatch; patch geometry and aggregation are part of the trained model.")


def load_checkpoint(path, cfg, device):
    torch, _ = torch_modules()
    checkpoint = torch.load(path, map_location="cpu", weights_only=True)
    verify_checkpoint_configuration(checkpoint, cfg)
    if checkpoint.get("kind") == "patchcore":
        from .patchcore import load_patchcore
        return load_patchcore(path, cfg, device)
    model, _ = make_model(checkpoint["architecture"], cfg)
    model.load_state_dict(checkpoint["state_dict"], strict=True)
    return model.to(device).eval(), checkpoint


def predict_checkpoint(path, rows, cfg, device=None, stop_check=None, on_scores=None):
    torch, _ = torch_modules()
    device = device_for(cfg) if device is None else torch.device(device)
    check_stop(stop_check)
    stored = torch.load(path, map_location="cpu", weights_only=True)
    inference_cfg = copy.deepcopy(cfg)
    # Candidate-specific input semantics travel with the checkpoint. Runtime
    # device, loader worker count and eval batch size remain the caller's choice.
    for key in ("image_size", "resize", "preserve_native_resolution", "patchcore", "image_strategy", "patches"):
        if key in stored.get("model_config", {}):
            inference_cfg[key] = copy.deepcopy(stored["model_config"][key])
    # Legacy supervised checkpoints predate the strategy fields.
    inference_cfg["image_strategy"] = stored.get("image_strategy", "full_image")
    if inference_cfg["image_strategy"] == "global_patches":
        inference_cfg["patches"] = copy.deepcopy(stored["patches"])
    del stored
    model, checkpoint = load_checkpoint(path, inference_cfg, device)
    try:
        if checkpoint.get("kind") == "patchcore":
            from .patchcore import predict_patchcore
            options = {"on_scores": on_scores} if on_scores is not None else {}
            return predict_patchcore(model, rows, inference_cfg, device, stop_check=stop_check, **options)
        options = {"on_scores": on_scores} if on_scores is not None else {}
        scores, _, seconds = predict_model(model, rows, inference_cfg, device, stop_check=stop_check, **options)
        return scores, seconds
    finally:
        del model
        if device.type == "cuda":
            torch.cuda.empty_cache()


def capture_rng(generator, sampler):
    torch, _ = torch_modules()
    state = np.random.get_state()
    return {"python": random.getstate(), "numpy_name": state[0],
            "numpy_keys": torch.tensor(state[1].astype(np.int64)), "numpy_pos": state[2],
            "numpy_has_gauss": state[3], "numpy_cached_gaussian": state[4],
            "torch": torch.get_rng_state(),
            "cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [],
            "loader": generator.get_state(),
            "sampler": sampler.generator.get_state() if sampler is not None else None}


def restore_rng(state, generator, sampler):
    torch, _ = torch_modules()
    random.setstate(state["python"])
    np.random.set_state((state["numpy_name"], state["numpy_keys"].numpy().astype(np.uint32),
                         state["numpy_pos"], state["numpy_has_gauss"], state["numpy_cached_gaussian"]))
    torch.set_rng_state(state["torch"])
    if torch.cuda.is_available() and state["cuda"]:
        for index, cuda_state in enumerate(state["cuda"][:torch.cuda.device_count()]):
            torch.cuda.set_rng_state(cuda_state, index)
    generator.set_state(state["loader"])
    if sampler is not None and state["sampler"] is not None:
        sampler.generator.set_state(state["sampler"])


def configure_training_stage(model, head, name, settings, epoch, is_update=False):
    """Freeze parameter gradients AND running/dropout behavior in frozen blocks."""
    mode = settings.get("mode", "full")
    warmup = 0 if is_update else int(settings.get("warmup_epochs", 2))
    frozen = mode == "head_only" or epoch < warmup
    if mode not in ("head_only", "full", "last_block"):
        raise ValueError("training.mode must be head_only, full or last_block.")
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    model.eval()
    if not frozen:
        if mode == "full":
            model.train()
            for parameter in model.parameters():
                parameter.requires_grad_(True)
        else:
            core = model.core if getattr(model, "image_strategy", None) == "global_patches" else model
            if name.startswith("resnet"):
                block = core.layer4
            elif name.startswith(("efficientnet", "convnext", "swin", "mobilenet")):
                block = core.features[-1]
            elif name.startswith("densenet"):
                block = core.features.denseblock4
            else:
                raise ValueError(f"No last_block mapping for {name}.")
            block.train()
            for parameter in block.parameters():
                parameter.requires_grad_(True)
    head.train()
    for parameter in head.parameters():
        parameter.requires_grad_(True)
    if settings.get("freeze_batch_norm", True):
        torch, _ = torch_modules()
        for module in model.modules():
            if isinstance(module, torch.nn.modules.batchnorm._BatchNorm):
                module.eval()
    return {"stage": "head_only" if frozen else mode,
            "finetune_epochs": 0 if frozen else epoch - warmup + 1,
            "stage_ready": mode == "head_only" or not frozen,
            "trainable_parameters": sum(p.numel() for p in model.parameters() if p.requires_grad)}


def make_optimizer_scheduler(backbone, head, settings, factor=1.0):
    torch, _ = torch_modules()
    parameters = [{"params": backbone, "lr": settings["learning_rate"] * factor},
                  {"params": head.parameters(), "lr": settings["head_learning_rate"] * factor}]
    name = settings.get("optimizer", "adamw")
    if name == "adamw":
        optimizer = torch.optim.AdamW(parameters, weight_decay=settings["weight_decay"])
    elif name == "sgd":
        optimizer = torch.optim.SGD(parameters, weight_decay=settings["weight_decay"],
                                    momentum=settings.get("momentum", .9))
    else:
        raise ValueError("training.optimizer must be adamw or sgd.")
    schedule = settings.get("scheduler", "cosine")
    if schedule == "cosine":
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=settings["epochs"])
    elif schedule == "plateau":
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, mode="max", factor=float(settings.get("scheduler_factor", .5)),
            patience=int(settings.get("scheduler_patience", 2)))
    elif schedule == "constant":
        scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda _: 1.)
    else:
        raise ValueError("training.scheduler must be cosine, plateau or constant.")
    return optimizer, scheduler


def train_one(name, seed, rows, cfg, out, init_checkpoint=None, progress_callback=None, stop_check=None):
    check_stop(stop_check)
    objective = cfg.get("search", {}).get("objective", "validation_ap")
    if objective not in VALIDATION_OBJECTIVES:
        raise ValueError(f"Unknown validation objective: {objective}.")
    if name == "patchcore":
        if objective != "validation_ap":
            raise ValueError("PatchCore supports validation_ap only in this release.")
        from .patchcore import fit_patchcore
        return fit_patchcore(seed, rows, cfg, out, init_checkpoint,
                             progress_callback=progress_callback, stop_check=stop_check)
    from .policy import metrics
    torch, _ = torch_modules()
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    fingerprints = backend_fingerprints(name, seed, rows, cfg, init_checkpoint)
    last_path, best_path = out / "last.pt", out / "best.pt"
    previous_best_path = out / "previous_best.pt"
    resumed = None
    if last_path.is_file():
        resumed = torch.load(last_path, map_location="cpu", weights_only=True)
        if any(resumed.get(key) != value for key, value in fingerprints.items()):
            raise ValueError("Resume refused: configuration or dataset fingerprint changed. Create a new run for updated training.")
        verify_checkpoint_configuration(resumed, cfg)
        if not best_path.is_file():
            raise ValueError("Resume checkpoint exists but best.pt is missing; restore the complete training package.")
        expected_best = resumed.get("best_checkpoint_sha256")
        if expected_best is None or expected_best != sha_file(best_path):
            if expected_best and previous_best_path.is_file() and sha_file(previous_best_path) == expected_best:
                recovery = best_path.with_suffix(".recovery.tmp")
                shutil.copy2(previous_best_path, recovery)
                _replace_file_with_retry(recovery, best_path)
                print("Recovered the best checkpoint belonging to the last completed epoch.", flush=True)
            else:
                raise ValueError("Resume refused: best.pt does not match the last completed epoch. "
                                 "Restore a consistent training package or start a new run from the desired best checkpoint.")
    seed_everything(seed)
    device = device_for(cfg)
    model, head = make_model(name, cfg, pretrained=cfg.get("pretrained", True) and init_checkpoint is None and resumed is None)
    if init_checkpoint and resumed is None:
        initial = torch.load(init_checkpoint, map_location="cpu", weights_only=True)
        verify_checkpoint_configuration(initial, cfg)
        if initial["task"] != cfg["task"] or initial["architecture"] != name or initial["class_to_index"] != LABELS:
            raise ValueError("Fine-tuning checkpoint task/architecture/labels mismatch.")
        model.load_state_dict(initial["state_dict"], strict=True)
    model.to(device)
    train = [row for row in rows if row["split"] == "train"]
    validation = [row for row in rows if row["split"] == "val"]
    if set(int(row["label"]) for row in validation) != {0, 1}:
        raise ValueError("Validation requires independent examples from both classes.")
    settings = cfg["training"]
    loss_weights, sampler, info = imbalance_setup(train, cfg, seed)
    write_json(out / "imbalance.json", info)
    generator = torch.Generator().manual_seed(seed)
    batches = loader(train, cfg, training=True, seed=seed, sampler=sampler, generator=generator)
    device_weights = loss_weights.to(device) if loss_weights is not None else None
    criterion = torch.nn.CrossEntropyLoss(weight=device_weights, reduction="sum")
    head_ids = {id(parameter) for parameter in head.parameters()}
    backbone = [parameter for parameter in model.parameters() if id(parameter) not in head_ids]
    factor = settings.get("fine_tune_lr_factor", .2) if init_checkpoint else 1.0
    optimizer, scheduler = make_optimizer_scheduler(backbone, head, settings, factor)
    amp = settings.get("amp", True) and device.type == "cuda"
    scaler = torch.amp.GradScaler("cuda", enabled=amp)
    best, stale, history, start_epoch, finished = (-float("inf"), -float("inf")), 0, [], 0, False
    best_ap = -float("inf")
    best_epoch = 0
    if resumed is not None:
        model.load_state_dict(resumed["state_dict"], strict=True)
        optimizer.load_state_dict(resumed["optimizer_state_dict"])
        scheduler.load_state_dict(resumed["scheduler_state_dict"])
        # A disabled CPU scaler legitimately has an empty state; device transfer
        # starts a new scale if AMP becomes available. All model/optimizer state remains.
        if amp and resumed["scaler_state_dict"]:
            scaler.load_state_dict(resumed["scaler_state_dict"])
        best, stale, history = tuple(resumed["best_key"]), resumed["stale_epochs"], resumed["history"]
        start_epoch, finished = resumed["epoch"], resumed.get("training_finished", False)
        best_epoch = resumed.get("best_epoch", 0)
        best_ap = float(resumed.get("best_val_pr_auc_bad", history[best_epoch - 1]["val_pr_auc_bad"]
                                  if best_epoch and history else -float("inf")))
        restore_rng(resumed["rng_state"], generator, sampler)
        print(f"Resuming {out.name} after completed epoch {start_epoch} on {device}.", flush=True)
    started = time.perf_counter()
    telemetry_session = uuid.uuid4().hex
    for epoch in range(start_epoch, settings["epochs"]):
        check_stop(stop_check)
        if finished:
            break
        epoch_start = time.perf_counter()
        stage = configure_training_stage(model, head, name, settings, epoch, bool(init_checkpoint))
        optimizer.zero_grad(set_to_none=True)
        total_loss, total_denominator, window_denominator = 0.0, 0.0, 0.0
        accumulation = int(settings["accumulation_steps"])
        telemetry_every = max(1, int(settings.get("telemetry_every", 25)))
        window_start, window_images, window_batches, optimizer_steps = time.perf_counter(), 0, 0, 0
        for step, (inputs, labels) in enumerate(batches):
            check_stop(stop_check)
            inputs, labels = inputs.to(device, non_blocking=True), labels.to(device, non_blocking=True)
            with autocast_context(device, amp):
                logits = model(inputs)
                loss = criterion(logits, labels)
            if not torch.isfinite(loss):
                raise RuntimeError("Nonfinite training loss. Inspect data, reduce learning rates or disable AMP.")
            denominator = len(labels)
            scaler.scale(loss).backward()
            window_denominator += denominator
            if (step + 1) % accumulation == 0 or step + 1 == len(batches):
                scaler.unscale_(optimizer)
                for parameter in model.parameters():
                    if parameter.grad is not None:
                        parameter.grad.div_(window_denominator)
                clip = float(settings.get("gradient_clip", 5.0))
                if clip > 0:
                    torch.nn.utils.clip_grad_norm_(model.parameters(), clip)
                scaler.step(optimizer)
                scaler.update()
                optimizer_steps += 1
                optimizer.zero_grad(set_to_none=True)
                window_denominator = 0.0
            total_loss += loss.item()
            total_denominator += denominator
            window_images += len(labels)
            window_batches += 1
            if (step + 1) % telemetry_every == 0 or step + 1 == len(batches):
                if device.type == "cuda":
                    torch.cuda.synchronize(device)
                seconds = max(time.perf_counter() - window_start, 1e-9)
                snapshot = {"session": telemetry_session, "epoch": epoch + 1, "batch": step + 1, "batches": len(batches),
                            "window_batches": window_batches, "window_images": window_images,
                            "window_seconds": seconds, "images_per_second": window_images / seconds,
                            "mean_batch_seconds": seconds / window_batches,
                            "train_loss_so_far": total_loss / total_denominator,
                            "optimizer_steps": optimizer_steps, **resource_sample(device)}
                append_telemetry(out / "telemetry.csv", snapshot)
                write_json(out / "progress.json", dict(snapshot, status="training", current_epoch=epoch + 1,
                           total_epochs=settings["epochs"], **stage, device=str(device),
                           elapsed_seconds=sum(item["seconds"] for item in history) + time.perf_counter() - epoch_start))
                window_start, window_images, window_batches = time.perf_counter(), 0, 0
            if (step + 1) % 50 == 0:
                print(f"{out.name}: epoch {epoch + 1}/{settings['epochs']}, batch {step + 1}/{len(batches)}", flush=True)
        check_stop(stop_check)
        scores, logits, _ = predict_model(model, validation, cfg, device, stop_check=stop_check)
        labels = [int(row["label"]) for row in validation]
        val_loss = torch.nn.functional.cross_entropy(logits, torch.tensor(labels)).item()
        values = metrics(labels, scores, .5)
        objective_value = float(values[VALIDATION_OBJECTIVES[objective]])
        key = (objective_value, -val_loss)
        if not np.isfinite(key).all():
            raise RuntimeError("Nonfinite validation metrics; inspect class counts and predictions.")
        history.append({"epoch": epoch + 1, "train_loss": total_loss / total_denominator,
                        "val_loss": val_loss, "val_pr_auc_bad": values["pr_auc_bad"],
                        "val_roc_auc_bad": values["roc_auc_bad"],
                        "val_balanced_accuracy": values["balanced_accuracy"],
                        "objective_metric": objective, "objective_value": objective_value,
                        "val_bad_recall_at_0_5": values["bad_recall"],
                        "backbone_lr": optimizer.param_groups[0]["lr"],
                        "head_lr": optimizer.param_groups[1]["lr"], "stage": stage["stage"],
                        "finetune_epochs": stage["finetune_epochs"],
                        "seconds": time.perf_counter() - epoch_start})
        print(f"{out.name}: epoch {epoch + 1}, {objective}={objective_value:.4f}, "
              f"validation AP(bad)={values['pr_auc_bad']:.4f}, loss={val_loss:.4f}", flush=True)
        if key > best:
            best, stale = key, 0
            best_epoch = epoch + 1
            best_ap = float(values["pr_auc_bad"])
            # Retain the previous committed best until last.pt atomically commits
            # this epoch. A crash between these writes can then roll back safely.
            if best_path.is_file():
                backup = previous_best_path.with_suffix(".pt.tmp")
                shutil.copy2(best_path, backup)
                _replace_file_with_retry(backup, previous_best_path)
            save_checkpoint(best_path, model, cfg, name, seed, epoch + 1, init_checkpoint, fingerprints)
        else:
            stale += 1
        if settings.get("scheduler", "cosine") == "plateau":
            scheduler.step(key[0])
        else:
            scheduler.step()
        minimum_phase_epochs = int(settings.get("min_finetune_epochs", 1))
        phase_epochs = epoch + 1 if settings.get("mode", "full") == "head_only" else stage["finetune_epochs"]
        early_stop_ready = stage["stage_ready"] and phase_epochs >= minimum_phase_epochs
        finished = epoch + 1 >= settings["epochs"] or (stale >= settings["patience"] and early_stop_ready)
        extra = dict(fingerprints, optimizer_state_dict=optimizer.state_dict(),
                     scheduler_state_dict=scheduler.state_dict(), scaler_state_dict=scaler.state_dict(),
                     best_key=list(best), best_epoch=best_epoch, stale_epochs=stale, history=history,
                     objective_metric=objective, best_objective_value=best[0], best_val_pr_auc_bad=best_ap,
                     rng_state=capture_rng(generator, sampler), training_finished=finished,
                     best_checkpoint_sha256=sha_file(best_path),
                     execution_device=str(device))
        save_checkpoint(last_path, model, cfg, name, seed, epoch + 1, init_checkpoint, extra)
        previous_best_path.unlink(missing_ok=True)
        write_csv(out / "history.csv", history)
        progress = {"status": "completed" if finished else "training",
                   "current_epoch": epoch + 1, "total_epochs": settings["epochs"],
                   "epoch": epoch + 1, **stage,
                   "best_epoch": best_epoch, "train_loss": history[-1]["train_loss"],
                   "val_loss": val_loss, "val_pr_auc_bad": float(values["pr_auc_bad"]),
                   "val_roc_auc_bad": float(values["roc_auc_bad"]),
                   "val_balanced_accuracy": float(values["balanced_accuracy"]),
                   "objective_metric": objective, "objective_value": objective_value,
                   "best_objective_value": best[0],
                   "best_val_pr_auc_bad": best_ap, "elapsed_seconds": sum(item["seconds"] for item in history),
                   "device": str(device), **resource_sample(device)}
        write_json(out / "progress.json", progress)
        if progress_callback is not None:
            progress_callback(progress)
    check_stop(stop_check)
    write_json(out / "completed.json", dict(fingerprints, checkpoint_sha256=sha_file(best_path),
               best_val_pr_auc_bad=best_ap, objective_metric=objective, best_objective_value=best[0],
               objective_value=best[0], epochs_ran=len(history), kind="supervised",
               score_type="bad_probability_uncalibrated", resumed_after_epoch=start_epoch,
               current_process_seconds=time.perf_counter() - started))
    del model, optimizer, scaler
    if device.type == "cuda":
        torch.cuda.empty_cache()
    return best_path
