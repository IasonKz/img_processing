# Training and Results

## Model

The pilot trains one small U-Net from scratch. It is a convolutional encoder/decoder: the encoder learns local appearance at progressively coarser scales, and the decoder combines those features with higher-resolution features to predict a class for each pixel. The default first feature width is 16 channels. There are three output classes: Background, Inner defect, and Outer defect.

No pretrained weights or torchvision models are used. Training and prediction require PyTorch; annotation and classical proposals do not.

The model uses three encoder/decoder levels and GroupNorm. Training combines weighted cross-entropy with half-weight foreground soft Dice loss. Class weights are estimated from training pixels and capped to limit extreme weights. AdamW performs optimization, with learning-rate reduction on a validation plateau and gradient clipping. Optional training augmentation applies matched 90-degree rotations and horizontal flips to images and masks.

## Prepare a usable dataset

Only explicitly approved revisions become training examples. Include both defect classes and representative clean images. Five approved images is the default minimum enforced by the software, but such a small dataset is appropriate only to check that the workflow runs. The number and diversity needed for useful performance depend on the defects, appearance variability, and consistency of annotations.

Configure physical-unit grouping before import if multiple images belong to a unit. The deterministic train/validation split keeps whole groups together. Duplicate copies are not extra independent examples. Inspect class support as well as image counts in both splits.

Training uses a frozen copy of the approved dataset inside the run directory. Annotation changes made later do not change that run's recorded data.

## Resolution

The annotation masks use native image dimensions. For training, RGB images are scaled with preserved aspect ratio and centered in a square of `training.image_size`. Masks use nearest-neighbor resizing; padding has ignore value `255`, so it does not contribute to the loss or metrics. RGB values are mapped to `[0, 1]`.

The default model input is 512 × 512. Larger inputs, including sizes above 600 × 600, may be used when memory permits. Thin or small defects can disappear at reduced resolution. Inspect the preprocessing warnings and class support, and increase the configured size when needed. A native-size predicted mask does not imply that the model analyzed every original pixel at native resolution.

## Train

```bash
python segmentation.py train --config project.yaml
```

Each invocation creates a new run below `output_dir/runs/`. The configuration, approved dataset snapshot, split, training history, checkpoint, and report are retained with that run. The maximum epoch count and early-stopping patience are configurable.

| Run artifact | Contents |
| --- | --- |
| `config.json` | Resolved experiment configuration |
| `dataset/` | Frozen approved image/mask copies and `dataset.json` |
| `split.json` | Physical-unit train/validation assignments and class support |
| `preprocessing_report.json` | Model-input dimensions and defect components lost through resizing |
| `history.csv` | Epoch training and validation measurements |
| `model_state.json` | Current/completed status, settings, data fingerprint, warnings, and performance |
| `report.html` | Readable run report |
| `best.pt` | Model checkpoint selected by validation performance |
| `last.pt` | Most recently completed epoch checkpoint |
| `validation/` | Metrics, per-image CSV, predicted masks, prediction overlays, and reference overlays |
| `comparison.json` | Previous/current measurements on the same development validation set, for fine-tuning runs |

Checkpoint selection uses foreground mean IoU measured after predictions are restored to native image geometry. When validation contains no target defects, selection falls back to validation loss and reports the missing defect evidence. That fallback is a functional pilot path, not a meaningful assessment of defect recovery.

Use `device: cpu` for a portable first experiment. Set `device: cuda` only with a working CUDA-capable Torch installation. `auto` selects CUDA when available and otherwise CPU. This version does not use Apple's MPS backend.

## Interpret validation

For each defect class, the report provides pixel-level overlap metrics:

- **IoU:** intersection divided by union of predicted and reference defect pixels.
- **Dice:** twice the intersection divided by the sum of predicted and reference pixel counts.
- **Recall:** fraction of reference defect pixels recovered.
- **Precision:** fraction of predicted defect pixels that match the reference.

The foreground mean summarizes Inner and Outer. Read it together with each class's reference pixel count and individual score. A class absent from both reference and predictions is undefined rather than a perfect score. A class absent from the reference but spuriously predicted can have zero overlap while its recall is undefined.

Pixel accuracy includes background and can appear high even when important defects are missed. Review validation images and masks alongside the numeric metrics. These are segmentation measurements, not part-level false-negative rates or a certified pass/fail decision.

The validation split is used for checkpoint selection and development. Repeatedly adjusting a model based on it makes it part of the development process. A later acceptance assessment needs independent units that were not used for training, checkpoint selection, or tuning.

## Add new annotations and fine-tune

For new source files, first run `python segmentation.py init --config project.yaml` to add them to the existing working project. Annotate and approve the new images or corrections. Start a new run with a compatible earlier checkpoint:

```bash
python segmentation.py train --config project.yaml --init-checkpoint outputs/runs/PREVIOUS_RUN/best.pt
```

This initializes a new training experiment from the earlier model. It is not an exact continuation of the old optimizer/epoch state. Fine-tuning requires the same input size, model width, and grouping rule. Existing groups retain their historical train/validation roles; new groups are assigned without moving old validation units into training. The earlier model is evaluated on the new run's current validation set so that `comparison.json` compares the two models on the same images.

Retain the previous run and its dataset snapshot. Adding data can change the validation composition and class mix, so scores from different run reports are not automatically comparable. The shared-set comparison is still development validation and does not replace an independent acceptance test.

The pilot does not automatically replace a deployed model or select among several model families. Keep the checkpoint you choose explicitly and record the data and settings used.

## Predict new images

```bash
python segmentation.py predict --checkpoint outputs/runs/RUN_ID/best.pt --input data/new_top --output outputs/predictions_v1 --device cpu
```

Use a new or empty output directory separate from the input tree. The checkpoint carries the class mapping, model architecture, and training input size, so prediction uses the corresponding preprocessing.

| Output | Contents |
| --- | --- |
| `masks/` | Single-channel class-index PNGs at native source dimensions |
| `overlays/` | RGB image previews with colored defect pixels |
| `predictions.csv` | Source image, native dimensions, Inner/Outer pixel counts, and output paths |
| `summary.json` | Checkpoint fingerprint, input size, device, timing, processing counts, and decoding failures |

The model computes three class scores per pixel. Softmax probabilities are unpadded and resized to native geometry, then the highest-probability class is selected. The result identifies defect pixels; it does not make an automatic part-acceptance decision.

The output preserves relative subfolder names and adds output suffixes to avoid collisions between source files with different extensions. Prediction does not alter source images and does not approve the predicted masks as annotation ground truth.

## Transfer to another computer

For annotation, copy the application, the complete working project, and its configuration; update paths and install the core dependencies. Keep original acquisition files separately.

For inference, copy the application and the selected `.pt` checkpoint, then install the training dependencies. Prediction can run on CPU even when training used CUDA. A self-contained ONNX runtime package is outside this pilot's scope.

For reproducibility, retain the complete training run including its dataset snapshot, configuration, split, and reports. Checkpoint files alone do not preserve all annotation history.
