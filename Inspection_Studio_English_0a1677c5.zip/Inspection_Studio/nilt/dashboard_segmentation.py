"""Shared ROI crop annotation workspaces and segmentation dataset handoffs."""
from collections import Counter
from pathlib import Path
import re

from .common import read_json, write_json, sha_file
from .roi.datasets import DEFAULT_KINDS


class SegmentationDashboardMixin:
    def _segmentation_export(self, side, export_id):
        self._roi_side({"side": side})
        if not isinstance(export_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]+", export_id):
            raise ValueError("Choose a recorded ROI export.")
        root = (self.roi_root / side / "exports").resolve()
        directory = (root / export_id).resolve()
        if not directory.is_relative_to(root) or directory == root or (directory / "INCOMPLETE.json").exists():
            raise ValueError("Choose a completed ROI export from this project.")
        manifest = read_json(directory / "manifest.json")
        if (manifest.get("schema") != "roi_dataset_snapshot.v1" or manifest.get("side") != side
                or manifest.get("export_id") != export_id):
            raise ValueError("ROI export identity differs from the selected segmentation view.")
        return directory, manifest

    def segmentation_catalog(self, data):
        side = self._roi_side(data)
        exports = self.roi_project({"side": side}).state().get("exports", [])
        crops, localizers = [], []
        for export in reversed(exports):
            export_id = export.get("export_id") or export.get("id") or Path(export["path"]).name
            try:
                directory, manifest = self._segmentation_export(side, export_id)
                rows = read_json(directory / "crops_manifest.json").get("samples", [])
            except (OSError, ValueError, KeyError):
                continue
            for kind in DEFAULT_KINDS[side]:
                samples = [row for row in rows if row.get("kind") == kind]
                if not samples:
                    continue
                prefix = f"/segmentation/{side}/roi/{kind}/{export_id}"
                root = self.config.parent / "segmentation" / side / "roi" / kind / export_id
                crops.append({"export_id": export_id, "kind": kind, "count": len(samples),
                              "splits": dict(Counter(row["split"] for row in samples)),
                              "prefix": prefix, "context": f"{side}:roi:{kind}:{export_id}",
                              "prepared": (root / "project.yaml").is_file()})
            if manifest.get("segmentation"):
                localizers.append({"export_id": export_id, **manifest["segmentation"]})
        return {"side": side, "whole_image_available": side == "top", "crops": crops,
                "localizers": localizers, "experiments": self.roi_state({"side": side})["experiments"],
                "job": self.roi_job({"side": side})["job"]}

    def segmentation_prepare_crops(self, data):
        from .segmentation_bridge import workspace
        import yaml
        side, kind = self._roi_side(data), data.get("kind")
        if kind not in DEFAULT_KINDS[side]:
            raise ValueError("Choose an ROI kind supported by this view.")
        with self.lock:
            self._idle_for_dataset_edit()
            if self.roi_busy():
                raise ValueError("Wait for the active ROI operation before opening its crop dataset.")
            directory, export = self._segmentation_export(side, data.get("export_id"))
            export_id = export["export_id"]
            source = directory / "crops" / kind
            rows = [row for row in read_json(directory / "crops_manifest.json")["samples"] if row["kind"] == kind]
            if not rows:
                raise ValueError("This export contains no crops for the selected ROI kind.")
            samples = []
            for row in rows:
                path = (directory / row["path"]).resolve()
                if not path.is_relative_to(source.resolve()) or not path.is_file():
                    raise ValueError("ROI crop is missing or outside its recorded export.")
                digest = sha_file(path)
                if row.get("sha256") and row["sha256"] != digest:
                    raise ValueError("Exported ROI crop pixels changed. Create a new export.")
                samples.append({**row, "relative_path": path.relative_to(source.resolve()).as_posix(), "sha256": digest})
            root = self.config.parent / "segmentation" / side / "roi" / kind / export_id
            root.mkdir(parents=True, exist_ok=True)
            lineage = {"schema": "roi_crop_annotation_source.v1", "side": side, "kind": kind,
                       "export_id": export_id, "source_manifest": str(directory / "crops_manifest.json"),
                       "samples": samples}
            source_manifest = root / "source.json"
            if source_manifest.exists():
                if read_json(source_manifest) != lineage:
                    raise ValueError("Crop lineage changed since this annotation project was created. Make a new ROI export.")
            else:
                write_json(source_manifest, lineage)
            cfg_path = root / "project.yaml"
            if not cfg_path.exists():
                cfg_path.write_text(yaml.safe_dump({"name": f"{side}_{kind}_defects", "task": side,
                    "input_dir": str(source), "project_dir": str(root / "annotations"),
                    "output_dir": str(root / "results"), "roi_source": {
                        "manifest": str(source_manifest), "sha256": sha_file(source_manifest)},
                    "training": {"require_both_defect_classes": False}}), encoding="utf-8")
            server = workspace(self, side, 0, kind=kind, export_id=export_id)
            imported = {alias for item in server.project.items() for alias in item['source_aliases']}
            if imported != {row['relative_path'] for row in samples}:
                server.jobs.start("import", {})
            return {"side": side, "kind": kind, "export_id": export_id,
                    "prefix": f"/segmentation/{side}/roi/{kind}/{export_id}",
                    "context": f"{side}:roi:{kind}:{export_id}", "job": server.jobs.current(),
                    "session_token": server.session_token,
                    "project": server.cfg["project_dir"], "input": str(source), "count": len(samples)}
