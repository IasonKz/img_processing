# Start here — Inspection Studio 6.1

## 1. Extract into a new folder

Use a short local path such as `C:\Users\YOUR_NAME\InspectionStudio6`. It must contain `inspection.py`, `project.yaml`, `Setup.cmd`, and `Start.cmd`. Keep the previous release and its environment. Do not overwrite previous results or add older patch files.

## 2. Set up once on Windows

Install Python **3.12, 64-bit**, then open PowerShell in the new project folder. Run **one** setup route:

```powershell
# CPU laptop
.\Setup.cmd -Device cpu
```

```powershell
# NVIDIA GPU
.\Setup.cmd -Device cuda
```

```powershell
# Intel/AMD Windows GPU — experimental DirectML environment
.\Setup-DirectML.cmd
```

DirectML has its own compatible torch/torchvision dependencies. Do not install `torch-directml` over a working CPU/CUDA environment. Setup records the interpreter used by this project; a visible `(venv)` prompt is unnecessary. See [INSTALLATION.md](docs/INSTALLATION.md).

For Intel laptop **training**, select **Laptop · Intel iGPU (experimental)** after launch. The CPU Laptop preset stays unchanged.

Launch and reopen with:

```powershell
.\Start.cmd
```

Keep the terminal open. The printed address is normally `http://127.0.0.1:8765`. The NILT terminal animation indicates that the dashboard is open, not that training has completed. See [TERMINAL_V6.md](docs/TERMINAL_V6.md) to disable it or reduce its refresh rate.

On Linux, follow [INSTALLATION_LINUX.md](docs/INSTALLATION_LINUX.md), then run `bash Start.sh`. DirectML setup is Windows-only.

## 3. Preview or configure data

The GUI opens without images. Leave the sample paths unchanged for a preview; audit and training require real inputs.

The first tab is **Preprocessing / Data processing**. For evaluation CSVs
and their source captures, enter the CSV paths and a new output folder there.
Run **Check CSV references**, then **Prepare dataset**. Review the counts and
crop overlays, then choose **Use prepared dataset → setup** to save the prepared
task folders in a configuration copy. See [dashboard preprocessing](docs/DASHBOARD_PREPROCESSING.md).
If the good/bad folders are already prepared, go directly to **Dataset & setup**.

For training, set the existing path in `project.yaml`:

```yaml
tasks:
  vig:
    enabled: true
    dataset_root: 'D:/InspectionData/vig'
```

That folder must contain `good` and `bad`. Configure `top` or `bottom` separately when required. Keep results, predictions, and review exports outside the source dataset.

Eight-bit PNG and unsigned 16-bit PNG/TIFF inputs are supported. Spatial resolution and intensity bit depth are different controls: native padding preserves dimensions; 16-bit decoding preserves intensity detail. The default 16-bit mapping is `0` to `65535`. Do not choose `4095` or another sensor white level without confirming the source encoding. Previously processed 8-bit images continue to work.

## 4. Run a first search

1. Select a small model list in **Train & search**.
2. Missing official pretrained weights may download automatically on every profile. Alternatively use **Download pretrained weights** explicitly. **Check installation** only inspects local resources.
3. Audit the data and read label, duplicate, group, intensity, and size errors before training.
4. Use profile defaults or **Custom Optuna**. Choose the execution device, total seconds, trial count, sampler, ranges, pruning, and timeouts.
5. Validate the contract, start one search, and monitor the operation log and charts.

Budgets of 2, 6, and 12 hours are editable preset suggestions. The extended
`workstation_50h` profile defaults to 48 hours and enforces a cumulative maximum
of 50 hours; the other profiles retain editable positive finite budgets.
For example, `86400` seconds is 24 hours. The device can be selected independently
of the preset. A budget is shared across the selected architectures and
finalization; it does not guarantee that every requested trial finishes.

Choose an evolutionary sampler only with enough trials for its configured population and generations. A large population in a short CPU run may receive no opportunity to evolve. Read [SAMPLERS_V6.md](docs/SAMPLERS_V6.md) for method compatibility and optional dependencies.

## 5. Compare models and try review decisions

Compare completed candidates on the recorded selection data. Use AP/ROC curves, confusion matrices, bad escapes, good rejects, and review workload together. Parameter radars compare search settings; they do not make a larger setting automatically better.

In **Decision explorer**, use two thresholds for an optional review band. For bad score `s`, lower threshold `L`, and upper threshold `U`:

- `s < L`: good.
- `L <= s < U`: review.
- `s >= U`: bad.

In **Decision lab**, multiple distinct candidates can additionally send disagreement or excessive score dispersion to review. Such dispersion is a heuristic, not a calibrated probability of error. Guarded cascades must run every selected source, so early exit no longer saves inference work.

Classify with image copies enabled, then open **Image review**. A review flag is not a new training label. Record a human good/bad judgment explicitly; original labels remain separate.

## 6. Pause, cancel, and restart

Use **Pause** for a resumable stop. Use **Cancel search** to stop the search and preserve available unfinished model state. Wait for the worker to acknowledge the request before shutting down or changing files. Partial model predictions are diagnostic and always require human review; the checkpoint is not promoted to a completed trial automatically. A power loss or forced process kill can lose work after the last committed checkpoint.

Closing a browser tab does not stop training. Ctrl+C closes the dashboard server; previously launched workers can remain active. Reopen with `Start.cmd`, then inspect the recorded job state. Resume retains the original configuration and remaining budget. Changing model families, sampler, spaces, intensity mapping, or data creates a new experiment.

Open **Quality & documentation** to combine recorded training evidence with historical tray inspections and export HTML/CSV/JSON reports. See [WHATS_NEW_6_1.md](WHATS_NEW_6_1.md).

Read [MIGRATION_V6.md](MIGRATION_V6.md) before bringing older experiments into this release.
