"""Synthetic correctness checks, not qualification of real inspection accuracy."""
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np
from PIL import Image, ImageDraw

from nilt.roi.learning import inspect_dataset, train, predict, evaluate, _loss, localize_with_model


HAS_TORCH = importlib.util.find_spec("torch") is not None
HAS_CV = importlib.util.find_spec("cv2") is not None


def make_dataset(root):
    root = Path(root)
    root.mkdir(parents=True)
    samples = []
    for index, split in enumerate(("train", "val", "test")):
        image = Image.new("RGB", (40, 32), "black")
        ImageDraw.Draw(image).rectangle((8, 8, 30, 24), fill="white")
        image.save(root / f"image{index}.png")
        masks, valid_masks = {}, {}
        for channel, rectangle in (("inner_area", (8, 8, 30, 24)), ("label", (12, 10, 20, 14))):
            mask = Image.new("L", image.size, 0)
            ImageDraw.Draw(mask).rectangle(rectangle, fill=255)
            mask.save(root / f"{channel}{index}.png")
            valid = Image.new("L", image.size, 255)
            ImageDraw.Draw(valid).rectangle((0, 0, 3, 3), fill=0)
            valid.save(root / f"valid_{channel}{index}.png")
            masks[channel] = f"{channel}{index}.png"
            valid_masks[channel] = f"valid_{channel}{index}.png"
        samples.append({"image_id": str(index), "unit_id": f"unit{index}", "split": split,
                        "image_path": f"image{index}.png", "masks": masks, "valid_masks": valid_masks})
    manifest = {"schema": "roi_segmentation_dataset.v1", "side": "top", "template_version": 1,
                "channels": ["inner_area", "label"], "samples": samples}
    (root / "manifest.json").write_text(json.dumps(manifest))
    return manifest


class DatasetChecks(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.data = make_dataset(self.root / "data")

    def tearDown(self):
        self.temp.cleanup()

    def test_unit_leakage_is_rejected_before_training(self):
        self.data["samples"][1]["unit_id"] = "unit0"
        (self.root / "data/manifest.json").write_text(json.dumps(self.data))
        with self.assertRaisesRegex(ValueError, "Unit leakage"):
            inspect_dataset(self.root / "data")

    def test_valid_masks_are_required_not_assumed_background(self):
        del self.data["samples"][0]["valid_masks"]
        (self.root / "data/manifest.json").write_text(json.dumps(self.data))
        with self.assertRaisesRegex(ValueError, "valid_masks"):
            inspect_dataset(self.root / "data")

    def test_unreviewed_expected_geometry_cannot_train_all_background(self):
        for path in self.data["samples"][0]["valid_masks"].values():
            Image.new("L", (40, 32), 0).save(self.root / "data" / path)
        with self.assertRaisesRegex(ValueError, "No confirmed positive"):
            train(self.root / "data", self.root / "model", {"epochs": 1})
        status = json.loads((self.root / "model/status.json").read_text())
        self.assertEqual(status["status"], "failed")


@unittest.skipUnless(HAS_TORCH, "Optional PyTorch is not installed")
class TorchChecks(unittest.TestCase):
    def test_ignored_pixels_do_not_change_loss(self):
        import torch
        logits = torch.zeros((1, 2, 8, 8))
        masks = torch.ones_like(logits)
        valid = torch.ones_like(logits)
        valid[:, :, :4] = 0
        original = _loss(torch, logits, masks, valid)
        logits[:, :, :4] = 100
        masks[:, :, :4] = 0
        self.assertAlmostEqual(float(original), float(_loss(torch, logits, masks, valid)), places=6)

    def test_local_train_predict_frozen_test_roundtrip(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            make_dataset(root / "dataset")
            # A test image can be unreadable throughout training: it is not loaded.
            test_path = root / "dataset/image2.png"
            original_test = test_path.read_bytes()
            test_path.write_bytes(b"test must never be loaded for fitting")
            status = train(root / "dataset", root / "model",
                           {"epochs": 1, "batch_size": 1, "image_size": 32, "width": 4, "device": "cpu"})
            self.assertEqual(status["status"], "completed")
            self.assertTrue((root / "model/best.pt").is_file())
            test_path.write_bytes(original_test)
            prediction = predict(test_path, root / "model")
            self.assertEqual(prediction["probabilities"].shape, (2, 32, 40))
            self.assertTrue(np.isfinite(prediction["probabilities"]).all())
            checkpoint = (root / "model/best.pt").read_bytes()
            config = (root / "model/model.json").read_bytes()
            evaluation = evaluate(root / "dataset", root / "model", root / "test")
            self.assertTrue(evaluation["frozen"])
            self.assertEqual(evaluation["samples"], 1)
            self.assertEqual(evaluation["units"], 1)
            self.assertEqual(evaluation["metrics"]["inner_area"]["ignored_pixels"], 16)
            self.assertEqual(checkpoint, (root / "model/best.pt").read_bytes())
            self.assertEqual(config, (root / "model/model.json").read_bytes())
            data = json.loads((root / "dataset/manifest.json").read_text())
            data["samples"] = [data["samples"][2]]
            data["samples"][0]["unit_id"] = "unit0"
            (root / "dataset/manifest.json").write_text(json.dumps(data))
            with self.assertRaisesRegex(ValueError, "Test units overlap"):
                evaluate(root / "dataset", root / "model", root / "leaky-test")

    def test_stop_flag(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            make_dataset(root / "dataset")
            (root / "model").mkdir()
            (root / "model/STOP").touch()
            result = train(root / "dataset", root / "model", {"epochs": 2, "image_size": 32, "width": 4})
            self.assertEqual(result["status"], "stopped")
            self.assertFalse((root / "model/best.pt").exists())


@unittest.skipUnless(HAS_CV, "OpenCV is not installed")
class ModelGeometryChecks(unittest.TestCase):
    def test_model_missing_pin_preserves_expected_roi_and_canonical_ids(self):
        import cv2
        from nilt.roi.geometry import default_template, template_to_rois
        from nilt.roi.localization import _initial
        template = default_template("bottom")
        template["starter"] = False
        size = [240, 240]
        transform = _initial(template["reference_size"], size, 1)
        rows = template_to_rois(template, size, transform)
        classes = ["pins", "triangle", "square"]
        masks = {c: np.zeros((240, 240), np.uint8) for c in classes}
        for roi in rows:
            if roi["id"] == "pin_r2_c3":
                continue
            pts = np.asarray(roi["points"])
            if roi["shape"] == "circle":
                cv2.circle(masks[roi["kind"]], np.rint(pts[0]).astype(int),
                           round(float(np.linalg.norm(pts[1] - pts[0]))), 1, -1)
            else:
                cv2.fillPoly(masks[roi["kind"]], [np.rint(pts).astype(np.int32)], 1)
        prediction = {"classes": classes, "masks": masks, "probabilities": np.stack([masks[c] * .99 for c in classes]),
                      "image_size": size, "config": {"schema": "roi_segmentation_model.v1", "side": "bottom", "template_version": 1}}
        with patch("nilt.roi.learning.predict", return_value=prediction):
            result = localize_with_model("unused.png", template, "model", method="segmentation")
        self.assertEqual(len(result["rois"]), 18)
        self.assertAlmostEqual(result["orientation_degrees"], 90, delta=3)
        missing = next(r for r in result["rois"] if r["id"] == "pin_r2_c3")
        self.assertEqual(missing["source"], "inferred")
        self.assertIsNone(missing["observed_points"])
        self.assertEqual(missing["points"], missing["expected_points"])
        observed = next(r for r in result["rois"] if r["id"] == "pin_r1_c1")
        self.assertIsNotNone(observed["observed_points"])
        self.assertEqual(observed["points"], observed["expected_points"])


if __name__ == "__main__":
    unittest.main()
