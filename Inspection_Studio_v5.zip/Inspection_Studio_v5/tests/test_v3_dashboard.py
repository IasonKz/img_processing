"""Operator UI contracts, local-file isolation and request authorization."""
from http.server import ThreadingHTTPServer
import json
from pathlib import Path
import tempfile
import threading
import unittest
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from nilt.dashboard import Dashboard, _safe_path, make_handler


class DashboardTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        (self.root / "data" / "vig").mkdir(parents=True)
        self.config = self.root / "project.yaml"
        self.config.write_text("schema_version: 3\npaths:\n  output_root: ./results\n  weights_root: ./weights\ntasks:\n  vig:\n    dataset_root: ./data/vig\n", encoding="utf-8")
        self.app = Dashboard(self.config)
        self.run = self.root / "results" / "vig" / "example"
        self.run.mkdir(parents=True)
        (self.run / "config.json").write_text(json.dumps({"task": "vig", "profile": "laptop"}))
        (self.run / "model_state.json").write_text('{"status":"PREPARED"}')

    def tearDown(self):
        self.temp.cleanup()

    def test_commands_are_argument_arrays_with_finite_profile_caps(self):
        command = self.app.command("search", {"task": "vig", "profile": "laptop", "hours": 2,
                                               "models": ["resnet18", "efficientnet_b0"]})
        self.assertIsInstance(command, list)
        self.assertEqual(command[command.index("--models") + 1:], ["resnet18", "efficientnet_b0"])
        for hours in (-1, float("inf"), float("nan")):
            with self.assertRaises(ValueError):
                self.app.command("search", {"models": ["resnet18"], "hours": hours})
        for action in ("rm", "evaluate", "activate", "download-weights"):
            with self.assertRaises(ValueError):
                self.app.command(action, {})

    def test_resume_uses_existing_search_contract(self):
        command = self.app.command("resume-search", {"run": str(self.run)})
        self.assertIn("search", command)
        self.assertIn("--run", command)
        self.assertNotIn("--config", command)

    def test_export_can_use_saved_manual_decision(self):
        decision = self.root / "decisions" / "v1" / "decision.json"
        decision.parent.mkdir(parents=True)
        decision.write_text('{"mode":"manual","threshold":0.7}')
        args = {"run": str(self.run), "output": str(self.root / "packages" / "new"),
                "decision": str(decision), "kind": "inference"}
        command = self.app.command("package", args)
        self.assertEqual(command[-2:], ["--decision", str(decision)])
        with self.assertRaises(ValueError):
            self.app.command("package", dict(args, kind="training"))

    def test_profile_model_defaults_come_from_configuration(self):
        self.app.raw["profiles"] = {"laptop": {"models": ["efficientnet_b0"]}}
        self.assertEqual(self.app.bootstrap()["profile_models"]["laptop"], ["efficientnet_b0"])

    def test_disabled_task_becomes_enabled_in_saved_configuration(self):
        self.app.raw["tasks"]["vig"]["enabled"] = False
        self.app.save_config({"task": "vig", "dataset": str(self.root / "data" / "vig")})
        self.assertTrue(self.app.bootstrap()["task_enabled"]["vig"])

    def test_saving_paths_preserves_source_and_creates_snapshot(self):
        original = self.config.read_bytes()
        boot = self.app.save_config({"task": "vig", "dataset": str(self.root / "data" / "vig"),
                                     "output": str(self.root / "new_results"), "weights": str(self.root / "weights")})
        self.assertEqual(self.config.read_bytes(), original)
        self.assertNotEqual(Path(boot["config"]), self.config)
        self.assertTrue(Path(boot["config"]).is_file())
        self.assertIn("new_results", boot["paths"]["output"])

    def test_results_cannot_overlap_dataset(self):
        with self.assertRaises(ValueError):
            self.app.save_config({"task": "vig", "dataset": str(self.root / "data" / "vig"),
                                  "output": str(self.root / "data" / "vig" / "results")})

    def test_live_batch_progress_exists_before_first_epoch(self):
        trial = self.run / "search" / "resnet18" / "trial_00000"
        trial.mkdir(parents=True)
        (trial / "progress.json").write_text('{"batch":25,"batches":100,"current_epoch":1,"ram_bytes":1024}')
        # The reserved final-test marker must not be surfaced by ordinary reads.
        (self.run / "final_test_summary.json").write_text('{"secret_test_accuracy":0.9}')
        info = self.app.run_info(str(self.run))
        self.assertEqual(info["histories"][0]["history"], [])
        self.assertEqual(info["histories"][0]["progress"]["batch"], 25)
        self.assertNotIn("secret_test_accuracy", json.dumps(info))

    def test_confirmation_history_and_missing_metrics_are_preserved(self):
        confirmation = self.run / "search" / "confirmations" / "resnet18_trial0" / "seed_123"
        confirmation.mkdir(parents=True)
        (confirmation / "progress.json").write_text('{"current_epoch":1,"ram_bytes":1024,"vram_bytes":null}')
        (confirmation / "history.csv").write_text("epoch,val_pr_auc_bad,train_loss\n1,0.62,0.45\n")
        info = self.app.run_info(str(self.run))
        self.assertEqual(len(info["histories"]), 1)
        recorded = info["histories"][0]
        self.assertEqual(recorded["name"], "search/confirmations/resnet18_trial0/seed_123")
        self.assertEqual(recorded["history"][0]["val_pr_auc_bad"], "0.62")
        self.assertIsNone(recorded["progress"]["vram_bytes"])
        self.assertNotIn("val_loss", recorded["history"][0])

    def test_path_and_symlink_escape_rejected(self):
        with self.assertRaises(ValueError):
            _safe_path(self.root / "results", "../../outside.png")
        with self.assertRaises(ValueError):
            self.app.checked_output(self.root / "data" / "vig")
        secret = self.root / "outside"
        secret.mkdir()
        link = self.run / "linked"
        try:
            link.symlink_to(secret, target_is_directory=True)
        except OSError:
            self.skipTest("This Windows account cannot create symlinks")
        with self.assertRaises(ValueError):
            _safe_path(self.root / "results", "vig/example/linked/image.png")

    def test_pause_is_cooperative_and_run_scoped(self):
        self.app.jobs.append({"status": "running", "action": "search", "run": str(self.run)})
        result = self.app.pause()
        self.assertIn("Pause requested", result["message"])
        signal = json.loads((self.run / "control.json").read_text())
        self.assertTrue(signal["stop"])
        self.assertEqual(signal["action"], "pause")

    def test_reopened_dashboard_can_pause_recorded_active_search(self):
        (self.run / "search_status.json").write_text('{"status":"SEARCHING"}')
        self.app.pause(str(self.run))
        self.assertEqual(json.loads((self.run / "control.json").read_text())["action"], "pause")

    def test_http_requires_loopback_host_same_origin_and_csrf(self):
        server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(self.app))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        url = "http://127.0.0.1:" + str(server.server_port)
        try:
            with urlopen(url + "/api/bootstrap", timeout=5) as response:
                boot = json.load(response)
            self.assertEqual(boot["token"], self.app.token)
            with urlopen(url + "/", timeout=5) as response:
                self.assertIn("Inspection Studio", response.read().decode())
            requests = [Request(url + "/api/bootstrap", headers={"Host": "attacker.example"}),
                        Request(url + "/api/pause", data=b"{}", headers={"Content-Type": "application/json"}),
                        Request(url + "/api/pause", data=b"{}", headers={"Content-Type": "application/json", "X-Inspection-Token": self.app.token, "Origin": "https://attacker.example"})]
            for request in requests:
                with self.assertRaises(HTTPError) as error:
                    urlopen(request, timeout=5)
                self.assertEqual(error.exception.code, 403)
            with self.assertRaises(HTTPError):
                urlopen(url + "/results/0/%2e%2e/%2e%2e/private.json", timeout=5)
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=3)


if __name__ == "__main__":
    unittest.main()
