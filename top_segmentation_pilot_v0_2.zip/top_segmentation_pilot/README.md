# Top Segmentation Pilot

Local annotation and a small semantic segmentation model for top-view inspection images. A classical image-processing method proposes defect pixels; an operator corrects and approves each image before it becomes training data.

Start with [START_HERE.md](START_HERE.md). All image processing runs on the local computer. The annotation interface uses a browser connected to `127.0.0.1`; it does not upload images or load external web assets. Internet access is needed only to obtain dependencies when they are not already available locally.

| Label | Mask value | Meaning |
| --- | ---: | --- |
| Background | 0 | Pixels without a labeled defect |
| Inner | 1 | Defect pixels in the inner inspection region |
| Outer | 2 | Defect pixels in the outer inspection region |

The yellow polygon separates the inner and outer inspection regions. All annotated defect pixels are assigned automatically: inside = Inner, outside = Outer. An annotation crossing the boundary is split pixel by pixel. Unannotated pixels stay Background; the whole lens is not filled as a defect. Existing ellipse boundaries remain readable.

Version **0.2.0** adds polygon/octagon boundaries with optional local detection, background-drag panning, reversible image rejection, and an annotation-object list with shape previews, selection, visibility and deletion. See [UPGRADE_v0_2.md](UPGRADE_v0_2.md) when continuing an existing project.

## Workflow

1. Configure the input folder and a separate working project folder.
2. Import image copies at their original resolution.
3. Open each image, review classical proposals, correct the mask, and explicitly approve it.
4. Export an immutable dataset snapshot containing approved images and masks.
5. Train a small U-Net from scratch, inspect validation results, and predict masks for new images.

The annotation interface includes brush, ellipse/circle, polygon, rectangle, eraser, lens-region editing, zoom, pan, and undo/redo. Images are handled individually. Drafts and rejected images are excluded from training; clean images require explicit clean approval. Hiding an annotation changes only its display, not its saved mask or training inclusion.

## Scope

This pilot provides one small U-Net, one grouped train/validation split, model checkpoints, and native-resolution prediction masks and overlays. It does not include the classification project's model competition, production qualification, ONNX packaging, automatic cropping/alignment, or before/after comparison. Use consistently prepared top-view images. Classical detection is a starting mask for manual review, not a defect-detection guarantee.

Annotations remain at native resolution. Training uses a configurable aspect-preserving fit into a square input, with ignored padding; the default size is 512 pixels. Increase this setting when small defects disappear after resizing, subject to available memory. Prediction masks are restored to source dimensions, but resizing back cannot recover detail that was lost at model input.

## Documentation

| Guide | Contents |
| --- | --- |
| [START_HERE.md](START_HERE.md) | Installation and first annotation/training run |
| [Operator guide](docs/OPERATOR_GUIDE.md) | Annotation tools, approval, and recovery |
| [Configuration](docs/CONFIGURATION_REFERENCE.md) | Paths, proposal parameters, and training settings |
| [Training and results](docs/TRAINING_AND_RESULTS.md) | Dataset rules, metrics, checkpoints, and prediction |
| [Data format](docs/DATA_FORMAT.md) | Label masks, revisions, copies, and snapshots |
| [Troubleshooting](docs/TROUBLESHOOTING.md) | Common operational issues |
| [Validation report](docs/VALIDATION_REPORT.md) | What was and was not tested |

Run `python segmentation.py --help` for the command reference. Dependencies for annotation and classical proposals are separate from the optional PyTorch training dependency.
