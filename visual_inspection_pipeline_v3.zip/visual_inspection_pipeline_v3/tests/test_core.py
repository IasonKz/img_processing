import copy
from pathlib import Path
import tempfile
import unittest

import numpy as np
from PIL import Image

from nilt.common import read_json, write_json
from nilt.data import audit, make_manifest, allocate, read_manifest
from nilt.policy import tune_threshold, metrics, escape_upper_bound, selection_key
from nilt.reporting import export_predictions


def config(root):
    return {"task": "top", "data_root": str(root), "image_size": 64, "resize": "pad",
            "split_seed": 42, "split_fractions": {"train": .55, "val": .10, "threshold": .10, "selection": .10, "test": .15},
            "near_duplicate_distance": -1, "policy": {"max_bad_escape_rate": .01, "max_good_reject_rate": .2, "confidence": .95}}


def sample_rows(n=50):
    return [{"path": f"/{c}/{i}.png", "relative_path": f"{c}/{i}.png", "label": c,
             "class_name": "bad" if c == 0 else "good", "pixel_hash": f"{c}_{i}",
             "group": f"g{c}_{i}", "split_hint": ""}
            for c in (0, 1) for i in range(n)]


class ThresholdTests(unittest.TestCase):
    def test_tied_scores_never_split_ties(self):
        p = {"max_bad_escape_rate": 0, "max_good_reject_rate": 1}
        labels, scores = [0, 0, 1, 1], [.3, .9, .3, .1]
        t = tune_threshold(labels, scores, p)
        self.assertEqual(t, .3)
        m = metrics(labels, scores, t)
        self.assertEqual(m["bad_passed_as_good_FN"], 0)
        self.assertEqual(m["good_rejected_as_bad_FP"], 1)

    def test_lower_threshold_is_more_conservative(self):
        y, s = [0, 0, 1, 1], [.4, .8, .3, .1]
        a, b = metrics(y, s, .5), metrics(y, s, .2)
        self.assertGreater(a["bad_passed_as_good_FN"], b["bad_passed_as_good_FN"])
        self.assertLess(a["good_rejected_as_bad_FP"], b["good_rejected_as_bad_FP"])

    def test_zero_errors_do_not_imply_zero_risk(self):
        self.assertGreater(escape_upper_bound(0, 100), .01)
        self.assertLessEqual(escape_upper_bound(0, 299), .01)
        self.assertIsNone(escape_upper_bound(0, 0))

    def test_grouped_bad_units_not_counted_as_independent_images(self):
        m = metrics([0, 0, 0, 1], [.1, .9, .9, .1], .5, ["a", "a", "b", "c"])
        self.assertEqual(m["n_bad_units"], 2)
        self.assertEqual(m["n_escaped_bad_units"], 1)

    def test_selector_rejects_high_accuracy_with_escapes(self):
        policy = {"max_bad_escape_rate": .01, "max_good_reject_rate": .20}
        safe = {"name": "safe", "members": [1], "selection_metrics": {"bad_escape_rate": 0., "good_reject_rate": .1, "pr_auc_bad": .9}}
        unsafe = {"name": "unsafe", "members": [1], "selection_metrics": {"bad_escape_rate": .1, "good_reject_rate": 0., "pr_auc_bad": .99}}
        self.assertLess(selection_key(safe, policy), selection_key(unsafe, policy))

    def test_tuning_matches_exhaustive_search(self):
        rng = np.random.default_rng(42)
        for _ in range(40):
            y = rng.integers(0, 2, 100)
            s = rng.integers(0, 20, 100) / 20
            p = {"max_bad_escape_rate": .1}
            t = tune_threshold(y, s, p)
            feasible = [x for x in np.unique(s) if metrics(y, s, x)["bad_escape_rate"] <= .1]
            self.assertEqual(t, max(feasible))

    def test_no_bad_support_and_invalid_scores(self):
        self.assertIsNone(metrics([1, 1], [.2, .3], .5)["bad_recall"])
        with self.assertRaises(ValueError):
            tune_threshold([1, 1], [.2, .3], {"max_bad_escape_rate": .01})
        with self.assertRaises(ValueError):
            metrics([0, 1], [float("nan"), .5], .5)


class DatasetTests(unittest.TestCase):
    def test_group_integrity_and_reproducibility(self):
        rows = sample_rows()
        rows += [dict(r, relative_path=r["relative_path"] + ".other", pixel_hash=r["pixel_hash"] + "b") for r in rows]
        cfg = config("/unused")
        a = allocate(rows, cfg["split_fractions"], 42)
        b = allocate(rows, cfg["split_fractions"], 42)
        self.assertEqual(a, b)
        mapping = {}
        for row in a:
            mapping.setdefault(row["group"], set()).add(row["split"])
        self.assertTrue(all(len(s) == 1 for s in mapping.values()))
        self.assertEqual(set(r["split"] for r in a), set(cfg["split_fractions"]))

    def test_pixel_duplicate_conflict_stops(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "data"
            for label in ("good", "bad"):
                (root / label).mkdir(parents=True)
                Image.new("RGB", (32, 32), (10, 20, 30)).save(root / label / "a.png")
            with self.assertRaisesRegex(ValueError, "both good and bad"):
                audit(config(root), Path(tmp) / "audit")

    def test_exact_duplicate_same_class_dedup_and_near_not_deleted(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "data"
            for label, color in (("good", 10), ("bad", 20)):
                (root / label).mkdir(parents=True)
                Image.new("RGB", (32, 32), (color, 20, 30)).save(root / label / "a.png")
            Image.new("RGB", (32, 32), (10, 20, 30)).save(root / "good" / "copy.bmp")
            cfg = config(root)
            cfg["near_duplicate_distance"] = 2
            rows = audit(cfg, Path(tmp) / "audit")
            self.assertEqual(len(rows), 2)
            self.assertEqual(read_json(Path(tmp) / "audit" / "audit_summary.json")["n_original_images"], 3)

    def test_existing_splits_preserved(self):
        with tempfile.TemporaryDirectory() as tmp:
            rows = sample_rows(120)
            for row in rows:
                i = int(row["pixel_hash"].split("_")[1])
                row["split_hint"] = "train" if i < 60 else "val" if i < 100 else "test"
            result = make_manifest(config("/none"), rows, tmp)
            for row in result:
                if row["split_hint"] in ("train", "test"):
                    self.assertEqual(row["split"], row["split_hint"])

    def test_incremental_preserves_test_and_excludes_new_test_unit_views(self):
        with tempfile.TemporaryDirectory() as tmp:
            previous, current = Path(tmp) / "old", Path(tmp) / "new"
            cfg = config("/unused")
            old = make_manifest(cfg, sample_rows(60), previous)
            write_json(previous / "config.json", cfg)
            newer = [dict(r, split_hint="") for r in old]
            bad_test = next(r for r in old if r["split"] == "test" and r["label"] == 0)
            newer.append(dict(bad_test, pixel_hash="NEW_VIEW", relative_path="new_view.png", split_hint=""))
            newer.extend(dict(r, group="new_"+r["group"], pixel_hash="new_"+r["pixel_hash"], relative_path="new/"+r["relative_path"]) for r in sample_rows(10))
            cfg["previous_run"] = str(previous)
            result = make_manifest(cfg, newer, current)
            oldmap = {r["pixel_hash"]: r["split"] for r in old}
            for row in result:
                if row["pixel_hash"] in oldmap:
                    self.assertEqual(row["split"], oldmap[row["pixel_hash"]])
                elif row["pixel_hash"] == "NEW_VIEW":
                    self.assertEqual(row["split"], "excluded_old_test_group")
                else:
                    self.assertNotEqual(row["split"], "test")

    def test_incremental_missing_old_data_stops(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg = config("/unused")
            old = make_manifest(cfg, sample_rows(60), Path(tmp) / "old")
            write_json(Path(tmp) / "old" / "config.json", cfg)
            cfg["previous_run"] = str(Path(tmp) / "old")
            with self.assertRaisesRegex(ValueError, "missing"):
                make_manifest(cfg, old[1:], Path(tmp) / "new")

    def test_regex_must_cover_every_image(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "data"
            for label, color in (("good", 5), ("bad", 9)):
                (root / label).mkdir(parents=True)
                Image.new("RGB", (32, 32), (color, 0, 0)).save(root / label / "unknown.png")
            cfg = config(root)
            cfg["group_regex"] = r"(?P<group>UNIT\d+)"
            with self.assertRaisesRegex(ValueError, "invalid"):
                audit(cfg, Path(tmp) / "audit")


class ExportTests(unittest.TestCase):
    def test_real_folders_correct_errors_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            rows = []
            for i, label in enumerate([0, 0, 1, 1]):
                source = Path(tmp) / f"source{i}.png"
                Image.new("RGB", (32, 32), (i * 20, 0, 0)).save(source)
                rows.append({"path": str(source), "relative_path": source.name, "label": label, "group": str(i)})
            original = [Path(r["path"]).read_bytes() for r in rows]
            out = Path(tmp) / "export"
            m = export_predictions(rows, [.9, .1, .9, .1], .5, out)
            self.assertEqual(m["bad_passed_as_good_FN"], 1)
            self.assertEqual(len(list((out / "predicted" / "good").glob("*.png"))), 2)
            self.assertEqual(len(list((out / "errors" / "bad_passed_as_good_FN").glob("*.png"))), 1)
            self.assertEqual(original, [Path(r["path"]).read_bytes() for r in rows])
            with self.assertRaises(FileExistsError):
                export_predictions(rows, [.9, .1, .9, .1], .5, out)


if __name__ == "__main__":
    unittest.main()
