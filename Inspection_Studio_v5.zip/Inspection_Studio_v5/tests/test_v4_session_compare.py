"""End-to-end rule comparisons must use identical image content and labels."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

from nilt.session_compare import compare_sessions
from nilt.review import initialize_session, append_prediction


class SessionComparison(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.records = [
            {"relative_path": "bad/a.png", "file_sha256": "a" * 64, "reference_label": "bad", "prediction": "bad"},
            {"relative_path": "good/b.png", "file_sha256": "b" * 64, "reference_label": "good", "prediction": "good"},
        ]

    def session(self, name, records=None, status="completed", **summary):
        path = self.root / name
        path.mkdir()
        (path / "summary.json").write_text(json.dumps({"status": status, "elapsed_seconds": 2, **summary}))
        initialize_session(path, kind="classification")
        for row in (records or self.records):
            append_prediction(path, row)
        return path

    def test_compares_full_rules_and_ignores_review_edits(self):
        first = self.session("first")
        records = copy.deepcopy(self.records)
        records[1]["prediction"] = "bad"
        second = self.session("second", records)
        (second / "reviews.json").write_text('{"anything":{"label":"bad"}}')
        result = compare_sessions([first, second])
        self.assertEqual(result["n_images"], 2)
        self.assertEqual(result["sessions"][0]["metrics"]["accuracy"], 1)
        self.assertEqual(result["sessions"][1]["metrics"]["good_reject_rate"], 1)
        self.assertEqual(result["sessions"][1]["metrics"]["balanced_accuracy"], .5)
        self.assertEqual(result["sessions"][0]["images_per_second"], 1)

    def test_rejects_changed_bytes_labels_or_paths(self):
        first = self.session("first")
        for key, value in (("relative_path", "bad/renamed.png"), ("file_sha256", "c" * 64), ("reference_label", "good")):
            records = copy.deepcopy(self.records)
            records[0][key] = value
            second = self.session(key, records)
            with self.assertRaisesRegex(ValueError, "same image"):
                compare_sessions([first, second])

    def test_rejects_running_failed_scores_only_or_invalid(self):
        first = self.session("first")
        for state in ("running", "failed"):
            with self.assertRaisesRegex(ValueError, "completed"):
                compare_sessions([first, self.session(state, status=state)])
        records = copy.deepcopy(self.records)
        records[0]["prediction"] = None
        with self.assertRaisesRegex(ValueError, "Scores-only"):
            compare_sessions([first, self.session("scores", records)])
        with self.assertRaisesRegex(ValueError, "invalid inputs"):
            compare_sessions([first, self.session("invalid", invalid_images=1)])

    def test_unlabeled_has_no_accuracy_and_missing_class_is_null(self):
        records = copy.deepcopy(self.records)
        for record in records:
            record["reference_label"] = None
        result = compare_sessions([self.session("one", records), self.session("two", records)])
        self.assertEqual(result["n_labeled"], 0)
        self.assertIsNone(result["sessions"][0]["metrics"]["accuracy"])
        self.assertIsNone(result["sessions"][0]["metrics"]["balanced_accuracy"])

    def test_rejects_missing_hash_duplicate_records_or_same_session(self):
        first = self.session("first")
        with self.assertRaisesRegex(ValueError, "different"):
            compare_sessions([first, first])
        records = copy.deepcopy(self.records)
        del records[0]["file_sha256"]
        with self.assertRaisesRegex(ValueError, "fingerprints"):
            compare_sessions([first, self.session("hashless", records)])
        second = self.session("dup")
        source = next((second / "records").glob("*.json"))
        (second / "records" / "extra.json").write_bytes(source.read_bytes())
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            compare_sessions([first, second])


if __name__ == "__main__":
    unittest.main()
