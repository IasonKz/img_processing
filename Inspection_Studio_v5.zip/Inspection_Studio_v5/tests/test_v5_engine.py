"""Native-pixel MIL, extra pretrained architectures and checkpoint integrity."""
import copy
import re
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np
from PIL import Image

from nilt.common import DEFAULTS, MODEL_NAMES, merge_dict, validate_config, sha_file, write_json, read_json, load_project
from nilt.preprocessing import patch_boxes, validate_patch_settings, prepare_image, rotate_quarter_turn

try:
    import torch
    import torchvision
    TORCH_AVAILABLE = True
except (ImportError, RuntimeError, OSError):
    TORCH_AVAILABLE = False


class PatchGeometryTests(unittest.TestCase):
    def test_saved_dashboard_profile_is_resolved_and_cli_can_override(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "project.json"
            project = {"profile": "workstation", "tasks": {"vig": {"dataset_root": "data"}},
                       "paths": {"output_root": "results", "weights_root": "weights"}}
            write_json(path, project)
            self.assertEqual(load_project(path)[0]["profile"], "workstation")
            self.assertEqual(load_project(path, "laptop")[0]["profile"], "laptop")
            project["profile"] = "unknown"
            write_json(path, project)
            with self.assertRaisesRegex(ValueError, "profile"):
                load_project(path)

    def test_finetune_preserves_selected_trial_and_explicit_scope(self):
        from nilt.workflow import fine_tune_member_config
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            old_cfg = merge_dict(DEFAULTS, {"task": "vig", "data_root": str(root / "old"),
                     "output_root": str(root / "results"), "weights_dir": str(root / "weights"),
                     "image_size": 64, "models": ["resnet18"]})
            trial_cfg = merge_dict(old_cfg, {"image_strategy": "global_patches",
                "patches": {"size": 32, "overlap": 8},
                "training": {"mode": "head_only", "learning_rate": 0.000003, "optimizer": "sgd"}})
            trial = root / "trial.json"
            write_json(trial, trial_cfg)
            member = {"architecture": "resnet18", "config": "trial.json", "config_sha256": sha_file(trial)}
            current = merge_dict(old_cfg, {"training": {"epochs": 3, "mode": "head_only", "batch_size": 1},
                              "device": "cpu", "data_root": str(root / "new")})
            result = fine_tune_member_config(root, member, old_cfg, current)
            self.assertEqual(result["image_strategy"], "global_patches")
            self.assertEqual(result["patches"]["size"], 32)
            self.assertEqual(result["training"]["mode"], "full")
            self.assertEqual(result["training"]["learning_rate"], 0.000003)
            self.assertEqual(result["training"]["optimizer"], "sgd")
            self.assertEqual(result["training"]["epochs"], 3)
            self.assertEqual(result["training"]["batch_size"], 1)
            self.assertEqual(result["data_root"], current["data_root"])
            current["fine_tuning"] = {"mode": "head_only", "training": {"learning_rate": 1e-5}}
            explicit = fine_tune_member_config(root, member, old_cfg, current)
            self.assertEqual(explicit["training"]["mode"], "head_only")
            self.assertEqual(explicit["training"]["learning_rate"], 1e-5)
            self.assertEqual(trial_cfg["training"]["mode"], "head_only")

    def test_direct_update_checks_review_integrity_before_creating_run(self):
        from nilt.workflow import new_run
        with tempfile.TemporaryDirectory() as tmp:
            cfg = merge_dict(DEFAULTS, {"task": "vig", "data_root": str(Path(tmp) / "dataset"),
                       "output_root": str(Path(tmp) / "runs"),
                       "review_dataset": {"version": str(Path(tmp) / "review")}})
            with patch("nilt.review_dataset.validate_update_config", side_effect=ValueError("changed review export")) as gate:
                with self.assertRaisesRegex(ValueError, "changed review export"):
                    new_run(cfg)
            gate.assert_called_once()
            self.assertFalse(Path(cfg["output_root"]).exists())

    def test_complete_coverage_and_borders_for_nondivisible_canvas(self):
        settings = validate_patch_settings({"patches": {"size": 32, "overlap": 7}})
        canvas = np.zeros((59, 91), dtype=int)
        boxes = patch_boxes(91, 59, settings)
        for x0, y0, x1, y1 in boxes:
            canvas[y0:y1, x0:x1] += 1
        self.assertGreaterEqual(int(canvas.min()), 1)
        self.assertGreater(int(canvas.max()), 1)
        self.assertEqual(boxes[-1], (59, 27, 91, 59))

    def test_patch_limit_never_silently_samples(self):
        with self.assertRaisesRegex(ValueError, "No patches were silently omitted"):
            patch_boxes(96, 96, {"size": 32, "overlap": 0, "max_patches": 8})

    def test_small_image_is_not_resampled(self):
        self.assertEqual(patch_boxes(17, 21, {"size": 32, "overlap": 8}), [(0, 0, 17, 21)])

    def test_invalid_settings(self):
        for values in ({"size": 31}, {"overlap": 256}, {"global_weight": 1},
                       {"topk": 0}, {"chunk_size": True}, {"random_sampling": True},
                       {"global_weight": float("nan")}, {"aggregation": "average"}):
            with self.subTest(values=values), self.assertRaises(ValueError):
                validate_patch_settings({"patches": values})

    def test_rotation_preserves_every_original_pixel_before_patches(self):
        pixels = np.arange(17 * 29 * 3, dtype=np.uint8).reshape(17, 29, 3)
        cfg = {"image_size": 32, "resize": "pad", "preserve_native_resolution": True}
        image = Image.fromarray(pixels)
        for k in range(4):
            rotated = rotate_quarter_turn(image, k)
            prepared = np.asarray(prepare_image(rotated, cfg))
            expected = np.rot90(pixels, k)
            h, w = expected.shape[:2]
            np.testing.assert_array_equal(prepared[(32-h)//2:(32-h)//2+h,
                                                    (32-w)//2:(32-w)//2+w], expected)

    def test_new_models_are_registered_without_broadening_default_search(self):
        for name in ("efficientnet_b2", "efficientnet_v2_s", "mobilenet_v3_large", "densenet121"):
            self.assertIn(name, MODEL_NAMES)
            self.assertNotIn(name, DEFAULTS["models"])

    def test_strategy_rejects_patchcore_resampling_and_unfrozen_bn(self):
        base = merge_dict(DEFAULTS, {"task": "vig", "data_root": "/tmp/data",
                          "output_root": "/tmp/out", "models": ["resnet18"],
                          "image_size": 64, "image_strategy": "global_patches"})
        self.assertEqual(validate_config(base), base)
        for override in ({"models": ["patchcore"]}, {"resize": "fit"},
                         {"training": {"freeze_batch_norm": False}}):
            with self.assertRaises(ValueError):
                validate_config(merge_dict(base, override))

    def test_patchcore_requires_ap_objective(self):
        cfg = merge_dict(DEFAULTS, {"task": "vig", "data_root": "/tmp/data", "output_root": "/tmp/out",
                         "models": ["patchcore"], "search": {"objective": "validation_balanced_accuracy"}})
        with self.assertRaisesRegex(ValueError, "PatchCore supports validation_ap"):
            validate_config(cfg)


@unittest.skipUnless(TORCH_AVAILABLE, "torch/torchvision not installed")
class PatchTrainingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1)

    @staticmethod
    def config():
        return merge_dict(DEFAULTS, {"task": "vig", "image_size": 64, "models": ["resnet18"],
                    "pretrained": False, "image_strategy": "global_patches", "device": "cpu",
                    "cpu_threads": 1, "patches": {"size": 32, "overlap": 8, "chunk_size": 2},
                    "training": {"epochs": 2, "warmup_epochs": 0, "patience": 5,
                        "batch_size": 1, "eval_batch_size": 2, "accumulation_steps": 1,
                        "optimizer": "sgd", "momentum": 0., "scheduler": "constant", "amp": False}})

    @staticmethod
    def tiny_model(name=None, cfg=None, pretrained=False):
        from nilt.patch_models import GlobalPatchClassifier
        core = torch.nn.Sequential(torch.nn.Conv2d(3, 4, 3, padding=1), torch.nn.ReLU(),
                 torch.nn.AdaptiveAvgPool2d(1), torch.nn.Flatten(), torch.nn.Linear(4, 2))
        head = core[-1]
        return (GlobalPatchClassifier(core, cfg) if cfg and cfg.get("image_strategy") == "global_patches" else core), head

    @staticmethod
    def rows(root):
        rng = np.random.default_rng(4)
        rows = []
        for i in range(8):
            image = root / f"{i}.png"
            Image.fromarray(rng.integers(0, 255, (59, 45, 3), dtype=np.uint8)).save(image)
            rows.append({"path": str(image), "relative_path": image.name,
                         "pixel_hash": sha_file(image), "label": i % 2,
                         "group": str(i), "split": "train" if i < 4 else "val"})
        return rows

    def test_logits_have_one_output_per_image_with_gradients(self):
        for aggregate in ("max", "topk"):
            cfg = self.config()
            cfg["patches"]["aggregation"] = aggregate
            model, head = self.tiny_model(cfg=cfg)
            images = torch.randn(2, 3, 64, 64)
            logits = model(images)
            self.assertEqual(tuple(logits.shape), (2, 2))
            torch.nn.functional.cross_entropy(logits, torch.tensor([0, 1])).backward()
            self.assertTrue(torch.isfinite(head.weight.grad).all())
            self.assertGreater(float(head.weight.grad.abs().sum()), 0)

    def test_chunk_size_does_not_change_eval_predictions(self):
        cfg = self.config()
        model, _ = self.tiny_model(cfg=cfg)
        model.eval()
        x = torch.randn(2, 3, 64, 64)
        with torch.inference_mode():
            expected = model(x)
            model.settings["chunk_size"] = 7
            actual = model(x)
        torch.testing.assert_close(expected, actual, rtol=1e-5, atol=1e-6)

    def test_train_resume_and_checkpoint_input_semantics(self):
        from nilt import engine
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            rows, cfg = self.rows(root), self.config()
            epochs = []
            with patch.object(engine, "make_model", self.tiny_model):
                with self.assertRaises(engine.TrainingStopped):
                    engine.train_one("resnet18", 42, rows, cfg, root / "resumed",
                         progress_callback=lambda p: epochs.append(p["epoch"]),
                         stop_check=lambda: "pause" if epochs else None)
                resumed = engine.train_one("resnet18", 42, rows, cfg, root / "resumed")
                direct = engine.train_one("resnet18", 42, rows, cfg, root / "direct")
                for key, value in torch.load(resumed, weights_only=True)["state_dict"].items():
                    torch.testing.assert_close(value, torch.load(direct, weights_only=True)["state_dict"][key], rtol=0, atol=0)
                expected, _ = engine.predict_checkpoint(direct, rows, cfg)
                caller_cfg = merge_dict(cfg, {"image_strategy": "full_image", "image_size": 128,
                                              "patches": {"global_weight": .1}})
                actual, _ = engine.predict_checkpoint(direct, rows, caller_cfg)
                np.testing.assert_array_equal(expected, actual)
                changed = merge_dict(cfg, {"patches": {"global_weight": .8}})
                with self.assertRaisesRegex(ValueError, "fingerprint"):
                    engine.train_one("resnet18", 42, rows, changed, root / "resumed")

    def test_singleton_weighted_loss_keeps_class_influence(self):
        from nilt.engine import imbalance_setup
        rows = [{"label": 0}] + [{"label": 1}] * 3
        cfg = self.config()
        cfg["training"]["imbalance"] = "weighted_loss"
        weights, _, info = imbalance_setup(rows, cfg, 42)
        self.assertAlmostEqual(float(weights[0] / weights[1]), 3.)
        x = torch.tensor([[0., 0.]], requires_grad=True)
        y = x.detach().clone().requires_grad_(True)
        torch.nn.functional.cross_entropy(x, torch.tensor([0]), weight=weights, reduction="sum").backward()
        torch.nn.functional.cross_entropy(y, torch.tensor([0]), reduction="sum").backward()
        torch.testing.assert_close(x.grad, y.grad * weights[0])
        self.assertNotEqual(info["effective_loss_weights"][0], 1.)

    def test_objective_selects_checkpoint_without_relabeling_ap(self):
        from nilt import engine
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            rows, cfg = self.rows(root), self.config()
            cfg["search"]["objective"] = "validation_roc_auc"
            reported = []
            values = [{"pr_auc_bad": .9, "roc_auc_bad": .6, "balanced_accuracy": .5, "bad_recall": .5},
                      {"pr_auc_bad": .7, "roc_auc_bad": .8, "balanced_accuracy": .5, "bad_recall": .5}]
            with patch.object(engine, "make_model", self.tiny_model), patch("nilt.policy.metrics", side_effect=values):
                best = engine.train_one("resnet18", 42, rows, cfg, root / "trial", progress_callback=reported.append)
            self.assertEqual(torch.load(best, weights_only=True)["epoch"], 2)
            meta = read_json(root / "trial" / "completed.json")
            self.assertEqual(meta["best_val_pr_auc_bad"], .7)
            self.assertEqual(meta["best_objective_value"], .8)
            self.assertEqual(reported[-1]["objective_metric"], "validation_roc_auc")
            self.assertEqual(reported[-1]["val_pr_auc_bad"], .7)
            changed = merge_dict(cfg, {"search": {"objective": "validation_ap"}})
            with patch.object(engine, "make_model", self.tiny_model), self.assertRaisesRegex(ValueError, "fingerprint"):
                engine.train_one("resnet18", 42, rows, changed, root / "trial")

    def test_finetune_updates_backbone_from_a_frozen_source(self):
        from nilt import engine
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            rows, cfg = self.rows(root), self.config()
            cfg["training"].update(epochs=1, mode="head_only", learning_rate=.01)
            with patch.object(engine, "make_model", self.tiny_model):
                initial = engine.train_one("resnet18", 42, rows, cfg, root / "frozen")
                cfg["training"]["mode"] = "full"
                updated = engine.train_one("resnet18", 42, rows, cfg, root / "updated", init_checkpoint=initial)
            source_state = torch.load(initial, weights_only=True)
            updated_state = torch.load(updated, weights_only=True)
            self.assertEqual(updated_state["parent_sha256"], sha_file(initial))
            self.assertFalse(torch.equal(source_state["state_dict"]["core.0.weight"],
                                         updated_state["state_dict"]["core.0.weight"]))
            self.assertEqual(read_json(root / "updated" / "progress.json")["stage"], "full")

    def test_added_models_forward_and_last_block(self):
        from nilt import engine
        for name in ("efficientnet_b2", "efficientnet_v2_s", "mobilenet_v3_large", "densenet121"):
            with self.subTest(name=name):
                # Offline random initialization is ONLY this local structure
                # test. The released GUI enforces provisioned pretrained weights.
                model, head = engine.make_model(name)
                engine.configure_training_stage(model, head, name,
                    {"mode": "last_block", "warmup_epochs": 0, "freeze_batch_norm": True}, 0)
                with torch.inference_mode():
                    self.assertEqual(tuple(model(torch.randn(1, 3, 64, 64)).shape), (1, 2))
                self.assertTrue(all(p.requires_grad for p in head.parameters()))
                self.assertTrue(any(not p.requires_grad for p in model.parameters()))

    def test_local_densenet_legacy_weight_key_migration(self):
        from nilt import engine
        original = torchvision.models.densenet121(weights=None)
        old_keys = {re.sub(r"(denselayer\d+\.(?:norm|relu|conv))([12])\.", r"\1.\2.", key): value
                    for key, value in original.state_dict().items() if not key.endswith("num_batches_tracked")}
        self.assertIn("features.denseblock1.denselayer1.norm.1.weight", old_keys)
        with patch("torch.load", return_value=old_keys):
            loaded, _ = engine.make_model("densenet121", {"weights_dir": "/unused"}, pretrained=True)
        torch.testing.assert_close(loaded.features.conv0.weight, original.features.conv0.weight)
        self.assertEqual(loaded.classifier.out_features, 2)


if __name__ == "__main__":
    unittest.main()
