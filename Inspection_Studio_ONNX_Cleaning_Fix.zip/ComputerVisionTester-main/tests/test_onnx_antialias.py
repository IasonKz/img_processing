"""Real ATen/ONNX Runtime parity; no pretrained weights or network required."""
import numpy as np
import pytest
torch=pytest.importorskip("torch")
ort=pytest.importorskip("onnxruntime")
from nilt.export_support import export_onnx


@pytest.mark.parametrize("mode",["bicubic","bilinear"])
@pytest.mark.parametrize("align",[False,True])
@pytest.mark.parametrize("size,scale",[((11,13),None),((29,31),None),(None,1.7)])
def test_resize_parity_and_symbolic_restoration(tmp_path,mode,align,size,scale):
    class Resize(torch.nn.Module):
        def forward(self,x):
            return torch.nn.functional.interpolate(x,size=size,scale_factor=scale,mode=mode,align_corners=align,antialias=True)
    model=Resize().eval();torch.manual_seed(12);sample=torch.randn(1,3,19,21)
    torch.set_num_threads(1)
    expected=model(sample).numpy()
    metadata=export_onnx(model,sample,tmp_path/"resize.onnx",input_names=["images"],output_names=["pixels"],opset_version=17,dynamo=False)
    options=ort.SessionOptions();options.intra_op_num_threads=1
    actual=ort.InferenceSession(str(tmp_path/"resize.onnx"),options,providers=["CPUExecutionProvider"]).run(None,{"images":sample.numpy()})[0]
    np.testing.assert_allclose(actual,expected,atol=1e-5,rtol=1e-4)
    np.testing.assert_array_equal(model(sample).numpy(),expected)
    assert metadata["antialias_resizes"]
    from torch.onnx._internal import registration
    assert not registration.registry.get_function_group("aten::_upsample_bicubic2d_aa")._functions.overridden(17)


def test_dynamic_vit_positional_embedding_export(tmp_path):
    timm=pytest.importorskip("timm")
    torch.manual_seed(19);torch.set_num_threads(1)
    model=timm.create_model("vit_tiny_patch16_224",pretrained=False,num_classes=2,dynamic_img_size=True).eval()
    sample=torch.randn(1,3,64,80)
    before=model.pos_embed.detach().clone()
    with torch.inference_mode():expected=model(sample).numpy()
    metadata=export_onnx(model,sample,tmp_path/"vit.onnx",input_names=["images"],output_names=["logits"],opset_version=17,dynamo=False,external_data=False)
    options=ort.SessionOptions();options.intra_op_num_threads=1
    actual=ort.InferenceSession(str(tmp_path/"vit.onnx"),options,providers=["CPUExecutionProvider"]).run(None,{"images":sample.numpy()})[0]
    np.testing.assert_allclose(actual,expected,atol=1e-5,rtol=1e-4)
    assert torch.equal(before,model.pos_embed)
    assert any(row["operator"]=="aten::_upsample_bicubic2d_aa" for row in metadata["antialias_resizes"])


@pytest.mark.parametrize("patches",[False, True])
def test_project_eva_backbone_with_rotary_geometry_and_optional_patches(tmp_path, patches):
    pytest.importorskip("timm")
    from nilt.engine import make_model
    torch.manual_seed(29);torch.set_num_threads(1)
    cfg={"image_strategy":"global_patches" if patches else "full_image", "image_size":70,
         "patches":{"size":42,"overlap":0,"chunk_size":2,"aggregation":"max","topk":1,"global_weight":.5}}
    model,_=make_model("eva02-tiny",cfg,pretrained=False);model.eval()
    sample=torch.randn(1,3,70,70)
    core=model.core if patches else model
    before=core.pos_embed.detach().clone()
    original_method=core.rope.get_embed
    with torch.inference_mode():expected=model(sample).numpy()
    metadata=export_onnx(model,sample,tmp_path/"eva.onnx",input_names=["images"],opset_version=17,dynamo=False,external_data=False)
    options=ort.SessionOptions();options.intra_op_num_threads=1
    actual=ort.InferenceSession(str(tmp_path/"eva.onnx"),options,providers=["CPUExecutionProvider"]).run(None,{"images":sample.numpy()})[0]
    np.testing.assert_allclose(actual,expected,atol=1e-5,rtol=1e-4)
    assert torch.equal(before,core.pos_embed)
    assert core.rope.get_embed==original_method
    assert len(metadata["geometry_tables"]) == (2 if patches else 1)
    assert metadata["antialias_resizes"] and metadata["fixed_reshape_count"]
