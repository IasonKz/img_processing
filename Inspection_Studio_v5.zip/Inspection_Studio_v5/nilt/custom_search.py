"""Validated, serializable Optuna search contracts for GUI and Python clients.

Contracts describe only development-data optimization. Image geometry and
labels cannot be modified through this interface; all image backbones start
from the declared pretrained weights. Numerical specs support fixed values,
categorical choices and bounded ranges without accepting executable content.
"""
from __future__ import annotations

import math

from .common import merge_dict, validate_config

OBJECTIVES = {
    "validation_ap": "Validation average precision (bad)",
    "validation_roc_auc": "Validation ROC AUC (bad)",
    "validation_balanced_accuracy": "Validation balanced accuracy at threshold 0.5",
}
SEARCH_DEFAULTS = {
    "total_budget_seconds": 7200, "max_trials_per_model": 8, "max_grid_combinations": 10000,
    "startup_trials": 3, "min_finetune_epochs": 2, "shortlist_per_model": 1,
    "minimum_trial_seconds": 60, "selection_reserve_fraction": .15,
    "confirmation_reserve_fraction": .20, "seed": 42,
    "sampler": "tpe", "pruner": "median", "trial_timeout_seconds": 0,
    "pruner_startup_trials": 3, "pruner_warmup_steps": 0,
    "pruner_interval_steps": 1, "pruner_reduction_factor": 3,
    "study_patience_trials": 0, "minimum_improvement": 0.,
    "max_failed_trials_per_model": 3, "enqueue_presets": True,
    "space": {}, "model_spaces": {}, "objective": "validation_ap",
}
CATEGORIES = {
    "mode": ["head_only", "full", "last_block"],
    "optimizer": ["adamw", "sgd"],
    "scheduler": ["cosine", "plateau", "constant"],
    "imbalance": ["none", "weighted_loss", "sampler"],
}
RANGES = {
    "learning_rate": [1e-6, 1e-4], "head_learning_rate": [1e-4, 3e-3],
    "weight_decay": [1e-6, 1e-3], "momentum": [.8, .95],
}
INTEGER_PARAMS = {"effective_batch_size", "warmup_epochs", "coreset_size", "projection_dim"}
PARAMETERS = set(CATEGORIES) | set(RANGES) | INTEGER_PARAMS | {"max_class_weight"}
TRAINING_KEYS = {"epochs", "patience", "batch_size", "eval_batch_size", "amp"}
SEARCH_KEYS = set(SEARCH_DEFAULTS) | {"enabled", "custom", "contract_version"}


def _number(value, path, minimum=None, maximum=None, integer=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{path} must be a finite number.")
    if integer and int(value) != value:
        raise ValueError(f"{path} must be an integer.")
    if minimum is not None and value < minimum or maximum is not None and value > maximum:
        raise ValueError(f"{path} must be in [{minimum}, {maximum}].")
    return int(value) if integer else float(value)


def parameter_spec(key, value):
    """Normalize v4 lists and v5 fixed/choices/range parameter declarations."""
    if key not in PARAMETERS:
        raise ValueError(f"Unknown search parameter: {key}.")
    path = "search.space." + key
    if isinstance(value, dict):
        spec = dict(value)
        kind = spec.get("kind")
        allowed = {"fixed": {"kind", "value"}, "choices": {"kind", "values"},
                   "range": {"kind", "low", "high", "log", "step"}}
        if kind not in allowed or set(spec) - allowed[kind]:
            raise ValueError(f"{path} needs kind fixed, choices, or range with supported fields.")
    elif isinstance(value, list):
        if key in RANGES:
            if len(value) != 2:
                raise ValueError(f"{path} legacy range needs two endpoints; use kind=choices for a list.")
            spec = {"kind": "range", "low": value[0], "high": value[1], "log": key != "momentum"}
        else:
            spec = {"kind": "choices", "values": list(value)}
    else:
        spec = {"kind": "fixed", "value": value}
    kind = spec["kind"]
    if kind == "fixed":
        if "value" not in spec:
            raise ValueError(f"{path}.value is required.")
        values = [spec["value"]]
    elif kind == "choices":
        values = spec.get("values")
        if not isinstance(values, list) or not values or len(values) > 256:
            raise ValueError(f"{path}.values must contain 1 to 256 choices.")
    else:
        if key in CATEGORIES:
            raise ValueError(f"{path} accepts fixed or choices, not ranges.")
        if "low" not in spec or "high" not in spec:
            raise ValueError(f"{path} range requires low and high.")
        values = [spec["low"], spec["high"]]
        if type(spec.get("log", False)) is not bool:
            raise ValueError(f"{path}.log must be boolean.")
        spec.setdefault("log", False)
    if key in CATEGORIES:
        if any(v not in CATEGORIES[key] for v in values):
            raise ValueError(f"{path} choices must be drawn from {CATEGORIES[key]}.")
    else:
        low = 0 if key in {"warmup_epochs", "weight_decay", "momentum"} else 1 if key in INTEGER_PARAMS or key == "max_class_weight" else 1e-12
        high = .999999 if key == "momentum" else None
        values = [_number(v, path, low, high, key in INTEGER_PARAMS) for v in values]
    if kind == "fixed":
        spec["value"] = values[0]
    elif kind == "choices":
        if len(set(values)) != len(values):
            raise ValueError(f"{path} choices must be distinct.")
        spec["values"] = values
    else:
        spec["low"], spec["high"] = values
        if values[0] > values[1]:
            raise ValueError(f"{path}.low must not exceed high.")
        if spec["log"] and values[0] <= 0:
            raise ValueError(f"{path} logarithmic ranges require a positive lower bound.")
        if "step" in spec:
            _number(spec["step"], path + ".step", 1 if key in INTEGER_PARAMS else 1e-12, integer=key in INTEGER_PARAMS)
            if spec["log"]:
                raise ValueError(f"{path} cannot combine logarithmic sampling with step.")
    return spec


def finite_choices(spec, limit=10000):
    """Finite support for grid search and compatibility validation."""
    if spec["kind"] == "fixed":
        return [spec["value"]]
    if spec["kind"] == "choices":
        return list(spec["values"])
    if spec["low"] == spec["high"]:
        return [spec["low"]]
    if spec.get("log") or "step" not in spec:
        raise ValueError("Grid sampling requires fixed values, explicit choices, or linear ranges with step.")
    size = int(math.floor((spec["high"] - spec["low"]) / spec["step"] + 1e-9)) + 1
    if size > limit:
        raise ValueError(f"The declared grid exceeds max_grid_combinations={limit:,}; increase the setting or use TPE/Random sampling.")
    return [spec["low"] + i * spec["step"] for i in range(size)]


def active_parameters(space, model):
    if model == "patchcore":
        return {"coreset_size", "projection_dim"}
    names = set(space) - {"coreset_size", "projection_dim"}
    if "sgd" not in finite_choices(space["optimizer"]):
        names.discard("momentum")
    if "weighted_loss" not in finite_choices(space["imbalance"]):
        names.discard("max_class_weight")
    if finite_choices(space["mode"]) == ["head_only"]:
        names -= {"learning_rate", "warmup_epochs"}
    return names


def default_space(cfg):
    train = cfg["training"]
    batch = int(train["batch_size"]) * int(train.get("accumulation_steps", 1))
    max_warmup = max(0, int(train["epochs"]) - int(cfg.get("search", {}).get("min_finetune_epochs", 2)))
    cap = int(cfg["patchcore"]["reservoir_size"])
    return {
        "mode": CATEGORIES["mode"], "optimizer": ["adamw"],
        "scheduler": ["cosine", "plateau"], "imbalance": CATEGORIES["imbalance"],
        **RANGES, "max_class_weight": [2., 4.],
        "effective_batch_size": sorted({batch, batch * 2}),
        "warmup_epochs": sorted({min(max_warmup, n) for n in (1, 2, 4)}),
        "coreset_size": sorted({min(cap, n) for n in (128, 256, 512)}),
        "projection_dim": [16, 32, 64],
    }


def resolved_space(cfg, model=None):
    settings = cfg.get("search", {})
    raw = {**default_space(cfg), **settings.get("space", {})}
    if model is not None:
        raw.update(settings.get("model_spaces", {}).get(model, {}))
    return {key: parameter_spec(key, value) for key, value in raw.items()}


def validate_settings(cfg):
    values = merge_dict(SEARCH_DEFAULTS, cfg.get("search", {}))
    if "pruner_startup_trials" not in cfg.get("search", {}):
        values["pruner_startup_trials"] = values["startup_trials"]
    unknown = set(values) - SEARCH_KEYS
    if unknown:
        raise ValueError(f"Unknown search settings: {sorted(unknown)}.")
    for key in ("max_trials_per_model", "min_finetune_epochs", "shortlist_per_model", "pruner_interval_steps", "max_grid_combinations"):
        values[key] = _number(values[key], "search." + key, 1, integer=True)
    for key in ("startup_trials", "pruner_startup_trials", "pruner_warmup_steps", "study_patience_trials", "max_failed_trials_per_model"):
        values[key] = _number(values[key], "search." + key, 0, integer=True)
    _number(values["pruner_reduction_factor"], "search.pruner_reduction_factor", 2, integer=True)
    _number(values["seed"], "search.seed", 0, 2**32 - 1, integer=True)
    _number(values["total_budget_seconds"], "search.total_budget_seconds", 1e-6)
    _number(values["minimum_trial_seconds"], "search.minimum_trial_seconds", 1e-6)
    _number(values["trial_timeout_seconds"], "search.trial_timeout_seconds", 0)
    _number(values["minimum_improvement"], "search.minimum_improvement", 0, 1)
    for key in ("selection_reserve_fraction", "confirmation_reserve_fraction"):
        _number(values[key], "search." + key, 0, .799999)
    if values["selection_reserve_fraction"] + values["confirmation_reserve_fraction"] >= .9:
        raise ValueError("Search reserve fractions must leave at least 10% for trial training.")
    if values["sampler"] not in {"tpe", "random", "grid"}:
        raise ValueError("Sampler must be tpe, random, or grid.")
    if values["objective"] not in OBJECTIVES:
        raise ValueError(f"Search objective must be one of {list(OBJECTIVES)}.")
    if values["pruner"] not in {"median", "none", "successive_halving", "hyperband"}:
        raise ValueError("Unsupported pruning method.")
    if type(values["enqueue_presets"]) is not bool:
        raise ValueError("search.enqueue_presets must be boolean.")
    for key in ("space", "model_spaces"):
        if not isinstance(values[key], dict):
            raise ValueError(f"search.{key} must be an object.")
    if not cfg.get("models") or len(set(cfg["models"])) != len(cfg["models"]):
        raise ValueError("Search requires a nonempty list of distinct models.")
    if "patchcore" in cfg["models"] and values["objective"] != "validation_ap":
        raise ValueError("PatchCore search currently requires the validation_ap objective. Select only supervised classifiers for other objectives.")
    if set(values["model_spaces"]) - set(cfg["models"]):
        raise ValueError("model_spaces may only name selected architectures.")
    if any(not isinstance(value, dict) for value in values["model_spaces"].values()):
        raise ValueError("Each model_spaces entry must be a search-space object.")
    check_cfg = merge_dict(cfg, {"search": values})
    for model in cfg["models"]:
        space = resolved_space(check_cfg, model)
        if model == "patchcore":
            coreset = space["coreset_size"]
            maximum = coreset["high"] if coreset["kind"] == "range" else max(finite_choices(coreset))
            if maximum > cfg["patchcore"]["reservoir_size"]:
                raise ValueError("Optuna coreset size exceeds the configured reservoir size.")
        else:
            batch = cfg["training"]["batch_size"]
            effective = space["effective_batch_size"]
            if effective["kind"] == "range" and effective["low"] != effective["high"]:
                if effective.get("log") or effective.get("step", 1) % batch or effective["low"] % batch:
                    raise ValueError("Effective batch ranges must use linear, batch-divisible endpoints and step.")
            elif any(v < batch or v % batch for v in finite_choices(effective)):
                raise ValueError("Effective batch choices must be positive multiples of training.batch_size.")
            modes = finite_choices(space["mode"])
            if any(mode != "head_only" for mode in modes):
                warmup = space["warmup_epochs"]
                maximum = warmup["high"] if warmup["kind"] == "range" else max(finite_choices(warmup))
                if maximum + values["min_finetune_epochs"] > cfg["training"]["epochs"]:
                    raise ValueError("Warmup leaves fewer than min_finetune_epochs within the trial epoch budget.")
        if values["sampler"] == "grid":
            active = active_parameters(space, model)
            size = 1
            for key in active:
                size *= len(finite_choices(space[key], limit=values["max_grid_combinations"]))
                if size > values["max_grid_combinations"]:
                    raise ValueError(f"Grid exceeds max_grid_combinations={values['max_grid_combinations']:,}; increase the setting or choose TPE/Random.")
    return values


def defaults_for(cfg):
    """Full GUI contract; changing a profile supplies a fresh editable copy."""
    values = merge_dict(SEARCH_DEFAULTS, cfg.get("search", {}))
    if "pruner_startup_trials" not in cfg.get("search", {}):
        values["pruner_startup_trials"] = values["startup_trials"]
    values["space"] = resolved_space(cfg)
    return {"device": cfg.get("device", "auto"), "cpu_threads": cfg.get("cpu_threads", 4), "num_workers": cfg.get("num_workers", 0), "search": values,
            "training": {key: cfg["training"][key] for key in TRAINING_KEYS},
            "seeds": list(cfg.get("seeds", [42])),
            "augmentation": {"rotation90": bool(cfg.get("augmentation", {}).get("rotation90", False))},
            "image_strategy": cfg.get("image_strategy", "full_image"),
            "patches": cfg.get("patches", {"size": 256, "overlap": 64, "max_patches": 64,
                        "chunk_size": 4, "aggregation": "max", "topk": 3, "global_weight": .5})}


def apply_custom(cfg, payload):
    """Return a new resolved configuration, never mutate the project or run."""
    if not isinstance(payload, dict) or set(payload) - {"device", "cpu_threads", "num_workers", "search", "training", "seeds", "image_strategy", "patches", "augmentation"}:
        raise ValueError("Custom search accepts device, cpu_threads, num_workers, search, training, seeds, image_strategy, patches, and rotation augmentation.")
    for section in ("search", "training"):
        if not isinstance(payload.get(section, {}), dict):
            raise ValueError(f"custom.{section} must be an object.")
    if set(payload.get("training", {})) - TRAINING_KEYS:
        raise ValueError("Unsupported custom training setting.")
    augmentation = payload.get("augmentation", {})
    if not isinstance(augmentation, dict) or set(augmentation) - {"rotation90"}:
        raise ValueError("Only rotation90 augmentation is supported by Custom search.")
    if "rotation90" in augmentation and type(augmentation["rotation90"]) is not bool:
        raise ValueError("augmentation.rotation90 must be boolean.")
    if augmentation.get("rotation90") and cfg.get("task") != "vig":
        raise ValueError("Rotation augmentation is enabled only for the VIG task.")
    result = merge_dict(cfg, payload)
    if result.get("device") not in {"cpu", "cuda", "auto"}:
        raise ValueError("Device must be cpu, cuda, or auto.")
    result["cpu_threads"] = _number(result.get("cpu_threads", 4), "cpu_threads", 1, integer=True)
    result["num_workers"] = _number(result.get("num_workers", 0), "num_workers", 0, integer=True)
    # Search contracts replace specs atomically. A fixed spec must not inherit
    # the low/high fields of a previous range from recursive config merging.
    for section in ("space", "model_spaces"):
        if section in payload.get("search", {}):
            result["search"][section] = payload["search"][section]
    for key in TRAINING_KEYS - {"amp"}:
        result["training"][key] = _number(result["training"][key], "training." + key, 1, integer=True)
    if type(result["training"]["amp"]) is not bool:
        raise ValueError("training.amp must be boolean.")
    seeds = result.get("seeds")
    if not isinstance(seeds, list) or not seeds or len(set(seeds)) != len(seeds):
        raise ValueError("Provide a nonempty list of distinct training seeds.")
    for seed in seeds:
        _number(seed, "seeds", 0, 2**32 - 1, integer=True)
    result["pretrained"] = True
    result["previous_run"] = None
    result["search"] = validate_settings(result)
    result["search"].update(enabled=True, custom=True, contract_version=1)
    if result.get("image_strategy", "full_image") not in {"full_image", "global_patches"}:
        raise ValueError("image_strategy must be full_image or global_patches.")
    patches = result.get("patches", {})
    if not isinstance(patches, dict) or set(patches) - {"size", "overlap", "max_patches", "chunk_size", "aggregation", "topk", "global_weight"}:
        raise ValueError("Unsupported patches settings.")
    for key in ("size", "max_patches", "chunk_size", "topk"):
        if key in patches:
            _number(patches[key], "patches." + key, 1, integer=True)
    if "overlap" in patches:
        _number(patches["overlap"], "patches.overlap", 0, patches.get("size", 256) - 1, integer=True)
    if "global_weight" in patches:
        _number(patches["global_weight"], "patches.global_weight", 0, 1)
    if patches.get("aggregation", "max") not in {"max", "topk"}:
        raise ValueError("patches.aggregation must be max or topk.")
    for model in result["models"]:
        resolved_space(result, model)
    return validate_config(result)
