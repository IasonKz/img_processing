"use strict";
// Dependency-free behavioral DOM contract. Network is stubbed intentionally;
// backend/API and native-browser coverage live in separate tests.
const fs=require("node:fs"),path=require("node:path"),vm=require("node:vm"),assert=require("node:assert/strict");
const harness=require("./test_v4_ui.cjs"),{context,document,el,settle,boot,fetchMock}=harness;
const Element=document.constructor,ui=path.join(__dirname,"..","nilt","ui"),calls=[];
const clone=value=>JSON.parse(JSON.stringify(value));
Object.defineProperties(Element.prototype,{
  parentNode:{get(){return this.parentElement;}},
  tagName:{get(){return this.tag.toUpperCase();}},
  options:{get(){return this.querySelectorAll("option");}},
  style:{get(){return this._style||(this._style={});}},
  clientWidth:{get(){return 720;}},
  contentWindow:{get(){return this._contentWindow||(this._contentWindow={NiltEmbedded:{layout(){}},TopsegStudio:{selectTab(){}}});}},
});
Element.prototype.appendChild=function(child){if(child.parentElement){const siblings=child.parentElement.children,index=siblings.indexOf(child);if(index>=0)siblings.splice(index,1);}child.parentElement=this;this.children.push(child);return child;};
Element.prototype.insertBefore=function(child,before){const index=this.children.indexOf(before);child.parentElement=this;if(index>=0)this.children.splice(index,0,child);else this.children.push(child);return child;};
Element.prototype.getAttribute=function(name){return this.attributes[name]??null;};
Element.prototype.focus=function(){};
Element.prototype.setPointerCapture=function(){};
Element.prototype.getBoundingClientRect=function(){return {left:0,top:0,width:this.width||720,height:this.height||660};};
Element.prototype.dispatchEvent=function(event){event.target=this;for(const handler of this.handlers[event.type]||[])handler(event);};
Element.prototype.insertAdjacentHTML=function(position,markup){this.innerHTML=position==="afterbegin"?markup+this.innerHTML:this.innerHTML+markup;};
const drawing=new Proxy({measureText:text=>({width:String(text).length*6})},{get:(target,key)=>target[key]||(target[key]=()=>{})});
Element.prototype.getContext=function(){return drawing;};
document.createElement=tag=>new Element(tag);
document.fullscreenElement=null;
context.window=context;context.innerHeight=1000;context.scrollTo=()=>{};
context.addEventListener=(type,handler)=>document.addEventListener(type,handler);
context.requestAnimationFrame=handler=>queueMicrotask(handler);
context.ResizeObserver=class{observe(){}};
context.Event=class{constructor(type,options={}){this.type=type;Object.assign(this,options);}};
context.Image=class{constructor(){this.naturalWidth=600;this.naturalHeight=600;}set src(value){this._src=value;queueMicrotask(()=>this.onload?.());}get src(){return this._src;}};
context.URL=URL;context.Blob=Blob;
boot.tasks=["vig","top","bottom"];boot.datasets={vig:"C:/data/vig",top:"C:/data/top",bottom:"C:/data/bottom"};
boot.roi_datasets={top:{whole_image:"C:/data/top",label:"C:/roi/top/label"},bottom:{whole_image:"C:/data/bottom",pins:"C:/roi/bottom/pins"},vig:{whole_image:"C:/data/vig"}};
boot.roi_scopes={vig:"whole_image",top:"whole_image",bottom:"whole_image"};
function shape(id,kind,points,extra={}){return {id,kind,shape:"polygon",points,expected_points:clone(points),observed_points:null,source:"inferred",presence:"unknown",margin:.2,enabled:true,...extra};}
const topRois=[shape("label","label",[[80,90],[170,90],[170,130],[80,130]]),shape("inner_area","inner_area",[[160,160],[440,160],[440,440],[160,440]])];
const bottomRois=[shape("triangle","triangle",[[450,450],[510,510],[450,510]]),shape("square","square",[[500,260],[530,260],[530,300],[500,300]])];
function makeState(side,rois){return {side,images:[{id:side+"-image",name:side+"<unsafe>.png",unit_id:"C83:R1:C1",identity_confirmed:true,tray:"C83",split:"train",width:600,height:600,initial_label:"bad",annotation:{rois:clone(rois),quality:Object.fromEntries(rois.map(r=>[r.id,"unknown"])),geometry_reviewed:false,updated_at:"fixture"}}],exports:[],warnings:[],template:null,default_template:{schema:"inspection_roi_template.v1",side,reference_size:[600,600],outline:[[.1,.12],[.9,.12],[.9,.88],[.1,.88]],rois:rois.map(r=>({...clone(r),points:r.points.map(p=>p.map(v=>v/599))}))},job:{status:"idle"}};}
const states={top:makeState("top",topRois),bottom:makeState("bottom",bottomRois)};
context.fetch=async (url,options={})=>{
  const parsed=new URL(url,"http://localhost"),body=options.body?JSON.parse(options.body):null;
  if(!parsed.pathname.startsWith("/api/roi/"))return fetchMock(url,options);
  calls.push({path:parsed.pathname,body:clone(body),query:Object.fromEntries(parsed.searchParams)});
  const side=body?.side||parsed.searchParams.get("side")||"top",state=states[side];let result;
  if(parsed.pathname==="/api/roi/state")result=state;
  else if(parsed.pathname==="/api/roi/job")result={job:{status:"completed",action:"test"}};
  else if(parsed.pathname==="/api/roi/annotation"){
    const image=state.images.find(row=>row.id===body.image_id);assert.ok(image,"Known side/image in annotation payload");
    if(body.rois)image.annotation.rois=clone(body.rois);
    if(body.quality)image.annotation.quality=clone(body.quality);
    if(body.geometry_reviewed!==undefined)image.annotation.geometry_reviewed=body.geometry_reviewed;
    if(body.unit_id)image.unit_id=body.unit_id;
    result={state,summary:{}};
  }else if(parsed.pathname==="/api/roi/template"){state.template=clone(body.template);result={state,summary:{}};}
  else if(parsed.pathname==="/api/roi/classification"){boot.roi_scopes[side]=body.roi_scope;boot.datasets[side]=body.dataset||boot.roi_datasets[side][body.roi_scope]||"";result={config:boot};}
  else result={state,summary:{}};
  return {ok:true,json:async()=>clone(result)};
};
async function emit(element,type,extra={}){const event={type,target:element,preventDefault(){},...extra};for(const handler of element.handlers[type]||[])await handler(event);await settle();}
async function click(id){const element=typeof id==="string"?el(id):id;assert.equal(element.disabled,false,"Enabled control: "+element.id);await emit(element,"click");}
const lastAnnotation=()=>calls.filter(row=>row.path==="/api/roi/annotation").at(-1)?.body;

async function main(){
  await settle();
  vm.runInContext(fs.readFileSync(path.join(ui,"workspace.js"),"utf8"),context,{filename:"workspace.js"});
  vm.runInContext(fs.readFileSync(path.join(ui,"roi.js"),"utf8"),context,{filename:"roi.js"});
  context.WorkspaceStudio.selectFamily("roi");await settle();
  assert.equal(context.WorkspaceStudio.task(),"top");assert.equal(el("roi-navigation").hidden,false);
  assert.equal(document.querySelector('[data-workspace="vig"]').hidden,true);
  assert.equal(el("roi-shape-list").querySelectorAll("[data-roi-shape]").length,2);
  assert.equal(el("roi-image-list").innerHTML.includes("&lt;unsafe&gt;"),true);
  el("roi-folder").value="C:/input";await click("roi-import");
  assert.equal(calls.filter(row=>row.path==="/api/roi/import").at(-1).body.unit_id_strategy,"unconfirmed","Default import must not silently confirm view-specific filenames as unit IDs");
  await click("roi-approve");
  assert.equal(lastAnnotation().geometry_reviewed,true);
  assert.deepEqual(lastAnnotation().quality,{label:"unknown",inner_area:"unknown"},"Approving geometry must not set Good labels");
  el("roi-selected-quality").value="good";await emit(el("roi-selected-quality"),"change");await click("roi-save-quality");
  assert.equal(lastAnnotation().quality.label,"good");assert.equal("geometry_reviewed" in lastAnnotation(),false,"Quality-only save must not alter geometry approval");
  el("roi-margin").value="0.5";await emit(el("roi-margin"),"change");await click("roi-save");
  assert.equal(lastAnnotation().geometry_reviewed,false,"Changed crop needs a new geometry review");
  assert.equal(lastAnnotation().quality.label,"unknown","Changed crop must not retain an old Good target");
  assert.equal(lastAnnotation().rois[0].observed_points,null,"Changing a crop margin is not observing a material boundary");
  await click("roi-confirm-visible");await click("roi-save");
  assert.ok(lastAnnotation().rois[0].observed_points,"Explicit visibility can provide a segmentation target");
  await click("roi-absent");await click("roi-save");
  assert.equal(lastAnnotation().rois[0].presence,"absent");assert.equal(lastAnnotation().rois[0].observed_points,null);
  await click("roi-unknown-visible");await click("roi-save");
  assert.equal(lastAnnotation().rois[0].presence,"unknown","Occlusion is not evidence of absent material");
  const canvas=el("roi-canvas"),scale=Math.min(canvas.width/600,canvas.height/600)*.94;
  const px=(canvas.width-600*scale)/2+80*scale,py=(canvas.height-600*scale)/2+90*scale;
  await emit(canvas,"pointerdown",{clientX:px,clientY:py,button:0,pointerId:1});
  await emit(canvas,"pointermove",{clientX:px+20,clientY:py,pointerId:1});await emit(canvas,"pointerup",{pointerId:1});await click("roi-save");
  assert.ok(lastAnnotation().rois[0].points[0][0]>80,"Dragging changes the selected ROI vertex");
  assert.deepEqual(lastAnnotation().rois[0].expected_points[0],[80,90],"Expected geometry is retained separately from edits");
  assert.equal(lastAnnotation().rois[0].observed_points,null,"Dragging expected crop support must not confirm visible material");
  await click(document.querySelector('[data-roi-step="quality"]'));await click("roi-all-good");await click("roi-save-quality");
  assert.equal(Object.values(lastAnnotation().quality).every(value=>value==="good"),true);
  assert.ok(el("roi-method").options.some(option=>option.value==="hybrid"),"Hybrid model/CV localization must be selectable");
  el("roi-method").value="hybrid";el("roi-localizer-model").value="C:/models/best.pt";el("roi-rotation").value="1";
  await click("roi-localize-one");const localization=calls.filter(row=>row.path==="/api/roi/localize").at(-1).body;
  assert.equal(localization.method,"hybrid");assert.equal(localization.quarter_turn,1);assert.deepEqual(localization.image_ids,["top-image"]);
  el("roi-selected-quality").value="bad";await emit(el("roi-selected-quality"),"change");
  context.WorkspaceStudio.selectTask("bottom");await settle();
  assert.equal(states.top.images[0].annotation.quality.label,"bad","Switching views must retain the previous view's edited label");
  assert.equal(el("roi-grid-controls").hidden,false);
  await click("roi-grid-generate");await click("roi-save");
  assert.equal(lastAnnotation().side,"bottom");assert.equal(lastAnnotation().rois.filter(row=>row.kind==="pins").length,16);
  assert.equal(lastAnnotation().rois.length,18);assert.equal(lastAnnotation().rois[0].id,"pin_r1_c1");assert.equal(lastAnnotation().rois[15].id,"pin_r4_c4");
  assert.equal(lastAnnotation().rois.filter(row=>row.kind==="pins").every(row=>row.observed_points===null),true);
  await click(document.querySelector('[data-roi-step="template"]'));
  await click("roi-edit-outline");assert.equal(el("roi-selected").value,"reference_die_outline");
  await click("roi-save-template");let bottomTemplate=calls.filter(row=>row.path==="/api/roi/template").at(-1).body.template;
  assert.deepEqual(bottomTemplate.outline,states.bottom.default_template.outline,"BOTTOM keeps the non-full-image reference outline");
  assert.equal(bottomTemplate.rois.length,18,"Outline helper must not create a nineteenth inspection ROI");
  const outlinePx=(canvas.width-600*scale)/2+.1*599*scale,outlinePy=(canvas.height-600*scale)/2+.12*599*scale;
  await emit(canvas,"pointerdown",{clientX:outlinePx,clientY:outlinePy,button:0,pointerId:2});
  await emit(canvas,"pointermove",{clientX:outlinePx+15,clientY:outlinePy,pointerId:2});await emit(canvas,"pointerup",{pointerId:2});
  await click("roi-save-template");bottomTemplate=calls.filter(row=>row.path==="/api/roi/template").at(-1).body.template;
  assert.ok(bottomTemplate.outline[0][0]>.1,"BOTTOM die outline is editable on the reference canvas");
  assert.equal(bottomTemplate.rois.length,18);await click("roi-save");assert.equal(lastAnnotation().rois.length,18,"Reference outline is excluded from production annotations");
  context.WorkspaceStudio.selectFamily("segmentation");await settle();
  assert.equal(context.WorkspaceStudio.task(),"bottom");assert.equal(document.querySelector('[data-workspace="bottom"]').hidden,false);
  context.WorkspaceStudio.selectFamily("classification");context.WorkspaceStudio.selectTask("bottom");await settle();
  assert.equal(el("classification-scope-label").hidden,false);
  assert.deepEqual(el("classification-scope").options.map(option=>option.value),["whole_image","pins","triangle","square"]);
  context.WorkspaceStudio.selectTask("top");await settle();await context.WorkspaceStudio.setScope("label");await settle();
  assert.equal(el("dataset").value,"C:/roi/top/label");assert.equal(context.WorkspaceStudio.roiScope(),"label");
  await context.WorkspaceStudio.setScope("whole_image");await settle();
  assert.equal(el("dataset").value,"C:/data/top","Returning to whole-image classification restores its independent dataset");
  assert.equal(context.WorkspaceStudio.roiScope(),"whole_image");
  console.log("PASS: ROI/workspace DOM handlers, family/view restrictions, scope dataset restoration, safe default import payload, geometry-quality separation, crop-label invalidation, observed/absent/occluded controls, vertex editing with expected geometry retained, localization payloads, 16-pin generation, editable BOTTOM outline without extra inspection ROI, draft persistence and XSS escaping. Canvas rendering/layout and live API are outside this stub test.");
}
main().catch(error=>{console.error(error);process.exitCode=1;});
