# Windows 11 installation

This guide applies to v3. Install into a fresh project folder and create a new
environment on each PC. Do not move a virtual environment between machines.
Administrative access is not required for the project itself; corporate policies
may require IT to install Python or an NVIDIA driver.

## Supported setup target

- Windows 11; Python 3.11 or 3.12, 64-bit.
- Laptop: CPU PyTorch.
- Workstation: NVIDIA CUDA-capable GPU, approximately 16 GB VRAM and 32–64 GB RAM.
- A local disk with room for source images, pretrained weights and multiple trial
  checkpoints. Run directories can become much larger than the source code ZIP.

The setup uses the official matched pair **torch 2.7.1 / torchvision 0.22.1**.
The official previous-version instructions list both CPU and CUDA 12.8 wheels for
Windows. The pin is a compatibility choice, not a claim that it is the latest
release. See [PyTorch's official wheel instructions](https://pytorch.org/get-started/previous-versions/).

## Assisted setup

Open PowerShell in the project root (the directory containing `inspection.py`).
Choose one command:

```powershell
# CPU laptop
powershell -NoProfile -File .\scripts\setup_windows.ps1 -Device cpu

# NVIDIA workstation
powershell -NoProfile -File .\scripts\setup_windows.ps1 -Device cuda
```

For Python 3.12 add `-PythonVersion 3.12`. For ONNX export dependencies add
`-WithExport`. The script creates `.venv`, installs packages, performs `pip check`,
and verifies the chosen device. CUDA setup includes a small actual GPU tensor
operation; a machine with an unusable GPU is not silently accepted as CPU-only.

The script does not change the PowerShell execution policy. If script execution
is blocked, use the individual commands below in accordance with company policy.

## Individual PowerShell commands

Replace the path on the first line. Use `py -3.12` instead of `py -3.11` if needed.
Stop if any command reports an error.

```powershell
cd "C:\YOUR_PATH\visual_inspection_pipeline_v3"
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Install **one** of these matched PyTorch pairs:

```powershell
# Laptop only
.\.venv\Scripts\python.exe -m pip install torch==2.7.1 torchvision==0.22.1 --index-url https://download.pytorch.org/whl/cpu

# NVIDIA workstation only
.\.venv\Scripts\python.exe -m pip install torch==2.7.1 torchvision==0.22.1 --index-url https://download.pytorch.org/whl/cu128
```

Then check dependencies:

```powershell
.\.venv\Scripts\python.exe -m pip check
.\.venv\Scripts\python.exe -c "import torch, torchvision; print('torch:', torch.__version__); print('torchvision:', torchvision.__version__); print('CUDA available:', torch.cuda.is_available())"
```

On the workstation also run:

```powershell
nvidia-smi
.\.venv\Scripts\python.exe -c "import torch; assert torch.cuda.is_available(), 'CUDA is unavailable'; x=torch.ones(4,device='cuda'); print('GPU:',torch.cuda.get_device_name(0)); print('VRAM GiB:',round(torch.cuda.get_device_properties(0).total_memory/2**30,2)); print('GPU check:',(x+x).cpu().tolist())"
```

A CUDA wheel includes its CUDA runtime dependencies; this workflow does not
compile custom CUDA code. A compatible NVIDIA driver is still required. If GPU
initialization or the tensor check fails, resolve the driver/wheel/device issue
before choosing a workstation profile. Do not interpret a CPU fallback as GPU
training.

Optional ONNX tools:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-export.txt
.\.venv\Scripts\python.exe -m pip check
```

## Configure paths and provision weights

Edit `project.yaml`, especially `tasks.vig.dataset_root`. Forward slashes in
Windows paths are convenient, for example `'C:/inspection_data/vig'`. Relative
paths resolve from the configuration file. Preserve the remaining task settings.

With internet available, provision the selected profile's public weights:

```powershell
.\.venv\Scripts\python.exe inspection.py download-weights --config project.yaml --profile laptop --task vig
```

Replace `laptop` with your GPU profile when applicable. This command downloads
public pretrained weights, not image data. You can instead download individual
architectures explicitly:

```powershell
.\.venv\Scripts\python.exe download_weights.py --output weights --models resnet18 efficientnet_b0
```

PatchCore uses its configured backbone's weights. Copy the resulting `weights`
folder to the offline machine. Training does not download missing weights.

## Offline installation

Prepare wheels on a connected **Windows machine using the same Python version
and architecture as the destination**. This is package provisioning only; no
company images are needed on that machine. Create separate CPU and CUDA
wheelhouses to avoid ambiguous torch builds.

After creating the provisioning environment, for a CPU wheelhouse:

```powershell
.\.venv\Scripts\python.exe -m pip download --only-binary=:all: --dest wheelhouse_cpu -r requirements.txt -r requirements-export.txt
.\.venv\Scripts\python.exe -m pip download --only-binary=:all: --dest wheelhouse_cpu torch==2.7.1 torchvision==0.22.1 --index-url https://download.pytorch.org/whl/cpu
```

For CUDA, use a separate `wheelhouse_cuda` directory and the `cu128` index instead
of `cpu`. CUDA wheels are large. Copy the project, the appropriate wheelhouse and
the pretrained `weights` folder to the target. Then:

```powershell
# Example CPU installation with no package-index network access
powershell -NoProfile -File .\scripts\setup_windows.ps1 -Device cpu -OfflineWheelhouse "D:\wheelhouse_cpu" -WithExport
```

If PowerShell scripts are unavailable, create the environment with `py -3.11 -m
venv .venv`, then use these individual commands:

```powershell
.\.venv\Scripts\python.exe -m pip install --no-index --find-links "D:\wheelhouse_cpu" -r requirements.txt torch==2.7.1 torchvision==0.22.1
.\.venv\Scripts\python.exe -m pip install --no-index --find-links "D:\wheelhouse_cpu" -r requirements-export.txt
.\.venv\Scripts\python.exe -m pip check
```

Use the CUDA wheelhouse on the GPU machine. Missing wheels cause a clear failure;
`--no-index` prevents falling back to a public package index.

## Privacy during operation

Training and inference use local image paths and locally provisioned weights.
The dashboard binds to loopback and serves its own assets, without a CDN.
ONNX Runtime telemetry is disabled in code before inference sessions are created;
no environment-variable opt-out is required. Hardware/time measurements shown in
the project reports are local diagnostic logs, not remote telemetry. Package and
public-weight downloads occur only in the explicit online provisioning steps.

## Local preflight and first launch

```powershell
.\.venv\Scripts\python.exe inspection.py doctor --config project.yaml --profile laptop --task vig
.\.venv\Scripts\python.exe inspection.py dashboard --config project.yaml
```

Change the doctor's profile on a GPU machine. The dashboard prints its loopback
URL. No virtual-environment activation is necessary. Select `.venv\Scripts\python.exe`
as the PyCharm interpreter if you prefer running scripts from the IDE.

Before a long search, run the v3 synthetic end-to-end installation check in a
new output directory:

```powershell
.\.venv\Scripts\python.exe scripts/smoke_v3.py --output ..\smoke_check
```

It creates synthetic rectangular PNG/BMP images, runs one small Optuna search
with two ResNet18 epochs, exercises all four decision modes and generates a
report. Without `--weights`, it uses an untrained backbone solely for testing the
installation. It does not read company images or download weights.

To use local pretrained ResNet18 weights and test ONNX too:

```powershell
.\.venv\Scripts\python.exe scripts/smoke_v3.py --output ..\smoke_check_pretrained --weights .\weights --with-onnx
```

Install `requirements-export.txt` before requesting `--with-onnx`. The weights
directory must already contain the expected ResNet18 pretrained file. ONNX
checks cover argmax and scores-only export/inference. Every smoke run needs a new
or empty output directory. Look for `SMOKE PASSED` and `smoke_result.json`.

Synthetic accuracy is not industrial performance evidence. A machine that
cannot complete the small check should have its diagnostics inspected before a
long dataset search. The separate legacy `inspection.py smoke` command remains
available; without `--with-models` it checks only data/decision plumbing.

## Moving to another PC

Transfer code, configuration, weights and the run/package you need. Recreate
`.venv`; `__pycache__` directories need not be transferred. Re-point the dataset
path in a new-run configuration. For an existing trained run, follow the
training-package restore instructions in `V3_GUIDE.md` rather than editing saved
manifests or `selected.json` by hand. Matching dataset contents are verified.

Keep CPU/GPU environment records with important results. A recorded package
version list is useful evidence, but is not a guarantee of identical floating
point results across different devices.
