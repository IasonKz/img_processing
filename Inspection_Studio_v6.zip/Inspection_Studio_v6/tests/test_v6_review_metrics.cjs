"use strict";
const assert=require('node:assert/strict'),vm=require('node:vm');
const h=require('./test_v4_ui.cjs');
const {context,el,click,settle}=h;
(async()=>{
  await settle();
  vm.runInContext(`reviewData={metrics:{dataset_reference:{n_images:4,n_automatic:2,n_review:2,
    automatic_accuracy:1,automation_rate:.5,review_rate:.5,bad_escape_rate:0,good_reject_rate:0,
    bad_to_bad:1,good_to_good:1,bad_to_review:1,good_to_review:1}}};renderReviewMetrics();`,context);
  const summary=el('review-summary').innerHTML;
  assert.ok(summary.includes('100.0%'));
  assert.ok(summary.includes('Automated coverage'));
  assert.ok(summary.includes('Sent to human review'));
  assert.equal((summary.match(/50.0%/g)||[]).length,2);
  assert.ok(el('review-confusion').innerHTML.includes('1 bad · 1 good'));
  vm.runInContext(`reviewData={metrics:{dataset_reference:{n:0,n_total:2,n_labeled:2,
    n_review:2,n_automatic:0,selective_accuracy:null,accuracy:null,
    decision_coverage:0,review_rate:1,bad_sent_to_review:1,good_sent_to_review:1}}};renderReviewMetrics();`,context);
  assert.ok(!el('review-confusion').textContent.includes('No labeled'));
  assert.ok(el('review-confusion').innerHTML.includes('Sent to REVIEW: 1 bad · 1 good'));
  assert.ok(el('review-summary').innerHTML.includes('0.0%'));
  const original=context.fetch;
  context.fetch=async(url,options={})=>{
    if(new URL(url,'http://localhost').pathname!='/api/review-compare')return original(url,options);
    return {ok:true,json:async()=>({n_images:2,n_labeled:2,sessions:[{name:'Guarded',kind:'workflow',
      metrics:{automatic_accuracy:1,decision_coverage:.5,review_rate:.5,bad_escape_rate:0,good_reject_rate:0}}]})};
  };
  el('session-compare-options').querySelectorAll('input').forEach(e=>e.checked=true);
  await click('session-compare');
  const comparison=el('session-compare-result').innerHTML;
  assert.ok(comparison.includes('Accuracy · automated only'));
  assert.ok(comparison.includes('Automated coverage'));
  assert.ok(comparison.includes('Human review'));
  assert.ok(!comparison.includes('Balanced accuracy'));
  assert.ok(el('session-compare-note').textContent.includes('Review is abstention'));
  console.log('PASS: triage and all-review metrics preserve conditional accuracy, coverage, review counts and honest session comparisons.');
})().catch(e=>{console.error(e);process.exitCode=1;});
