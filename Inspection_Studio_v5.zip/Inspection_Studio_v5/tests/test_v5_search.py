"""Custom Optuna contracts and persisted ask/tell scheduling regression tests."""
from __future__ import annotations

import importlib.util
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch

from nilt.common import DEFAULTS, PROFILES, merge_dict, read_json, sha_file, write_json
from nilt.custom_search import apply_custom, defaults_for, finite_choices, parameter_spec
from nilt import search


def config():
    return merge_dict(merge_dict(DEFAULTS, PROFILES["laptop"]), {
        "profile": "laptop", "task": "vig", "data_root": "/tmp/data",
        "weights_dir": "/tmp/weights", "output_root": "/tmp/results",
        "search": {"enqueue_presets": False, "minimum_trial_seconds": .001}})


class ContractTests(unittest.TestCase):
    def test_defaults_roundtrip_pretrained_and_no_mutation(self):
        cfg = config()
        original = merge_dict({}, cfg)
        payload = defaults_for(cfg)
        payload["search"]["sampler"] = "random"
        actual = apply_custom(cfg, payload)
        self.assertEqual(cfg, original)
        self.assertEqual(actual["search"]["sampler"], "random")
        self.assertTrue(actual["pretrained"])
        self.assertTrue(actual["search"]["custom"])

    def test_unknown_fields_and_executable_values_rejected(self):
        cfg = config()
        for payload in ({"code": "exec('x')"}, {"search": {"typo": 2}},
                        {"training": {"learning_rate": .01}},
                        {"search": {"space": {"run_python": [1]}}}):
            with self.subTest(payload=payload), self.assertRaises(ValueError):
                apply_custom(cfg, payload)

    def test_finite_positive_budget(self):
        for budget in (0, -1, float("inf"), float("nan"), True):
            with self.subTest(budget=budget), self.assertRaises(ValueError):
                apply_custom(config(), {"search": {"total_budget_seconds": budget}})

    def test_runtime_selection_and_budget_are_independent_of_profile(self):
        for profile in ("laptop", "workstation", "workstation_large"):
            for device in ("cpu", "cuda", "auto"):
                with self.subTest(profile=profile, device=device):
                    cfg = config()
                    cfg["profile"] = profile
                    actual = apply_custom(cfg, {"device": device, "cpu_threads": 12, "num_workers": 3,
                        "search": {"total_budget_seconds": 48 * 3600, "max_trials_per_model": 50000}})
                    self.assertEqual(actual["device"], device)
                    self.assertEqual(actual["cpu_threads"], 12)
                    self.assertEqual(actual["num_workers"], 3)
                    self.assertEqual(actual["search"]["total_budget_seconds"], 48 * 3600)
                    self.assertEqual(actual["search"]["max_trials_per_model"], 50000)

    def test_runtime_rejects_invalid_controls(self):
        for payload in ({"device": "other"}, {"cpu_threads": 0}, {"num_workers": -1},
                        {"cpu_threads": True}, {"num_workers": 1.5}):
            with self.subTest(payload=payload), self.assertRaises(ValueError):
                apply_custom(config(), payload)

    def test_grid_memory_guard_is_explicit_and_configurable(self):
        payload = {"search": {"sampler": "grid", "space": {
            "mode": ["head_only"], "optimizer": ["adamw"], "scheduler": ["constant"],
            "imbalance": ["none"], "effective_batch_size": [4], "weight_decay": 0,
            "head_learning_rate": {"kind": "range", "low": .00001, "high": .10001,
                                   "step": .00001, "log": False}}}}
        with self.assertRaisesRegex(ValueError, "max_grid_combinations"):
            apply_custom(config(), payload)
        payload["search"]["max_grid_combinations"] = 12000
        cfg = apply_custom(config(), payload)
        self.assertEqual(cfg["search"]["max_grid_combinations"], 12000)
        grid_values = finite_choices(search.resolved_space(cfg, "resnet18")["head_learning_rate"],
                                     limit=cfg["search"]["max_grid_combinations"])
        self.assertEqual(len(grid_values), 10001)
        payload["search"]["max_grid_combinations"] = 0
        with self.assertRaises(ValueError):
            apply_custom(config(), payload)

    def test_parameter_fixed_choices_and_logrange(self):
        self.assertEqual(parameter_spec("learning_rate", .001)["kind"], "fixed")
        choices = parameter_spec("learning_rate", {"kind": "choices", "values": [.001, .003]})
        self.assertEqual(finite_choices(choices), [.001, .003])
        self.assertTrue(parameter_spec("learning_rate", [1e-5, 1e-3])["log"])
        for invalid in ({"kind": "range", "low": 0, "high": 1, "log": True},
                        {"kind": "choices", "values": [.1, .1]},
                        {"kind": "fixed"}, {"kind": "range", "low": 2, "high": 1}):
            with self.assertRaises(ValueError):
                parameter_spec("learning_rate", invalid)

    def test_fixed_specs_replace_prior_ranges_atomically(self):
        cfg = apply_custom(config(), defaults_for(config()))
        actual = apply_custom(cfg, {"search": {"space": {"learning_rate": {"kind": "fixed", "value": .001}}}})
        self.assertEqual(actual["search"]["space"]["learning_rate"], {"kind": "fixed", "value": .001})

    def test_batch_divisibility_and_warmup_guard(self):
        with self.assertRaisesRegex(ValueError, "multiples"):
            apply_custom(config(), {"training": {"batch_size": 3}, "search": {"space": {"effective_batch_size": [4]}}})
        with self.assertRaisesRegex(ValueError, "Warmup"):
            apply_custom(config(), {"training": {"epochs": 4}, "search": {"space": {"warmup_epochs": [4]}}})

    def test_grid_requires_finite_active_parameters_only(self):
        cfg = config()
        payload = {"search": {"sampler": "grid", "space": {
            "mode": ["head_only"], "optimizer": ["adamw"], "scheduler": ["constant"],
            "imbalance": ["none"], "effective_batch_size": [4],
            "head_learning_rate": {"kind": "choices", "values": [.001, .003]},
            "weight_decay": 0}}}
        self.assertEqual(apply_custom(cfg, payload)["search"]["sampler"], "grid")
        payload["search"]["space"]["mode"] = ["full"]
        with self.assertRaisesRegex(ValueError, "Grid"):
            apply_custom(cfg, payload)

    def test_rotation_only_for_vig_and_patch_contract(self):
        actual = apply_custom(config(), {"augmentation": {"rotation90": True},
            "image_strategy": "global_patches", "patches": {"size": 128, "overlap": 32}})
        self.assertTrue(actual["augmentation"]["rotation90"])
        cfg = config()
        cfg["task"] = "top"
        with self.assertRaisesRegex(ValueError, "VIG"):
            apply_custom(cfg, {"augmentation": {"rotation90": True}})
        with self.assertRaises(ValueError):
            apply_custom(config(), {"patches": {"size": 64, "overlap": 64}})

    def test_contract_immutable_on_resume(self):
        with tempfile.TemporaryDirectory() as root:
            cfg = config()
            search._persist_contract(root, cfg)
            search._persist_contract(root, cfg)
            cfg["search"]["sampler"] = "random"
            with self.assertRaisesRegex(ValueError, "immutable"):
                search._persist_contract(root, cfg)

    def test_objective_selection_and_patchcore_restriction(self):
        for metric in ("validation_ap", "validation_roc_auc", "validation_balanced_accuracy"):
            cfg = apply_custom(config(), {"search": {"objective": metric}})
            self.assertEqual(cfg["search"]["objective"], metric)
        with self.assertRaisesRegex(ValueError, "objective"):
            apply_custom(config(), {"search": {"objective": "test_ap"}})
        cfg = config()
        cfg["models"] = ["patchcore"]
        with self.assertRaisesRegex(ValueError, "PatchCore"):
            apply_custom(cfg, {"search": {"objective": "validation_roc_auc"}})

    def test_per_model_overrides_are_independent(self):
        cfg = config()
        cfg["models"] = ["resnet18", "efficientnet_b0"]
        cfg = apply_custom(cfg, {"search": {
            "space": {"head_learning_rate": {"kind": "fixed", "value": .001}},
            "model_spaces": {"efficientnet_b0": {"head_learning_rate": {"kind": "fixed", "value": .0003}}}}})
        self.assertEqual(search.resolved_space(cfg, "resnet18")["head_learning_rate"]["value"], .001)
        self.assertEqual(search.resolved_space(cfg, "efficientnet_b0")["head_learning_rate"]["value"], .0003)


@unittest.skipUnless(importlib.util.find_spec("optuna"), "Optuna not installed")
class OptunaSchedulingTests(unittest.TestCase):
    def test_metric_optimization_keeps_average_precision_distinct(self):
        cfg = apply_custom(config(), {"search": {"objective": "validation_roc_auc"}})
        with tempfile.TemporaryDirectory() as root:
            run = Path(root)
            study = search._study("resnet18", cfg, run)

            def train(name, seed, rows, config, target, progress_callback, **kwargs):
                target.mkdir(parents=True, exist_ok=True)
                checkpoint = target / "best.pt"
                checkpoint.write_bytes(b"test-checkpoint")
                progress_callback({"epoch": 1, "status": "completed", "best_val_pr_auc_bad": .65,
                                   "best_objective_value": .89, "finetune_epochs": 1})
                write_json(target / "completed.json", {"best_val_pr_auc_bad": .65,
                    "best_objective_value": .89, "objective_metric": "validation_roc_auc",
                    "checkpoint_sha256": sha_file(checkpoint), "kind": "supervised", "epochs_ran": 1})
                return checkpoint

            with patch("nilt.engine.train_one", train), patch.object(search, "_clean_memory"):
                result = search._run_trial(run, "resnet18", study, [], cfg, {"resnet18": study}, time.time() + 10, time.time() + 20)
            self.assertEqual(result, "complete")
            self.assertEqual(study.best_value, .89)
            row = search._trial_rows({"resnet18": study})[0]
            self.assertEqual(row["validation_ap"], .65)
            self.assertEqual(row["objective"], "validation_roc_auc")
            status = search._publish(run, {"resnet18": study}, "SEARCHING")
            self.assertEqual(status["best_validation_ap"]["resnet18"], .65)
            self.assertEqual(status["best_objective_value"]["resnet18"], .89)
            (run / "manifest.csv").write_text("id,split\n1,train\n", encoding="utf-8")
            shortlist = search._freeze_shortlist(run, {"resnet18": study}, cfg)
            self.assertEqual(shortlist["candidates"][0]["val_pr_auc_bad"], .65)
            self.assertEqual(shortlist["candidates"][0]["search_objective_value"], .89)

    def test_reopening_study_with_changed_objective_is_rejected(self):
        cfg = config()
        with tempfile.TemporaryDirectory() as root:
            study = search._study("resnet18", cfg, root)
            study.tell(study.ask(), .5)
            cfg["search"]["objective"] = "validation_roc_auc"
            with self.assertRaisesRegex(ValueError, "different objective"):
                search._study("resnet18", cfg, root)

    def test_all_sampler_and_pruner_factories(self):
        import optuna
        cfg = config()
        for sampler, kind in (("random", optuna.samplers.RandomSampler), ("tpe", optuna.samplers.TPESampler)):
            cfg["search"]["sampler"] = sampler
            self.assertIsInstance(search._sampler("resnet18", cfg), kind)
        for name, kind in (("none", optuna.pruners.NopPruner), ("median", optuna.pruners.MedianPruner),
                           ("hyperband", optuna.pruners.HyperbandPruner),
                           ("successive_halving", optuna.pruners.SuccessiveHalvingPruner)):
            cfg["search"]["pruner"] = name
            self.assertIsInstance(search._pruner(cfg), kind)

    def test_grid_ask_tell_finishes_without_study_stop_error(self):
        cfg = apply_custom(config(), {"search": {"sampler": "grid", "space": {
            "mode": ["head_only"], "optimizer": ["adamw"], "scheduler": ["constant"],
            "imbalance": ["none"], "effective_batch_size": [4],
            "head_learning_rate": {"kind": "choices", "values": [.001, .003]}, "weight_decay": 0}}})
        with tempfile.TemporaryDirectory() as root:
            study = search._study("resnet18", cfg, root)
            seen = set()
            for _ in range(2):
                trial, resumed = search._resume_or_ask(study)
                self.assertFalse(resumed)
                proposed = search.suggest_config(trial, "resnet18", cfg)
                seen.add(proposed["training"]["head_learning_rate"])
                study.tell(trial, .5)
            self.assertEqual(seen, {.001, .003})
            self.assertEqual(search._architecture_stop_reason(study, search.search_settings(cfg)), "grid_exhausted")

    def test_study_patience_and_failure_cap_exclude_timeouts(self):
        import optuna
        study = optuna.create_study(direction="maximize")
        settings = search.search_settings(config())
        settings.update(study_patience_trials=2, minimum_improvement=.01, max_failed_trials_per_model=1)
        trial = study.ask()
        trial.set_user_attr("outcome", "TIMEOUT")
        study.tell(trial, state=optuna.trial.TrialState.FAIL)
        self.assertIsNone(search._architecture_stop_reason(study, settings))
        for value in (.5, .501, .502):
            study.tell(study.ask(), value)
        self.assertEqual(search._architecture_stop_reason(study, settings), "study_patience")
        trial = study.ask()
        trial.set_user_attr("outcome", "OOM")
        study.tell(trial, state=optuna.trial.TrialState.FAIL)
        self.assertEqual(search._architecture_stop_reason(study, settings), "failure_limit")

    def test_conditional_sgd_momentum_and_finetuning(self):
        import optuna
        cfg = apply_custom(config(), {"search": {"space": {
            "mode": "full", "optimizer": "sgd", "momentum": .85,
            "warmup_epochs": 1, "learning_rate": .00002,
            "head_learning_rate": .001, "effective_batch_size": [8]}}})
        trial = optuna.create_study().ask()
        actual = search.suggest_config(trial, "resnet18", cfg)
        self.assertEqual(actual["training"]["momentum"], .85)
        self.assertEqual(actual["training"]["accumulation_steps"], 8)
        self.assertEqual(actual["training"]["learning_rate"], .00002)

    def test_timed_out_trial_is_terminal_without_zero_score(self):
        from nilt.engine import TrainingStopped
        cfg = config()
        cfg["search"]["trial_timeout_seconds"] = 1
        with tempfile.TemporaryDirectory() as root:
            run = Path(root)
            study = search._study("resnet18", cfg, run)
            with patch("nilt.engine.train_one", side_effect=TrainingStopped("trial_time_slice")), patch.object(search, "_clean_memory"):
                result = search._run_trial(run, "resnet18", study, [], cfg, {"resnet18": study}, time.time() + 5, time.time() + 10)
            self.assertEqual(result, "time_slice")
            self.assertEqual(study.trials[0].user_attrs["outcome"], "TIMEOUT")
            self.assertIsNone(study.trials[0].value)
            trial, resumed = search._resume_or_ask(study)
            self.assertFalse(resumed)
            self.assertEqual(trial.number, 1)
            status = search._publish(run, {"resnet18": study}, "SEARCHING")
            self.assertEqual(status["failed_trials"], 0)
            self.assertEqual(status["timed_out_trials"], 1)

    def test_paused_trial_cumulative_timeout_checked_before_training(self):
        cfg = config()
        cfg["search"]["trial_timeout_seconds"] = 10
        with tempfile.TemporaryDirectory() as root:
            run = Path(root)
            study = search._study("resnet18", cfg, run)
            trial = study.ask()
            target = run / "search/resnet18/trial_00000/config.json"
            write_json(target, cfg)
            trial.set_user_attr("trial_config_sha256", sha_file(target))
            trial.set_user_attr("elapsed_seconds", 10.)
            with patch("nilt.engine.train_one", side_effect=AssertionError("No remaining trial budget")), patch.object(search, "_clean_memory"):
                result = search._run_trial(run, "resnet18", study, [], cfg, {"resnet18": study}, time.time() + 20, time.time() + 30)
            self.assertEqual(result, "time_slice")
            self.assertEqual(study.trials[0].user_attrs["outcome"], "TIMEOUT")

    def test_round_robin_timeouts_do_not_starve_later_trials(self):
        from nilt.engine import TrainingStopped
        cfg = config()
        cfg["models"] = ["resnet18", "efficientnet_b0"]
        cfg["search"].update(max_trials_per_model=2, trial_timeout_seconds=1)
        seen = []

        def train(name, seed, rows, config, target, **kwargs):
            seen.append((name, target.name, {row["split"] for row in rows}))
            raise TrainingStopped("trial_time_slice")

        with tempfile.TemporaryDirectory() as root:
            run = Path(root)
            with patch("nilt.workflow.open_run", return_value=(cfg, [{"split": s} for s in ("train", "val", "threshold", "selection", "test")])), \
                 patch("nilt.workflow.verify_sources"), patch("nilt.engine.check_weights"), \
                 patch("nilt.engine.train_one", train), patch.object(search, "_record_environment"), patch.object(search, "_clean_memory"):
                search.run_search(run, finalize=False)
            self.assertEqual([(name, trial) for name, trial, _ in seen], [
                ("resnet18", "trial_00000"), ("efficientnet_b0", "trial_00000"),
                ("resnet18", "trial_00001"), ("efficientnet_b0", "trial_00001")])
            self.assertTrue(all(splits == {"train", "val"} for _, _, splits in seen))
            status = read_json(run / "search_status.json")
            self.assertEqual(status["timed_out_trials"], 4)
            self.assertEqual(status["failed_trials"], 0)
            self.assertEqual(status["architecture_stops"], {"resnet18": "trial_limit", "efficientnet_b0": "trial_limit"})


if __name__ == "__main__":
    unittest.main()
