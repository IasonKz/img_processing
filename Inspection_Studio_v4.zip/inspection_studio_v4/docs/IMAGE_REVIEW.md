# Image review and reference labels

**Image review** displays the copied image, model prediction, reference tag, and operator review tag together. Records appear as classification or workflow execution publishes them. The gallery reads completed per-image records, so the entire batch need not finish before review begins.

## Three separate pieces of evidence

| Field | Source | Meaning |
| --- | --- | --- |
| Prediction | Saved model decision or composed workflow | What the software decided |
| Dataset reference | Original `good`/`bad` folder at classification time | Your original supplied tag |
| Operator review | Explicit good/bad/unreviewed action and note | A later human assessment |

The review operation does not overwrite the original image, move it to another source folder, or change the saved prediction. Operator tags and their history are stored separately in the classification output. Returning a record to unreviewed removes its current manual override, not its historical record.

## Review a batch

1. Classify with copied images enabled. For reference comparison, also mark the input as labeled.
2. In **Image review**, select the output session.
3. Filter by prediction, reference label, or review status. Inspect disagreements first when diagnosing errors.
4. Open an image, compare the prediction and supplied tag, and record an operator tag plus a note where useful.
5. Inspect the resulting metric scope before interpreting accuracy or error rates.

The preview is read from a recorded output copy. A run made without image copies still has prediction records, but cannot show a copied-image preview. Unreadable or failed inputs are visible as errors and must not be interpreted as accepted good images.

Use **Compare selected sessions** to compare two to four recorded classification or workflow sessions. Compare matched image identities with consistent reference labels; missing, changed, or unmatched inputs must not be treated as a measured improvement. This is the practical way to check whether an ordered workflow helps against the same labeled batch compared with its individual decisions.

## Metric scopes

| Scope | Denominator and labels | Suitable interpretation |
| --- | --- | --- |
| `dataset_reference` | Classified labeled records, using original tags | Prediction comparison with the supplied dataset |
| `reviewed_only` | Manually reviewed subset, using operator tags | Review progress and errors within that selected subset |
| `effective_reference` | Operator tag where present; otherwise original tag | A working corrected-label comparison |

These scopes answer different questions. Reviewing only disagreements creates a selected subset; its accuracy is not the accuracy of the entire batch or future production. Unlabeled, unreviewed records have no ground truth and do not produce an accuracy value.

Bad is the positive event: an actual bad predicted good is a **bad escape / false negative**. An actual good predicted bad is a **good reject / false positive**. For detailed formulas, see [MODELS_AND_METRICS.md](MODELS_AND_METRICS.md).

## Stored records

- `review_session.json`: source decision/workflow and session identity.
- `review_progress.json`: live counts and status.
- `records/<id>.json`: atomic, complete prediction records.
- `predictions.jsonl`: incremental prediction journal.
- `reviews.json`: operator tags, notes, and history.
- `predicted/good`, `predicted/bad`: copies of classified source images.
- `copies/scored`: copied images for scores-only decisions.

Review tags do not automatically retrain a model or rewrite the training dataset. Promote agreed corrections into a new controlled dataset revision, retain the previous revision, and create a new training experiment. Keep test/reference evidence separate from new training data.
