# Αναλυτικός οδηγός — NILT Binary Inspection 1.0

## 1. Πεδίο εφαρμογής

Το πακέτο μαθαίνει από εικόνες `good/` και `bad/` και ταξινομεί καινούριες εικόνες.
Το ίδιο πρόγραμμα εφαρμόζεται σε top, bottom ή vig, με **ξεχωριστές εκπαιδεύσεις**.
Δεν μαντεύει από την εικόνα ποια όψη είναι. Το επιλέγεις με το σωστό YAML.

Οι εκπαιδευτικές κλάσεις είναι σταθερά **GOOD=0, BAD=1**, ανεξάρτητα από την
αλφαβητική σειρά των φακέλων. Το BAD→PASS είναι το επικίνδυνο escape.
Το GOOD→FAIL είναι false fail/reject. Το REVIEW είναι αποχή/ανθρώπινος έλεγχος.

Δεν υπάρχει YOLO, segmentation, μέτρηση εμβαδού ή engineering rule engine σε αυτή
την έκδοση. Το VIG κρίνεται ως εικόνα βάσει των labels που δίνεις. Δεν υπολογίζεται
θέση μέσα/έξω από τον φακό, ούτε φυσικό μέγεθος defect.

Επίσης δεν υπάρχει αυθαίρετος αλγόριθμος που «βρίσκει την κάμερα» χωρίς εικόνες
αναφοράς. Δώσε ήδη κατάλληλα ROI/crops από την προηγούμενη επεξεργασία σου.
Το ενσωματωμένο preprocessing κρατά ολόκληρο το παρεχόμενο ROI.
Δεν εγγυάται ότι μια έγκυρη αλλά λάθος όψη ή φωτογραφία χωρίς module θα εντοπιστεί.

## 2. Ρόλος κάθε μοντέλου

| Όνομα στο YAML | Αρχιτεκτονική | Εκπαίδευση | Ρόλος |
|---|---|---|---|
| resnet50 | ResNet50/ImageNet | Head και έπειτα fine-tuning | Baseline, αλλά μπορεί να κερδίσει |
| convnext_tiny | ConvNeXt-Tiny/ImageNet | Head και fine-tuning | Σύγχρονος CNN υποψήφιος |
| dinov2_small | DINOv2 ViT-S/14 | Αρχικά frozen backbone + head | Transformer με self-supervised features |
| swin_tiny | Swin-Tiny/ImageNet | Head και fine-tuning | Δεύτερος Transformer υποψήφιος |
| patchcore | Native PatchCore-style | Μνήμη από GOOD train patches | Προαιρετικό anomaly veto |

Δεν επιβάλλουμε ότι Transformer ή ensemble είναι καλύτερο. Ο selector συγκρίνει
τα πραγματικά validation αποτελέσματα. Το τελικό pipeline κρατά έναν classifier
ή ένα ζεύγος, συν το anomaly veto όταν είναι ενεργό.

Το DINOv2 χρησιμοποιεί concat των CLS, mean patch και max patch features
(1152 features στο μικρό μοντέλο), με ένα linear binary head. Έτσι η υλοποίηση
δεν βασίζεται αποκλειστικά στο CLS token. Αυτό είναι επιλογή υλοποίησης του
πακέτου, όχι ισχυρισμός ότι λύνει όλα τα tiny defects.

Η native υλοποίηση PatchCore είναι δικός μας κώδικας PyTorch, **όχι το Anomalib**:
pooled layer2/layer3 features, bounded random reservoir, random-projection greedy
coreset, exact nearest-neighbor distances και neighborhood reweighting.
Δεν δηλώνουμε ταυτόσημη συμπεριφορά ή benchmarks με επίσημες υλοποιήσεις.
Η υποδειγματοληψία και η ανάλυση πρέπει να ελεγχθούν στα δικά σου defects.

## 3. Εγκατάσταση και περιβάλλον

Δες `START_HERE_EL.md`. Για Windows προτείνεται ξεχωριστό Python 3.11/3.12 environment.
Το development CPU test έγινε με Python 3.13.5, torch 2.10.0+cpu, torchvision 0.25.0+cpu.
Αυτό δεν αποτελεί δοκιμή σε Windows ή CUDA.

Εγκατέστησε πρώτα ένα επίσημα συμβατό ζεύγος torch/torchvision για τη GPU και τον
NVIDIA driver του workstation και μετά `requirements.txt`.
Το `timm` έχει συγκεκριμένο pin 1.0.25 για τη διαδρομή DINOv2· η διαδρομή δεν
εκτελέστηκε στο offline περιβάλλον δημιουργίας. Κάνε τον σχετικό τοπικό έλεγχο:

```powershell
python -m pytest tests/test_models.py -q
python inspect_binary.py doctor --config configs/top.yaml
```

Μετά την επιτυχημένη εγκατάσταση αποθήκευσε το πραγματικό περιβάλλον:

```powershell
python -m pip freeze > environment_local_lock.txt
```

Το `doctor` αποθηκεύει το αρχικό `environment.json` και το τρέχον
`environment_latest.json`. Ο φάκελος πρέπει να φυλάσσεται μαζί με τα checkpoints.

## 4. Αρχεία εισόδου και bit depth

Η ρίζα του dataset περιέχει good και bad, με εικόνες ή υποφακέλους εικόνων.
Υποστηρίζονται PNG/JPEG/BMP/TIFF/WebP. Δεν γίνεται επεξεργασία ZIP ως dataset:
πρώτα αποσυμπίεσέ το σε έναν φάκελο.

EXIF orientation εφαρμόζεται με τον ίδιο τρόπο παντού. Οι RGB/gray εικόνες
μετατρέπονται σε RGB. 16-bit εικόνες μετατρέπονται με **σταθερό δηλωμένο εύρος**:

```yaml
data:
  uint16_range: [0, 65535]
```

Για πραγματικά 12-bit δεδομένα αποθηκευμένα σε 16-bit, όρισε `[0, 4095]` μόνον
όταν αυτό αντιστοιχεί στο acquisition. Τιμές εκτός του δηλωμένου εύρους σταματούν
τον έλεγχο. Δεν υπάρχει per-image min/max normalization που αλλάζει αυθαίρετα
το contrast. Για τη διατήρηση κρίσιμης >8-bit πληροφορίας χρειάζεται διαφορετικό,
ειδικά validated preprocessing/model input· το παρόν μοντέλο χρησιμοποιεί RGB8.

Multi-frame TIFF και float εικόνες απορρίπτονται από προεπιλογή για να μη
χρησιμοποιηθεί σιωπηρά λάθος frame ή λάθος μετατροπή.

## 5. Τι ακριβώς κάνει το audit

Το `audit` δεν αλλάζει τα πρωτότυπα. Παράγει αναφορές και προετοιμάζει την επιλογή
εικόνων που θα αναφέρονται στο manifest.

**Ίδια δεδομένα, διαφορετικά labels:** SHA-256 αρχείου, hash native pixels και hash
του RGB model input διακρίνουν αντίγραφα/ανακωδικοποιήσεις. Ίδια model inputs σε
GOOD και BAD είναι ασυνεπές supervision και σταματούν το training. Το πρόγραμμα
δεν αποφασίζει μόνο του ποιο label είναι σωστό.

**Ίδια εικόνα, ίδιο label:** κρατείται μία εκπαιδευτική εγγραφή όταν
`deduplicate_same_class: true`. Τα υπόλοιπα αρχεία δεν σβήνονται. Όλες οι σχέσεις
με physical groups διατηρούνται, ώστε το deduplication να μη δημιουργεί leakage.

**Ίδιο filename:** μόνο report. Δύο διαφορετικές εικόνες που λέγονται `001.png`
σε good και bad δεν δημιουργούν από μόνες τους σύγκρουση labels.

**Ίδιο unit:** είναι grouping information, όχι duplicate-image evidence. Ένα unit
μπορεί να έχει διαφορετικά labels σε start και post, αλλά οι εικόνες του δεν
πρέπει να μοιράζονται σε train/test.

**Near duplicates:** pHash/Hamming και thumbnail RMSE παράγουν ύποπτα ζεύγη.
Τα ζεύγη ενώνονται στο ίδιο split, δεν διαγράφονται και δεν γίνεται αυτόματο
relabeling. Μια μικρή πραγματική φθορά μπορεί να είναι η μόνη διαφορά ενός GOOD
και ενός BAD. Η μέθοδος είναι heuristic και δεν ανιχνεύει όλες τις περιστροφές,
crops ή φωτομετρικές παραλλαγές. Αν εξαντληθεί το όριο ελέγχων, το audit σταματά
αντί να παρουσιάσει έναν ελλιπή έλεγχο ως επιτυχημένο.

Τα βασικά αρχεία:

```text
audit_summary.json       συνολική κατάσταση, warnings, fatal errors
conflicts.csv            ίδιες είσοδοι με αντίθετα labels
duplicates.csv           επαναλαμβανόμενες είσοδοι με ίδιο label
near_duplicates.csv      ύποπτα πολύ παρόμοια ζεύγη
same_filenames.csv       ίδια ονόματα, όχι απαραίτητα ίδιο περιεχόμενο
invalid_images.csv       μη αναγνώσιμες εικόνες / QC / metadata errors
metadata_template.csv    βάση για unit/tray/batch/split metadata
manifest_audit.csv       αναλυτική καταγραφή των ελεγμένων εικόνων
```

## 6. Grouping — αναγκαίο για ουσιαστική αξιολόγηση

Ένας φάκελος good/bad δεν λέει ποια αρχεία είναι το ίδιο φυσικό κομμάτι.
Κανένα image hash δεν μπορεί να αντικαταστήσει πλήρη unit/tray πληροφορία.

Χωρίς metadata, το πρόγραμμα λειτουργεί με image/duplicate clusters και γράφει
έντονο warning ότι η αξιολόγηση είναι exploratory. Δεν το παρουσιάζει ως
ανεξάρτητο test παραγωγής. Για υποχρεωτικά physical groups βάλε:

```yaml
split:
  require_physical_groups: true
```

### Metadata CSV

Αντέγραψε το παραγόμενο `metadata_template.csv` έξω από το run και συμπλήρωσέ το:

```csv
relpath,unit_id,tray_id,batch_id,split
good/C83_U001_start.png,U001,C83,B1,
bad/C83_U001_post.png,U001,C83,B1,
good/C84_U010_start.png,U010,C84,B1,
```

Το παράδειγμα δείχνει μόνο τη μορφή, δεν αποτελεί πλήρες dataset.
Βάλε στο task YAML:

```yaml
paths:
  metadata_csv: 'D:/AI_Data/top_metadata.csv'
data:
  group_by: unit_id
```

Υποστηρίζεται comma ή semicolon separator. Το `relpath` πρέπει να είναι μοναδικό
και σχετικό με το dataset root. Οι εγγραφές πρέπει να καλύπτουν κάθε εικόνα.
Τα labels εξακολουθούν να προκύπτουν από good/bad, όχι από αμφίσημη στήλη CSV.

Για πιο αυστηρό split χρησιμοποίησε `group_by: tray_id` ή `batch_id`, όταν έχεις
αρκετές ανεξάρτητες ομάδες. Με μόνο τρία trays δεν μπορείς να έχεις πέντε
διαφορετικά tray-only subsets. Μπορείς όμως να κρατήσεις ένα ολόκληρο tray ως test
και να μοιράσεις τα units των άλλων trays στα τέσσερα development subsets, με
explicit `split` στο metadata και `group_by: unit_id`.

Όταν χρησιμοποιείς τη στήλη split, συμπλήρωσέ τη **σε όλες** τις εγγραφές με ένα
από `train`, `tune`, `calibration`, `selection`, `test`. Όλες οι συνδεδεμένες
εικόνες ενός group πρέπει να έχουν την ίδια τιμή.

### IDs μέσα στο filename

Εναλλακτικά:

```yaml
data:
  group_by: unit_id
  group_regex: '(?P<tray_id>C\d+)_(?P<unit_id>U\d+)'
```

Ο κανόνας είναι παράδειγμα για `C83_U001_start.png`, **όχι υπόθεση για τη δική σου
ονοματοδοσία**. Κάθε filename πρέπει να ταιριάζει. Δεν γίνεται σιωπηρό fallback.

## 7. Γιατί υπάρχουν πέντε subsets

| Subset | Προεπιλογή | Χρήση |
|---|---:|---|
| train | 60% | Βάρη supervised models, GOOD PatchCore memory |
| tune | 10% | Early stopping / επιλογή epoch |
| calibration | 10% | Sigmoid calibrators, stacker, normal anomaly quantile |
| selection | 10% | Σύγκριση candidates και απόφαση thresholds |
| test | 10% | Τελική αξιολόγηση του παγωμένου συστήματος |

Τα ποσοστά είναι στόχοι· το grouping μπορεί να δημιουργήσει αποκλίσεις.
Χρειάζονται και τα δύο labels σε κάθε subset. Από προεπιλογή απαιτούνται τουλάχιστον
πέντε παραδείγματα ανά κλάση ανά subset, που είναι μόνο τεχνικό minimum, όχι αρκετά
για αξιόπιστη στατιστική απόδειξη.

Η επιλογή του καλύτερου από πολλά candidates πάνω στο selection δημιουργεί
selection bias στις αναφορές αυτού του subset. Γι' αυτό **μόνο το ανέγγιχτο test**
χρησιμοποιείται ως τελική εκτίμηση. Τα confidence bounds του selection είναι
περιγραφικά, όχι εγγύηση μετά τη βελτιστοποίηση.

Μετά το prepare το `manifest.csv` είναι κλειδωμένο. Αλλαγές εικόνων, labels,
metadata ή split απαιτούν νέο run directory, όχι edits στο υπάρχον manifest.

## 8. Training

Η `run` εκτελεί όλα τα ενεργά μοντέλα διαδοχικά. Για έλεγχο ανά στάδιο:

```powershell
python inspect_binary.py prepare --config configs/top.yaml
python inspect_binary.py train --config configs/top.yaml --model resnet50
python inspect_binary.py train --config configs/top.yaml --model convnext_tiny
python inspect_binary.py train --config configs/top.yaml --model dinov2_small
python inspect_binary.py train --config configs/top.yaml --model swin_tiny
python inspect_binary.py train-anomaly --config configs/top.yaml
python inspect_binary.py select --config configs/top.yaml
python inspect_binary.py evaluate --config configs/top.yaml
```

BCE-with-logits loss, προαιρετικό/automatic BAD weight από **train μόνο**, AdamW,
χωριστά learning rates backbone/head, cosine scheduler, gradient accumulation,
AMP σε CUDA, gradient clipping και early stopping στο tune. BatchNorm running
statistics μένουν σταθερά για μικρά batches. Το epoch κρίνεται πρώτα από tune
average precision και, σε ισοπαλία, από unweighted tune BCE.

ResNet/ConvNeXt/Swin: πρώτα head, μετά fine-tuning. DINOv2: αρχικά frozen backbone.
Για δεύτερο πείραμα με περιορισμένο DINO fine-tuning:

```yaml
models:
  dinov2_small:
    strategy: partial
    unfreeze_last_blocks: 2
paths:
  output_dir: '../runs/top_dino_partial_v2'
```

Το DINO backbone εξακολουθεί να κάνει forward σε κάθε batch/epoch· δεν υπάρχει
κρυφό feature caching που θα άλλαζε τα augmentations.

Augmentations: ήπιο brightness/contrast από προεπιλογή. Flips και 90° rotations
είναι κλειστά μέχρι να επιβεβαιώσεις ότι διατηρούν το label για τη συγκεκριμένη
όψη. Δεν γίνεται random crop που θα μπορούσε να κόψει το defect.

## 9. Ανάλυση και μνήμη GPU

Προεπιλογές: CNN/Swin 512, DINO 518, PatchCore 448. Το letterbox κρατά όλο το
ROI και τις αναλογίες του. Δεν υπάρχει εγγύηση ότι η επιλεγμένη ανάλυση διατηρεί
το μικρότερο κρίσιμο defect· έλεγξέ το με μεγεθυμένα παραδείγματα.

Σε CUDA out-of-memory μείωσε πρώτα:

```yaml
training:
  batch_size: 2
  gradient_accumulation: 4
prediction:
  batch_size: 2
anomaly:
  batch_size: 1
  query_chunk: 256
```

Αλλαγές training parameters γίνονται σε νέο run. Μετά σκέψου αλλαγή ανάλυσης.
Για DINO χρησιμοποίησε πολλαπλάσια του 14, π.χ. 392 ή 518, όχι αυθαίρετα 512.
Μη χαμηλώσεις την ανάλυση πριν ελέγξεις ότι δεν εξαφανίζεις μικρές φθορές.

## 10. Selector και fusion

Ο selector αξιολογεί singles και κάθε ζεύγος σε τρεις τρόπους:
mean των calibrated scores, maximum και regularized logistic stacking.
Με τέσσερα μοντέλα και όλες τις επιλογές είναι 22 candidates.

Τα calibrators/stacker βλέπουν μόνο το calibration subset, που δεν εκπαίδευσε
τα base networks. Συνεπώς εδώ δεν χρειάζεται να χρησιμοποιήσουμε in-sample
training predictions ούτε να προσποιηθούμε ότι είναι out-of-fold.
Το stacking έχει μη αρνητικά βάρη, ώστε μεγαλύτερο member risk να μην μειώνει
το τελικό risk λόγω αυθαίρετου αρνητικού συντελεστή.

Η επιλογή μεγιστοποιεί τα σωστά αυτόματα PASS/FAIL, υπό τα παρακάτω **εμπειρικά
selection-set** όρια. Σε κοντινή επίδοση προτιμά λιγότερα μοντέλα.

```yaml
selector:
  max_bad_escape_rate: 0.005
  max_good_false_fail_rate: 0.02
  disagreement_threshold: 0.35
  pass_member_cap: 0.30
  fail_member_floor: 0.50
  min_selection_good_pass_rate: 0.10
```

Το `0.005` δεν σημαίνει «εγγυημένα κάτω από 0.5% escapes στην παραγωγή».
Είναι στόχος για το subset επιλογής. Τα πραγματικά `pass_threshold` και
`fail_threshold` μαθαίνονται και αποθηκεύονται στο selector.json.

Η απόφαση είναι ασύμμετρη: χαμηλό combined risk δεν αρκεί για PASS αν κάποιος
επιλεγμένος member ξεπερνά το cap ή υπάρχει μεγάλη διαφωνία. Υψηλό anomaly score
εμποδίζει PASS και παραπέμπει σε REVIEW· δεν αποδεικνύει defect και δεν προκαλεί
FAIL μόνο του. FAIL απαιτεί υψηλό supervised score και agreement.

Αν κανένα candidate δεν πετυχαίνει τη ρυθμισμένη ελάχιστη χρήσιμη αυτοματοποίηση,
ο selector γράφει `NO_FEASIBLE_POLICY_ALL_REVIEW`. Δεν χαλαρώνει κρυφά τους κανόνες.

Τα output scores είναι risk scores. Sigmoid calibration δεν εγγυάται ορθή
πιθανότητα μετά από drift, νέο tray ή διαφορετικό ποσοστό BAD στην παραγωγή.
Ειδικά max/mean fusion δεν πρέπει να ερμηνεύεται αυτομάτως ως πραγματική P(BAD).

## 11. Απενεργοποίηση μοντέλων

Για μικρότερο πείραμα:

```yaml
models:
  resnet50:
    enabled: false
  swin_tiny:
    enabled: false
```

Έτσι μένουν ConvNeXt + DINO υποψήφια. Ο selector μπορεί πάλι να προτιμήσει μόνο
το ένα. Για αμιγώς supervised σύστημα χωρίς anomaly layer:

```yaml
anomaly:
  enabled: false
selector:
  use_anomaly_veto: false
```

Πρέπει να αλλάξεις **και τις δύο** ρυθμίσεις. Ένα απαιτούμενο μοντέλο που λείπει
δεν παραλείπεται σιωπηρά. Μετά το τελικό test, νέα επιλογή/threshold tuning
απαιτεί νέα έκδοση και νέα ανεξάρτητη επιβεβαίωση.

## 12. Ερμηνεία των reports

`selector_leaderboard.csv` αφορά το **selection**, όχι το τελικό test.
`evaluation/test_report.json` αφορά μόνο το παγωμένο τελικό pipeline.

- `bad_escape_rate`: BAD→PASS / όλα τα BAD.
- `good_false_fail_rate`: GOOD→FAIL / όλα τα GOOD.
- `review_rate`: όλα τα REVIEW / όλες τις εικόνες.
- `good_not_pass_rate`: GOOD→(FAIL ή REVIEW) / όλα τα GOOD.
- `pass_contamination_rate`: BAD→PASS / όλες τις PASS εικόνες.
- `bad_auto_fail_recall`: BAD→FAIL / όλα τα BAD. Το REVIEW δεν μετρά ως αυτόματο FAIL.

Υπάρχουν επίσης PR average precision, ROC-AUC, Brier, log loss, calibration bins
και, όταν παρέχονται tray IDs, per-tray metrics.

`bad_escape_upper_bound_iid` είναι one-sided exact Clopper–Pearson bound.
Για zero escapes σε N=100 ανεξάρτητα BAD, το 95% upper bound είναι περίπου 2.95%,
όχι 0%. Η εξάρτηση μεταξύ φωτογραφιών του ίδιου unit/tray περιορίζει την ερμηνεία
του binomial bound. Υπάρχει και group-level bound για το διαφορετικό event
«έστω μία BAD εικόνα του group περνά». Δεν το συγχέουμε με per-image probability.

Οι κοντινές/γνωστές development εικόνες στο απλό `predict` δεν δημιουργούν
ανεξάρτητη μέτρηση. Τα exact matches με development inputs επισημαίνονται και,
από προεπιλογή, ένα προτεινόμενο PASS τέτοιας εικόνας γίνεται REVIEW.
Ο έλεγχος αυτός δεν αποτελεί cross-run near-duplicate detector.

## 13. Inference, ταξινόμηση αρχείων και review

```powershell
python inspect_binary.py predict --config configs/vig.yaml --input "D:/new_vig"
```

Το prediction χρησιμοποιεί αποθηκευμένο preprocessing/calibration/thresholds,
όχι αυθαίρετες νέες ρυθμίσεις που άλλαξαν μετά το training.
Για προαιρετικά αντίγραφα σε φακέλους:

```yaml
prediction:
  copy_images: true
```

Δημιουργούνται `sorted/PASS`, `sorted/REVIEW`, `sorted/FAIL`. Τα filenames
παίρνουν ασφαλές μοναδικό prefix. Τα originals δεν μετακινούνται/διαγράφονται.
Το `review.html` ανοίγει τοπικά και δείχνει έως 100 παραδείγματα με προτεραιότητα
σε BAD escapes και REVIEW. Το πλήρες αποτέλεσμα είναι στο CSV.

Το πακέτο λειτουργεί σε shadow/proposal mode. Το `release_authorized` είναι false:
δεν ελέγχει PLC/tray placement και δεν αποτελεί έγκριση παραγωγής. Πριν συνδεθεί
με αυτόματη αποδοχή, χρειάζεται επιβεβαίωση στα πραγματικά κριτήρια της εταιρείας.

Οι αποφάσεις είναι **ανά εικόνα**, όχι ολοκληρωμένη απόφαση unit από πολλές όψεις.
Λείπουσες αναμενόμενες εικόνες δεν ανιχνεύονται χωρίς λίστα αναμενόμενων units/views.
Στη μελλοντική ενοποίηση, ένα unit περνά μόνο όταν υπάρχουν όλα τα απαιτούμενα
views και είναι αποδεκτά, με χωριστό ελεγμένο aggregation rule.

## 14. Νέα δεδομένα, επανεκπαίδευση και διακοπές

Μη ρίχνεις νέες εικόνες στον ήδη κλειδωμένο φάκελο ενός run και συνεχίζεις σαν
να μην άλλαξε τίποτα. Δημιούργησε dataset v2 και `output_dir: ../runs/top_v2`.
Η απλούστερη καθαρή σύγκριση είναι νέο fine-tuning από τα δημόσια pretrained weights.

Υποστηρίζεται προαιρετικό warm-start από προηγούμενο δικό σου run:

```yaml
paths:
  dataset_root: 'D:/AI_Data/top_v2'
  output_dir: '../runs/top_v2'
  warm_start_run: '../runs/top_v1'
  metadata_csv: 'D:/AI_Data/top_v2_metadata.csv'
```

Κράτησε **όλους** τους παλιούς ρόλους split για κοινές εικόνες/units με explicit
metadata.split. Δεν επιτρέπεται παλιό TRAIN να γίνει νέο TEST ούτε παλιό TEST
να χρησιμοποιηθεί στο development. Εικόνες/units που δεν μπορούν να ταυτοποιηθούν
αξιόπιστα δεν παρέχουν εγγύηση κατά cross-run leakage. Χρειάζεται νέο ανεξάρτητο
confirmation set όταν οι προηγούμενες test επιδόσεις έχουν επηρεάσει επιλογές σου.

Το warm-start φορτώνει μόνο συμβατά model weights. Δεν είναι resume optimizer.
Calibration, selector και PatchCore memory υπολογίζονται εκ νέου από τους
αντίστοιχους επιτρεπόμενους ρόλους δεδομένων.

Αν διακοπεί το training, αποθηκεύεται το καλύτερο ολοκληρωμένο epoch και το history.
Η επανεκτέλεση παραλείπει ήδη ολοκληρωμένα μοντέλα με έλεγχο signature/hash.
Το μη ολοκληρωμένο μοντέλο ξεκινά ξανά την εκπαίδευση· δεν ισχυριζόμαστε exact
resume του optimizer από το σημείο διακοπής.

## 15. Συνήθη προβλήματα

**Missing good/bad folder:** έδωσες λάθος dataset_root ή παλιά δομή train/val/test.

**Same tag / ίδιο unit:** δεν είναι label conflict από μόνο του. Δες conflicts.csv
για ίδια pixels/model inputs, όχι μόνο ονόματα.

**Cannot make grouped split:** πολύ λίγες ανεξάρτητες ομάδες/σπάνια BAD ή μεγάλο
near-duplicate chain. Επιθεώρησε τα groups. Μην παρακάμψεις το πρόβλημα βάζοντας
παρόμοια δείγματα σε train και test. Δώσε αξιόπιστα metadata ή περισσότερα groups.

**Near duplicate audit incomplete:** αύξησε το computational limit όταν υπάρχουν
πολλά παρόμοια inputs, ή επανεξέτασε τη μέθοδο/παραμέτρους με πραγματικές εικόνες.
Η απενεργοποίηση σημαίνει ότι αυτός ο έλεγχος δεν έγινε και καταγράφεται ως warning.

**All REVIEW:** κοίτα selector status, member disagreement, anomaly veto, dataset
quality και candidate performance. Δεν «διορθώνεται» υπεύθυνα βάζοντας αυθαίρετο
threshold 0.5. Πρώτα εντόπισε την αιτία στο selection set.

**DINO/timm missing:** εγκατάστησε το pin στο ίδιο interpreter του PyCharm.

**Missing pretrained weights:** εκτέλεσε download-weights ή μετέφερε το weights/
από εγκεκριμένο υπολογιστή. Μη χρησιμοποιήσεις random initialization ως λύση.

**CUDA false:** έλεγξε interpreter, NVIDIA driver και PyTorch build. Το πρόγραμμα
δεν διορθώνει ή εγκαθιστά drivers αυτόματα.

**Config/data changed:** νέο output_dir για νέα έκδοση. Μη σβήνεις τα safeguards
για να εμφανιστεί επιτυχία στην ίδια αξιολόγηση.

## 16. Πηγές και όρια

Οι επίσημες πηγές βρίσκονται στο SOURCES.md. Η συγκεκριμένη σύνθεση, οι heuristics
του audit, τα default thresholds, το bounded PatchCore και η διαδικασία επιλογής
είναι engineering επιλογές αυτού του πακέτου που απαιτούν δική σου αξιολόγηση.
Οι CPU software tests αποδεικνύουν συγκεκριμένες λειτουργικές συμπεριφορές,
όχι industrial defect-detection accuracy. Δες TEST_REPORT.md για ακριβές scope.
