#!/usr/bin/env bash
set -euo pipefail
inspection_project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd -- "$inspection_project_dir"
inspection_python="${STUDIO_PYTHON:-$inspection_project_dir/.venv-studio6/bin/python}"
if [[ ! -x "$inspection_python" ]]; then
    printf '%s\n' 'Dashboard Python environment not found. Set STUDIO_PYTHON to the interpreter used to launch the dashboard.' >&2
    exit 1
fi
"$inspection_python" -m pip install --upgrade -r requirements-export.txt "$@"
"$inspection_python" scripts/check_export.py
"$inspection_python" -m pip check
