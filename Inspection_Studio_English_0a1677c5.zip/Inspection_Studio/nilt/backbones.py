"""Curated timm backbones used by Studio and the standalone classifier CLI."""
from cvtester.catalog import CATALOG, select_model

TIMM_MODELS = tuple(CATALOG)


def validate_model_usage(names, usage="commercial"):
    if usage not in {"commercial", "research"}:
        raise ValueError("model_usage must be commercial or research (noncommercial use).")
    for name in names:
        if name in CATALOG:
            select_model(name, usage)


def model_details():
    return {name: {"family": spec.family, "size": spec.size, "license": spec.license,
                   "commercial": spec.commercial, "source": spec.card_url,
                   "checkpoint": spec.checkpoint}
            for name, spec in CATALOG.items()}


def normalization(name):
    if name not in CATALOG:
        return [0.485, 0.456, 0.406], [0.229, 0.224, 0.225]
    import timm
    cfg = timm.get_pretrained_cfg(CATALOG[name].checkpoint)
    return list(cfg.mean), list(cfg.std)


def make_backbone(name, cfg, pretrained=False):
    import timm
    from safetensors.torch import load_file
    from .engine import weight_path
    spec = select_model(name, (cfg or {}).get("model_usage", "commercial"))
    options = {}
    # Preserve the inspection canvas: interpolate position embeddings, not images.
    if spec.family in {"DeiT III", "EVA-02"}:
        options.update(dynamic_img_size=True, dynamic_img_pad=True)
    elif spec.family == "Swin V2":
        options["strict_img_size"] = False
    model = timm.create_model(spec.checkpoint, pretrained=False, **options)
    if pretrained:
        model.load_state_dict(load_file(str(weight_path(cfg, name))), strict=True)
    model.reset_classifier(2)
    return model, model.get_classifier()


def last_block(model, name):
    family = CATALOG[name].family
    if family in {"ConvNeXt", "ConvNeXt V2"}:
        return model.stages[-1]
    if family == "Swin V2":
        return model.layers[-1]
    return model.blocks[-1]


def canvas_alignment(names):
    return 32 if any(name in {"convnext_tiny", "swin_t"} or
                     name in CATALOG and CATALOG[name].family in {"ConvNeXt", "ConvNeXt V2", "Swin V2"}
                     for name in names) else 1
