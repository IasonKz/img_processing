from pathlib import Path
import shutil

import numpy as np
from PIL import Image
import pytest

from binary_inspection.audit import audit
from binary_inspection.common import read_csv, write_csv
from binary_inspection.images import load_image, letterbox
from binary_inspection.splitting import prepare, read_manifest, verify_manifest
from conftest import make_dataset


def test_conflicting_identical_input_stops(config):
    root = Path(config["paths"]["dataset_root"])
    make_dataset(root, 3)
    shutil.copy2(next((root / "good").glob("*.png")), root / "bad" / "different_name.png")
    _, summary = audit(config)
    assert not summary["passed"]
    assert summary["conflicting_inputs"] == 1
    with pytest.raises(ValueError, match="Audit stopped"):
        prepare(config)


def test_same_class_duplicate_is_removed_not_deleted(config):
    root = Path(config["paths"]["dataset_root"])
    make_dataset(root, 3)
    source = next((root / "good").glob("*.png"))
    Image.open(source).save(root / "good" / "new_encoding.bmp")
    rows, summary = audit(config)
    assert summary["passed"] and len(rows) == 6
    assert summary["same_class_duplicates"] == 1
    assert (root / "good" / "new_encoding.bmp").exists()


def test_same_filename_different_images_is_not_conflict(config):
    root = Path(config["paths"]["dataset_root"])
    make_dataset(root, 1)
    next((root / "good").glob("*.png")).rename(root / "good" / "same.png")
    next((root / "bad").glob("*.png")).rename(root / "bad" / "same.png")
    _, summary = audit(config)
    assert summary["passed"]
    assert summary["same_filenames"] == 1


def test_corrupted_image_stops_and_is_reported(config):
    root = Path(config["paths"]["dataset_root"])
    make_dataset(root, 2)
    (root / "good" / "corrupt.png").write_text("not an image")
    _, summary = audit(config)
    assert not summary["passed"] and summary["invalid_files"] == 1


def test_grouped_splits_are_disjoint_even_with_mixed_labels(config):
    root = Path(config["paths"]["dataset_root"])
    make_dataset(root, 50)
    config["data"]["group_regex"] = r"(?P<unit_id>unit_\d+)"
    config["data"]["group_by"] = "unit_id"
    prepare(config)
    rows = read_manifest(config)
    assert len({r["split"] for r in rows}) == 5
    by_unit = {}
    for row in rows:
        by_unit.setdefault(row["unit_id"], set()).add(row["split"])
    assert all(len(splits) == 1 for splits in by_unit.values())
    verify_manifest(config)
    (root / "good" / "new.png").write_bytes(next((root / "good").glob("*.png")).read_bytes())
    with pytest.raises(ValueError, match="added/removed"):
        verify_manifest(config)


def test_modified_image_is_detected(config):
    root = Path(config["paths"]["dataset_root"])
    make_dataset(root, 30)
    prepare(config)
    image_path = next((root / "good").glob("*.png"))
    Image.new("RGB", (64, 64), (100, 90, 80)).save(image_path)
    with pytest.raises(ValueError, match="changed since audit"):
        verify_manifest(config)


def test_near_duplicates_group_without_relabelling(config):
    root = Path(config["paths"]["dataset_root"])
    make_dataset(root, 1)
    source = next((root / "good").glob("*.png"))
    arr = np.array(Image.open(source))
    arr[30, 30, 0] = min(255, int(arr[30, 30, 0]) + 1)
    target = root / "bad" / "near.png"
    Image.fromarray(arr).save(target)
    config["audit"]["near_duplicates"].update(enabled=True, hamming_radius=3, max_thumbnail_rmse=3.0)
    rows, summary = audit(config)
    assert summary["passed"] and summary["near_pairs"] >= 1
    linked = [r for r in rows if r["path"] in (str(source), str(target))]
    assert len({r["group_id"] for r in linked}) == 1
    assert len({r["label"] for r in linked}) == 2


def test_partial_near_audit_cannot_pass(config):
    root = Path(config["paths"]["dataset_root"])
    make_dataset(root, 2)
    config["audit"]["near_duplicates"].update(enabled=True, hamming_radius=64, max_candidate_pairs=1)
    _, summary = audit(config)
    assert not summary["passed"] and not summary["near_complete"]


def test_uint16_fixed_scaling(config, tmp_path):
    arr = np.full((64, 64), 32768, dtype=np.uint16)
    path = tmp_path / "image.tif"
    Image.fromarray(arr).save(path)
    image, _ = load_image(path, config["data"])
    assert int(np.asarray(image)[0, 0, 0]) == 128


def test_letterbox_preserves_edges():
    image = Image.new("RGB", (100, 50), "white")
    array = np.array(image)
    array[:, 0] = 0
    array[:, -1] = 0
    out = np.array(letterbox(Image.fromarray(array), 100))
    assert out.shape == (100, 100, 3)
    assert out[50, 0].sum() == 0 and out[50, -1].sum() == 0


def test_explicit_split_conflicting_group_stops(config, tmp_path):
    root = Path(config["paths"]["dataset_root"])
    make_dataset(root, 3)
    meta = []
    for p in root.rglob("*.png"):
        meta.append({"relpath": p.relative_to(root).as_posix(), "unit_id": "SAME_UNIT",
                     "split": "train" if p.parent.name == "good" else "test"})
    path = tmp_path / "meta.csv"
    write_csv(path, meta)
    config["paths"]["metadata_csv"] = str(path)
    config["data"]["group_by"] = "unit_id"
    _, report = audit(config)
    assert "LINKED_IMAGES_ASSIGNED_TO_DIFFERENT_SPLITS" in report["fatal_errors"]
