from __future__ import annotations

import argparse
import multiprocessing as mp

from qc.comparison import run_model_comparison
from qc.config import load_yaml


def main() -> None:
    parser = argparse.ArgumentParser(description="Compare model checkpoints on one frozen manifest.")
    parser.add_argument("--config", required=True, help="Path to a model-comparison YAML file")
    args = parser.parse_args()
    result = run_model_comparison(load_yaml(args.config))
    print(f"\nComparison output: {result['output_folder']}")
    if result.get("promotion"):
        print(f"Promote candidate: {result['promotion']['promote_candidate']}")


if __name__ == "__main__":
    mp.freeze_support()
    main()
