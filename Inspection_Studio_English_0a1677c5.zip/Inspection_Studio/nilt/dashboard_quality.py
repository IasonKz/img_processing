"""Read-only evidence aggregation and explicit local quality-report exports."""
from datetime import datetime, timezone
from pathlib import Path
import uuid


class QualityDashboardMixin:
    @property
    def quality_root(self):
        return self.config.parent / "quality_reports"

    def _restore_quality_sessions(self):
        from .common import read_json
        from .review import _session
        marker = self.logs_root / "quality_sessions.json"
        self.loaded_quality_sessions = []
        if marker.is_symlink() or not marker.is_file():
            return
        try:
            values = read_json(marker)
        except (OSError, ValueError):
            return
        if not isinstance(values, list):
            return
        for value in values[:100]:
            try:
                path, _ = _session(value)
            except (OSError, ValueError, TypeError):
                continue
            self.loaded_quality_sessions.append(path)
            if path not in self.output_roots:
                self.output_roots.append(path)

    def quality_load_session(self, data):
        from .common import write_json
        from .review import _session
        value = data.get("path")
        if not isinstance(value, str) or not value.strip():
            raise ValueError("Enter an existing recorded inspection session folder.")
        try:
            path, _ = _session(Path(value).expanduser())
        except (OSError, ValueError) as exc:
            raise ValueError("Choose a recorded inspection session folder containing a valid review_session.json.") from exc
        if any(path == root or root.is_relative_to(path) for root in self.data_roots):
            raise ValueError("Choose a recorded session, not a dataset folder or its parent.")
        with self.lock:
            loaded = self.loaded_quality_sessions
            if path not in loaded:
                if len(loaded) >= 100:
                    raise ValueError("At most 100 historical sessions can be registered in this workspace.")
                loaded.append(path)
            if path not in self.output_roots:
                self.output_roots.append(path)
            write_json(self.logs_root / "quality_sessions.json", [str(p) for p in loaded])
        return self.quality_catalog()

    def quality_catalog(self):
        reports = []
        root = self.quality_root.resolve()
        for path in sorted(root.glob("*/report.html"), reverse=True):
            if path.is_symlink() or not path.resolve().is_relative_to(root):
                continue
            reports.append({"name": path.parent.name, "path": str(path), "url": self.file_url(path)})
        return {"runs": self.runs(), "sessions": self.review_sessions(),
                "report_root": str(root), "reports": reports[:200]}

    def _quality_request(self, data):
        runs, sessions = data.get("runs", []), data.get("sessions", [])
        for name, values in (("runs", runs), ("sessions", sessions)):
            if not isinstance(values, list) or len(values) > 100 or any(not isinstance(x, str) or not x.strip() for x in values):
                raise ValueError(f"Choose at most 100 recorded {name}.")
        if not runs and not sessions:
            raise ValueError("Choose at least one experiment or inspection session.")
        title, notes = data.get("title", "Quality report"), data.get("notes", "")
        if not isinstance(title, str) or not title.strip() or len(title) > 200:
            raise ValueError("Report title must contain 1 to 200 characters.")
        if not isinstance(notes, str) or len(notes) > 20000:
            raise ValueError("Report notes must contain at most 20,000 characters.")
        run_paths = list(dict.fromkeys(self.run_path(p) for p in runs))
        session_paths = list(dict.fromkeys(self.checked_output(p, exists=True) for p in sessions))
        from .review import _session
        for path in session_paths:
            _session(path)
        return run_paths, session_paths, title.strip(), notes

    def quality_preview(self, data):
        from .quality import build_quality_report
        return {"report": build_quality_report(*self._quality_request(data))}

    def quality_export(self, data):
        from .quality import build_quality_report
        from .quality_render import export_quality_report
        # Reports observe recorded evidence; they neither stop an active worker
        # nor run inference on unopened final holdouts.
        report = build_quality_report(*self._quality_request(data))
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
        output = self.quality_root / (stamp + "_" + uuid.uuid4().hex[:8])
        result = export_quality_report(report, output)
        result["html_url"] = self.file_url(result["html"])
        result["file_links"] = [{"name": p.name, "url": self.file_url(p)}
                                for p in sorted(output.iterdir()) if p.is_file() and p.suffix in {".html", ".json", ".csv", ".txt"}]
        return result
