"""Immutable crop lineage and inherited unit splits for ROI defect projects."""
from pathlib import Path
import re

from .common import read_json, safe_path, sha256


def source_mapping(cfg):
    binding = cfg.get("roi_source")
    if binding is None:
        return None
    if not isinstance(binding, dict) or set(binding) != {"manifest", "sha256"}:
        raise ValueError("ROI source requires its recorded manifest and checksum.")
    path = Path(binding["manifest"])
    if sha256(path) != binding["sha256"]:
        raise ValueError("ROI crop lineage changed. Create a new annotation project.")
    metadata = read_json(path)
    if metadata.get("schema") != "roi_crop_annotation_source.v1" or metadata.get("side") != cfg["task"]:
        raise ValueError("ROI crop lineage belongs to a different segmentation view.")
    result, units = {}, {}
    for row in metadata.get("samples", []):
        relative, unit, split = row.get("relative_path"), row.get("unit_id"), row.get("split")
        if not isinstance(relative, str) or not relative or relative in result:
            raise ValueError("ROI crop paths must be unique nonempty strings.")
        safe_path(cfg["input_dir"], relative)
        if not isinstance(unit, str) or not unit.strip() or split not in ("train", "val", "test"):
            raise ValueError("Every crop requires its original unit and train/val/test role.")
        if unit in units and units[unit] != split:
            raise ValueError("A physical unit occurs in multiple ROI splits.")
        if not re.fullmatch(r"[a-f0-9]{64}", str(row.get("sha256", ""))):
            raise ValueError("Every ROI crop needs a verified source checksum.")
        units[unit] = split
        result[relative] = row
    if not result:
        raise ValueError("The ROI crop source contains no images.")
    return result


def fixed_split(records, require_both=True):
    """Never reassign ROI units or expose their held-out test during fitting."""
    roles, groups = {}, {}
    for row in records:
        role = {"val": "validation"}.get(row.get("fixed_split"), row.get("fixed_split"))
        if role not in ("train", "validation", "test") or not row.get("group"):
            raise ValueError("Every ROI crop needs its original unit split.")
        unit = row["group"]
        if unit in groups and groups[unit] != role:
            raise ValueError("ROI unit leakage across training, validation and test.")
        groups[unit] = role
        roles[row["id"]] = role
    train = [row for row in records if roles[row["id"]] == "train"]
    val = [row for row in records if roles[row["id"]] == "validation"]
    if not train or not val:
        raise ValueError("Approve ROI crops from both original training and validation units before training.")
    available = {c for row in train for c in row.get("defect_classes", [])}
    required = {1, 2} if require_both else available
    if not available or not required.issubset(available):
        raise ValueError("The original ROI training split lacks the required annotated defect classes.")
    present_val = {c for row in val for c in row.get("defect_classes", [])}
    if not present_val:
        raise ValueError("Original ROI validation crops need annotated defects for model selection.")
    return {"group_split": groups, "split_source": "roi_detection_unit_ledger",
            "validation_missing_classes": [name for name, value in (("inner", 1), ("outer", 2))
                                           if value in required and value not in present_val],
            **{role + "_ids": [row["id"] for row in records if roles[row["id"]] == role]
               for role in ("train", "validation", "test")}}
