"""Wall-clock supervisor for Windows/Linux local searches.

The child checkpoints cooperatively before the deadline. The parent enforces
the deadline even during a blocked audit/kernel, retaining only committed state.
Budgets are cumulative across resumes, independent of Optuna trial counts.
"""
from __future__ import annotations

import math
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid

from .common import read_json, write_json, utc_now

PROFILE_CAPS = {"laptop": 7200, "workstation": 21600, "workstation_large": 43200}


def recover_lock(run):
    """An operator request cannot remove a live process's lock."""
    path = Path(run) / "operation.lock"
    if not path.exists():
        return
    import psutil
    owner = read_json(path)
    pid = int(owner.get("pid", -1))
    if pid > 0 and psutil.pid_exists(pid):
        raise RuntimeError(f"Process {pid} still exists; refusing to remove {path}.")
    path.unlink()


def stop_tree(proc):
    import psutil
    try:
        parent = psutil.Process(proc.pid)
        children = parent.children(recursive=True)
    except psutil.NoSuchProcess:
        return
    for child in reversed(children):
        try:
            child.kill()
        except psutil.NoSuchProcess:
            pass
    try:
        parent.kill()
    except psutil.NoSuchProcess:
        pass
    proc.wait(timeout=10)


def _read_run(session_file):
    try:
        value = read_json(session_file).get("run")
        return Path(value) if value else None
    except (OSError, ValueError):
        return None


def supervise_search(cfg=None, run=None, hours=None, finalize=True,
                     recover=False, device=None, finalize_only=False):
    from .workflow import open_run
    run = Path(run).resolve() if run else None
    if run:
        cfg, _ = open_run(run)
        if recover:
            recover_lock(run)
        if (run / "operation.lock").exists():
            raise RuntimeError("Run is busy or has an abandoned lock. Verify it stopped, then use --recover-lock.")
        if device:
            write_json(run / "runtime_overrides.json", {"device": device})
            cfg["device"] = device
    if cfg is None:
        raise ValueError("Provide one configuration or an existing run.")
    profile = cfg.get("profile", "laptop")
    cap = PROFILE_CAPS.get(profile, PROFILE_CAPS["laptop"])
    if hours is not None and (not math.isfinite(hours) or hours <= 0 or hours * 3600 > cap):
        raise ValueError(f"--hours must be positive and at most {cap / 3600:g} for {profile}.")
    configured = float(cfg.get("search", {}).get("total_budget_seconds", cfg.get("budget_seconds", cap)))
    if not math.isfinite(configured) or configured <= 0:
        raise ValueError("Search budget must be finite and positive.")
    budget = min(cap, configured, hours * 3600 if hours is not None else cap)
    prior = read_json(run / "budget.json") if run and (run / "budget.json").exists() else {}
    consumed = float(prior.get("consumed_seconds", 0))
    if prior.get("session_active"):
        # A supervisor itself may have been killed. Charge the elapsed session,
        # capped at its original deadline; never grant a fresh full budget.
        consumed += max(0, min(time.time(), prior["time_limit_at"]) - prior["session_started_at"])
    if prior:
        budget = min(budget, float(prior["total_budget_seconds"]))
    if finalize_only:
        # Explicit separate operation; the original search ledger is untouched.
        budget, consumed = min(cap, (hours if hours is not None else .5) * 3600), 0.0
    remaining = budget - consumed
    if remaining <= 0:
        raise ValueError("Search time budget is exhausted. Read saved results or explicitly run finalize-search for pending comparison.")
    root = Path(cfg["output_root"]) / "_sessions"
    root.mkdir(parents=True, exist_ok=True)
    token = uuid.uuid4().hex
    session_file = root / (token + ".json")
    started = time.time()
    deadline = started + remaining
    session = {"schema_version": 3, "run": str(run) if run else None, "config": cfg,
               "created_at": utc_now(), "deadline": deadline,
               "cooperative_deadline": max(started, deadline - min(3., remaining * .1)),
               "total_budget_seconds": budget, "consumed_before": consumed,
               "session_started_at": started, "finalize": finalize,
               "finalize_only": finalize_only}
    write_json(session_file, session)
    if run:
        (run / "control.json").unlink(missing_ok=True)
    ledger = {"total_budget_seconds": budget, "consumed_seconds": consumed,
              "session_started_at": started, "time_limit_at": deadline,
              "session_active": True, "session_file": str(session_file)}
    ledger_name = "finalization_budget.json" if finalize_only else "budget.json"
    if run:
        write_json(run / ledger_name, ledger)
    command = [sys.executable, "-u", str(Path(__file__).resolve().parents[1] / "inspection.py"),
               "_search-worker", "--session", str(session_file)]
    print(f"TIME BUDGET: {remaining / 3600:.3f} hours remaining; deadline includes audit, training and selection.", flush=True)
    proc = subprocess.Popen(command)
    timed_out, interrupted, ledger_written = False, False, bool(run)
    try:
        while proc.poll() is None:
            if not run:
                run = _read_run(session_file)
            if run and not ledger_written:
                write_json(run / ledger_name, ledger)
                ledger_written = True
            if time.time() >= deadline:
                timed_out = True
                stop_tree(proc)
                break
            time.sleep(min(.15, max(.01, deadline - time.time())))
    except KeyboardInterrupt:
        interrupted = True
        run = run or _read_run(session_file)
        if run:
            write_json(run / "control.json", {"action": "pause", "stop": True, "reason": "operator_pause"})
        until = min(deadline, time.time() + 3)
        while proc.poll() is None and time.time() < until:
            time.sleep(.1)
        if proc.poll() is None:
            stop_tree(proc)
    finally:
        run = run or _read_run(session_file)
        elapsed = max(0, min(time.time(), deadline) - started)
        if run:
            ledger.update(consumed_seconds=min(budget, consumed + elapsed), session_active=False,
                          completed_at=utc_now(), hard_timeout=timed_out, interrupted=interrupted)
            write_json(run / ledger_name, ledger)
            # Clear only the ended child's own lock. This also handles delayed
            # deletion visibility on synchronized/network filesystems.
            lock = run / "operation.lock"
            if proc.poll() is not None and lock.exists() and read_json(lock).get("pid") == proc.pid:
                lock.unlink(missing_ok=True)
            if timed_out or interrupted:
                write_json(run / "supervisor_event.json", {
                    "at": utc_now(), "status": "TIME_LIMIT" if timed_out else "PAUSED",
                    "checkpoint_scope": "last successfully committed epoch",
                    "selection_complete": (run / "selected.json").exists()})
                if not (run / "selected.json").exists():
                    state_file = run / "model_state.json"
                    state = read_json(state_file) if state_file.exists() else {}
                    state.update(status="SEARCH_TIME_LIMIT" if timed_out else "SEARCH_PAUSED", updated_at=utc_now())
                    write_json(state_file, state)
        print(f"SESSION: {session_file}", flush=True)
    if timed_out:
        print("TIME_LIMIT: saved checkpoints retained; no unfinished comparison is promoted.", flush=True)
        return 4
    return 130 if interrupted else proc.returncode


def search_worker(session_file):
    from .workflow import new_run
    from .search import run_search, finalize_search
    session_file = Path(session_file)
    session = read_json(session_file)
    run = Path(session["run"]) if session.get("run") else None
    if run is None:
        def on_created(path):
            session["run"] = str(Path(path).resolve())
            write_json(session_file, session)
        run = new_run(session["config"], on_created=on_created)
    if session["finalize_only"]:
        return finalize_search(run, deadline=session["cooperative_deadline"])
    if not session["config"].get("search", {}).get("enabled", True):
        from .workflow import run_training
        def stop_check():
            control = run / "control.json"
            if control.exists():
                value = read_json(control)
                if value.get("stop") or value.get("action") in ("pause", "stop"):
                    return "operator_pause"
            return "time_limit" if time.time() >= session["cooperative_deadline"] else False
        return run_training(run, stop_check=stop_check)
    return run_search(run, resume=True, finalize=session["finalize"], deadline=session["cooperative_deadline"])
