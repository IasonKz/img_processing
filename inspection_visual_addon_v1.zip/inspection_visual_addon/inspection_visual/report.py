"""Read-only report builder. The HTML embeds derived records, never image bytes."""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np


def read_json(path, default=None):
    if not path.is_file():
        return default
    return json.loads(path.read_text(encoding="utf-8-sig"))


def read_csv(path):
    if not path.is_file():
        return []
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def number(value):
    try:
        value = float(value)
        return value if math.isfinite(value) else None
    except (TypeError, ValueError):
        return None


def clean(value):
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(v) for v in value]
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def selection_signature(rows):
    selection = [r for r in rows if r.get("split") == "selection"]
    if not selection or any(not r.get("pixel_hash") or not r.get("group") for r in selection):
        return None
    records = sorted((r["pixel_hash"], str(r["label"]), r["group"]) for r in selection)
    return hashlib.sha256(json.dumps(records, separators=(",", ":")).encode()).hexdigest()


def score_summary(labels, scores, threshold):
    """Tie-correct curves and operating points, score>=threshold means bad."""
    labels, scores = np.asarray(labels, int), np.asarray(scores, float)
    if labels.ndim != 1 or scores.ndim != 1 or len(labels) != len(scores) or not len(labels):
        raise ValueError("Empty, mismatched or non-vector saved scores.")
    if not np.isin(labels, [0, 1]).all() or not np.isfinite(scores).all():
        raise ValueError("Invalid saved labels/scores.")
    bad = labels == 0
    nb, ng = int(bad.sum()), int((~bad).sum())
    if not nb or not ng:
        raise ValueError("Both classes are required for score plots.")
    order = np.argsort(-scores, kind="stable")
    sorted_scores = scores[order]
    ends = np.r_[np.flatnonzero(np.diff(sorted_scores)), len(scores) - 1]
    tp = np.cumsum(bad[order])[ends].astype(float)
    fp = (ends + 1) - tp
    recall, precision, fpr = tp / nb, tp / (tp + fp), fp / ng
    # Average precision matches the pipeline's pr_auc_bad definition (step integral).
    ap = float(np.sum(np.diff(np.r_[0., recall]) * precision))
    rx, ry = np.r_[0., fpr], np.r_[0., recall]
    auc = float(np.sum(np.diff(rx) * (ry[:-1] + ry[1:]) / 2))
    keep = np.unique(np.linspace(0, len(ends) - 1, min(350, len(ends))).astype(int))
    sweep = []
    thresholds = np.r_[sorted_scores[ends][keep], np.nextafter(scores.max(), np.inf)]
    if number(threshold) is not None:
        thresholds = np.r_[thresholds, float(threshold)]
    bad_sorted, good_sorted = np.sort(scores[bad]), np.sort(scores[~bad])
    for cutoff in np.unique(thresholds):
        fn = int(np.searchsorted(bad_sorted, cutoff, side="left"))
        tn = int(np.searchsorted(good_sorted, cutoff, side="left"))
        sweep.append(dict(threshold=float(cutoff), fn=fn, fp=ng-tn, tp=nb-fn, tn=tn,
                          escape=fn/nb, reject=(ng-tn)/ng, accuracy=(nb-fn+tn)/(nb+ng)))
    lo, hi = float(scores.min()), float(scores.max())
    if lo == hi:
        lo, hi = lo - .01, hi + .01
    edges = np.linspace(lo, hi, 31)
    return dict(n_bad=nb, n_good=ng, ap=ap, roc_auc=auc, prevalence=nb/(nb+ng),
                pr=[[0., 1.]] + [[float(recall[i]), float(precision[i])] for i in keep],
                roc=[[0., 0.]] + [[float(fpr[i]), float(recall[i])] for i in keep],
                hist=dict(x=((edges[:-1]+edges[1:])/2).tolist(),
                          bad=np.histogram(scores[bad], bins=edges)[0].tolist(),
                          good=np.histogram(scores[~bad], bins=edges)[0].tolist()),
                sweep=sweep)


def safe_child(root, name):
    value = (root / name).resolve()
    if not value.is_relative_to(root.resolve()):
        raise ValueError("Candidate path escapes its run directory.")
    return value


def load_run(run):
    run = Path(run).resolve()
    warnings = []

    def doc(name, default):
        try:
            return read_json(run / name, default)
        except (OSError, ValueError) as exc:
            warnings.append(f"Could not read {name}: {exc}")
            return default

    cfg, state, selected = doc("config.json", {}), doc("model_state.json", {}), doc("selected.json", {})
    rows = read_csv(run / "manifest.csv")
    candidates = doc("candidates.json", [])
    if not candidates and selected:
        candidates = [selected]
    integrity = doc("selection_integrity.json", {})
    if selected and integrity.get("sha256"):
        digest = hashlib.sha256((run / "selected.json").read_bytes()).hexdigest()
        if digest != integrity["sha256"]:
            warnings.append("Selected record changed after selection. Stored metrics may be stale; this report does not certify integrity.")
    models = []
    for folder in sorted((run / "models").glob("*")):
        if not folder.is_dir():
            continue
        history = [{k: number(v) for k, v in row.items()} for row in read_csv(folder / "history.csv")]
        telemetry = []
        sessions = []
        for session in sorted((folder / "visual_telemetry").glob("*")):
            try:
                meta = read_json(session / "session.json", {})
                sessions.append(meta)
                for row in read_csv(session / "batch_windows.csv"):
                    telemetry.append({**{k: number(v) for k, v in row.items()}, "session": session.name})
            except (OSError, ValueError) as exc:
                warnings.append(f"Partial telemetry for {folder.name}: {exc}")
        models.append(dict(name=folder.name, history=history, telemetry=telemetry,
                           sessions=sessions, progress=read_json(folder / "progress.json", {})))
    result_candidates = []
    for candidate in candidates:
        name = candidate.get("name", "unknown")
        entry = {k: candidate.get(k) for k in ("name", "threshold", "score_type", "selection_metrics", "threshold_metrics", "empirical_target_met", "selection_seconds")}
        entry["selected"] = name == selected.get("name")
        entry["members"] = len(candidate.get("members", []))
        for split in ("threshold", "selection"):
            entry[split + "_plot"] = None
            try:
                target = safe_child(run / "scores", name) / (split + ".npy")
                if target.is_file():
                    scores = np.load(target, allow_pickle=False)
                    labels = [int(r["label"]) for r in rows if r.get("split") == split]
                    entry[split + "_plot"] = score_summary(labels, scores, candidate.get("threshold"))
            except (OSError, ValueError) as exc:
                warnings.append(f"{name}/{split} score plots unavailable: {exc}")
        met = entry.get("selection_metrics") or {}
        sec, n = number(entry.get("selection_seconds")), number(met.get("n_images"))
        entry["selection_images_per_second"] = n/sec if sec and sec > 0 and n else None
        entry["selection_ms_per_image"] = sec*1000/n if sec is not None and sec >= 0 and n else None
        result_candidates.append(entry)
    counts = {}
    for row in rows:
        count = counts.setdefault(row.get("split", "unknown"), {"bad": 0, "good": 0})
        if str(row.get("label")) in ("0", "1"):
            count["bad" if str(row["label"]) == "0" else "good"] += 1
    if not cfg.get("independent_units_confirmed", False):
        warnings.append("Physical unit independence is not confirmed. Confidence bounds require independent units.")
    if not candidates:
        warnings.append("No selected candidate recorded. This may be an audit, running, interrupted or failed run.")
    # Intentionally read only already-recorded final-test summaries; never test scores/images.
    final = doc("final_test_summary.json", None)
    config_keys = ("profile", "task", "models", "seeds", "image_size", "resize", "device", "num_workers",
                   "cpu_threads", "training", "policy", "augmentation", "pilot", "independent_units_confirmed")
    return clean(dict(id=run.name, task=cfg.get("task", run.parent.name), status=state.get("status", "UNKNOWN"),
                      selection_signature=selection_signature(rows), counts=counts,
                      config={k: cfg.get(k) for k in config_keys}, environment=doc("environment.json", {}),
                      selected_name=selected.get("name"), candidates=result_candidates, models=models,
                      final_test=final, warnings=warnings, created_at=state.get("created_at")))


def discover_runs(root, task=None):
    root = Path(root).resolve()
    if (root / "config.json").is_file():
        return [root]
    if task and root.name != task:
        root = root / task
    # The result root has at most task/run/config.json. Do not recursively inspect datasets.
    return sorted({p.parent for pattern in ("*/config.json", "*/*/config.json") for p in root.glob(pattern)})


def config_results(path):
    import yaml
    path = Path(path).resolve()
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    return (path.parent / raw.get("paths", {}).get("output_root", "results")).resolve()


def build_report(runs, output, *, demo=False):
    output = Path(output).resolve()
    if output.suffix.lower() != ".html":
        raise ValueError("Output must be an .html file.")
    if not runs:
        raise ValueError("No run config.json found. Check --results, --config or --run.")
    data = dict(version="1.0.0", generated_at=datetime.now(timezone.utc).isoformat(), demo=demo,
                runs=[load_run(p) for p in runs])
    template = Path(__file__).with_name("dashboard.html").read_text(encoding="utf-8")
    payload = json.dumps(data, ensure_ascii=False, allow_nan=False).replace("<", "\\u003c").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    html = template.replace("__REPORT_DATA__", payload)
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        raise FileExistsError(f"Output exists: {output}. Choose a new filename to retain snapshots.")
    with output.open("x", encoding="utf-8") as stream:
        stream.write(html)
    print(f"Report: {output}\nRuns: {len(runs)}. Open this HTML in a browser; no server or network required.")
    return output


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    src = parser.add_mutually_exclusive_group(required=True)
    src.add_argument("--run", action="append", help="Run folder; repeat to compare runs.")
    src.add_argument("--results", help="Results root or task results folder.")
    src.add_argument("--config", help="Project YAML, used only to find output_root.")
    parser.add_argument("--task", choices=["vig", "top", "bottom"])
    parser.add_argument("--output", help="New HTML path. Default: timestamped file under results/visual_reports.")
    args = parser.parse_args(argv)
    try:
        if args.run:
            runs = [Path(p).resolve() for p in args.run]
            root = runs[0].parent
        else:
            root = config_results(args.config) if args.config else Path(args.results).resolve()
            runs = discover_runs(root, args.task)
        output = args.output or root / "visual_reports" / ("inspection_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f") + ".html")
        build_report(runs, output)
        return 0
    except (ValueError, OSError, KeyError, TypeError) as exc:
        print(f"Report error: {exc}", file=sys.stderr)
        return 2

