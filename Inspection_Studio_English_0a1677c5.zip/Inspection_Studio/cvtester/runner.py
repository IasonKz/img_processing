import json
from pathlib import Path
from time import perf_counter

from .catalog import check_metadata, select_model


def load_model(name, purpose, device):
    import timm
    import torch
    from huggingface_hub import HfApi, hf_hub_download
    from safetensors.torch import load_file

    spec = select_model(name, purpose)
    info = HfApi().model_info(spec.repo_id)
    revision = check_metadata(spec, info)
    config_path = hf_hub_download(spec.repo_id, "config.json", revision=revision)
    config = json.loads(Path(config_path).read_text())
    if config.get("architecture") != spec.checkpoint.split(".")[0] or config.get("num_classes") != 1000:
        raise ValueError("Checkpoint is not the expected ImageNet-1k classifier")
    # Never call pretrained=True: timm's fallback may deserialize pickle weights.
    model = timm.create_model(spec.checkpoint, pretrained=False,
                              pretrained_cfg=config["pretrained_cfg"])
    weights = hf_hub_download(spec.repo_id, "model.safetensors", revision=revision)
    model.load_state_dict(load_file(weights), strict=True)
    selected_device = torch.device(device)
    if selected_device.type == "cuda" and not torch.cuda.is_available():
        raise ValueError("CUDA was requested but is unavailable; use --device cpu")
    model = model.eval().to(selected_device)
    transform = timm.data.create_transform(
        **timm.data.resolve_model_data_config(model), is_training=False)
    metadata = {"model": name, "repo_id": spec.repo_id, "revision": revision,
                "license": spec.license, "purpose": purpose, "device": str(selected_device),
                "parameters": sum(p.numel() for p in model.parameters())}
    return model, transform, metadata


def predict(name, image, purpose="commercial", device="cpu", top_k=5):
    import torch
    from PIL import Image, ImageOps
    from timm.data import ImageNetInfo

    if not 1 <= top_k <= 1000:
        raise ValueError("top-k must be between 1 and 1000")
    model, transform, metadata = load_model(name, purpose, device)
    with Image.open(image) as source:
        tensor = transform(ImageOps.exif_transpose(source).convert("RGB")).unsqueeze(0).to(device)
    with torch.inference_mode():
        values, indices = model(tensor).softmax(dim=-1).topk(top_k)
    labels = ImageNetInfo()
    metadata["predictions"] = [
        {"index": index, "synset": labels.index_to_label_name(index),
         "label": labels.index_to_description(index), "probability": probability}
        for probability, index in zip(values[0].tolist(), indices[0].tolist())]
    return metadata


def class_indices(classes, class_map=None):
    from timm.data import ImageNetInfo

    if class_map is None:
        labels = ImageNetInfo()
        lookup = {synset: index for index, synset in enumerate(labels.label_names())}
        if any(name not in lookup for name in classes):
            raise ValueError("Use ImageNet synset folder names or --class-map JSON "
                             "mapping each folder to an ImageNet index (0..999). "
                             "Custom classes require fine-tuning a new head.")
        return [lookup[name] for name in classes]
    if set(class_map) != set(classes):
        raise ValueError("Class map keys must match dataset class folders exactly")
    indices = [class_map[name] for name in classes]
    if any(type(index) is not int or not 0 <= index < 1000 for index in indices):
        raise ValueError("Class map values must be integer ImageNet indices (0..999)")
    if len(set(indices)) != len(indices):
        raise ValueError("Each folder must map to a distinct ImageNet class")
    return indices


def benchmark(name, dataset, purpose="commercial", device="cpu", batch_size=8,
              class_map=None, workers=0):
    import torch
    from torchvision.datasets import ImageFolder
    from torch.utils.data import DataLoader

    if batch_size < 1 or workers < 0:
        raise ValueError("Batch size must be positive and workers nonnegative")
    images = ImageFolder(dataset)
    mapping = torch.tensor(class_indices(images.classes, class_map), device=device)
    model, transform, metadata = load_model(name, purpose, device)
    images.transform = transform
    loader = DataLoader(images, batch_size=batch_size, num_workers=workers,
                        shuffle=False, pin_memory=device.startswith("cuda"))
    total = correct1 = correct5 = 0
    elapsed = 0.0
    with torch.inference_mode():
        # Warm up the same input shape before measuring model forward time.
        warmup, _ = next(iter(loader))
        model(warmup.to(device))
        for batch, targets in loader:
            batch = batch.to(device)
            targets = mapping[targets.to(device)]
            if device.startswith("cuda"):
                torch.cuda.synchronize(device)
            start = perf_counter()
            logits = model(batch)
            if device.startswith("cuda"):
                torch.cuda.synchronize(device)
            elapsed += perf_counter() - start
            top5 = logits.topk(5, dim=-1).indices
            correct1 += (top5[:, 0] == targets).sum().item()
            correct5 += (top5 == targets[:, None]).any(dim=1).sum().item()
            total += len(targets)
    metadata.update(samples=total, top1=correct1 / total, top5=correct5 / total,
                    forward_seconds=elapsed, forward_images_per_second=total / elapsed,
                    batch_size=batch_size, input_size=list(batch.shape[1:]))
    return metadata
