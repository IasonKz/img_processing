# Validation Report

Release: **0.2.0 — Top Segmentation Pilot**

This release changes annotation geometry, object editing and dataset exclusion. No real inspection dataset or trained weights are included.

The Python suite completed **70 tests: 68 passed and 2 skipped** (PyTorch unavailable).

## Verified software behavior

The Python regression suite covers:

- Polygon validation, native pixel-centre rasterization, legacy ellipse compatibility and exact polygon boundary guards.
- Automatic per-pixel Inner/Outer assignment, preserving background and splitting annotations at the boundary.
- Detection of synthetic clipped-corner and rotated polygon outlines; conservative fallback for uniform and circular inputs.
- Independent annotation footprints, overlaps, hidden objects included in export, revision round trips and legacy-mask migration.
- Rejection after approval, immutable prior revisions/snapshots, restore to draft, source preservation and stale-revision rejection.
- Real local HTTP requests for editing, object integrity, nonmutating boundary detection, rejection, restoration and dataset exclusion.
- Existing import, duplicate, grouping, dataset, preprocessing and metric checks.

See [validation/unit_tests.txt](validation/unit_tests.txt) for the recorded Python run and the other transcripts in the same folder for JavaScript/CLI checks.

## Boundary detection limits

Synthetic geometry tests exercise software behavior and do not establish performance on production inspection images. The supplied photograph of a monitor has a faint boundary and display/photograph artifacts; the detector conservatively returned no reliable polygon. Use the original native inspection image and visually review the outline, or place/adjust its corners manually. Detection never approves annotations.

## Browser verification limit

Playwright was available, but no Chromium executable was installed. One bounded attempt to obtain the headless browser timed out. The real-browser test is included, but successful full browser interaction or visual layout verification is **not claimed** for this delivery. The Node controller simulation passed with **21 real HTTP requests**, exercising the unchanged application controller against the actual local server. It uses DOM/canvas stubs and is not a substitute for actual browser rendering. The JavaScript raster/object tests also passed, including seeded sparse eraser/stroke cases.

The optional test `tests/test_ui_browser.js` exercises background panning, polygon boundaries and classification, independent object visibility/deletion/persistence, undo/redo, rejection/restoration and original-file hashes. It creates isolated synthetic data and does not open an operator project.

## Neural verification limit

PyTorch was unavailable. The actual U-Net forward/backward and train/fine-tune/predict tests are skipped, not counted as passed. The training implementation is retained; its synthetic integration fixture now defines a boundary that places its two defect examples in their intended classes. This annotation update does not claim improved model accuracy.

## Reproduce

```bash
python segmentation.py doctor
python -m unittest discover -s tests -v
node tests/test_mask.js
node tests/test_ui_controller.js
```

With Playwright and Chromium installed:

```bash
node tests/test_ui_browser.js
```

Node and Playwright are developer-test dependencies only. Operating the annotation interface still needs just Python dependencies from `requirements.txt` and a local browser.
