"""Object identity, display visibility, legacy migration and reversible rejection."""
from copy import deepcopy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
from PIL import Image

from topseg.annotations import encode_rle, decode_rle, objects_from_mask, validate_objects
from topseg.classical import reclassify_mask, validate_roi
from topseg.common import DEFAULTS, atomic_json, merge, read_json, sha256
from topseg.project import Project, ConflictError


class ObjectEncodingTests(unittest.TestCase):
    def test_connected_component_migration_is_lossless_including_touching_classes(self):
        mask = np.zeros((23, 31), dtype=np.uint8)
        mask[1:5, 3:6] = 1
        mask[5:8, 6:9] = 2  # diagonal connectivity joins the same defect
        mask[15:19, 2:5] = 2
        objects = objects_from_mask(mask)
        self.assertEqual(len(objects), 2)
        _, support = validate_objects(objects, 31, 23)
        np.testing.assert_array_equal(support > 0, mask > 0)
        self.assertEqual(objects, objects_from_mask(mask))

    def test_strict_binary_footprints_unique_ids_and_bounded_strings(self):
        base = {'id': 'shape-1', 'name': 'Polygon 1', 'kind': 'polygon',
                'visible': True, 'mask_rle': [[0, 3], [1, 3]]}
        for field, value in [('visible', 1), ('id', '../shape'), ('name', 'x' * 201),
                             ('kind', 'unknown'), ('mask_rle', [[2, 6]]),
                             ('mask_rle', [[1, True], [0, 5]]),
                             ('mask_rle', [[0, 6]]), ('mask_rle', [[1, 5]])]:
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                validate_objects([dict(base, **{field: value})], 3, 2)
        with self.assertRaisesRegex(ValueError, 'unique'):
            validate_objects([base, deepcopy(base)], 3, 2)
        hidden = dict(base, visible=False)
        _, support = validate_objects([hidden], 3, 2)
        self.assertEqual(int(support.sum()), 3)


class AnnotationObjectProjectTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source = self.root / 'source'; self.source.mkdir()
        self.original = self.source / 'lens.png'
        Image.fromarray(np.full((40, 60, 3), 125, dtype=np.uint8)).save(self.original)
        self.original_hash = sha256(self.original)
        self.cfg = merge(DEFAULTS, {'input_dir': str(self.source),
                                  'project_dir': str(self.root / 'project'),
                                  'output_dir': str(self.root / 'results')})
        self.project = Project(self.cfg)
        self.project.import_images()
        self.image_id = self.project.items()[0]['id']
        self.roi = {'type': 'polygon', 'points': [{'x': 15, 'y': 10}, {'x': 45, 'y': 10}, {'x': 45, 'y': 30}, {'x': 15, 'y': 30}]}
        # One closed object crosses the inner/outer boundary and becomes two
        # semantic classes while preserving its identity and full footprint.
        self.mask = np.zeros((40, 60), dtype=np.uint8)
        self.mask[18:22, 8:30] = 1
        self.objects = [{'id': 'polygon-closed-1', 'name': 'Lens scratch', 'kind': 'polygon',
                         'visible': True, 'mask_rle': encode_rle(self.mask > 0)}]

    def tearDown(self):
        self.temp.cleanup()

    def saved_mask(self):
        with Image.open(self.project.mask_path(self.image_id)) as image:
            return np.asarray(image).copy()

    def save(self, **kwargs):
        return self.project.save_annotation(self.image_id, self.mask, roi=self.roi,
                                            objects=self.objects, **kwargs)

    def test_polygon_geometry_relabels_without_filling_unannotated_pixels(self):
        saved = self.save()
        expected = reclassify_mask(self.mask, self.roi)
        np.testing.assert_array_equal(self.saved_mask(), expected)
        self.assertEqual(self.saved_mask()[19, 12], 2)
        self.assertEqual(self.saved_mask()[19, 20], 1)
        self.assertEqual(self.saved_mask()[12, 20], 0)
        self.assertEqual(saved['objects'][0]['id'], 'polygon-closed-1')
        self.assertEqual(self.project.open_image(self.image_id)['objects'], self.objects)

    def test_hidden_objects_round_trip_and_remain_in_training_export(self):
        self.objects[0]['visible'] = False
        saved = self.save(approved=True)
        self.assertFalse(saved['objects'][0]['visible'])
        dataset_path = self.project.snapshot(self.root / 'dataset')
        record = read_json(dataset_path)['records'][0]
        with Image.open(dataset_path.parent / record['mask']) as image:
            np.testing.assert_array_equal(np.asarray(image), reclassify_mask(self.mask, self.roi))
        self.assertFalse(self.project.open_image(self.image_id)['objects'][0]['visible'])

    def test_object_mask_mismatch_is_rejected_without_creating_revision(self):
        self.mask[1, 1] = 2
        with self.assertRaisesRegex(ValueError, 'footprints'):
            self.save()
        self.assertEqual(self.project.items()[0]['revision'], 0)
        self.assertFalse((self.project.root / 'history').exists())

    def test_overlapping_objects_are_independently_deletable(self):
        another = np.zeros_like(self.mask)
        another[20:25, 20:40] = 1
        second = dict(self.objects[0], id='circle-2', kind='circle', name='Spot', mask_rle=encode_rle(another))
        combined = ((self.mask > 0) | (another > 0)).astype(np.uint8)
        saved = self.project.save_annotation(self.image_id, combined, roi=self.roi,
                                            objects=self.objects + [second])
        updated = self.project.save_annotation(self.image_id, another, roi=self.roi,
                                              objects=[second], expected_revision=saved['revision'])
        self.assertEqual(len(updated['objects']), 1)
        np.testing.assert_array_equal(self.saved_mask() > 0, another > 0)

    def test_reject_preserves_source_annotations_history_and_excludes_snapshot(self):
        approved = self.save(approved=True, notes='Review microscopy image')
        old_mask = self.saved_mask()
        old_record = read_json(self.project.root / approved['mask'].replace('mask.png', 'annotation.json'))
        snapshot = self.project.snapshot(self.root / 'before_reject')
        frozen = (snapshot.parent / read_json(snapshot)['records'][0]['mask']).read_bytes()
        rejected = self.project.set_rejected(self.image_id, True, approved['revision'], 'Blurred exposure')
        self.assertEqual(rejected['status'], 'rejected')
        self.assertFalse(rejected['approved'])
        self.assertEqual(rejected['objects'], approved['objects'])
        self.assertEqual(rejected['roi'], approved['roi'])
        self.assertEqual(rejected['notes'], approved['notes'])
        self.assertEqual(rejected['rejection_reason'], 'Blurred exposure')
        np.testing.assert_array_equal(self.saved_mask(), old_mask)
        self.assertEqual(sha256(self.original), self.original_hash)
        self.assertEqual(read_json(self.project.root / approved['mask'].replace('mask.png', 'annotation.json')), old_record)
        with self.assertRaisesRegex(ValueError, 'No reviewed'):
            self.project.snapshot(self.root / 'after_reject')
        self.assertEqual((snapshot.parent / read_json(snapshot)['records'][0]['mask']).read_bytes(), frozen)
        with self.assertRaises(ConflictError):
            self.project.set_rejected(self.image_id, False, approved['revision'])
        with self.assertRaisesRegex(ValueError, 'Restore'):
            self.save(approved=True, expected_revision=rejected['revision'])
        restored = self.project.set_rejected(self.image_id, False, rejected['revision'])
        self.assertEqual(restored['status'], 'draft')
        self.assertFalse(restored['approved'])
        np.testing.assert_array_equal(self.saved_mask(), old_mask)
        with self.assertRaisesRegex(ValueError, 'No reviewed'):
            self.project.snapshot(self.root / 'after_restore')
        with self.assertRaisesRegex(ValueError, 'Only rejected'):
            self.project.set_rejected(self.image_id, False, restored['revision'])

    def test_editing_rejected_image_does_not_silently_restore_it(self):
        saved = self.save()
        rejected = self.project.set_rejected(self.image_id, True, saved['revision'])
        edited = self.save(expected_revision=rejected['revision'])
        self.assertEqual(edited['status'], 'rejected')

    def test_legacy_open_preserves_saved_labels_and_revision_until_explicit_save(self):
        saved = self.save()
        mask_path = self.project.root / saved['mask']
        # Construct the exact on-disk format emitted by v0.1, including manually
        # assigned labels that no longer agree with automatic ROI classes.
        Image.fromarray(self.mask).save(mask_path)
        record = read_json(mask_path.parent / 'annotation.json')
        record.pop('objects'); record.pop('objects_schema_version')
        record['roi'] = {'cx': 30, 'cy': 20, 'rx': 14, 'ry': 14}
        record['mask_sha256'] = sha256(mask_path)
        atomic_json(mask_path.parent / 'annotation.json', record)
        current_path = self.project.root / 'annotations' / f'{self.image_id}.json'
        atomic_json(current_path, record)
        before = current_path.read_bytes()
        opened = self.project.open_image(self.image_id)
        self.assertEqual(opened['revision'], saved['revision'])
        self.assertEqual(current_path.read_bytes(), before)
        self.assertEqual(len(opened['objects']), 1)
        np.testing.assert_array_equal(self.saved_mask(), self.mask)
        rejected = self.project.set_rejected(self.image_id, True, opened['revision'])
        np.testing.assert_array_equal(self.saved_mask(), self.mask)
        restored = self.project.set_rejected(self.image_id, False, rejected['revision'])
        np.testing.assert_array_equal(self.saved_mask(), self.mask)
        final = self.project.save_annotation(self.image_id, self.mask, roi=self.roi,
                                            objects=opened['objects'], expected_revision=restored['revision'])
        np.testing.assert_array_equal(self.saved_mask(), reclassify_mask(self.mask, self.roi))
        self.assertEqual(final['objects'][0]['id'], opened['objects'][0]['id'])

    def test_detection_is_nonmutating_and_revision_checked_before_and_after(self):
        saved = self.save()
        current = self.project.root / 'annotations' / f'{self.image_id}.json'
        original = current.read_bytes()
        with patch('topseg.project.detect_inner_roi', return_value=(self.roi, {'detected': True})):
            detected = self.project.detect_roi(self.image_id, saved['revision'])
            self.assertEqual(detected['roi'], self.roi)
            self.assertEqual(current.read_bytes(), original)
            with self.assertRaises(ConflictError):
                self.project.detect_roi(self.image_id, 0)
        def concurrent_save(*args, **kwargs):
            self.save(expected_revision=saved['revision'])
            return self.roi, {'detected': True}
        with patch('topseg.project.detect_inner_roi', side_effect=concurrent_save), self.assertRaises(ConflictError):
            self.project.detect_roi(self.image_id, saved['revision'])


if __name__ == '__main__':
    unittest.main()
