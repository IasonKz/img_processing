from __future__ import annotations

from datetime import datetime, timezone
import gc
import json
from pathlib import Path
import shutil
import traceback

import numpy as np

from .common import (EXTENSIONS, load_config, read_json, sha_file, write_csv, write_json,
                     merge_dict, DEFAULTS, safe_relative, dataset_fingerprint, utc_now, run_lock)
from .data import audit, make_manifest, read_manifest, pixel_signature, discover
from .policy import (metrics, tune_threshold_details, empirical_pass, evidence_pass,
                     selection_key, candidate_targets_met, POLICY_VERSION)
from .reporting import export_predictions, leaderboard, render_run_report


def write_state(run, status, **details):
    run = Path(run)
    path = run / "model_state.json"
    old = read_json(path) if path.exists() else {"schema_version": 2, "run_id": run.name,
                                               "created_at": utc_now(), "history": []}
    old.update(status=status, updated_at=utc_now(), **details)
    old.setdefault("history", []).append({"status": status, "at": old["updated_at"], **details})
    write_json(path, old)
    render_run_report(run)
    return old


def group_identities(rows):
    identities = set()
    for row in rows:
        identities.add(row.get("source_group") or row["group"])
        identities.add(row["group"])
        for key in ("source_groups", "group_aliases"):
            if row.get(key):
                identities.update(json.loads(row[key]))
    return identities


def external_history(run):
    """Retain inspected holdouts across generations and portable snapshots."""
    entries, visited, seen_entries = [], set(), set()
    cursor = Path(run).resolve()
    while cursor:
        if str(cursor) in visited:
            raise ValueError("Cyclic previous_run lineage.")
        visited.add(str(cursor))
        ledger = cursor / "external_evaluation_ledger.json"
        if ledger.exists():
            for entry in read_json(ledger):
                signature = (tuple(sorted(entry["pixel_hashes"])), tuple(sorted(entry["groups"])))
                if signature not in seen_entries:
                    seen_entries.add(signature)
                    entries.append(dict(entry, source_run=entry.get("source_run", cursor.name)))
        cfg, _ = open_run(cursor)
        cursor = Path(cfg["previous_run"]).resolve() if cfg.get("previous_run") else None
    return entries


def new_run(config_path, on_created=None):
    cfg = merge_dict(DEFAULTS, config_path) if isinstance(config_path, dict) else load_config(config_path)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
    run = Path(cfg["output_root"]) / cfg["task"] / stamp
    run.mkdir(parents=True, exist_ok=False)
    if on_created:
        on_created(run)
    print(f"RUN: {run}", flush=True)
    write_state(run, "AUDITING", task=cfg["task"], profile=cfg.get("profile", "custom"))
    try:
        inspected_holdouts = []
        if cfg.get("previous_run"):
            previous_cfg, _ = open_run(cfg["previous_run"])
            inspected_holdouts = external_history(cfg["previous_run"])
            # Auto geometry in an incremental run inherits the old input contract.
            if cfg["image_size"] == "auto":
                cfg["image_size"] = previous_cfg["image_size"]
        records = audit(cfg, run / "audit")
        historical_hashes = {value for entry in inspected_holdouts for value in entry["pixel_hashes"]}
        historical_groups = {value for entry in inspected_holdouts for value in entry["groups"]}
        if ({row["pixel_hash"] for row in records} & historical_hashes or
                group_identities(records) & historical_groups):
            raise ValueError("Development data overlaps a previously inspected external holdout. Keep qualification units outside the development dataset.")
        rows = make_manifest(cfg, records, run)
    except Exception as exc:
        write_json(run / "requested_config.json", cfg)
        write_state(run, "AUDIT_FAILED", error=str(exc))
        raise
    cfg["dataset_fingerprint"] = dataset_fingerprint(rows)
    write_json(run / "config.json", cfg)
    import yaml
    (run / "resolved_config.yaml").write_text(yaml.safe_dump(cfg, sort_keys=False), encoding="utf-8")
    write_json(run / "data_location.json", {"data_root": cfg["data_root"]})
    lineage = []
    if cfg.get("previous_run"):
        previous = Path(cfg["previous_run"])
        if (previous / "lineage.json").exists():
            lineage = read_json(previous / "lineage.json")
        lineage.append({"run_id": previous.name, "path": str(previous.resolve()),
                        "test_previously_used": (previous / "final_test_summary.json").exists(),
                        "dataset_fingerprint": previous_cfg.get("dataset_fingerprint")})
    write_json(run / "lineage.json", lineage)
    write_json(run / "external_evaluation_ledger.json", inspected_holdouts)
    write_json(run / "integrity.json", {"config_sha256": sha_file(run / "config.json"),
                                       "manifest_sha256": sha_file(run / "manifest.csv")})
    print((run / "split_summary.json").read_text(), flush=True)
    write_state(run, "PREPARED", dataset_fingerprint=cfg["dataset_fingerprint"],
                n_images=len(rows), n_groups=len({r["group"] for r in rows}))
    return run


def open_run(run):
    run = Path(run).resolve()
    integrity = read_json(run / "integrity.json")
    for filename, field in (("config.json", "config_sha256"), ("manifest.csv", "manifest_sha256")):
        if sha_file(run / filename) != integrity[field]:
            raise ValueError(f"Saved {filename} changed. Keep runs immutable; edit YAML and create a new run.")
    cfg = read_json(run / "config.json")
    rows = read_manifest(run / "manifest.csv")
    location = read_json(run / "data_location.json") if (run / "data_location.json").exists() else {"data_root": cfg["data_root"]}
    cfg["data_root"] = location["data_root"]
    for row in rows:
        relative = location.get("image_paths", {}).get(row["pixel_hash"], row["relative_path"])
        row["path"] = str(safe_relative(cfg["data_root"], relative))
    if (run / "dependency_locations.json").exists():
        dependencies = read_json(run / "dependency_locations.json")
        if set(dependencies) - {"weights_dir", "previous_run"}:
            raise ValueError("Unsupported portable dependency location key.")
        for key, relative in dependencies.items():
            cfg[key] = str(safe_relative(run, relative))
    # Runtime-only resource overrides never rewrite the experiment configuration.
    if (run / "runtime_overrides.json").exists():
        overrides = read_json(run / "runtime_overrides.json")
        if set(overrides) - {"device", "cpu_threads", "num_workers"}:
            raise ValueError("Runtime overrides may only change device, cpu_threads and num_workers.")
        cfg.update(overrides)
    return cfg, rows


def load_selected(run):
    run = Path(run)
    path = run / "selected.json"
    if (run / "selection_integrity.json").exists():
        expected = read_json(run / "selection_integrity.json")["sha256"]
        if sha_file(path) != expected:
            raise ValueError("Selected decision system changed after selection; create a new candidate version.")
    return read_json(path)


def verify_sources(rows):
    for row in rows:
        if pixel_signature(row["path"])[0] != row["pixel_hash"]:
            raise ValueError(f"An image changed since audit: {row['path']}. Create a new dataset/run version.")


def member_runtime_config(run, member, cfg):
    """Validate a candidate's immutable trial settings and apply runtime paths."""
    if not member.get("config"):
        return cfg
    config_path = safe_relative(run, member["config"])
    if sha_file(config_path) != member["config_sha256"]:
        raise ValueError(f"Trial configuration changed: {config_path}")
    member_cfg = merge_dict(cfg, read_json(config_path))
    for key in ("task", "image_size", "resize"):
        if member_cfg[key] != cfg[key]:
            raise ValueError(f"Candidate changed the shared {key} contract.")
    for key in ("device", "cpu_threads", "num_workers", "data_root", "weights_dir"):
        member_cfg[key] = cfg[key]
    return member_cfg


def predict_members(run, members, rows, cfg, stop_check=None, on_scores=None):
    from .engine import device_for, predict_checkpoint, torch_modules
    torch, _ = torch_modules()
    device = device_for(cfg)
    total = np.zeros(len(rows), dtype=float)
    seconds = 0.
    if not members:
        raise ValueError("At least one model member is required for inference.")
    for member_index, member in enumerate(members):
        if stop_check and stop_check():
            from .engine import TrainingStopped
            raise TrainingStopped("Selection or inference stopped at the requested limit.")
        path = safe_relative(run, member["checkpoint"])
        if sha_file(path) != member["sha256"]:
            raise ValueError(f"Checkpoint changed: {path}")
        member_cfg = member_runtime_config(run, member, cfg)
        options = {"stop_check": stop_check} if stop_check is not None else {}
        if on_scores is not None and member_index == len(members) - 1:
            def publish(offset, chunk):
                # Previous members are complete. The last member completes each
                # averaged ensemble decision, without loading all models at once.
                chunk = np.asarray(chunk, dtype=float)
                on_scores(offset, total[offset:offset + len(chunk)] + chunk / len(members))
            options["on_scores"] = publish
        scores, elapsed = predict_checkpoint(path, rows, member_cfg, device, **options)
        total += scores / len(members)
        seconds += elapsed
        gc.collect()
        if device.type == "cuda":
            torch.cuda.empty_cache()
    return total, seconds


def run_training(run, stop_check=None):
    from .engine import TrainingStopped
    with run_lock(run):
        try:
            return _run_training(run, stop_check=stop_check)
        except TrainingStopped as exc:
            write_state(run, "PAUSED", error=str(exc),
                        checkpoint_scope="last successfully committed epoch")
            return Path(run)
        except KeyboardInterrupt:
            write_state(run, "INTERRUPTED", error="Operator interrupted execution; completed-epoch checkpoint retained.")
            raise
        except Exception as exc:
            write_state(run, "FAILED", error=str(exc))
            raise


def _run_training(run, stop_check=None):
    from .engine import check_weights, train_one, torch_modules, weight_path, required_weight_names, TrainingStopped
    run = Path(run)
    cfg, rows = open_run(run)
    if (run / "selected.json").exists():
        print(f"Run already selected: {run / 'selected.json'}. Use test, predict or export.", flush=True)
        return run
    if stop_check and stop_check():
        raise TrainingStopped("Training stopped at the requested limit.")
    check_weights(cfg)
    verify_sources(rows)
    write_state(run, "TRAINING", error=None)
    torch, tv = torch_modules()
    import importlib.metadata
    versions = {}
    for package in ("torch", "torchvision", "numpy", "Pillow", "scipy", "scikit-learn", "PyYAML", "matplotlib"):
        versions[package] = importlib.metadata.version(package)
    (run / "requirements_snapshot.txt").write_text("\n".join(f"{k}=={v}" for k, v in versions.items()) + "\n")
    write_json(run / "environment.json", {"torch": str(torch.__version__), "torchvision": str(tv.__version__),
                                          "numpy": np.__version__, "cuda_available": torch.cuda.is_available(),
                                          "cuda_runtime": str(torch.version.cuda),
                                          "pretrained_sha256": {n: sha_file(weight_path(cfg, n)) for n in required_weight_names(cfg)}
                                          if cfg.get("pretrained", True) else {}})
    jobs = [(f"{name}_seed{seed}", name, seed, None) for name in cfg["models"] for seed in cfg["seeds"]]
    incumbent = None
    if cfg.get("previous_run"):
        old_run = Path(cfg["previous_run"])
        previous = load_selected(old_run)
        old_cfg, _ = open_run(old_run)
        for key in ("task", "image_size", "resize"):
            if old_cfg[key] != cfg[key]:
                raise ValueError(f"Incremental run requires the same {key}; use a new independent run for preprocessing changes.")
        incumbent_members = []
        for i, member in enumerate(previous["members"]):
            source = old_run / member["checkpoint"]
            if sha_file(source) != member["sha256"]:
                raise ValueError("Previous model checkpoint changed.")
            target = run / "incumbent" / f"member{i}.pt"
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            new_member = {**member, "checkpoint": target.relative_to(run).as_posix()}
            if member.get("config"):
                source_config = safe_relative(old_run, member["config"])
                if sha_file(source_config) != member["config_sha256"]:
                    raise ValueError("Previous candidate configuration changed.")
                target_config = target.with_suffix(".config.json")
                shutil.copy2(source_config, target_config)
                new_member.update(config=target_config.relative_to(run).as_posix(),
                                  config_sha256=sha_file(target_config))
            incumbent_members.append(new_member)
            if cfg.get("fine_tune_previous", True) and member["architecture"] != "patchcore":
                arch = member["architecture"]
                seed = cfg["seeds"][0]
                jobs.append((f"{arch}_finetune_member{i}_seed{seed}", arch, seed, target))
        incumbent = {"name": "incumbent_frozen", "members": incumbent_members,
                     "fixed_threshold": previous["threshold"], "score_type": previous.get("score_type", "bad_probability_uncalibrated")}
    base, failures = [], []
    for job_name, arch, seed, initial in jobs:
        if stop_check and stop_check():
            raise TrainingStopped("Training stopped at the requested limit.")
        target = run / "models" / job_name
        write_state(run, "TRAINING", current_candidate=job_name)
        try:
            done = target / "completed.json"
            if done.exists():
                if sha_file(target / "best.pt") != read_json(done)["checkpoint_sha256"]:
                    raise ValueError("Completed checkpoint checksum changed.")
                checkpoint = target / "best.pt"
                print(f"Reusing completed candidate: {job_name}", flush=True)
            else:
                options = {"stop_check": stop_check} if stop_check is not None else {}
                checkpoint = train_one(arch, seed, rows, cfg, target, initial, **options)
            meta = read_json(done)
            base.append({"name": job_name, "architecture": arch,
                         "score_type": "anomaly_distance" if arch == "patchcore" else "bad_probability_uncalibrated",
                         "val_pr_auc_bad": meta["best_val_pr_auc_bad"],
                         "members": [{"checkpoint": checkpoint.relative_to(run).as_posix(),
                                      "sha256": sha_file(checkpoint), "architecture": arch}]})
        except TrainingStopped:
            raise
        except Exception as exc:
            failures.append({"name": job_name, "error": str(exc), "traceback": traceback.format_exc()})
            write_json(run / "failed_candidates.json", failures)
            print(f"FAILED: {job_name}: {exc}", flush=True)
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            if not cfg.get("continue_on_model_error", True):
                raise
    if not base:
        raise RuntimeError("No new candidate trained successfully; inspect failed_candidates.json.")
    options = {"stop_check": stop_check} if stop_check is not None else {}
    return select_candidates(run, base, failures, cfg, rows, incumbent=incumbent, **options)


def select_candidates(run, base, failures, cfg, rows, incumbent=None, stop_check=None):
    """Freeze validation-defined candidates, then calibrate and select.

    Search and regular training share this exact selection protocol. No test
    rows are read or predicted here. A caller may impose a wall-clock stop.
    """
    run = Path(run)
    if not base:
        raise ValueError("Selection requires at least one completed candidate.")

    def check_stop():
        if stop_check and stop_check():
            from .engine import TrainingStopped
            raise TrainingStopped("Selection paused at the requested limit.")

    check_stop()
    # Candidate ensembles are defined from validation results, before reading selection labels/scores.
    candidates = list(base)
    if cfg.get("ensembles", True):
        arch_winners = []
        for arch in sorted({c["architecture"] for c in base if c["architecture"] != "patchcore"}):
            same = sorted([c for c in base if c["architecture"] == arch], key=lambda c: (-c["val_pr_auc_bad"], c["name"]))
            arch_winners.append(same[0])
            if len(same) >= 2:
                candidates.append({"name": f"{arch}_mean", "score_type": "bad_probability_uncalibrated", "members": [member for c in same for member in c["members"]]})
        top = sorted(arch_winners, key=lambda c: (-c["val_pr_auc_bad"], c["name"]))[:3]
        if len(top) >= 2:
            candidates.append({"name": "top_architectures_mean", "score_type": "bad_probability_uncalibrated", "members": [member for c in top for member in c["members"]]})
    if incumbent:
        candidates.append(incumbent)
    write_state(run, "SELECTING", current_candidate=None)
    threshold_rows = [r for r in rows if r["split"] == "threshold"]
    selection_rows = [r for r in rows if r["split"] == "selection"]
    # Cache member scores once; ensembles reuse the same images/scores without extra model passes.
    cache = {}
    for c in candidates:
        check_stop()
        for member in c["members"]:
            key = member["checkpoint"]
            if key not in cache:
                print(f"Evaluating {key} on threshold and selection data", flush=True)
                options = {"stop_check": stop_check} if stop_check is not None else {}
                tscore, _ = predict_members(run, [member], threshold_rows, cfg, **options)
                sscore, sec = predict_members(run, [member], selection_rows, cfg, **options)
                cache[key] = tscore, sscore, sec
    for c in candidates:
        check_stop()
        tscore = np.mean([cache[m["checkpoint"]][0] for m in c["members"]], axis=0)
        sscore = np.mean([cache[m["checkpoint"]][1] for m in c["members"]], axis=0)
        threshold = c.get("fixed_threshold")
        if threshold is None:
            c["threshold_decision"] = tune_threshold_details([r["label"] for r in threshold_rows], tscore, cfg["policy"])
            threshold = c["threshold_decision"]["threshold"]
            if not c["threshold_decision"]["targets_feasible"]:
                print(f"{c['name']}: no calibration threshold meets BOTH targets. "
                      "Using a balanced-accuracy fallback for development; targets remain unmet.", flush=True)
        else:
            c["threshold_decision"] = {"threshold": threshold, "mode": "frozen_incumbent", "policy_version": POLICY_VERSION}
        c["threshold"] = threshold
        c["threshold_metrics"] = metrics([r["label"] for r in threshold_rows], tscore, threshold,
                                          [r["group"] for r in threshold_rows], cfg["policy"]["confidence"])
        c["selection_metrics"] = metrics([r["label"] for r in selection_rows], sscore, threshold,
                                          [r["group"] for r in selection_rows], cfg["policy"]["confidence"])
        c["selection_seconds"] = sum(cache[m["checkpoint"]][2] for m in c["members"])
        c["selection_target_met"] = empirical_pass(c["selection_metrics"], cfg["policy"])
        c["threshold_target_met"] = empirical_pass(c["threshold_metrics"], cfg["policy"])
        c["empirical_target_met"] = candidate_targets_met(c, cfg["policy"])
        target = run / "scores" / c["name"]
        target.mkdir(parents=True, exist_ok=True)
        np.save(target / "threshold.npy", tscore, allow_pickle=False)
        np.save(target / "selection.npy", sscore, allow_pickle=False)
        write_json(target / "provenance.json", {
            "manifest_sha256": sha_file(run / "manifest.csv"), "candidate": c["name"],
            "files": {name: sha_file(target / name) for name in ("threshold.npy", "selection.npy")}})
        export_dir = run / "comparison_folders" / c["name"]
        export_stale = False
        if export_dir.exists():
            # A run interrupted before selection may contain old-policy exports.
            # Do not pair a new threshold with folders/metrics from an old one.
            complete = (export_dir / "export_complete.json").exists()
            rule = read_json(export_dir / "decision_rule.json") if (export_dir / "decision_rule.json").exists() else {}
            old_metrics = read_json(export_dir / "metrics.json") if (export_dir / "metrics.json").exists() else {}
            export_stale = not complete or rule.get("threshold") != threshold or "balanced_accuracy" not in old_metrics
        if export_stale:
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%f")
            export_dir.rename(export_dir.with_name(export_dir.name + "_superseded_" + stamp))
        if not export_dir.exists():
            export_predictions(selection_rows, sscore, threshold, export_dir,
                               copy_images=cfg.get("export_images", True), confidence=cfg["policy"]["confidence"],
                               score_type=c["score_type"], model_version=run.name + "/" + c["name"])
    candidates.sort(key=lambda c: selection_key(c, cfg["policy"]))
    winner = candidates[0]
    selected = {**winner, "task": cfg["task"], "policy": cfg["policy"], "decision_policy_version": POLICY_VERSION,
                "manifest_sha256": sha_file(run / "manifest.csv"),
                "selection_evidence_sufficient": (winner["empirical_target_met"] and evidence_pass(winner["selection_metrics"], cfg["policy"])
                                                  and cfg.get("independent_units_confirmed", False)),
                "final_test_completed": False,
                "comparison_complete": not failures, "failed_candidate_count": len(failures),
                "status": "PENDING_INDEPENDENT_TEST" if winner["empirical_target_met"] else "TARGET_NOT_MET",
                "notes": ["Selection metrics are development estimates, not a production guarantee.",
                          "Run the fixed winner on the held-out test once after finalizing development.",
                          "Infeasible targets use a balanced-accuracy development fallback; selection is not approval.",
                          "bad=0, good=1; positive event=bad; score_type defines the score scale."]}
    write_json(run / "candidates.json", candidates)
    leaderboard(candidates, winner, run)
    write_json(run / "selected.json", selected)
    write_json(run / "selection_integrity.json", {"sha256": sha_file(run / "selected.json")})
    write_state(run, selected["status"], selected_candidate=winner["name"],
                threshold=winner["threshold"], score_type=winner["score_type"],
                selection_metrics=winner["selection_metrics"], comparison_complete=not failures)
    if cfg.get("previous_run"):
        from .registry import compare_runs
        compare_runs(cfg["previous_run"], run)
    print(f"SELECTED: {winner['name']}, threshold={winner['threshold']:.8f}, status={selected['status']}", flush=True)
    print(f"Comparison: {run / 'comparison.html'}\nImage folders: {run / 'comparison_folders'}", flush=True)
    if failures:
        print(f"WARNING: {len(failures)} candidates failed. Winner is among successful candidates only; inspect failed_candidates.json.", flush=True)
    return run


def final_test(run, input_dir=None, groups_csv=None):
    with run_lock(run):
        return _final_test(run, input_dir, groups_csv)


def _final_test(run, input_dir=None, groups_csv=None):
    run = Path(run)
    cfg, rows = open_run(run)
    selected = load_selected(run)
    if input_dir is None and ((run / "final_test_summary.json").exists() or (run / "final_test").exists()):
        raise ValueError("This run already has a final test or partial test export. Read those results; do not retune using them.")
    export_dir = run / "final_test"
    summary_path = run / "final_test_summary.json"
    if input_dir is not None:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
        export_dir = run / "evaluations" / stamp / "predictions"
        summary_path = export_dir.parent / "summary.json"
        eval_cfg = merge_dict(cfg, {"data_root": str(Path(input_dir).resolve()),
                                   "groups_csv": str(Path(groups_csv).resolve()) if groups_csv else None,
                                   "previous_run": None})
        if export_dir.resolve().is_relative_to(Path(eval_cfg["data_root"])):
            raise ValueError("External evaluation input must be outside the run output tree.")
        test = audit(eval_cfg, export_dir.parent / "audit")
        if {r["label"] for r in test} != {0, 1}:
            raise ValueError("External holdout requires both classes.")
        known_hashes = {r["pixel_hash"] for r in rows}
        known_groups = group_identities(rows)
        if any(r["pixel_hash"] in known_hashes for r in test):
            raise ValueError("External holdout overlaps known dataset images.")
        if group_identities(test) & known_groups:
            raise ValueError("External holdout overlaps known physical units.")
        ledger = external_history(run)
        previous_hashes = {k for entry in ledger for k in entry["pixel_hashes"]}
        previous_groups = {k for entry in ledger for k in entry["groups"]}
        if ({r["pixel_hash"] for r in test} & previous_hashes or
                group_identities(test) & previous_groups):
            raise ValueError("External holdout overlaps an earlier inspected evaluation; supply a fresh holdout.")
        # Register before scoring: failed/partial inspection is not silently treated as unseen later.
        ledger.append({"at": utc_now(), "pixel_hashes": [r["pixel_hash"] for r in test],
                       "groups": sorted(group_identities(test)), "source_run": run.name,
                       "summary": summary_path.relative_to(run).as_posix()})
        write_json(run / "external_evaluation_ledger.json", ledger)
    else:
        test = [r for r in rows if r["split"] == "test"]
    verify_sources(test)
    write_state(run, "EVALUATING", evaluation_role="external" if input_dir else "final-test")
    scores, seconds = predict_members(run, selected["members"], test, cfg)
    met = export_predictions(test, scores, selected["threshold"], export_dir,
                             copy_images=cfg.get("export_images", True), confidence=cfg["policy"]["confidence"],
                             score_type=selected.get("score_type", "bad_probability_uncalibrated"), model_version=run.name)
    ancestor = cfg.get("previous_run")
    reused_test = False
    visited = {str(run.resolve())}
    lineage = read_json(run / "lineage.json") if (run / "lineage.json").exists() else []
    reused_test = any(entry.get("test_previously_used", False) for entry in lineage)
    while ancestor and input_dir is None:
        ancestor_path = Path(ancestor).resolve()
        if str(ancestor_path) in visited:
            raise ValueError("Cyclic previous_run lineage.")
        visited.add(str(ancestor_path))
        if not (ancestor_path / "config.json").exists():
            reused_test = True
            break
        if (ancestor_path / "final_test_summary.json").exists():
            reused_test = True
        ancestor = read_json(ancestor_path / "config.json").get("previous_run")
    if input_dir is not None:
        reused_test = False
    summary = {"candidate": selected["name"], "threshold": selected["threshold"], "metrics": met,
               "seconds_including_image_loading": seconds,
               "empirical_target_met": empirical_pass(met, cfg["policy"]),
               "confidence_bound_below_target": evidence_pass(met, cfg["policy"]),
               "statistical_target_supported": (evidence_pass(met, cfg["policy"])
                                                  and cfg.get("independent_units_confirmed", False) and not reused_test),
               "independent_units_confirmed": cfg.get("independent_units_confirmed", False),
               "test_used_in_previous_generation": reused_test,
               "evaluation_role": "external" if input_dir else "final-test",
               "selected_sha256": sha_file(run / "selected.json"),
               "evaluation_dataset_fingerprint": __import__("hashlib").sha256("\n".join(sorted(r["pixel_hash"] for r in test)).encode()).hexdigest(),
               "assumptions": "Fixed rule; independent representative groups; no prior tuning on this test.",
               "previous_run": cfg.get("previous_run"),
               "note": "A test reused across development cycles is a regression benchmark, not a fresh independent certification."}
    write_json(summary_path, summary)
    eligible = summary["empirical_target_met"] and not cfg.get("pilot", False)
    if cfg.get("release", {}).get("require_statistical_evidence", True):
        eligible = eligible and summary["statistical_target_supported"]
    if cfg.get("release", {}).get("require_complete_comparison", True):
        eligible = eligible and selected.get("comparison_complete", False)
    write_state(run, "QUALIFIED" if eligible else "EVALUATED_NOT_QUALIFIED",
                last_evaluation=summary_path.relative_to(run).as_posix(),
                final_metrics=met, empirical_target_met=summary["empirical_target_met"],
                statistical_target_supported=summary["statistical_target_supported"])
    print(f"Test: bad->good={met['bad_passed_as_good_FN']}/{met['n_bad']}, good->bad={met['good_rejected_as_bad_FP']}/{met['n_good']}", flush=True)
    print(f"Independent-unit escape upper bound: {met['bad_unit_escape_upper']}; target supported: {summary['statistical_target_supported']}", flush=True)
    return summary


def export_again(run, candidate_name, output):
    run = Path(run)
    cfg, rows = open_run(run)
    candidates = read_json(run / "candidates.json")
    if candidate_name == "selected":
        candidate_name = load_selected(run)["name"]
    chosen = candidates if candidate_name == "all" else [c for c in candidates if c["name"] == candidate_name]
    if not chosen:
        raise ValueError("Unknown candidate. See leaderboard.csv.")
    selection = [r for r in rows if r["split"] == "selection"]
    verify_sources(selection)
    for c in chosen:
        score = np.load(run / "scores" / c["name"] / "selection.npy", allow_pickle=False)
        export_predictions(selection, score, c["threshold"], Path(output) / c["name"],
                           confidence=cfg["policy"]["confidence"], score_type=c.get("score_type", "bad_probability_uncalibrated"), model_version=run.name)


def predict_folder(run, input_dir, output_dir, labeled=False, device=None):
    run, input_dir, output_dir = Path(run), Path(input_dir).resolve(), Path(output_dir).resolve()
    if not input_dir.is_dir():
        raise FileNotFoundError(f"Input folder not found: {input_dir}")
    if output_dir.is_relative_to(input_dir):
        raise ValueError("Prediction output must be outside the input tree.")
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError("Choose an empty/new prediction output folder.")
    cfg, _ = open_run(run)
    if device:
        cfg["device"] = device
    selected = load_selected(run)
    pairs = discover(input_dir) if labeled else [(p, None, "") for p in sorted(input_dir.rglob("*"))
                                                  if p.is_file() and p.suffix.lower() in EXTENSIONS]
    rows, invalid = [], []
    for path, label, _ in pairs:
        rel = path.relative_to(input_dir).as_posix()
        try:
            pixel, _, width, height = pixel_signature(path)
            if cfg["resize"] == "pad" and max(width, height) > cfg["image_size"]:
                raise ValueError("Input exceeds trained input size; use matching preprocessing.")
            row = {"path": str(path), "relative_path": rel, "pixel_hash": pixel, "group": "pixel:" + pixel}
            if label:
                row["label"] = 0 if label == "bad" else 1
            rows.append(row)
        except Exception as exc:
            invalid.append({"path": str(path), "relative_path": rel, "error": str(exc)})
    if not rows:
        output_dir.mkdir(parents=True, exist_ok=True)
        write_csv(output_dir / "invalid_images.csv", invalid, ["path", "relative_path", "error"])
        raise ValueError("No valid images to classify; inspect invalid_images.csv.")
    scores, seconds = predict_members(run, selected["members"], rows, cfg)
    export_predictions(rows, scores, selected["threshold"], output_dir, labeled=labeled,
                       confidence=cfg["policy"]["confidence"], score_type=selected.get("score_type", "bad_probability_uncalibrated"), model_version=run.name)
    write_csv(output_dir / "invalid_images.csv", invalid, ["path", "relative_path", "error"])
    if invalid:
        target = output_dir / "unreadable_review"
        target.mkdir()
        for i, row in enumerate(invalid):
            shutil.copy2(row["path"], target / f"{i:06d}__{Path(row['path']).name}")
    current_state = read_json(run / "model_state.json") if (run / "model_state.json").exists() else {}
    evaluation = current_state.get("last_evaluation")
    write_json(output_dir / "prediction_summary.json", {
        "run": str(run.resolve()), "candidate": selected["name"],
        "status": current_state.get("status", selected["status"]),
        "selection_status": selected["status"],
        "n_classified": len(rows), "n_invalid_not_classified": len(invalid),
        "elapsed_seconds_including_loading": seconds,
        "final_test_summary": read_json(run / "final_test_summary.json") if (run / "final_test_summary.json").exists() else None,
        "latest_evaluation": read_json(safe_relative(run, evaluation)) if evaluation else None,
        "labeled_input_note": "Labeled prediction metrics are descriptive; this command does not verify unseen units or qualify a model."})
    print(f"Classified {len(rows)} images; {len(invalid)} invalid. Output: {output_dir}", flush=True)
