# Visual Inspection v3 — operator and experiment guide

This is the authoritative guide for the unified v3 application. Older v2 guides,
patch notes and add-on README files describe their respective earlier workflows.
Do not install old patches on top of v3. The v3 source already includes the
integrated functions.

## 1. What this project learns

Each task (`vig`, `top`, `bottom`) is a separate good/bad image-classification
problem. The initial configuration enables only `vig`. It expects an already
cropped ROI and preserves all of it. This project does not redo camera alignment,
create segmentation masks, or decide whether a new defect appeared between a
before/after pair. Those are different tasks with different labels.

The supervised models produce two scores using labels `bad = 0`, `good = 1`.
The reported bad score is the bad softmax output. It is not automatically a
calibrated probability of a defective part. PatchCore instead produces an anomaly
distance and has its own score scale.

A trained model and a decision are separate objects. Changing a threshold changes
the decision rule; it does not change learned image features.

## 2. Data layout and grouping

Set `tasks.vig.dataset_root` in `project.yaml` to a directory containing `good`
and `bad`. Each class directory may contain subdirectories for the three trays.
For example, these are valid relative paths:

| Class | Example relative path |
|---|---|
| good | `good/C0000083/C0000083_Rc09_Cc17_FlatField_16000um_3000us_20260901T105522.png` |
| bad | `bad/C0000084/C0000084_Rc10_Cc18_FlatField_16000um_3000us_20260902T105600.bmp` |

Do not put outputs, augmented copies or test reports inside the dataset root.
The audit reads original files and writes reports elsewhere; it does not repair,
move or delete the originals.

The default `grouping: tray_unit` extracts **tray + row + column**. Capture date,
time and measurement-type suffixes do not create new physical units. Alternate
captures of the same unit are assigned to the same split. Numeric leading zeros
are normalized. Both separated and adjacent row/column tokens are supported.
Unrecognized filenames are reported as an error rather than silently treated as
independent pictures.

This rule assumes a tray coordinate identifies the same physical unit across the
input data. If trays/slots are reused for different parts or batches, supply
explicit `groups_csv` mappings or a suitable `group_regex`; the physical unit
identity must include the distinguishing batch information. Do not add capture
time merely to force related pictures into different groups.

The audit detects exact decoded-image duplicates even when filenames or formats
differ. An identical image labeled both good and bad is a conflict that must be
resolved in the source labels. Same-label exact copies are represented once for
model evaluation. Near-duplicate findings are review suggestions; visually
similar images are not automatically relabeled.

Physical-unit grouping prevents leakage between captures of the same unit. It
does **not** prove generalization to a completely new tray or manufacturing batch.
For that question, later evaluate a genuinely new tray as an external holdout.

## 3. Full image preservation and augmentation

The supplied settings are:

```yaml
defaults:
  image_size: auto
  resize: pad
  preserve_native_resolution: true
  image_size_limit: 4096
tasks:
  vig:
    augmentation:
      rotation90: true
```

The example shows relevant fields, not a replacement for the full configuration.
`auto` finds a common input canvas large enough for the image dimensions. Padding
adds a border when needed; it does not shrink the source image. Rectangular
images can therefore be padded into a square canvas while every source pixel is
retained. An image above the configured size limit fails explicitly instead of
being resized behind your back. Raising the limit also raises memory/time needs.

If the selected models include ConvNeXt-Tiny or Swin-T, the shared square canvas
is padded to a multiple of 32 so their patch/stride operations do not omit
right/bottom source pixels. For example, a 400 × 400 source image then uses a
416 × 416 canvas; a 401 × 177 image also fits a 416 × 416 canvas. Original pixels
and files stay unchanged, and all candidates within that run share the resolved
canvas. The resolved image size and canvas alignment are recorded with the run.

VIG augmentation chooses exact 0°, 90°, 180° or 270° turns during training. The
label stays unchanged. It uses pixel permutations, not arbitrary-angle
interpolation. Brightness, contrast and arbitrary-angle rotation are disabled.
Validation, calibration, selection and test images are not randomly augmented.
No augmented files are added to the dataset and no extra independent units are
claimed. Top/bottom augmentation stays off until enabled deliberately.

PNG/BMP containers do not determine bit depth. This version accepts normal
supported 8-bit image inputs; 16-bit integer and floating-point image modes are
rejected rather than silently clipped. If these occur, define an explicit,
consistent intensity conversion before training and apply it identically during
inference. Do not apply an automatic per-image contrast normalization without
checking whether brightness itself carries the VIG defect signal.

## 4. Profiles, time and memory

| Profile | Device | Maximum search allowance | Default intent |
|---|---|---:|---|
| `laptop` | CPU | 7,200 seconds / 2 h | Small supervised-model search |
| `workstation` | CUDA | 21,600 seconds / 6 h | Broader model comparison |
| `workstation_large` | CUDA | 43,200 seconds / 12 h | More trials/epochs and confirmation |

Exact model lists, trial ceilings and training settings are visible in
`project.yaml`. The time allowance is shared by the requested models; it is not
two/six/twelve hours per architecture. Trials run sequentially to avoid competing
for one GPU's memory. CUDA profiles require an available NVIDIA device and do not
silently switch to CPU.

Search has an outer process deadline, covering audit, training and evaluation.
It first requests a cooperative stop so checkpoints can be saved, then stops a
worker that has not exited by the deadline. A hard stop may lose progress since
the last saved checkpoint. Disk flushing and process teardown are not a
real-time operating-system guarantee.

Part of the allowance is reserved for candidate evaluation. If time runs out
before a usable candidate or final comparison exists, the report says so.
Increasing the number of requested models can reduce the depth explored for
each one. A trial ceiling is a maximum, not a promise of that many completed
trials. An incomplete architecture comparison cannot qualify as complete.

Microbatch size controls how many full-resolution images are loaded at once.
Gradient accumulation lets several microbatches contribute to one optimizer
update. For example, `batch_size: 1` and `accumulation_steps: 8` gives up to eight
images per update, while keeping the forward/backward microbatch small. This is
not the same as increasing the BatchNorm batch; BatchNorm is frozen by default.

If a model runs out of memory, inspect the recorded failure. Lower its
microbatch/evaluation batch and, if appropriate, increase accumulation to retain
the desired effective batch. For PatchCore, reduce memory-bank/coreset settings.
There is no silent crop/downsample fallback. Sixteen GB VRAM does not guarantee
every model will fit every possible native image size.

## 5. How Optuna experiments are compared

The split roles remain separate:

| Split | Default fraction | Purpose |
|---|---:|---|
| train | 55% | Learn model parameters; training-only rotations |
| val | 10% | Choose checkpoints, hyperparameters and training configurations |
| threshold | 10% | Fit decision thresholds after validation shortlisting |
| selection | 10% | Compare frozen candidates and decisions |
| test | 15% | Final check after freezing the selected system |

Grouped splitting can make the realized fractions differ slightly. Check the
audit counts and class balance. Five splits require enough independent good and
bad units; the code cannot manufacture independent evidence by rotating pictures.

Every search uses one immutable manifest. Optuna trials receive train/validation
data, not calibration/selection/test feedback. There is a separate TPE study for
each selected model in a local SQLite database. The supervised objective is bad
average precision (AP, historically named `pr_auc_bad` in report files).

The default search exposes these conditional choices:

| Choice | Supervised classifiers | PatchCore |
|---|---|---|
| Feature adaptation | Head only, last block, or full backbone | Frozen pretrained features |
| Learning rates | Head; backbone when trainable | Not applicable |
| Warmup | Before last-block/full fine-tuning | Not applicable |
| Regularization | Weight decay | Coreset size |
| Imbalance | None, weighted loss, or sampling | Good training examples define normality |
| Scheduling | Cosine or plateau | Not applicable |
| Resource-related search | Effective batch by accumulation | Projection dimension and coreset |

The initial optimizer search is AdamW; SGD is an explicit advanced choice when
configured in the supported search space. Model families and optional search
spaces are declared in configuration. PatchCore's backbone and image geometry
stay fixed within its study. Do not interpret its coreset/projection search as
neural-network fine-tuning.

Pruning waits for the configured startup trials and for a candidate's minimum
fine-tuning opportunity after warmup. A poor-looking warmup alone should not
eliminate a trial before the backbone has been evaluated. Completed, pruned,
failed and interrupted trials remain distinguishable in the report.

On profiles with additional configured seeds, budgeted confirmation evaluates
validation stability before freezing the shortlist. Only completed confirmation
runs can support stability claims. The report records failures or skipped
confirmations rather than implying that all seeds ran. Do not search for a lucky
split or seed and present it as independent confirmation.

For supervised models, completed seed-confirmation members can form a mean-score
ensemble. For PatchCore, the primary seed's model is fixed before confirmation
and remains the single prediction/export member. Extra PatchCore seeds are
diagnostics only: their scores and validation AP are recorded, but the search
does not replace the primary model with whichever extra seed looks best.
PatchCore confirmation records identify these runs as `diagnostic_only` with
`used_for_prediction: false`. A diagnostic mean/std is not the AP of the deployed
single model. Missing required confirmations keep the comparison incomplete.

The implementation uses **single-objective TPE**. Runtime/memory are reported for
comparison; this is not a multi-objective Pareto-search interface. The model
families and allowed choices define the search; Optuna does not invent a new
architecture or guarantee a global optimum.

Once shortlisting is frozen, calibration fits thresholds and selection compares
the resulting systems. Test is untouched until explicitly evaluated. Repeated
manual choices based on selection results gradually turn that set into more
development data; use a fresh holdout for the final claim when that happens.

## 6. Commands for everyday use

All examples run in PowerShell from the project root. Replace paths in quotes;
do not type placeholder values literally. Use `.venv\Scripts\python.exe` so you
know which Python environment is running. These commands need no activation.

### Inspect and start

```powershell
.\.venv\Scripts\python.exe inspection.py doctor --config project.yaml --profile laptop --task vig
.\.venv\Scripts\python.exe inspection.py audit --config project.yaml --profile laptop --task vig
.\.venv\Scripts\python.exe inspection.py dashboard --config project.yaml
```

Audit creates a run with the manifest and reports; it does not train. A new
`search --config` makes a new run and performs its own audit. Use the dashboard's
printed `127.0.0.1` URL; leave its terminal open. It has no CDN or cloud dependency.

### Start one bounded search

```powershell
.\.venv\Scripts\python.exe inspection.py search --config project.yaml --profile laptop --task vig
.\.venv\Scripts\python.exe inspection.py search --config project.yaml --profile workstation --task vig
.\.venv\Scripts\python.exe inspection.py search --config project.yaml --profile workstation_large --task vig
```

Those are alternatives, not three commands to start simultaneously. To narrow a
search or use a smaller allowance:

```powershell
.\.venv\Scripts\python.exe inspection.py search --config project.yaml --profile laptop --task vig --models resnet18 --hours 1
```

`--hours` cannot exceed the selected profile's ceiling. The actual model list and
configuration are recorded inside the run. Changes to `project.yaml` apply to
new runs; they do not change a running experiment.

### Resume an interrupted search

```powershell
.\.venv\Scripts\python.exe inspection.py search --run "C:\PATH\TO\RUN"
```

Resume uses the existing configuration, data identity, Optuna studies and saved
checkpoints. It retains the **remaining original allowance**, not a fresh two,
six or twelve hours. Paused/offline time is not new training time. Device
overrides are available for a resumed run:

```powershell
.\.venv\Scripts\python.exe inspection.py search --run "C:\PATH\TO\RUN" --device cpu
```

If a process crashed and left a lock, verify that no original worker is running
before using `--recover-lock`; live-process ownership is checked. Do not delete
lock files to run two writers against the same experiment.

### Finish evaluation after time expired

```powershell
.\.venv\Scripts\python.exe inspection.py finalize-search --run "C:\PATH\TO\RUN" --hours 0.5
```

This is an explicit, separate postprocessing allowance. It does not start new
training trials. It can evaluate already trained finalists; it cannot invent a
completed checkpoint if no trial trained successfully.

### Generate a standalone report

```powershell
.\.venv\Scripts\python.exe inspection.py report --run "C:\PATH\TO\RUN"
.\.venv\Scripts\python.exe inspection.py report --config project.yaml --task vig
```

The first reports one run, the second discovers configured results. Open the
printed HTML file in a browser. Report generation does not retrain models.
`comparison.html`, visual report paths, logs and state are linked from the
dashboard or printed by the command.

## 7. Read the metrics before trusting the winner

The **positive event is bad**, regardless of the numeric class index.

| Actual image / prediction | Predicted bad | Predicted good |
|---|---:|---:|
| Actually bad | True positive (TP): defect caught | False negative (FN): bad escape |
| Actually good | False positive (FP): good reject | True negative (TN): good accepted |

- Bad escape rate = `FN / (TP + FN)`.
- Good reject rate = `FP / (FP + TN)`.
- Bad recall = `TP / (TP + FN)` = 1 − bad escape rate.
- Balanced accuracy = `((1 − bad escape rate) + (1 − good reject rate)) / 2`.
- Accuracy = `(TP + TN) / total`; this can be misleading with unequal classes.
- Accepted contamination = `FN / (FN + TN)`, when anything is accepted.
- AP measures bad-score ranking across thresholds; it is not an accuracy value.

An always-good model has zero good rejects but escapes every defect. An
always-bad model catches every defect but rejects every good. Both have balanced
accuracy 0.5 when both classes exist. The constant-score AP baseline equals the
bad prevalence of the evaluated set.

Both policy targets must be met to count as meeting the operating target. If no
calibration threshold meets both, the balanced-accuracy fallback is explicitly a
development decision with `TARGET_NOT_MET`. It must not be presented as a
production-qualified model just because a candidate was selected.

Empirical rates and statistical evidence differ. For example, zero misses among
50 independent bad units does not establish a 1% population escape ceiling at
95% confidence. The default one-sided upper bound is about 5.8% in that case.
More images of the same physical unit do not fix that evidence shortage.

## 8. Change the decision without training again

Freeze a new decision from the selected candidate:

```powershell
.\.venv\Scripts\python.exe inspection.py decision --run "C:\PATH\TO\RUN" --mode policy --output-root decisions
.\.venv\Scripts\python.exe inspection.py decision --run "C:\PATH\TO\RUN" --mode manual --threshold 0.65 --output-root decisions
.\.venv\Scripts\python.exe inspection.py decision --run "C:\PATH\TO\RUN" --mode argmax --output-root decisions
.\.venv\Scripts\python.exe inspection.py decision --run "C:\PATH\TO\RUN" --mode scores_only --output-root decisions
```

Choose one mode for the behavior you want. Each command creates a separate
timestamped decision directory and prints the new `decision.json` path. To use a
different recorded candidate, add `--candidate "NAME_FROM_CANDIDATES_JSON"`.

| Mode | Rule |
|---|---|
| policy | Fit a threshold using calibration and the recorded policy |
| manual | Bad when score is greater than or equal to your supplied threshold |
| argmax | Choose the larger binary supervised class output; ties go to bad |
| scores_only | Export scores with no good/bad decision |

For a supervised two-class softmax, argmax corresponds to a 0.5 bad-score
boundary. That removes manual threshold tuning, not the mathematical decision
boundary. PatchCore distances are not probabilities, so argmax/0.5 is rejected
for PatchCore. Scores-only works with both score types.

A manual threshold such as 0.65 is an example, not a recommendation for your
model. Higher thresholds accept more images as good. New decisions do not inherit
the source model's qualification and do not overwrite `selected.json`.

Use the dashboard calibration explorer or save a threshold review:

```powershell
.\.venv\Scripts\python.exe inspection.py threshold-review --run "C:\PATH\TO\RUN" --thresholds 0.15 0.20 0.25
```

These are calibration-development results, not final-test performance. The
explorer does not access the final test. Changing its slider alone does not change
the saved decision used for subsequent inference.

## 9. Classify new images

```powershell
.\.venv\Scripts\python.exe inspection.py classify --decision "C:\PATH\TO\DECISION\decision.json" --input "C:\NEW_IMAGES" --output-root classified --device cpu --copy-images
```

Use `--device cuda` on the workstation. Output is written into a new timestamped
directory. Original images are untouched. `--copy-images` requests copied images;
without it, use the prediction tables/reports without duplicating image storage.
Scores-only mode does not assign prediction class folders.

For an input folder with **true** `good` and `bad` subfolders, add `--labeled`:

```powershell
.\.venv\Scripts\python.exe inspection.py classify --decision "C:\PATH\TO\DECISION\decision.json" --input "C:\LABELED_NEW_IMAGES" --output-root classified --labeled --copy-images
```

Without true labels, the program reports predictions and counts, not accuracy,
recall or false-positive rates. Do not use folders created by an earlier model
as ground truth. Scores-only with labels may report ranking metrics, but there
is no decision confusion matrix until a decision rule is chosen.

Decision directories include an integrity record. Move the complete directory,
not only its JSON. If a source run was relocated separately, `classify --run
"C:\NEW_RUN_LOCATION"` supplies the verified source override. Keep original run
configuration/manifest/checkpoint hashes unchanged.

## 10. Final evaluation, releases and export

For the original frozen selected system:

```powershell
.\.venv\Scripts\python.exe inspection.py evaluate --run "C:\PATH\TO\RUN" --split final-test
.\.venv\Scripts\python.exe inspection.py activate --run "C:\PATH\TO\RUN" --config project.yaml
```

Activation applies configured qualification checks and can be refused. It is
not necessary for development inference. The command above evaluates the run's
recorded selected system; it does not silently evaluate an unrelated manual
decision. To assess a revised decision, use fresh labeled data with `classify`
and retain that separate evidence. Do not repeatedly retune on the final test.

Install export dependencies first, then export:

```powershell
.\.venv\Scripts\python.exe inspection.py package --run "C:\PATH\TO\RUN" --kind inference --format onnx --output "C:\PACKAGES\vig_candidate"
```

To package an explicit post-training decision, add `--decision
"C:\PATH\TO\DECISION\decision.json"`. The model, preprocessing, class mapping
and decision travel together. ONNX score/decision agreement is checked using the
configured tolerances; export must not hide disagreements. Exporting a model is
not production qualification. Some candidates may not support a requested export
on a particular dependency stack; inspect the actual export result.

Portable ONNX package inference:

```powershell
.\.venv\Scripts\python.exe inspection.py predict --model "C:\PACKAGES\vig_candidate" --input "C:\NEW_IMAGES" --output "C:\PREDICTIONS\batch_001" --device cpu
```

Create a new output directory for each package-inference batch.

## 11. Portability and later retraining

For a new experiment on another PC, copy the project and weights, recreate its
environment, and change `dataset_root`. For training-state migration use:

```powershell
.\.venv\Scripts\python.exe inspection.py package --run "C:\PATH\TO\RUN" --kind training --output "C:\PACKAGES\vig_training"
.\.venv\Scripts\python.exe inspection.py restore --package "C:\PACKAGES\vig_training" --data-root "D:\DATA\vig" --output "D:\RESTORED\vig_run"
```

Restore verifies the matching image contents and rebases data references. The
training package does not substitute for your original dataset backup. Search
continuation requires the complete recorded study and checkpoints, not only a
`best.pt` file. Keep decisions with their integrity files and source runs when
moving them.

To incorporate new labeled units, create a new generation rather than rewriting
old results:

```powershell
.\.venv\Scripts\python.exe inspection.py update --config project.yaml --profile workstation --task vig --from-run "C:\PATH\TO\OLD_RUN"
```

The update path retains lineage and holdout protections. Fine-tuning an existing
model and running an independent Optuna search from pretrained weights answer
different questions. For a fresh search use `search --config`; do not reuse
old test feedback as a hyperparameter objective.

Legacy v2 runs can be inspected with the retained visual/report and threshold
tools when their source metadata is intact. A legacy run is not retroactively
an Optuna study. Preserve the original folder for auditability; do not paste a
new configuration over its saved metadata.

## 12. What to check if VIG still performs poorly

1. Inspect a sample of false good and false bad predictions with their true
   labels. Are label definitions consistent across all trays?
2. Verify the full ROI and defect remain visible after decoding/padding. Check
   bit depth; input conversion must match the production acquisition process.
3. Inspect duplicate conflicts and grouping. Are multiple captures of one part
   staying together? Are reused tray slots identified correctly?
4. Compare head-only, last-block and full fine-tuning validation curves. A
   checkpoint that deteriorates after unfreezing suggests an experiment to try,
   not automatic proof of a single cause.
5. Compare AP/ROC ranking with both operating error rates. Better ranking alone
   does not prove that a 1% escape / 20% reject operating point exists.
6. Compare completed models only, and inspect failed/skipped trials. If no model
   separates the classes sufficiently, collect targeted examples and examine
   labels/acquisition conditions before spending more search time.
7. Check a new tray/batch as an external holdout before claiming generalization.

The software makes these comparisons reproducible and visible. Good industrial
performance still has to be demonstrated on representative, correctly labeled,
independent local data.

## 13. Repeat the installation check locally

The release validation includes automated tests plus a synthetic end-to-end
check with pretrained ResNet18, two epochs, four decision modes, reports and real
ONNX argmax/scores-only export and inference. The final test count, tested
environment and remaining limits are in [VALIDATION_REPORT.md](VALIDATION_REPORT.md).
This does not claim validation on Windows hardware or your industrial dataset.

To repeat a small check from PowerShell:

```powershell
.\.venv\Scripts\python.exe scripts/smoke_v3.py --output ..\smoke_check
```

This creates a new sibling folder with synthetic images, a small search, saved
decisions, predictions and a report. It uses randomly initialized ResNet18
weights unless `--weights` points to an existing public-weights directory.
It never downloads weights. A full optional check is:

```powershell
.\.venv\Scripts\python.exe scripts/smoke_v3.py --output ..\smoke_check_pretrained --weights .\weights --with-onnx
```

`--with-onnx` needs the export dependencies. Each output folder must be new or
empty. Success writes `smoke_result.json` with `industrial_performance_evidence:
false`. Keep smoke output outside the real dataset. These synthetic examples
exercise program behavior, not the camera-defect problem or its target rates.
