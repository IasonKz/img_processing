# Pretrained weight downloads

The laptop, experimental laptop iGPU, workstation and large-workstation presets
use the same network policy. New projects enable missing-weight downloads before
training. Selecting CUDA or DirectML does not change the application's weight
download policy. Third-party backend diagnostics are a separate concern; see
the note below.

```yaml
defaults:
  download_missing_weights: true
  weight_download_timeout_seconds: 15
```

Only the selected supported models' official TorchVision ImageNet weight files
are requested from `https://download.pytorch.org/models/`. Files are checked
against the SHA-256 prefix published in the TorchVision weight URL and installed
atomically. A manifest records the full SHA-256 checksum and source URL. Verified
local files are reused. Dataset images, manual labels and reports are not sent.

Downloads are included in the search wall-clock budget. Pause and cancellation
are checked between downloaded blocks. A blocked request can wait for the
network timeout; the search supervisor still enforces its total deadline. A
cancelled or corrupt partial download is not installed. Installed weights remain
available to future runs. No model checkpoint exists if training never started.

To prevent automatic model downloads, disable **Download missing official weights** in Custom
search or set `download_missing_weights: false`. Provision files beforehand:

```powershell
python inspection.py download-weights --config project.yaml
```

The explicit download command is an online setup action even when automatic
downloads are disabled. The `doctor` command remains read-only and reports
missing files rather than downloading them. Inference uses saved local model
artifacts and does not fetch pretrained weights.

Existing recorded runs without the new setting retain offline behavior.
Installation of Python packages remains an explicit setup action; training never
runs `pip install`, changes the environment or disables security software. Use
your normal approved company internet/proxy connection. Download failures report
the cause; do not bypass a company network restriction.

If an existing weight file fails verification, it is preserved and training
stops. Move that specific file aside, then run the explicit download command.

## Third-party backend diagnostics

The download checkbox governs this application's model-file requests; it is not
a system-wide network or telemetry switch. Microsoft documents GPU-device and
CPU-fallback-operator diagnostics in the `torch-directml` package's
[Data Collection Notice](https://pypi.org/project/torch-directml/0.2.5.dev240914/).
This application does not upload inspection images or labels, but does not
claim to audit or control every dependency's diagnostic traffic. Review the
DirectML notice and company IT policy before enabling that optional backend.
Strict network isolation, if required, belongs to the approved deployment
environment, not this checkbox. Do not disable company security controls.
