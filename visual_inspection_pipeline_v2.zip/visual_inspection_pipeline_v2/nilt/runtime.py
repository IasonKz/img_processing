"""Portable inference runtime. Requires only NumPy, Pillow and ONNX Runtime.

This module is copied unchanged into deployment packages. Package checksums detect
accidental changes; they are not a digital signature or a trust mechanism.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
from pathlib import Path, PurePosixPath
import shutil
import sys
import time

import numpy as np
from PIL import Image, ImageOps

EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}
MEAN = [0.485, 0.456, 0.406]
STD = [0.229, 0.224, 0.225]


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False), encoding="utf-8")


def sha_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def safe_asset(root, relative):
    """Resolve portable assets without absolute paths, traversal or symlinks."""
    if not isinstance(relative, str) or not relative or "\\" in relative or ":" in relative:
        raise ValueError("Invalid package asset path.")
    portable = PurePosixPath(relative)
    if portable.is_absolute() or ".." in portable.parts or str(portable) != relative:
        raise ValueError(f"Unsafe package asset path: {relative!r}")
    root = Path(root).resolve()
    path = root / relative
    if not path.resolve().is_relative_to(root):
        raise ValueError(f"Package asset escapes package: {relative}")
    current = root
    for part in portable.parts:
        current /= part
        if current.is_symlink():
            raise ValueError(f"Package asset is a symlink: {relative}")
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def verify_package(root):
    root = Path(root).resolve()
    integrity = read_json(safe_asset(root, "integrity.json"))
    assets = integrity.get("files")
    if not isinstance(assets, dict) or not assets:
        raise ValueError("Empty or invalid package integrity manifest.")
    for relative, expected in assets.items():
        if sha_file(safe_asset(root, relative)) != expected:
            raise ValueError(f"Package integrity mismatch: {relative}")
    for filename in ("package.json", "preprocessing.json", "decision_policy.json", "export_validation.json"):
        if filename not in assets:
            raise ValueError(f"Required asset is not integrity protected: {filename}")
    return assets


def load_rgb(path):
    with Image.open(path) as raw:
        if raw.mode.startswith("I") or raw.mode == "F":
            raise ValueError("16-bit/float images require an explicit intensity conversion first.")
        if getattr(raw, "n_frames", 1) != 1:
            raise ValueError("Multi-frame images require explicit frame extraction before ingestion.")
        return ImageOps.exif_transpose(raw).convert("RGB")


def prepare_image(im, specification):
    """Whole-image aspect-preserving fit or no-rescale centered padding."""
    im = im.convert("RGB")
    size = int(specification["image_size"])
    mode = specification.get("resize", "pad")
    if size < 32 or mode not in ("pad", "fit"):
        raise ValueError("Unsupported input geometry policy.")
    if mode == "fit":
        scale = size / max(im.size)
        im = im.resize((max(1, round(im.width * scale)), max(1, round(im.height * scale))), Image.Resampling.BILINEAR)
    elif max(im.size) > size:
        raise ValueError(f"Image {im.size} exceeds package input size {size}; no implicit resizing is permitted.")
    left, top = (size - im.width) // 2, (size - im.height) // 2
    return ImageOps.expand(im, (left, top, size - im.width - left, size - im.height - top),
                           fill=tuple(specification.get("padding_rgb", [124, 116, 104])))


def preprocess(path, specification):
    im = prepare_image(load_rgb(path), specification)
    x = np.asarray(im, dtype=np.float32).transpose(2, 0, 1) / np.float32(255)
    mean = np.asarray(specification.get("mean", MEAN), dtype=np.float32)[:, None, None]
    std = np.asarray(specification.get("std", STD), dtype=np.float32)[:, None, None]
    if mean.shape != (3, 1, 1) or std.shape != (3, 1, 1) or np.any(std <= 0):
        raise ValueError("Invalid normalization specification.")
    return np.ascontiguousarray(((x - mean) / std)[None], dtype=np.float32)


def nearest_bank_distances(features, bank, query_chunk=256, bank_chunk=2048):
    """Exact Euclidean 1-NN with bounded pairwise memory, no approximation.

    Double-precision accumulation limits cancellation for nearly identical patches.
    The source backend uses direct FP32 cdist; export parity validates numerical
    agreement with this portable reference. Output remains float32.
    """
    features, bank = np.asarray(features), np.asarray(bank)
    if features.ndim != 2 or bank.ndim != 2 or features.shape[1] != bank.shape[1] or not len(bank):
        raise ValueError("Invalid feature/memory bank dimensions.")
    if not np.isfinite(features).all() or not np.isfinite(bank).all():
        raise ValueError("Nonfinite PatchCore features or memory bank.")
    if query_chunk < 1 or bank_chunk < 1:
        raise ValueError("Nearest-neighbor chunk sizes must be positive.")
    result = np.empty(len(features), dtype=np.float32)
    for start in range(0, len(features), query_chunk):
        q = features[start:start + query_chunk].astype(np.float64)
        qnorm = np.einsum("ij,ij->i", q, q)[:, None]
        best = np.full(len(q), np.inf, dtype=np.float64)
        for offset in range(0, len(bank), bank_chunk):
            b = bank[offset:offset + bank_chunk].astype(np.float64)
            squared = qnorm + np.einsum("ij,ij->i", b, b)[None] - 2 * (q @ b.T)
            best = np.minimum(best, squared.min(axis=1))
        result[start:start + len(q)] = np.sqrt(np.maximum(best, 0)).astype(np.float32)
    return result


def patchcore_score(embedding, bank, query_chunk=256, bank_chunk=2048):
    embedding = np.asarray(embedding)
    if embedding.ndim != 4 or embedding.shape[0] != 1:
        raise ValueError("Expected one spatial feature map in NCHW format.")
    features = embedding[0].transpose(1, 2, 0).reshape(-1, embedding.shape[1])
    distances = nearest_bank_distances(features, bank, query_chunk, bank_chunk)
    return float(distances.max()), distances.reshape(embedding.shape[2:])


def choose_providers(available, device):
    if device not in ("cpu", "cuda", "auto"):
        raise ValueError("device must be cpu, cuda or auto.")
    use_cuda = device == "cuda" or (device == "auto" and "CUDAExecutionProvider" in available)
    if use_cuda:
        if "CUDAExecutionProvider" not in available:
            raise RuntimeError("CUDAExecutionProvider unavailable; install compatible onnxruntime-gpu and NVIDIA dependencies, or request cpu.")
        return ["CUDAExecutionProvider", "CPUExecutionProvider"]
    if "CPUExecutionProvider" not in available:
        raise RuntimeError("CPUExecutionProvider is unavailable.")
    return ["CPUExecutionProvider"]


class PackageRunner:
    def __init__(self, package, device="cpu", verify=True):
        self.root = Path(package).resolve()
        protected = verify_package(self.root) if verify else None
        self.metadata = read_json(safe_asset(self.root, "package.json"))
        if self.metadata.get("format_version") != 1:
            raise ValueError("Unsupported deployment package version.")
        self.preprocessing = read_json(safe_asset(self.root, "preprocessing.json"))
        self.decision = read_json(safe_asset(self.root, "decision_policy.json"))
        self.threshold = float(self.decision["threshold"])
        if not np.isfinite(self.threshold) or self.decision.get("class_to_index") != {"bad": 0, "good": 1}:
            raise ValueError("Invalid classification decision policy.")
        if self.decision.get("rule") != "bad_if_score_greater_equal_threshold":
            raise ValueError("Unknown decision rule.")
        validation = read_json(safe_asset(self.root, "export_validation.json"))
        if validation.get("status") != "passed" and verify:
            raise ValueError("Deployment export has not passed source/runtime parity validation.")
        import onnxruntime as ort
        self.ort_version = ort.__version__
        self.providers = choose_providers(ort.get_available_providers(), device)
        exported_versions = validation.get("versions", {})
        self.runtime_versions = {"onnxruntime": ort.__version__, "numpy": np.__version__, "Pillow": Image.__version__}
        self.runtime_versions_match_export = all(exported_versions.get(name) == version for name, version in self.runtime_versions.items())
        self.provider_validated = (self.providers[0] in validation.get("validated_providers", []) and self.runtime_versions_match_export)
        self.sessions = []
        members = self.metadata.get("members", [])
        if not members:
            raise ValueError("Package has no model members.")
        kinds = {m.get("kind", "supervised") for m in members}
        if not kinds <= {"supervised", "patchcore"} or ("patchcore" in kinds and len(members) != 1):
            raise ValueError("Only supervised score averages or a single PatchCore member are supported.")
        for member in members:
            relative = member["onnx"]
            if protected is not None and relative not in protected:
                raise ValueError("Unprotected ONNX member.")
            options = ort.SessionOptions()
            options.intra_op_num_threads = int(self.metadata.get("runtime_cpu_threads", 4))
            session = ort.InferenceSession(str(safe_asset(self.root, relative)), sess_options=options, providers=self.providers)
            session.disable_fallback()
            if self.providers[0] not in session.get_providers():
                raise RuntimeError("Requested execution provider did not initialize; use an explicit working device.")
            self.sessions.append((member, session))
        self.banks = {}
        for member in members:
            if member.get("kind") == "patchcore":
                relative = member["memory_bank"]
                if protected is not None and relative not in protected:
                    raise ValueError("Unprotected memory bank.")
                self.banks[relative] = np.load(safe_asset(self.root, relative), allow_pickle=False, mmap_mode="r")

    def score(self, path):
        return self.score_tensor(preprocess(path, self.preprocessing))

    def score_tensor(self, x):
        scores = []
        for member, session in self.sessions:
            value = np.asarray(session.run([member["output_name"]], {member["input_name"]: x})[0])
            if member.get("kind", "supervised") == "patchcore":
                score, _ = patchcore_score(value, self.banks[member["memory_bank"]],
                                          int(member.get("query_chunk", 256)), int(member.get("bank_chunk", 2048)))
            else:
                if value.size != 1:
                    raise ValueError("Expected one supervised bad score per image.")
                score = float(value.reshape(-1)[0])
                if not 0 <= score <= 1:
                    raise ValueError("Supervised score outside [0,1].")
            if not np.isfinite(score):
                raise ValueError("Model produced a nonfinite score.")
            scores.append(score)
        return float(np.mean(scores))


def discover_inputs(input_root, labeled=False):
    root = Path(input_root).resolve()
    if not root.is_dir():
        raise NotADirectoryError(root)
    if labeled and any(not (root / name).is_dir() for name in ("good", "bad")):
        raise ValueError("Labeled input requires good and bad subfolders.")
    roots = [(root / name, name) for name in ("good", "bad")] if labeled else [(root, None)]
    rows = []
    for folder, label in roots:
        for path in sorted(folder.rglob("*")):
            if path.is_file() and path.suffix.lower() in EXTENSIONS:
                if path.is_symlink() or not path.resolve().is_relative_to(root):
                    raise ValueError(f"Input image escapes input root: {path}")
                rows.append({"path": path, "relative_path": path.relative_to(root).as_posix(), "true_class": label})
    if not rows:
        raise ValueError("No supported image files found.")
    return rows


def predict_package(package, input, output, device="cpu", labeled=False):
    source, target, package = Path(input).resolve(), Path(output).resolve(), Path(package).resolve()
    if target.is_relative_to(source) or source.is_relative_to(target):
        raise ValueError("Input and output folders must be separate, non-nested locations.")
    if target.is_relative_to(package) or package.is_relative_to(target):
        raise ValueError("Output must not overlap the deployment package.")
    if target.exists() and (not target.is_dir() or any(target.iterdir())):
        raise FileExistsError("Output must be absent or empty; existing results are never overwritten.")
    rows = discover_inputs(source, labeled)
    runner = PackageRunner(package, device)
    target.mkdir(parents=True, exist_ok=True)
    for name in ("good", "bad", "review"):
        (target / "predicted" / name).mkdir(parents=True)
    if labeled:
        for name in ("bad_to_good", "good_to_bad"):
            (target / "errors" / name).mkdir(parents=True)
    columns = ["image_id", "relative_path", "task", "true_class", "predicted_class", "score", "score_type", "threshold", "model_version", "status", "error", "output_path"]
    results = []
    start = time.perf_counter()
    for row in rows:
        relative = row["relative_path"]
        identity = hashlib.sha256(relative.encode("utf-8")).hexdigest()[:20]
        result = {"image_id": identity, "relative_path": relative, "task": runner.metadata["task"],
                  "true_class": row["true_class"] or "", "threshold": runner.threshold,
                  "model_version": runner.metadata["model_version"], "score_type": runner.decision["score_type"],
                  "predicted_class": "review", "score": "", "status": "input_error", "error": ""}
        try:
            # Input errors enter review; model/provider failures abort instead of being mislabeled as input errors.
            tensor = preprocess(row["path"], runner.preprocessing)
        except (OSError, ValueError, Image.DecompressionBombError) as error:
            result["error"] = str(error)
        else:
            try:
                score = runner.score_tensor(tensor)
            except Exception as error:
                write_json(target / "inference_failure.json", {"status": "failed", "completed_images": len(results),
                           "relative_path": relative, "error_type": type(error).__name__, "error": str(error)})
                raise RuntimeError(f"Model inference failed on {relative}; partial output is not a completed batch.") from error
            result.update(score=score, predicted_class="bad" if score >= runner.threshold else "good", status="ok")
        filename = identity + "__" + row["path"].stem[:100] + row["path"].suffix.lower()
        destination = target / "predicted" / result["predicted_class"] / filename
        shutil.copy2(row["path"], destination)
        result["output_path"] = destination.relative_to(target).as_posix()
        if labeled and result["status"] == "ok" and result["true_class"] != result["predicted_class"]:
            shutil.copy2(row["path"], target / "errors" / (result["true_class"] + "_to_" + result["predicted_class"]) / filename)
        results.append(result)
    with (target / "predictions.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        writer.writerows(results)
    summary = {"status": "completed_with_input_errors" if any(r["status"] != "ok" for r in results) else "completed",
               "task": runner.metadata["task"], "model_version": runner.metadata["model_version"],
               "model_qualification": runner.metadata.get("qualification_status", "not_recorded"),
               "images": len(results), "counts": {name: sum(r["predicted_class"] == name for r in results) for name in ("good", "bad", "review")},
               "elapsed_seconds": time.perf_counter() - start, "providers": runner.providers,
               "provider_parity_validated": runner.provider_validated, "onnxruntime_version": runner.ort_version,
               "runtime_versions": runner.runtime_versions, "runtime_versions_match_export": runner.runtime_versions_match_export,
               "python_version": platform.python_version(), "platform": platform.platform(),
               "threshold": runner.threshold, "labeled": bool(labeled)}
    if labeled:
        valid = [r for r in results if r["status"] == "ok"]
        total_bad = sum(r["true_class"] == "bad" for r in valid)
        total_good = sum(r["true_class"] == "good" for r in valid)
        escapes = sum(r["true_class"] == "bad" and r["predicted_class"] == "good" for r in valid)
        rejects = sum(r["true_class"] == "good" and r["predicted_class"] == "bad" for r in valid)
        summary["evaluation"] = {"valid_images": len(valid), "bad_count": total_bad, "good_count": total_good,
              "bad_to_good": escapes, "good_to_bad": rejects,
              "bad_escape_rate": escapes / total_bad if total_bad else None,
              "good_reject_rate": rejects / total_good if total_good else None,
              "accuracy": 1 - (escapes + rejects) / len(valid) if valid else None,
              "note": "Invalid inputs excluded from metrics and reported separately; this batch is not an independent qualification test."}
    write_json(target / "inference_summary.json", summary)
    return target


def main(argv=None):
    parser = argparse.ArgumentParser(description="Run a portable visual inspection deployment package.")
    parser.add_argument("--package", default=str(Path(__file__).resolve().parent))
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--device", choices=["cpu", "cuda", "auto"], default="cpu")
    parser.add_argument("--labeled", action="store_true")
    args = parser.parse_args(argv)
    try:
        destination = predict_package(args.package, args.input, args.output, args.device, args.labeled)
    except Exception as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 2
    print(f"Results: {destination}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
