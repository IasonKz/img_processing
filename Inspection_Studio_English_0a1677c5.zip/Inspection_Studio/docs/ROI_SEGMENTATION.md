# ROI annotation and segmentation

The **Segmentation target** selector determines the model task for each view:

| Target | TOP | BOTTOM | Model output |
| --- | --- | --- | --- |
| **Whole image · TOP defects** | Supported | Unavailable | Defect masks in complete images using the existing TOP annotation project. |
| **ROI crops · defects** | Supported | Supported | Defect masks within exported crops, with one project per ROI kind. |
| **ROI localization · geometry masks** | Supported | Supported | ROI position and shape masks on source images for ROI Detection. |

## Crop annotation

1. In **ROI Detection → TOP/BOTTOM**, complete import, template calibration, localization and geometry review.
2. Create a dataset export. Crops can be exported without Good/Bad quality labels.
3. Open **Crop annotations**, select the export and **ROI kind**, and choose **Open crop annotations**. Import runs automatically.
4. Annotate with the existing brush, polygon, box, erase, notes and exclusion tools. Defect pixels are labelled inner or outer relative to the boundary defined inside the crop. For pins and labels, define an appropriate region-of-interest boundary. Class IDs are `0=background, 1=inner defect, 2=outer defect`.
5. Save and approve with **Approve & next**. For a clean crop, clear the defect mask and use **Approve clean & next**. Automatic proposals, approved geometry and Good/Bad labels do not approve defect masks.
6. Choose **Continue → Segmentation** for model search. The same project is also available from **Segmentation → ROI crops · defects → Open ROI dataset**. **Open in ROI Detection** returns to that dataset.

Both entry points use one annotation project. Saving creates a revision; a conflicting save from an older revision requires a reload. Each study snapshots approved annotations. Later edits do not modify an existing study; use a new study name to train with revised annotations.

**Full screen** is available in both crop annotation and segmentation annotation. The editor is integrated into the dashboard page.

## Training, splits and image depth

Each project belongs to a specific `side + kind + export`. All 16 BOTTOM pins share one kind and model, retaining their individual ROI IDs and positions. TOP label, corners, inner area and lens use separate annotation projects.

Crops retain the physical `unit_id`, source image, ROI ID, crop transform, checksum and train/validation/test role of the export. Every crop from one unit stays in the same split. ROI studies inherit those roles instead of using the whole-image studio's split ratios. Split and source path controls are locked in the GUI. Test crops are excluded from fitting and model selection.

Training requires approved crops from both original **training and validation units**, with positive defect pixels in both groups. **Require both defect classes** is initially disabled for ROI studies, allowing a single defect class such as inner defects. Test evaluation requires approved test crops and retains the existing rule that a frozen trial is selected before opening the test set.

Working copies and snapshots preserve native uint8 and uint16 crop pixels. Training and inference use fixed `/255` or `/65535` scaling respectively. Only editor previews are converted to 8-bit. Predicted masks are restored to the original crop dimensions. Exported Python packages include the native decoder. Whole-image TOP segmentation retains its existing 8-bit input requirement.

A change to geometry, margin or crop orientation requires a new ROI export and annotation project. Existing masks belong to the previous pixels and must not be transferred to different geometry without review.

## Geometric localizer training

Select **Segmentation → TOP/BOTTOM → ROI localization · geometry masks**. Choose the geometry-mask export, epochs, image size, batch size and CPU/CUDA device, then use **Train ROI localizer**. Visible, absent and unknown feature judgments remain under **ROI Detection → Locate & review**.

This task uses the existing localizer engine, geometry masks, splits, checkpoints and experiment records. **Evaluate held-out test masks** evaluates the frozen model. **Use model in localization** returns to ROI Detection with the checkpoint and segmentation method selected; hybrid localization is also available there.

Geometric localizer masks and crop defect masks have different meanings and use separate models. Their source lineage and unit splits are shared. Good/Bad ROI classifiers remain in **Classification**. A combined production verdict across all regions requires separate pipeline development and qualification.

## Project storage

```text
roi_detection/<side>/exports/<export>/        # Native crops and source geometry
roi_detection/<side>/models/<experiment>/    # Geometric localizer checkpoints
segmentation/top/                           # Whole-image TOP project
segmentation/<side>/roi/<kind>/<export>/
  source.json                               # Frozen provenance, units and splits
  project.yaml                              # Link to the selected export
  annotations/                              # Shared editor, native copies and revisions
  results/                                  # Studies, evaluations, predictions and packages
```

Legacy BOTTOM whole-image folders are retained, and their workers remain recoverable for the global stop control. The dashboard does not offer or create new BOTTOM whole-image segmentation projects.

## Updating an installation

Stop the dashboard before updating. For an existing Arch Linux installation, run these commands from the repository root, replacing `.venv-studio6` with the installation's environment directory if necessary:

```bash
git pull --ff-only
source .venv-studio6/bin/activate
python inspection.py dashboard --config project.yaml
```

The ROI integration adds no new dependency requirements. An installation without segmentation support requires `python -m pip install -r requirements-segmentation.txt` in the active environment with a matching CPU/CUDA PyTorch build. On Windows, update with `git pull --ff-only` and start with `Start.cmd`. For a new Linux installation, see [Linux installation](INSTALLATION_LINUX.md).
