"""Reproducible Optuna studies over one frozen, grouped segmentation dataset."""
from __future__ import annotations
import csv
import gc
import hashlib
import json
import math
import random
import re
import time
from pathlib import Path
import numpy as np
from PIL import Image
from .common import CLASSES, atomic_json, read_json, safe_path, sha256, utc_now
from .project import Project
from .registry import catalog, build_model, validate_spec
from .training import split_groups, inspect_training_masks, _load_native, _checkpoint_save
from .inference import prepare_image, prepare_mask, restore_probabilities, confusion_matrix, metrics_from_confusion, overlay, select_device

DEFAULT_SEARCH = dict(study_name='top_search_01', models=['small_unet','unet_resnet18','segformer_mit_b0'],
    custom_models=[], trials=20, hours=0, trial_minutes=0, device='auto', epochs=30, patience=7,
    image_sizes=[256,512], batch_sizes=[2,4], learning_rate=[0.00001,0.003], weight_decay=[0.000001,0.001],
    losses=['ce_dice','ce_tversky'], optimizers=['AdamW'], sampler='tpe', pruner='median',
    warmup_epochs=3, seed=42, val_fraction=.2, test_fraction=.2, min_images=5,
    require_both=True, rotations=True, flips=False, mixed_precision=True, cpu_threads=4,
    metric='foreground_mean_iou', freeze_batchnorm=True)


def settings(raw):
    cfg = {**DEFAULT_SEARCH, **raw}
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,79}', str(cfg['study_name'])):
        raise ValueError('Study name: letters, numbers, underscore or dash; up to 80 characters.')
    for key in ['epochs','patience','cpu_threads','min_images']:
        if type(cfg[key]) is not int or cfg[key] < 1: raise ValueError(f'{key} must be a positive integer.')
    for key in ['trials','warmup_epochs']:
        if type(cfg[key]) is not int or cfg[key]<0: raise ValueError(f'{key} must be a non-negative integer.')
    for key in ['hours','trial_minutes']:
        if not math.isfinite(float(cfg[key])) or float(cfg[key])<0: raise ValueError(f'{key} must be finite and non-negative.')
    if not 0<float(cfg['val_fraction'])<1 or not 0<=float(cfg['test_fraction'])<1 or float(cfg['val_fraction'])+float(cfg['test_fraction'])>=1:
        raise ValueError('Validation must be positive; validation + test fractions must be less than 1.')
    if any(type(v) is int and v > 4096 for v in cfg['image_sizes']): raise ValueError('image_sizes must be at most 4096 pixels.')
    for key, lo in [('image_sizes',32),('batch_sizes',1)]:
        if not cfg[key] or any(type(v) is not int or v<lo for v in cfg[key]): raise ValueError(f'Invalid {key}.')
    for key in ['learning_rate','weight_decay']:
        values=cfg[key]
        if len(values)!=2 or not 0<float(values[0])<=float(values[1]) or not all(math.isfinite(float(v)) for v in values): raise ValueError(f'{key} requires two positive ordered bounds.')
    for key, allowed in [('losses',{'ce_dice','ce','ce_tversky'}), ('optimizers',{'AdamW','Adam','SGD'})]:
        if not cfg[key] or not set(cfg[key])<=allowed: raise ValueError(f'Invalid {key}.')
    if cfg['device'] not in ('auto','cpu','cuda') or cfg['sampler'] not in ('tpe','random') or cfg['pruner'] not in ('median','hyperband','none'):
        raise ValueError('Invalid device, sampler or pruner.')
    if cfg['metric'] not in ('foreground_mean_iou','foreground_mean_dice'):
        raise ValueError('Select foreground_mean_iou or foreground_mean_dice.')
    entries={m['id']:m for m in catalog()}
    specs=[]
    for key in cfg['models']:
        if key not in entries: raise ValueError(f'Unknown model: {key}')
        specs.append(entries[key])
    specs += cfg['custom_models']
    specs=[validate_spec(s) for s in specs]
    if not specs or len(set(s['id'] for s in specs))!=len(specs):
        raise ValueError('Select at least one model; IDs must be unique.')
    for spec in specs:
        spec.pop('available',None)
        if spec.get('encoder_checkpoint'):
            path=Path(spec['encoder_checkpoint']).expanduser().resolve()
            spec['encoder_checkpoint']=str(path)
            spec['encoder_checkpoint_sha256']=sha256(path)
    cfg['specs']=specs
    return cfg


def make_split(records, cfg):
    if cfg['test_fraction']:
        first=split_groups(records,cfg['test_fraction'],cfg['seed'],require_both=cfg['require_both'])
        test_ids=set(first['validation_ids'])
    else: test_ids=set()
    pool=[r for r in records if r['id'] not in test_ids]
    remaining=split_groups(pool,cfg['val_fraction']/(1-cfg['test_fraction']),cfg['seed']+1,require_both=cfg['require_both'])
    train_ids=set(remaining['train_ids'])
    roles={r['group']: 'test' if r['id'] in test_ids else 'train' if r['id'] in train_ids else 'validation' for r in records}
    val=[r for r in records if roles[r['group']]=='validation']
    if not any(r['defect_classes'] for r in val):
        raise ValueError('Validation has no labeled defects. Add independent defect groups or change split seed/fractions.')
    return dict(group_split=roles, seed=cfg['seed'], validation_missing_classes=remaining['validation_missing_classes'],
                **{role+'_ids':[r['id'] for r in records if roles[r['group']]==role] for role in ['train','validation','test']})


def dataset_contract(cfg):
    return {k:v for k,v in cfg.items() if k not in ('trials','hours','trial_minutes','device','cpu_threads','study_name','models','custom_models')}


def prepare_study(project_cfg, cfg):
    root=Path(project_cfg['output_dir'])/'studies'/cfg['study_name']
    contract=dataset_contract(cfg)
    if (root/'contract.json').exists():
        if read_json(root/'contract.json') != contract:
            raise ValueError('This study has a different search space or split configuration. Use a new study name, or restore its saved settings. Budgets and device may change.')
    elif root.exists() and any(root.iterdir()):
        raise ValueError('An incomplete study directory already exists. Use a new study name; its diagnostic files have been preserved.')
    else:
        root.mkdir(parents=True,exist_ok=True)
        Project(project_cfg).snapshot(root/'dataset')
        dataset=read_json(root/'dataset/dataset.json')
        records=dataset['records']
        if len(records)<max(3,int(cfg['min_images'])): raise ValueError('Too few approved images. Approve more before search.')
        inspect_training_masks(records,root/'dataset',max(cfg['image_sizes']))
        split=make_split(records,cfg)
        atomic_json(root/'split.json',split)
        atomic_json(root/'records.json',records)
        atomic_json(root/'contract.json',contract)
        atomic_json(root/'search_settings.json',cfg)
    dataset=read_json(root/'dataset/dataset.json')
    for row in dataset['records']:
        for name in ('image','mask'):
            if sha256(safe_path(root/'dataset',row[name]))!=row[name+'_sha256']:
                raise ValueError('Frozen dataset checksum mismatch. Do not modify study snapshots.')
    return root, read_json(root/'records.json'), read_json(root/'split.json'), dataset['fingerprint']


def loss_fn(logits, targets, weights, kind):
    import torch
    from torch.nn import functional as F
    ce=F.cross_entropy(logits,targets,weight=weights,ignore_index=255)
    if kind=='ce': return ce
    valid=targets!=255
    prob=logits.softmax(1)*valid[:,None]
    truth=F.one_hot(targets.masked_fill(~valid,0),3).permute(0,3,1,2)*valid[:,None]
    p,y=prob[:,1:],truth[:,1:]
    tp=(p*y).sum((0,2,3)); fp=(p*(1-y)).sum((0,2,3)); fn=((1-p)*y).sum((0,2,3))
    if kind=='ce_tversky': overlap=(tp+1)/(tp+.3*fp+.7*fn+1)
    else: overlap=(2*tp+1)/(2*tp+fp+fn+1)
    return ce+.5*(1-overlap.mean())


def evaluate(model, rows, data_root, size, device, weights=None, output=None, check=None):
    import torch
    cm=np.zeros((3,3),dtype=np.int64); entries=[]; losses=[]
    model.eval()
    if output: Path(output).mkdir(parents=True,exist_ok=True)
    with torch.inference_mode():
        for row in rows:
            if check: check()
            image,target=_load_native(row,data_root)
            x,g=prepare_image(image,size)
            logits=model(torch.from_numpy(x)[None].to(device))
            if weights is not None:
                y=torch.from_numpy(prepare_mask(target,g).astype(np.int64))[None].to(device)
                losses.append(float(loss_fn(logits,y,weights,'ce_dice')))
            pred=restore_probabilities(logits.softmax(1)[0].cpu().numpy(),g)
            local=confusion_matrix(target,pred); cm+=local
            metrics=metrics_from_confusion(local)
            entry={'id':row['id'],'group':row['group'],'iou':metrics['foreground_mean_iou'],'dice':metrics['foreground_mean_dice']}
            if output:
                for suffix,im in [('mask',Image.fromarray(pred)),('overlay',overlay(image,pred)),('target',overlay(image,target))]:
                    name=f"{row['id']}.{suffix}.png"; im.save(Path(output)/name); entry[suffix]=name
            entries.append(entry)
    metrics=metrics_from_confusion(cm)
    metrics.update(images=len(rows), canonical_loss=float(np.mean(losses)) if losses else None)
    if output:
        atomic_json(Path(output)/'metrics.json',metrics); atomic_json(Path(output)/'images.json',entries)
        if entries:
            with (Path(output)/'predictions.csv').open('w',newline='',encoding='utf-8') as f:
                writer=csv.DictWriter(f,fieldnames=list(entries[0])); writer.writeheader(); writer.writerows(entries)
    return metrics


def summary(study, root):
    trials=[]
    for t in study.trials:
        trials.append(dict(number=t.number,state=t.state.name,value=t.value if t.value is not None and math.isfinite(t.value) else None,
                           params=t.params,attributes=t.user_attrs,seconds=(t.datetime_complete-t.datetime_start).total_seconds() if t.datetime_complete and t.datetime_start else None))
    complete=[t for t in trials if t['state']=='COMPLETE' and t['value'] is not None]
    result=dict(study_name=study.study_name,updated_at=utc_now(),trials=trials,best=max(complete,key=lambda t:t['value']) if complete else None,
                snapshot='Frozen approved annotations; test split is excluded from Optuna.')
    atomic_json(root/'summary.json',result)
    with (root/'trials.csv').open('w',newline='',encoding='utf-8') as f:
        fields=['number','state','value','seconds','model','image_size','batch_size','learning_rate','loss','optimizer','error']
        writer=csv.DictWriter(f,fieldnames=fields); writer.writeheader()
        for t in trials: writer.writerow({**{k:t[k] for k in fields[:4]},**{k:t['params'].get(k) for k in fields[4:-1]},'error':t['attributes'].get('error','')})
    return result


def run_search(project_cfg, raw, job_root):
    import torch
    import optuna
    cfg=settings(raw); root,records,split,fingerprint=prepare_study(project_cfg,cfg)
    device=select_device(cfg['device']); torch.set_num_threads(cfg['cpu_threads'])
    seed=cfg['seed']; sampler=optuna.samplers.TPESampler(seed=seed) if cfg['sampler']=='tpe' else optuna.samplers.RandomSampler(seed=seed)
    pruner={'median':lambda:optuna.pruners.MedianPruner(n_startup_trials=3,n_warmup_steps=cfg['warmup_epochs']),
            'hyperband':lambda:optuna.pruners.HyperbandPruner(min_resource=max(1,cfg['warmup_epochs']),max_resource=cfg['epochs']),
            'none':optuna.pruners.NopPruner}[cfg['pruner']]()
    study=optuna.create_study(study_name=cfg['study_name'],storage='sqlite:///'+(root/'optuna.db').resolve().as_posix(),
                              direction='maximize',load_if_exists=True,sampler=sampler,pruner=pruner)
    # A previous process may have been killed after saving an epoch.
    for t in study.get_trials(states=(optuna.trial.TrialState.RUNNING,)):
        study.tell(t.number,state=optuna.trial.TrialState.FAIL)
    train_rows=[r for r in records if r['id'] in set(split['train_ids'])]
    val_rows=[r for r in records if r['id'] in set(split['validation_ids'])]
    specs={s['id']:s for s in cfg['specs']}
    started=time.monotonic(); deadline=started+cfg['hours']*3600 if cfg['hours'] else math.inf
    job_root=Path(job_root)
    def stopped(): return (job_root/'stop').exists() or time.monotonic()>=deadline
    def publish(**extra):
        atomic_json(job_root/'status.json',dict(status='running',study_name=cfg['study_name'],elapsed_seconds=time.monotonic()-started,device=str(device),**extra))
    def objective(trial):
        model=None; optimizer=None
        trial_dir=root/'trials'/f'{trial.number:05d}'; trial_dir.mkdir(parents=True)
        try:
            model_id=trial.suggest_categorical('model',list(specs)); spec=specs[model_id]
            size=trial.suggest_categorical('image_size',cfg['image_sizes']); batch=trial.suggest_categorical('batch_size',cfg['batch_sizes'])
            lr=trial.suggest_float('learning_rate',*cfg['learning_rate'],log=True)
            wd=trial.suggest_float('weight_decay',*cfg['weight_decay'],log=True)
            kind=trial.suggest_categorical('loss',cfg['losses']); optimizer_name=trial.suggest_categorical('optimizer',cfg['optimizers'])
            trial_start=time.monotonic(); trial_deadline=trial_start+cfg['trial_minutes']*60 if cfg['trial_minutes'] else math.inf
            def check():
                if stopped() or time.monotonic()>=trial_deadline:
                    trial.set_user_attr('stop_reason','user_or_study_budget' if stopped() else 'trial_budget')
                    raise optuna.TrialPruned('Stopped at a batch boundary; saved checkpoints are retained.')
            random.seed(seed+trial.number); np.random.seed(seed+trial.number); torch.manual_seed(seed+trial.number)
            if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed+trial.number)
            check(); model=build_model(spec).to(device)
            # Frozen batchnorm statistics allow batch-size 1 and final partial batches.
            def train_mode():
                model.train()
                if cfg['freeze_batchnorm']:
                    for m in model.modules():
                        if isinstance(m,torch.nn.modules.batchnorm._BatchNorm): m.eval()
            train_mode()
            findings=inspect_training_masks(train_rows,root/'dataset',size)
            atomic_json(trial_dir/'preprocessing.json',findings)
            counts=np.zeros(3,dtype=np.int64)
            for r in train_rows:
                im,mask=_load_native(r,root/'dataset'); _,g=prepare_image(im,size); small=prepare_mask(mask,g)
                counts+=np.bincount(small[small!=255],minlength=3)
            needed={c for r in train_rows for c in r['defect_classes']}
            if any(counts[c]==0 for c in needed): raise ValueError('A defect class vanished at this image size. Increase the resolution.')
            weights=torch.tensor([1.]+[min(10.,max(1.,math.sqrt(max(1,counts[0])/max(1,counts[i])))) for i in (1,2)],device=device)
            optimizer=getattr(torch.optim,optimizer_name)(model.parameters(),lr=lr,weight_decay=wd,**({'momentum':.9} if optimizer_name=='SGD' else {}))
            amp=bool(cfg['mixed_precision'] and device.type=='cuda')
            scaler=torch.amp.GradScaler('cuda',enabled=amp)
            history=[]; best=-math.inf; stalled=0
            atomic_json(trial_dir/'spec.json',spec)
            trial.set_user_attr('parameter_count',sum(p.numel() for p in model.parameters()))
            trial.set_user_attr('lost_components',sum(sum(x['lost_components'].values()) for x in findings))
            for epoch in range(1,cfg['epochs']+1):
                check(); train_mode(); order=list(train_rows); random.shuffle(order); total=0.; n=0
                for offset in range(0,len(order),batch):
                    check(); arrays=[]; masks=[]
                    for row in order[offset:offset+batch]:
                        im,mask=_load_native(row,root/'dataset'); x,g=prepare_image(im,size); y=prepare_mask(mask,g)
                        if cfg['rotations']:
                            k=random.randrange(4); x=np.rot90(x,k,(1,2)); y=np.rot90(y,k)
                        if cfg['flips'] and random.random()<.5: x=x[:,:,::-1]; y=y[:,::-1]
                        arrays.append(np.ascontiguousarray(x)); masks.append(np.ascontiguousarray(y,dtype=np.int64))
                    x=torch.from_numpy(np.stack(arrays)).to(device); y=torch.from_numpy(np.stack(masks)).to(device)
                    optimizer.zero_grad(set_to_none=True)
                    with torch.autocast(device_type=device.type,enabled=amp): loss=loss_fn(model(x),y,weights,kind)
                    if not torch.isfinite(loss): raise RuntimeError('Non-finite loss.')
                    scaler.scale(loss).backward(); scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(model.parameters(),1.); scaler.step(optimizer); scaler.update()
                    total+=float(loss.detach())*len(arrays); n+=len(arrays)
                    publish(trial=trial.number,model=model_id,epoch=epoch,batch_done=min(offset+batch,len(order)),train_images=len(order))
                val=evaluate(model,val_rows,root/'dataset',size,device,weights,check=check)
                score=val[cfg['metric']]
                if score is None or not math.isfinite(score): raise ValueError('Validation metric is undefined.')
                row=dict(epoch=epoch,train_loss=total/n,validation_loss=val['canonical_loss'],score=score,
                         iou=val['foreground_mean_iou'],dice=val['foreground_mean_dice'],inner_iou=val['classes']['inner']['iou'],outer_iou=val['classes']['outer']['iou'])
                history.append(row); atomic_json(trial_dir/'history.json',history)
                payload=dict(schema_version=2,model_type='studio_semantic',classes=CLASSES,spec=spec,image_size=size,
                             epoch=epoch,model_state_dict={k:v.detach().cpu().clone() for k,v in model.state_dict().items()},
                             dataset_fingerprint=fingerprint,group_split=split['group_split'],validation_metrics=val,
                             normalization='RGB / 255 before model adapter',max_image_pixels=project_cfg['max_image_pixels'])
                if score>best+1e-8:
                    best=score; stalled=0; _checkpoint_save(trial_dir/'best.pt',payload)
                    trial.set_user_attr('best_epoch',epoch); trial.set_user_attr('validation',val)
                else: stalled+=1
                _checkpoint_save(trial_dir/'last.pt',{**payload,'optimizer_state_dict':optimizer.state_dict(),'scaler_state_dict':scaler.state_dict()})
                publish(trial=trial.number,model=model_id,epoch=epoch,best_score=best,history=history)
                trial.report(score,epoch)
                if trial.should_prune(): raise optuna.TrialPruned('Pruner stopped this trial after validation.')
                if stalled>=cfg['patience']: break
            trial.set_user_attr('checkpoint',f'trials/{trial.number:05d}/best.pt')
            return best
        except optuna.TrialPruned: raise
        except Exception as exc:
            trial.set_user_attr('error',f'{type(exc).__name__}: {exc}')
            atomic_json(trial_dir/'error.json',{'error':str(exc),'type':type(exc).__name__})
            raise
        finally:
            del model,optimizer; gc.collect()
            if torch.cuda.is_available(): torch.cuda.empty_cache()
    def callback(study, trial):
        summary(study,root)
        if stopped(): study.stop()
        recent=study.trials[-max(10,len(specs)*2):]
        if len(recent)>=max(10,len(specs)*2) and all(t.state==optuna.trial.TrialState.FAIL for t in recent):
            study.stop(); publish(note='Search stopped after repeated failures. Inspect errors and run preflight.')
    if not stopped():
        study.optimize(objective,n_trials=cfg['trials'] or None,timeout=cfg['hours']*3600 or None,
                       callbacks=[callback],catch=(Exception,),gc_after_trial=True)
    result=summary(study,root)
    result['status']='stopped' if (job_root/'stop').exists() else 'completed' if result['best'] else 'no_completed_trials'
    result['output_dir']=str(root)
    return result


def preflight(raw, job_root):
    import torch
    cfg=settings(raw); device=select_device(cfg['device']); torch.set_num_threads(cfg['cpu_threads'])
    results=[]
    for spec in cfg['specs']:
        for size in cfg['image_sizes']:
            if (Path(job_root)/'stop').exists(): return {'status':'stopped','models':results}
            model=None
            try:
                model=build_model(spec).to(device); model.train()
                if cfg['freeze_batchnorm']:
                    for m in model.modules():
                        if isinstance(m,torch.nn.modules.batchnorm._BatchNorm):m.eval()
                # Use the largest requested batch to test the selected memory demand.
                x=torch.zeros(max(cfg['batch_sizes']),3,size,size,device=device)
                y=model(x)
                if y.shape!=(x.shape[0],3,size,size) or not torch.isfinite(y).all(): raise ValueError('Invalid output shape or values.')
                y.mean().backward()
                results.append({'id':spec['id'],'size':size,'batch_size':len(x),'ok':True,'parameters':sum(p.numel() for p in model.parameters())})
            except Exception as exc: results.append({'id':spec['id'],'size':size,'ok':False,'error':str(exc)})
            finally:
                del model; gc.collect()
                if torch.cuda.is_available(): torch.cuda.empty_cache()
            atomic_json(Path(job_root)/'status.json',{'status':'running','models':results})
    return {'status':'completed','models':results}
