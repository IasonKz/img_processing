# Changelog

## 5.0.0

- Removed profile-specific time ceilings. Presets supply editable defaults; Custom Optuna selects CPU/CUDA/Auto, CPU threads, data-loader workers, and an independently defined total budget.
- Added combined learning/search analytics, parameter relationship plots, candidate comparison charts, and confusion-matrix grids with explicit evidence roles.

- Added validated Custom Optuna contracts: fixed/choices/range specifications, per-model overrides, validation-objective selection, TPE/Random/finite Grid, selectable pruners, trial allowances, improvement patience, and failure caps.
- Added pretrained EfficientNet-B2, EfficientNetV2-S, MobileNetV3-Large, and DenseNet121 while keeping focused profile shortlists. Image-model searches require pretrained initialization.
- Added optional shared global-plus-overlapping-patch classification with image-level supervision, complete spatial coverage, and explicit memory/coverage limits.
- Corrected weighted-loss normalization so minority weights remain effective with single-image microbatches. Old resumable optimizer states are not assumed compatible; old checkpoints retain inference use.
- Added Decision Lab for triage, weighted ensembles, regularized held-out stacking, and confidence cascades. Score calibration/combiner fitting uses protected calibration-fit groups, with threshold tuning on separate groups and a frozen-system selection report.
- Added threshold-pair sweep and bounded Optuna decision tuning, with separate error/review targets and no automatic final-test access.
- Added reviewed-data revision export with explicit human labels, content/group checks, unchanged old holdouts, and training replay for controlled fine-tuning.
- Added a short Linux launcher and Windows v5-specific environment defaults. Previous project folders and virtual environments are retained.

Full grouped OOF stacking, DINOv2 integration, segmentation, arbitrary nested systems, and automatic whole-system ONNX export are not implemented. See [V5_DESIGN_AND_LIMITS.md](V5_DESIGN_AND_LIMITS.md) and the release verification record.

## 4.0.0

- Reworked the local workspace for model development, inspection sequences, and image review.
- Added immutable ordered workflow recipes with any-bad, all-bad, and majority rules, short-circuit traces, and labeled batch metrics.
- Added live copied-image review with original reference tags, separate operator tags and notes, and explicit metric scopes.
- Added dedicated Windows setup/start launchers, separate short-path environments, and a real requested-device computation check.
- Integrated atomic output publishing with bounded retry for transient Windows access and sharing failures.
- Replaced legacy operator material with English setup, workflow, review, and troubleshooting guides.
- Retained profile budgets, full-image preprocessing, quarter-turn VIG augmentation, decision modes, and portable model operations.

## 3.0.0

- Integrated the prior threshold, policy-review, visual-report and telemetry additions.
- Added per-model Optuna studies, profile-specific search spaces, bounded seed
  confirmations, resumable SQLite studies and cumulative 2/6/12-hour budgets.
- Added a local browser dashboard for configuration, search, comparison, decisions,
  classification, reports and export.
- Preserved native image pixels with padding and exact quarter-turn VIG training
  augmentation; grouped tray/row/column units remain in a single split.
- Corrected weighted-loss normalization across microbatches; added explicit
  head-only/full/last-block training and fine-tuning-aware stopping/pruning.
- Added versioned policy/manual/argmax/scores-only decisions and portable runtime
  support without modifying original model results.
- Made missing targets, incomplete comparisons and outstanding independent tests
  visible; included constant-class baselines and both class error rates.
- Added Windows CPU/CUDA setup, three launch profiles and a reproducible synthetic
  end-to-end smoke check. ONNX Runtime telemetry is disabled before session creation.

Optuna searches a bounded set of candidates; no customer-dataset performance is
guaranteed. See [VALIDATION_REPORT.md](VALIDATION_REPORT.md) for executed checks and
remaining Windows/GPU acceptance work. The older notes below describe v2 only.

## 2.0.0

- Added project-level task configuration with CPU pilot and GPU workstation profiles.
- Added PatchCore-style normal-feature memory banks alongside the supervised roster.
- Added automatic image-envelope discovery without a fixed 600×600 assumption.
- Added tracked model state, immutable manifests, continuation checkpoints, and frozen-version comparison.
- Added ONNX packages with independent runtime scripts, package integrity, and parity verification.
- Added training-package relocation, current-model registration, and rollback support.
- Added English operator, installation, model-management, and deployment documentation.
- Retained defect-oriented decision policy, separate development/test roles, and image-folder exports.

### Scope limits

This release does not implement pairwise new-damage classification, camera-die cropping/alignment, tiled training, grouped cross-validation, automatic hyperparameter search, probability calibration, quantization, a graphical interface, or machine/PLC control. The PatchCore-style implementation differs from the published reference scoring method as documented in [MODELS_AND_METRICS.md](MODELS_AND_METRICS.md).

Actual test coverage and hardware acceptance status are recorded in [VALIDATION_REPORT.md](VALIDATION_REPORT.md). No accuracy or throughput is asserted for a customer dataset before the relevant experiment has run.
