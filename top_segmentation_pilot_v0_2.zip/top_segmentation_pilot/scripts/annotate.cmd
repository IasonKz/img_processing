@echo off
setlocal
pushd "%~dp0.."
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" segmentation.py annotate --config project.yaml %*
) else (
  python segmentation.py annotate --config project.yaml %*
)
set "result=%errorlevel%"
popd
exit /b %result%
