"""Frozen patch-feature anomaly detection with a bounded representative coreset.

This implementation follows the PatchCore feature-memory approach: pretrained
ResNet layer2/layer3 features, local aggregation, representative feature subset,
and nearest-neighbor anomaly localization. Image scores use the maximum nearest
Euclidean patch distance, without the paper's optional neighborhood reweighting.
The input contract is a whole inspection ROI; no hidden resize or tiling occurs.
"""
from __future__ import annotations

from pathlib import Path
import time

import numpy as np

from .common import read_json, sha_file, write_json
from .engine import (backend_fingerprints, checkpoint_metadata, device_for, loader,
                     seed_everything, torch_modules, verify_checkpoint_configuration,
                     weight_path, _atomic_torch_save, check_stop, resource_sample)


def patchcore_settings(cfg):
    values = {"backbone": "resnet18", "reservoir_size": 10000, "coreset_size": 1024,
              "projection_dim": 32, "query_chunk_size": 1024, "memory_chunk_size": 1024}
    values.update(cfg.get("patchcore", {}))
    if values["backbone"] not in ("resnet18", "resnet50"):
        raise ValueError("PatchCore backbone must be resnet18 or resnet50.")
    for key in ("reservoir_size", "coreset_size", "projection_dim", "query_chunk_size", "memory_chunk_size"):
        if not isinstance(values[key], int) or isinstance(values[key], bool) or values[key] < 1:
            raise ValueError(f"patchcore.{key} must be a positive integer.")
    if values["coreset_size"] > values["reservoir_size"]:
        raise ValueError("PatchCore coreset_size cannot exceed reservoir_size.")
    if int(values.get("num_neighbors", 1)) != 1:
        raise ValueError("This implementation uses one nearest memory neighbor per patch.")
    return values


def make_patchcore_extractor(backbone="resnet18", cfg=None, pretrained=False):
    """Build an exportable frozen module producing B,C,H,W patch embeddings."""
    torch, tv = torch_modules()
    if backbone not in ("resnet18", "resnet50"):
        raise ValueError("PatchCore backbone must be resnet18 or resnet50.")
    source = tv.models.get_model(backbone, weights=None)
    if pretrained:
        source.load_state_dict(torch.load(weight_path(cfg, backbone), map_location="cpu", weights_only=True), strict=True)

    class FeatureExtractor(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.stem = torch.nn.Sequential(source.conv1, source.bn1, source.relu, source.maxpool)
            self.layer1, self.layer2, self.layer3 = source.layer1, source.layer2, source.layer3
            self.pool = torch.nn.AvgPool2d(kernel_size=3, stride=1, padding=1)

        def forward(self, inputs):
            early = self.layer2(self.layer1(self.stem(inputs)))
            later = self.layer3(early)
            early, later = self.pool(early), self.pool(later)
            later = torch.nn.functional.interpolate(later, size=early.shape[-2:], mode="bilinear", align_corners=False)
            return torch.cat([early, later], dim=1)

    extractor = FeatureExtractor().eval()
    for parameter in extractor.parameters():
        parameter.requires_grad_(False)
    return extractor


class FeatureReservoir:
    """Uniform streaming reservoir using independent random priorities.

    All observed patches have equal admission probability. Resident memory is
    capped at reservoir_size plus a single incoming feature block. Values are
    accumulated in CPU float32 to avoid retaining device tensors between images.
    """
    def __init__(self, capacity, seed):
        self.capacity = int(capacity)
        if self.capacity < 1:
            raise ValueError("Reservoir capacity must be positive.")
        self.rng = np.random.default_rng(seed)
        self.values = None
        self.priorities = np.empty(0)
        self.seen = 0

    def update(self, values):
        values = np.asarray(values, dtype=np.float32)
        if values.ndim != 2 or not np.isfinite(values).all():
            raise ValueError("Patch features must be a finite two-dimensional array.")
        if self.values is not None and values.shape[1] != self.values.shape[1]:
            raise ValueError("Patch embedding dimensions changed during fitting.")
        # Small bounded pieces prevent an unusually large image from allocating
        # a concatenation containing all its patches plus the reservoir.
        for first in range(0, len(values), self.capacity):
            part = values[first:first + self.capacity]
            priorities = self.rng.random(len(part))
            self.seen += len(part)
            merged = part if self.values is None else np.concatenate([self.values, part])
            scores = np.concatenate([self.priorities, priorities])
            if len(scores) > self.capacity:
                keep = np.argpartition(scores, self.capacity - 1)[:self.capacity]
                self.values, self.priorities = merged[keep], scores[keep]
            else:
                self.values, self.priorities = merged.copy(), scores


def greedy_coreset(features, size, projection_dim=32, seed=42, device="cpu", stop_check=None):
    """Farthest-first coreset in a seeded Gaussian projection of patch features."""
    torch, _ = torch_modules()
    check_stop(stop_check)
    features = np.asarray(features, dtype=np.float32)
    if features.ndim != 2 or len(features) == 0 or not np.isfinite(features).all():
        raise ValueError("Coreset requires a nonempty finite feature matrix.")
    size = min(int(size), len(features))
    if size < 1 or projection_dim < 1:
        raise ValueError("Coreset and projection sizes must be positive.")
    if size == len(features):
        return torch.from_numpy(features.copy())
    rng = np.random.default_rng(seed)
    dimensions = min(int(projection_dim), features.shape[1])
    projection = rng.normal(size=(features.shape[1], dimensions)).astype(np.float32) / np.float32(np.sqrt(dimensions))
    reduced = torch.from_numpy(features @ projection).to(device)
    chosen = torch.zeros(len(features), dtype=torch.bool, device=device)
    distances = torch.full((len(features),), float("inf"), device=device)
    index = int(rng.integers(len(features)))
    indices = []
    with torch.inference_mode():
        for _ in range(size):
            check_stop(stop_check)
            indices.append(index)
            chosen[index] = True
            latest = ((reduced - reduced[index]) ** 2).sum(1)
            distances = torch.minimum(distances, latest)
            distances[chosen] = -1
            index = int(distances.argmax().item())
    return torch.from_numpy(features[np.asarray(indices)].copy())


def nearest_distances(queries, bank, query_chunk_size=1024, memory_chunk_size=1024, stop_check=None):
    """Exact Euclidean nearest distances without a full patches-by-bank matrix."""
    torch, _ = torch_modules()
    if queries.ndim != 2 or bank.ndim != 2 or queries.shape[1] != bank.shape[1] or len(bank) == 0:
        raise ValueError("Queries and nonempty memory bank must have matching embedding dimensions.")
    if query_chunk_size < 1 or memory_chunk_size < 1:
        raise ValueError("Distance chunk sizes must be positive.")
    results = []
    for first in range(0, len(queries), query_chunk_size):
        check_stop(stop_check)
        part = queries[first:first + query_chunk_size].float()
        best = torch.full((len(part),), float("inf"), device=part.device)
        for start in range(0, len(bank), memory_chunk_size):
            check_stop(stop_check)
            distances = torch.cdist(part, bank[start:start + memory_chunk_size].float(), p=2,
                                    compute_mode="donot_use_mm_for_euclid_dist")
            best = torch.minimum(best, distances.min(dim=1).values)
        results.append(best)
    return torch.cat(results) if results else queries.new_empty((0,))


def build_patchcore_model(extractor, memory_bank, query_chunk_size=1024, memory_chunk_size=1024, stop_check=None):
    torch, _ = torch_modules()

    class PatchCoreModel(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.extractor = extractor
            self.register_buffer("memory_bank", memory_bank.float())
            self.query_chunk_size = int(query_chunk_size)
            self.memory_chunk_size = int(memory_chunk_size)
            self.stop_check = stop_check

        def score_features(self, features):
            batch, channels, height, width = features.shape
            flat = features.permute(0, 2, 3, 1).reshape(-1, channels)
            distances = nearest_distances(flat, self.memory_bank, self.query_chunk_size, self.memory_chunk_size,
                                          stop_check=self.stop_check)
            maps = distances.reshape(batch, height, width)
            return maps.flatten(1).max(1).values, maps

        def forward(self, inputs):
            return self.score_features(self.extractor(inputs))[0]

        def anomaly_maps(self, inputs):
            return self.score_features(self.extractor(inputs))[1]

    return PatchCoreModel().eval()


def load_patchcore(path, cfg, device):
    torch, _ = torch_modules()
    checkpoint = torch.load(path, map_location="cpu", weights_only=True)
    verify_checkpoint_configuration(checkpoint, cfg)
    if checkpoint.get("kind") != "patchcore":
        raise ValueError("Expected a PatchCore checkpoint.")
    extractor = make_patchcore_extractor(checkpoint["backbone"])
    extractor.load_state_dict(checkpoint["state_dict"], strict=True)
    bank = checkpoint["memory_bank"]
    if bank.ndim != 2 or len(bank) < 1 or not torch.isfinite(bank).all():
        raise ValueError("PatchCore memory bank is empty or contains invalid values.")
    settings = patchcore_settings(cfg)
    model = build_patchcore_model(extractor, bank, settings["query_chunk_size"], settings["memory_chunk_size"])
    return model.to(device).eval(), checkpoint


def predict_patchcore(model, rows, cfg, device, stop_check=None, on_scores=None):
    torch, _ = torch_modules()
    device = torch.device(device)
    if not rows:
        return np.empty(0, dtype=float), 0.0
    model.eval()
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    start = time.perf_counter()
    values = []
    offset = 0
    # The callback also reaches memory-distance chunks within a single image.
    model.stop_check = stop_check
    with torch.inference_mode():
        for inputs, _ in loader(rows, cfg):
            check_stop(stop_check)
            batch_scores = model(inputs.to(device)).float().cpu()
            if not torch.isfinite(batch_scores).all() or (batch_scores < 0).any():
                raise RuntimeError("PatchCore produced an invalid anomaly score.")
            values.append(batch_scores)
            if on_scores is not None:
                on_scores(offset, batch_scores.numpy().astype(float))
            offset += len(batch_scores)
    check_stop(stop_check)
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    seconds = time.perf_counter() - start
    scores = torch.cat(values).numpy().astype(float)
    if not np.isfinite(scores).all() or (scores < 0).any():
        raise RuntimeError("PatchCore produced an invalid anomaly score.")
    return scores, seconds


def fit_patchcore(seed, rows, cfg, out, init_checkpoint=None, progress_callback=None, stop_check=None):
    from .policy import metrics
    torch, _ = torch_modules()
    check_stop(stop_check)
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    settings = patchcore_settings(cfg)
    fingerprints = backend_fingerprints("patchcore", seed, rows, cfg, init_checkpoint)
    path = out / "best.pt"
    if path.is_file():
        checkpoint = torch.load(path, map_location="cpu", weights_only=True)
        if any(checkpoint.get(key) != value for key, value in fingerprints.items()):
            raise ValueError("PatchCore resume refused: dataset/configuration changed. Start a new run.")
        if (out / "completed.json").is_file():
            if read_json(out / "completed.json")["checkpoint_sha256"] != sha_file(path):
                raise ValueError("Completed PatchCore checkpoint integrity check failed.")
            return path
    seed_everything(seed)
    device = device_for(cfg)
    good_train = [row for row in rows if row["split"] == "train" and int(row["label"]) == 1]
    validation = [row for row in rows if row["split"] == "val"]
    if not good_train:
        raise ValueError("PatchCore requires at least one good training image.")
    if set(int(row["label"]) for row in validation) != {0, 1}:
        raise ValueError("PatchCore validation requires independent good and bad examples.")
    started = time.perf_counter()
    extractor = make_patchcore_extractor(settings["backbone"], cfg, cfg.get("pretrained", True) and not init_checkpoint)
    if init_checkpoint:
        parent = torch.load(init_checkpoint, map_location="cpu", weights_only=True)
        verify_checkpoint_configuration(parent, cfg)
        if parent.get("kind") != "patchcore" or parent.get("backbone") != settings["backbone"]:
            raise ValueError("PatchCore parent must use the same frozen feature extractor.")
        extractor.load_state_dict(parent["state_dict"], strict=True)
    extractor.to(device).eval()
    reservoir = FeatureReservoir(settings["reservoir_size"], seed)
    completed_images = 0
    with torch.inference_mode():
        for inputs, _ in loader(good_train, cfg, training=True, seed=seed):
            check_stop(stop_check)
            features = extractor(inputs.to(device)).float()
            flattened = features.permute(0, 2, 3, 1).reshape(-1, features.shape[1]).cpu().numpy()
            reservoir.update(flattened)
            completed_images += len(inputs)
            write_json(out / "progress.json", {"status": "collecting_good_features", "current_epoch": 0,
                       "processed_good_images": completed_images, "total_good_images": len(good_train),
                       "seen_patches": reservoir.seen, "retained_features": len(reservoir.values),
                       "elapsed_seconds": time.perf_counter() - started, **resource_sample(device)})
            print(f"{out.name}: PatchCore good images {completed_images}/{len(good_train)}, patches={reservoir.seen}", flush=True)
    write_json(out / "progress.json", {"status": "selecting_coreset", "current_epoch": 0,
               "processed_good_images": completed_images, "seen_patches": reservoir.seen,
               "retained_features": len(reservoir.values), "elapsed_seconds": time.perf_counter() - started})
    bank = greedy_coreset(reservoir.values, settings["coreset_size"], settings["projection_dim"], seed, device,
                          stop_check=stop_check)
    model = build_patchcore_model(extractor, bank, settings["query_chunk_size"], settings["memory_chunk_size"]).to(device)
    scores, validation_seconds = predict_patchcore(model, validation, cfg, device, stop_check=stop_check)
    validation_metrics = metrics([int(row["label"]) for row in validation], scores, float(np.median(scores)))
    payload = checkpoint_metadata(cfg, "patchcore", seed, 0, init_checkpoint)
    payload.update(fingerprints, kind="patchcore", backbone=settings["backbone"], score_type="anomaly_distance",
                   state_dict={key: value.detach().cpu() for key, value in extractor.state_dict().items()},
                   memory_bank=bank.cpu(), num_neighbors=1, score_aggregation="max_patch_nearest_euclidean",
                   local_pool_kernel=3, feature_layers=["layer2", "layer3"], interpolate_align_corners=False,
                   seen_patches=reservoir.seen, reservoir_count=len(reservoir.values), coreset_count=len(bank),
                   good_training_image_count=len(good_train), patchcore_settings=settings,
                   fit_resume_policy="restart_deterministically_from_good_training_images")
    _atomic_torch_save(payload, path)
    # No optimizer exists for a frozen feature-memory fit. last.pt is the same
    # completed state; an interrupted fit restarts deterministically from input.
    _atomic_torch_save(payload, out / "last.pt")
    details = dict(fingerprints, checkpoint_sha256=sha_file(path),
                   best_val_pr_auc_bad=float(validation_metrics["pr_auc_bad"]), epochs_ran=0,
                   kind="patchcore", score_type="anomaly_distance", training_seconds=time.perf_counter() - started,
                   validation_seconds=validation_seconds, good_training_image_count=len(good_train),
                   excluded_bad_training_image_count=sum(row["split"] == "train" and int(row["label"]) == 0 for row in rows),
                   seen_patches=reservoir.seen, coreset_count=len(bank),
                   embedding_dimension=int(bank.shape[1]), memory_bank_bytes=bank.numel() * bank.element_size())
    if progress_callback is not None:
        progress_callback(dict(details, current_epoch=0, epoch=0, stage="patchcore", finetune_epochs=0,
                               val_pr_auc_bad=details["best_val_pr_auc_bad"]))
    check_stop(stop_check)
    write_json(out / "completed.json", details)
    write_json(out / "progress.json", dict(details, status="completed", current_epoch=0, best_epoch=0,
                                           elapsed_seconds=details["training_seconds"]))
    del model, extractor
    if device.type == "cuda":
        torch.cuda.empty_cache()
    return path
