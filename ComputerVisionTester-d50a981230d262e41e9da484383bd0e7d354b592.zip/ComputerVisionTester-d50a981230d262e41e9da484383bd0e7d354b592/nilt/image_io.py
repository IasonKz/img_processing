"""Shared native-depth decoding and fixed intensity conversion.

Also shipped unchanged beside the standalone ONNX runtime. Display previews may
be reduced to eight bits; tensors and decoded-pixel identities never are.
"""
from __future__ import annotations

import math
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps

INTENSITY_DEFAULTS = {"uint16_black_level": 0.0, "uint16_white_level": 65535.0}


def intensity_settings(cfg):
    raw = cfg.get("intensity", {})
    if not isinstance(raw, dict) or set(raw) - set(INTENSITY_DEFAULTS):
        raise ValueError("intensity accepts uint16_black_level and uint16_white_level only.")
    result = {**INTENSITY_DEFAULTS, **raw}
    for key, value in result.items():
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
            raise ValueError(f"intensity.{key} must be finite and numeric.")
        result[key] = float(value)
    if not 0 <= result["uint16_black_level"] < result["uint16_white_level"] <= 65535:
        raise ValueError("Intensity levels must satisfy 0 <= black level < white level <= 65535.")
    return result


class NativeImage:
    """RGB pixels that Pillow cannot represent without truncating bit depth."""
    def __init__(self, pixels, normalized=False):
        pixels = np.asarray(pixels)
        expected = np.float32 if normalized else np.uint16
        if pixels.ndim != 3 or pixels.shape[2] != 3 or pixels.dtype != expected:
            raise ValueError("NativeImage requires HWC RGB uint16, or normalized float32 pixels.")
        self.pixels = np.ascontiguousarray(pixels)
        self.normalized = bool(normalized)

    @property
    def width(self):
        return self.pixels.shape[1]

    @property
    def height(self):
        return self.pixels.shape[0]

    @property
    def size(self):
        return (self.width, self.height)

    def copy(self):
        return NativeImage(self.pixels.copy(), self.normalized)

    def transpose(self, method):
        turns = {Image.Transpose.ROTATE_90: 1, Image.Transpose.ROTATE_180: 2,
                 Image.Transpose.ROTATE_270: 3}
        return NativeImage(np.rot90(self.pixels, turns[method]), self.normalized)

    def tobytes(self):
        dtype = "<f4" if self.normalized else "<u2"
        return self.pixels.astype(dtype, copy=False).tobytes()

    def __array__(self, dtype=None, copy=None):
        array = np.asarray(self.pixels, dtype=dtype)
        return array.copy() if copy else array


def _opencv():
    try:
        import cv2
    except ImportError as error:
        raise RuntimeError("Native 16-bit decoding requires opencv-python-headless. Install the project requirements.") from error
    return cv2


def _oriented(pixels, orientation):
    # EXIF orientation is lossless and matches Pillow ImageOps.exif_transpose.
    if orientation == 2:
        pixels = pixels[:, ::-1]
    elif orientation == 3:
        pixels = np.rot90(pixels, 2)
    elif orientation == 4:
        pixels = pixels[::-1]
    elif orientation == 5:
        pixels = pixels.transpose(1, 0, 2)
    elif orientation == 6:
        pixels = np.rot90(pixels, 3)
    elif orientation == 7:
        pixels = pixels.transpose(1, 0, 2)[::-1, ::-1]
    elif orientation == 8:
        pixels = np.rot90(pixels, 1)
    return np.ascontiguousarray(pixels)


def load_rgb(path):
    """Return Pillow RGB for 8-bit sources, NativeImage for unsigned 16-bit.

    Float/signed integer and multiframe inputs require explicit preprocessing.
    PNG IHDR and TIFF BitsPerSample are inspected before Pillow can truncate
    color data. OpenCV IMREAD_UNCHANGED preserves channels and integer levels.
    """
    path = Path(path)
    with path.open("rb") as handle:
        header = handle.read(29)
    png16 = (header[:8] == b"\x89PNG\r\n\x1a\n" and header[12:16] == b"IHDR"
             and len(header) > 24 and header[24] == 16)
    with Image.open(path) as raw:
        if getattr(raw, "n_frames", 1) != 1:
            raise ValueError("Multi-frame images require explicit frame extraction before ingestion.")
        bits = getattr(raw, "tag_v2", {}).get(258, ())
        bits = (bits,) if isinstance(bits, int) else bits
        high_depth = png16 or raw.mode.startswith("I;16") or bool(bits and max(bits) > 8)
        if not high_depth:
            if raw.mode.startswith("I") or raw.mode == "F":
                raise ValueError("Float/signed integer images require explicit intensity conversion first.")
            return ImageOps.exif_transpose(raw).convert("RGB")
        orientation = int(raw.getexif().get(274, 1))
        is_tiff = raw.format == "TIFF"
    cv2 = _opencv()
    # Reading bytes first supports non-ASCII Windows paths consistently.
    pixels = cv2.imdecode(np.frombuffer(path.read_bytes(), dtype=np.uint8), cv2.IMREAD_UNCHANGED)
    if pixels is None or pixels.dtype != np.uint16:
        raise ValueError("Expected unsigned 16-bit image; decoder did not preserve native intensity precision.")
    if pixels.ndim == 2:
        pixels = np.repeat(pixels[:, :, None], 3, axis=2)
    elif pixels.ndim == 3 and pixels.shape[2] in (3, 4):
        # Alpha is dropped, matching Pillow RGB conversion for eight-bit inputs.
        pixels = pixels[:, :, :3][:, :, ::-1]
    else:
        raise ValueError("Unsupported 16-bit channel layout.")
    # OpenCV's TIFF decoder applies the TIFF orientation tag itself, including
    # IMREAD_UNCHANGED. PNG EXIF is not applied in that mode. Do not rotate TIFF
    # twice; the regression fixtures exercise every orientation for both.
    return NativeImage(pixels if is_tiff else _oriented(pixels, orientation))


def decoded_identity_bytes(image):
    # Preserve historical eight-bit identities so existing manifests stay valid.
    prefix = b"uint16-rgb-le:" if isinstance(image, NativeImage) else b""
    return prefix + str(image.size).encode() + image.tobytes()


def display_image(image):
    """An explicitly display-only 8-bit representation, never a training input."""
    if not isinstance(image, NativeImage):
        return image
    scale = 255.0 if image.normalized else 255.0 / 65535.0
    return Image.fromarray(np.clip(np.rint(image.pixels * scale), 0, 255).astype(np.uint8))


def display_statistics(image):
    """Native pixel levels for the viewer, before eight-bit display conversion."""
    pixels = image.pixels if isinstance(image, NativeImage) else np.asarray(image)
    return {"min": float(pixels.min()), "max": float(pixels.max()),
            "range_max": 65535 if isinstance(image, NativeImage) and not image.normalized else 255,
            "bit_depth": 16 if isinstance(image, NativeImage) and not image.normalized else 8,
            "width": image.width, "height": image.height}


def window_display(image, black="min", white="max"):
    """Display-only clipping/stretch from native pixels; never used for inference."""
    pixels = image.pixels if isinstance(image, NativeImage) else np.asarray(image)
    stats = display_statistics(image)
    low = stats["min"] if black == "min" else float(black)
    high = stats["max"] if white == "max" else float(white)
    if not math.isfinite(low) or not math.isfinite(high) or not 0 <= low <= high <= stats["range_max"]:
        raise ValueError(f"Display limits require 0 <= low < high <= {stats['range_max']}.")
    if low == high:
        if black not in ("min", "0", 0) or white != "max" or stats["min"] != stats["max"]:
            raise ValueError("Display upper limit must be greater than the lower limit.")
        output = np.zeros(pixels.shape, dtype=np.uint8)
    else:
        output = np.clip(np.rint((pixels.astype(np.float64) - low) / (high - low) * 255.0), 0, 255).astype(np.uint8)
    return Image.fromarray(output)


def prepare_native_image(image, cfg):
    """Fixed float32 scaling then optional explicit fit or native-pixel padding."""
    levels = intensity_settings(cfg)
    size = cfg.get("image_size")
    mode = cfg.get("resize", "pad")
    if isinstance(size, bool) or not isinstance(size, int) or size < 32 or mode not in ("pad", "fit"):
        raise ValueError("Unsupported input geometry policy; resolve image_size >=32 and choose pad or fit.")
    if cfg.get("preserve_native_resolution", False) and mode != "pad":
        raise ValueError("Native resolution preservation requires resize=pad.")
    pixels = image.pixels.astype(np.float32)
    if not image.normalized:
        pixels = ((pixels - np.float32(levels["uint16_black_level"])) /
                  np.float32(levels["uint16_white_level"] - levels["uint16_black_level"]))
    if mode == "fit":
        scale = size / max(image.size)
        dimensions = (max(1, round(image.width * scale)), max(1, round(image.height * scale)))
        # Per-channel Pillow float32 bilinear uses the same spatial convention
        # as eight-bit fit, without converting intensities to eight bits.
        pixels = np.stack([np.asarray(Image.fromarray(pixels[:, :, c]).resize(
            dimensions, Image.Resampling.BILINEAR), dtype=np.float32) for c in range(3)], axis=2)
    elif max(image.size) > size:
        raise ValueError(f"Image {image.size} exceeds image_size={size}; no implicit resizing is permitted.")
    height, width = pixels.shape[:2]
    output = np.empty((size, size, 3), dtype=np.float32)
    output[:] = np.asarray(cfg.get("padding_rgb", [124, 116, 104]), dtype=np.float32) / np.float32(255)
    top, left = (size - height) // 2, (size - width) // 2
    output[top:top+height, left:left+width] = pixels
    return NativeImage(output, normalized=True)


def normalized_chw(image, mean, std):
    """Already-prepared pixels to a contiguous normalized float32 CHW tensor."""
    pixels = np.asarray(image, dtype=np.float32)
    if not isinstance(image, NativeImage):
        pixels = pixels / np.float32(255)
    elif not image.normalized:
        raise ValueError("Call prepare_image before tensor conversion of native-depth input.")
    mean = np.asarray(mean, dtype=np.float32)[:, None, None]
    std = np.asarray(std, dtype=np.float32)[:, None, None]
    if mean.shape != (3, 1, 1) or std.shape != (3, 1, 1) or not np.isfinite(mean).all() or not np.isfinite(std).all() or np.any(std <= 0):
        raise ValueError("Invalid normalization specification.")
    return np.ascontiguousarray((pixels.transpose(2, 0, 1) - mean) / std, dtype=np.float32)
