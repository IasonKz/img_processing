"use strict";
// Descriptive chart contracts. No synthetic score is substituted for missing data.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const {context,document,el,emit,settle}=require('./test_v4_ui.cjs');
async function main(){
 await settle();
 vm.runInContext(fs.readFileSync(path.join(__dirname,'../nilt/ui/analytics.js'),'utf8'),context,{filename:'analytics.js'});
 const metric={pr_auc_bad:.8,balanced_accuracy:.85,bad_escape_rate:.1,good_reject_rate:.2,bad_detected_TP:9,bad_passed_as_good_FN:1,good_rejected_as_bad_FP:4,good_accepted_TN:16};
 const data={path:'sample',trials:[
  {model:'resnet18',trial:'0',state:'COMPLETE',value:'.6',seconds:'120',objective:'validation_ap',params_json:'{"learning_rate":0.0001,"optimizer":"adamw","weight_decay":0.01}'},
  {model:'resnet18',trial:'1',state:'COMPLETE',value:'.8',seconds:'180',objective:'validation_ap',params_json:'{"learning_rate":0.001,"optimizer":"sgd","weight_decay":0.05}'},
  {model:'efficientnet_b0',trial:'0',state:'COMPLETE',value:'.9',seconds:'240',objective:'validation_ap',params_json:'{"learning_rate":0.0003,"optimizer":"adamw","weight_decay":0.02}'},
  {model:'resnet18',trial:'2',state:'FAIL',outcome:'TIMEOUT_RESUMABLE',value:null,seconds:300,params_json:'broken'},
  {model:'resnet18',trial:'3',state:'COMPLETE',value:'',seconds:300,params_json:'{}'},
  {model:'resnet18',trial:'4',state:'COMPLETE',value:null,seconds:300,params_json:'{}'},
  {model:'resnet18',trial:'5',state:'COMPLETE',value:'.95',seconds:150,objective:'validation_roc_auc',params_json:'{"learning_rate":0.001}'},
 ],histories:[{name:'search/resnet18/trial_00000',history:[{epoch:1,val_pr_auc_bad:.4},{epoch:2,val_pr_auc_bad:''},{epoch:3,val_pr_auc_bad:null},{epoch:4,val_pr_auc_bad:.6}]}],candidates:[{name:'resnet18<script>',selection_metrics:metric},{name:'empty class',selection_metrics:{...metric,pr_auc_bad:null,bad_detected_TP:0,bad_passed_as_good_FN:0}}]};
 context.analyticsData=data;vm.runInContext('Analytics.render(analyticsData)',context);
 for(const id of ['search-history-chart','search-efficiency-chart','search-learning-chart','search-parameter-chart','search-parallel-chart'])assert.equal(el(id).tag,'svg',id+' must be an SVG element');
 assert.equal(el('search-efficiency-chart').querySelectorAll('circle').length,3,'only valid completed objective values');
 assert.equal(el('search-parameter-chart').querySelectorAll('circle').length,3,'actual recorded parameters');
 assert.equal(el('search-history-chart').querySelectorAll('polyline').length,2,'architecture comparisons');
 assert.equal(el('search-learning-chart').querySelectorAll('polyline')[0].attributes.points.trim().split(' ').length,2,'missing AP values are not zero');
 assert.equal(el('search-parallel-chart').querySelectorAll('polyline').length,3);
 assert.ok(el('analytics-search').innerHTML.includes('<strong>1</strong><span>TIMEOUT</span>'));
 assert.ok(el('analytics-compare').innerHTML.includes('90.0% of true bad'));
 assert.ok(el('analytics-compare').innerHTML.includes('No reference images'));
 assert.ok(el('analytics-compare').innerHTML.includes('resnet18&lt;script&gt;'));
 assert.equal(el('model-confusions').querySelectorAll('script').length,0);
 assert.ok(el('analytics-compare').innerHTML.includes('Not available'));
 assert.equal(/NaN|Infinity/.test(el('analytics-search').innerHTML),false);
 el('analytics-model').value='resnet18';await emit(el('analytics-model'),'change');
 assert.equal(el('search-efficiency-chart').querySelectorAll('circle').length,2);
 el('analytics-parameter').value='optimizer';await emit(el('analytics-parameter'),'change');
 assert.equal(el('analytics-log').disabled,true,'categorical parameters cannot be plotted logarithmically');
 el('analytics-objective').value='validation_roc_auc';await emit(el('analytics-objective'),'change');
 assert.equal(el('search-efficiency-chart').querySelectorAll('circle').length,1,'objectives are not mixed');
 vm.runInContext('Analytics.render(analyticsData)',context);
 assert.equal(el('analytics-objective').value,'validation_roc_auc','filters survive polling');
 context.analyticsData={path:'empty',trials:[],histories:[],candidates:[]};vm.runInContext('Analytics.render(analyticsData)',context);
 assert.equal(el('search-efficiency-chart').querySelectorAll('circle').length,0);
 assert.ok(el('analytics-compare').innerHTML.includes('Completed and evaluated candidates'));
 console.log('PASS: analytics SVG rendering, real trial parameters, objective and architecture filters, missing-score handling, categorical axes, timeout status, confusion denominators, escaping and empty states.');
}
main().catch(error=>{console.error(error);process.exitCode=1;});
