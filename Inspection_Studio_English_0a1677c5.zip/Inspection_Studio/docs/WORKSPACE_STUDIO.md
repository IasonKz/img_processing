# Classification, Segmentation and ROI Detection workspaces

Start the local dashboard with `Start.cmd` on Windows or `python inspection.py dashboard --config project.yaml` from the activated Linux environment. Model experiments, annotations and deployment are accessible from the GUI.

Choose **Classification**, **Segmentation** or **ROI Detection** above the sidebar navigation. Classification exposes VIG/TOP/BOTTOM and a Whole image / ROI scope selector. Segmentation exposes TOP whole-image defects, TOP/BOTTOM ROI crop defect segmentation, and geometric ROI localizer training. ROI Detection exposes geometry setup, localization, review, crop datasets and the shared crop annotation editor. **Preprocessing / Data processing** remains available. Development and Deployment are separate classification views. See [the ROI workflow](ROI_WORKFLOW.md) for the new dataset route.

The dashboard starts in navy / black **Night mode**. The **Light mode / Night mode** button changes the whole workspace, including TOP/BOTTOM and annotation, and remembers the choice in this browser. The cropped NIL Technology logo is shared across tasks.

In **Preprocessing / Data processing**, select **Untagged tester folder → classification** to prepare incoming tester captures without CSVs or good/bad tags. The copies go directly into `top/`, `bottom/` and `vig/`; failed originals and overlays stay in sibling folders. Choose a completed task and **Use prepared images → classify** to fill its Whole image classification input without replacing training data. See [preprocessing](DASHBOARD_PREPROCESSING.md) for stage selection and pixel settings.

## Data cleaning and tray membership

Open a dataset containing `good/` and `bad/` in **Data cleaning**. Click an image, use Left/Right to navigate, then choose **Good**, **Bad**, **Review**, or **Unsuitable**. This moves the actual file into the corresponding class folder, preserving its tray subdirectories. A destination collision gets a unique suffix and never replaces an existing capture. Review and unsuitable are quarantine folders, not training labels. **Undo** reverses the latest recorded move; a changed image or occupied original path is refused. Moves are journalled in `.nilt-cleaning/moves.jsonl`.

Dataset editing is blocked while an owned worker uses data. If an image changes after opening, reload it before changing its label. Re-audit and start a new experiment after editing labels; existing experiment manifests and results remain immutable.

In **Dataset & setup**, load the trays and save their roles:

| Role | Development splits | Classification / explicit tuning |
| --- | --- | --- |
| Development (default) | Train, validation, calibration/threshold, selection and final test | Not automatically classified; may be explicitly added to tuning |
| Classification only | None | Use the classification button or add these trays to threshold tuning |
| Excluded | None | Omitted when the configured dataset is used |

New audits/searches use the saved roles. Roles do not retroactively remove images from old trained models. Tray names use the capture filename's physical tray ID (`C00000083` → `C83`); nested folders are a fallback for other filenames. Independent incoming folders are classified normally. To classify the configured project dataset, save classification-only trays first: the GUI uses the current project configuration rather than the model's older configuration snapshot.

## Threshold tuning

Select a finalized experiment and candidate, add one or more manually cleaned `good/bad` datasets, and optionally specify tray names. Supplied labels are trusted: this operation does not rerun cleanliness checks. Each dataset is scored once. A pooled, image-weighted objective selects thresholds, with a separate per-dataset/per-tray breakdown. Adding a dataset twice counts it twice.

The score increases towards **bad**. FP means a good image rejected as bad; FN means a bad image accepted as good. This definition is printed in the GUI; choose the corresponding goal for the inspection policy.

For a single threshold, scores at or above the threshold are bad. For two thresholds, scores below the lower threshold are good, scores at or above the upper threshold are bad, and the middle band is review. Equal scores stay together. Every attainable score boundary, including all-good/all-bad decisions, is covered. Exact prefix optimization evaluates the optimum across all attainable pairs without allocating a quadratic matrix; it is not a coarse fixed-step sweep.

| Goal | Selection order |
| --- | --- |
| Minimum FP | FP, then FN, then review |
| Minimum FN | FN, then FP, then review |
| Minimum mistakes | FP + FN, then review; remaining ties prefer fewer FP |
| FP / FN weighted tradeoff | `FP weight × FP / all good + FN weight × FN / all bad + review weight × review / all images` |

The weighted option is a penalty tradeoff, not division by the number of FN. Defaults give mistakes much greater cost than review. The maximum review fraction is a hard constraint. With two thresholds, sending many images for review may be necessary to minimize errors. It is displayed separately from automated accuracy.

Results include the single-threshold FP/FN chart, best pairs, counts, full CSVs and JSON. Very large curves are sampled for display only; optimization and exported results retain every boundary. **Save best threshold as a new decision** creates a separate frozen version. Operator tuning is exploratory evidence on the supplied datasets, not an independent qualification claim; development path overlap is recorded.

## Image review

After classification, open an image in **Image review**. Left/Right and the visible previous/next buttons navigate the filtered gallery, including adjacent pages. Keys retain their normal editing behavior inside text fields. Per-model/stage cards show score, lower/upper thresholds and the score's distance from the bad threshold. Supervised scores are uncalibrated softmax outputs; anomaly distances use their own scale.

## VIG deployment

Develop and save a decision, multi-model Decision Lab system or ordered workflow first. In **Deployment**, select it and **Freeze pipeline**. The pipeline records the exact decision/source hash and checkpoint identities. Editing the frozen source is detected at execution; create a new version for a changed recipe. Scores-only decisions cannot produce a deployment classifier.

Supply an image folder or ZIP and run on CPU/CUDA. The new run folder contains `good/`, `bad/`, `review/`, `images.csv`, and a short `report.html`/`report.json` with date, input, model identities, thresholds and counts. Original capture filenames are preserved; collisions receive a suffix. Invalid inputs are recorded as unavailable, never automatically accepted. ZIP traversal and image symlinks are refused. Deployment reads the input and creates new outputs. Detailed stage evidence is retained in the underlying inspection session.

## Whole-image TOP and shared ROI segmentation

The integrated **Top Segmentation Studio v2** is retained under **Segmentation → TOP** and `segmentation/top/`. Its imported queue, annotations, model search, results and exports retain their existing behavior. **Project & images → Import images**, then **Annotation**, opens the existing brush/polygon editor. Full screen, theme propagation and drafts are retained. Earlier BOTTOM segmentation folders are not deleted; the new GUI limits this whole-image defect workflow to TOP.

This existing studio reads 8-bit RGB. Its original guide is retained in [segmentation/UPSTREAM_README.md](segmentation/UPSTREAM_README.md).

**ROI Detection → TOP/BOTTOM** uses a separate `roi_detection/` project store and segmentation model. It generates independent masks for nested ROIs, keeps physical-unit splits, and exports reviewed crops without copying image-level labels onto them. **Use in Classification** selects the exported ROI scope and its existing classifier training backend. The **Crop annotations** step opens the same crop defect annotation project as **Segmentation → ROI crops · defects**, with native uint8/uint16 copies and original physical-unit splits. **Segmentation → ROI localization · geometry masks** owns localizer training and evaluation, with a checkpoint handoff back to ROI Detection. BOTTOM has only ROI targets. Read [ROI_SEGMENTATION.md](ROI_SEGMENTATION.md) for the shared annotation and training workflow.

A combined production verdict across every ROI and whole-image defect model requires an explicit deployed recipe and representative validation; training and crop datasets alone do not qualify that verdict.

## Native folder selection and worker stop

**Browse…** launches the local Python machine's native Tk folder/file chooser. Windows 11 with the standard Python installer includes Tk. Arch requires `tk` and a desktop display; a headless/remote cloud server cannot display a chooser on a remote operator workstation. Manual paths remain available. Output selection can create a new folder from the chooser.

**Stop worker now** is global and stops only recorded, verified application workers and their owned child processes. It also recovers segmentation workers after a dashboard restart. It force-stops a stuck operation without closing the dashboard. Already committed files/checkpoints remain; an in-progress batch or annotation export may be incomplete. Inspect the log and start a new operation. The existing Pause/Cancel search controls remain available for saving at safe training boundaries.

## Update an existing installation

```powershell
git pull --ff-only
.\.venv-studio6\Scripts\python.exe -m pip install -r requirements-segmentation.txt
.\Start.cmd
```

```bash
git pull --ff-only
source .venv-studio6/bin/activate
python -m pip install -r requirements-segmentation.txt
# Arch desktop, if Tk is missing: sudo pacman -S tk
python inspection.py dashboard --config project.yaml
```

Use the installation's virtual environment name if it differs. New Windows installations include segmentation dependencies through Setup.cmd. CPU/CUDA selection must still match the machine's installed PyTorch build.
