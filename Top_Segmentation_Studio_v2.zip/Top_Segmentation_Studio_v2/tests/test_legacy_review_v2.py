"""Reviewed v1 proposal footprints remain human annotations after upgrading."""
from unittest.mock import patch

import numpy as np
import pytest

import test_server
from topseg.annotations import encode_rle
from topseg.common import atomic_json, read_json


@pytest.fixture
def api():
    fixture = test_server.AnnotationHTTPTests()
    fixture.setUp()
    try:
        yield fixture
    finally:
        fixture.tearDown()


def v1_reviewed_record(api):
    project = api.server.project
    record = project.open_image(api.image_id)
    footprint = np.zeros((48, 64), np.uint8)
    footprint[22:25, 30:34] = 1
    obj = {'id': 'proposal-reviewed', 'name': 'My reviewed defect', 'kind': 'proposal',
           'visible': False, 'mask_rle': encode_rle(footprint)}
    record = project.save_annotation(api.image_id, footprint, expected_revision=record['revision'],
                                     roi=record['roi'], objects=[obj], notes='Reviewed in v1')
    annotation_path = project.root / 'annotations' / f'{api.image_id}.json'
    legacy = read_json(annotation_path)
    legacy.pop('manual_edits')
    legacy.pop('automation')
    history_path = project.root / legacy['mask']
    history_path = history_path.parent / 'annotation.json'
    atomic_json(annotation_path, legacy)
    atomic_json(history_path, legacy)
    return legacy, obj, footprint, annotation_path, history_path


def test_open_migrates_reviewed_objects_response_only(api):
    legacy, obj, footprint, path, history = v1_reviewed_record(api)
    saved_bytes, history_bytes = path.read_bytes(), history.read_bytes()
    migrated = api.server.project.open_image(api.image_id)
    assert migrated['objects'] == [{**obj, 'kind': 'legacy'}]
    assert migrated['manual_edits'] == {'erase_rle': [[0, 3072]]}
    assert path.read_bytes() == saved_bytes
    assert history.read_bytes() == history_bytes
    assert migrated['revision'] == legacy['revision']


def test_regeneration_retains_v1_review_without_explicit_discard(api):
    legacy, obj, footprint, path, history = v1_reviewed_record(api)
    project = api.server.project
    # The new detector misses the defect. A reviewed v1 footprint still survives
    # unless the user explicitly requests discarding manual edits.
    with patch.object(project, '_automatic_mask', return_value=(np.zeros_like(footprint), {'method': 'basic'})):
        result = project.propose(api.image_id, expected_revision=legacy['revision'])
        assert result['objects'] == [{**obj, 'kind': 'legacy'}]
        assert result['notes'] == 'Reviewed in v1'
        result = project.propose(api.image_id, expected_revision=result['revision'], keep_manual_edits=False)
        assert result['objects'] == []


def test_status_change_cannot_erase_v1_migration_marker(api):
    legacy, obj, footprint, path, history = v1_reviewed_record(api)
    project = api.server.project
    rejected = project.set_rejected(api.image_id, True, legacy['revision'], reason='Review later')
    assert rejected['objects'] == [{**obj, 'kind': 'legacy'}]
    restored = project.set_rejected(api.image_id, False, rejected['revision'])
    assert restored['objects'] == [{**obj, 'kind': 'legacy'}]


def test_unreviewed_v1_candidates_stay_replaceable(api):
    legacy, obj, footprint, path, history = v1_reviewed_record(api)
    legacy['origin'] = 'classical'
    atomic_json(path, legacy)
    opened = api.server.project.open_image(api.image_id)
    assert opened['objects'] == [obj]


def test_new_v2_proposals_remain_replaceable_after_manual_save(api):
    legacy, obj, footprint, path, history = v1_reviewed_record(api)
    legacy['manual_edits'] = {'erase_rle': [[0, 3072]]}
    atomic_json(path, legacy)
    assert api.server.project.open_image(api.image_id)['objects'] == [obj]
