"""Safety and numerical regression checks for native-resolution VIG training."""
import copy
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np
from PIL import Image

from nilt.common import DEFAULTS, PROFILES, merge_dict, read_json, sha_file, validate_config
from nilt.data import audit, allocate, make_manifest, tray_unit_identity
from nilt.preprocessing import prepare_image, rotate_quarter_turn


class NativeDataTests(unittest.TestCase):
    def test_all_quarter_turns_preserve_rectangle_pixels_and_corners(self):
        original = np.arange(7 * 11 * 3, dtype=np.uint8).reshape(7, 11, 3)
        for k in range(4):
            with self.subTest(k=k):
                rotated = rotate_quarter_turn(Image.fromarray(original), k)
                expected = np.rot90(original, k)
                np.testing.assert_array_equal(np.asarray(rotated), expected)
                padded = np.asarray(prepare_image(rotated, {"image_size": 32, "resize": "pad"}))
                h, w = expected.shape[:2]
                top, left = (32 - h) // 2, (32 - w) // 2
                np.testing.assert_array_equal(padded[top:top+h, left:left+w], expected)

    def test_16bit_rgb_png_is_rejected_before_pillow_silently_truncates(self):
        import struct
        import zlib
        from nilt.data import load_rgb as training_load
        from nilt.runtime import load_rgb as runtime_load
        def chunk(kind, data):
            return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xffffffff)
        raw = (b"\x89PNG\r\n\x1a\n"
               + chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 16, 2, 0, 0, 0))
               + chunk(b"IDAT", zlib.compress(b"\x00" + struct.pack(">HHH", 32769, 65535, 1)))
               + chunk(b"IEND", b""))
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "rgb16.png"
            path.write_bytes(raw)
            with Image.open(path) as image:
                self.assertEqual(image.mode, "RGB")
                self.assertEqual(image.getpixel((0, 0)), (128, 255, 0))
            for reader in (training_load, runtime_load):
                with self.assertRaisesRegex(ValueError, "16-bit PNG"):
                    reader(path)
            original = np.arange(7 * 11 * 3, dtype=np.uint8).reshape(7, 11, 3)
            for extension in ("png", "bmp"):
                supported = Path(tmp) / f"rgb8.{extension}"
                Image.fromarray(original).save(supported)
                for reader in (training_load, runtime_load):
                    np.testing.assert_array_equal(np.asarray(reader(supported)), original)

    def test_tray_unit_key_ignores_view_time_and_zero_padding(self):
        a = tray_unit_identity("C0000083_Rc09_Cc17_FlatField_20260101T105522.png")
        b = tray_unit_identity("C00000083_Rc009Cc017_other_20260901T000001.bmp")
        self.assertEqual(a, b)
        self.assertNotEqual(a, tray_unit_identity("C0000084_Rc09Cc17_vig.png"))
        for invalid in ("C83_flat.png", "C83_Rc09_other.png", "C83_Rc09Cc17_Rc03.png"):
            with self.assertRaises(ValueError):
                tray_unit_identity(invalid)

    def test_mixed_views_of_unit_stay_together_but_exact_conflicts_fail(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            rng = np.random.default_rng(5)
            for label in ("good", "bad"):
                (root / "data" / label).mkdir(parents=True)
                for i in range(10):
                    Image.fromarray(rng.integers(0, 255, (9, 13, 3), dtype=np.uint8)).save(
                        root / "data" / label / f"C0000083_Rc01Cc{i:02d}_{label}.png")
            cfg = {"task": "vig", "data_root": str(root / "data"), "grouping": "tray_unit",
                   "image_size": "auto", "resize": "pad", "near_duplicate_distance": -1}
            rows = audit(cfg, root / "audit")
            allocation = allocate(rows, DEFAULTS["split_fractions"], 42)
            self.assertEqual(len(allocation), 20)
            for group in {r["group"] for r in allocation}:
                self.assertEqual(len({r["split"] for r in allocation if r["group"] == group}), 1)
            self.assertEqual(read_json(root / "audit" / "audit_summary.json")["n_groups"], 10)
            cfg.update(split_fractions=DEFAULTS["split_fractions"], split_seed=42)
            make_manifest(cfg, rows, root / "run")
            summary = read_json(root / "run" / "split_summary.json")
            self.assertTrue((root / "run" / "tray_split_summary.csv").is_file())
            self.assertEqual(sum(summary[s]["trays"]["C83"]["images"]["bad"] for s in DEFAULTS["split_fractions"]), 10)
            # Label differences between views are allowed, identical pixels are not.
            source = root / "data" / "good" / "C0000083_Rc01Cc00_good.png"
            Image.open(source).save(root / "data" / "bad" / "C0000083_Rc01Cc00_copy.bmp")
            with self.assertRaisesRegex(ValueError, "Identical decoded"):
                audit(cfg, root / "conflict")

    def test_invalid_tray_filename_never_falls_back_to_independent_hash(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for label, color in (("good", 20), ("bad", 80)):
                (root / label).mkdir()
                Image.new("RGB", (32, 32), (color, 0, 0)).save(root / label / "unknown.png")
            with self.assertRaisesRegex(ValueError, "invalid images or mappings"):
                audit({"data_root": str(root), "grouping": "tray_unit"}, root / "audit")

    def test_native_guard_and_budget_profiles(self):
        for profile, seconds in (("laptop", 7200), ("workstation", 21600), ("workstation_large", 43200)):
            self.assertEqual(PROFILES[profile]["budget_seconds"], seconds)
            self.assertEqual(PROFILES[profile]["search"]["total_budget_seconds"], seconds)
        cfg = merge_dict(DEFAULTS, {"task": "vig", "data_root": "/data", "output_root": "/results"})
        cfg["resize"] = "fit"
        with self.assertRaisesRegex(ValueError, "preserve_native_resolution"):
            validate_config(cfg)
        cfg["resize"] = "pad"
        cfg["augmentation"]["brightness"] = .01
        with self.assertRaisesRegex(ValueError, "quarter-turn"):
            validate_config(cfg)

    def test_native_patch_model_canvas_keeps_401_pixel_edges_in_complete_patches(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            rng = np.random.default_rng(91)
            images = {}
            for label in ("good", "bad"):
                (root / "data" / label).mkdir(parents=True)
                arr = rng.integers(0, 256, (177, 401, 3), dtype=np.uint8)
                path = root / "data" / label / "one.png"
                Image.fromarray(arr).save(path)
                images[path] = arr
            cfg = {"data_root": str(root / "data"), "models": ["resnet18", "swin_t"],
                   "image_size": "auto", "resize": "pad", "preserve_native_resolution": True,
                   "near_duplicate_distance": -1}
            audit(cfg, root / "audit")
            self.assertEqual(cfg["image_size"], 416)
            self.assertEqual(cfg["canvas_alignment"], 32)
            self.assertEqual(cfg["image_size"] % 32, 0)
            for path, original in images.items():
                with Image.open(path) as image:
                    for k in range(4):
                        rotated = rotate_quarter_turn(image, k)
                        expected = np.rot90(original, k)
                        padded = np.asarray(prepare_image(rotated, cfg))
                        h, w = expected.shape[:2]
                        top, left = (416 - h) // 2, (416 - w) // 2
                        np.testing.assert_array_equal(padded[top:top+h, left:left+w], expected)
            legacy = {**cfg, "image_size": "auto", "preserve_native_resolution": False}
            audit(legacy, root / "legacy")
            self.assertEqual(legacy["image_size"], 401)


class TorchTrainingTests(unittest.TestCase):
    @staticmethod
    def fixture(root):
        rng = np.random.default_rng(31)
        rows = []
        for i in range(12):
            path = root / f"{i}.png"
            Image.fromarray(rng.integers(0, 255, (32, 32, 3), dtype=np.uint8)).save(path)
            rows.append({"path": str(path), "relative_path": path.name,
                         "label": 0 if i in (0, 2, 8, 10) else 1,
                         "pixel_hash": sha_file(path), "group": str(i), "split": "train" if i < 8 else "val"})
        cfg = merge_dict(DEFAULTS, {"task": "vig", "image_size": 32, "pretrained": False,
                    "device": "cpu", "cpu_threads": 1, "num_workers": 0,
                    "training": {"epochs": 2, "warmup_epochs": 0, "patience": 5,
                        "batch_size": 1, "eval_batch_size": 2, "accumulation_steps": 4,
                        "learning_rate": .001, "head_learning_rate": .002, "weight_decay": 0.,
                        "optimizer": "sgd", "momentum": 0., "scheduler": "constant",
                        "amp": False, "imbalance": "weighted_loss", "telemetry_every": 2}})
        return rows, cfg

    @staticmethod
    def tiny_model(*args, **kwargs):
        import torch
        model = torch.nn.Sequential(torch.nn.Conv2d(3, 4, 3, padding=1), torch.nn.ReLU(),
                                    torch.nn.AdaptiveAvgPool2d(1), torch.nn.Flatten(), torch.nn.Linear(4, 2))
        return model, model[-1]

    def test_weighted_microbatch_gradient_matches_full_effective_batch(self):
        import torch
        from nilt import engine
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            rows, cfg = self.fixture(root)
            cfg["training"]["epochs"] = 1
            other = copy.deepcopy(cfg)
            other["training"].update(batch_size=4, accumulation_steps=1)
            with patch.object(engine, "make_model", self.tiny_model):
                a = engine.train_one("resnet18", 7, rows, cfg, root / "micro")
                b = engine.train_one("resnet18", 7, rows, other, root / "full")
            a, b = torch.load(a, weights_only=True), torch.load(b, weights_only=True)
            for key in a["state_dict"]:
                torch.testing.assert_close(a["state_dict"][key], b["state_dict"][key], rtol=1e-6, atol=1e-7)

    def test_callback_runs_after_checkpoint_and_stop_never_marks_completed(self):
        import torch
        from nilt import engine
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            rows, cfg = self.fixture(root)
            out = root / "paused"
            committed = []

            def callback(progress):
                self.assertTrue((out / "best.pt").is_file())
                state = torch.load(out / "last.pt", weights_only=True)
                self.assertEqual(state["epoch"], progress["epoch"])
                self.assertFalse((out / "completed.json").exists())
                committed.append(progress["epoch"])

            with patch.object(engine, "make_model", self.tiny_model):
                with self.assertRaisesRegex(engine.TrainingStopped, "budget"):
                    engine.train_one("resnet18", 7, rows, cfg, out, progress_callback=callback,
                                     stop_check=lambda: "budget" if committed else False)
                self.assertEqual(committed, [1])
                self.assertFalse((out / "completed.json").exists())
                resumed = engine.train_one("resnet18", 7, rows, cfg, out)
                direct = engine.train_one("resnet18", 7, rows, cfg, root / "direct")
            a, b = torch.load(resumed, weights_only=True), torch.load(direct, weights_only=True)
            for key in a["state_dict"]:
                torch.testing.assert_close(a["state_dict"][key], b["state_dict"][key], rtol=0, atol=0)
            self.assertTrue((out / "telemetry.csv").exists())

    def test_head_only_fixes_backbone_and_inference_uses_checkpoint_canvas(self):
        import torch
        from nilt import engine
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            rows, cfg = self.fixture(root)
            cfg["training"].update(mode="head_only", epochs=1)
            engine.seed_everything(17)
            initial, _ = self.tiny_model()
            with patch.object(engine, "make_model", self.tiny_model):
                trained = engine.train_one("resnet18", 17, rows, cfg, root / "head")
                state = torch.load(trained, weights_only=True)
                for key in ("0.weight", "0.bias"):
                    torch.testing.assert_close(initial.state_dict()[key], state["state_dict"][key], rtol=0, atol=0)
                self.assertFalse(torch.equal(initial[-1].weight, state["state_dict"]["4.weight"]))
                changed = copy.deepcopy(cfg)
                changed["image_size"] = 64
                a, _ = engine.predict_checkpoint(trained, rows, cfg)
                b, _ = engine.predict_checkpoint(trained, rows, changed)
                np.testing.assert_array_equal(a, b)

    def test_stage_and_plateau_scheduler_are_real_torch_objects(self):
        import torch
        from nilt import engine
        model, head = engine.make_model("resnet18")
        status = engine.configure_training_stage(model, head, "resnet18", {"mode": "last_block", "warmup_epochs": 1}, 1)
        self.assertEqual(status["finetune_epochs"], 1)
        self.assertFalse(model.layer3[0].conv1.weight.requires_grad)
        self.assertTrue(model.layer4[0].conv1.weight.requires_grad)
        self.assertTrue(model.fc.weight.requires_grad)
        self.assertFalse(model.layer4[0].bn1.training)
        settings = copy.deepcopy(DEFAULTS["training"])
        settings.update(scheduler="plateau", scheduler_patience=0, scheduler_factor=.5)
        optimizer, scheduler = engine.make_optimizer_scheduler(list(model.layer4.parameters()), head, settings)
        initial_lr = optimizer.param_groups[0]["lr"]
        scheduler.step(.7)
        scheduler.step(.6)
        self.assertEqual(optimizer.param_groups[0]["lr"], initial_lr * .5)

    def test_patience_waits_for_required_finetuning_phase(self):
        import torch
        from nilt import engine
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            rows, cfg = self.fixture(root)
            cfg["training"].update(epochs=8, warmup_epochs=2, patience=1, min_finetune_epochs=2)
            def constant_validation(model, data, config, device, stop_check=None):
                return np.full(len(data), .5), torch.zeros((len(data), 2)), 0.
            progress = []
            with patch.object(engine, "make_model", self.tiny_model), patch.object(engine, "predict_model", constant_validation):
                engine.train_one("resnet18", 17, rows, cfg, root / "phase", progress_callback=progress.append)
            self.assertEqual([p["finetune_epochs"] for p in progress], [0, 0, 1, 2])
            self.assertEqual(read_json(root / "phase" / "completed.json")["epochs_ran"], 4)

    def test_validation_never_applies_random_rotation_and_distance_stop_is_checked(self):
        import torch
        from nilt.engine import Transform, TrainingStopped
        from nilt.patchcore import nearest_distances
        cfg = {"image_size": 32, "augmentation": {"rotation90": True}}
        transform = Transform(cfg, training=False)
        with patch("nilt.engine.random.randrange", side_effect=AssertionError("validation rotated")):
            transform(Image.new("RGB", (17, 13)))
        with self.assertRaises(TrainingStopped):
            nearest_distances(torch.ones(2, 3), torch.ones(2, 3), stop_check=lambda: "budget")


if __name__ == "__main__":
    unittest.main()
