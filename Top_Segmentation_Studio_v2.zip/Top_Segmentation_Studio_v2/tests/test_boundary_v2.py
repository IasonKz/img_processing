"""Native-pixel boundary fitting and conservative custom-shape retention."""
import math
import unittest
from unittest.mock import patch

import numpy as np
from scipy import ndimage

from topseg.classical import detect_inner_roi, roi_mask


def polygon(points):
    return {'type': 'polygon', 'points': [{'x': float(x), 'y': float(y)} for x, y in points]}


def lens_points():
    # Independent corner cuts and unequal horizontal/vertical dimensions.
    return np.array([[115, 90], [230, 90], [260, 108], [260, 206],
                     [246, 222], [106, 222], [90, 210], [90, 115]], dtype=float)


def transform(points, angle=0., shift=(0., 0.), scale=1.):
    center = points.mean(axis=0)
    theta = math.radians(angle)
    rotation = np.array([[math.cos(theta), -math.sin(theta)], [math.sin(theta), math.cos(theta)]])
    return scale * ((points - center) @ rotation.T) + center + shift


def scene(points, width=360, height=320, noise=.3):
    mask = roi_mask(polygon(points), width, height)
    values = np.where(mask, 149., 91.)
    values += np.random.default_rng(43).normal(0, noise, values.shape)
    return np.repeat(np.clip(values, 0, 255).astype(np.uint8)[..., None], 3, axis=2), mask


class BoundaryV2Tests(unittest.TestCase):
    def test_auto_finds_non_equilateral_independent_chamfers(self):
        image, expected = scene(lens_points())
        detected, stats = detect_inner_roi(image, polygon(lens_points()), mode='auto')
        self.assertTrue(stats['found'], stats)
        self.assertEqual(len(detected['points']), 8)
        actual = roi_mask(detected, 360, 320)
        self.assertGreater((actual & expected).sum() / (actual | expected).sum(), .96)

    def test_guided_small_shift_rotation_and_scale_preserve_corner_proportions(self):
        prior = lens_points()
        expected_points = transform(prior, angle=3., shift=(5., -4.), scale=1.025)
        image, expected = scene(expected_points)
        detected, stats = detect_inner_roi(image, polygon(prior), mode='guided')
        self.assertTrue(stats['found'], stats)
        actual = roi_mask(detected, 360, 320)
        self.assertGreater((actual & expected).sum() / (actual | expected).sum(), .985)
        output = np.array([[p['x'], p['y']] for p in detected['points']])
        before_lengths = np.linalg.norm(np.roll(prior, -1, axis=0) - prior, axis=1)
        after_lengths = np.linalg.norm(np.roll(output, -1, axis=0) - output, axis=1)
        np.testing.assert_allclose(after_lengths / before_lengths, stats['scale'], atol=.00001)
        self.assertLess(abs(stats['rotation_degrees'] - 3.), .6)
        self.assertTrue(stats['review_required'])

    def test_guided_rings_inside_real_polygon_do_not_move_boundary_to_eye(self):
        prior = lens_points()
        expected_points = transform(prior, angle=-2., shift=(-3., 4.))
        image, expected = scene(expected_points)
        yy, xx = np.mgrid[:320, :360]
        radius = np.hypot(xx + .5 - 175, yy + .5 - 156)
        rings = (radius < 45) & ((radius.astype(int) % 7) < 3)
        image[rings] = 220
        detected, stats = detect_inner_roi(image, polygon(prior), mode='guided')
        self.assertTrue(stats['found'], stats)
        actual = roi_mask(detected, 360, 320)
        self.assertGreater((actual & expected).sum() / (actual | expected).sum(), .985)

    def test_guided_circular_edges_alone_do_not_count_as_straight_sides(self):
        prior = polygon(lens_points())
        yy, xx = np.mgrid[:320, :360]
        radius = np.hypot(xx + .5 - 175, yy + .5 - 156)
        values = np.where((radius < 100) & ((radius.astype(int) % 13) < 5), 185, 95).astype(np.uint8)
        image = np.repeat(values[..., None], 3, axis=2)
        detected, stats = detect_inner_roi(image, prior, mode='guided')
        self.assertFalse(stats['found'], stats)
        self.assertEqual(detected, prior)

    def test_weak_boundary_keeps_exact_saved_coordinates(self):
        prior = polygon(lens_points() + [.1234, .5678])
        image = np.full((320, 360, 3), 110, np.uint8)
        for mode in ('guided', 'auto'):
            with self.subTest(mode=mode):
                detected, stats = detect_inner_roi(image, prior, mode=mode)
                self.assertEqual(detected, prior)
                self.assertFalse(stats['found'])
                self.assertEqual(stats['confidence'], 0)

    def test_native_resolution_large_image_keeps_original_and_fine_outline(self):
        points = lens_points() * 4
        width, height = 1440, 1280
        expected = roi_mask(polygon(points), width, height)
        outline = expected ^ ndimage.binary_erosion(expected, iterations=1)
        values = np.full((height, width), 120, np.uint8)
        values[outline] = 65
        image = np.repeat(values[..., None], 3, axis=2)
        original = image.copy()
        with patch('topseg.classical.ndimage.zoom', side_effect=AssertionError('Images must never be resized')):
            detected, stats = detect_inner_roi(image, polygon(points + [3, -2]), mode='guided')
        self.assertTrue(stats['found'], stats)
        self.assertTrue(stats['native_resolution'])
        self.assertEqual((stats['analysis_width'], stats['analysis_height']), (width, height))
        actual = roi_mask(detected, width, height)
        self.assertGreater((actual & expected).sum() / (actual | expected).sum(), .99)
        np.testing.assert_array_equal(image, original)

    def test_native_auto_never_downsamples(self):
        points = lens_points() * 2
        image, expected = scene(points, 720, 640)
        with patch('topseg.classical.ndimage.zoom', side_effect=AssertionError('Images must never be resized')):
            detected, stats = detect_inner_roi(image, polygon(points), mode='auto')
        self.assertTrue(stats['found'], stats)
        self.assertEqual((stats['analysis_width'], stats['analysis_height']), (720, 640))
        actual = roi_mask(detected, 720, 640)
        self.assertGreater((actual & expected).sum() / (actual | expected).sum(), .98)

    def test_invalid_mode_has_explicit_error(self):
        with self.assertRaisesRegex(ValueError, 'mode'):
            detect_inner_roi(np.zeros((30, 30, 3), np.uint8), mode='unknown')


if __name__ == '__main__':
    unittest.main()
