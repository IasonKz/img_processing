"""Operator workflows: exact optimization, reversible edits and frozen deployment.

Synthetic inputs and mocked neural scores test orchestration, not model quality.
"""
import copy
import json
from pathlib import Path
import random
import tempfile
import unittest
from unittest.mock import patch
import zipfile
from http.server import ThreadingHTTPServer
import re
import threading
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import numpy as np

from nilt.common import read_json, sha_file, write_json
from nilt.dataset_tools import dataset_items, move_image, undo_move, classification_roles
from nilt.threshold_tuning import optimize, counts, options, _key, run_experiment
from nilt.pipeline_deployment import create_pipeline, deploy, load_pipeline, _input
from nilt.decisions import create_decision, _audit_inputs
from test_data_v2 import config, save_image
from test_integration_v2 import fixture_run


class ExactThresholdTests(unittest.TestCase):
    def test_all_objectives_match_exhaustive_pairs_with_ties_and_review_caps(self):
        rng = random.Random(41)
        for size in range(2, 15):
            for repeat in range(6):
                labels = [0, 1] + [rng.randrange(2) for _ in range(size - 2)]
                scores = [rng.randrange(6) / 5 for _ in labels]
                values = sorted(set(scores)) + [np.nextafter(max(scores), np.inf)]
                for mode in ("single", "double"):
                    for goal in ("min_fp", "min_fn", "min_mistakes", "fp_fn_ratio"):
                        for cap in (0, .35, 1):
                            cfg = options({"mode": mode, "goal": goal, "max_review_rate": cap,
                                           "fp_weight": 10, "fn_weight": 3, "review_weight": .17})
                            keys = []
                            for j, high in enumerate(values):
                                for low in values[:j + 1] if mode == "double" else [high]:
                                    row = counts(labels, scores, low, high)
                                    if row["review"] <= int(cap * size + 1e-12):
                                        keys.append(_key(row["fp"], row["fn"], row["review"], row["n_good"], row["n_bad"], size, cfg))
                            best = optimize(labels, scores, cfg)["best"]
                            self.assertEqual(_key(best["fp"], best["fn"], best["review"], best["n_good"], best["n_bad"], size, cfg), min(keys))

    def test_rejects_invalid_scores_and_supports_cancellation(self):
        for labels, scores in (([0], [.1]), ([0, 1], [np.nan, .5]), ([0, 2], [.2, .8]), ([0, 1], [.1])):
            with self.assertRaises(ValueError):
                optimize(labels, scores)
        with self.assertRaises(InterruptedError):
            optimize([0, 1], [.8, .2], stop_check=lambda: True)


class DatasetEditingTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / "dataset"
        self.image = self.root / "good" / "tray" / "capture.png"
        save_image(self.image, 42)
        save_image(self.root / "bad" / "tray" / "capture.png", 43)
        self.digest = sha_file(self.image)

    def test_collision_preserves_images_and_undo_restores_original(self):
        old_bad = sha_file(self.root / "bad" / "tray" / "capture.png")
        result = move_image(self.root, "good/tray/capture.png", "bad", self.digest)
        self.assertNotEqual(result["to"], "bad/tray/capture.png")
        self.assertEqual(sha_file(self.root / "bad" / "tray" / "capture.png"), old_bad)
        self.assertFalse(self.image.exists())
        undo_move(self.root)
        self.assertEqual(sha_file(self.image), self.digest)
        with self.assertRaises(ValueError):
            undo_move(self.root)

    def test_quarantine_chain_can_be_undone_without_deleting(self):
        first = move_image(self.root, "good/tray/capture.png", "review", self.digest)
        move_image(self.root, first["to"], "unsuitable", self.digest)
        self.assertEqual({r["label"] for r in dataset_items(self.root)}, {"bad", "unsuitable"})
        undo_move(self.root)
        undo_move(self.root)
        self.assertTrue(self.image.exists())

    def test_stale_hash_traversal_symlink_and_occupied_undo_are_refused(self):
        with self.assertRaises(ValueError):
            move_image(self.root, "good/tray/capture.png", "bad", "stale")
        with self.assertRaises(ValueError):
            move_image(self.root, "good/../../escape.png", "bad", self.digest)
        outside = Path(self.temp.name) / "outside"
        outside.mkdir()
        (self.root / "review").symlink_to(outside, target_is_directory=True)
        with self.assertRaises(ValueError):
            move_image(self.root, "good/tray/capture.png", "review", self.digest)
        self.assertEqual(list(outside.iterdir()), [])
        result = move_image(self.root, "good/tray/capture.png", "unsuitable", self.digest)
        save_image(self.image, 3)
        with self.assertRaises(ValueError):
            undo_move(self.root)
        self.assertTrue((self.root / result["to"]).exists())

    def test_training_and_classification_use_disjoint_saved_trays(self):
        from nilt.data import audit
        roles = {"C83": "development", "C84": "classification", "C85": "excluded"}
        root = Path(self.temp.name) / "trays"
        for tray in (83, 84, 85):
            for i, label in enumerate(("good", "bad")):
                save_image(root / label / f"C{tray:08d}_Rc01Cc{i+1:02d}.png", tray * 10 + i)
        cfg = {**config(root), "tray_roles": roles}
        rows = audit(cfg, Path(self.temp.name) / "audit")
        self.assertEqual(len(rows), 2)
        self.assertTrue(all("C00000083" in row["relative_path"] for row in rows))
        classified, invalid, _ = _audit_inputs(root, True, {**cfg, "image_size": 32}, tray_roles=roles)
        self.assertEqual(len(classified), 2)
        self.assertTrue(all("C00000084" in row["relative_path"] for row in classified))
        self.assertFalse(invalid)


class FrozenPipelineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.run, self.data, self.rows = fixture_run(self.root, threshold=.5)
        cfg = read_json(self.run / "config.json")
        cfg["task"] = "vig"
        write_json(self.run / "config.json", cfg)
        integrity = read_json(self.run / "integrity.json")
        integrity["config_sha256"] = sha_file(self.run / "config.json")
        write_json(self.run / "integrity.json", integrity)
        chosen = read_json(self.run / "selected.json")
        chosen["task"] = "vig"
        write_json(self.run / "selected.json", chosen)
        write_json(self.run / "selection_integrity.json", {"sha256": sha_file(self.run / "selected.json")})
        write_json(self.run / "candidates.json", [chosen])
        self.decision = create_decision(self.run, mode="triage", good_threshold=.3, bad_threshold=.7,
                                        output_root=self.root / "decisions")

    def test_tuning_scores_each_dataset_once_and_preserves_operator_labels(self):
        source = self.root / "clean"
        # Contradictory pixel labels are deliberate: supplied cleaned labels are trusted.
        save_image(source / "good" / "C00000091_Rc01Cc01.png", 1)
        save_image(source / "bad" / "C00000092_Rc01Cc01.png", 1)
        with patch("nilt.workflow.predict_members", return_value=(np.array([.9, .1]), .01)) as predict:
            report = run_experiment({"run": str(self.run), "datasets": [{"path": str(source)}],
                                     "options": {"mode": "double"}}, self.root / "tuning")
        self.assertEqual(predict.call_count, 1)
        self.assertTrue(report["complete"])
        self.assertEqual(report["best"]["mistakes"], 0)

    def test_deployment_preserves_capture_names_and_brief_model_history(self):
        frozen = self.root / "frozen"
        create_pipeline("Factory check", "decision", self.decision, frozen)
        source = self.root / "incoming"
        for i in range(3):
            save_image(source / f"C00000091_Rc01Cc{i+1:02d}.png", i)
        with patch("nilt.workflow.predict_members", return_value=(np.array([.1, .5, .9]), .01)):
            report = deploy({"pipeline": str(frozen / "pipeline.json"), "input": str(source)}, self.root / "out")
        self.assertEqual(report["counts"], {"good": 1, "bad": 1, "review": 1, "unsuitable": 0})
        for label, i in (("good", 1), ("review", 2), ("bad", 3)):
            self.assertTrue((self.root / "out" / label / f"C00000091_Rc01Cc{i:02d}.png").exists())
        self.assertTrue((self.root / "out" / "report.html").is_file())
        self.assertTrue(report["pipeline"]["models"])
        record = read_json(self.decision)
        record["threshold"] = .8
        write_json(self.decision, record)
        with self.assertRaises(ValueError):
            load_pipeline(frozen)

    def test_scores_only_is_not_a_deployment_classifier(self):
        decision = create_decision(self.run, mode="scores_only", output_root=self.root / "decisions")
        with self.assertRaises(ValueError):
            create_pipeline("Scores", "decision", decision, self.root / "invalid")

    def test_mixed_view_inspection_classifies_only_vig_and_retains_unit_previews(self):
        from nilt.deployment_review import read_index, read_unit
        frozen = self.root / "mixed_frozen"
        create_pipeline("Mixed-view check", "decision", self.decision, frozen)
        source = self.root / "mixed_incoming"
        for view in ("top", "bottom", "vig"):
            for i in range(3):
                save_image(source / view / f"C00000091_Rc01Cc{i+1:02d}_{view}.png", i)
        with patch("nilt.workflow.predict_members", return_value=(np.array([.1, .5, .9]), .01)) as predict:
            report = deploy({"pipeline": str(frozen / "pipeline.json"), "input": str(source)}, self.root / "mixed_out")
        self.assertEqual(predict.call_count, 1)
        self.assertEqual(report['images'], 3)
        self.assertEqual(report['quality_review']['units'], 3)
        _, index = read_index(self.root / 'mixed_out')
        _, unit = read_unit(self.root / 'mixed_out', index['units'][0]['id'])
        self.assertEqual({item['view'] for item in unit['items']}, {'top', 'bottom', 'vig'})
        self.assertTrue(all(item['kind'] == 'image' for item in unit['items'] if item['view'] != 'vig'))
        self.assertEqual(unit['views']['top']['result'], 'not_inspected')
        self.assertEqual(index['counts'], {'review': 2, 'bad': 1})

    def test_zip_traversal_symlinks_and_image_extraction(self):
        for name in ("../escape.png", "/escape.png", "C:/escape.png"):
            archive = self.root / "unsafe.zip"
            with zipfile.ZipFile(archive, "w") as stream:
                stream.writestr(name, b"bad")
            with self.assertRaises(ValueError):
                _input(archive, self.root / "output")
        archive = self.root / "safe.zip"
        with zipfile.ZipFile(archive, "w") as stream:
            stream.writestr("nested/capture.png", b"pixels")
            stream.writestr("readme.txt", "ignore")
        extracted = _input(archive, self.root / "safe_output")
        self.assertEqual((extracted / "nested/capture.png").read_bytes(), b"pixels")
        self.assertFalse((extracted / "readme.txt").exists())


class MountedWorkspaceTests(unittest.TestCase):
    def setUp(self):
        from nilt.dashboard import Dashboard, make_handler
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.config = self.root / "project.yaml"
        self.config.write_text("schema_version: 3\ntasks:\n  vig:\n    dataset_root: ./dataset\n")
        self.app = Dashboard(self.config)
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(self.app))
        self.addCleanup(self.server.server_close)
        self.addCleanup(self.server.shutdown)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        self.base = f"http://127.0.0.1:{self.server.server_port}"

    def request(self, path, data=None, token=None, origin=True):
        headers = {}
        if token:
            headers["X-Session-Token"] = token
        if data is not None:
            headers["Content-Type"] = "application/json"
            if origin:
                headers["Origin"] = self.base
        with urlopen(Request(self.base + path, headers=headers,
                             data=json.dumps(data).encode() if data is not None else None)) as response:
            return response.read()

    def token(self, task):
        html = self.request(f"/segmentation/{task}/").decode()
        self.assertIn(f'/segmentation/{task}/studio.js', html)
        return re.search(r'name="session-token" content="([^"]+)"', html)[1]

    def test_top_mount_csrf_and_bottom_whole_image_refusal(self):
        top = self.token("top")
        for bad_token in (None, 'another-project-token'):
            with self.assertRaises(HTTPError) as error:
                self.request("/segmentation/top/api/studio/state", token=bad_token)
            self.assertEqual(error.exception.code, 403)
        top_state = json.loads(self.request("/segmentation/top/api/studio/state", token=top))
        self.assertEqual(top_state['config']['task'], 'top')
        with self.assertRaises(HTTPError) as error:
            self.token('bottom')
        self.assertEqual(error.exception.code, 400)
        with self.assertRaises(HTTPError) as error:
            self.request("/segmentation/top/api/studio/start", {"action": "import"}, token=top, origin=False)
        self.assertEqual(error.exception.code, 403)

    def test_recovery_loads_both_projects_before_tabs_are_opened(self):
        from nilt.dashboard import Dashboard
        from nilt.segmentation_bridge import state, workspace
        self.token("top")
        # Existing BOTTOM projects must still be recovered to track/stop their
        # workers, although new whole-image BOTTOM workspaces are unavailable.
        workspace(self.app, 'bottom', 0, legacy=True)
        restarted = Dashboard(self.config)
        recovered = state(restarted)
        self.assertEqual(set(recovered), {"top", "bottom"})
        self.assertEqual(recovered["top"]["project"], str(self.root / "segmentation/top/annotations"))

    def test_large_threshold_history_is_sampled_and_cached_without_changing_export(self):
        report = self.root / "threshold_tuning" / "experiment" / "report.json"
        curve = [{"bad_threshold": i / 1200, "fp": i, "fn": 1200 - i} for i in range(1200)]
        write_json(report, {"single_curve": curve, "task": "vig", "candidate": "test"})
        original = sha_file(report)
        from nilt.dashboard import _read_json
        with patch("nilt.dashboard._read_json", wraps=_read_json) as read:
            first = self.app.experiment_history()
            second = self.app.experiment_history()
        self.assertEqual(read.call_count, 1)
        self.assertEqual(len(first["tuning"][0]["report"]["single_curve"]), 500)
        self.assertEqual(first, second)
        self.assertEqual(sha_file(report), original)

    def test_native_picker_passes_literal_paths_without_a_shell(self):
        from types import SimpleNamespace
        with patch("nilt.dashboard_workspace.subprocess.run", return_value=SimpleNamespace(returncode=0, stdout='{"path":"C:/data"}')) as run:
            result = self.app.pick_path({"initial": "C:/$(capture)`tray`", "kind": "folder"})
        self.assertEqual(result["path"], "C:/data")
        self.assertEqual(json.loads(run.call_args.kwargs["input"])["initial"], "C:/$(capture)`tray`")
        self.assertNotIn("shell", run.call_args.kwargs)

    def test_segmentation_pid_identity_never_signals_an_unrelated_process(self):
        from topseg.common import load_config, atomic_json
        from topseg.jobs import JobManager
        import os
        import psutil
        self.token("top")
        cfg = load_config(self.root / "segmentation/top/project.yaml")
        jobs = JobManager(cfg)
        folder = jobs.root / "unrelated"
        folder.mkdir()
        atomic_json(folder / "status.json", {"status": "running"})
        atomic_json(jobs.root / "active.json", {"id": "unrelated", "action": "import", "pid": os.getpid(),
                    "create_time": psutil.Process().create_time()})
        with patch("psutil.Process.terminate") as terminate, patch("psutil.Process.kill") as kill:
            self.assertEqual(jobs.force_stop()["status"], "idle")
        terminate.assert_not_called()
        kill.assert_not_called()
        self.assertEqual(jobs.current()["status"], "interrupted")


if __name__ == "__main__":
    unittest.main()
