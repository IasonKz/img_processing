@echo off
setlocal
pushd "%~dp0.."
python inspection.py doctor --config project.yaml --profile laptop %*
set "inspection_result=%errorlevel%"
popd
exit /b %inspection_result%
