"""Real HTTP coverage of previews, old projects, profiles and manual corrections."""
from copy import deepcopy
import json
import numpy as np
from PIL import Image
import pytest
import test_server
from topseg.annotations import encode_rle, decode_rle
from topseg.classical import reclassify_mask
from topseg.project import Project, ConflictError
from topseg.common import atomic_json, read_json


@pytest.fixture
def api():
    fixture = test_server.AnnotationHTTPTests()
    fixture.setUp()
    try:
        yield fixture
    finally:
        fixture.tearDown()


def box(x, y, width, height):
    return {'type': 'polygon', 'points': [{'x': x, 'y': y}, {'x': x+width, 'y': y},
            {'x': x+width, 'y': y+height}, {'x': x, 'y': y+height}]}


def open_record(api):
    path = f'/api/image/{api.image_id}'
    status, record = api.request('GET', path)
    assert status == 200, record
    return path, record


def test_preview_does_not_write_and_keeps_approval(api):
    path, record = open_record(api)
    payload = dict(mask_rle=record['mask_rle'], objects=record['objects'], roi=record['roi'],
                   expected_revision=record['revision'], approved=True, clean=not record['objects'])
    status, record = api.request('POST', path+'/annotation', payload)
    assert status == 200
    p=api.server.project
    history=sorted((p.root/'history'/api.image_id).iterdir())
    original=(p.root/'annotations'/f'{api.image_id}.json').read_bytes()
    for method in ('basic','exclusions','structure'):
        status, preview=api.request('POST',path+'/proposal-preview',dict(
            expected_revision=record['revision'], roi=record['roi'], automation={'method':method}))
        assert status == 200, preview
        assert preview['roi'] == record['roi']
        assert preview['automation']['method'] == method
        assert 'proposal' in preview['statistics']
        assert decode_rle(preview['mask_rle'],64,48).shape == (48,64)
    assert sorted((p.root/'history'/api.image_id).iterdir()) == history
    assert (p.root/'annotations'/f'{api.image_id}.json').read_bytes() == original
    assert api.request('GET',path)[1]['status']=='approved'
    assert api.request('POST',path+'/proposal-preview',dict(expected_revision=record['revision']-1))[0]==409


def test_failed_preview_preserves_exact_record(api):
    path,record=open_record(api)
    for automation in ({'method':'reference'},{'method':'unknown'},{'scope':'custom'},
                       {'method':'reference','reference_ids':[api.image_id]}):
        status,error=api.request('POST',path+'/proposal-preview',dict(
            expected_revision=record['revision'],roi=record['roi'],automation=automation))
        assert status==400,error
        assert api.request('GET',path)[1]==record


def test_profile_persists_and_scales_only_geometry(api):
    path,record=open_record(api)
    automation={**record['automation'],'method':'exclusions','scope':'custom','scope_roi':box(4,4,50,36),
                'zones':[{'id':'label-one','name':'Label','category':'label','roi':box(5,5,9,8)}],
                'eye':{'cx':32,'cy':24,'rx':5,'ry':4}}
    payload=dict(image_id=api.image_id,automation=automation,expected_revision=0,enabled=True)
    status,saved=api.request('POST','/api/automation',payload)
    assert status==200,saved
    assert saved['revision']==1
    assert api.request('POST','/api/automation',payload)[0]==409
    p=Project(api.cfg)
    scaled=p.profile_automation(128,96)
    assert scaled['zones'][0]['roi']['points'][0]=={'x':10,'y':10}
    assert scaled['eye']=={'cx':64.,'cy':48.,'rx':10.,'ry':8.}
    assert scaled['scope_roi']['points'][2]=={'x':108.,'y':80.}
    assert api.request('GET',path)[1]==record # profiles never rewrite reviewed image records
    status,loaded=api.request('POST','/api/automation/load',{'image_id':api.image_id})
    assert status==200 and loaded['automation']==saved['automation']
    before=api.source_bytes
    assert (api.root/'sources'/'unit-a.png').read_bytes()==before
    Image.new('RGB',(128,96),(140,140,140)).save(api.root/'sources'/'new.png')
    p.import_images()
    new=next(i for i in p.items() if i['relative_path']=='new.png')
    opened=p.open_image(new['id'])
    assert opened['automation']==scaled
    assert Image.open(p.image_path(new['id'])).size==(128,96)


def test_persist_manual_erase_and_brush_across_regeneration(api):
    path,record=open_record(api)
    # Suppress ALL automatic pixels, yet keep a hand drawn defect in that area.
    # This is also the significant overlap case: a manual addition wins erasures.
    brush=np.zeros((48,64),np.uint8);brush[21:25,31:35]=1
    obj=dict(id='manual-one',name='Manual defect',kind='brush',visible=False,mask_rle=encode_rle(brush))
    manual={'erase_rle':[[1,64*48]]}
    status,saved=api.request('POST',path+'/annotation',dict(
        expected_revision=record['revision'],mask_rle=encode_rle(brush),objects=[obj],
        roi=record['roi'],notes='Keep this defect',automation={'method':'exclusions'},manual_edits=manual))
    assert status==200,saved
    assert saved['manual_edits']==manual
    for method in ('basic','structure','exclusions'):
        status,saved=api.request('POST',path+'/propose',dict(expected_revision=saved['revision'],
                                      automation={'method':method},keep_manual_edits=True))
        assert status==200,saved
        assert saved['notes']=='Keep this defect'
        assert saved['objects']==[obj]
        assert saved['manual_edits']==manual
        np.testing.assert_array_equal(decode_rle(saved['mask_rle'],64,48), reclassify_mask(brush,record['roi']))
    status,fresh=api.request('POST',path+'/propose',dict(expected_revision=saved['revision'],
                              automation={'method':'basic'},keep_manual_edits=False))
    assert status==200,fresh
    assert all(o['kind']=='proposal' for o in fresh['objects'])
    assert fresh['manual_edits']=={'erase_rle':[[0,64*48]]}


def test_invalid_manual_state_is_not_committed(api):
    path,record=open_record(api)
    for manual in ({'erase_rle':[[2,3072]]},{'erase_rle':[[1,5]]},{'erase_rle':[[0,3072]],'extra':1}):
        status,result=api.request('POST',path+'/annotation',dict(expected_revision=record['revision'],
                    mask_rle=record['mask_rle'],objects=record['objects'],manual_edits=manual))
        assert status==400,result
        assert api.request('GET',path)[1]==record


def test_v1_read_migration_does_not_mutate_history(api):
    path,record=open_record(api)
    p=api.server.project
    old=read_json(p.root/'annotations'/f'{api.image_id}.json')
    old.pop('automation');old.pop('manual_edits')
    saved_path=p.root/'annotations'/f'{api.image_id}.json'
    history_path=p.root/old['mask'];history_path=history_path.parent/'annotation.json'
    atomic_json(saved_path,old);atomic_json(history_path,old)
    before=saved_path.read_bytes();history=history_path.read_bytes()
    status,migrated=api.request('GET',path)
    assert status==200,migrated
    assert migrated['automation']['method']=='basic'
    assert migrated['manual_edits']=={'erase_rle':[[0,3072]]}
    assert before==saved_path.read_bytes() and history==history_path.read_bytes()


def test_unavailable_saved_reference_profile_still_opens_new_image(api):
    path,record=open_record(api)
    # A uniform reference cannot be aligned reliably. An open must still make
    # the editor available to change methods, explicitly displaying the failure.
    uniform=api.root/'sources'/'uniform.png'
    Image.new('RGB',(64,48),(120,120,120)).save(uniform)
    p=api.server.project;p.import_images()
    new=next(i for i in p.items() if i['relative_path']=='uniform.png')
    p.save_automation_profile(api.image_id,{'method':'reference','reference_ids':[api.image_id]},0)
    opened=p.open_image(new['id'])
    assert opened['status']=='draft'
    assert opened['statistics']['proposal']['failed']
    assert opened['statistics']['proposal']['warnings']
    assert opened['automation']['method']=='reference'
    assert opened['clean'] is False


def test_proposal_diagnostics_survive_save_and_mark_changed_inputs(api):
    path,record=open_record(api)
    status,preview=api.request('POST',path+'/proposal-preview',dict(
        expected_revision=record['revision'],roi=record['roi'],automation={'method':'structure'}))
    assert status==200,preview
    stats=preview['statistics']['proposal']
    assert stats['stale'] is False
    payload=dict(expected_revision=record['revision'],mask_rle=preview['mask_rle'],objects=preview['objects'],
                 roi=preview['roi'],automation=preview['automation'],settings=preview['settings'],proposal_statistics=stats)
    status,saved=api.request('POST',path+'/annotation',payload)
    assert status==200,saved
    assert saved['statistics']['proposal']['input_context']==stats['input_context']
    assert saved['statistics']['proposal']['stale'] is False
    changed={**payload,'expected_revision':saved['revision'],'automation':{'method':'basic'}}
    changed.pop('proposal_statistics')
    status,changed=api.request('POST',path+'/annotation',changed)
    assert status==200,changed
    assert changed['statistics']['proposal']['stale'] is True
    assert changed['statistics']['proposal']['method']=='structure'


def test_invalid_diagnostics_never_allocate_history(api):
    path,record=open_record(api)
    folder=api.server.project.root/'history'/api.image_id
    before=sorted(folder.iterdir())
    status,error=api.request('POST',path+'/annotation',dict(
        expected_revision=record['revision'],mask_rle=record['mask_rle'],objects=record['objects'],
        proposal_statistics=['not an object']))
    assert status==400,error
    assert sorted(folder.iterdir())==before


def test_missing_reference_allows_new_image_to_open_for_manual_recovery(api):
    _,record=open_record(api)
    p=api.server.project
    Image.new('RGB',(64,48),(141,141,141)).save(api.root/'sources'/'new-open.png')
    p.import_images();new=next(i for i in p.items() if i['relative_path']=='new-open.png')
    p.save_automation_profile(api.image_id,{'method':'reference','reference_ids':[api.image_id]},0)
    p.image_path(api.image_id).unlink() # Simulate missing working reference, not missing target.
    opened=p.open_image(new['id'])
    assert opened['statistics']['proposal']['failed'] is True
    assert 'unavailable' in opened['statistics']['proposal']['warnings'][0]
    empty=np.zeros((48,64),np.uint8)
    saved=p.save_annotation(new['id'],empty,expected_revision=opened['revision'])
    assert saved['statistics']['proposal']['failed'] is True
    assert saved['statistics']['proposal']['stale'] is False
