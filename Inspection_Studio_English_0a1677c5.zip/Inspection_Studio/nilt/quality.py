"""Read-only quality documentation from recorded experiment and inspection evidence.

No image, checkpoint, score array, or sealed test partition is opened. Original
dataset labels, later operator reviews, and model decisions remain independent.
The caller selects authorized run/session directories; references inside their
metadata are documented, never followed to another directory.
"""
from __future__ import annotations

from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
import math
from pathlib import Path
import re

FORMAT = "inspection_quality_report_v1"
MAX_ARTIFACT_BYTES = 64 * 1024 * 1024
MAX_ROWS = 250_000
MAX_SOURCES = 128
MAX_MODELS = 4096
LABELS = {"good", "bad"}
DECISIONS = LABELS | {"review"}
COMPLETE = {"completed", "completed_with_input_errors"}


def _ratio(a, b):
    return a / b if b else None


def _clean(value):
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, dict):
        return {str(k): _clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_clean(v) for v in value]
    return value


def _digest(value):
    return hashlib.sha256(json.dumps(_clean(value), sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _hash(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-fA-F]{64}", value) is not None


def _label(value):
    value = str(value or "").lower()
    return value if value in LABELS else None


def _identity(row):
    """Parse physical units without inventing coordinates for arbitrary filenames."""
    filename = str(row.get("relative_path") or row.get("path") or "").replace("\\", "/").split("/")[-1]
    trays = re.findall(r"(?<![A-Za-z0-9])C(\d+)(?=[_\-.\s]|$)", filename, re.I)
    rr = re.findall(r"(?<![A-Za-z])Rc(\d+)", filename, re.I)
    cc = re.findall(r"(?<![A-Za-z])Cc(\d+)", filename, re.I)
    tray = "C" + str(int(trays[0])) if len(trays) == 1 else "unknown"
    if tray == "unknown" and re.fullmatch(r"C\d+", str(row.get("tray", "")), re.I):
        tray = "C" + str(int(str(row["tray"])[1:]))
    unit = f"{tray}:R{int(rr[0])}:C{int(cc[0])}" if tray != "unknown" and len(rr) == len(cc) == 1 else None
    if unit is None and row.get("unit_id"):
        unit = str(row["unit_id"])
    return tray, unit


class _Evidence:
    def __init__(self):
        self.artifacts = []
        self.issues = []
        self.cache = {}

    def issue(self, root, path, message, severity="warning"):
        self.issues.append({"severity": severity, "root": str(root), "path": str(path), "message": message})

    def safe(self, root, relative):
        relative = Path(relative)
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("Artifact path must stay inside its selected directory.")
        path = root
        for part in relative.parts:
            path /= part
            if path.is_symlink():
                raise ValueError("Symbolic links are not followed in quality reports.")
        if not path.resolve().is_relative_to(root):
            raise ValueError("Artifact escapes its selected directory.")
        return path

    def read(self, root, relative, kind="json", required=False):
        key = (str(root), str(relative))
        if key in self.cache:
            return self.cache[key]
        artifact = {"root": str(root), "path": str(relative), "kind": kind,
                    "sha256": None, "bytes": None, "status": "missing"}
        self.artifacts.append(artifact)
        result = None
        try:
            path = self.safe(root, relative)
            if not path.exists():
                if required:
                    self.issue(root, relative, "Required evidence artifact is missing.", "error")
                self.cache[key] = None
                return None
            size = path.stat().st_size
            if not path.is_file() or size > MAX_ARTIFACT_BYTES:
                raise ValueError("Evidence is not a regular file or exceeds the 64 MiB safety limit.")
            raw = path.read_bytes()
            if len(raw) > MAX_ARTIFACT_BYTES:
                raise ValueError("Evidence grew beyond the 64 MiB safety limit while being read.")
            artifact.update(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw), status="read")
            text = raw.decode("utf-8-sig")
            if kind == "csv":
                result = []
                for index, row in enumerate(csv.DictReader(io.StringIO(text))):
                    if index >= MAX_ROWS:
                        raise ValueError("Evidence exceeds the 250,000-row safety limit; no truncated metrics were used.")
                    result.append(dict(row))
            elif kind == "jsonl":
                result = []
                for index, line in enumerate(text.splitlines()):
                    if not line.strip():
                        continue
                    if index >= MAX_ROWS:
                        raise ValueError("Evidence exceeds the record safety limit.")
                    result.append(json.loads(line))
            else:
                result = json.loads(text)
                if not isinstance(result, dict) and Path(relative).name not in {
                        "candidates.json", "lineage.json", "failed_candidates.json",
                        "search_shortlist.json", "search_confirmations.json"}:
                    raise ValueError("Evidence artifact must contain a JSON object.")
            result = _clean(result)
        except (OSError, ValueError, UnicodeError) as exc:
            artifact["status"] = "invalid"
            self.issue(root, relative, str(exc), "error")
            result = None
        self.cache[key] = result
        return result

    def children(self, root, relative, suffix=None, directories=False, limit=MAX_ROWS):
        try:
            path = self.safe(root, relative)
            if not path.exists():
                return []
            result = []
            for index, child in enumerate(path.iterdir()):
                if index >= limit:
                    raise ValueError("Directory exceeds the safety limit; evidence was not partially aggregated.")
                if child.is_symlink():
                    self.issue(root, child.relative_to(root), "Skipped symbolic link.", "error")
                    continue
                if child.is_dir() if directories else child.is_file():
                    if suffix is None or child.suffix == suffix:
                        result.append(child.relative_to(root))
            return sorted(result)
        except (OSError, ValueError) as exc:
            self.issue(root, relative, str(exc), "error")
            return []

    def sha(self, root, relative):
        return next((a["sha256"] for a in self.artifacts
                     if a["root"] == str(root) and a["path"] == str(relative) and a["status"] == "read"), None)


def _metrics(rows, reference="reference_label"):
    matrix = [[0, 0, 0], [0, 0, 0]]
    unavailable = {"bad": 0, "good": 0}
    n_labeled = 0
    for row in rows:
        truth = row.get(reference)
        if truth not in LABELS:
            continue
        n_labeled += 1
        prediction = row.get("prediction")
        if row.get("status", "ok") != "ok" or prediction not in DECISIONS:
            unavailable[truth] += 1
            continue
        matrix[0 if truth == "bad" else 1][["bad", "good", "review"].index(prediction)] += 1
    tp, fn, rb = matrix[0]
    fp, tn, rg = matrix[1]
    bad, good = sum(matrix[0]) + unavailable["bad"], sum(matrix[1]) + unavailable["good"]
    automatic = sum(row.get("status", "ok") == "ok" and row.get("prediction") in LABELS for row in rows)
    review = sum(row.get("status", "ok") == "ok" and row.get("prediction") == "review" for row in rows)
    n = tp + fn + fp + tn
    return {"n": n, "n_total": len(rows), "n_labeled": n_labeled, "n_bad": bad, "n_good": good,
            "n_automatic": automatic, "n_review": review, "n_unavailable": len(rows) - automatic - review,
            "n_labeled_review": rb + rg, "n_labeled_unavailable": sum(unavailable.values()),
            "accuracy": _ratio(tp + tn, n), "selective_accuracy": _ratio(tp + tn, n),
            "automatic_correct_rate": _ratio(tp + tn, n_labeled),
            "decision_coverage": _ratio(automatic, len(rows)), "labeled_decision_coverage": _ratio(n, n_labeled),
            "review_rate": _ratio(review, len(rows)), "bad_review_rate": _ratio(rb, bad),
            "good_review_rate": _ratio(rg, good), "bad_escape_rate": _ratio(fn, bad),
            "good_reject_rate": _ratio(fp, good), "bad_detection_rate": _ratio(tp, bad),
            "good_accept_rate": _ratio(tn, good), "accepted_contamination": _ratio(fn, fn + tn),
            "balanced_accuracy": (tp / (tp + fn) + tn / (tn + fp)) / 2 if tp + fn and tn + fp else None,
            "bad_detected_TP": tp, "bad_passed_as_good_FN": fn, "good_rejected_as_bad_FP": fp,
            "good_accepted_TN": tn, "bad_sent_to_review": rb, "good_sent_to_review": rg,
            "confusion": {"rows": ["bad", "good"], "columns": ["bad", "good", "review"], "matrix": matrix},
            "labeled_no_decision": unavailable,
            "reference_basis": "original dataset labels" if reference == "reference_label" else "post-inspection operator-confirmed good/bad labels only; not independent holdout truth",
            "note": "Accuracy is conditional on automatic labeled decisions; show coverage beside it. Review is not counted as success. Class rates include all labeled inputs, including unavailable predictions."}


def _counts(rows):
    c = Counter(r.get("prediction") if r.get("status", "ok") == "ok" and r.get("prediction") in DECISIONS
                else "no_decision" for r in rows)
    return {"total": len(rows), **{k: c[k] for k in ("good", "bad", "review", "no_decision")},
            "labeled": sum(r.get("reference_label") in LABELS for r in rows),
            "operator_labeled": sum(r.get("operator_label") in LABELS for r in rows),
            "predicted_bad_rate": _ratio(c["bad"], len(rows)), "review_rate": _ratio(c["review"], len(rows)),
            "automatic_coverage": _ratio(c["good"] + c["bad"], len(rows))}


def _quality_status(counts):
    if counts["review"] or counts["no_decision"]:
        return "Human review or input follow-up required"
    if counts["bad"]:
        return "Model-flagged bad present"
    if counts["good"]:
        return "No model-flagged bad among recorded decisions"
    return "No automatic decision"


def _manifest_summary(rows):
    by_split, by_tray = defaultdict(list), defaultdict(list)
    for row in rows:
        tray, unit = _identity(row)
        row.update(_tray=tray, _unit=unit)
        by_split[str(row.get("split") or "unknown")].append(row)
        by_tray[tray].append(row)
    def counts(group):
        labels = Counter(_label(r.get("class_name")) or ("bad" if str(r.get("label")) == "0" else
                         "good" if str(r.get("label")) == "1" else "unknown") for r in group)
        return {"images": len(group), "good": labels["good"], "bad": labels["bad"], "unknown_label": labels["unknown"],
                "units": len({r["_unit"] for r in group if r["_unit"]}),
                "unknown_unit_images": sum(not r["_unit"] for r in group)}
    return {"n_images": len(rows), "n_units": len({r["_unit"] for r in rows if r["_unit"]}),
            "unknown_unit_images": sum(not r["_unit"] for r in rows),
            "split_counts": {split: counts(group) for split, group in sorted(by_split.items())},
            "tray_counts": [{"tray": tray, **counts(group),
                              "splits": dict(Counter(r.get("split") or "unknown" for r in group))}
                             for tray, group in sorted(by_tray.items())]}


def _recorded_evaluation(root, summary, prediction_path, evidence, task, role):
    """Read an already-published evaluation, never trigger or inspect sealed scores."""
    result = {"available": isinstance(summary, dict), "summary": summary,
              "role": role, "prediction_rows": [], "per_tray": [],
              "note": "Previously recorded evaluation only. Tray slices are descriptive and often have small samples; no new evaluation was performed."}
    if not isinstance(summary, dict):
        return result
    rows = evidence.read(root, prediction_path, "csv")
    if rows is None:
        return result
    for recorded in rows:
        tray, unit = _identity(recorded)
        row = {"run_id": root.name, "task": task, "evaluation_role": role, "tray": tray, "unit_id": unit,
               "relative_path": recorded.get("relative_path"), "reference_label": _label(recorded.get("true_class")),
               "prediction": recorded.get("predicted_class") if recorded.get("predicted_class") in DECISIONS else None,
               "status": recorded.get("status") or "ok", "operator_label": None,
               "score": recorded.get("score"), "threshold": recorded.get("threshold"),
               "model_version": recorded.get("model_version"), "error_type": recorded.get("error_type"),
               "file_sha256": recorded.get("file_sha256"), "pixel_hash": recorded.get("pixel_hash")}
        result["prediction_rows"].append(row)
    for tray in sorted({row["tray"] for row in result["prediction_rows"]}):
        subset = [row for row in result["prediction_rows"] if row["tray"] == tray]
        result["per_tray"].append({"run_id": root.name, "task": task, "tray": tray, "evaluation_role": role,
                                   "n_units": len({r["unit_id"] for r in subset if r["unit_id"]}),
                                   "counts": _counts(subset), "metrics_reference": _metrics(subset)})
    return result


def _load_run(root, evidence):
    filenames = ("config.json", "model_state.json", "split_summary.json", "selected.json", "candidates.json",
                 "final_test_summary.json", "environment.json", "search_status.json", "search_contract.json",
                 "lineage.json", "integrity.json", "selection_integrity.json", "failed_candidates.json",
                 "search_shortlist.json", "search_confirmations.json", "audit/audit_summary.json")
    docs = {name: evidence.read(root, name, required=name == "config.json") for name in filenames}
    cfg = docs["config.json"] if isinstance(docs["config.json"], dict) else {}
    manifest = evidence.read(root, "manifest.csv", "csv", required=True) or []
    data = _manifest_summary(manifest)
    data.update(fingerprint=cfg.get("dataset_fingerprint"), manifest_sha256=evidence.sha(root, "manifest.csv"),
                manifest_available=evidence.sha(root, "manifest.csv") is not None)
    integrity = docs.get("integrity.json") or {}
    data["integrity_valid"] = True
    for file, field in (("config.json", "config_sha256"), ("manifest.csv", "manifest_sha256")):
        if integrity.get(field) and integrity[field] != evidence.sha(root, file):
            evidence.issue(root, file, "Recorded run integrity hash does not match this artifact.", "error")
            data["integrity_valid"] = False
    folders = evidence.children(root, "models", directories=True, limit=MAX_MODELS)
    for architecture in evidence.children(root, "search", directories=True, limit=MAX_MODELS):
        children = evidence.children(root, architecture, directories=True, limit=MAX_MODELS)
        folders.extend(children)
        if architecture.name == "confirmations":
            for candidate in children:
                folders.extend(evidence.children(root, candidate, directories=True, limit=MAX_MODELS))
    models = []
    if len(folders) > MAX_MODELS:
        evidence.issue(root, "models", "Model count exceeds the safety limit; model details were not partially aggregated.", "error")
        folders = []
    for folder in folders:
        completed = evidence.read(root, folder / "completed.json")
        progress = evidence.read(root, folder / "progress.json")
        config = evidence.read(root, folder / "config.json")
        history = evidence.read(root, folder / "history.csv", "csv")
        failure = evidence.read(root, folder / "failure.json")
        partial = evidence.read(root, folder / "partial.json")
        if not any(v is not None for v in (completed, progress, config, history, failure, partial)):
            continue
        models.append({"name": folder.as_posix(), "path": str(root / folder), "progress": progress,
                       "completed": completed, "parameters": config or cfg, "history": history or [],
                       "failure": failure, "partial": partial,
                       "checkpoint_hashes": {"best_recorded_sha256": (completed or {}).get("checkpoint_sha256"),
                                             "partial_recorded_sha256": (partial or {}).get("checkpoint_sha256"),
                                             "binary_verified": False}})
    selected = docs.get("selected.json") or {}
    final_test = _recorded_evaluation(root, docs.get("final_test_summary.json"), "final_test/predictions.csv",
                                      evidence, cfg.get("task") or "unknown", "recorded final test")
    external_evaluations = []
    for folder in evidence.children(root, "evaluations", directories=True, limit=MAX_MODELS):
        summary = evidence.read(root, folder / "summary.json")
        if isinstance(summary, dict):
            external_evaluations.append({"id": folder.name, **_recorded_evaluation(
                root, summary, folder / "predictions" / "predictions.csv", evidence,
                cfg.get("task") or "unknown", "recorded external evaluation")})
    membership = [{"run_id": root.name, "task": cfg.get("task") or "unknown",
                   "relative_path": row.get("relative_path"), "label": row.get("label"),
                   "class_name": row.get("class_name"), "split": row.get("split"),
                   "tray": row["_tray"], "unit_id": row["_unit"], "pixel_hash": row.get("pixel_hash"),
                   "file_sha256": row.get("file_sha256"), "width": row.get("width"),
                   "height": row.get("height"), "source_bit_depth": row.get("source_bit_depth"),
                   "group": row.get("group")}
                  for row in manifest]
    report = {"id": root.name, "path": str(root), "task": cfg.get("task") or "unknown",
              "roi_scope": cfg.get("roi_scope", "whole_image"),
              "status": (docs.get("model_state.json") or {}).get("status", (docs.get("model_state.json") or {}).get("state", (docs.get("search_status.json") or {}).get("status", "unknown"))),
              "config": cfg, "config_sha256": evidence.sha(root, "config.json"), "dataset": data,
              "dataset_membership": membership, "models": models,
              "selection": {"selected": selected, "candidates": docs.get("candidates.json") or [],
                            "role": "development selection; not an independent final test"},
              "final_test": final_test, "external_evaluations": external_evaluations,
              "documents": {k: v for k, v in docs.items() if v is not None}}
    return report, manifest


def _source_specs(applied):
    if applied.get("source_run_id"):
        return [applied]
    return applied.get("sources") or applied.get("stages") or []


def _matching_runs(applied, runs):
    matched, missing = [], False
    specs = _source_specs(applied)
    for spec in specs:
        if not isinstance(spec, dict):
            missing = True
            continue
        candidates = []
        for run in runs:
            if run["task"] != applied.get("task", run["task"]):
                continue
            if run.get("roi_scope", "whole_image") != applied.get("roi_scope", "whole_image"):
                continue
            # Immutable manifests and configuration fingerprints are strongest.
            sha = spec.get("source_manifest_sha256")
            config_sha = spec.get("source_config_sha256")
            if sha:
                if run["dataset"]["manifest_sha256"] != sha or (config_sha and config_sha != run["config_sha256"]):
                    continue
            elif spec.get("source_run_id"):
                if run["id"] != spec["source_run_id"]:
                    continue
            else:
                # A portable workflow reference's basename is only a locator;
                # without immutable source evidence it is NOT enough to assert exposure.
                continue
            candidates.append(run)
        if (len(candidates) != 1 or not candidates[0]["dataset"]["manifest_available"]
                or not candidates[0]["dataset"]["integrity_valid"]):
            missing = True
        elif candidates[0] not in matched:
            matched.append(candidates[0])
    return matched, missing or not specs


def _manifest_index(rows):
    result = {field: defaultdict(list) for field in ("unit_id", "file_sha256", "pixel_hash")}
    result["_coverage"] = {field: set() for field in ("unit_id", "file_sha256", "pixel_hash")}
    result["_rows"] = len(rows)
    result["_coverage_cache"] = {}
    for i, row in enumerate(rows):
        if row.get("_unit"):
            result["unit_id"][row["_unit"]].append(row)
            result["_coverage"]["unit_id"].add(i)
        for field in ("file_sha256", "pixel_hash"):
            if _hash(row.get(field)):
                result[field][row[field].lower()].append(row)
                result["_coverage"][field].add(i)
    return result


def _exposure(row, linked, missing, manifests):
    any_identity = False
    matches = []
    for run in linked:
        index = manifests[run["path"]]
        available = tuple(field for field in ("unit_id", "file_sha256", "pixel_hash")
                          if row.get(field) and (field == "unit_id" or _hash(row[field])))
        if available not in index["_coverage_cache"]:
            covered = set().union(*(index["_coverage"][field] for field in available))
            index["_coverage_cache"][available] = bool(index["_rows"]) and len(covered) == index["_rows"]
        missing |= not index["_coverage_cache"][available]
        for field in ("unit_id", "file_sha256", "pixel_hash"):
            value = row.get(field)
            if not value or (field != "unit_id" and not _hash(value)):
                continue
            any_identity |= bool(index[field])
            if field != "unit_id":
                value = value.lower()
            for m in index[field].get(value, []):
                entry = {"run_id": run["id"], "split": m.get("split") or "unknown",
                         "basis": "physical_unit" if field == "unit_id" else "content_hash"}
                if entry not in matches:
                    matches.append(entry)
    if any(m["split"] == "train" for m in matches):
        state = "seen_in_training"
    elif any(m["split"] in {"validation", "val", "threshold", "selection"} for m in matches):
        state = "seen_in_development"
    elif missing or not linked or not any_identity:
        state = "unknown"
    elif any(m["split"] in {"test", "excluded_old_test", "excluded_old_test_group"} for m in matches):
        state = "seen_in_test"
    else:
        state = "not_matched"
    return state, matches


def _exposure_counts(rows, linked):
    counts = Counter(r["training_exposure"] for r in rows)
    return {**{key: counts[key] for key in ("seen_in_training", "seen_in_development", "seen_in_test", "not_matched", "unknown")},
            "matched_run_ids": [r["id"] for r in linked],
            "scope": "selected matching source-run manifests only; not_matched is not proof of independence",
            "note": "Any view of the same physical unit is considered exposed. Unknown identities or unavailable source manifests remain unknown."}


def _load_session(root, evidence, runs, manifests):
    initial_errors = sum(x["severity"] == "error" for x in evidence.issues)
    marker = evidence.read(root, "review_session.json", required=True) or {}
    summary = evidence.read(root, "summary.json") or {}
    progress = evidence.read(root, "review_progress.json") or {}
    reviews = evidence.read(root, "reviews.json") or {}
    metadata = marker.get("metadata") or {}
    if not isinstance(metadata, dict):
        evidence.issue(root, "review_session.json", "Session metadata must be an object.", "error")
        metadata = {}
    documents = {}
    for name in ("applied_decision.json", "applied_workflow.json", "applied_system.json"):
        value = evidence.read(root, name)
        if value is not None:
            documents[name] = value
    applied = next(iter(documents.values()), {})
    task = metadata.get("task") or summary.get("task") or applied.get("task") or "unknown"
    roi_scope = metadata.get("roi_scope") or summary.get("roi_scope") or applied.get("roi_scope") or "whole_image"
    status = summary.get("status") or progress.get("status") or "unknown"
    provisional = status not in COMPLETE
    if marker.get("format") != "inspection_review_session_v4" or marker.get("id") != root.name:
        evidence.issue(root, "review_session.json", "Session marker format or identity is invalid; data is provisional.", "error")
        provisional = True
    linked, missing = _matching_runs(applied, runs)
    decision_identity = (metadata.get("decision_sha256") or metadata.get("workflow_sha256") or metadata.get("system_sha256") or
                         summary.get("decision_sha256") or summary.get("workflow_sha256") or summary.get("system_sha256") or
                         (_digest(applied) if applied else "unknown"))
    model_identity = {"candidate": metadata.get("candidate") or applied.get("candidate") or metadata.get("system_name") or metadata.get("workflow_name"),
                      "sources": _source_specs(applied), "source_run_ids": [r["id"] for r in linked],
                      "decision_sha256": decision_identity}
    records = []
    files = evidence.children(root, "records", suffix=".json")
    for file in files:
        value = evidence.read(root, file)
        if isinstance(value, dict):
            records.append(value)
        elif value is not None:
            evidence.issue(root, file, "Prediction record must be an object.", "error")
    # Modern sessions use immutable record files. A journal fallback is allowed
    # only when no authoritative records exist; malformed journals never disappear silently.
    if not files:
        journal = evidence.read(root, "predictions.jsonl", "jsonl")
        records = journal if isinstance(journal, list) else []
    images, identities = [], set()
    review_items = reviews.get("items", {})
    if not isinstance(review_items, dict):
        evidence.issue(root, "reviews.json", "Operator review items must be an object.", "error")
        review_items = {}
    for record in records:
        if not isinstance(record, dict):
            evidence.issue(root, "predictions", "Non-object prediction record excluded.", "error")
            continue
        relative = str(record.get("relative_path") or "")
        if not relative or relative in identities:
            evidence.issue(root, "predictions", "Missing or duplicate relative_path; ambiguous record excluded.", "error")
            continue
        identities.add(relative)
        tray, unit = _identity(record)
        review = review_items.get(record.get("id"), {})
        if not isinstance(review, dict):
            evidence.issue(root, "reviews.json", "An operator review entry is invalid; it was not used as a label.", "error")
            review = {}
        prediction = record.get("prediction", record.get("predicted_class"))
        prediction = str(prediction).lower() if prediction in DECISIONS else None
        reference = _label(record.get("reference_label", record.get("true_class")))
        operator = str(review.get("label") or "unreviewed")
        row = {"session_id": root.name, "session_path": str(root), "task": task, "tray": tray, "unit_id": unit,
               "roi_scope": roi_scope,
               "relative_path": relative, "file_sha256": record.get("file_sha256", record.get("sha256")),
               "pixel_hash": record.get("pixel_hash", record.get("pixel_sha256")), "prediction": prediction, "reference_label": reference,
               "operator_label": operator, "operator_note": review.get("note", ""), "operator_updated_utc": review.get("updated_utc"),
               "reference_mismatch": reference != prediction if reference in LABELS and prediction in LABELS else None,
               "operator_mismatch": operator != prediction if operator in LABELS and prediction in LABELS else None,
               "manual_reference_disagreement": reference != operator if reference in LABELS and operator in LABELS else None,
               "review_reason": record.get("review_reason") or "", "status": record.get("status", "ok"),
               "error": record.get("error", ""), "score": record.get("bad_score", record.get("score")),
               "score_type": record.get("score_type"), "stage_results": record.get("stage_results") or [],
               "model_disagreement": bool(record.get("model_disagreement")), "uncertainty": record.get("uncertainty"),
               "threshold": record.get("threshold"), "good_threshold": record.get("good_threshold"),
               "bad_threshold": record.get("bad_threshold"), "completed_utc": record.get("completed_utc"),
               "model_identity": model_identity, "decision_identity": decision_identity, "provisional": provisional}
        row["training_exposure"], row["exposure_matches"] = _exposure(row, linked, missing, manifests)
        row["recorded_source_splits"] = sorted({m["split"] for m in row["exposure_matches"]})
        images.append(row)
    if progress.get("completed") is not None and progress["completed"] != len(images):
        evidence.issue(root, "review_progress.json", "Recorded progress and readable committed predictions differ; this snapshot may be incomplete.")
        provisional = True
    if status in COMPLETE and progress.get("total") is not None and progress["total"] != len(images):
        evidence.issue(root, "review_progress.json", "Completed session has fewer or more committed records than its expected total; metrics describe only readable records.")
        provisional = True
    if sum(x["severity"] == "error" for x in evidence.issues) > initial_errors:
        provisional = True
    for row in images:
        row["provisional"] = provisional
    count = _counts(images)
    result = {"id": root.name, "path": str(root), "task": task, "status": status, "provisional": provisional,
              "roi_scope": roi_scope,
              "created_utc": marker.get("created_utc") or summary.get("created_utc"), "kind": marker.get("kind"),
              "model_identity": model_identity, "decision_identity": decision_identity, "metadata": metadata,
              "metrics_reference": _metrics(images), "metrics_operator": _metrics(images, "operator_label"),
              "counts": count, "training_exposure": _exposure_counts(images, linked), "quality_status": _quality_status(count),
              "expected_images": progress.get("total"), "documents": {**documents, "summary.json": summary,
               "review_progress.json": progress, "review_session.json": marker, "reviews.json": reviews}}
    trays = []
    for tray in sorted({r["tray"] for r in images}):
        group = [r for r in images if r["tray"] == tray]
        counts = _counts(group)
        trays.append({"session_id": root.name, "session_path": str(root), "task": task, "tray": tray,
                      "roi_scope": roi_scope,
                      "n_units": len({r["unit_id"] for r in group if r["unit_id"]}),
                      "unknown_unit_images": sum(not r["unit_id"] for r in group),
                      "status": status, "provisional": provisional, "model_identity": model_identity,
                      "decision_identity": decision_identity, "counts": counts, "metrics_reference": _metrics(group),
                      "metrics_operator": _metrics(group, "operator_label"), "training_exposure": _exposure_counts(group, linked),
                      "quality_status": _quality_status(counts)})
    return result, images, trays


def _comparisons(sessions, images):
    result = []
    indexed = {}
    for session in sessions:
        mapping = defaultdict(list)
        for row in images:
            if row["session_path"] == session["path"] and _hash(row.get("file_sha256")):
                mapping[row["file_sha256"].lower()].append(row)
        indexed[session["path"]] = mapping
    for index, a in enumerate(sessions):
        for b in sessions[index + 1:]:
            comparison = {"session_a": a["id"], "session_b": b["id"], "session_a_path": a["path"], "session_b_path": b["path"],
                          "task": a["task"] if a["task"] == b["task"] else None, "comparable": False,
                          "roi_scope": a.get("roi_scope", "whole_image") if a.get("roi_scope", "whole_image") == b.get("roi_scope", "whole_image") else None,
                          "reason": None, "common_images": 0, "decision_disagreements": 0, "disagreement_rate": None,
                          "reference_conflicts": 0, "excluded_ambiguous_fingerprints": 0,
                          "metrics_a": None, "metrics_b": None, "coverage_a": None, "coverage_b": None,
                          "provisional": a["provisional"] or b["provisional"],
                          "note": "Paired descriptive comparison on identical file bytes and original labels only. Different tray populations or operator corrections are not pooled. No causal improvement or production qualification is inferred."}
            result.append(comparison)
            if a["task"] != b["task"] or a["task"] == "unknown":
                comparison["reason"] = "Different or unknown inspection tasks cannot be compared."
                continue
            if a.get("roi_scope", "whole_image") != b.get("roi_scope", "whole_image"):
                comparison["reason"] = "Different ROI scopes cannot be compared."
                continue
            ma, mb = indexed[a["path"]], indexed[b["path"]]
            aa, bb = [], []
            for digest in sorted(ma.keys() & mb.keys()):
                if len(ma[digest]) != 1 or len(mb[digest]) != 1:
                    comparison["excluded_ambiguous_fingerprints"] += 1
                    continue
                ra, rb = ma[digest][0], mb[digest][0]
                if ra["reference_label"] != rb["reference_label"]:
                    comparison["reference_conflicts"] += 1
                    continue
                aa.append(ra)
                bb.append(rb)
            if not aa:
                comparison["reason"] = "No unambiguous matching file fingerprints with identical original labels."
                continue
            disagreement = sum((ra["prediction"] if ra["status"] == "ok" else None) !=
                               (rb["prediction"] if rb["status"] == "ok" else None) for ra, rb in zip(aa, bb))
            comparison.update(comparable=True, common_images=len(aa), decision_disagreements=disagreement,
                              disagreement_rate=disagreement / len(aa), metrics_a=_metrics(aa), metrics_b=_metrics(bb),
                              coverage_a=len(aa) / a["counts"]["total"], coverage_b=len(bb) / b["counts"]["total"])
    return result


def build_quality_report(runs: list[Path], sessions: list[Path], title: str = "Quality report", notes: str = "") -> dict:
    """Build a JSON-safe snapshot; never mutate experiment or session artifacts.

    Readers are bounded and do not follow symlinks. Only explicitly selected
    source roots are opened. Missing evidence is recorded, never filled by a
    new model evaluation or an assumed correct prediction.
    """
    if not isinstance(runs, (list, tuple)) or not isinstance(sessions, (list, tuple)):
        raise ValueError("runs and sessions must be lists of selected directories.")
    if not runs and not sessions:
        raise ValueError("Choose at least one recorded training run or inspection session.")
    if len(runs) + len(sessions) > MAX_SOURCES:
        raise ValueError("Choose at most 128 evidence directories per report.")
    if not isinstance(title, str) or not title.strip() or len(title) > 200:
        raise ValueError("Report title must contain 1–200 characters.")
    if not isinstance(notes, str) or len(notes) > 20_000:
        raise ValueError("Report notes must contain at most 20,000 characters.")
    evidence = _Evidence()
    def paths(values):
        result = []
        for value in values:
            path = Path(value).absolute()
            if path.is_symlink() or not path.is_dir():
                raise ValueError("Selected evidence must be an existing directory, not a symbolic link: " + str(path))
            path = path.resolve()
            if path in result:
                raise ValueError("Duplicate evidence directory: " + str(path))
            result.append(path)
        return result
    run_paths, session_paths = paths(runs), paths(sessions)
    run_results, manifests = [], {}
    for path in run_paths:
        report, manifest = _load_run(path, evidence)
        run_results.append(report)
        manifests[str(path)] = _manifest_index(manifest)
    session_results, image_results, tray_results = [], [], []
    for path in session_paths:
        report, rows, trays = _load_session(path, evidence, run_results, manifests)
        session_results.append(report)
        image_results.extend(rows)
        tray_results.extend(trays)
    disagreement_rows = [row for row in image_results if row["reference_mismatch"] is True or row["operator_mismatch"] is True
                         or row["manual_reference_disagreement"] is True or row["model_disagreement"] or row["prediction"] == "review"]
    report = {"format": FORMAT, "generated_utc": datetime.now(timezone.utc).isoformat(), "title": title.strip(), "notes": notes,
              "runs": run_results, "sessions": session_results, "trays": tray_results, "images": image_results,
              "disagreements": disagreement_rows, "comparisons": _comparisons(session_results, image_results),
              "artifacts": evidence.artifacts, "issues": evidence.issues,
              "summary": {"runs": len(run_results), "sessions": len(session_results), "tray_session_rows": len(tray_results),
                          "recorded_predictions": len(image_results), "disagreement_or_review_rows": len(disagreement_rows),
                          "tasks": sorted({r["task"] for r in run_results + session_results}),
                          "provisional_sessions": sum(s["provisional"] for s in session_results),
                          "errors": sum(x["severity"] == "error" for x in evidence.issues),
                          "note": "Counts are recorded observations, not unique physical units. Repeated sessions are not pooled into a quality score."},
              "definitions": {"quality_status": "Descriptive model routing, not physical product quality or release approval.",
                              "predicted_bad_rate": "Model bad decisions / all committed input records, including review and unavailable decisions.",
                              "accuracy": "Correct automatic decisions / automatic decisions with the chosen label reference; must be shown with coverage.",
                              "review": "Abstention requiring a human verdict; neither a correct decision nor a ground-truth label.",
                              "reference_labels": "Original dataset good/bad tags remain immutable. Operator labels are analyzed separately.",
                              "operator_metrics": "Post-inspection reviews may have been made after seeing predictions and are not independent holdout truth. Only explicit good/bad verdicts count; review, unknown and unreviewed are not ground truth. Reviewed subsets may be biased.",
                              "final_test": "Only already-recorded final_test_summary.json is read. No sealed image, score file or new test evaluation is accessed.",
                              "training_exposure": "Same physical unit or matching recorded content hash in selected source-run manifests. Unknown is not independent.",
                              "snapshot": "A read-only evidence snapshot. Running sessions are provisional and may change after export.",
                              "provenance": "SHA-256 identifies exact artifact bytes read, not authenticity. Checkpoint binary hashes are recorded claims, not reverified here."}}
    return _clean(report)
