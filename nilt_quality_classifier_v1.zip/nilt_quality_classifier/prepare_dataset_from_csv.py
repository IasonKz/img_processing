from __future__ import annotations

import argparse

from qc.config import load_yaml
from qc.preparation import run_dataset_preparation


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Create a dataset_root/good and dataset_root/bad from evaluation_results.csv."
    )
    parser.add_argument("--config", required=True, help="Path to a preparation YAML file")
    args = parser.parse_args()
    result = run_dataset_preparation(load_yaml(args.config))
    print(f"\nPrepared dataset: {result['output_root']}")
    print(f"GOOD: {result['prepared_good']} | BAD: {result['prepared_bad']}")


if __name__ == "__main__":
    main()
