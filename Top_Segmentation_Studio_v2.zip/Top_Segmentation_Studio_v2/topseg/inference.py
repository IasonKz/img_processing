"""Native-geometry segmentation output and lightweight preprocessing helpers."""
from __future__ import annotations

import csv
import json
from pathlib import Path
import time

import numpy as np
from PIL import Image

CLASSES = {"background": 0, "inner": 1, "outer": 2}
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"}


def fit_geometry(width, height, size):
    width, height, size = int(width), int(height), int(size)
    if min(width, height) < 1 or size < 32:
        raise ValueError("Images must have positive dimensions and image_size must be at least 32.")
    scale = min(size / width, size / height)
    rw, rh = max(1, round(width * scale)), max(1, round(height * scale))
    return {"width": width, "height": height, "size": size,
            "resized_width": rw, "resized_height": rh,
            "left": (size-rw)//2, "top": (size-rh)//2}


def prepare_image(image, size):
    image = image.convert("RGB")
    g = fit_geometry(*image.size, size)
    rgb = image.resize((g["resized_width"], g["resized_height"]), Image.Resampling.BILINEAR)
    canvas = np.zeros((size, size, 3), dtype=np.uint8)
    y, x = g["top"], g["left"]
    canvas[y:y+g["resized_height"], x:x+g["resized_width"]] = np.asarray(rgb)
    # Identical fixed normalization during training and inference.
    tensor = np.ascontiguousarray((canvas.astype(np.float32)/255.0).transpose(2, 0, 1))
    return tensor, g


def prepare_mask(mask, geometry):
    mask = np.asarray(mask)
    g = geometry
    if mask.ndim != 2 or mask.shape != (g["height"], g["width"]) or not np.isin(mask, [0, 1, 2]).all():
        raise ValueError("Mask must match the native image and contain only labels 0, 1, 2.")
    resized = np.asarray(Image.fromarray(mask.astype(np.uint8)).resize(
        (g["resized_width"], g["resized_height"]), Image.Resampling.NEAREST))
    result = np.full((g["size"], g["size"]), 255, dtype=np.uint8)
    y, x = g["top"], g["left"]
    result[y:y+g["resized_height"], x:x+g["resized_width"]] = resized
    return result


def restore_probabilities(probabilities, geometry):
    """Unpad, resize each probability plane, then classify in native geometry."""
    p = np.asarray(probabilities, dtype=np.float32)
    g = geometry
    if p.shape != (3, g["size"], g["size"]) or not np.isfinite(p).all():
        raise ValueError("Expected three finite probability planes at the configured resolution.")
    y, x = g["top"], g["left"]
    native = []
    for channel in p:
        crop = channel[y:y+g["resized_height"], x:x+g["resized_width"]]
        native.append(np.asarray(Image.fromarray(crop).resize((g["width"], g["height"]), Image.Resampling.BILINEAR)))
    return np.stack(native).argmax(0).astype(np.uint8)


def confusion_matrix(target, predicted):
    a, b = np.asarray(target), np.asarray(predicted)
    if a.shape != b.shape or a.ndim != 2:
        raise ValueError("Target and predicted masks must be matching two-dimensional arrays.")
    if not np.isin(a, [0, 1, 2, 255]).all() or not np.isin(b, [0, 1, 2]).all():
        raise ValueError("Unknown segmentation label.")
    valid = a != 255
    return np.bincount(3*a[valid].astype(np.int64) + b[valid], minlength=9).reshape(3, 3)


def metrics_from_confusion(matrix):
    cm = np.asarray(matrix, dtype=np.int64)
    if cm.shape != (3, 3) or (cm < 0).any():
        raise ValueError("Expected a nonnegative 3 by 3 confusion matrix.")
    per_class = {}
    for name, i in CLASSES.items():
        tp, support, predicted = int(cm[i, i]), int(cm[i].sum()), int(cm[:, i].sum())
        union = support + predicted - tp
        per_class[name] = {
            "target_pixels": support, "predicted_pixels": predicted,
            "iou": tp/union if union else None,
            "dice": 2*tp/(support+predicted) if support+predicted else None,
            "recall": tp/support if support else None,
            "precision": tp/predicted if predicted else None,
        }
    # A missing target class never appears as a perfect detection result.
    available_iou = [per_class[c]["iou"] for c in ("inner", "outer") if per_class[c]["iou"] is not None]
    available_dice = [per_class[c]["dice"] for c in ("inner", "outer") if per_class[c]["dice"] is not None]
    return {"classes": per_class, "foreground_mean_iou": float(np.mean(available_iou)) if available_iou else None,
            "foreground_mean_dice": float(np.mean(available_dice)) if available_dice else None,
            "foreground_target_classes": sum(per_class[c]["target_pixels"] > 0 for c in ("inner", "outer")),
            "pixel_accuracy": float(np.trace(cm)/cm.sum()) if cm.sum() else None,
            "confusion_matrix": cm.tolist()}


def overlay(image, mask, opacity=0.55):
    rgb = np.asarray(image.convert("RGB")).copy()
    m = np.asarray(mask)
    if m.shape != rgb.shape[:2]:
        raise ValueError("Overlay mask does not match image dimensions.")
    for value, color in ((1, (255, 65, 65)), (2, (30, 190, 255))):
        selected = m == value
        rgb[selected] = np.rint((1-opacity)*rgb[selected] + opacity*np.asarray(color)).astype(np.uint8)
    return Image.fromarray(rgb)


def require_torch():
    try:
        import torch
    except ImportError as exc:
        raise RuntimeError("PyTorch is required for train and predict. Install requirements-training.txt; annotation works without PyTorch.") from exc
    return torch


def select_device(requested):
    torch = require_torch()
    requested = str(requested)
    if requested == "auto":
        requested = "cuda" if torch.cuda.is_available() else "cpu"
    if requested not in ("cpu", "cuda"):
        raise ValueError("device must be cpu, cuda, or auto.")
    if requested == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable. Use device: cpu.")
    return torch.device(requested)


def load_model(checkpoint, device="cpu"):
    torch = require_torch()
    from .model import SmallUNet
    path = Path(checkpoint).expanduser().resolve()
    state = torch.load(path, map_location="cpu", weights_only=True)
    if state.get("model_type") not in ("small_unet_v1", "studio_semantic") or state.get("classes") != CLASSES:
        raise ValueError("This checkpoint is not a compatible top segmentation pilot model.")
    size = int(state["image_size"])
    if size < 32 or size > 4096:
        raise ValueError("Checkpoint image_size is outside the supported range 32..4096.")
    if state.get("model_type") == "studio_semantic":
        from .registry import build_model
        model = build_model(state["spec"], initialize=False)
    else:
        model = SmallUNet(int(state["base_channels"]))
    model.load_state_dict(state["model_state_dict"], strict=True)
    target_device = select_device(device)
    model.to(target_device).eval()
    return model, state, target_device


def predict(checkpoint, input_dir, output_dir, device="cpu"):
    from .common import atomic_json, read_rgb, sha256, utc_now
    torch = require_torch()
    root = Path(input_dir).expanduser().resolve()
    output = Path(output_dir).expanduser().resolve()
    if not root.is_dir():
        raise ValueError("input_dir must be an existing image directory.")
    if output == root or output.is_relative_to(root) or root.is_relative_to(output):
        raise ValueError("Prediction output must be separate from the input tree.")
    if output.exists() and any(output.iterdir()):
        raise ValueError("Prediction output must be a new or empty directory.")
    files = sorted(p for p in root.rglob("*") if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS)
    if not files:
        raise ValueError("No supported images found in input_dir.")
    model, state, target_device = load_model(checkpoint, device)
    output.mkdir(parents=True, exist_ok=True)
    rows, failures = [], []
    started = time.perf_counter()
    with torch.inference_mode():
        for path in files:
            relative = path.relative_to(root)
            try:
                image = read_rgb(path, max_pixels=int(state.get("max_image_pixels", 25_000_000)))
            except (OSError, ValueError) as exc:
                failures.append({"image": relative.as_posix(), "error": str(exc)})
                continue
            array, geometry = prepare_image(image, state["image_size"])
            probabilities = model(torch.from_numpy(array)[None].to(target_device)).softmax(1)[0].cpu().numpy()
            mask = restore_probabilities(probabilities, geometry)
            mask_file = Path("masks") / relative.parent / (relative.name + ".mask.png")
            overlay_file = Path("overlays") / relative.parent / (relative.name + ".overlay.png")
            for destination in (mask_file, overlay_file):
                (output/destination).parent.mkdir(parents=True, exist_ok=True)
            Image.fromarray(mask).save(output/mask_file)
            overlay(image, mask).save(output/overlay_file)
            rows.append({"image": relative.as_posix(), "width": image.width, "height": image.height,
                         "inner_pixels": int((mask == 1).sum()), "outer_pixels": int((mask == 2).sum()),
                         "mask": mask_file.as_posix(), "overlay": overlay_file.as_posix()})
    with (output/"predictions.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["image", "width", "height", "inner_pixels", "outer_pixels", "mask", "overlay"])
        writer.writeheader(); writer.writerows(rows)
    summary = {"created_at": utc_now(), "model_type": state["model_type"], "checkpoint_sha256": sha256(Path(checkpoint)),
               "dataset_fingerprint": state.get("dataset_fingerprint"), "classes": CLASSES,
               "device": str(target_device), "image_size": state["image_size"], "images_processed": len(rows),
               "images_failed": len(failures), "failures": failures, "elapsed_seconds": time.perf_counter()-started,
               "decision": "per-pixel argmax; no automated part acceptance decision", "native_geometry": True}
    atomic_json(output/"summary.json", summary)
    if not rows:
        raise RuntimeError("No image could be processed. See summary.json for image decoding failures.")
    return summary
