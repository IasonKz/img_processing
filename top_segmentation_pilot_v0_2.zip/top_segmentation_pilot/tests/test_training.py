"""Geometry/metric checks run without Torch; model checks run when it is installed."""
from __future__ import annotations

import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
from PIL import Image

from topseg.inference import (confusion_matrix, fit_geometry, metrics_from_confusion,
                             overlay, prepare_image, prepare_mask, restore_probabilities)
from topseg.training import inspect_training_masks, split_groups


class GeometryTests(unittest.TestCase):
    def test_fit_preserves_aspect_and_central_padding(self):
        g = fit_geometry(100, 50, 64)
        self.assertEqual((g["resized_width"], g["resized_height"], g["top"], g["left"]), (64, 32, 16, 0))

    def test_large_native_image_is_recorded_without_source_mutation(self):
        image = Image.new("RGB", (1300, 800), (100, 150, 200))
        before = image.tobytes()
        array, g = prepare_image(image, 64)
        self.assertEqual(array.shape, (3, 64, 64))
        self.assertEqual((g["width"], g["height"]), (1300, 800))
        self.assertEqual(image.tobytes(), before)

    def test_mask_padding_is_ignore_and_labels_remain_discrete(self):
        mask = np.zeros((50, 100), dtype=np.uint8)
        mask[10:20, 10:20], mask[30:40, 70:80] = 1, 2
        result = prepare_mask(mask, fit_geometry(100, 50, 64))
        self.assertEqual(set(np.unique(result)), {0, 1, 2, 255})
        self.assertTrue((result[:16] == 255).all())
        self.assertTrue((result[48:] == 255).all())

    def test_restoration_discards_padding_before_interpolation(self):
        g = fit_geometry(101, 47, 64)
        p = np.zeros((3, 64, 64), dtype=np.float32)
        p[2] = 1
        y, h = g["top"], g["resized_height"]
        p[:, y:y+h] = 0
        p[1, y:y+h] = 1
        result = restore_probabilities(p, g)
        self.assertEqual(result.shape, (47, 101))
        self.assertTrue((result == 1).all())

    def test_unknown_annotation_labels_rejected(self):
        with self.assertRaises(ValueError):
            prepare_mask(np.full((32, 32), 255, dtype=np.uint8), fit_geometry(32, 32, 32))

    def test_mask_geometry_mismatch_rejected(self):
        with self.assertRaises(ValueError):
            prepare_mask(np.zeros((32, 33), np.uint8), fit_geometry(32, 32, 32))

    def test_nonfinite_probabilities_rejected(self):
        p = np.zeros((3, 32, 32)); p[1, 0, 0] = np.nan
        with self.assertRaises(ValueError):
            restore_probabilities(p, fit_geometry(32, 32, 32))

    def test_overlay_preserves_nondefect_pixels(self):
        image = Image.new("RGB", (64, 32), (100, 100, 100))
        mask = np.zeros((32, 64), np.uint8); mask[0, 0] = 1
        result = np.asarray(overlay(image, mask))
        self.assertTrue((result[1:] == 100).all())
        self.assertGreater(result[0, 0, 0], 100)

    def test_disappearing_native_component_is_reported(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            mask = np.zeros((200, 200), np.uint8)
            mask[0, 0], mask[50:100, 50:100] = 1, 2
            Image.fromarray(mask).save(root/"mask.png")
            rows = [{"id": "a", "mask": "mask.png", "width": 200, "height": 200}]
            evidence = inspect_training_masks(rows, root, 32)
            self.assertEqual(evidence[0]["lost_components"]["inner"], 1)
            self.assertEqual(evidence[0]["lost_components"]["outer"], 0)
            self.assertEqual(rows[0]["defect_classes"], [1, 2])


class MetricTests(unittest.TestCase):
    def test_empty_foreground_is_not_perfect(self):
        target = np.zeros((4, 4), np.uint8)
        result = metrics_from_confusion(confusion_matrix(target, target))
        self.assertIsNone(result["foreground_mean_iou"])
        self.assertIsNone(result["classes"]["inner"]["dice"])
        self.assertEqual(result["pixel_accuracy"], 1)

    def test_missed_small_defect_does_not_hide_behind_background(self):
        target = np.zeros((100, 100), np.uint8); target[0, 0] = 1
        result = metrics_from_confusion(confusion_matrix(target, np.zeros_like(target)))
        self.assertAlmostEqual(result["pixel_accuracy"], .9999)
        self.assertEqual(result["foreground_mean_iou"], 0)
        self.assertEqual(result["classes"]["inner"]["recall"], 0)

    def test_false_positive_absent_class_penalized(self):
        target = np.zeros((8, 8), np.uint8)
        predicted = target.copy(); predicted[0, 0] = 2
        result = metrics_from_confusion(confusion_matrix(target, predicted))
        self.assertEqual(result["classes"]["outer"]["iou"], 0)
        self.assertIsNone(result["classes"]["outer"]["recall"])

    def test_padding_does_not_enter_confusion(self):
        target = np.array([[255, 1], [0, 2]], np.uint8)
        predicted = np.array([[2, 1], [0, 2]], np.uint8)
        cm = confusion_matrix(target, predicted)
        self.assertEqual(cm.sum(), 3)
        self.assertEqual(metrics_from_confusion(cm)["foreground_mean_dice"], 1)

    def test_metrics_separate_inner_outer(self):
        target = np.array([[1, 1], [2, 2]], np.uint8)
        predicted = np.ones((2, 2), np.uint8)
        result = metrics_from_confusion(confusion_matrix(target, predicted))
        self.assertEqual(result["classes"]["inner"]["iou"], .5)
        self.assertEqual(result["classes"]["outer"]["iou"], 0)
        self.assertEqual(result["foreground_mean_iou"], .25)


class GroupSplitTests(unittest.TestCase):
    def rows(self):
        return [{"id": str(i), "group": f"unit{i//2}", "defect_classes": [1, 2]} for i in range(12)]

    def test_repeated_unit_views_stay_together(self):
        rows = self.rows(); split = split_groups(rows, .3, 42)
        train, val = set(split["train_ids"]), set(split["validation_ids"])
        for i in range(0, 12, 2):
            self.assertEqual(str(i) in train, str(i+1) in train)
        self.assertFalse(train & val)
        self.assertEqual(train | val, {r["id"] for r in rows})

    def test_split_is_deterministic(self):
        self.assertEqual(split_groups(self.rows(), .3, 42), split_groups(self.rows(), .3, 42))

    def test_predecessor_validation_cannot_move_to_training(self):
        split = split_groups(self.rows(), .2, 78, previous={"unit0": "validation", "unit1": "train"})
        self.assertEqual(split["group_split"]["unit0"], "validation")
        self.assertEqual(split["group_split"]["unit1"], "train")

    def test_missing_classes_rejected_when_required(self):
        rows = self.rows()
        for row in rows:
            row["defect_classes"] = [1]
        with self.assertRaisesRegex(ValueError, "both inner and outer"):
            split_groups(rows)

    def test_one_defect_class_allowed_explicitly(self):
        rows = self.rows()
        for row in rows:
            row["defect_classes"] = [1]
        split = split_groups(rows, require_both=False)
        self.assertTrue(split["train_ids"])

    def test_clean_only_dataset_rejected(self):
        rows = self.rows()
        for row in rows:
            row["defect_classes"] = []
        with self.assertRaisesRegex(ValueError, "no defect pixels"):
            split_groups(rows, require_both=False)

    def test_single_physical_unit_rejected(self):
        rows = self.rows()
        for row in rows:
            row["group"] = "same-unit"
        with self.assertRaisesRegex(ValueError, "two independent groups"):
            split_groups(rows)


TORCH_AVAILABLE = importlib.util.find_spec("torch") is not None


@unittest.skipUnless(TORCH_AVAILABLE, "PyTorch is not installed; actual neural execution was not validated.")
class TorchTests(unittest.TestCase):
    def test_model_backward_and_ignored_padding(self):
        import torch
        from topseg.model import SmallUNet, segmentation_loss
        torch.set_num_threads(1)
        torch.manual_seed(42)
        model = SmallUNet(4)
        logits = model(torch.randn(2, 3, 33, 47))
        self.assertEqual(tuple(logits.shape), (2, 3, 33, 47))
        target = torch.zeros((2, 33, 47), dtype=torch.long)
        target[:, :4] = 255; target[:, 10:14, 10:14] = 1; target[:, 20:24, 20:24] = 2
        logits.retain_grad()
        loss = segmentation_loss(logits, target, torch.ones(3))
        loss.backward()
        self.assertTrue(torch.isfinite(loss))
        self.assertEqual(float(logits.grad[:, :, :4].abs().sum()), 0)
        self.assertGreater(float(model.head.weight.grad.abs().sum()), 0)

    def test_actual_train_finetune_predict_with_approved_snapshot(self):
        from topseg.common import DEFAULTS, read_json
        from topseg.project import Project
        from topseg.training import train
        from topseg.inference import load_model, predict
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            cfg = copy.deepcopy(DEFAULTS)
            cfg.update(input_dir=str(root/"input"), project_dir=str(root/"project"), output_dir=str(root/"output"))
            cfg["training"].update(epochs=2, batch_size=2, image_size=64, base_channels=4, cpu_threads=1, min_images=5)
            (root/"input").mkdir()
            for i in range(6):
                image = np.random.default_rng(i).integers(80, 160, (48, 80, 3), dtype=np.uint8)
                image[10:16, 10:16] = 255; image[25:32, 55:64] = 0
                Image.fromarray(image).save(root/"input"/f"unit{i}.png")
            project = Project(cfg); project.import_images()
            for row in project.items():
                mask = np.zeros((48, 80), np.uint8)
                mask[10:16, 10:16] = 1; mask[25:32, 55:64] = 2
                # Labels now follow the boundary: keep both synthetic defect
                # classes represented regardless of the editor's default ROI.
                roi = {'type': 'polygon', 'points': [
                    {'x': 3, 'y': 3}, {'x': 30, 'y': 3},
                    {'x': 30, 'y': 23}, {'x': 3, 'y': 23}]}
                project.save_annotation(row["id"], mask, roi=roi,
                                        expected_revision=row["revision"], approved=True)
            run = train(cfg)
            state = read_json(run/"model_state.json")
            self.assertEqual(state["status"], "completed")
            for asset in ("best.pt", "last.pt", "report.html", "history.csv", "split.json", "validation/predictions.csv"):
                self.assertTrue((run/asset).is_file(), asset)
            _, old, _ = load_model(run/"best.pt")
            cfg["training"]["epochs"] = 1
            updated = train(cfg, run/"best.pt")
            _, new, _ = load_model(updated/"best.pt")
            self.assertEqual(old["group_split"], new["group_split"])
            self.assertTrue((updated/"comparison.json").is_file())
            summary = predict(run/"best.pt", root/"input", root/"predictions")
            self.assertEqual(summary["images_processed"], 6)
            for mask_file in (root/"predictions"/"masks").rglob("*.png"):
                mask = np.asarray(Image.open(mask_file))
                self.assertEqual(mask.shape, (48, 80))
                self.assertTrue(np.isin(mask, [0, 1, 2]).all())


if __name__ == "__main__":
    unittest.main()
