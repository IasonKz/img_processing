# Workspace update validation

Verified in a Linux validation environment with Python 3.12, torch 2.7.1+CPU, torchvision 0.22.1 and system Chromium. All data were generated test fixtures. No production inspection images or GPU training were used.

- The existing Python regression suite plus the new workspace tests passed (six existing skips).
- The 111 imported segmentation tests and 45 subtests passed. After integration changes, the project/server/studio subset passed again: 26 tests and 17 subtests.
- New operator tests verify collision-safe relabel/undo, quarantine, stale hashes, path containment, disjoint development/classification trays, exact optimizer results against exhaustive enumeration for all four goals and review limits, cancellation, trusted operator labels, deployment output/history, source hash changes, ZIP traversal, mounted CSRF isolation, project recovery, literal native-picker paths and refusal to kill unrelated PIDs.
- JavaScript dashboard regression checks for v4, v5 and quality passed.
- A real Chromium GUI run used a randomly initialized ResNet18 checkpoint to execute CPU inference. It completed cleaning/undo, tray role saving, classification-only tray inference, Left/Right navigation, score cards, two-dataset tuning, saved decisions, force-stop of an owned worker, frozen ZIP deployment, TOP import/draft/approval and BOTTOM project isolation. Unsaved TOP notes survived switching to BOTTOM and back. Browser errors: none.
- The Python wheel built successfully and contained the complete TOP/BOTTOM web assets, offline Plotly bundle, NILT logo, workspace UI, native picker helper and segmentation CLI. `pip check` and `git diff --check` passed.
- After the night-mode/navigation update, 41 workspace/project/server/studio tests and 17 subtests passed, along with all three JavaScript dashboard regression checks. Chromium verified persisted light/night mode, all six segmentation sections in the outer sidebar, fullscreen entry/exit, preserved drafts across TOP/BOTTOM, and one page scroll at 1550, 1100 and 760 px widths. A focused follow-up verified that shortcuts and save feedback remain visible in fullscreen, with no browser errors.

The randomized checkpoint checks inference plumbing only. Its scores, charts and decisions do not measure pretrained model quality. Windows 11 native dialogs and CUDA hardware were not available in this environment; the native-picker subprocess contract was tested with mocks.

## Reproduce

```bash
python -m unittest discover -s tests
python -m pytest tests/segmentation -q
node tests/test_v4_ui.cjs
node tests/test_v5_ui.cjs
node tests/test_v61_quality_ui.cjs
```

The imported studio's pytest tests need pytest. Browser checks need Playwright and Chromium, as with the existing GUI tests. From the repository root:

```bash
PYTHONPATH=. python tests/make_workspace_demo.py /tmp/workspace-demo
python inspection.py dashboard --config /tmp/workspace-demo/project.yaml --port 18769 --no-browser
# In a testing terminal while this fixture dashboard is running:
node tests/browser_workspaces.cjs http://127.0.0.1:18769 /tmp/workspace-demo /tmp/workspace-screenshots
```

Use a fresh fixture directory for a clean run. No additional terminal is needed for normal model training, tuning or annotation in the product.

## GUI captures

All screenshots below show synthetic data and unqualified model scores.

- [Night mode and cropped NIL Technology logo](validation/workspaces/SYNTHETIC-night-mode.png)
- [Annotation in full screen](validation/workspaces/SYNTHETIC-annotation-fullscreen.png)
- [Data cleaning](validation/workspaces/SYNTHETIC-data-cleaning.png)
- [Per-image score evidence](validation/workspaces/SYNTHETIC-image-scores.png)
- [Threshold tuning](validation/workspaces/SYNTHETIC-thresholds.png)
- [Deployment](validation/workspaces/SYNTHETIC-deployment.png)
- [TOP annotation](validation/workspaces/SYNTHETIC-top-annotation.png)
- [BOTTOM workspace](validation/workspaces/SYNTHETIC-bottom-workspace.png)
