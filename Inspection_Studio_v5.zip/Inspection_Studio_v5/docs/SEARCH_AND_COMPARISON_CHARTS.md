# Search analytics and model comparisons

Plots report recorded results from the active experiment. An empty plot means the required evidence is not available yet; it is not a zero score. Use the trial table and error log to distinguish complete, pruned, paused, timed-out, and failed work.

## During search

| View | Question it answers | How to read it |
| --- | --- | --- |
| Objective history | Is the search finding stronger trials? | Compare completed objective values and the running best. Each architecture has its own study and trial numbering. |
| Learning-curve overlays | Which trials improve, plateau, or become unstable? | Validation AP trends compare ranking quality. Different epoch durations mean equal epoch counts are not equal compute. |
| Duration versus performance | What quality is obtained for the observed training cost? | A slow trial can be useful, but a short failed or timed-out trial is not a low-scoring completed trial. |
| Parameter relationship | Where have useful parameter values occurred? | Log-scaled learning-rate axes distinguish orders of magnitude. Filter/compare within an architecture before inferring a trend. |
| Parallel coordinates | Which parameter combinations produced particular results? | Each line is a recorded combination; correlation, inactive parameters, and small sample counts can mislead. |

The model-search objective can be AP, ROC AUC, or balanced accuracy. These are different quantities. Compare objective curves only when the objective definition and data role match. The separately recorded AP remains AP even when another objective guides the search.

No relationship plot establishes causation or replaces a controlled comparison. With one completed trial per architecture, there is little evidence about the value of a hyperparameter range. Increase trials and budget, narrow the architecture shortlist, or compare deliberate variants while preserving the evaluation design.

## After candidates are finalized

The **Compare models** view uses the recorded selection split. Its combined metric plots and confusion-matrix grid let you inspect candidates on the same evidence. A calibration preview, selection result, and final-test result must never be presented as if they were the same measurement.

Bad is the positive class:

| Reference | Predicted BAD | Predicted GOOD |
| --- | --- | --- |
| BAD | True positive: defect caught | False negative: bad escape |
| GOOD | False positive: unnecessary reject | True negative: good accepted |

Read raw counts alongside rates. A result on ten bad images has different uncertainty from the same fraction on a thousand independent bad units. AP measures ranking across thresholds; higher AP does not itself tell you how many good images are rejected at the saved operating point.

For an operating comparison, inspect bad escape and good reject together at each candidate's saved decision. If comparing a shared error target, use calibration data to choose that target's threshold, freeze it, then assess on the separate selection data. Do not retune on final-test labels.

## Systems with REVIEW

A triage or cascade can abstain. Its confusion table includes REVIEW, and the report must include automatic coverage and review workload. Accuracy conditional on automatic decisions can rise merely because more images go to review. Compare full-system bad escapes, good rejects, review rate, counts, and runtime together.

Weighted ensembles and stacking may improve complementary errors, but adding models is not evidence of improvement. A cascade's early GOOD decisions never reach later stages; inspect stage traces for missed defects.

## Practical comparison sequence

1. Verify that both candidates completed and use the same audited input and split assignments.
2. Compare AP/ROC AUC for ranking, then saved-threshold confusion counts and both error rates.
3. Open missed bad images and unnecessary good rejects in Image review.
4. Check whether mistakes cluster by tray, capture condition, reference-label ambiguity, or defect type.
5. Freeze the chosen model or complete decision system before its independent final evaluation.
6. Retain the complete experiment and system artifacts so plots remain reproducible.
