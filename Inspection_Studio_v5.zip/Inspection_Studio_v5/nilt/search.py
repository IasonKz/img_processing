"""Bounded, resumable Optuna studies sharing one immutable dataset manifest.

Only train and validation rows reach trial training. Calibration and selection
are deferred until the validation shortlist has been frozen. The final test is
never touched by this module. SQLite and checkpoint paths are run-relative.
"""
from __future__ import annotations

import gc
import math
from pathlib import Path
import time
import traceback

from .common import (merge_dict, read_json, run_lock, safe_relative, sha_file,
                     utc_now, write_csv, write_json)
from .custom_search import OBJECTIVES, active_parameters, finite_choices, resolved_space, validate_settings


def _optuna():
    try:
        import optuna
    except ImportError as exc:
        raise RuntimeError("Optuna is not installed. Install the project requirements in this environment.") from exc
    return optuna


def search_settings(cfg):
    return validate_settings(cfg)


def suggest_config(trial, model, cfg):
    """Explicit conditional spaces; resource and image geometry stay fixed."""
    settings = search_settings(cfg)
    space = resolved_space(cfg, model)
    proposed = merge_dict(cfg, {"models": [model], "seeds": [int(cfg["seeds"][0])]})

    def sample(key):
        spec = space[key]
        if spec["kind"] == "fixed":
            return trial.suggest_categorical(key, [spec["value"]])
        if spec["kind"] == "choices":
            return trial.suggest_categorical(key, spec["values"])
        if settings["sampler"] == "grid":
            return trial.suggest_categorical(key, finite_choices(spec, limit=settings["max_grid_combinations"]))
        kwargs = {"log": spec.get("log", False)}
        if "step" in spec:
            kwargs["step"] = spec["step"]
        if key in {"effective_batch_size", "warmup_epochs", "coreset_size", "projection_dim"}:
            return trial.suggest_int(key, int(spec["low"]), int(spec["high"]), **kwargs)
        return trial.suggest_float(key, float(spec["low"]), float(spec["high"]), **kwargs)

    if model == "patchcore":
        pc = proposed["patchcore"]
        cap = int(pc["reservoir_size"])
        pc["coreset_size"] = int(sample("coreset_size"))
        pc["projection_dim"] = int(sample("projection_dim"))
        # Backbones and image geometry are deliberately fixed: switching a
        # backbone would require a separately declared local weight contract.
        if pc["coreset_size"] > cap:
            raise ValueError("Optuna coreset size exceeds the configured reservoir size.")
        return proposed

    training = proposed["training"]
    training["min_finetune_epochs"] = int(settings["min_finetune_epochs"])
    training["mode"] = sample("mode")
    training["optimizer"] = sample("optimizer")
    if training["optimizer"] == "sgd":
        training["momentum"] = sample("momentum")
    training["scheduler"] = sample("scheduler")
    training["head_learning_rate"] = sample("head_learning_rate")
    training["weight_decay"] = sample("weight_decay")
    training["imbalance"] = sample("imbalance")
    if training["imbalance"] == "weighted_loss":
        training["max_class_weight"] = float(sample("max_class_weight"))
    batch = int(training["batch_size"])
    effective = int(sample("effective_batch_size"))
    if effective < batch or effective % batch:
        raise ValueError("Effective batch choices must be positive multiples of training.batch_size.")
    training["accumulation_steps"] = effective // batch
    if training["mode"] == "head_only":
        training["warmup_epochs"] = 0
    else:
        training["learning_rate"] = sample("learning_rate")
        max_warmup = max(0, int(training["epochs"]) - int(settings["min_finetune_epochs"]))
        training["warmup_epochs"] = int(sample("warmup_epochs"))
        if training["warmup_epochs"] > max_warmup:
            raise ValueError("Warmup leaves fewer than min_finetune_epochs within the trial epoch budget.")
    return proposed


def _active_parameters(space, model):
    return active_parameters(space, model)


def _sampler(model, cfg, count=0):
    optuna = _optuna()
    settings = search_settings(cfg)
    seed = int(settings["seed"]) + count * 1009
    seed %= 2**32
    if settings["sampler"] == "random":
        return optuna.samplers.RandomSampler(seed=seed)
    if settings["sampler"] == "grid":
        # GridSampler.after_trial calls study.stop(), which is valid only in
        # optimize(), not this checkpoint-aware ask/tell scheduler. Exhaustion
        # is enforced by _architecture_stop_reason before the next ask().
        class AskTellGridSampler(optuna.samplers.GridSampler):
            def after_trial(self, study, trial, state, values):
                return None

        space = resolved_space(cfg, model)
        grid = {key: finite_choices(space[key], limit=settings["max_grid_combinations"])
                for key in sorted(_active_parameters(space, model))}
        return AskTellGridSampler(grid, seed=int(settings["seed"]))
    return optuna.samplers.TPESampler(seed=seed, n_startup_trials=int(settings["startup_trials"]))


def _pruner(cfg):
    optuna = _optuna()
    settings = search_settings(cfg)
    name = settings["pruner"]
    if name == "none":
        return optuna.pruners.NopPruner()
    if name == "median":
        return optuna.pruners.MedianPruner(
            n_startup_trials=int(settings["pruner_startup_trials"]),
            n_warmup_steps=int(settings["pruner_warmup_steps"]),
            interval_steps=int(settings["pruner_interval_steps"]))
    minimum = max(1, int(settings["pruner_warmup_steps"]), int(settings["min_finetune_epochs"]))
    reduction = int(settings["pruner_reduction_factor"])
    if name == "successive_halving":
        return optuna.pruners.SuccessiveHalvingPruner(min_resource=minimum, reduction_factor=reduction)
    return optuna.pruners.HyperbandPruner(min_resource=minimum,
        max_resource=max(minimum, int(cfg["training"]["epochs"])), reduction_factor=reduction)


def _architecture_stop_reason(study, settings):
    trials = study.get_trials(deepcopy=False)
    # Explicitly paused work remains resumable even after a trial count cap.
    if any(t.state.name == "RUNNING" for t in trials):
        return None
    failures = sum(t.state.name == "FAIL" and t.user_attrs.get("outcome") not in {"TIMEOUT", "TIMEOUT_RESUMABLE"}
                   for t in trials)
    if settings["max_failed_trials_per_model"] and failures >= settings["max_failed_trials_per_model"]:
        return "failure_limit"
    complete = sorted((t for t in trials if t.state.name == "COMPLETE"), key=lambda t: t.number)
    patience = int(settings["study_patience_trials"])
    if patience and len(complete) > patience:
        best, stale = float("-inf"), 0
        for trial in complete:
            if trial.value > best + float(settings["minimum_improvement"]):
                best, stale = trial.value, 0
            else:
                stale += 1
        if stale >= patience:
            return "study_patience"
    if sum(t.state.name != "WAITING" for t in trials) >= settings["max_trials_per_model"]:
        return "trial_limit"
    if settings["sampler"] == "grid" and study.sampler.is_exhausted(study):
        return "grid_exhausted"
    return None


def _study(model, cfg, run):
    optuna = _optuna()
    settings = search_settings(cfg)
    database = (Path(run) / "search" / "optuna.sqlite3").resolve()
    database.parent.mkdir(parents=True, exist_ok=True)
    sampler = _sampler(model, cfg)
    pruner = _pruner(cfg)
    study = optuna.create_study(study_name=model, storage="sqlite:///" + database.as_posix(),
                                load_if_exists=True, direction="maximize", sampler=sampler, pruner=pruner)
    objective = settings["objective"]
    recorded_objective = study.user_attrs.get("objective", "validation_ap")
    if study.trials and recorded_objective != objective:
        raise ValueError("An existing study uses a different objective. Start a new experiment.")
    study.set_user_attr("objective", objective)
    # SQLite stores completed observations, not a sampler's random generator.
    # Derive a distinct reproducible continuation seed rather than replaying
    # the first startup samples on every process restart.
    count = len(study.get_trials(deepcopy=False))
    if count:
        study.sampler = _sampler(model, cfg, count)
    elif model != "patchcore" and settings["enqueue_presets"] and settings["sampler"] != "grid":
        space = resolved_space(cfg, model)
        modes = finite_choices(space["mode"])
        for mode in ("head_only", "full"):
            if mode not in modes:
                continue
            baseline = {"mode": mode}
            defaults = {"optimizer": "adamw", "scheduler": "cosine", "imbalance": "weighted_loss",
                        "max_class_weight": 4.,
                        "effective_batch_size": cfg["training"]["batch_size"] * cfg["training"]["accumulation_steps"]}
            for key, value in defaults.items():
                spec = space[key]
                if spec["kind"] != "range" and value in finite_choices(spec):
                    baseline[key] = value
            for key, value, bounds in (("head_learning_rate", 1e-3, [1e-4, 3e-3]),
                                        ("weight_decay", 1e-4, [1e-6, 1e-3]),
                                        ("learning_rate", 1e-5, [1e-6, 1e-4])):
                if key == "learning_rate" and mode == "head_only":
                    continue
                spec = space[key]
                allowed = (spec["low"] <= value <= spec["high"] if spec["kind"] == "range"
                           else value in finite_choices(spec))
                if allowed and not (spec["kind"] == "range" and "step" in spec):
                    baseline[key] = value
            study.enqueue_trial(baseline, user_attrs={"baseline": mode}, skip_if_exists=True)
    return study


def _resume_or_ask(study):
    optuna = _optuna()
    unfinished = study.get_trials(deepcopy=False, states=(optuna.trial.TrialState.RUNNING,))
    if unfinished:
        if len(unfinished) > 1:
            raise ValueError("This local sequential study has multiple unfinished trials; inspect the SQLite study.")
        # Optuna's Trial constructor accepts its persisted storage identifier.
        # The identifier is retained by FrozenTrial across process restarts.
        return optuna.trial.Trial(study, unfinished[0]._trial_id), True
    return study.ask(), False


def _trial_rows(studies):
    import json
    rows = []
    for model, study in studies.items():
        for trial in study.get_trials(deepcopy=False):
            attrs = trial.user_attrs
            rows.append({
                "model": model, "trial": trial.number, "state": trial.state.name,
                "outcome": attrs.get("outcome", trial.state.name), "value": trial.value,
                "objective": study.user_attrs.get("objective", "validation_ap"),
                "validation_ap": attrs.get("validation_ap", trial.value if study.user_attrs.get("objective", "validation_ap") == "validation_ap" else None),
                "seconds": attrs.get("elapsed_seconds", 0),
                "checkpoint": attrs.get("checkpoint", ""),
                "trial_config": attrs.get("trial_config", ""),
                "params_json": json.dumps(trial.params, sort_keys=True),
                "error": attrs.get("error", ""),
            })
    return rows


def _publish(run, studies, status, deadline=None, **details):
    rows = _trial_rows(studies)
    write_csv(Path(run) / "trials.csv", rows,
              ["model", "trial", "state", "outcome", "value", "objective", "validation_ap", "seconds", "checkpoint", "trial_config", "params_json", "error"])
    complete = [r for r in rows if r["state"] == "COMPLETE"]
    payload = {
        "status": status, "total_trials": sum(r["state"] != "WAITING" for r in rows),
        "queued_trials": sum(r["state"] == "WAITING" for r in rows), "completed_trials": len(complete),
        "pruned_trials": sum(r["state"] == "PRUNED" for r in rows),
        "failed_trials": sum(r["state"] == "FAIL" and r["outcome"] not in ("TIMEOUT", "TIMEOUT_RESUMABLE") for r in rows),
        "timed_out_trials": sum(r["outcome"] in ("TIMEOUT", "TIMEOUT_RESUMABLE") for r in rows),
        "objective": next(iter(studies.values())).user_attrs.get("objective", "validation_ap") if studies else "validation_ap",
        "best_objective_value": {name: max((r["value"] for r in complete if r["model"] == name), default=None)
                               for name in studies},
        "best_validation_ap": {name: max((r["validation_ap"] for r in complete if r["model"] == name and r["validation_ap"] is not None), default=None)
                               for name in studies},
        "deadline": deadline, "remaining_seconds": max(0., deadline - time.time()) if deadline else None,
        "current_model": None, "current_trial": None, "updated_at": utc_now(), **details,
    }
    # Architecture-level stop reasons survive final selection status updates.
    stop_path = Path(run) / "search_stopping.json"
    if stop_path.exists():
        payload["architecture_stops"] = read_json(stop_path).get("architecture_stops", {})
    write_json(Path(run) / "search_status.json", payload)
    return payload


def _control_reason(run):
    path = Path(run) / "control.json"
    if path.exists():
        action = read_json(path).get("action")
        if action in ("pause", "stop"):
            return "operator_" + action
        if read_json(path).get("stop"):
            return "operator_stop"
    return None


def _clean_memory():
    gc.collect()
    try:
        from .engine import torch_modules
        torch, _ = torch_modules()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except ImportError:
        pass


def _run_trial(run, model, study, rows, cfg, studies, trial_deadline, overall_deadline):
    from .engine import TrainingStopped, train_one
    optuna = _optuna()
    trial, resumed = _resume_or_ask(study)
    target = Path(run) / "search" / model / f"trial_{trial.number:05d}"
    config_path = target / "config.json"
    started = time.time()
    prior_seconds = float(trial.user_attrs.get("elapsed_seconds", 0))
    abandoned_start = trial.user_attrs.get("session_started_at")
    if abandoned_start is not None:
        abandoned_end = min(started, float(trial.user_attrs.get("session_deadline", started)))
        prior_seconds += max(0., abandoned_end - float(abandoned_start))
    settings = search_settings(cfg)
    timeout = float(settings["trial_timeout_seconds"])
    if timeout:
        trial_deadline = min(trial_deadline, started + max(0., timeout - prior_seconds))
    if resumed and config_path.exists():
        trial_cfg = read_json(config_path)
        expected = trial.user_attrs.get("trial_config_sha256")
        if expected and sha_file(config_path) != expected:
            raise ValueError("Saved trial configuration changed; do not modify experiments in place.")
        # Portable dependency paths and runtime device are runtime concerns.
        for key in ("device", "cpu_threads", "num_workers", "data_root", "weights_dir"):
            trial_cfg[key] = cfg[key]
    else:
        trial_cfg = suggest_config(trial, model, cfg)
        write_json(config_path, trial_cfg)
        trial.set_user_attr("trial_config", config_path.relative_to(run).as_posix())
        trial.set_user_attr("trial_config_sha256", sha_file(config_path))
    trial.set_user_attr("outcome", "RUNNING")
    trial.set_user_attr("session_started_at", started)
    trial.set_user_attr("session_deadline", trial_deadline)
    trial.set_user_attr("elapsed_seconds", prior_seconds)

    def stop_check():
        reason = _control_reason(run)
        if reason:
            return reason
        return "trial_time_slice" if time.time() >= trial_deadline else False

    def callback(progress):
        epoch = int(progress.get("epoch", progress.get("current_epoch", 0)))
        value = float(progress.get("best_objective_value", progress["best_val_pr_auc_bad"]))
        if not math.isfinite(value):
            raise ValueError("Validation objective is non-finite.")
        trial.report(value, step=epoch)
        trial.set_user_attr("last_progress", progress)
        trial.set_user_attr("elapsed_seconds", prior_seconds + time.time() - started)
        trial.set_user_attr("session_started_at", time.time())
        _publish(run, studies, "SEARCHING", overall_deadline,
                 current_model=model, current_trial=trial.number)
        enough_training = (epoch >= int(settings["min_finetune_epochs"]) if trial_cfg["training"].get("mode") == "head_only"
                           else int(progress.get("finetune_epochs", 0)) >= int(settings["min_finetune_epochs"]))
        if model != "patchcore" and progress.get("status") != "completed" and enough_training and trial.should_prune():
            raise optuna.TrialPruned("Pruned after the required training phase.")

    _publish(run, studies, "SEARCHING", overall_deadline, current_model=model, current_trial=trial.number)
    try:
        if time.time() >= trial_deadline:
            raise TrainingStopped("Cumulative trial time budget exhausted before restart.")
        if (target / "completed.json").exists():
            checkpoint = target / "best.pt"
        else:
            checkpoint = train_one(model, int(cfg["seeds"][0]), rows, trial_cfg, target,
                                   progress_callback=callback, stop_check=stop_check)
        meta = read_json(target / "completed.json")
        if sha_file(checkpoint) != meta["checkpoint_sha256"]:
            raise ValueError("Completed trial checkpoint checksum changed.")
        value = float(meta.get("best_objective_value", meta["best_val_pr_auc_bad"]))
        if not math.isfinite(value):
            raise ValueError("Trial produced a non-finite validation score.")
        if settings["objective"] != "validation_ap" and meta.get("objective_metric") != settings["objective"]:
            raise ValueError("Completed checkpoint does not match the requested validation objective.")
        trial.set_user_attr("validation_ap", float(meta["best_val_pr_auc_bad"]))
        trial.set_user_attr("checkpoint", Path(checkpoint).relative_to(run).as_posix())
        trial.set_user_attr("checkpoint_sha256", sha_file(checkpoint))
        early_stopped = (meta.get("kind") == "supervised" and
                         int(meta.get("epochs_ran", trial_cfg["training"]["epochs"])) < int(trial_cfg["training"]["epochs"]))
        trial.set_user_attr("outcome", "EARLY_STOPPED" if early_stopped else "COMPLETE")
        trial.set_user_attr("stop_reason", "epoch_patience" if early_stopped else "completed")
        trial.set_user_attr("elapsed_seconds", prior_seconds + time.time() - started)
        study.tell(trial, value)
        return "complete"
    except optuna.TrialPruned as exc:
        trial.set_user_attr("outcome", "PRUNED")
        trial.set_user_attr("stop_reason", "pruner")
        trial.set_user_attr("error", str(exc))
        trial.set_user_attr("elapsed_seconds", prior_seconds + time.time() - started)
        study.tell(trial, state=optuna.trial.TrialState.PRUNED)
        return "pruned"
    except (TrainingStopped, KeyboardInterrupt) as exc:
        reason = _control_reason(run) or ("keyboard_interrupt" if isinstance(exc, KeyboardInterrupt) else "time_slice")
        trial.set_user_attr("outcome", "INTERRUPTED" if reason != "time_slice" else "TIMEOUT")
        trial.set_user_attr("stop_reason", reason)
        trial.set_user_attr("error", str(exc))
        trial.set_user_attr("elapsed_seconds", prior_seconds + time.time() - started)
        if reason == "time_slice":
            # Time exhaustion is not pruning, poor quality or a zero score.
            # End this trial so automatic scheduling cannot repeatedly resume
            # it and starve other trials. Saved checkpoints remain inspectable.
            study.tell(trial, state=optuna.trial.TrialState.FAIL)
        if isinstance(exc, KeyboardInterrupt):
            raise
        return reason
    except Exception as exc:
        oom = "out of memory" in str(exc).lower()
        trial.set_user_attr("outcome", "OOM" if oom else "FAILED")
        trial.set_user_attr("stop_reason", "out_of_memory" if oom else "exception")
        trial.set_user_attr("error", str(exc))
        trial.set_user_attr("elapsed_seconds", prior_seconds + time.time() - started)
        write_json(target / "failure.json", {"error": str(exc), "traceback": traceback.format_exc(), "oom": oom})
        study.tell(trial, state=optuna.trial.TrialState.FAIL)
        return "oom" if oom else "failed"
    finally:
        # Finished Optuna trials reject attribute updates, so use the storage
        # id only while RUNNING. Completed sessions need no crash recovery.
        if study._storage.get_trial(trial._trial_id).state.name == "RUNNING":
            trial.set_user_attr("session_started_at", None)
        _clean_memory()


def _freeze_shortlist(run, studies, cfg):
    path = Path(run) / "search_shortlist.json"
    if path.exists():
        saved = read_json(path)
        if saved["manifest_sha256"] != sha_file(Path(run) / "manifest.csv"):
            raise ValueError("Search shortlist manifest changed.")
        return saved
    settings = search_settings(cfg)
    candidates, failures = [], []
    for model, study in studies.items():
        complete = [t for t in study.get_trials(deepcopy=False) if t.state.name == "COMPLETE"]
        complete.sort(key=lambda t: (-t.value, t.number))
        if not complete:
            failures.append({"name": model, "error": "No completed trial for this requested architecture within the search budget."})
        for trial in complete[:int(settings["shortlist_per_model"])]:
            attrs = trial.user_attrs
            checkpoint = safe_relative(run, attrs["checkpoint"])
            config = safe_relative(run, attrs["trial_config"])
            if sha_file(checkpoint) != attrs["checkpoint_sha256"] or sha_file(config) != attrs["trial_config_sha256"]:
                raise ValueError("Cannot select a trial whose checkpoint or configuration changed.")
            candidates.append({"name": f"{model}_trial{trial.number:05d}", "architecture": model,
                               "score_type": "anomaly_distance" if model == "patchcore" else "bad_probability_uncalibrated",
                               "val_pr_auc_bad": attrs.get("validation_ap", trial.value if settings["objective"] == "validation_ap" else None),
                               "search_objective": settings["objective"], "search_objective_value": trial.value,
                               "members": [{"checkpoint": attrs["checkpoint"], "sha256": attrs["checkpoint_sha256"],
                                            "architecture": model, "config": attrs["trial_config"],
                                            "config_sha256": attrs["trial_config_sha256"]}]})
    payload = {"created_at": utc_now(), "manifest_sha256": sha_file(Path(run) / "manifest.csv"),
               "selection_rule": f"Top completed trials by {OBJECTIVES[settings['objective']]} per architecture; fixed before calibration/selection.",
               "candidates": candidates, "failures": failures}
    if candidates:
        write_json(path, payload)
    return payload


def _confirm_shortlist(run, shortlist, cfg, rows, deadline):
    """Train declared seeds using fixed shortlisted settings, without retuning.

    Every completed supervised seed enters the candidate mean ensemble.
    PatchCore confirmations are diagnostics; its predefined primary seed stays
    the single deployable member. Seeds are never chosen by their performance.
    Missing confirmations are explicit comparison failures.
    """
    from .engine import TrainingStopped, train_one
    from .workflow import member_runtime_config, write_state
    if shortlist.get("confirmations_finalized"):
        return shortlist
    seeds = [int(s) for s in cfg.get("seeds", [42])[1:]]
    if len(set(cfg.get("seeds", [42]))) != len(cfg.get("seeds", [42])):
        raise ValueError("Confirmation seeds must be distinct.")
    source_cfg = {candidate["name"]: member_runtime_config(run, candidate["members"][0], cfg)
                  for candidate in shortlist["candidates"]}
    tasks = [(candidate, seed) for candidate in shortlist["candidates"] for seed in seeds]
    results = []
    for candidate in shortlist["candidates"]:
        candidate.setdefault("validation_seed_scores", {str(cfg["seeds"][0]): candidate["val_pr_auc_bad"]})
    write_state(run, "CONFIRMING_SEEDS", confirmation_seeds=seeds)
    for index, (candidate, seed) in enumerate(tasks):
        target = Path(run) / "search" / "confirmations" / candidate["name"] / f"seed_{seed}"
        config_path = target / "config.json"
        trial_cfg = source_cfg[candidate["name"]]
        entry = {"candidate": candidate["name"], "model": candidate["architecture"], "seed": seed,
                 "state": "NOT_STARTED", "val_pr_auc_bad": None, "checkpoint": "", "error": "",
                 "role": "diagnostic_only" if candidate["architecture"] == "patchcore" else "ensemble_member",
                 "used_for_prediction": False}
        remaining = deadline - time.time()
        reason = _control_reason(run)
        if remaining <= search_settings(cfg)["minimum_trial_seconds"] or reason:
            entry["state"] = "BUDGET_EXHAUSTED" if not reason else "INTERRUPTED"
            entry["error"] = reason or "Confirmation did not fit the declared budget."
        else:
            stop_at = time.time() + remaining / max(1, len(tasks) - index)
            write_json(config_path, trial_cfg) if not config_path.exists() else None

            def stop_check():
                return _control_reason(run) or time.time() >= stop_at

            try:
                if (target / "completed.json").exists():
                    checkpoint = target / "best.pt"
                else:
                    checkpoint = train_one(candidate["architecture"], seed, rows, trial_cfg, target, stop_check=stop_check)
                meta = read_json(target / "completed.json")
                if sha_file(checkpoint) != meta["checkpoint_sha256"]:
                    raise ValueError("Confirmation checkpoint changed.")
                ap = float(meta["best_val_pr_auc_bad"])
                if not math.isfinite(ap):
                    raise ValueError("Confirmation validation AP must be finite.")
                entry.update(state="COMPLETE", val_pr_auc_bad=ap, checkpoint=Path(checkpoint).relative_to(run).as_posix())
                candidate["validation_seed_scores"][str(seed)] = ap
                if candidate["architecture"] != "patchcore":
                    candidate["members"].append({"checkpoint": entry["checkpoint"], "sha256": sha_file(checkpoint),
                                                  "architecture": candidate["architecture"], "config": config_path.relative_to(run).as_posix(),
                                                  "config_sha256": sha_file(config_path)})
                    entry["used_for_prediction"] = True
            except TrainingStopped as exc:
                entry.update(state="TIMEOUT_RESUMABLE", error=str(exc))
            except Exception as exc:
                entry.update(state="OOM" if "out of memory" in str(exc).lower() else "FAILED", error=str(exc))
            finally:
                _clean_memory()
        if entry["state"] != "COMPLETE":
            shortlist["failures"].append({"name": candidate["name"] + f"_seed{seed}", "error": entry["error"]})
        results.append(entry)
        write_json(Path(run) / "search_confirmations.json", results)
        write_csv(Path(run) / "search_confirmations.csv", results)
        if _control_reason(run):
            # Keep the original frozen shortlist on disk. Completed seed
            # checkpoints are reused, and the interrupted seed can resume.
            return shortlist
    for candidate in shortlist["candidates"]:
        import numpy as np
        values = list(candidate["validation_seed_scores"].values())
        candidate["search_validation_ap"] = candidate["val_pr_auc_bad"]
        candidate["validation_seed_ap_mean"] = float(np.mean(values))
        candidate["validation_seed_ap_std"] = float(np.std(values)) if len(values) > 1 else None
        candidate["confirmation_expected_seeds"] = list(cfg["seeds"])
        candidate["confirmation_complete"] = len(values) == len(cfg["seeds"])
        candidate["validation_ranking_basis"] = ("Search-trial " + OBJECTIVES[search_settings(cfg)["objective"]] + " before fixed-seed confirmation.")
        candidate["confirmation_aggregation"] = ("diagnostic_only_primary_seed_retained"
                                                  if candidate["architecture"] == "patchcore"
                                                  else "mean_scores_of_all_completed_supervised_seeds")
    shortlist["confirmations_finalized"] = True
    write_json(Path(run) / "search_shortlist.json", shortlist)
    return shortlist


def _finalize_search(run, cfg, rows, studies, deadline=None):
    from .engine import TrainingStopped
    from .workflow import select_candidates, write_state
    if (Path(run) / "selected.json").exists():
        _publish(run, studies, "SELECTED", deadline)
        return Path(run)
    shortlist = _freeze_shortlist(run, studies, cfg)
    if not shortlist["candidates"]:
        _publish(run, studies, "SEARCH_PAUSED", deadline, stop_reason="no_completed_trial")
        write_state(run, "SEARCH_PAUSED", error="No trial completed. Inspect failures/timeouts and start a new search with an adjusted budget. Operator-paused work can resume; exhausted trial time limits do not reset.")
        return Path(run)
    if len(cfg.get("seeds", [42])) > 1 and not shortlist.get("confirmations_finalized"):
        shortlist["failures"].append({"name": "seed_confirmations", "error": "Explicit finalization used the saved shortlist before all planned seed confirmations completed."})
        shortlist["confirmations_finalized"] = True
        write_json(Path(run) / "search_shortlist.json", shortlist)

    def stop_check():
        return _control_reason(run) or (deadline is not None and time.time() >= deadline)

    try:
        select_candidates(run, shortlist["candidates"], shortlist["failures"], cfg, rows, stop_check=stop_check)
    except TrainingStopped:
        _publish(run, studies, "SEARCH_FINISHED_PENDING_SELECTION", deadline, stop_reason="selection_limit")
        write_state(run, "SEARCH_FINISHED_PENDING_SELECTION", error="Validation shortlist saved. Selection needs an explicit finalize command within an available time budget.")
        return Path(run)
    _publish(run, studies, "SELECTED", deadline)
    return Path(run)


def _budget_start(run, settings, deadline):
    path = Path(run) / "search_budget.json"
    saved = read_json(path) if path.exists() else {"consumed_seconds": 0.}
    started = time.time()
    if saved.get("session_started_at") is not None:
        # A killed process cannot execute finally. Conservatively account for
        # its last session up to its deadline, never reset a spent budget.
        previous_end = min(started, float(saved.get("deadline", started)))
        saved["consumed_seconds"] = float(saved["consumed_seconds"]) + max(0., previous_end - float(saved["session_started_at"]))
    if deadline is None:
        deadline = started + max(0., float(settings["total_budget_seconds"]) - float(saved["consumed_seconds"]))
    write_json(path, {**saved, "session_started_at": started, "deadline": deadline,
                      "total_budget_seconds": settings["total_budget_seconds"]})
    return started, saved, float(deadline)


def _budget_finish(run, started, saved):
    current = read_json(Path(run) / "search_budget.json")
    current.update(consumed_seconds=float(saved["consumed_seconds"]) + max(0., time.time() - started),
                   session_started_at=None, last_finished_at=utc_now())
    write_json(Path(run) / "search_budget.json", current)


def _persist_contract(run, cfg):
    """The effective search settings are immutable even through Python resume."""
    path = Path(run) / "search_contract.json"
    contract = {"schema_version": 1, "search": search_settings(cfg),
                "models": cfg["models"], "seeds": cfg["seeds"],
                "training": cfg["training"], "pretrained": cfg.get("pretrained", True),
                "image_size": cfg.get("image_size"), "resize": cfg.get("resize"),
                "image_strategy": cfg.get("image_strategy", "full_image"),
                "patches": cfg.get("patches", {}), "augmentation": cfg.get("augmentation", {}),
                "objective": "maximize " + OBJECTIVES[search_settings(cfg)["objective"]],
                "trial_data": ["train", "val"], "final_test_used": False}
    if path.exists():
        if read_json(path) != contract:
            raise ValueError("Search contract changed. Start a new experiment; existing runs are immutable.")
    else:
        write_json(path, contract)


def run_search(run, resume=False, finalize=True, deadline=None):
    """Execute round-robin model studies. ``deadline`` is absolute Unix time.

    The CLI supervisor supplies the deadline *before* audit, so the advertised
    budget includes audit and final selection. Direct Python callers should do
    likewise. Without a supplied deadline, search_budget.json limits cumulative
    time spent in this function across resumes.
    """
    from .engine import check_weights
    from .workflow import open_run, verify_sources, write_state
    run = Path(run).resolve()
    with run_lock(run):
        cfg, rows = open_run(run)
        settings = search_settings(cfg)
        _persist_contract(run, cfg)
        if cfg.get("previous_run"):
            raise ValueError("Optuna studies start from the declared pretrained baseline. Use update for incremental fine-tuning, or create an independent search.")
        if (run / "search" / "optuna.sqlite3").exists() and not resume:
            raise ValueError("An Optuna study already exists. Use resume to continue it.")
        studies = {model: _study(model, cfg, run) for model in cfg["models"]}
        started, saved, deadline = _budget_start(run, settings, deadline)
        try:
            if (run / "selected.json").exists():
                return _finalize_search(run, cfg, rows, studies, deadline)
            if (run / "search_shortlist.json").exists():
                if finalize:
                    (run / "control.json").unlink(missing_ok=True)
                    shortlist = read_json(run / "search_shortlist.json")
                    if not shortlist.get("confirmations_finalized"):
                        development = [row for row in rows if row["split"] in ("train", "val")]
                        _confirm_shortlist(run, shortlist, cfg, development,
                                           time.time() + max(0., deadline - time.time()) * .5)
                    if _control_reason(run):
                        _publish(run, studies, "SEARCH_PAUSED", deadline, stop_reason=_control_reason(run))
                        write_state(run, "SEARCH_PAUSED", error=_control_reason(run))
                        return run
                    return _finalize_search(run, cfg, rows, studies, deadline)
                return run
            if resume:
                (run / "control.json").unlink(missing_ok=True)
            if time.time() >= deadline:
                _publish(run, studies, "SEARCH_PAUSED", deadline, stop_reason="budget_exhausted")
                write_state(run, "SEARCH_PAUSED", error="Cumulative search budget exhausted.")
                return run
            check_weights(cfg)
            verify_sources([row for row in rows if row["split"] in ("train", "val")])
            _record_environment(run, cfg)
            write_state(run, "SEARCHING", error=None)
            # Trial code receives no calibration, selection or final-test rows.
            development = [row for row in rows if row["split"] in ("train", "val")]
            available_seconds = max(0., deadline - time.time())
            confirmation_reserve = settings["confirmation_reserve_fraction"] if len(cfg.get("seeds", [42])) > 1 else 0.
            training_deadline = time.time() + available_seconds * (1. - settings["selection_reserve_fraction"] - confirmation_reserve)
            confirmation_deadline = deadline - available_seconds * settings["selection_reserve_fraction"]
            cursor = 0
            models = list(studies)
            stop_reason = "trial_limit"
            architecture_stops = {}
            while time.time() + settings["minimum_trial_seconds"] < training_deadline:
                reason = _control_reason(run)
                if reason:
                    stop_reason = reason
                    break
                available = []
                for name in models:
                    model_stop = _architecture_stop_reason(studies[name], settings)
                    if model_stop is None:
                        available.append(name)
                    else:
                        architecture_stops[name] = model_stop
                if not available:
                    stop_reason = "all_architectures_stopped"
                    break
                for offset in range(len(models)):
                    model = models[(cursor + offset) % len(models)]
                    if model in available:
                        cursor = (cursor + offset + 1) % len(models)
                        break
                # A single expensive model cannot consume the whole initial
                # comparison budget before another selected model is attempted.
                remaining_models = len(available)
                share = (training_deadline - time.time()) / max(1, remaining_models)
                duration = float(settings["trial_timeout_seconds"]) or max(settings["minimum_trial_seconds"], share)
                trial_deadline = min(training_deadline, time.time() + duration)
                result = _run_trial(run, model, studies[model], development, cfg, studies, trial_deadline, deadline)
                _publish(run, studies, "SEARCHING", deadline)
                if result in ("operator_pause", "operator_stop"):
                    stop_reason = result
                    break
            else:
                stop_reason = "training_budget"
            for name in models:
                architecture_stops[name] = _architecture_stop_reason(studies[name], settings) or stop_reason
            write_json(run / "search_stopping.json", {"stop_reason": stop_reason,
                "architecture_stops": architecture_stops, "at": utc_now(),
                "trial_timeout_policy": "cooperative cumulative timeout; timed-out trials are not automatically resumed"})
            if stop_reason.startswith("operator_"):
                _publish(run, studies, "SEARCH_PAUSED", deadline, stop_reason=stop_reason)
                write_state(run, "SEARCH_PAUSED", error=stop_reason)
                return run
            if finalize and time.time() < deadline:
                shortlist = _freeze_shortlist(run, studies, cfg)
                if shortlist["candidates"]:
                    _confirm_shortlist(run, shortlist, cfg, development, confirmation_deadline)
                if _control_reason(run):
                    _publish(run, studies, "SEARCH_PAUSED", deadline, stop_reason=_control_reason(run))
                    write_state(run, "SEARCH_PAUSED", error=_control_reason(run))
                    return run
                return _finalize_search(run, cfg, rows, studies, deadline)
            _publish(run, studies, "SEARCH_FINISHED_PENDING_SELECTION", deadline, stop_reason=stop_reason)
            write_state(run, "SEARCH_FINISHED_PENDING_SELECTION", error=None)
            return run
        except KeyboardInterrupt:
            _publish(run, studies, "SEARCH_PAUSED", deadline, stop_reason="keyboard_interrupt")
            write_state(run, "SEARCH_PAUSED", error="Operator interrupted; committed checkpoints retained.")
            raise
        finally:
            _budget_finish(run, started, saved)


def finalize_search(run, deadline=None):
    """Finish the frozen validation shortlist without launching training trials."""
    from .workflow import open_run, verify_sources
    run = Path(run).resolve()
    with run_lock(run):
        cfg, rows = open_run(run)
        settings = search_settings(cfg)
        if not (run / "search" / "optuna.sqlite3").exists():
            raise ValueError("This run has no Optuna study.")
        studies = {model: _study(model, cfg, run) for model in cfg["models"]}
        started, saved, deadline = _budget_start(run, settings, deadline)
        try:
            (run / "control.json").unlink(missing_ok=True)
            if time.time() < deadline:
                verify_sources([r for r in rows if r["split"] in ("threshold", "selection")])
            return _finalize_search(run, cfg, rows, studies, deadline)
        finally:
            _budget_finish(run, started, saved)


def _record_environment(run, cfg):
    from .engine import torch_modules, required_weight_names, weight_path
    import importlib.metadata
    import platform
    torch, tv = torch_modules()
    versions = {}
    for name in ("torch", "torchvision", "numpy", "Pillow", "scipy", "scikit-learn", "PyYAML", "optuna"):
        versions[name] = importlib.metadata.version(name)
    (Path(run) / "requirements_snapshot.txt").write_text(
        "\n".join(f"{name}=={version}" for name, version in versions.items()) + "\n", encoding="utf-8")
    write_json(Path(run) / "environment.json", {
        "python": platform.python_version(), "platform": platform.platform(),
        "torch": str(torch.__version__), "torchvision": str(tv.__version__),
        "cuda_available": torch.cuda.is_available(), "cuda_runtime": str(torch.version.cuda),
        "pretrained_sha256": {name: sha_file(weight_path(cfg, name)) for name in required_weight_names(cfg)}
        if cfg.get("pretrained", True) else {}, "packages": versions,
    })
