"""Explicit architecture/backbone pairs; no weight download during studio use."""
import importlib.util

ARCHITECTURES = ['Unet', 'UnetPlusPlus', 'FPN', 'PSPNet', 'DeepLabV3',
                 'DeepLabV3Plus', 'Linknet', 'MAnet', 'PAN', 'UPerNet', 'Segformer', 'DPT']


def catalog():
    entries = [dict(id='small_unet', label='Small U-Net', architecture='SmallUNet',
                    encoder='', base_channels=16, family='Lightweight')]
    for arch in ARCHITECTURES:
        if arch == 'DPT':
            continue
        enc = 'mit_b0' if arch == 'Segformer' else 'resnet18'
        entries.append(dict(id=f'{arch.lower()}_{enc}', label=f'{arch} / {enc}',
                            architecture=arch, encoder=enc, family='Transformer' if arch == 'Segformer' else 'CNN'))
    for arch, enc in [('Unet', 'resnet34'), ('Unet', 'mobilenet_v2'), ('Unet', 'efficientnet-b0'),
                      ('DeepLabV3Plus', 'resnet50'), ('Segformer', 'mit_b2'),
                      ('UPerNet', 'tu-convnext_tiny'), ('DPT', 'tu-vit_small_patch16_224.augreg_in21k'),
                      ('DPT', 'tu-vit_small_patch14_dinov2.lvd142m')]:
        entries.append(dict(id=f'{arch.lower()}_{enc.replace(".", "_")}', label=f'{arch} / {enc}',
                            architecture=arch, encoder=enc, family='Transformer' if arch in ('Segformer','DPT') else 'CNN',
                            **({'kwargs': {'dynamic_img_size': True}, 'pad_multiple': 224 if 'patch14' in enc else 32} if arch=='DPT' else {})))
    available = importlib.util.find_spec('segmentation_models_pytorch') is not None
    torch = importlib.util.find_spec('torch') is not None
    for spec in entries:
        spec['available'] = torch and (spec['architecture']=='SmallUNet' or available)
    return entries


def validate_spec(spec):
    import json
    spec = json.loads(json.dumps(spec))
    if spec.get('architecture') not in ['SmallUNet'] + ARCHITECTURES:
        raise ValueError('Unsupported architecture. Choose a listed SMP architecture or SmallUNet.')
    if not spec.get('id') or not isinstance(spec['id'], str):
        raise ValueError('Every model needs a unique id.')
    if spec['architecture'] != 'SmallUNet' and not isinstance(spec.get('encoder'), str):
        raise ValueError('A model encoder name is required.')
    kwargs = spec.get('kwargs', {})
    if not isinstance(kwargs, dict) or set(kwargs) & {'encoder_weights','classes','in_channels','activation','aux_params','pretrained'}:
        raise ValueError('Do not override weights, class mapping, channels, activation or auxiliary heads in kwargs.')
    return spec


def build_model(spec, initialize=True):
    import os
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['HF_HUB_DISABLE_TELEMETRY'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'
    import torch
    from torch import nn
    from torch.nn import functional as F
    spec = validate_spec(spec)
    if spec['architecture'] == 'SmallUNet':
        from .model import SmallUNet
        net = SmallUNet(int(spec.get('base_channels', 16)))
    else:
        import segmentation_models_pytorch as smp
        cls = getattr(smp, spec['architecture'])
        net = cls(encoder_name=spec['encoder'], encoder_weights=None, in_channels=3,
                  classes=3, activation=None, **spec.get('kwargs', {}))
    # SMP 0.5 rounds non-power-of-two DPT reassembly factors for patch-14
    # backbones. Use a consistent nominal patch-16 pyramid, then resample logits
    # to the actual padded input below. The DINOv2 encoder itself is unchanged.
    if spec['architecture'] == 'DPT' and any(v == 14 for v in net.encoder.output_strides):
        from segmentation_models_pytorch.decoders.dpt.decoder import DPTDecoder
        kw = spec.get('kwargs', {})
        net.decoder = DPTDecoder(encoder_out_channels=net.encoder.out_channels,
            encoder_output_strides=[16]*len(net.encoder.out_channels),
            encoder_has_prefix_tokens=net.encoder.has_prefix_tokens,
            readout=kw.get('decoder_readout','cat'),
            intermediate_channels=kw.get('decoder_intermediate_channels',(256,512,1024,1024)),
            fusion_channels=kw.get('decoder_fusion_channels',256))
        net.initialize()
    # The checkpoint must be an explicit local encoder state_dict; no URL or hub fallback.
    if initialize and spec.get('encoder_checkpoint'):
        from pathlib import Path
        path = Path(spec['encoder_checkpoint']).expanduser()
        if not path.is_file():
            raise ValueError(f'Local encoder weights do not exist: {path}')
        weights = torch.load(path, map_location='cpu', weights_only=True)
        weights = weights.get('state_dict', weights)
        net.encoder.load_state_dict(weights, strict=True)

    class Adapter(nn.Module):
        def __init__(self):
            super().__init__()
            self.net = net
            normalization = spec.get('normalization', 'imagenet' if spec['architecture']!='SmallUNet' else 'unit')
            if normalization not in ('unit', 'imagenet'):
                raise ValueError('normalization must be unit or imagenet.')
            self.register_buffer('mean', torch.tensor([.485,.456,.406] if normalization=='imagenet' else [0.,0.,0.]).view(1,3,1,1))
            self.register_buffer('std', torch.tensor([.229,.224,.225] if normalization=='imagenet' else [1.,1.,1.]).view(1,3,1,1))
            self.multiple = int(spec.get('pad_multiple', 32))
            if not 1 <= self.multiple <= 512:
                raise ValueError('pad_multiple must be between 1 and 512.')

        def forward(self, x):
            h, w = x.shape[-2:]
            y = (x-self.mean)/self.std
            ph, pw = (-h) % self.multiple, (-w) % self.multiple
            y = F.pad(y, (0,pw,0,ph))
            logits = self.net(y)
            logits = F.interpolate(logits, size=y.shape[-2:], mode='bilinear', align_corners=False)
            return logits[..., :h, :w]
    return Adapter()


def encoder_names():
    import segmentation_models_pytorch as smp
    import timm
    return sorted(set(smp.encoders.get_encoder_names()+['tu-'+n for n in timm.list_models()]))
