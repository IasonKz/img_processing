"""Visual Inspection command-line application."""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import sys
import traceback


def build_parser():
    parser = argparse.ArgumentParser(prog="inspection", description="Local visual inspection: training, version management and portable inference.")
    parser.add_argument("--version", action="version", version="Visual Inspection 2.0.0")
    sub = parser.add_subparsers(dest="command", required=True)
    def project_args(p, required=True):
        p.add_argument("--config", required=required)
        p.add_argument("--profile", choices=["laptop", "workstation"], default="laptop")
        p.add_argument("--task", choices=["top", "bottom", "vig"])
    for command, description in (("audit", "Audit data and prepare immutable grouped splits."),
                                 ("run", "Train, tune, compare and select candidates."),
                                 ("download-weights", "Provision public pretrained weights; explicitly online.")):
        p = sub.add_parser(command, help=description)
        project_args(p)
    p = sub.add_parser("doctor", help="Check local installation, configuration and resources.")
    project_args(p, required=False)
    p.add_argument("--deployment", action="store_true", help="Also require ONNX export dependencies.")
    p = sub.add_parser("resume", help="Continue a prepared/interrupted run at a saved epoch boundary.")
    p.add_argument("--run", required=True)
    p.add_argument("--device", choices=["cpu", "cuda", "auto"])
    p.add_argument("--recover-lock", action="store_true", help="Remove an abandoned lock after verifying no operation is running.")
    p = sub.add_parser("update", help="Create a new generation with old and new labeled data.")
    project_args(p)
    p.add_argument("--from-run", required=True)
    p = sub.add_parser("status", help="Read state and regenerate human-readable model reports.")
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--run")
    src.add_argument("--config")
    p.add_argument("--task", choices=["top", "bottom", "vig"])
    p = sub.add_parser("compare", help="Compare fixed versions on common selection records.")
    p.add_argument("--old-run", required=True)
    p.add_argument("--new-run", required=True)
    p.add_argument("--output")
    p = sub.add_parser("evaluate", help="Evaluate the frozen selected system on a final or fresh external holdout.")
    p.add_argument("--run", required=True)
    p.add_argument("--split", choices=["final-test", "external"], default="final-test")
    p.add_argument("--input")
    p.add_argument("--groups-csv")
    p = sub.add_parser("activate", help="Set current release after configured qualification checks.")
    p.add_argument("--run", required=True)
    p.add_argument("--config")
    p = sub.add_parser("predict", help="Classify folders with a model package, source run or active release.")
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--model", help="Portable inference package directory.")
    src.add_argument("--run", help="Source training run (requires PyTorch).")
    src.add_argument("--config", help="Project with activated per-task releases.")
    p.add_argument("--input")
    p.add_argument("--output")
    p.add_argument("--device", choices=["cpu", "cuda", "auto"], default="cpu")
    p.add_argument("--profile", choices=["laptop", "workstation"], default="laptop")
    p.add_argument("--task", choices=["top", "bottom", "vig"])
    p.add_argument("--labeled", action="store_true")
    p = sub.add_parser("export", help="Create image comparison folders from saved selection scores.")
    p.add_argument("--run", required=True)
    p.add_argument("--candidate", default="selected")
    p.add_argument("--output", required=True)
    p = sub.add_parser("package", help="Build an ONNX inference or training continuation package.")
    p.add_argument("--run", required=True)
    p.add_argument("--kind", choices=["inference", "training"], default="inference")
    p.add_argument("--format", choices=["onnx"], default="onnx")
    p.add_argument("--output", required=True)
    p = sub.add_parser("restore", help="Restore training state against matching relocated image data.")
    p.add_argument("--package", required=True)
    p.add_argument("--data-root", required=True)
    p.add_argument("--output", required=True)
    p = sub.add_parser("smoke", help="Run synthetic workflow checks without using inspection data.")
    p.add_argument("--output", required=True)
    p.add_argument("--with-models", action="store_true")
    p.add_argument("--with-onnx", action="store_true")
    return parser


class Tee:
    def __init__(self, original, handle):
        self.original, self.handle = original, handle
    def write(self, value):
        self.original.write(value)
        self.handle.write(value)
    def flush(self):
        self.original.flush()
        self.handle.flush()


@contextmanager
def log_to(run):
    path = Path(run) / "operation.log"
    old_out, old_err = sys.stdout, sys.stderr
    with path.open("a", encoding="utf-8") as handle:
        sys.stdout, sys.stderr = Tee(old_out, handle), Tee(old_err, handle)
        try:
            yield
        except BaseException:
            traceback.print_exc(file=handle)
            raise
        finally:
            sys.stdout, sys.stderr = old_out, old_err


def doctor(config=None, profile="laptop", task=None, deployment=False):
    from nilt.common import load_project
    import importlib.metadata
    dependencies = {}
    for name, module in (("numpy", "numpy"), ("Pillow", "PIL"), ("PyYAML", "yaml"),
                         ("scikit-learn", "sklearn"), ("scipy", "scipy"), ("matplotlib", "matplotlib"),
                         ("torch", "torch"), ("torchvision", "torchvision"),
                         ("onnx", "onnx"), ("onnxruntime", "onnxruntime")):
        dependencies[name] = importlib.metadata.version(name) if importlib.util.find_spec(module) else None
    report = {"python": sys.version.split()[0], "dependencies": dependencies, "tasks": []}
    ready = all(dependencies[x] for x in ("numpy", "Pillow", "PyYAML", "scikit-learn", "scipy", "matplotlib", "torch", "torchvision"))
    if deployment:
        ready = ready and bool(dependencies["onnx"] and dependencies["onnxruntime"])
    configs = load_project(config, profile, task) if config else []
    for cfg in configs:
        item = {"task": cfg["task"], "data_root": cfg["data_root"],
                "dataset_exists": Path(cfg["data_root"]).is_dir(), "device": cfg["device"],
                "profile": profile, "image_size": cfg["image_size"], "models": cfg["models"]}
        try:
            from nilt.engine import check_weights, device_for
            check_weights(cfg)
            item["resolved_device"] = str(device_for(cfg))
            item["resources_ready"] = True
        except Exception as exc:
            item["resources_ready"] = False
            item["issue"] = str(exc)
        ready = ready and item["dataset_exists"] and item["resources_ready"]
        report["tasks"].append(item)
    report["ready"] = bool(ready)
    print(json.dumps(report, indent=2))
    return report


def smoke(output, with_models=False, with_onnx=False):
    from nilt.common import merge_dict, DEFAULTS, write_json
    from nilt.workflow import new_run, run_training, open_run, final_test, predict_folder, write_state
    from nilt.reporting import export_predictions
    import numpy as np
    from PIL import Image
    output = Path(output).resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError("Smoke output must be a new or empty directory.")
    if with_onnx and not with_models:
        raise ValueError("--with-onnx requires --with-models.")
    rng = np.random.default_rng(431)
    for label in ("good", "bad"):
        target = output / "data" / label
        target.mkdir(parents=True, exist_ok=True)
        for i in range(40):
            arr = rng.integers(30, 80, (64, 64, 3), dtype=np.uint8)
            if label == "bad":
                arr[22:40, 22:40] = 230
            Image.fromarray(arr).save(target / f"{label}_{i:04d}.png")
    cfg = merge_dict(DEFAULTS, {"task": "top", "profile": "laptop", "pilot": True,
        "dataset_version": "SYNTHETIC_SMOKE_ONLY", "data_root": str(output / "data"),
        "output_root": str(output / "results"), "weights_dir": str(output / "weights"),
        "image_size": "auto", "pretrained": False, "device": "cpu", "cpu_threads": 2,
        "models": ["resnet18", "patchcore"], "seeds": [42], "ensembles": False,
        "near_duplicate_distance": -1, "training": {"epochs": 1, "warmup_epochs": 0, "batch_size": 4,
        "eval_batch_size": 4, "accumulation_steps": 1, "amp": False},
        "patchcore": {"reservoir_size": 256, "coreset_size": 32, "projection_dim": 16}})
    run = new_run(cfg)
    cfg, rows = open_run(run)
    if with_models:
        run_training(run)
        final_test(run)
        predict_folder(run, output / "data", output / "predictions", labeled=True, device="cpu")
        if with_onnx:
            from nilt.deployment import export_package, predict_package
            package = export_package(run, output / "onnx_package")
            predict_package(package, output / "data", output / "onnx_predictions", device="cpu", labeled=True)
    else:
        heldout = [r for r in rows if r["split"] == "selection"]
        # Diagnostic scores test decision/export plumbing; these are not model predictions.
        scores = np.linspace(.1, .9, len(heldout))
        export_predictions(heldout, scores, .5, output / "diagnostic_exports", model_version="SYNTHETIC_NON_MODEL_SCORES")
        write_state(run, "CORE_SMOKE_ONLY", note="Synthetic data/decision plumbing passed. No model trained or evaluated.")
    report = {"status": "passed", "with_models": with_models, "with_onnx": with_onnx,
              "run": str(run), "data": "synthetic", "industrial_performance_evidence": False}
    write_json(output / "smoke_result.json", report)
    print(json.dumps(report, indent=2))
    return report


def dispatch(args):
    # Portable package inference does not import the training stack.
    if args.command == "predict" and args.model:
        if not args.input or not args.output:
            raise ValueError("--model prediction requires --input and --output.")
        from nilt.runtime import predict_package
        return predict_package(args.model, args.input, args.output, device=args.device, labeled=args.labeled)
    from nilt.common import load_project, read_json, write_json
    from nilt.workflow import new_run, open_run, run_training, final_test, predict_folder, export_again
    if args.command == "doctor":
        return 0 if doctor(args.config, args.profile, args.task, args.deployment)["ready"] else 3
    if args.command in ("audit", "run"):
        for cfg in load_project(args.config, args.profile, args.task):
            run = new_run(cfg)
            if args.command == "run":
                with log_to(run):
                    run_training(run)
    elif args.command == "resume":
        run = Path(args.run).resolve()
        open_run(run)
        if args.recover_lock and (run / "operation.lock").exists():
            old = read_json(run / "operation.lock")
            print(f"Recovering abandoned lock recorded as {old}")
            (run / "operation.lock").unlink()
        if args.device:
            write_json(run / "runtime_overrides.json", {"device": args.device})
        with log_to(run):
            run_training(run)
    elif args.command == "update":
        old_cfg, _ = open_run(args.from_run)
        if args.task and args.task != old_cfg["task"]:
            raise ValueError("Update task must match predecessor task.")
        cfg = load_project(args.config, args.profile, old_cfg["task"])[0]
        cfg["previous_run"] = str(Path(args.from_run).resolve())
        run = new_run(cfg)
        with log_to(run):
            run_training(run)
    elif args.command == "status":
        from nilt.reporting import render_run_report
        runs = [Path(args.run)] if args.run else []
        if args.config:
            for cfg in load_project(args.config, task=args.task):
                runs.extend(p.parent for p in sorted((Path(cfg["output_root"]) / cfg["task"]).glob("*/model_state.json")))
        result = []
        for run in runs:
            render_run_report(run)
            state = read_json(run / "model_state.json")
            result.append({"run": str(run), "status": state["status"], "updated_at": state.get("updated_at"),
                           "current_candidate": state.get("current_candidate"), "selected_candidate": state.get("selected_candidate"),
                           "report": str(run / "model_report.html")})
        print(json.dumps(result, indent=2))
    elif args.command == "compare":
        from nilt.registry import compare_runs
        result = compare_runs(args.old_run, args.new_run, args.output)
        print(json.dumps(result, indent=2))
    elif args.command == "evaluate":
        if args.split == "external" and not args.input:
            raise ValueError("External evaluation requires --input with labeled good/bad folders.")
        if args.split == "final-test" and (args.input or args.groups_csv):
            raise ValueError("--input/--groups-csv are only valid with --split external.")
        result = final_test(args.run, args.input, args.groups_csv)
        return 0 if result["empirical_target_met"] else 5
    elif args.command == "activate":
        from nilt.registry import activate_run
        print(json.dumps(activate_run(args.run, args.config), indent=2))
    elif args.command == "predict":
        if args.run:
            if not args.input or not args.output:
                raise ValueError("--run prediction requires --input and --output.")
            predict_folder(args.run, args.input, args.output, args.labeled, args.device)
        else:
            from nilt.registry import current_run
            configs = load_project(args.config, args.profile, args.task)
            if len(configs) > 1 and (args.input or args.output):
                raise ValueError("Explicit --input/--output require one selected --task.")
            for cfg in configs:
                stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
                src = args.input or Path(cfg["incoming_root"]) / cfg["task"]
                dst = args.output or Path(cfg["classification_output_root"]) / cfg["task"] / stamp
                predict_folder(current_run(cfg), src, dst, args.labeled, args.device)
    elif args.command == "export":
        export_again(args.run, args.candidate, args.output)
    elif args.command == "package":
        if args.kind == "training":
            from nilt.registry import create_training_package
            print(create_training_package(args.run, args.output))
        else:
            from nilt.deployment import export_package
            print(export_package(args.run, args.output, kind=args.kind, format=args.format))
    elif args.command == "restore":
        from nilt.registry import restore_training_package
        print(restore_training_package(args.package, args.data_root, args.output))
    elif args.command == "download-weights":
        from nilt.engine import required_weight_names
        import download_weights
        old_argv = sys.argv
        try:
            for cfg in load_project(args.config, args.profile, args.task):
                sys.argv = ["download_weights.py", "--output", cfg["weights_dir"], "--models", *required_weight_names(cfg)]
                download_weights.main()
        finally:
            sys.argv = old_argv
    elif args.command == "smoke":
        smoke(args.output, args.with_models, args.with_onnx)
    return 0


def main(argv=None):
    args = build_parser().parse_args(argv)
    try:
        result = dispatch(args)
        return result if isinstance(result, int) else 0
    except KeyboardInterrupt:
        print("INTERRUPTED: completed-epoch state is retained where available.", file=sys.stderr)
        return 130
    except (ValueError, FileNotFoundError, FileExistsError, KeyError) as exc:
        print(f"INPUT_ERROR: {exc}", file=sys.stderr)
        return 2
    except (ImportError, RuntimeError, OSError) as exc:
        print(f"EXECUTION_ERROR: {exc}", file=sys.stderr)
        return 3


if __name__ == "__main__":
    sys.exit(main())
