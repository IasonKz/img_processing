from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd

from .config import get, resolve_path
from .data import load_manifest
from .inference import predict_labeled_records
from .metrics import binary_metrics, save_evaluation_bundle, threshold_sweep
from .utils import setup_logging, write_json


def _promotion_decision(
    baseline: dict[str, Any],
    candidate: dict[str, Any],
    rules: dict[str, Any],
) -> dict[str, Any]:
    reasons: list[str] = []

    if rules.get("max_false_pass_rate") is not None:
        limit = float(rules["max_false_pass_rate"])
        if candidate["false_pass_rate"] > limit:
            reasons.append(
                f"Candidate false-pass rate {candidate['false_pass_rate']:.6f} exceeds {limit:.6f}."
            )

    if rules.get("min_bad_recall") is not None:
        limit = float(rules["min_bad_recall"])
        if candidate["bad_recall"] < limit:
            reasons.append(
                f"Candidate BAD recall {candidate['bad_recall']:.6f} is below {limit:.6f}."
            )

    if bool(rules.get("must_not_increase_false_pass_count", True)):
        if int(candidate["false_pass"]) > int(baseline["false_pass"]):
            reasons.append(
                f"Candidate has {candidate['false_pass']} false passes versus baseline {baseline['false_pass']}."
            )

    if rules.get("max_false_reject_rate_increase") is not None:
        limit = float(rules["max_false_reject_rate_increase"])
        increase = float(candidate["false_reject_rate"] - baseline["false_reject_rate"])
        if increase > limit:
            reasons.append(
                f"Candidate false-reject-rate increase {increase:.6f} exceeds {limit:.6f}."
            )

    if rules.get("min_average_precision_delta") is not None:
        minimum = float(rules["min_average_precision_delta"])
        delta = float(
            candidate["average_precision_bad"] - baseline["average_precision_bad"]
        )
        if delta < minimum:
            reasons.append(
                f"Candidate AP delta {delta:.6f} is below required {minimum:.6f}."
            )

    return {
        "promote_candidate": not reasons,
        "reasons": reasons or ["All configured promotion gates passed."],
    }


def run_model_comparison(config: dict[str, Any]) -> dict[str, Any]:
    manifest_path = resolve_path(
        get(config, "benchmark.manifest_path"), config=config, must_exist=True
    )
    if manifest_path is None:
        raise ValueError("Set benchmark.manifest_path")
    records = load_manifest(manifest_path)
    requested_splits = set(get(config, "benchmark.splits", ["test"]))
    records = [record for record in records if record.split in requested_splits]
    if not records:
        raise ValueError(f"No benchmark records found for splits: {sorted(requested_splits)}")

    output_dir = resolve_path(
        get(config, "comparison.output_folder", "model_comparison"), config=config
    )
    assert output_dir is not None
    output_dir.mkdir(parents=True, exist_ok=True)
    logger = setup_logging(output_dir / "comparison.log")

    model_entries = config.get("models", [])
    if not isinstance(model_entries, list) or len(model_entries) < 1:
        raise ValueError("models must contain at least one model entry")

    metrics_rows: list[dict[str, Any]] = []
    predictions_by_name: dict[str, pd.DataFrame] = {}
    metrics_by_name: dict[str, dict[str, Any]] = {}

    for entry in model_entries:
        name = str(entry.get("name", Path(str(entry["checkpoint"])).stem))
        checkpoint = resolve_path(entry.get("checkpoint"), config=config, must_exist=True)
        assert checkpoint is not None
        frame, checkpoint_data = predict_labeled_records(
            checkpoint_path=checkpoint,
            records=records,
            device_request=str(get(config, "inference.device", "auto")),
            batch_size=int(get(config, "inference.batch_size", 16)),
            num_workers=int(get(config, "inference.num_workers", 4)),
            mixed_precision=bool(get(config, "inference.mixed_precision", True)),
            threshold_override=(
                None if entry.get("threshold_bad") is None else float(entry["threshold_bad"])
            ),
            show_progress=bool(get(config, "inference.show_progress", True)),
        )
        threshold = float(frame["threshold_bad"].iloc[0])
        metrics = binary_metrics(
            frame["true_index"].astype(int).to_numpy(),
            frame["p_bad"].to_numpy(),
            threshold=threshold,
        )
        metrics_by_name[name] = metrics
        predictions_by_name[name] = frame
        row = {"model": name, "checkpoint": str(checkpoint), **metrics}
        metrics_rows.append(row)
        save_evaluation_bundle(
            output_dir=output_dir / name,
            name=name,
            y_true=frame["true_index"].astype(int).to_numpy(),
            p_bad=frame["p_bad"].to_numpy(),
            threshold=threshold,
            predictions=frame,
            threshold_sweep_frame=threshold_sweep(
                frame["true_index"].astype(int).to_numpy(), frame["p_bad"].to_numpy(), steps=1001
            ),
            export_error_images=bool(get(config, "comparison.export_error_images", False)),
        )
        logger.info(
            "%s | false passes=%d | BAD recall=%.4f | false rejects=%d",
            name,
            metrics["false_pass"],
            metrics["bad_recall"],
            metrics["false_reject"],
        )

    metrics_frame = pd.DataFrame(metrics_rows)
    metrics_frame.to_csv(output_dir / "model_metrics.csv", index=False, encoding="utf-8")

    # One row per benchmark image, with side-by-side probabilities and decisions.
    merged: pd.DataFrame | None = None
    for name, frame in predictions_by_name.items():
        subset = frame[
            ["path", "unit_id", "true_label", "p_bad", "predicted_label", "error_type"]
        ].copy()
        subset = subset.rename(
            columns={
                "p_bad": f"{name}__p_bad",
                "predicted_label": f"{name}__prediction",
                "error_type": f"{name}__error_type",
            }
        )
        if merged is None:
            merged = subset
        else:
            merged = merged.merge(
                subset.drop(columns=["true_label"]),
                on=["path", "unit_id"],
                how="outer",
            )
    assert merged is not None
    if len(model_entries) >= 2:
        first = str(model_entries[0].get("name", Path(str(model_entries[0]["checkpoint"])).stem))
        second = str(model_entries[1].get("name", Path(str(model_entries[1]["checkpoint"])).stem))
        merged["models_disagree"] = (
            merged[f"{first}__prediction"] != merged[f"{second}__prediction"]
        )
    merged.to_csv(output_dir / "side_by_side_predictions.csv", index=False, encoding="utf-8")

    promotion = None
    if len(model_entries) >= 2:
        baseline_name = str(model_entries[0].get("name", Path(str(model_entries[0]["checkpoint"])).stem))
        candidate_name = str(model_entries[1].get("name", Path(str(model_entries[1]["checkpoint"])).stem))
        promotion = {
            "baseline": baseline_name,
            "candidate": candidate_name,
            **_promotion_decision(
                metrics_by_name[baseline_name],
                metrics_by_name[candidate_name],
                config.get("promotion_rules", {}) or {},
            ),
        }
        write_json(promotion, output_dir / "promotion_decision.json")

    summary = {
        "manifest": str(manifest_path),
        "splits": sorted(requested_splits),
        "benchmark_images": len(records),
        "metrics": metrics_by_name,
        "promotion": promotion,
        "output_folder": str(output_dir),
    }
    write_json(summary, output_dir / "comparison_summary.json")
    return summary
