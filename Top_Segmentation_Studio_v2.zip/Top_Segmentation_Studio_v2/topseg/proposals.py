"""Selectable, reviewable top-image proposal methods at native resolution.

Basic delegates to the original detector. The other methods are assistive
classical algorithms, not trained defect recognizers. Exclusions affect proposals
only: a caller must never translate them into verified good training labels.
No function in this module resizes an image or changes the source pixels.
"""
from __future__ import annotations

import copy
import math

import numpy as np
from scipy import ndimage

from .classical import (_boundary_distance, roi_mask, suggest, validate_roi,
                        validate_settings)


AUTOMATION_DEFAULTS = {
    'method': 'basic', 'scope': 'full', 'scope_roi': None, 'zones': [],
    'exclude_label': True, 'exclude_symbols': True, 'exclude_eye': False,
    'exclude_custom': True, 'suppress_edges': False, 'eye': None,
    'radial_strength': 1.0, 'reference_ids': [], 'reference_max_shift': 32,
    'reference_rotation': 3.0, 'reference_min_correlation': .75,
}


def validate_automation(value, width, height):
    """Return a detached, JSON-compatible configuration; reject ambiguous input."""
    if (not isinstance(width, (int, np.integer)) or isinstance(width, bool) or
            not isinstance(height, (int, np.integer)) or isinstance(height, bool) or
            width < 1 or height < 1):
        raise ValueError('Image dimensions must be positive integers.')
    if value is None:
        value = {}
    if not isinstance(value, dict):
        raise ValueError('Automation settings must be an object.')
    if set(value) - set(AUTOMATION_DEFAULTS):
        raise ValueError('Unknown automation settings: ' + ', '.join(sorted(set(value) - set(AUTOMATION_DEFAULTS))))
    cfg = copy.deepcopy(AUTOMATION_DEFAULTS)
    cfg.update(copy.deepcopy(value))
    if cfg['method'] not in ('basic', 'exclusions', 'structure', 'reference'):
        raise ValueError('Annotation method must be basic, exclusions, structure or reference.')
    if cfg['scope'] not in ('full', 'central', 'custom'):
        raise ValueError('Detection area must be full, central or custom.')
    for key in ('exclude_label', 'exclude_symbols', 'exclude_eye', 'exclude_custom', 'suppress_edges'):
        if not isinstance(cfg[key], bool):
            raise ValueError(f'{key} must be true or false.')
    for key, lower, upper in (('radial_strength', 0, 2), ('reference_max_shift', 0, 256),
                              ('reference_rotation', 0, 10), ('reference_min_correlation', 0, 1)):
        if isinstance(cfg[key], bool) or not isinstance(cfg[key], (int, float)) or not math.isfinite(cfg[key]) or not lower <= cfg[key] <= upper:
            raise ValueError(f'{key} must be a finite number in [{lower},{upper}].')
        cfg[key] = float(cfg[key])
    for key in ('scope_roi', 'eye'):
        if cfg[key] is not None:
            cfg[key] = validate_roi(cfg[key], width, height)
    if cfg['scope'] == 'custom' and cfg['scope_roi'] is None:
        raise ValueError('Draw a custom detection area before using Custom area.')
    if not isinstance(cfg['zones'], list) or len(cfg['zones']) > 64:
        raise ValueError('Exclusion zones must be a list containing at most 64 regions.')
    identifiers = set()
    for zone in cfg['zones']:
        if not isinstance(zone, dict) or set(zone) != {'id', 'name', 'category', 'roi'}:
            raise ValueError('Every exclusion zone requires id, name, category and roi.')
        if not isinstance(zone['id'], str) or not 1 <= len(zone['id']) <= 128 or zone['id'] in identifiers:
            raise ValueError('Exclusion zone IDs must be unique, nonempty strings of at most 128 characters.')
        identifiers.add(zone['id'])
        if not isinstance(zone['name'], str) or len(zone['name']) > 200:
            raise ValueError('Exclusion zone names must be strings of at most 200 characters.')
        if zone['category'] not in ('label', 'symbols', 'eye', 'custom'):
            raise ValueError('Zone category must be label, symbols, eye or custom.')
        zone['roi'] = validate_roi(zone['roi'], width, height)
    refs = cfg['reference_ids']
    if (not isinstance(refs, list) or len(refs) > 8 or
            any(not isinstance(ref, str) or not 1 <= len(ref) <= 256 for ref in refs) or
            len(set(refs)) != len(refs)):
        raise ValueError('Select at most eight distinct reference image IDs.')
    return cfg


def _cv2():
    try:
        import cv2
    except ImportError as exc:
        raise ValueError('This method requires opencv-python-headless. Run Setup again, or choose Basic with Full image/Custom area.') from exc
    return cv2


def _gray(image):
    return np.asarray(image).astype(np.float32) @ np.array([.299, .587, .114], dtype=np.float32)


def _bounds(roi):
    if roi.get('type') == 'polygon':
        xs, ys = [p['x'] for p in roi['points']], [p['y'] for p in roi['points']]
        return min(xs), min(ys), max(xs), max(ys)
    return roi['cx'] - roi['rx'], roi['cy'] - roi['ry'], roi['cx'] + roi['rx'], roi['cy'] + roi['ry']


def _eye_roi(roi, cfg, width, height):
    if cfg['eye'] is not None:
        return cfg['eye']
    x0, y0, x1, y1 = _bounds(roi)
    return validate_roi({'cx': (x0 + x1) / 2, 'cy': (y0 + y1) / 2,
                         'rx': max(1., min(width, .175 * (x1 - x0))),
                         'ry': max(1., min(height, .175 * (y1 - y0)))}, width, height)


def _refine_die_edges(points, smooth):
    """Fit straight lines through native gradient peaks, avoiding threshold halos."""
    equations = []
    offsets = np.linspace(-4, 4, 33)
    for a, b in zip(points, np.roll(points, -1, axis=0)):
        vector = b - a
        length = np.linalg.norm(vector)
        normal = np.array([-vector[1], vector[0]]) / length
        positions = a + np.linspace(.12, .88, max(12, int(length / 3)))[:, None] * vector
        strengths = []
        for offset in offsets:
            before, after = positions + (offset - .8) * normal, positions + (offset + .8) * normal
            strengths.append(np.abs(ndimage.map_coordinates(smooth, [after[:, 1] - .5, after[:, 0] - .5], order=1, mode='nearest') -
                                    ndimage.map_coordinates(smooth, [before[:, 1] - .5, before[:, 0] - .5], order=1, mode='nearest')))
        strengths = np.asarray(strengths)
        chosen = np.argmax(strengths, axis=0)
        peaks = positions + offsets[chosen, None] * normal
        strong = strengths[chosen, np.arange(len(chosen))] >= max(4., .65 * np.median(strengths.max(axis=0)))
        if strong.sum() < 8:
            return points
        peaks = peaks[strong]
        selected = np.ones(len(peaks), bool)
        for _ in range(4):
            centroid = peaks[selected].mean(axis=0)
            _, _, axes = np.linalg.svd(peaks[selected] - centroid, full_matrices=False)
            fitted_normal = axes[-1]
            distances = np.abs((peaks - centroid) @ fitted_normal)
            cutoff = max(.3, 3 * 1.4826 * float(np.median(distances)))
            next_selected = distances <= cutoff
            if next_selected.sum() < 8 or np.array_equal(selected, next_selected):
                break
            selected = next_selected
        if abs(float(fitted_normal @ normal)) < .995:
            return points
        equations.append((fitted_normal, float(fitted_normal @ centroid)))
    refined = []
    for index, (normal, offset) in enumerate(equations):
        previous_normal, previous_offset = equations[index - 1]
        matrix = np.stack((previous_normal, normal))
        if abs(np.linalg.det(matrix)) < .1:
            return points
        vertex = np.linalg.solve(matrix, [previous_offset, offset])
        if np.linalg.norm(vertex - points[index]) > 7:
            return points
        refined.append(vertex)
    return np.asarray(refined)


def _central_die(gray):
    """Find a separated rectangular central die, with a conservative failure.

    Threshold components supply candidates; a filled rectangle must have four
    supported corners and substantial occupancy. Circles, rings, image borders
    and the surrounding dark field are rejected. The largest plausible central
    rectangle wins, to prefer a die perimeter over an inner optical pattern.
    """
    cv2 = _cv2()
    height, width = gray.shape
    failure = 'Central die could not be located reliably. Choose Full image or draw Custom area.'
    if min(height, width) < 24 or float(np.percentile(gray, 99) - np.percentile(gray, 1)) < 8:
        raise ValueError(failure)
    smooth = cv2.GaussianBlur(gray, (5, 5), .9)
    byte = np.clip(smooth, 0, 255).astype(np.uint8)
    otsu, _ = cv2.threshold(byte, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    thresholds = sorted(set([float(otsu)] + [float(np.percentile(byte, p)) for p in (25, 45, 65, 80)]))
    candidates, seen = [], set()
    center = np.array([width / 2, height / 2])
    min_area = max(80, .004 * width * height)
    for threshold in thresholds:
        for polarity in (1, -1):
            binary = np.asarray(byte > threshold if polarity == 1 else byte < threshold, dtype=np.uint8)
            contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            for contour in contours:
                area = float(cv2.contourArea(contour))
                if not min_area <= area <= .9 * width * height:
                    continue
                x, y, w, h = cv2.boundingRect(contour)
                if x <= 1 or y <= 1 or x + w >= width - 1 or y + h >= height - 1:
                    continue
                signature = (x, y, w, h)
                if signature in seen:
                    continue
                seen.add(signature)
                perimeter = cv2.arcLength(contour, True)
                polygon = cv2.approxPolyDP(contour, .018 * perimeter, True)
                if len(polygon) != 4 or not cv2.isContourConvex(polygon):
                    continue
                rect = cv2.minAreaRect(contour)
                rw, rh = rect[1]
                extent = area / max(1., rw * rh)
                if extent < .86 or min(rw, rh) < 8 or not .45 <= rw / max(rh, 1.) <= 2.2:
                    continue
                if cv2.pointPolygonTest(polygon, tuple(center), False) < 0:
                    continue
                rect_center = np.array(rect[0])
                if np.linalg.norm(rect_center - center) > .2 * min(width, height):
                    continue
                points = polygon[:, 0, :].astype(float) + .5
                # OpenCV contours run through border-pixel centres. Expand
                # their supporting lines by half a pixel to cover those pixels.
                equations = []
                centroid = points.mean(axis=0)
                for pa, pb in zip(points, np.roll(points, -1, axis=0)):
                    edge = pb - pa
                    normal = np.array([-edge[1], edge[0]]) / np.linalg.norm(edge)
                    if np.dot(normal, (pa + pb) / 2 - centroid) < 0:
                        normal = -normal
                    equations.append((normal, float(np.dot(normal, pa) + .5)))
                expanded = []
                for index, (normal, offset) in enumerate(equations):
                    previous_normal, previous_offset = equations[index - 1]
                    expanded.append(np.linalg.solve(np.stack((previous_normal, normal)), [previous_offset, offset]))
                points = np.asarray(expanded)
                points = _refine_die_edges(points, smooth)
                candidate = {'type': 'polygon', 'points': [{'x': float(px), 'y': float(py)} for px, py in points]}
                # Side-normal contrasts guard against a chance intensity island.
                supported = _supported_edge_mask(smooth, candidate, band=1.5, min_length=8, return_sides=True)
                if supported[1] < 4:
                    continue
                score = area * extent / (1 + 3 * np.linalg.norm(rect_center - center) / min(width, height))
                candidates.append((score, candidate, extent))
    if not candidates:
        raise ValueError(failure)
    _, region, extent = max(candidates, key=lambda item: item[0])
    return region, {'algorithm': 'native_central_rectangle_components', 'rectangular_occupancy': float(extent), 'review_required': True}


def _supported_edge_mask(gray, region, band=2.5, min_length=20, return_sides=False):
    """Only suppress coherent intensity steps on an established die perimeter."""
    height, width = gray.shape
    result = None if return_sides else np.zeros((height, width), bool)
    if region.get('type') != 'polygon':
        return (result, 0) if return_sides else result
    yy, xx = np.ogrid[:height, :width]
    supported = 0
    for a, b in zip(region['points'], region['points'][1:] + region['points'][:1]):
        av, bv = np.array([a['x'], a['y']]), np.array([b['x'], b['y']])
        vector = bv - av
        length = np.linalg.norm(vector)
        if length < min_length:
            continue
        normal = np.array([-vector[1], vector[0]]) / length
        positions = av + np.linspace(.1, .9, max(12, int(length / 2)))[:, None] * vector
        before, after = positions - 3 * normal, positions + 3 * normal
        differences = (ndimage.map_coordinates(gray, [after[:, 1] - .5, after[:, 0] - .5], order=1, mode='nearest') -
                       ndimage.map_coordinates(gray, [before[:, 1] - .5, before[:, 0] - .5], order=1, mode='nearest'))
        sign = np.sign(np.median(differences))
        if np.mean(differences * sign >= 8) < .8:
            continue
        supported += 1
        if return_sides:
            continue
        t = np.clip(((xx + .5 - av[0]) * vector[0] + (yy + .5 - av[1]) * vector[1]) / length ** 2, 0, 1)
        result |= ((xx + .5 - av[0] - t * vector[0]) ** 2 + (yy + .5 - av[1] - t * vector[1]) ** 2 <= band ** 2)
    return (result, supported) if return_sides else result


def _correct_straight_edges(gray, residual, mask, boundary, inner, valid, cfg):
    """Subtract a supported die/background step, retaining local deviations.

    Only straight sides with consistent normal contrast contribute. The ideal
    step uses robust gray levels on either side, then exactly the same Gaussian
    filters as Basic. This avoids classifying its predictable halo as a defect,
    without blindly discarding every pixel near a perimeter.
    """
    height, width = gray.shape
    sigma = cfg['background_sigma']
    band = max(5., 3 * sigma)
    eligible_band = _supported_edge_mask(gray, boundary, band=band,
                                         min_length=max(20, .08 * min(width, height)))
    perimeter_inside = roi_mask(boundary, width, height)
    distance = _boundary_distance(boundary, width, height, perimeter_inside)
    samples = eligible_band & (distance >= max(2., .75 * sigma)) & (distance <= max(4., 2 * sigma))
    inside_values, outside_values = gray[samples & perimeter_inside], gray[samples & ~perimeter_inside]
    metadata = {'found': False, 'suppressed_edge_pixels': 0}
    if min(len(inside_values), len(outside_values)) < 40:
        metadata['note'] = 'Too little supporting die/background area; perimeter proposals were retained.'
        return mask, metadata
    inside_level, outside_level = float(np.median(inside_values)), float(np.median(outside_values))
    contrast = abs(inside_level - outside_level)
    if contrast < 8:
        metadata['note'] = 'Insufficient coherent die/background contrast; perimeter proposals were retained.'
        return mask, metadata
    ideal = np.where(perimeter_inside, inside_level, outside_level).astype(np.float32)
    ideal_smooth = ndimage.gaussian_filter(ideal, .6, mode='reflect')
    expected_residual = ideal_smooth - ndimage.gaussian_filter(ideal_smooth, sigma, mode='reflect')
    corrected = residual - expected_residual
    application = valid & eligible_band
    replacement, _ = _threshold(corrected, inner, application, cfg)
    output = mask.copy()
    output[application] = replacement[application]
    metadata.update({'found': True, 'inside_gray_level': inside_level, 'outside_gray_level': outside_level,
                     'suppressed_edge_pixels': int(((mask != 0) & (output == 0) & eligible_band).sum()),
                     'modeled_band_pixels': int((eligible_band & valid).sum()),
                     'note': 'Consistent die/background steps were modeled; localized deviations remain eligible for proposals.'})
    return output, metadata


def _valid_pixels(roi, scope, cfg, width, height):
    inner = roi_mask(roi, width, height)
    valid = scope.copy()
    guard = cfg['boundary_guard']
    if guard:
        valid &= _boundary_distance(roi, width, height, inner) > guard
        valid[:guard] = valid[-guard:] = False
        valid[:, :guard] = valid[:, -guard:] = False
    return inner, valid


def _threshold(residual, inner, eligible, cfg, multiplier=1.):
    mask = np.zeros(residual.shape, np.uint8)
    thresholds, components = {}, {}
    maximum = max(cfg['min_area'], cfg['max_area_fraction'] * residual.size)
    for value, region in ((1, inner), (2, ~inner)):
        selected_region = eligible & region
        values = residual[selected_region]
        name = 'inner' if value == 1 else 'outer'
        if not values.size:
            thresholds[name], components[name] = None, 0
            continue
        center = float(np.median(values))
        noise = max(1., 1.4826 * float(np.median(np.abs(values - center))))
        threshold = cfg['sensitivity'] * noise * multiplier
        difference = residual - center
        selected = np.abs(difference) >= threshold if cfg['polarity'] == 'both' else (
            difference <= -threshold if cfg['polarity'] == 'dark' else difference >= threshold)
        labels, _ = ndimage.label(selected & selected_region, structure=np.ones((3, 3), dtype=bool))
        counts = np.bincount(labels.ravel())
        keep = (counts >= cfg['min_area']) & (counts <= maximum)
        keep[0] = False
        mask[keep[labels]] = value
        thresholds[name], components[name] = float(threshold), int(keep.sum())
    return mask, {'thresholds_gray_levels': thresholds, 'components': components}


def _ring_center(smooth, eye_mask, eye):
    """Robustly intersect gradient normals; a straight scratch cannot locate x/y."""
    x0, y0, x1, y1 = _bounds(eye)
    prior = np.array([(x0 + x1) / 2, (y0 + y1) / 2], dtype=float)
    gx, gy = ndimage.sobel(smooth, axis=1) / 8, ndimage.sobel(smooth, axis=0) / 8
    magnitude = np.hypot(gx, gy)
    interior = ndimage.binary_erosion(eye_mask, iterations=2)
    if interior.sum() < 40:
        return prior, False
    cutoff = max(1., float(np.percentile(magnitude[interior], 65)))
    ys, xs = np.nonzero(interior & (magnitude >= cutoff))
    if len(xs) < 40:
        return prior, False
    mag = magnitude[ys, xs]
    tangent = np.column_stack((-gy[ys, xs] / mag, gx[ys, xs] / mag)).astype(np.float64)
    target = tangent[:, 0] * (xs + .5) + tangent[:, 1] * (ys + .5)
    weights = np.minimum(mag, np.percentile(mag, 90)).astype(np.float64)
    center = prior.copy()
    for _ in range(5):
        distance = np.abs(tangent @ center - target)
        scale = max(.7, 1.4826 * float(np.median(distance)))
        robust = weights * np.square(np.maximum(0., 1 - (distance / (4 * scale)) ** 2))
        matrix = tangent.T @ (robust[:, None] * tangent)
        eigenvalues = np.linalg.eigvalsh(matrix)
        if eigenvalues[0] < 1e-8 or eigenvalues[0] / eigenvalues[-1] < .08:
            return prior, False
        center = np.linalg.solve(matrix, tangent.T @ (robust * target))
    if np.linalg.norm(center - prior) > max(2., .12 * min(x1 - x0, y1 - y0)):
        return prior, False
    return center, True


def _radial_residual(smooth, original_residual, eye_mask, eye, cfg):
    """Estimate median brightness at each radius using native pixel positions.

    Subpixel radial bins are a model parameter, not an image resampling. A local
    scratch occupies few angles and therefore survives the radial median. A
    complete annular defect may be absorbed and needs Basic/reference review.
    """
    height, width = smooth.shape
    center, refined = _ring_center(smooth, eye_mask, eye)
    ys, xs = np.nonzero(eye_mask)
    if len(xs) < 64:
        return original_residual, {'found': False, 'note': 'Eye footprint is too small; Basic proposals were retained there.'}
    radii = np.hypot(xs + .5 - center[0], ys + .5 - center[1])
    bins = np.rint(radii * 4).astype(np.int32)
    order = np.argsort(bins, kind='stable')
    grouped = bins[order]
    starts = np.r_[0, np.flatnonzero(np.diff(grouped)) + 1]
    ends = np.r_[starts[1:], len(order)]
    samples = smooth[ys, xs]
    radii_model, brightness = [], []
    for start, end in zip(starts, ends):
        if end - start >= 6:
            positions = order[start:end]
            radii_model.append(float(np.median(radii[positions])))
            brightness.append(float(np.median(samples[positions])))
    if len(brightness) < 12:
        return original_residual, {'found': False, 'note': 'Too few supported radial bands; Basic proposals were retained in the eye.'}
    expected = np.interp(radii, radii_model, brightness).astype(np.float32)
    delta = np.zeros((height, width), np.float32)
    delta[ys, xs] = samples - expected
    weights = ndimage.gaussian_filter(eye_mask.astype(np.float32), cfg['background_sigma'], mode='reflect')
    mean = ndimage.gaussian_filter(delta, cfg['background_sigma'], mode='reflect') / np.maximum(weights, 1e-6)
    corrected = delta - mean
    explained = 1 - float(np.var(samples - expected)) / max(1., float(np.var(samples)))
    return corrected, {'found': True, 'center': {'x': float(center[0]), 'y': float(center[1])},
                       'center_refined': bool(refined), 'radial_bands': len(brightness),
                       'explained_variance_fraction': float(np.clip(explained, 0, 1)),
                       'note': 'The radial median models repeated rings. Complete annular damage or an incorrect eye footprint can be missed; compare with Basic.'}


def _correlation(a, b):
    aa, bb = a.astype(np.float64), b.astype(np.float64)
    aa -= aa.mean()
    bb -= bb.mean()
    denominator = math.sqrt(float(aa @ aa) * float(bb @ bb))
    return float(aa @ bb / denominator) if denominator > 1e-10 else 0.


def _brightness_fit(reference, current, valid):
    x, y = reference[valid].astype(np.float64), current[valid].astype(np.float64)
    selected = np.ones(x.size, bool)
    gain, offset = 1., 0.
    for _ in range(5):
        xx, yy = x[selected], y[selected]
        if len(xx) < 64:
            raise ValueError('Reference brightness fitting has insufficient overlap. Choose Basic or another reference.')
        mx, my = float(xx.mean()), float(yy.mean())
        centered = xx - mx
        variance = float(centered @ centered)
        if variance < max(1., len(xx) * .25):
            raise ValueError('Reference image has insufficient texture for reliable alignment. Choose Basic or another reference.')
        gain = float(centered @ (yy - my) / variance)
        offset = my - gain * mx
        residual = y - (gain * x + offset)
        location = float(np.median(residual))
        cutoff = max(3., 3.5 * 1.4826 * float(np.median(np.abs(residual - location))))
        selected = np.abs(residual - location) <= cutoff
    if not .25 <= gain <= 4 or abs(offset) > 150:
        raise ValueError('Reference brightness differs too much for reliable comparison. Choose Basic or another reference.')
    return (reference * gain + offset).astype(np.float32), {'gain': gain, 'offset': float(offset), 'fit_pixels': int(selected.sum())}


def _align_reference(current, reference, scope, cfg, identifier):
    """Native ECC rigid alignment with bounded center translation and rotation."""
    cv2 = _cv2()
    height, width = current.shape
    if scope.sum() < 100 or min(float(np.std(current[scope])), float(np.std(reference[scope]))) < 1:
        raise ValueError(f'Reference {identifier}: insufficient texture for reliable alignment. Choose Basic or another reference.')
    # phaseCorrelate supplies an initial translation, at the full source size.
    masked_current = np.where(scope, current - np.median(current[scope]), 0).astype(np.float32)
    masked_reference = np.where(scope, reference - np.median(reference[scope]), 0).astype(np.float32)
    (sx, sy), response = cv2.phaseCorrelate(masked_current, masked_reference)
    initial = np.eye(2, 3, dtype=np.float32)
    if math.isfinite(sx) and math.isfinite(sy) and math.hypot(sx, sy) <= cfg['reference_max_shift'] + 1 and response > .03:
        initial[:, 2] = (sx, sy)
    motion = cv2.MOTION_EUCLIDEAN if cfg['reference_rotation'] > 0 else cv2.MOTION_TRANSLATION
    try:
        ecc, warp = cv2.findTransformECC(current, reference, initial, motion,
                                       (cv2.TERM_CRITERIA_COUNT | cv2.TERM_CRITERIA_EPS, 80, 1e-5),
                                       scope.astype(np.uint8), 5)
    except cv2.error as exc:
        raise ValueError(f'Reference {identifier}: alignment did not converge. Choose Basic or another reference.') from exc
    center = np.array([width / 2, height / 2])
    displacement = warp[:, :2] @ center + warp[:, 2] - center
    rotation = math.degrees(math.atan2(float(warp[1, 0]), float(warp[0, 0])))
    if (not np.isfinite(warp).all() or not math.isfinite(ecc) or
            np.linalg.norm(displacement) > cfg['reference_max_shift'] + .25 or
            abs(rotation) > cfg['reference_rotation'] + .05):
        raise ValueError(f'Reference {identifier}: alignment exceeded the allowed shift/rotation. Choose Basic, adjust the limits or select another reference.')
    warped = cv2.warpAffine(reference, warp, (width, height), flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP,
                            borderMode=cv2.BORDER_CONSTANT, borderValue=0)
    coverage = cv2.warpAffine(np.ones((height, width), np.uint8), warp, (width, height),
                             flags=cv2.INTER_NEAREST | cv2.WARP_INVERSE_MAP, borderMode=cv2.BORDER_CONSTANT) != 0
    coverage = ndimage.binary_erosion(coverage, iterations=2)
    valid = scope & coverage
    if valid.sum() < .8 * scope.sum():
        raise ValueError(f'Reference {identifier}: alignment leaves too little image overlap. Choose Basic or another reference.')
    correlation = _correlation(current[valid], warped[valid])
    if correlation < cfg['reference_min_correlation']:
        raise ValueError(f'Reference {identifier}: alignment correlation {correlation:.3f} is below {cfg["reference_min_correlation"]:.3f}. Choose Basic or another reference.')
    corrected, brightness = _brightness_fit(warped, current, valid)
    return corrected, coverage, {'id': identifier, 'correlation': correlation, 'ecc': float(ecc),
                                 'center_shift_pixels': [float(v) for v in displacement],
                                 'rotation_degrees': rotation, 'warp': warp.astype(float).tolist(),
                                 'overlap_fraction': float(valid.sum() / scope.sum()), **brightness}


def suggest_advanced(image, roi=None, settings=None, automation=None, references=None):
    """Return a uint8 0/inner/outer proposal mask and transparent review metadata."""
    rgb = np.asarray(image)
    if rgb.ndim != 3 or rgb.shape[2] != 3 or rgb.dtype != np.uint8:
        raise ValueError('Proposal input must be an 8-bit RGB image.')
    height, width = rgb.shape[:2]
    cfg = validate_automation(automation, width, height)
    classical_cfg = validate_settings(settings)
    roi = validate_roi(roi, width, height)
    method = cfg['method']
    warnings = []
    stats = {'method': method, 'automatic_proposal': True, 'review_required': True, 'warnings': warnings,
             'scope': cfg['scope'], 'effective_scope': None, 'effective_eye': None,
             'native_resolution': [width, height]}
    scope = np.ones((height, width), dtype=bool)
    gray = None
    if cfg['scope'] == 'custom':
        stats['effective_scope'] = cfg['scope_roi']
        scope = roi_mask(cfg['scope_roi'], width, height)
    elif cfg['scope'] == 'central':
        gray = _gray(rgb)
        stats['effective_scope'], stats['scope_detection'] = _central_die(gray)
        scope = roi_mask(stats['effective_scope'], width, height)
        warnings.append('Review the detected central die. Use a saved Custom area if this boundary is incorrect.')
    if not scope.any():
        raise ValueError('The detection area contains no image pixels.')
    if method == 'basic':
        mask, original_stats = suggest(rgb, roi, classical_cfg)
        mask[~scope] = 0
        stats.update({key: value for key, value in original_stats.items() if key != 'method'})
        stats['algorithm'] = original_stats['method']
    else:
        gray = _gray(rgb) if gray is None else gray
        inner, valid = _valid_pixels(roi, scope, classical_cfg, width, height)
        excluded = np.zeros((height, width), dtype=bool)
        for zone in cfg['zones']:
            if cfg['exclude_' + zone['category']]:
                excluded |= roi_mask(zone['roi'], width, height)
        eye = _eye_roi(roi, cfg, width, height)
        eye_mask = roi_mask(eye, width, height)
        if cfg['exclude_eye']:
            excluded |= eye_mask
        if cfg['exclude_eye'] or method == 'structure':
            stats['effective_eye'] = eye
            if cfg['eye'] is None:
                warnings.append('The eye footprint is estimated from the inner boundary. Review it or draw a custom eye footprint.')
        valid &= ~excluded
        stats['excluded_pixels'] = int((excluded & scope).sum())
        if excluded.any():
            warnings.append('Excluded pixels receive no automatic proposals; they are not confirmed good. Basic ignores these exclusions.')
        if not valid.any():
            raise ValueError('No inspection pixels remain after exclusions and the boundary guard. Reduce exclusions or choose Basic.')
        smooth = ndimage.gaussian_filter(gray, .6, mode='reflect')
        if method == 'reference':
            if not cfg['reference_ids']:
                raise ValueError('Select at least one known-good reference image before reloading reference proposals.')
            if not isinstance(references, (list, tuple)):
                raise ValueError('Reference images are missing. Choose Basic or select available references.')
            supplied = {}
            for entry in references:
                if not isinstance(entry, (list, tuple)) or len(entry) != 2 or not isinstance(entry[0], str) or entry[0] in supplied:
                    raise ValueError('Reference entries must contain unique image IDs and RGB arrays.')
                supplied[entry[0]] = np.asarray(entry[1])
            corrected, alignments = [], []
            comparison_valid = valid.copy()
            for identifier in cfg['reference_ids']:
                if identifier not in supplied:
                    raise ValueError(f'Reference image {identifier} is missing. Select an available reference or choose Basic.')
                reference = supplied[identifier]
                if reference.shape != rgb.shape or reference.dtype != np.uint8:
                    raise ValueError(f'Reference image {identifier} must be an 8-bit RGB image with the same native dimensions.')
                aligned, coverage, metadata = _align_reference(smooth, ndimage.gaussian_filter(_gray(reference), .6, mode='reflect'), scope, cfg, identifier)
                corrected.append(aligned)
                comparison_valid &= coverage
                alignments.append(metadata)
            expected = np.median(np.stack(corrected), axis=0)
            mask, details = _threshold(smooth - expected, inner, comparison_valid, classical_cfg)
            stats.update(details)
            stats.update({'algorithm': 'native_ecc_robust_brightness_reference_median', 'reference_alignments': alignments,
                          'alignment_uncovered_pixels': int((valid & ~comparison_valid).sum())})
            warnings.append('Reference comparison is experimental. References must be known good; shared defects, alignment errors and illumination changes can alter proposals.')
        else:
            residual = smooth - ndimage.gaussian_filter(smooth, classical_cfg['background_sigma'], mode='reflect')
            mask, details = _threshold(residual, inner, valid, classical_cfg)
            stats.update(details)
            stats['algorithm'] = 'local_gaussian_residual_with_exclusion_zones'
            if method == 'structure':
                stats['algorithm'] = 'local_residual_with_native_radial_eye_model'
                if not cfg['exclude_eye'] and cfg['radial_strength'] > 0:
                    corrected, radial = _radial_residual(smooth, residual, eye_mask & scope & ~excluded, eye, classical_cfg)
                    stats['radial_model'] = radial
                    if radial['found']:
                        blend = min(1., cfg['radial_strength'])
                        blended = residual * (1 - blend) + corrected * blend
                        replacement, radial_details = _threshold(blended, inner, valid & eye_mask, classical_cfg,
                                                                 multiplier=max(1., cfg['radial_strength']))
                        mask[eye_mask] = replacement[eye_mask]
                        stats['radial_thresholds_gray_levels'] = radial_details['thresholds_gray_levels']
                    else:
                        warnings.append(radial['note'])
                    warnings.append('Ring modeling can miss complete annular damage. Use Basic or reference comparison to inspect it.')
                if cfg['suppress_edges']:
                    boundary = stats['effective_scope']
                    if boundary is None:
                        try:
                            boundary, _ = _central_die(gray)
                        except ValueError:
                            warnings.append('No reliable die perimeter was found for edge suppression; perimeter proposals were retained.')
                    if boundary is not None:
                        edge_valid = valid
                        if stats.get('radial_model', {}).get('found'):
                            # Preserve the radial result where a custom eye
                            # footprint overlaps the perimeter modeling band.
                            edge_valid = valid & ~eye_mask
                        mask, edge_details = _correct_straight_edges(gray, residual, mask, boundary, inner, edge_valid, classical_cfg)
                        stats['edge_model'] = edge_details
                        stats['suppressed_edge_pixels'] = edge_details['suppressed_edge_pixels']
                        if not edge_details['found']:
                            warnings.append(edge_details['note'])
                        warnings.append('Straight-edge modeling can absorb broad, repeated perimeter changes. Use Basic to inspect edge damage.')
                warnings.append('Structure-aware proposals are experimental. Saved label/symbol zones provide the marking suppression; this method does not recognize arbitrary text or symbols.')
        stats['low_contrast'] = bool(np.percentile(gray, 99) - np.percentile(gray, 1) < 8)
    stats['inner_pixels'] = int((mask == 1).sum())
    stats['outer_pixels'] = int((mask == 2).sum())
    stats['components'] = {name: int(ndimage.label(mask == value, structure=np.ones((3, 3), dtype=bool))[1])
                           for value, name in ((1, 'inner'), (2, 'outer'))}
    stats['scope_pixels'] = int(scope.sum())
    stats['note'] = 'Review proposals before approval. Changing method does not change the inner/outer boundary or prove unmarked regions are good.'
    return mask, stats
