# ROI extension verification

Current shared ROI/Segmentation verification is recorded in [ROI_SEGMENTATION_VERIFICATION.md](ROI_SEGMENTATION_VERIFICATION.md). The results below describe the earlier 2026-10-03 environment.

Verified against Inspection Studio v6.2 on 2026-10-03 using Python 3.12, CPU PyTorch 2.7.1, OpenCV and Node. These are software and synthetic-image checks, not production accuracy measurements.

## Final targeted checks

```bash
python -m pytest -q tests/test_roi_geometry.py tests/test_roi_project.py tests/test_roi_learning.py tests/test_roi_classification.py tests/test_roi_dashboard.py tests/test_roi_context.py tests/test_dashboard_preprocessing.py
```

Result: **60 passed, 10 subtests passed**. The six new ROI test files account for 50 tests. Coverage includes rotated/missing features, expected versus observed geometry, independent nested masks, native uint16 pixels, corner normalization, duplicate alias grouping, unit splits shared across views, source overwrite detection, progress/cancellation, real CPU training/prediction/mask evaluation, held-out test protection, real HTTP/subprocess import/review/export, classification handoff, scope isolation and preservation of whole-image preprocessing settings.

```bash
node tests/test_v4_ui.cjs
node tests/test_v5_ui.cjs
node tests/test_v61_quality_ui.cjs
node tests/test_roi_ui.cjs
```

All four behavioral DOM/handler suites passed. The ROI suite verifies navigation restrictions, dataset scope selection/restoration, explicit geometry and quality controls, crop-label invalidation, vertex editing, observed/absent/unknown states, pin-grid IDs, hybrid localization requests, saving drafts when switching views, and HTML escaping. These harnesses intentionally stub the DOM/network; live backend behavior is covered by the Python HTTP tests.

Python compilation, JavaScript syntax checks and wheel packaging were also checked. The package includes `nilt.roi` and the new ROI UI assets.

## Existing behavior

Relevant existing backbone/profile, image-depth, preprocessing and TOP segmentation-server checks passed: 60 tests and 92 subtests in that regression run. Decision/workflow/review regressions passed: 88 tests, 1 skipped and 14 subtests. Existing quality checks also passed after the scope metadata/guard additions. These runs overlap some targeted checks; the counts are not a unique combined-suite total.

The original `project.yaml`, configuration YAML files, TOP segmentation engine, classifier engine/search/models, preprocessing algorithms, hardware profiles and VIG processing logic were retained. Integration edits add navigation, scope metadata/guards and ROI endpoints; they do not replace these backends. The standalone annotation tools are included in `tools/`.

## Environment limits and remaining qualification

Native browser rendering and canvas ergonomics were **not tested in the 2026-10-03 environment** because Chromium was unavailable. Subsequent browser validation is documented in [ROI segmentation verification](ROI_SEGMENTATION_VERIFICATION.md). `tests/browser_roi_workflow.cjs` supplies a reproducible local Playwright smoke test with synthetic images and actual dashboard APIs. Its JavaScript syntax and image/config fixture were checked; no browser screenshot or browser-pass evidence is claimed.

In that environment, one existing workspace test could not construct its PID fixture: `tests/test_workspace_studio.py::MountedWorkspaceTests::test_segmentation_pid_identity_never_signals_an_unrelated_process` raises `psutil.NoSuchProcess` for the current process before calling application code. The other 43 tests in that dataset/workspace/quality-dashboard regression run passed. The failure occurred during fixture construction, before application code ran.

No Windows, GPU/DirectML or real-camera accuracy qualification was performed. Fit the starter template to a clean training capture, inspect contextual crops and validate orientation/defect cases on independent units/trays. The current extension supports ROI dataset creation, localization/review, ROI classifier training through Classification, and localizer mask evaluation. The combined raw-image-to-final-die verdict, production recipe with all trained classifiers/thresholds, and end-to-end defect-escape metrics remain a separate next phase. Exported initial recipes record geometry/crop/localizer versions and empty model/threshold slots rather than claiming a qualified production pipeline.
