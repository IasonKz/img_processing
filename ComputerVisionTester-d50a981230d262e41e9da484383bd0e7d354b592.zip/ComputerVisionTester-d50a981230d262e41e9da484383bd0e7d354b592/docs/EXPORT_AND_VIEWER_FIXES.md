# Export and viewer corrections

The previous dependency message conflated a missing package with a native import failure and omitted the running Python path. Installing with an unrelated `pip` does not change the environment recorded in `.studio-python.txt` and used by `Start.cmd` and its export worker.

`Setup-Export.cmd` reads that interpreter record, upgrades `requirements-export.txt`, and runs `scripts/check_export.py`. The probe creates a small real ONNX graph and checks CPU runtime inference. CPU/CUDA `Setup.cmd` now includes export by default; use `-WithExport:$false` explicitly for an environment without export. Offline installations need matching ONNX wheels in the wheelhouse. Existing PyTorch wheels are preserved by the export repair script.

ONNX Runtime's older allowed versions could also coexist with NumPy 2 despite an incompatible native build. The corrected minimum is ONNX Runtime 1.20.1 and ONNX 1.17. Import failures now name the exact library, original error and running interpreter instead of always asking for requirements.

For Windows `DLL load failed` after installation, install or repair the Microsoft Visual C++ x64 redistributable required by [ONNX Runtime's installation documentation](https://onnxruntime.ai/docs/install/), then rerun `Setup-Export.cmd`. Microsoft supplies the current compatible x64 runtime at its [official download](https://aka.ms/vs/17/release/vc_redist.x64.exe). The export repair does not download or run that system installer automatically.

On Linux: `bash scripts/setup_export.sh`. Set `STUDIO_PYTHON` if the dashboard uses an interpreter other than `.venv-studio6/bin/python`. For an offline installation pass `--no-index --find-links /path/to/wheels`.

Successful classification exports include a verified ZIP, ONNX members, PatchCore memory banks where required, preprocessing, compact threshold/triage policy, standalone inference code, runtime requirements and integrity hashes. They exclude datasets, checkpoints, per-image parity predictions, full saved decisions and training histories. Numeric parity is still computed on the reserved selection records; its small summary remains in `export_validation.json`. Failed parity retains per-image diagnostics and never publishes a model ZIP. `--include-parity-predictions` is an explicit diagnostic option.

The explicit [PyTorch legacy ONNX exporter](https://docs.pytorch.org/docs/stable/onnx.html) remains selected with `dynamo=False`. Global + patches is now exported with fixed geometry, including every patch, and must pass the same real numeric and decision parity gates. A model/operator unsupported by ONNX is reported with its actual export error and produces no usable ZIP.

The laptop package uses CPU ONNX Runtime and does not need training dependencies or the original experiment. Copy and extract the whole ZIP, install its `requirements-runtime.txt` in a compatible Python environment, then run `predict.py`; see the bundled `OPERATOR_GUIDE.md`. Version pins describe the validated environment. GPU execution requires its separately compatible runtime and is recorded as unvalidated unless checked separately.

Image inspection now supports fullscreen, exact fit, 100% preview pixels, wheel/button zoom and drag pan. Brightness windows use native pixel values before 8-bit display conversion, with lower 0/min/custom and upper max/custom. Viewer changes never modify stored images, inference preprocessing or scores. Classification inspection and unit evidence share the viewer; evidence masks retain their semantic colors.

SVG charts show exact values from the nearest recorded sample while hovering a line. Clicking brings the selected series forward, thickens it and dims other series; clicking again clears selection. Selection survives live redraws. Training, threshold, learning-overlay, parallel and radar plots use the shared interaction. Newly generated standalone reports embed that interaction and need no network. Segmentation Plotly charts also highlight clicked traces.

Right-button pan is handled before annotation tools or vertex edits, preserving masks, polygons, undo history and geometry. Browser context menus are suppressed only over the relevant viewport/canvas.

Validation uses synthetic fixtures, not the user's trained models or image dataset:

- Real ResNet18, ensemble, PatchCore and 16-bit triage ONNX export and standalone inference.
- Real global + patches export with both max and top-k aggregation; the ZIP runs after deleting the original experiment.
- Native 16-bit window accuracy, custom clipping, constant images and invalid limits.
- Browser gestures for fullscreen fit, custom display limits, zoom/pan, hover/foreground selection and annotation right-drag followed by ordinary brush drawing.
- Existing deployment quality, dashboard access boundaries, ROI, image depth and report checks.

Windows setup scripts are provided for the user's environment; the validation host is Linux, so the Windows installer itself was not executed here.
