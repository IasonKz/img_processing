# Troubleshooting

Start with the exact command output, run path, `model_state.json`, and environment report. Preserve the failed run; do not erase evidence before diagnosing the failure.

```bash
python inspection.py doctor --config project.yaml --profile laptop
python scripts/check_environment.py --json environment.json
python -m pip check
```

| Symptom | Likely cause | Recovery |
| --- | --- | --- |
| Python cannot import `torch` | Training environment is not installed or active | Use the intended environment; follow the CPU/GPU installation procedure |
| Import error involving torchvision operators | Incompatible torch/torchvision or CPU/CUDA wheel pair | Rebuild a clean environment with a matched pair from one wheel family |
| Configured CUDA device unavailable | CPU build, driver issue, or inaccessible GPU | Review environment diagnostics; use CPU explicitly for a pilot or repair the GPU environment |
| Pretrained file missing | Local weights were not provisioned | Download public weights once on a connected setup machine, then copy the weights directory |
| No images discovered | Incorrect task root or unsupported layout/extensions | Point to the directory containing `good` and `bad`; inspect the audit report |
| Image exists in both labels | Content-identical image has conflicting ground truth | Review the source labels; preserve the correction in a new dataset revision |
| Grouping cannot be established | Filenames do not encode physical-unit identity | Supply `groups_csv` or a valid `group_regex`; do not declare independent units to bypass repeat views |
| A split lacks good or bad examples | Too few independent groups or restrictive split hints | Collect more independent examples or revise the evaluation design; do not use a one-class test as evidence of binary performance |
| Resume rejects changed data | Source bytes, labels, or split identity changed | Restore the recorded dataset revision or start a new update run |
| Image exceeds input envelope | Inference image is larger than the saved pad size | Correct upstream preprocessing or train/evaluate an explicit larger-envelope or fit-policy version |
| Out of memory | Large resolution, architecture, batch, or PatchCore feature bank | Reduce batch size or use a smaller explicit experiment; lower bank/reservoir settings only as a new PatchCore candidate |
| Laptop epoch takes a long time | CPU processes a high-resolution model | Use the pilot roster/budget; first estimate throughput; do not silently reduce resolution |
| Very many good images rejected | Threshold target, domain shifts, labeling, or anomaly novelty | Inspect false-rejection folders and compare tray subsets from the prediction records; tune only on designated development data |
| Accuracy is high but defects escape | Imbalance masks the critical error | Use bad escape counts/recall and confidence bounds; accuracy does not control selection |
| Zero escapes but qualification fails | Insufficient independent bad units for confidence requirement | Inspect the upper bound and denominator; acquire more independent qualification examples |
| PatchCore rejects acceptable rare marks | Rare accepted appearance is absent from the normal bank | Verify good labels and increase representative accepted variation in a new training bank |
| New run is worse than old | New labels/data distribution, overfitting, or forgetting | Retain the old active release; inspect version regressions and train with retained old data |
| Output directory already exists | Mixing batches or versions would overwrite evidence | Choose a fresh output directory; use supported resume only for an interrupted training run |
| ONNX package fails integrity checks | Incomplete copy or modified model/policy/bank | Recopy the complete intact package or regenerate it from the recorded source run |
| ONNX export parity fails | Unsupported graph behavior or numerical threshold sensitivity | Keep the PyTorch candidate; inspect parity results and resolve graph differences before release |
| CUDA ONNX provider unavailable | Wrong runtime distribution or missing CUDA dependencies | Install a compatible ONNX Runtime GPU environment or request CPU explicitly |
| Weights/checkpoints load warning | Untrusted or incompatible checkpoint | Load only artifacts from an authorized trusted origin and the compatible release |

## Interrupted training

Resume restores the last completed epoch, including optimizer and scheduler state when available. Work within the interrupted partial epoch may be repeated. Keep source data and the effective experiment configuration unchanged. Starting a new run with an edited training budget is different from exact continuation.

Changing the compute device may alter numerical results and throughput. Do not claim bitwise reproducibility across CPU/GPU, dependency releases, or nondeterministic kernels.

## PyCharm operation

Select the project virtual environment as the interpreter. Set the script to `inspection.py`, use the command arguments from the operator guide, and set the working directory to the project root. Windows worker-process behavior is most predictable with the supplied launcher/entry point and the laptop default `num_workers: 0` during diagnosis.

If a process remains active after an interrupt, inspect the operating system's process list and stop only the identified application process. Restart with `resume` after the process has stopped; concurrent writers must not operate on one run directory.

## Performance measurements

Record image dimensions, model, device, batch size, provider, and whether timing includes image decoding, preprocessing, copying, or only model scoring. End-to-end batch time can be dominated by filesystem copies. Do not compare a GPU model-only time with a laptop time that includes all I/O.

## Reporting an issue

Provide the application version, command, sanitized effective configuration, environment report, error trace, and run state. Use non-confidential reproductions when sharing outside the authorized environment. Trained checkpoints and PatchCore feature banks are derived artifacts and should follow the same local handling rules as the project data.
