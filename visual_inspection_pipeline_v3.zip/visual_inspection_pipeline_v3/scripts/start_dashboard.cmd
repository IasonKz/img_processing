@echo off
setlocal
cd /d "%~dp0.."
if not exist ".venv\Scripts\python.exe" (
    echo Missing .venv. Follow START_HERE.md or docs\INSTALLATION.md first.
    pause
    exit /b 2
)
".venv\Scripts\python.exe" "inspection.py" dashboard --config "project.yaml"
set "inspection_exit=%ERRORLEVEL%"
if not "%inspection_exit%"=="0" pause
exit /b %inspection_exit%
