"""Build an offline dashboard from existing run records; never execute a model."""
from inspection_visual.report import main

if __name__ == "__main__":
    raise SystemExit(main())
