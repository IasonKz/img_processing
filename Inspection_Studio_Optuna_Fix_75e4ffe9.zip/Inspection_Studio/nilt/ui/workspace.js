"use strict";
const WorkspaceStudio=window.WorkspaceStudio=(()=>{
  let family="classification",roiScope="whole_image",task="vig",mode="development",clean=null,cleanItem=null,cleanIndex=-1,cleanBusy=false,cleanRequest=0,trayCatalog=null,lastState=null,lastRun=null,tuneSelection="",datasetCounter=0;
  const frames=new Map(),segmentationTabs=new Map();
  const segmentationTitles={workspace:"Project & images",annotation:"Annotation",search:"Model search",results:"Results & compare",inspect:"Inspect & predict",export:"Export & deployment"};
  const on=(id,fn)=>$(id).addEventListener("click",()=>Promise.resolve().then(fn).catch(e=>notify(e.message,true)));
  function browseInput(input,kind="folder",append=false,mustexist=true){
    if(!input||input.dataset.picker)return;input.dataset.picker="yes";
    const row=document.createElement("div");row.className="browse-row";input.parentNode.insertBefore(row,input);row.appendChild(input);
    const button=document.createElement("button");button.type="button";button.className="secondary";button.textContent="Browse…";button.setAttribute("aria-label","Browse for "+(kind==="file"?"file":"folder"));row.appendChild(button);
    button.addEventListener("click",async()=>{button.disabled=true;try{const result=await api("/api/pick-path",{kind,initial:append?"":input.value,mustexist});if(result.path){input.value=append?(input.value.trim()?input.value.trim()+"\n":"")+result.path:result.path;input.dispatchEvent(new Event("change",{bubbles:true}));}}catch(e){notify(e.message,true);}finally{button.disabled=false;}});
  }
  for(const id of ["dataset","weights","load-run-path","predict-input","workflow-input","partial-input","clean-root","deploy-input"])browseInput($(id));
  for(const id of ["output","predict-output","workflow-output","package-output","partial-output","review-export-output"])browseInput($(id),"folder",false,false);
  browseInput($("prep-output"),"folder",false,false);browseInput($("prep-tray"));browseInput($("prep-folder"));browseInput($("prep-csv"),"file",true);
  const scopeOptions={vig:[["whole_image","Whole image"]],top:[["whole_image","Whole image"],["corners","Corners · TR + BL"],["label","Label"],["inner_area","Inner area"],["lens","Lens"]],bottom:[["whole_image","Whole image"],["pins","Pins · all 16"],["triangle","Triangle"],["square","Side rectangle / square"]]};
  function applyScope(){
    selectOptions("classification-scope",scopeOptions[task].map(([value,label])=>({value,label})),"Whole image",roiScope);roiScope=$("classification-scope").value;
    const datasets=boot?.roi_datasets?.[task]||{};$("dataset").value=roiScope==="whole_image"?(boot?.datasets?.[task]||""):(datasets[roiScope]||"");$("clean-root").value=$("dataset").value;
    $("task-development-caption").textContent=task.toUpperCase()+" / "+(roiScope==="whole_image"?"CLASSIFICATION":roiScope.replaceAll("_"," ").toUpperCase());
  }
  function selectTask(value){
    if(family!=="classification"&&value==="vig")value="top";
    $("notice").hidden=true;task=value;roiScope=boot?.roi_scopes?.[task]||"whole_image";
    document.querySelectorAll("[data-workspace]").forEach(b=>b.classList.toggle("active",b.dataset.workspace===task));
    if(![...$("task").options].some(o=>o.value===task)){const option=document.createElement("option");option.value=task;option.textContent=task.toUpperCase();$("task").appendChild(option);}
    $("task").value=task;applyScope();
    $("run-select").value="";lastRun=null;clean=null;cleanItem=null;$("clean-gallery").textContent="Open this task's dataset.";$("clean-image").hidden=true;
    workflowStages=[];workflowDefaultAdded=false;renderWorkflowStages();preview=null;
    if(typeof InspectionV5!=="undefined")InspectionV5.resetWorkspace();
    renderRun({path:"",state:{status:"Choose this task's experiment"},search:{},trials:[],histories:[],candidates:[],selected:{},splits:{},reports:[]});
    $("tray-roles").textContent="Load this task's trays.";trayCatalog=null;
    mode="development";syncMode();tab(family==="classification"?"setup":family==="roi"?"roi":"segmentation");
    if(boot?.tasks?.includes(task))$("task").dispatchEvent(new Event("change",{bubbles:true}));
    applyScope();
    refresh().catch(e=>notify(e.message,true));
  }
  function selectFamily(value){family=value;document.querySelectorAll("[data-family]").forEach(b=>b.classList.toggle("active",b.dataset.family===family));selectTask(family!=="classification"&&task==="vig"?"top":task);}
  function syncMode(){
    document.querySelectorAll("[data-workspace-mode]").forEach(b=>b.classList.toggle("active",b.dataset.workspaceMode===mode));
    document.querySelector(".workspace-modes").hidden=family!=="classification";
    document.querySelectorAll("[data-workspace]").forEach(b=>b.hidden=family!=="classification"&&b.dataset.workspace==="vig");
    $("classification-scope-label").hidden=family!=="classification";
    $("segmentation-target-label").hidden=family!=="segmentation";
    document.querySelectorAll("[data-vig-nav]").forEach(b=>b.hidden=family!=="classification"||mode!=="development");
    document.querySelectorAll("[data-segmentation-tab]").forEach(b=>b.hidden=family!=="segmentation"||$("segmentation-target").value==="roi_localizer");
    for(const id of ["nav-preprocessing","nav-cleaning","task-development-caption","data-preparation-caption"])$(id).hidden=family!=="classification"||mode!=="development";
    $("experiment-picker").hidden=family!=="classification";$("roi-navigation").hidden=family!=="roi";
    $("nav-deployment").hidden=family!=="classification"||task!=="vig"||roiScope!=="whole_image";$("deployment-caption").hidden=$("nav-deployment").hidden;$("nav-deployment-quality").hidden=$("nav-deployment").hidden;
    document.querySelector("[data-workspace-mode=deployment]").hidden=$("nav-deployment").hidden;
    $("deployment-vig").hidden=false;$("deployment-prototype").hidden=true;
    $("nav-deployment").innerHTML='<span>12</span>Run frozen pipeline';
  }
  document.querySelectorAll("[data-family]").forEach(b=>b.addEventListener("click",()=>selectFamily(b.dataset.family)));
  document.querySelectorAll("[data-workspace]").forEach(b=>b.addEventListener("click",()=>selectTask(b.dataset.workspace)));
  document.querySelectorAll("[data-workspace-mode]").forEach(b=>b.addEventListener("click",()=>{mode=b.dataset.workspaceMode;syncMode();tab(mode==="deployment"?"deployment":"setup");}));
  $("task").addEventListener("change",()=>{if($("task").value!==task)selectTask($("task").value);});
  async function setScope(value){
    const result=await api("/api/roi/classification",{side:task,roi_scope:value});roiScope=value;setup(result.config);applyScope();syncMode();
    $("run-select").value="";renderRun({path:"",state:{status:"Choose this target's experiment"},search:{},trials:[],histories:[],candidates:[],selected:{},splits:{},reports:[]});await refresh();
  }
  function ready(data){roiScope=data.roi_scopes?.[task]||"whole_image";applyScope();syncMode();}
  $("classification-scope").addEventListener("change",()=>setScope($("classification-scope").value).catch(e=>{notify(e.message,true);applyScope();}));
  function segmentationFrame(){
    if(family!=="segmentation")return null;
    const selected=window.SegmentationStudio?.selection();
    if(selected===null)return null;
    return mountSegmentation(selected?.context||task,selected?.prefix||"/segmentation/"+task);
  }
  function mountSegmentation(context,prefix){
    if(!frames.has(context)){let frame=$("segmentation-frame");if(frame.src&&frame.getAttribute("src")){frame=document.createElement("iframe");frame.title="Segmentation · "+context;$("segmentation-frame").parentNode.appendChild(frame);}frame.setAttribute("allow","fullscreen");frame.src=prefix+"/";frames.set(context,frame);}
    for(const [name,frame]of frames)frame.hidden=name!==context;
    return frames.get(context);
  }
  function segmentationChanged(name,section){
    if(!segmentationTitles[section])return;segmentationTabs.set(name,section);
    if(family!=="segmentation"||window.SegmentationStudio?.selection()===null)return;
    if(name!==(window.SegmentationStudio?.selection()?.context||task)||activeTab!=="segmentation")return;
    document.querySelectorAll("[data-segmentation-tab]").forEach(button=>{const selected=button.dataset.segmentationTab===section;button.classList.toggle("active",selected);if(selected)button.setAttribute("aria-current","page");else button.removeAttribute("aria-current");});
    $("page-title").textContent=(window.SegmentationStudio?.title()||task.toUpperCase())+" / "+segmentationTitles[section];$("page-eyebrow").textContent="SEGMENTATION / "+mode.toUpperCase();
    $("annotation-fullscreen").hidden=section!=="annotation";
  }
  function segmentationReady(name){const frame=frames.get(name);if(frame)frame.contentWindow.TopsegStudio?.selectTab(segmentationTabs.get(name)||"workspace");}
  function syncSegmentationNavigation(){
    const context=window.SegmentationStudio?.selection()?.context;
    if(context)segmentationChanged(context,segmentationTabs.get(context)||"workspace");
    else $("annotation-fullscreen").hidden=true;
  }
  function selectSegmentation(section){
    if(family!=="segmentation")return;const context=window.SegmentationStudio?.selection()?.context||task;segmentationTabs.set(context,section);tab("segmentation");
    const frame=segmentationFrame();if(frame){frame.contentWindow.TopsegStudio?.selectTab(section);segmentationChanged(context,section);}
    window.scrollTo({top:0,behavior:"instant"});
  }
  function tabChanged(name){
    mode=["deployment","deployment-quality"].includes(name)?"deployment":"development";syncMode();
    if(name==="deployment-quality")window.DeploymentQuality?.open().catch(e=>notify(e.message,true));
    if(name==="roi")window.RoiStudio?.open(task).catch(e=>notify(e.message,true));
    document.querySelectorAll("[data-segmentation-tab]").forEach(b=>{b.classList.remove("active");b.removeAttribute("aria-current");});
    $("annotation-fullscreen").hidden=true;
    if(name==="segmentation"){window.SegmentationStudio?.open(task).catch(e=>notify(e.message,true));const context=window.SegmentationStudio?.selection()?.context||task;segmentationFrame()?.contentWindow.NiltEmbedded?.layout();segmentationChanged(context,segmentationTabs.get(context)||"workspace");}
  }
  document.querySelectorAll("[data-segmentation-tab]").forEach(b=>b.addEventListener("click",()=>selectSegmentation(b.dataset.segmentationTab)));
  on("deployment-seg-export",()=>selectSegmentation("export"));
  on("annotation-fullscreen",async()=>{if(document.fullscreenElement)await document.exitFullscreen();else await $("main-content").requestFullscreen();});
  document.addEventListener("fullscreenchange",()=>{
    const focus=!!document.fullscreenElement;$("annotation-fullscreen").textContent=focus?"⛶ Exit full screen":"⛶ Full screen";$("annotation-fullscreen").setAttribute("aria-pressed",String(focus));
    if(focus)$("main-content").scrollTop=0;
    for(const frame of frames.values())frame.contentWindow.NiltEmbedded?.layout();
  });
  syncMode();
  on("stop-worker",async()=>{const result=await api("/api/stop-workers",{mode:"force"});notify(result.message+" Committed output is retained; unfinished batches may be incomplete.");await refresh();});
  function cleanPayload(){return {dataset:clean?.dataset,page:clean?.pagination?.page||1,label:$("clean-filter").value,tray:$("clean-tray").value,search:$("clean-search").value.trim()};}
  function renderClean(catalog){
    clean=catalog;$("clean-summary").textContent=Object.entries(catalog.counts).map(([label,n])=>`${label}: ${n}`).join(" · ");
    selectOptions("clean-tray",[{value:"",label:"All trays"},...Object.keys(catalog.trays).sort().map(value=>({value,label:value}))],"All trays");
    const host=$("clean-gallery");host.className=catalog.items.length?"clean-gallery":"empty";
    host.innerHTML=catalog.items.length?catalog.items.map((item,index)=>`<button class="clean-thumb" data-clean-index="${index}"><img src="${escapeHtml(item.image_url)}" loading="lazy" alt="${escapeHtml(item.relative_path)}"><span><b>${escapeHtml(item.label.toUpperCase())} · ${escapeHtml(item.tray)}</b>${escapeHtml(item.relative_path)}</span></button>`).join(""):"No images match these filters.";
    $("clean-page").textContent=`Page ${catalog.pagination.page} / ${catalog.pagination.pages} · ${catalog.pagination.total} images`;
    $("clean-page-prev").disabled=catalog.pagination.page<=1;$("clean-page-next").disabled=catalog.pagination.page>=catalog.pagination.pages;
  }
  async function loadClean(page=1){if(!clean)return;renderClean(await api("/api/cleaning?"+new URLSearchParams({...cleanPayload(),page})));}
  async function openClean(index){
    const item=clean?.items[index];if(!item){cleanItem=null;cleanIndex=-1;$("clean-image").hidden=true;$("clean-title").textContent="No image selected";return;}const sequence=++cleanRequest;cleanIndex=index;cleanItem=null;cleanBusy=true;$("clean-viewport").setAttribute("aria-busy","true");
    $("clean-title").textContent=item.relative_path;$("clean-image").src=item.image_url;$("clean-image").hidden=false;$("clean-current-label").textContent=item.label.toUpperCase();
    document.querySelectorAll("[data-clean-index]").forEach(card=>card.classList.toggle("active",Number(card.dataset.cleanIndex)===index));
    try{const details=await api("/api/cleaning/item?"+new URLSearchParams({dataset:clean.dataset,relative:item.relative_path}));if(sequence===cleanRequest)cleanItem={...item,...details};}finally{if(sequence===cleanRequest){cleanBusy=false;$("clean-viewport").setAttribute("aria-busy","false");}}
  }
  async function cleanStep(direction){
    if(!clean||cleanBusy)return;let index=cleanIndex+direction;
    if(index<0&&clean.pagination.page>1){await loadClean(clean.pagination.page-1);index=clean.items.length-1;}
    else if(index>=clean.items.length&&clean.pagination.page<clean.pagination.pages){await loadClean(clean.pagination.page+1);index=0;}
    if(index>=0&&index<clean.items.length)await openClean(index);
  }
  on("clean-open",async()=>{renderClean(await api("/api/cleaning/open",{path:$("clean-root").value}));await openClean(0);});
  $("clean-gallery").addEventListener("click",event=>{const item=event.target.closest("[data-clean-index]");if(item)openClean(Number(item.dataset.cleanIndex)).catch(e=>notify(e.message,true));});
  for(const id of ["clean-filter","clean-tray"])$(id).addEventListener("change",()=>loadClean().then(()=>openClean(0)).catch(e=>notify(e.message,true)));
  let searchTimer;$("clean-search").addEventListener("input",()=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>loadClean().then(()=>openClean(0)).catch(e=>notify(e.message,true)),250);});
  on("clean-previous",()=>cleanStep(-1));on("clean-next",()=>cleanStep(1));
  on("clean-page-prev",async()=>{await loadClean(clean.pagination.page-1);await openClean(0);});on("clean-page-next",async()=>{await loadClean(clean.pagination.page+1);await openClean(0);});
  on("clean-native",()=>$("clean-viewport").classList.toggle("native-size"));
  for(const label of ["good","bad","review","unsuitable"])on("clean-"+label,async()=>{if(!cleanItem||cleanBusy)throw Error("Choose an image and wait for it to load.");cleanBusy=true;try{const old=cleanIndex;const result=await api("/api/cleaning/move",{...cleanPayload(),relative:cleanItem.relative_path,label,expected_sha256:cleanItem.sha256});renderClean(result.catalog);$("clean-status").textContent="Moved to "+label+". Undo is available.";await openClean(Math.min(old,clean.items.length-1));}finally{cleanBusy=false;}});
  on("clean-undo",async()=>{const result=await api("/api/cleaning/undo",cleanPayload());renderClean(result.catalog);await openClean(0);$("clean-status").textContent="Last dataset move undone.";});
  on("trays-load",async()=>{trayCatalog=await api("/api/dataset-trays?"+new URLSearchParams({task,path:$("dataset").value}));$("tray-roles").className="table-scroll";$("tray-roles").innerHTML=`<table class="tray-role-table"><thead><tr><th>Tray</th><th>Good</th><th>Bad</th><th>Role</th></tr></thead><tbody>${trayCatalog.trays.map(row=>`<tr><td>${escapeHtml(row.tray)}</td><td>${row.counts.good||0}</td><td>${row.counts.bad||0}</td><td><select data-tray-role="${escapeHtml(row.tray)}">${[["development","Development · all splits"],["classification","Classification only"],["excluded","Excluded"]].map(([value,label])=>`<option value="${value}" ${row.role===value?"selected":""}>${label}</option>`).join("")}</select></td></tr>`).join("")}</tbody></table>`;});
  on("trays-save",async()=>{if(!trayCatalog)throw Error("Load the trays first.");const roles=Object.fromEntries([...$("tray-roles").querySelectorAll("[data-tray-role]")].map(input=>[input.dataset.trayRole,input.value]));setup(await api("/api/dataset-trays",{task,path:trayCatalog.path,roles}));notify("Tray roles saved. New audits and searches omit classification-only and excluded trays from every development split.");await refresh();});
  on("trays-classify",()=>{if(!trayCatalog)throw Error("Load and select tray roles first.");const trays=[...$("tray-roles").querySelectorAll("[data-tray-role]")].filter(input=>input.value==="classification").map(input=>input.dataset.trayRole);if(!trays.length)throw Error("Choose at least one classification-only tray.");addDataset(trayCatalog.path,trays);tab("tuning");});
  on("trays-predict",()=>{if(!trayCatalog)throw Error("Load and save tray roles first.");$("predict-input").value=trayCatalog.path;$("labeled").checked=true;tab("predict");notify("Select a saved decision and run classification. Only trays saved as classification-only will be scored.");});
  function addDataset(path="",trays=[]){
    const index=++datasetCounter,entry=document.createElement("div");entry.className="dataset-entry";
    entry.innerHTML=`<div class="entry-heading"><span>DATASET ${index}</span><button type="button" class="secondary small" data-remove-dataset>Remove</button></div><label>Name · optional<input class="tune-dataset-name"></label><label>Clean good/bad folder<input class="tune-dataset-path" spellcheck="false"></label><label>Selected trays · optional, comma separated<input class="tune-dataset-trays" placeholder="C83, C84"></label>`;
    $("tune-datasets").appendChild(entry);entry.querySelector(".tune-dataset-path").value=path;entry.querySelector(".tune-dataset-trays").value=trays.join(", ");browseInput(entry.querySelector(".tune-dataset-path"));entry.querySelector("[data-remove-dataset]").addEventListener("click",()=>entry.remove());
  }
  addDataset();on("tune-add",()=>addDataset());
  on("tune-start",async()=>{const datasets=[...$("tune-datasets").querySelectorAll(".dataset-entry")].map(entry=>({name:entry.querySelector(".tune-dataset-name").value.trim(),path:entry.querySelector(".tune-dataset-path").value.trim(),trays:entry.querySelector(".tune-dataset-trays").value.split(",").map(x=>x.trim()).filter(Boolean)}));if(!$("run-select").value)throw Error("Select a trained experiment first.");await api("/api/action",{action:"threshold-tune",run:$("run-select").value,candidate:$("tune-candidate").value,datasets,device:$("tune-device").value,options:{mode:$("tune-mode").value,goal:$("tune-goal").value,fp_weight:Number($("tune-fp").value),fn_weight:Number($("tune-fn").value),review_weight:Number($("tune-review-weight").value),max_review_rate:Number($("tune-review-limit").value)}});notify("Threshold experiment started. Datasets are scored once; monitor the operation log.");await refresh();});
  function renderTuning(){
    const chosen=lastState?.experiments?.tuning.find(row=>row.path===$("tune-results").value);$("tune-save").disabled=!chosen;
    if(!chosen){$("tune-summary").textContent="No completed threshold experiment for this task.";$("tune-chart").replaceChildren();$("tune-trays").replaceChildren();$("tune-frontier").replaceChildren();$("tune-report-link").hidden=true;return;}const report=chosen.report,b=report.best;$("tune-summary").className="";
    $("tune-summary").innerHTML=`<div class="tuning-kpis">${[[b.fp,"FALSE POSITIVES"],[b.fn,"FALSE NEGATIVES"],[b.review,"SENT FOR REVIEW"],[b.n,"LABELLED IMAGES"]].map(([value,label])=>`<div><strong>${value}</strong><span>${label}</span></div>`).join("")}</div><p><b>GOOD below ${number(b.good_threshold,8)}</b> · ${report.config.mode==="double"?"REVIEW between thresholds · ":""}<b>BAD at or above ${number(b.bad_threshold,8)}</b></p><p class="hint">${escapeHtml(report.candidate)} · ${escapeHtml(report.config.goal)} · ${report.unique_score_boundaries} score boundaries · ${report.attainable_combinations} attainable combinations · review ${percent(b.review_rate)}${report.development_path_overlap?" · "+report.development_path_overlap+" supplied images also occur in the model's development manifest":""}</p>`;
    table("tune-trays",[["Dataset","dataset_name"],["Tray","tray"],["Images","n"],["FP","fp"],["FN","fn"],["Review","review"]],report.per_tray);
    table("tune-frontier",[["Lower",r=>number(r.good_threshold,8)],["Upper",r=>number(r.bad_threshold,8)],["FP","fp"],["FN","fn"],["Review","review"]],report.frontier);
    plot("tune-chart",[{name:"False positives",color:"#b25a3d",points:report.single_curve.map(r=>[r.bad_threshold,r.fp])},{name:"False negatives",color:"#0076bd",points:report.single_curve.map(r=>[r.bad_threshold,r.fn])}],"Threshold");
    $("tune-report-link").href=chosen.url;$("tune-report-link").hidden=false;
  }
  $("tune-results").addEventListener("change",renderTuning);on("tune-refresh",refresh);
  on("tune-save",async()=>{const result=await api("/api/tuning/save-decision",{report:$("tune-results").value});notify("New threshold decision saved: "+result.path);await refresh();});
  on("deploy-freeze",async()=>{const value=$("deploy-source").value;if(!value)throw Error("Save and select a development recipe first.");const source=JSON.parse(value);const result=await api("/api/deployment/pipeline",{...source,name:$("deploy-name").value});await refresh();$("deploy-pipeline").value=result.path;notify("Pipeline version created.");});
  on("deploy-pick-zip",async()=>{const result=await api("/api/pick-path",{kind:"file",title:"Choose an image ZIP archive"});if(result.path)$("deploy-input").value=result.path;});
  on("deploy-run",async()=>{await api("/api/action",{action:"deploy-pipeline",pipeline:$("deploy-pipeline").value,input:$("deploy-input").value,device:$("deploy-device").value});notify("Deployment inspection started.");await refresh();});
  function runChanged(run){lastRun=run;const choices=[{value:"selected",label:"Selected candidate"},...(run.candidates||[]).map(candidate=>({value:candidate.name,label:candidate.name}))];selectOptions("tune-candidate",choices,"No trained candidates");}
  function stateChanged(state){
    window.DeploymentQuality?.stateChanged(state);
    lastState=state;if(boot&&!$("clean-root").value)$("clean-root").value=boot.datasets?.[task]||"";if(boot&&!$("deploy-input").value)$("deploy-input").value=boot.paths.incoming;
    const busy=(state.jobs||[]).some(job=>["running","unverified"].includes(job.status))||Object.values(state.segmentation||{}).some(value=>["running","starting","unverified"].includes(value.job.status))||Object.values(state.roi_jobs||{}).some(value=>["running","starting","queued","stopping","unverified"].includes(value.status));
    $("stop-worker").disabled=!busy;$("tune-start").disabled=busy;$("deploy-run").disabled=busy;
    const history=state.experiments||{tuning:[],pipelines:[],deployment:[]};
    selectOptions("tune-results",history.tuning.filter(r=>r.report.task===task&&(r.report.roi_scope||"whole_image")===roiScope).map(row=>({value:row.path,label:row.name+" · "+row.report.candidate})),"No completed experiment",tuneSelection||$("tune-results").value);tuneSelection="";renderTuning();
    const sources=[...(state.decisions||[]).filter(r=>r.task===task).map(r=>({value:JSON.stringify({kind:"decision",source:r.path}),label:"Decision · "+r.name})),...(state.workflows||[]).filter(r=>r.task===task).map(r=>({value:JSON.stringify({kind:"workflow",source:r.path}),label:"Workflow · "+r.name})),...(state.systems||[]).filter(r=>r.task===task).map(r=>({value:JSON.stringify({kind:"system",source:r.path}),label:"System · "+r.name}))];
    selectOptions("deploy-source",sources,"Save a decision or workflow first");selectOptions("deploy-pipeline",history.pipelines.filter(row=>(row.report.task||"vig")===task).map(row=>({value:row.path,label:row.report.name})),"Create a pipeline first");
    $("deploy-history").className=history.deployment.length?"":"empty";$("deploy-history").innerHTML=history.deployment.length?history.deployment.map(row=>`<div class="deployment-run"><strong>${escapeHtml(row.report.pipeline?.name||row.name)} · ${escapeHtml(row.report.status)}</strong><p>${escapeHtml(row.report.started_utc)} · ${escapeHtml(row.report.input)}</p><p>${Object.entries(row.report.counts||{}).map(([label,n])=>`${escapeHtml(label)}: ${n}`).join(" · ")}</p><p class="code-input">${escapeHtml(row.path.replace(/[\\/]report\.json$/, ""))}</p><div class="actions"><button class="primary small" data-deployment-quality="${escapeHtml(row.path.replace(/[\\/]report\.json$/, ""))}">Quality review</button><button class="secondary small" data-deployment-folder="${escapeHtml(row.path)}">Open results folder</button>${row.html_url?`<a class="primary small" href="${escapeHtml(row.html_url)}" target="_blank" rel="noopener">Short report</a>`:""}<a class="secondary small" href="${escapeHtml(row.url)}" target="_blank" rel="noopener">Run JSON</a></div></div>`).join(""):"No deployment runs yet.";
  }
  $("deploy-history").addEventListener("click",event=>{const button=event.target.closest("[data-deployment-folder]");if(button)api("/api/open-folder",{path:button.dataset.deploymentFolder}).then(result=>notify(result.message)).catch(error=>notify(error.message,true));});
  function showScores(item){
    const final={name:item.stage_results?.length?"Combined decision":"Model decision",score:item.bad_score,threshold:item.threshold,good_threshold:item.good_threshold,bad_threshold:item.bad_threshold,predicted_class:item.prediction,score_type:item.score_type};
    const rows=[...(item.stage_results||[]).map(row=>({...row,score:row.source_threshold!=null?(row.raw_score??row.score):row.score,threshold:row.threshold??row.source_threshold})),final];
    $("image-score-panel").innerHTML=rows.filter(row=>Number.isFinite(row.score)).map(row=>{const high=row.bad_threshold??row.threshold,low=row.good_threshold??high,prob=row.score_type==="bad_probability_uncalibrated"&&row.score>=0&&row.score<=1&&(!Number.isFinite(high)||high>=0&&high<=1);const clamp=v=>Math.min(100,Math.max(0,v*100));return `<div class="score-evidence"><h4>${escapeHtml(row.name||row.stage_name||row.candidate||"Model")}</h4><div class="score-numbers"><div><strong>${number(row.score,6)}</strong><span>${prob?"BAD-CLASS SCORE":"MODEL SCORE"}</span></div><div><strong>${number(high,6)}</strong><span>BAD THRESHOLD</span></div>${Number.isFinite(low)&&low!==high?`<div><strong>${number(low,6)}</strong><span>GOOD THRESHOLD</span></div>`:""}</div>${prob?`<div class="score-track" aria-label="Score ${row.score}; bad threshold ${high}"><i class="score-marker" style="left:${clamp(row.score)}%"></i>${Number.isFinite(high)?`<i class="threshold-marker" style="left:${clamp(high)}%"></i>`:""}${Number.isFinite(low)&&low!==high?`<i class="threshold-marker low" style="left:${clamp(low)}%"></i>`:""}</div>`:""}<p class="score-note">${escapeHtml(row.predicted_class||row.status||"Recorded score")}${Number.isFinite(high)?" · score − bad threshold = "+number(row.score-high,6):""}. A model score is not a calibrated certainty estimate.</p></div>`;}).join("");
  }
  async function reviewStep(direction){if(!$("image-dialog").open||!reviewItems.length)return;let index=reviewItems.findIndex(item=>item.id===reviewSelected?.id)+direction;if(index<0&&reviewPage>1){reviewPage--;await refreshReview();index=reviewItems.length-1;}else if(index>=reviewItems.length&&reviewPage<(reviewData?.pagination?.pages||1)){reviewPage++;await refreshReview();index=0;}if(index>=0&&index<reviewItems.length)openImage(index);}
  on("image-previous",()=>reviewStep(-1));on("image-next",()=>reviewStep(1));
  document.addEventListener("keydown",event=>{if(!["ArrowLeft","ArrowRight"].includes(event.key)||["INPUT","TEXTAREA","SELECT"].includes(event.target.tagName))return;const direction=event.key==="ArrowLeft"?-1:1;if($("image-dialog").open){event.preventDefault();reviewStep(direction).catch(e=>notify(e.message,true));}else if(activeTab==="cleaning"){event.preventDefault();cleanStep(direction).catch(e=>notify(e.message,true));}});
  function scopeState(state){const scoped={...state};for(const key of ["runs","decisions","workflows","review_sessions","models","systems"])scoped[key]=(state[key]||[]).filter(row=>(row.task||row.metadata?.task)===task&&(row.roi_scope||row.metadata?.roi_scope||"whole_image")===roiScope);return scoped;}
  return {task:()=>task,roiScope:()=>roiScope,family:()=>family,selectFamily,selectTask,applyScope,setScope,ready,tabChanged,stateChanged,runChanged,showScores,scopeState,segmentationChanged,segmentationReady,mountSegmentation,selectSegmentation,syncSegmentation:syncMode,syncSegmentationNavigation};
})();
