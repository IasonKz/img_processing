import tempfile
import unittest
from pathlib import Path

import numpy as np

from nilt.common import write_csv, write_json
from inspection_visual.report import build_report, load_run, native_telemetry


class V3VisualBridgeTests(unittest.TestCase):
    def fixture(self, root):
        run = root / "vig" / "run"
        write_json(run / "config.json", {"task": "vig", "search": {"enabled": True}})
        write_json(run / "model_state.json", {"status": "SEARCHING"})
        write_csv(run / "manifest.csv", [{"split": "selection", "label": 0, "group": "a", "pixel_hash": "a"},
                                         {"split": "selection", "label": 1, "group": "b", "pixel_hash": "b"}])
        return run

    def test_legacy_trials_and_confirmations_have_unique_histories(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            run = self.fixture(root)
            paths = ["models/resnet18_seed42", "search/resnet18/trial_00000",
                     "search/efficientnet_b0/trial_00000", "search/confirmations/resnet18_trial00000/seed_123"]
            for path in paths:
                write_csv(run / path / "history.csv", [{"epoch": 1, "val_pr_auc_bad": .6, "stage": "head_only"}])
            # Trial configuration files are not mistaken for new independent runs/models.
            write_json(run / "search/resnet18/trial_00000/config.json", {"task": "vig"})
            models = load_run(run)["models"]
            self.assertEqual(len(models), 4)
            self.assertEqual(len({m["name"] for m in models}), 4)
            self.assertTrue(all(m["history"][0]["val_pr_auc_bad"] == .6 for m in models))
            self.assertTrue(all(m["history"][0]["stage"] == "head_only" for m in models))

    def test_native_units_sessions_and_legacy_duplicate_exclusion(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            run = self.fixture(root)
            folder = run / "search/resnet18/trial_00000"
            base = {"session": "one", "epoch": 1, "batch": 4, "batches": 40,
                    "window_batches": 4, "window_images": 8, "window_seconds": 2,
                    "mean_batch_seconds": .5, "images_per_second": 4,
                    "ram_bytes": 2 * 2**20, "vram_bytes": 3 * 2**20,
                    "peak_vram_bytes": 5 * 2**20}
            write_csv(folder / "telemetry.csv", [base, {**base, "session": "two"}])
            write_csv(folder / "visual_telemetry/old/batch_windows.csv", [{"completed": 1, "seconds": 1000}])
            model = load_run(run)["models"][0]
            self.assertEqual(len(model["telemetry"]), 2)
            self.assertEqual({s["session"] for s in model["sessions"]}, {"one", "two"})
            row = model["telemetry"][0]
            self.assertEqual((row["batches"], row["images"], row["seconds"]), (4, 8, 2))
            self.assertEqual((row["rss_mib"], row["cuda_allocated_mib"], row["cuda_peak_allocated_mib"]), (2, 3, 5))
            self.assertEqual(row["seconds_per_batch"], .5)
            self.assertEqual(row["images_per_second"], 4)
            self.assertIsNone(row["cuda_reserved_mib"])
            self.assertEqual(row["completed"], 1)

    def test_missing_measurements_remain_null_and_partial_window_is_excluded(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            write_csv(folder / "telemetry.csv", [
                {"epoch": 1, "batch": 4, "window_batches": 4, "window_images": 4, "window_seconds": 2},
                {"epoch": 1, "batch": 4, "window_batches": 4, "window_images": 4, "window_seconds": ""}])
            records, sessions = native_telemetry(folder)
            self.assertIsNone(records[0]["rss_mib"])
            self.assertIsNone(records[0]["cuda_allocated_mib"])
            self.assertEqual(records[0]["images_per_second"], 2)
            self.assertIsNone(records[1]["seconds"])
            self.assertEqual(records[1]["completed"], 0)
            self.assertEqual(len(sessions), 2)

    def test_report_escapes_labels_and_never_opens_final_test_score_arrays(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            run = self.fixture(root)
            write_json(run / "search_status.json", {"current_model": "</script><script>evil()</script>"})
            write_json(run / "final_test_summary.json", {"metrics": {"accuracy": .5}})
            target = run / "final_test" / "scores.npy"
            target.parent.mkdir()
            target.write_bytes(b"invalid final-test array must never be opened")
            before = {p.relative_to(run): p.read_bytes() for p in run.rglob("*") if p.is_file()}
            html = build_report([run], root / "report.html").read_text(encoding="utf-8")
            self.assertNotIn("</script><script>evil()", html)
            self.assertIn("\\u003c/script>", html)
            after = {p.relative_to(run): p.read_bytes() for p in run.rglob("*") if p.is_file()}
            self.assertEqual(before, after)
            self.assertEqual(load_run(run)["final_test"]["metrics"]["accuracy"], .5)


if __name__ == "__main__":
    unittest.main()
