"""One background worker per output workspace; restart-safe process locking."""
import json
import os
import subprocess
import sys
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from .common import atomic_json, read_json, project_lock


class JobManager:
    def __init__(self,cfg):
        self.cfg=cfg
        self.root=Path(cfg['output_dir'])/'jobs'
        self.root.mkdir(parents=True,exist_ok=True)
        self.guard=threading.RLock()
        self.process=None

    def current(self):
        marker=self.root/'active.json'
        if not marker.exists(): return {'status':'idle'}
        job=read_json(marker); folder=self.root/job['id']
        state=read_json(folder/'status.json') if (folder/'status.json').exists() else {'status':'starting'}
        if state.get('status') in ('running','starting'):
            # psutil works on Windows and Unix, including stale PID detection.
            import psutil
            try:
                proc=psutil.Process(job['pid'])
                alive=proc.is_running() and proc.status()!=psutil.STATUS_ZOMBIE and abs(proc.create_time()-job['create_time'])<1
            except (psutil.NoSuchProcess,psutil.AccessDenied): alive=False
            if not alive:
                state={**state,'status':'interrupted','error':'Worker ended before completion. Check its log; restart the search to continue with new trials.'}
                atomic_json(folder/'status.json',state)
        log=folder/'worker.log'
        if log.exists():
            with log.open('rb') as f:
                f.seek(max(0,log.stat().st_size-10000)); tail=f.read().decode('utf-8',errors='replace')
        else:tail=''
        return {**state,'job_id':job['id'],'action':job['action'],'log':tail}

    def start(self,action,payload):
        if action not in ('search','preflight','evaluate','predict','export','dataset','import','report'):
            raise ValueError('Unknown operation.')
        with self.guard, project_lock(self.root):
            if self.current().get('status') in ('running','starting'):raise ValueError('An operation is already running. Stop it or wait for completion.')
            job_id=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')+'_'+uuid.uuid4().hex[:8]
            folder=self.root/job_id; folder.mkdir()
            atomic_json(folder/'request.json',{'cfg':self.cfg,'action':action,'payload':payload})
            atomic_json(folder/'status.json',{'status':'starting','action':action})
            with (folder/'worker.log').open('wb') as log:
                self.process=subprocess.Popen([sys.executable,'-m','topseg.worker',str(folder)],cwd=str(Path(__file__).parent.parent),stdout=log,stderr=subprocess.STDOUT)
            import psutil
            try: created=psutil.Process(self.process.pid).create_time()
            except psutil.NoSuchProcess:created=0
            atomic_json(self.root/'active.json',{'id':job_id,'pid':self.process.pid,'create_time':created,'action':action})
            return {'job_id':job_id,'status':'starting'}

    def stop(self):
        with self.guard:
            current=self.current()
            if current.get('job_id') and current.get('status') in ('starting','running'):
                (self.root/current['job_id']/'stop').touch()
                return {'status':'stop_requested','note':'The worker will stop at its next safe checkpoint. A running GPU operation must finish first.'}
            return {'status':'idle'}
