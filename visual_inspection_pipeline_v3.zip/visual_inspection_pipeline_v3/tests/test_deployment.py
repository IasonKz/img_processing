"""Deployment contract tests; real export test requires optional ML dependencies."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

import numpy as np
from PIL import Image

from nilt.deployment import parity_result
from nilt.runtime import (PackageRunner, choose_providers, nearest_bank_distances,
                          predict_package, prepare_image, safe_asset, sha_file, verify_package, load_rgb)


def write(path, value):
    path.write_text(json.dumps(value), encoding="utf-8")


def fake_package(root):
    root.mkdir()
    (root / "model.onnx").write_bytes(b"fake_model_for_runtime_contract_test")
    write(root / "package.json", {"format_version": 1, "task": "top", "model_version": "test/one",
        "qualification_status": "PILOT", "members": [{"onnx": "model.onnx", "kind": "supervised", "input_name": "images", "output_name": "bad_score"}]})
    write(root / "preprocessing.json", {"image_size": 32, "resize": "pad", "mean": [0, 0, 0], "std": [1, 1, 1]})
    write(root / "decision_policy.json", {"threshold": 0.5, "class_to_index": {"bad": 0, "good": 1},
        "rule": "bad_if_score_greater_equal_threshold", "score_type": "bad_probability_score"})
    write(root / "export_validation.json", {"status": "passed", "validated_providers": ["CPUExecutionProvider"],
        "versions": {"onnxruntime": "test", "numpy": np.__version__, "Pillow": Image.__version__}})
    write(root / "integrity.json", {"files": {p.name: sha_file(p) for p in root.iterdir()}})
    return root


def fake_ort():
    privacy = {"disabled": False, "events": []}

    def disable_telemetry_events():
        privacy["disabled"] = True
        privacy["events"].append("telemetry_disabled")

    class SessionOptions:
        pass

    class Session:
        def __init__(self, *args, **kwargs):
            if not privacy["disabled"]:
                raise AssertionError("An ONNX session was created before disabling platform telemetry.")
            privacy["events"].append("session_created")
            self.providers = kwargs["providers"]

        def disable_fallback(self):
            pass

        def get_providers(self):
            return self.providers

        def run(self, outputs, feed):
            return [np.array([feed["images"].mean()], dtype=np.float32)]

    return types.SimpleNamespace(__version__="test", get_available_providers=lambda: ["CPUExecutionProvider"],
                                  SessionOptions=SessionOptions, InferenceSession=Session,
                                  disable_telemetry_events=disable_telemetry_events, privacy=privacy)


class DeploymentContracts(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)

    def test_parity_rejects_changed_decisions_even_inside_tolerance(self):
        report = parity_result([0.499999], [0.500001], .5, atol=1e-4)
        self.assertEqual(report["status"], "failed")
        self.assertEqual(report["decision_mismatches"], 1)

    def test_onnx_platform_telemetry_disabled_before_session(self):
        package = fake_package(self.root / "package")
        backend = fake_ort()
        with patch.dict(sys.modules, {"onnxruntime": backend}):
            PackageRunner(package)
        self.assertEqual(backend.privacy["events"], ["telemetry_disabled", "session_created"])

    def test_runtime_stops_when_telemetry_opt_out_fails(self):
        package = fake_package(self.root / "package")
        backend = fake_ort()
        def fail_opt_out():
            raise RuntimeError("Telemetry opt-out failed")
        backend.disable_telemetry_events = fail_opt_out
        with patch.dict(sys.modules, {"onnxruntime": backend}):
            with self.assertRaisesRegex(RuntimeError, "Telemetry opt-out"):
                PackageRunner(package)
        self.assertEqual(backend.privacy["events"], [])

    def test_parity_accepts_raw_anomaly_scores(self):
        self.assertEqual(parity_result([.4, 12.0, 55.0], [.4, 12.000001, 55.0], 13)["status"], "passed")

    def test_parity_requires_finite_scores(self):
        self.assertEqual(parity_result([.4, np.nan], [.4, .5], .5)["status"], "failed")

    def test_package_paths_reject_traversal(self):
        for path in ("../a", "/tmp/a", "C:/a", "a\\b", "a/../b", "./a", ""):
            with self.subTest(path=path), self.assertRaises((ValueError, FileNotFoundError)):
                safe_asset(self.root, path)

    def test_package_checksums_detect_mutation(self):
        package = fake_package(self.root / "package")
        verify_package(package)
        (package / "model.onnx").write_bytes(b"changed")
        with self.assertRaisesRegex(ValueError, "integrity mismatch"):
            verify_package(package)

    def test_large_input_is_not_silently_resized(self):
        im = Image.new("RGB", (1200, 700))
        with self.assertRaisesRegex(ValueError, "exceeds"):
            prepare_image(im, {"image_size": 1024, "resize": "pad"})
        self.assertEqual(prepare_image(im, {"image_size": 1536, "resize": "pad"}).size, (1536, 1536))
        self.assertEqual(prepare_image(im, {"image_size": 640, "resize": "fit"}).size, (640, 640))

    def test_multiframe_images_require_explicit_extraction(self):
        path = self.root / "multiframe.tiff"
        Image.new("RGB", (32, 32), "white").save(path, save_all=True, append_images=[Image.new("RGB", (32, 32), "black")])
        with self.assertRaisesRegex(ValueError, "Multi-frame"):
            load_rgb(path)

    def test_exact_chunked_nearest_neighbor(self):
        random = np.random.default_rng(8)
        features = random.normal(size=(13, 8)).astype(np.float32)
        bank = random.normal(size=(19, 8)).astype(np.float32)
        bank[0] = features[0]
        expected = np.linalg.norm(features.astype(np.float64)[:, None] - bank.astype(np.float64)[None], axis=2).min(axis=1)
        actual = nearest_bank_distances(features, bank, query_chunk=3, bank_chunk=5)
        np.testing.assert_allclose(actual, expected, atol=1e-7)
        self.assertLess(actual[0], 1e-7)

    def test_cpu_requested_does_not_implicitly_use_cuda(self):
        self.assertEqual(choose_providers(["CPUExecutionProvider", "CUDAExecutionProvider"], "cpu"), ["CPUExecutionProvider"])
        with self.assertRaisesRegex(RuntimeError, "unavailable"):
            choose_providers(["CPUExecutionProvider"], "cuda")

    def test_runtime_creates_classification_and_error_folders(self):
        package = fake_package(self.root / "package")
        images = self.root / "images"
        for name in ("good", "bad"):
            (images / name).mkdir(parents=True)
        Image.new("RGB", (32, 32), "white").save(images / "good" / "same.png")
        Image.new("RGB", (32, 32), "black").save(images / "bad" / "same.png")
        (images / "bad" / "broken.png").write_bytes(b"invalid image")
        with patch.dict(sys.modules, {"onnxruntime": fake_ort()}):
            output = predict_package(package, images, self.root / "output", labeled=True)
        summary = json.loads((output / "inference_summary.json").read_text())
        self.assertEqual(summary["counts"], {"good": 1, "bad": 1, "review": 1})
        self.assertEqual(summary["evaluation"]["bad_to_good"], 1)
        self.assertEqual(summary["evaluation"]["good_to_bad"], 1)
        self.assertEqual(len(list((output / "errors" / "bad_to_good").iterdir())), 1)
        self.assertEqual(len(list((output / "errors" / "good_to_bad").iterdir())), 1)
        self.assertEqual(len(list((output / "predicted" / "review").iterdir())), 1)
        self.assertTrue((output / "predictions.csv").is_file())
        self.assertTrue(summary["provider_parity_validated"])
        self.assertTrue((images / "good" / "same.png").is_file())

    def test_existing_outputs_and_nested_input_are_rejected(self):
        package = fake_package(self.root / "package")
        images = self.root / "images"
        images.mkdir()
        Image.new("RGB", (32, 32)).save(images / "a.png")
        with self.assertRaisesRegex(ValueError, "non-nested"):
            predict_package(package, images, images / "out")
        output = self.root / "out"
        output.mkdir()
        (output / "existing.txt").write_text("preserve me")
        with self.assertRaises(FileExistsError):
            predict_package(package, images, output)

    def test_failed_export_cannot_be_run(self):
        package = fake_package(self.root / "package")
        write(package / "export_validation.json", {"status": "failed"})
        write(package / "integrity.json", {"files": {p.name: sha_file(p) for p in package.iterdir() if p.name != "integrity.json"}})
        with self.assertRaisesRegex(ValueError, "parity"):
            PackageRunner(package)

    def test_empty_input_does_not_create_output(self):
        package = fake_package(self.root / "package")
        source = self.root / "images"
        source.mkdir()
        with self.assertRaisesRegex(ValueError, "No supported"):
            predict_package(package, source, self.root / "output")
        self.assertFalse((self.root / "output").exists())

    def test_standalone_runtime_imports_without_training_packages(self):
        module = Path(__file__).parents[1] / "nilt" / "runtime.py"
        script = '''
import importlib.abc, importlib.util, sys
class DenyTraining(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path, target=None):
        if fullname.split('.')[0] in ('torch', 'torchvision', 'sklearn', 'scipy', 'yaml'):
            raise AssertionError('Training import in runtime: ' + fullname)
sys.meta_path.insert(0, DenyTraining())
spec = importlib.util.spec_from_file_location('portable_runtime', sys.argv[1])
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
print('runtime imports independently')
'''
        result = subprocess.run([sys.executable, "-c", script, str(module)], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)


@unittest.skipUnless(all(importlib.util.find_spec(n) for n in ("torch", "torchvision", "onnx", "onnxruntime")),
                     "Requires optional training/export integration dependencies")
class RealDeploymentIntegration(unittest.TestCase):
    def test_real_supervised_onnx_export(self):
        from nilt import deployment, workflow
        from nilt.engine import make_model, save_checkpoint
        from nilt.data import pixel_signature
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            run = root / "run"
            run.mkdir()
            cfg = {"task": "top", "image_size": 64, "resize": "pad", "device": "cpu", "cpu_threads": 1,
                   "num_workers": 0, "training": {"batch_size": 1, "eval_batch_size": 1, "amp": False}, "policy": {}}
            model, _ = make_model("resnet18")
            model.eval()
            save_checkpoint(run / "best.pt", model, cfg, "resnet18", 42, 0)
            rows = []
            for i, color in enumerate(("white", "black")):
                path = root / f"image{i}.png"
                Image.new("RGB", (56, 52), color).save(path)
                rows.append({"path": str(path), "relative_path": path.name, "label": i, "split": "selection", "pixel_hash": pixel_signature(path)[0]})
            write(run / "config.json", cfg)
            (run / "manifest.csv").write_text("integration fixture")
            write(run / "selected.json", {"name": "resnet18_fixture", "threshold": .99, "status": "PILOT",
                  "members": [{"checkpoint": "best.pt", "sha256": sha_file(run / "best.pt"), "architecture": "resnet18"}]})
            with patch.object(workflow, "open_run", return_value=(cfg, rows)):
                output = deployment.export_package(run, root / "package")
            runner = PackageRunner(output)
            self.assertTrue(0 <= runner.score(rows[0]["path"]) <= 1)
            report = json.loads((output / "export_validation.json").read_text())
            self.assertEqual(report["status"], "passed")
            self.assertEqual(report["decision_mismatches"], 0)


    def test_real_patchcore_onnx_export(self):
        import torch
        from nilt import deployment, workflow
        from nilt.engine import checkpoint_metadata
        from nilt.patchcore import make_patchcore_extractor
        from nilt.data import pixel_signature
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            run = root / "run"
            run.mkdir()
            cfg = {"task": "top", "image_size": 64, "resize": "pad", "device": "cpu", "cpu_threads": 1,
                   "num_workers": 0, "training": {"batch_size": 1, "eval_batch_size": 1, "amp": False}, "policy": {}}
            extractor = make_patchcore_extractor("resnet18")
            with torch.inference_mode():
                channels = extractor(torch.zeros(1, 3, 64, 64)).shape[1]
            checkpoint = checkpoint_metadata(cfg, "patchcore", 42, 0)
            checkpoint.update(kind="patchcore", backbone="resnet18", state_dict=extractor.state_dict(),
                              memory_bank=torch.randn(8, channels), num_neighbors=1)
            torch.save(checkpoint, run / "best.pt")
            rows = []
            for i, color in enumerate(("white", "black")):
                path = root / f"image{i}.png"
                Image.new("RGB", (56, 52), color).save(path)
                rows.append({"path": str(path), "relative_path": path.name, "label": i, "split": "selection", "pixel_hash": pixel_signature(path)[0]})
            write(run / "config.json", cfg)
            (run / "manifest.csv").write_text("integration fixture")
            write(run / "selected.json", {"name": "patchcore_fixture", "threshold": 1000, "status": "PILOT",
                  "members": [{"checkpoint": "best.pt", "sha256": sha_file(run / "best.pt"), "architecture": "patchcore", "kind": "patchcore"}]})
            with patch.object(workflow, "open_run", return_value=(cfg, rows)):
                output = deployment.export_package(run, root / "package")
            runner = PackageRunner(output)
            self.assertGreaterEqual(runner.score(rows[0]["path"]), 0)
            self.assertTrue((output / "members" / "000" / "memory_bank.npy").is_file())
            report = json.loads((output / "export_validation.json").read_text())
            self.assertEqual(report["status"], "passed")

    def test_real_supervised_ensemble_onnx_export(self):
        from nilt import deployment, workflow
        from nilt.engine import make_model, save_checkpoint
        from nilt.data import pixel_signature
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            run = root / "run"
            run.mkdir()
            cfg = {"task": "top", "image_size": 64, "resize": "pad", "device": "cpu", "cpu_threads": 1,
                   "num_workers": 0, "training": {"batch_size": 1, "eval_batch_size": 1, "amp": False}, "policy": {}}
            members = []
            for index in range(2):
                model, _ = make_model("resnet18")
                path = run / f"member{index}.pt"
                save_checkpoint(path, model.eval(), cfg, "resnet18", 42 + index, 0)
                members.append({"checkpoint": path.name, "sha256": sha_file(path), "architecture": "resnet18"})
            path = root / "image.png"
            Image.new("RGB", (56, 52), "white").save(path)
            rows = [{"path": str(path), "relative_path": path.name, "label": 1, "split": "selection", "pixel_hash": pixel_signature(path)[0]}]
            write(run / "config.json", cfg)
            (run / "manifest.csv").write_text("integration fixture")
            write(run / "selected.json", {"name": "ensemble_fixture", "threshold": .99, "status": "PILOT", "members": members})
            with patch.object(workflow, "open_run", return_value=(cfg, rows)):
                output = deployment.export_package(run, root / "package")
            runner = PackageRunner(output)
            self.assertEqual(len(runner.sessions), 2)
            self.assertTrue(0 <= runner.score(path) <= 1)
            self.assertEqual(json.loads((output / "export_validation.json").read_text())["status"], "passed")


if __name__ == "__main__":
    unittest.main()
