# Integrated compatibility features

Inspection Studio 4 includes the earlier policy review, threshold export, visual reporting, telemetry, and Windows file-publishing fixes. No add-on installation is required.

Use [START_HERE.md](START_HERE.md) for installation and [EXPERIMENT_GUIDE.md](docs/EXPERIMENT_GUIDE.md) for the current workflow. The retained `review_thresholds.py`, `threshold_addon.py`, and visual-report entry points support earlier experiment formats; they are not additional packages to overlay on this release.

Policy calibration attempts both configured error limits. If no threshold satisfies both, the balanced-accuracy fallback remains explicitly a development decision with unmet targets. It does not qualify a weak model by rejecting every good image.

Changing a threshold changes the decision. It does not retrain image features or repair a poorly separating model.
