# Model catalog and local weights

The built-in catalog contains 20 candidate pairs across 13 architecture families. Every pair shares the same canonical three-class semantic dataset. The architecture list is explicit rather than claiming universal support for all segmentation research systems.

| Architecture | Ready-made encoders |
|---|---|
| Small U-Net | Built-in lightweight encoder |
| U-Net | ResNet18, ResNet34, MobileNetV2, EfficientNet-B0 |
| U-Net++ | ResNet18 |
| FPN | ResNet18 |
| PSPNet | ResNet18 |
| DeepLabV3 | ResNet18 |
| DeepLabV3+ | ResNet18, ResNet50 |
| LinkNet | ResNet18 |
| MAnet | ResNet18 |
| PAN | ResNet18; use image size >=256 |
| UPerNet | ResNet18, ConvNeXt-Tiny |
| SegFormer | MiT-B0, MiT-B2 |
| DPT | ViT-Small patch16, DINOv2 ViT-Small patch14 with adapted pyramid |

Model search → Custom architecture / encoder combinations lets you load installed SMP/timm names, choose an architecture, add a candidate and edit its settings. Names in the list do not imply that every architecture/encoder pair is valid. Preflight checks the actual pair and all selected resolutions with the largest batch size.

Example custom candidate:

```json
[
  {
    "id": "unet_resnet34_local",
    "architecture": "Unet",
    "encoder": "resnet34",
    "encoder_checkpoint": "C:/weights/unet_resnet34_encoder.pt",
    "normalization": "imagenet",
    "kwargs": {}
  }
]
```

`encoder_checkpoint` is a **local encoder state_dict** matching `model.encoder` for SMP 0.5.0. Loading is strict; arbitrary classification model state_dicts may have different names or heads. Save the encoder state_dict from the same SMP architecture/encoder, then transfer it to the offline workstation. DPT's encoder contains its timm model; preserve that key hierarchy. Files are loaded with `torch.load(weights_only=True)`.

No weights are bundled. Built-in candidates use random initialization. For a small real dataset, using suitable local pretrained encoders may substantially change the result. Training settings and the checkpoint record the encoder specification and source weight checksum.

The model adapter embeds normalization and handles architecture padding. Small U-Net receives RGB/255; other default models use ImageNet mean/std after RGB/255. Input images keep their aspect ratio. The same preprocessing is used by training, evaluation, prediction and exports.

DPT's patch14 encoder uses a nominal patch16 decoder pyramid, followed by interpolation to the actual input grid. This avoids the inconsistent reassembly factors in the pinned SMP version while preserving the encoder. It is an adapted DPT implementation, and requires its saved specification to reconstruct weights.

ONNX export is fixed input size and batch 1. It is accepted only after ONNX validation and numerical comparison in ONNX Runtime. Unsupported operations in a custom model can still prevent export; the portable PyTorch package remains available for completed models.

Instance/promptable systems (YOLO-seg, SAM, Mask2Former) are outside the current training registry. Exact semantic masks and derived COCO connected-component RLE are exported for reuse; this conversion does not recover separate object identities when two defects touch.
