from __future__ import annotations

import argparse

from qc.config import load_yaml
from qc.evaluation import run_prediction_evaluation


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Compare predictions.csv with an evaluation_results.csv ground truth."
    )
    parser.add_argument("--config", required=True, help="Path to an evaluation YAML file")
    args = parser.parse_args()
    result = run_prediction_evaluation(load_yaml(args.config))
    print(f"\nEvaluation output: {result['output_folder']}")
    print(f"False passes: {result['metrics']['false_pass']}")


if __name__ == "__main__":
    main()
