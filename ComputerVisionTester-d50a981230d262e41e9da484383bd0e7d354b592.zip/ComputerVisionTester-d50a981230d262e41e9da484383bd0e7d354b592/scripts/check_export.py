"""Prove imports, PyTorch ONNX export and CPU runtime inference in this environment."""
from pathlib import Path
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def main():
    import numpy as np
    import torch
    from nilt.export_support import export_dependencies
    onnx, ort = export_dependencies()
    print("Export Python:", sys.executable)
    print("ONNX:", onnx.__version__, "ONNX Runtime:", ort.__version__)

    class Probe(torch.nn.Module):
        def forward(self, x):
            return torch.sigmoid(x + 1)

    model = Probe().eval()
    sample = torch.arange(6, dtype=torch.float32).reshape(1, 6)
    with tempfile.TemporaryDirectory(prefix="studio-export-check-") as temporary:
        path = Path(temporary) / "probe.onnx"
        with torch.inference_mode():
            reference = model(sample).numpy()
            torch.onnx.export(model, sample, str(path), input_names=["images"], output_names=["scores"],
                              opset_version=17, dynamo=False, external_data=False)
        onnx.checker.check_model(str(path))
        session = ort.InferenceSession(str(path), providers=["CPUExecutionProvider"])
        actual = session.run(["scores"], {"images": sample.numpy()})[0]
        np.testing.assert_allclose(actual, reference, atol=1e-6, rtol=1e-5)
    print("ONNX export and CPU inference passed. Restart the dashboard.")


if __name__ == "__main__":
    main()
