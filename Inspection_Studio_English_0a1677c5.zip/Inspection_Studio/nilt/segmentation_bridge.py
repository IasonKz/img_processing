"""Mount the supplied studio under isolated, same-origin TOP/BOTTOM routes."""
from pathlib import Path
import re
import secrets
import threading
from types import SimpleNamespace
from urllib.parse import urlsplit


def workspace(app, task, port, *, kind=None, export_id=None, legacy=False):
    if task not in ("top", "bottom"):
        raise ValueError("Segmentation workspaces are TOP or BOTTOM.")
    if kind is None and task == "bottom" and not legacy:
        raise ValueError("BOTTOM segmentation supports ROI crops only. Select an exported ROI dataset.")
    if kind is not None:
        from .roi.datasets import DEFAULT_KINDS
        if kind not in DEFAULT_KINDS[task] or not isinstance(export_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]+", export_id):
            raise ValueError("Choose a valid ROI kind and export for this segmentation view.")
    key = task if kind is None else f"{task}:roi:{kind}:{export_id}"
    from topseg.common import load_config
    from topseg.project import Project
    from topseg.jobs import JobManager
    import yaml
    with app.lock:
        if not hasattr(app, "segmentation_workspaces"):
            app.segmentation_workspaces = {}
        if key not in app.segmentation_workspaces:
            root = app.config.parent / "segmentation" / task
            if kind is not None:
                root = root / "roi" / kind / export_id
                if not (root / "project.yaml").is_file():
                    raise ValueError("Open this ROI export through the shared crop annotation workflow first.")
            root.mkdir(parents=True, exist_ok=True)
            config_path = root / "project.yaml"
            if not config_path.is_file():
                input_dir = app.raw.get("tasks", {}).get(task, {}).get("dataset_root", str(app.config.parent / "input" / task))
                config_path.write_text(yaml.safe_dump({"name": task + "_segmentation", "task": task, "input_dir": str(app._configured_path(input_dir)),
                    "project_dir": str(root / "annotations"), "output_dir": str(root / "results")}), encoding="utf-8")
            cfg = load_config(config_path)
            app.segmentation_workspaces[key] = SimpleNamespace(project=Project(cfg), project_lock=threading.RLock(),
                session_token=secrets.token_urlsafe(32), cfg=cfg, config_path=config_path, jobs=JobManager(cfg),
                server_port=port, local_hosts={f"127.0.0.1:{port}", f"localhost:{port}"})
        server = app.segmentation_workspaces[key]
        if port:
            server.server_port = port
            server.local_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
        return server


def dispatch(app, handler):
    from topseg.studio_server import StudioHandler
    parts = urlsplit(handler.path).path.split("/")
    if len(parts) < 4 or parts[2] not in ("top", "bottom"):
        raise ValueError("Unknown segmentation workspace.")
    task, prefix = parts[2], "/segmentation/" + parts[2]
    kind = export_id = None
    if parts[3] == "roi":
        if len(parts) < 7:
            raise ValueError("Choose a segmentation ROI kind and export.")
        kind, export_id = parts[4:6]
        prefix += f"/roi/{kind}/{export_id}"
    context = task if kind is None else f"{task}:roi:{kind}:{export_id}"
    state = workspace(app, task, handler.server.server_port, kind=kind, export_id=export_id)
    # StudioHandler rewrites /annotate to / before serving the editor HTML.
    # Preserve the outer route so the editor receives its own layout overrides.
    embedded_kind = "annotation" if urlsplit(handler.path).path == prefix + "/annotate" else "studio"

    class MountedHandler(StudioHandler):
        def _send(self, status, data, content_type="application/json; charset=utf-8"):
            def urls(value):
                if isinstance(value, str) and value.startswith("/api/"):
                    return prefix + value
                if isinstance(value, dict):
                    return {key: urls(v) for key, v in value.items()}
                if isinstance(value, list):
                    return [urls(v) for v in value]
                return value
            data = urls(data)
            if "html" in content_type:
                if isinstance(data, bytes):
                    data = data.decode("utf-8")
                data = data.replace('href="/', 'href="' + prefix + '/').replace('src="/', 'src="' + prefix + '/')
                if task == "bottom":
                    data = data.replace("Top Segmentation", "Bottom Segmentation").replace("Top Inspection", "Bottom Inspection").replace("Top segmentation", "Bottom segmentation").replace("TOP IMAGES ONLY", "BOTTOM WORKSPACE").replace("TOP ONLY", "BOTTOM ROI").replace("top-image", "bottom-image").replace("Top image folder", "Bottom ROI folder")
                kind = embedded_kind
                data = data.replace("<html ", f'<html data-embedded="{kind}" data-segmentation-task="{task}" data-segmentation-context="{context}" ', 1)
                data = data.replace("<body>", f'<body class="integrated-{kind}">', 1)
                data = data.replace("</head>", f'<script src="/theme.js"></script><link rel="stylesheet" href="/theme.css"><link rel="stylesheet" href="{prefix}/embedded.css"><script src="{prefix}/embedded.js" defer></script></head>')
            elif "javascript" in content_type and not self.path.endswith(("plotly.min.js", "embedded.js")):
                if isinstance(data, bytes):
                    data = data.decode("utf-8")
                # Keep all original controller logic; mount its absolute API/iframe URLs.
                data = re.sub(r"([\"'`])/(api/|annotate)", lambda m: m[1] + prefix + "/" + m[2], data)
            return super()._send(status, data, content_type)

        def do_POST(self):
            if urlsplit(self.path).path == "/api/studio/start":
                if not self._authorize(mutate=True):
                    return
                with app.lock:
                    if app.roi_busy():
                        return self._send(400, {"error": "Stop the active ROI worker before starting segmentation."})
                    app._refresh_recovered_jobs()
                    if any(j.get("status") in ("running", "unverified") for j in app.jobs) or getattr(app, "_v5_operation", None):
                        return self._send(400, {"error": "Stop the active classification worker before starting segmentation."})
                    if any(server is not state and server.jobs.current().get('status') in ('starting','running','unverified')
                           for server in getattr(app,'segmentation_workspaces',{}).values()):
                        return self._send(400, {"error": "Stop the active segmentation worker before starting another project."})
            return super().do_POST()

    mounted = object.__new__(MountedHandler)
    mounted.__dict__.update(handler.__dict__)
    mounted.server = state
    mounted.path = handler.path[len(prefix):] or "/"
    if mounted.path in ("/embedded.js", "/embedded.css"):
        suffix = Path(mounted.path).suffix
        asset = Path(__file__).with_name("ui") / ("segmentation_embed" + suffix)
        mounted._send(200, asset.read_bytes(), "text/javascript; charset=utf-8" if suffix == ".js" else "text/css; charset=utf-8")
    elif handler.command == "POST":
        mounted.do_POST()
    else:
        mounted.do_GET()
    handler.close_connection = mounted.close_connection


def state(app):
    # Recover previously started workers even when their tab has not been opened.
    for task in ("top", "bottom"):
        if (app.config.parent / "segmentation" / task / "project.yaml").is_file():
            workspace(app, task, 0, legacy=True)
        root = app.config.parent / "segmentation" / task / "roi"
        for cfg in root.glob('*/*/project.yaml'):
            workspace(app, task, 0, kind=cfg.parent.parent.name, export_id=cfg.parent.name)
    return {key: {"job": server.jobs.current(), "project": server.cfg["project_dir"], "input": server.cfg["input_dir"],
                  "side": server.cfg['task'], "roi_source": server.cfg.get('roi_source')}
            for key, server in getattr(app, "segmentation_workspaces", {}).items()}
