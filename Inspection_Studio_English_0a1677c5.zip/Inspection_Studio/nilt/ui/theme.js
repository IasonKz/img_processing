"use strict";
(() => {
  const root = document.documentElement;
  let preference = "dark";
  try { preference = localStorage.getItem("nilt-theme") || "dark"; } catch {}
  function apply(value) {
    const theme = value === "light" ? "light" : "dark";
    root.classList.add("theme-changing");
    root.dataset.theme = theme;
    requestAnimationFrame(() => requestAnimationFrame(() => root.classList.remove("theme-changing")));
    const button = document.getElementById("theme-toggle");
    if (button) {
      button.textContent = theme === "dark" ? "☀ Light mode" : "☾ Night mode";
      button.setAttribute("aria-pressed", String(theme === "dark"));
      button.title = theme === "dark" ? "Switch to light mode" : "Switch to navy / black night mode";
    }
    document.querySelectorAll("iframe").forEach(frame => {
      try { frame.contentWindow.NiltTheme?.apply(theme); } catch {}
    });
    if (window.Plotly) document.querySelectorAll(".js-plotly-plot").forEach(el => {
      const palette = colors();
      Plotly.relayout(el, {"font.color": palette.text, "xaxis.gridcolor": palette.line,
        "yaxis.gridcolor": palette.line, "paper_bgcolor": "transparent", "plot_bgcolor": "transparent"});
    });
    document.dispatchEvent(new CustomEvent("nilt-theme-changed", {detail: theme}));
  }
  function colors() {
    return root.dataset.theme === "dark" ? {text: "#a6bbcf", line: "#24364b"} : {text: "#667a8d", line: "#e6edf2"};
  }
  window.NiltTheme = {apply, colors};
  apply(preference);
  document.addEventListener("DOMContentLoaded", () => {
    apply(root.dataset.theme);
    document.getElementById("theme-toggle")?.addEventListener("click", () => {
      const next = root.dataset.theme === "dark" ? "light" : "dark";
      try { localStorage.setItem("nilt-theme", next); } catch {}
      apply(next);
    });
  });
  window.addEventListener("storage", event => { if (event.key === "nilt-theme") apply(event.newValue); });
})();
