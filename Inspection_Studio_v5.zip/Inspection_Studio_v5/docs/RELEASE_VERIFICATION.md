# Release verification — Inspection Studio 5.0.0

Verification date: 22 September 2026.

## Verification record

Executed on Linux with Python 3.12.14, PyTorch 2.7.1+cpu, torchvision 0.22.1+cpu and Optuna 4.5.0.

| Check | Result |
| --- | --- |
| Python regression suite | 374 tests run; 373 passed; 1 skipped; no failures |
| Native Windows file-lock integration | Skipped: requires Windows |
| Existing interface interaction harness | Passed |
| Custom-search and Decision Lab interface harness | Passed |
| Search analytics and model-comparison harness | Passed |
| Firefox browser with local server | Passed: startup without dataset, original NILT logo, custom 48-hour CUDA contract validation, chart rendering, no JavaScript errors |
| Visual inspection at 1440 × 1000 | Search controls, search analytics and candidate comparison inspected |

The browser's chart-rendering check used synthetic display records, not measured production performance. Selecting CUDA was a configuration validation test, not GPU execution. Full suite output is retained in `validation/unit_tests.txt`.

## Coverage

The software checks cover custom Optuna contracts and stopping states, CPU training, native-image and global-plus-patch behavior, weighted loss, dataset/group integrity, decisions, frozen systems, controlled review exports, checkpoint integrity, and HTTP/UI behavior. Synthetic fixtures exercise program behavior; they do not measure performance on production images.

## Destination-machine checks

- Windows PowerShell/CMD launchers, native file locking, and process behavior require a Windows execution check. Linux execution does not establish these results.
- CUDA execution, driver compatibility, VRAM capacity, and workstation throughput require the target GPU.
- Firefox layout was inspected on Linux. Check display scaling and the browser used on the destination machine.
- Model quality requires representative labeled images. No customer accuracy, bad-escape rate, or good-reject rate is inferred from synthetic software tests.

See [VALIDATION_REPORT.md](VALIDATION_REPORT.md) for installation and model acceptance.

## Repeat software checks

From PowerShell in the project folder:

```powershell
$StudioPython = (Get-Content .studio-python.txt -Raw).Trim()
& $StudioPython -m unittest discover -s tests -p 'test_*.py'
```

On Linux:

```bash
.venv-studio5/bin/python -m unittest discover -s tests -p 'test_*.py'
```

Optional interface behavior checks, with Node.js installed:

```bash
node tests/test_v4_ui.cjs
node tests/test_v5_ui.cjs
node tests/test_v5_analytics.cjs
```

Node.js is only required for these development checks. The application itself runs with Python and a local browser.
