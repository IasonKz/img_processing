# Inspection Studio 6.1

## Laptop Intel graphics training

The new **Laptop · Intel iGPU (experimental)** preset runs model training with
`directml:0`. It is not merely a graphics setting for the dashboard. The original
Laptop preset remains CPU-based. On a Windows laptop, run `Setup-DirectML.cmd`
once, open `Start.cmd`, and select the iGPU preset. Its two-hour budget, model
list and other settings are editable in Custom search.

This implementation uses `torch-directml` for compatible DirectX 12 adapters.
An Intel brand name or ThinkPad model alone does not establish compatibility or
speed. The installer performs a real forward/backward test on the selected
adapter. Validate a short run before allocating a long search. See
[IGPU_V61.md](docs/IGPU_V61.md).

## One download policy for every computer

New searches allow missing official pretrained weights to download by default
on CPU, Intel iGPU and NVIDIA GPU profiles. The same checkbox is available in
Custom search. Public model downloads do not upload inspection images, tags or
reports. There is no automatic package installation inside a training job.
Use Setup to install dependencies; keep normal company network and proxy rules.
The DirectML package has its own vendor diagnostic-data notice; the model
download checkbox is not a system-wide telemetry control. See the linked
download and iGPU guides before enabling that optional backend.

Downloads count against the search budget and failed downloads are explicit.
Turn **Allow missing public pretrained weights to download** off to require
already-provisioned local weights. **Check installation** is read-only and may
report missing local weights even when a later search is allowed to download
them. The explicit **Download pretrained weights** action is still available.
See [WEIGHT_DOWNLOADS_V61.md](docs/WEIGHT_DOWNLOADS_V61.md).

## Quality & documentation

1. Open **Quality & documentation**.
2. Select the training experiments whose dataset membership and model history
   you want to document. Load older experiments from **Models & reports** first.
3. Select inspection sessions for the trays to compare. For a session in an
   older output directory, use **Load historical session** with the directory
   containing `review_session.json`, not the original image folder.
4. Enter a report title and any operator notes. Preview the evidence.
5. Export the report. Open the HTML locally or use the browser's print-to-PDF
   function. CSV files provide complete row-level records; JSON retains the
   structured evidence and recorded configuration.

Reports distinguish:

- What each model was trained on: tasks, trays, physical units, labels, split
  roles, dataset fingerprints and recorded preprocessing/training parameters.
- Previously recorded validation, selection and final-test evidence. Creating a
  report does not evaluate or expose an untouched test holdout.
- Model routing for each tray: predicted good, bad, review and unavailable
  decisions. These are not certified statements of physical product quality.
- Measured agreement with original manual tags, separately from post-inspection
  operator corrections. Unlabelled inputs have no measured accuracy.
- False accepts, false rejects, review workload and conditional automatic
  accuracy, with their denominators and coverage shown together.
- Matched-input comparisons between models/sessions and warnings about known
  training/development exposure, missing evidence and unfinished sessions.

Repeated sessions are not pooled into a fictitious total of unique parts.
Different inspection tasks remain separate. Review is an abstention, not a
correct classification. A batch rejection fraction is not a calibrated defect
probability or an independent quality measurement.

The export includes provenance hashes for the artifacts read, detailed image
records and disagreement records. It leaves source images, labels, experiments
and previous reports unchanged. Read [QUALITY_REPORTS_V61.md](docs/QUALITY_REPORTS_V61.md)
for definitions and limitations.

## Installation and migration

Extract into a new folder; retain the previous project and results. Setup can
reuse the corresponding managed Studio 6 CPU/CUDA/DirectML environment; other
projects' environments remain untouched. Copy only the intended paths/settings
into the new `project.yaml`, not older source patches.

Run `Start.cmd` after setup. New projects default to the CPU laptop profile.
For NVIDIA workstations use `Setup.cmd -Device cuda` and a workstation preset.
For Intel laptop graphics use `Setup-DirectML.cmd` and the laptop iGPU preset.
The GUI can be opened without a dataset; training and meaningful reports need
actual recorded data.
