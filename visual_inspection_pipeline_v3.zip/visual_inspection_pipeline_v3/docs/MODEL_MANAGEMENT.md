# Model and Dataset Management

## Version boundary

A run is an immutable experiment identity with a mutable operational state record. It contains the task, resolved configuration, data manifest, model candidates, training history, selected threshold, and evaluations. New data, changed preprocessing, changed labels, or a new decision threshold require a new version.

The active-model registry points to a selected operational version. It is independent of the most recent run. Starting a new experiment does not overwrite the currently active release or its checkpoints.

| Artifact | Role |
| --- | --- |
| `config.json` / `resolved_config.yaml` | Frozen effective experiment settings |
| `manifest.csv` | Frozen dataset rows and split membership |
| `integrity.json` | Frozen configuration and manifest checksums |
| `data_location.json` | Mutable local dataset-root binding for relocation |
| `lineage.json` | Previous-version references and evaluation reuse history |
| `model_state.json` | Operational status and recorded transitions |
| `models/<candidate>/best.pt` | Best checkpoint by the validation criterion |
| `models/<candidate>/last.pt` | Last completed-epoch continuation state |
| `models/<candidate>/completed.json` | Candidate completion and checkpoint identity |
| `selected.json` | Fixed selected members, scores, threshold, and policy |
| `selection_integrity.json` | Selected-system checksum |
| `final_test_summary.json` | Final test evidence for the fixed selected system |

The training manifest includes portable relative paths and content identity. `data_location.json` resolves those records on the current computer. Retain the exact source image/label revision; a manifest cannot reconstruct a deleted image.

The registry stores a relative run pointer in `<output_root>/<task>/current_model.json` and appends activation events to `activation_history.json`. Keep both with the version history when transferring an operational project.

## Resume an interrupted experiment

```bash
python inspection.py resume --run ./results/top/RUN_ID --device cuda
```

`resume` validates the stored configuration, manifest, and current source-image identity, then reuses completed candidates and continues incomplete ones. It does not accept a new profile or training budget. The saved optimizer, scheduler, random-state, and mixed-precision state are used where applicable. Continuation is supported at completed-epoch boundaries; work inside an interrupted epoch may be repeated.

An existing run lock indicates another writer may be active. Inspect the machine and confirm the original process has stopped before using the explicit stale-lock recovery option:

```bash
python inspection.py resume --run ./results/top/RUN_ID --recover-lock
```

Do not run two writers against one experiment directory. Cross-device continuation is permitted as a runtime choice, but exact numerical equality across devices and software environments is not promised.

PatchCore is a bank-building procedure, not epoch-based supervised optimization. Its persisted completed bank can be reused; incomplete bank construction may restart. A revised bank is a new candidate.

## Train with additional data

Update the dataset root in the project configuration to contain all retained old records and newly reviewed records. Preserve the source revision used by previous models.

```bash
python inspection.py update --config project.yaml --from-run ./results/top/PREVIOUS_RUN --profile workstation
```

An update creates a new run, retains prior held-out group assignments, includes fresh training candidates, and can fine-tune the previous supervised members. The previous selected system is copied into the new experiment as a frozen incumbent with its original threshold. PatchCore banks are rebuilt as new candidates rather than silently extended in place.

The update comparison requires compatible task and preprocessing geometry. The automatic image-size setting inherits the previous envelope. If newly added images need another envelope or preprocessing, treat that as a separate experiment and reevaluate the full decision system.

Review `lineage.json` and dataset audit output. Revised labels, changed group identities, missing prior records, or duplicates spanning old held-out data can invalidate an update. Correct the dataset design rather than moving held-out examples into training to satisfy the command.

## Compare fixed versions

```bash
python inspection.py compare --old-run ./results/top/OLD_RUN --new-run ./results/top/NEW_RUN --output ./comparisons/top_old_new
```

The comparison uses common eligible evaluation records and each version's unchanged threshold. It must not compare an old accuracy on one dataset with a new accuracy on another dataset and call the difference a model improvement. Source identity and training-overlap checks protect the comparison against changed or leaked records.

Review old/new metrics, corrected examples, regressions, and disagreements. Source images are copied into the corresponding review folders. A model may improve total error while missing a newly important defect type; inspect defect escapes explicitly.

This paired comparison is development/regression evidence. The independent final test remains separate. Previously examined test data retain their history and must not be described as fresh independent evidence.

Fresh external holdouts can be evaluated with `evaluate --split external --input LABELED_FOLDER --groups-csv GROUP_MAPPING`. The external set must not overlap known images or physical units, and an evaluation ledger records inspected data before scoring. This ledger is inherited across subsequent generations. Reusing an external set, including after a partial failed evaluation or in a child run, is rejected as fresh qualification evidence. Previously inspected external images and physical units also cannot be introduced into a child run's development data.

## Qualify, activate, and roll back

```bash
python inspection.py evaluate --run ./results/top/RUN_ID --split final-test
python inspection.py activate --config project.yaml --run ./results/top/RUN_ID
python inspection.py status --config project.yaml
```

By default, activation requires a complete model comparison, a non-pilot run, empirical target compliance, and the configured statistical evidence. A small test can produce zero observed defect escapes while remaining insufficient for a strict upper confidence bound. Changing evidence requirements is a project-policy revision, not evidence that the model improved.

Rollback reactivates a retained prior eligible run:

```bash
python inspection.py activate --config project.yaml --run ./results/top/PREVIOUS_QUALIFIED_RUN
```

Retain every released run, its intact selected member files, qualification record, and deployment package. If the active pointer references a source run, moving or deleting that run breaks configuration-driven inference; activate the restored location after relocation.

## Training continuation package

Create a training package when moving an experiment to another computer:

```bash
python inspection.py package --run ./results/top/RUN_ID --kind training --output ./packages/top_training
```

The training package retains the recorded experiment and checkpoint artifacts, embeds required local pretrained weight files when `pretrained` is enabled, and includes predecessor experiment states needed to continue an update lineage. These dependencies have their own recorded relative locations and checksums. Source dataset bytes are not embedded; retain and move the corresponding dataset separately. The source application and a compatible training environment must also be available on the destination.

Restore to a fresh location and explicitly bind the data root:

```bash
python inspection.py restore --package ./packages/top_training --data-root D:/inspection/data/top --output D:/inspection/restored/top_run
```

The restored manifest must match the destination dataset content. The main dataset must also contain the retained predecessor images and consistent labels. The restore operation rebinds the main and embedded predecessor snapshots to matching image identities; it does not change labels, split membership, original configuration, or the selected decision threshold. Relative member and dependency paths allow checkpoints and local weights to move with the run.

After restore:

```bash
python inspection.py resume --run D:/inspection/restored/top_run --device cpu
```

A completed selected run can instead be evaluated, packaged, or used for prediction. Continuing a training experiment on CPU may be much slower than on the workstation. Copying `.venv` is not a substitute for installing the correct destination environment.

## Trusted artifact handling

PyTorch checkpoints contain serialized training state. Only restore artifacts produced by an authorized trusted workflow. Checksums detect accidental changes relative to recorded hashes; they do not establish the authenticity of an untrusted package whose manifest has also been replaced.

The application does not make source-run directories read-only at the operating-system level. Maintain normal project access controls and backups. Do not edit checkpoint files, policy JSON, or frozen manifest rows to modify a released model.
