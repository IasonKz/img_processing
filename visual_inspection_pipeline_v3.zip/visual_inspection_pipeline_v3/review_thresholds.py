"""Review the selected checkpoint using archived scores; no training or test tuning.

Reads threshold.npy to fit a decision and selection.npy to evaluate that fixed
decision. Writes a new sibling result folder; the original run stays immutable.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import html
from pathlib import Path
import sys
import uuid

import numpy as np

from nilt.common import read_json, write_json, write_csv, sha_file, safe_relative
from nilt.policy import (POLICY_VERSION, check_scores, metrics, threshold_curve,
                         tune_threshold_details, empirical_pass)
from nilt.reporting import export_predictions
from nilt.workflow import open_run, load_selected, verify_sources


def overlap(a, b):
    a, b = Path(a).resolve(), Path(b).resolve()
    return a.is_relative_to(b) or b.is_relative_to(a)


def table(records, columns):
    result = '<table><tr>' + ''.join('<th>' + html.escape(c) + '</th>' for c in columns) + '</tr>'
    for record in records:
        result += '<tr>'
        for column in columns:
            value = record.get(column)
            if isinstance(value, float):
                value = f'{value:.6g}'
            result += '<td>' + html.escape(str(value) if value is not None else 'undefined') + '</td>'
        result += '</tr>'
    return result + '</table>'


def review(run, output_root='threshold_review', copy_images=False):
    run = Path(run).resolve()
    if (run / 'operation.lock').exists():
        raise ValueError('Run is busy; wait until training/evaluation finishes.')
    cfg, manifest = open_run(run)
    selected = load_selected(run)
    manifest_hash = sha_file(run / 'manifest.csv')
    if selected.get('manifest_sha256', manifest_hash) != manifest_hash:
        raise ValueError('Selected model does not match the dataset manifest.')
    folder = safe_relative(run, 'scores/' + selected['name'])
    provenance = read_json(folder / 'provenance.json') if (folder / 'provenance.json').exists() else None
    if provenance and (provenance['manifest_sha256'] != manifest_hash or provenance['candidate'] != selected['name']):
        raise ValueError('Archived scores belong to a different manifest or candidate.')
    rows, scores, hashes = {}, {}, {}
    for split in ('threshold', 'selection'):
        rows[split] = [r for r in manifest if r['split'] == split]
        path = folder / (split + '.npy')
        hashes[path.name] = sha_file(path)
        if provenance and hashes[path.name] != provenance['files'][path.name]:
            raise ValueError('Archived score hash mismatch: ' + path.name)
        labels, scores[split] = check_scores([r['label'] for r in rows[split]], np.load(path, allow_pickle=False))
        if set(labels) != {0, 1}:
            raise ValueError(split + ' split requires good and bad images.')
    details = tune_threshold_details([r['label'] for r in rows['threshold']], scores['threshold'], cfg['policy'])
    confidence = cfg['policy'].get('confidence', .95)
    comparisons = []
    for split in ('threshold', 'selection'):
        for version, threshold in (('original', selected['threshold']), ('revised', details['threshold'])):
            met = metrics([r['label'] for r in rows[split]], scores[split], threshold,
                          [r['group'] for r in rows[split]], confidence)
            # Legacy caches have no hashes. Check against the saved original
            # metrics where available, without pretending this proves byte integrity.
            recorded = selected.get(split + '_metrics', {})
            if version == 'original':
                for field in ('bad_detected_TP', 'bad_passed_as_good_FN', 'good_rejected_as_bad_FP',
                              'good_accepted_TN', 'pr_auc_bad', 'roc_auc_bad'):
                    if recorded.get(field) is not None and not np.isclose(met[field], recorded[field], rtol=1e-9, atol=1e-12):
                        raise ValueError('Cached scores do not reproduce original ' + split + ' ' + field)
            comparisons.append({'split': split, 'decision': version, 'threshold': float(threshold),
                                'targets_met_on_this_split': empirical_pass(met, cfg['policy']), **met})
    revised_selection = next(r for r in comparisons if r['split'] == 'selection' and r['decision'] == 'revised')
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ') + '_' + uuid.uuid4().hex[:8]
    out = Path(output_root).resolve() / stamp
    if any(overlap(out, p) for p in (run, cfg['data_root'])):
        raise ValueError('Output must be outside the training run and image dataset.')
    if copy_images:
        verify_sources(rows['selection'])
    out.mkdir(parents=True, exist_ok=False)
    write_json(out / 'review_summary.json', {'status': 'incomplete'})
    curve = threshold_curve([r['label'] for r in rows['threshold']], scores['threshold'])
    write_csv(out / 'calibration_curve.csv', [{k: float(v[i]) for k, v in curve.items()} for i in range(len(curve['threshold']))])
    write_csv(out / 'comparison.csv', comparisons)
    write_json(out / 'metrics.json', comparisons)
    quantiles = []
    for split in ('threshold', 'selection'):
        labels = np.array([r['label'] for r in rows[split]])
        for label, name in ((0, 'bad'), (1, 'good')):
            numbers = np.quantile(scores[split][labels == label], [0, .1, .5, .9, 1])
            quantiles.append({'split': split, 'class': name, 'n': int((labels == label).sum()),
                              **{k: float(v) for k, v in zip(('min', 'p10', 'median', 'p90', 'max'), numbers)}})
    write_csv(out / 'score_distribution.csv', quantiles)
    export_predictions(rows['selection'], scores['selection'], details['threshold'], out / 'revised_predictions',
                       copy_images=copy_images, confidence=confidence, score_type=selected.get('score_type', 'bad_probability_uncalibrated'),
                       model_version=run.name + '/' + selected['name'])
    # Override the generic export text: the original run's qualification does
    # not apply to this revised decision.
    rule_path = out / 'revised_predictions' / 'decision_rule.json'
    rule = read_json(rule_path)
    rule['interpretation'] = 'Development-only retuned decision. Original qualification does not carry over.'
    write_json(rule_path, rule)
    decision = {'format': 'threshold_addon_decision_v1', 'rule': 'bad_if_score_greater_equal_threshold',
                'run': str(run), 'selected_sha256': sha_file(run / 'selected.json'), 'threshold': details['threshold'],
                'original_threshold': float(selected['threshold']), 'candidate': selected['name'],
                'policy_version': POLICY_VERSION, 'decision_status': 'RETUNED_NOT_INDEPENDENTLY_VALIDATED'}
    write_json(out / 'decision.json', decision)
    warnings = []
    training_context = {'pretrained': cfg.get('pretrained', True), 'image_size': cfg.get('image_size'),
                        'resize': cfg.get('resize'), 'training_settings': cfg.get('training', {}),
                        'members': []}
    for member in selected.get('members', []):
        checkpoint = safe_relative(run, member['checkpoint'])
        info = {'checkpoint': member['checkpoint']}
        for name in ('progress.json', 'imbalance.json', 'completed.json'):
            path = checkpoint.parent / name
            if path.is_file():
                info[name] = read_json(path)
        training_context['members'].append(info)
    if not cfg.get('pretrained', True):
        warnings.append('This run used pretrained=false. It did not start from local ImageNet weights.')
    if not details['targets_feasible']:
        warnings.append('No threshold satisfies BOTH requested limits on calibration data. This is a balanced-accuracy development fallback.')
    if not details['better_than_constant_on_calibration']:
        warnings.append('No threshold beats a constant classifier in calibration balanced accuracy. Investigate labels, scores, images and learning; do not interpret the fallback as a useful model.')
    if revised_selection['balanced_accuracy'] <= .5 + 1e-12:
        warnings.append('Revised decision does not beat a constant classifier in selection balanced accuracy.')
    if revised_selection['roc_auc_bad'] <= .5:
        warnings.append('Selection ROC-AUC is at or below 0.5. Check label conventions and model learning; do not automatically invert labels.')
    if revised_selection['accuracy'] <= revised_selection['majority_baseline_accuracy']:
        warnings.append('Revised accuracy is no higher than the majority-class baseline. That baseline may accept every defective image; inspect BOTH class error rates.')
    if not provenance:
        warnings.append('Legacy cache: no original score-file checksums exist. Available recorded metrics were checked, and current file hashes are recorded in this review.')
    summary = {'status': 'completed', 'policy_version': POLICY_VERSION, 'run': str(run), 'candidate': selected['name'],
               'selected_sha256': decision['selected_sha256'], 'manifest_sha256': manifest_hash, 'score_hashes': hashes,
               'threshold_decision': details, 'original_threshold': float(selected['threshold']),
               'revised_selection_metrics': revised_selection,
               'targets_met_on_calibration_and_selection': bool(details['targets_feasible'] and revised_selection['targets_met_on_this_split']),
               'qualification': 'NOT_INDEPENDENTLY_VALIDATED', 'warnings': warnings,
               'training_context': training_context,
               'note': 'Threshold fitted using threshold split ONLY; selection metrics are diagnostic. Final test was not evaluated. Old run and weights were not modified.'}
    columns = ['split', 'decision', 'threshold', 'bad_detected_TP', 'bad_passed_as_good_FN', 'good_rejected_as_bad_FP',
               'good_accepted_TN', 'bad_escape_rate', 'good_reject_rate', 'accuracy', 'balanced_accuracy', 'targets_met_on_this_split']
    page = '<!doctype html><html lang="en"><meta charset="utf-8"><title>Threshold review</title><style>body{font:15px system-ui;margin:30px;color:#172d3b}table{border-collapse:collapse;margin:20px 0}th,td{border:1px solid #cad4dc;padding:9px;text-align:left}th{background:#edf3f6}li{margin:10px 0}</style>'
    page += '<h1>Threshold review: same checkpoint, revised decision</h1><p>Bad is the positive event. Rates use 0–1 units. A lower threshold rejects more images.</p>'
    page += '<p>Threshold fitted on calibration data only. No training or final-test evaluation. These are development results, not production qualification.</p>'
    page += '<ul>' + ''.join('<li>' + html.escape(w) + '</li>' for w in warnings) + '</ul>'
    page += table(comparisons, columns)
    page += '<h2>Selection baselines</h2><p>Always-good and always-bad have balanced accuracy 0.5. AP baseline equals bad prevalence. AP/ROC-AUC do not change when the threshold changes.</p>'
    page += table([revised_selection], ['always_good_accuracy', 'always_bad_accuracy', 'majority_baseline_accuracy', 'constant_score_pr_auc_baseline', 'pr_auc_bad', 'roc_auc_bad'])
    page += '<h2>Score distributions</h2>' + table(quantiles, ['split', 'class', 'n', 'min', 'p10', 'median', 'p90', 'max'])
    (out / 'comparison.html').write_text(page + '</html>', encoding='utf-8')
    write_json(out / 'review_summary.json', summary)
    print('Review: ' + str(out / 'comparison.html'), flush=True)
    print(f"Threshold: {selected['threshold']:.8g} -> {details['threshold']:.8g}; mode: {details['mode']}", flush=True)
    print(f"Selection: bad escape={revised_selection['bad_escape_rate']:.2%}, good reject={revised_selection['good_reject_rate']:.2%}, balanced accuracy={revised_selection['balanced_accuracy']:.2%}", flush=True)
    print('Decision for threshold_addon.py --decision: ' + str(out / 'decision.json'), flush=True)
    return out


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', required=True)
    parser.add_argument('--output-root', default='threshold_review')
    parser.add_argument('--copy-images', action='store_true', help='Copy unchanged selection images into new predicted folders; requires original data.')
    args = parser.parse_args(argv)
    try:
        review(args.run, args.output_root, args.copy_images)
    except Exception as exc:
        print(f'ERROR: {type(exc).__name__}: {exc}', file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
