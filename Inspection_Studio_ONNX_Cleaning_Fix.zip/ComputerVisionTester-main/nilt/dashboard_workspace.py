"""Explicit dataset edits, native selection and termination of owned workers."""
from collections import Counter
from io import BytesIO
from pathlib import Path
import json
import subprocess
import sys
from urllib.parse import urlencode

from .common import sha_file, read_json
from .dataset_tools import dataset_items, checked_image, move_image, undo_move, TRAY_ROLES, DATA_LABELS


class WorkspaceDashboardMixin:
    def viewer_image(self, data, info=False):
        from urllib.parse import urlsplit, unquote
        from .dashboard import _safe_path
        from .common import EXTENSIONS
        from .image_io import load_rgb, display_image, display_statistics, window_display
        source = urlsplit(str(data.get("source", "")))
        if source.scheme or source.netloc:
            raise ValueError("Choose a registered local image.")
        parts = unquote(source.path).lstrip("/").split("/", 2)
        if len(parts) != 3 or parts[0] not in ("images", "results"):
            raise ValueError("Choose a registered dataset or result image.")
        roots = self.data_roots if parts[0] == "images" else self.output_roots
        index = int(parts[1])
        if not 0 <= index < len(roots):
            raise ValueError("Unknown image root.")
        path = _safe_path(roots[index], parts[2])
        if not path.is_file() or path.suffix.lower() not in EXTENSIONS or path.stat().st_size > 64 * 1024 * 1024:
            raise ValueError("Image is unavailable or too large for the viewer.")
        image = load_rgb(path)
        if info:
            return display_statistics(image)
        preview = window_display(image, data.get("black", "min"), data.get("white", "max")) if data.get("window") == "1" else display_image(image)
        buffer = BytesIO()
        preview.save(buffer, format="PNG")
        return buffer.getvalue()

    def cleaning_assessments(self, data):
        root = self._cleaning_root(data)
        reports = []
        for path in sorted((self.config.parent / "cleaning_assessments").glob("*/report.json"), reverse=True):
            if path.is_symlink() or not path.resolve().is_relative_to(self.config.parent.resolve()):
                continue
            report = read_json(path)
            if report.get("root") == str(root) and report.get("task") == data.get("task", "vig") and report.get("roi_scope", "whole_image") == data.get("roi_scope", "whole_image"):
                reports.append({"id": path.parent.name, **report})
        return {"assessments": reports}

    def _cleaning_predictions(self, data):
        identity = data.get("assessment", "")
        if not identity:
            return {}, None
        report = next((r for r in self.cleaning_assessments(data)["assessments"] if r["id"] == identity), None)
        if report is None or report["status"] != "completed":
            raise ValueError("Choose a completed cleaning assessment for this dataset and target.")
        path = self.config.parent / "cleaning_assessments" / identity / "predictions.json"
        if path.is_symlink():
            raise ValueError("Assessment records must stay in their saved folder.")
        stat = path.stat()
        root = self._cleaning_root(data)
        journal = root / ".nilt-cleaning" / "moves.jsonl"
        if journal.is_symlink() or not journal.resolve().is_relative_to(root):
            raise ValueError("Cleaning journal is outside its dataset.")
        signature = (stat.st_mtime_ns, stat.st_size, journal.stat().st_mtime_ns if journal.exists() else 0)
        cache = getattr(self, "_cleaning_prediction_cache", {})
        cached = cache.get((str(root), identity))
        if not cached or cached[0] != signature:
            predictions = {r["relative_path"]: r for r in read_json(path)}
            # Relabels and undo preserve the immutable score by content identity.
            if journal.exists():
                for line in journal.read_text(encoding="utf-8").splitlines():
                    try:
                        move = json.loads(line)
                    except ValueError:
                        continue
                    row = predictions.get(move.get("from"))
                    if row and row.get("file_sha256") == move.get("sha256"):
                        predictions[move["to"]] = {**row, "moved": True}
            cache[(str(root), identity)] = (signature, predictions)
            self._cleaning_prediction_cache = cache
        return cache[(str(root), identity)][1], report

    def _cleaning_prediction(self, root, item, predictions, *, digest=None):
        row = predictions.get(item["relative_path"])
        if not row:
            return None
        path = checked_image(root, item["relative_path"])
        stat = path.stat()
        # Hash once per file version. Cached scores are never applied to changed bytes.
        cache = getattr(self, "_cleaning_hash_cache", {})
        key = (str(path), stat.st_size, stat.st_mtime_ns)
        digest = digest or cache.get(key) or sha_file(path)
        cache[key] = digest
        self._cleaning_hash_cache = cache
        if digest != row.get("file_sha256"):
            return {"status": "stale", "prediction": None, "error": "Image changed since scoring. Run a new assessment."}
        return row

    def _idle_for_dataset_edit(self):
        if self.roi_busy():
            raise ValueError("Wait for or stop the active ROI operation before changing dataset files.")
        self._refresh_recovered_jobs()
        if any(j.get("status") in ("running", "unverified") for j in self.jobs) or getattr(self, "_v5_operation", None):
            raise ValueError("Stop the active worker before changing dataset files.")
        from .segmentation_bridge import state
        if any(server["job"].get("status") in ("running", "starting", "unverified") for server in state(self).values()):
            raise ValueError("Stop segmentation workers before changing dataset files.")

    def cleaning_open(self, data):
        import hashlib
        value = data.get("path", "")
        if not isinstance(value, str) or not value.strip():
            raise ValueError("Choose a local good/bad dataset folder.")
        root = self._configured_path(value)
        dataset_items(root)
        key = hashlib.sha256(str(root).encode()).hexdigest()[:24]
        if not hasattr(self, "cleaning_roots"):
            self.cleaning_roots = {}
        self.cleaning_roots[key] = root
        if root not in self.data_roots:
            self.data_roots.append(root)
        return self.cleaning_catalog({**data, "dataset": key})

    def _cleaning_root(self, data):
        root = getattr(self, "cleaning_roots", {}).get(data.get("dataset"))
        if root is None:
            raise ValueError("Open this dataset in Data cleaning first.")
        return root

    def cleaning_catalog(self, data):
        from .cleaning_assessment import disagreement
        root = self._cleaning_root(data)
        items = dataset_items(root)
        totals = Counter({label: 0 for label in DATA_LABELS})
        totals.update(item["label"] for item in items)
        trays = Counter(item["tray"] for item in items if item["label"] in ("good", "bad"))
        predictions, assessment = self._cleaning_predictions(data)
        comparison_counts = Counter()
        for item in items:
            item["model"] = self._cleaning_prediction(root, item, predictions)
            item["comparison"] = disagreement(item["label"], item["model"])
            comparison_counts[item["comparison"] or "unscored"] += 1
        comparison = data.get("comparison", "")
        if comparison not in ("", "mismatch", "fn", "fp", "match", "review", "unscored"):
            raise ValueError("Unknown comparison filter.")
        if comparison and assessment is None:
            raise ValueError("Select a saved model assessment before filtering model disagreements.")
        def matches(item):
            if not comparison:
                return True
            if comparison == "mismatch":
                return item["comparison"] in ("fn", "fp", "mismatch")
            if comparison == "review":
                return bool(item["model"] and item["model"].get("prediction") == "review")
            if comparison == "unscored":
                return not item["model"] or item["model"].get("status") != "ok"
            return item["comparison"] == comparison
        filtered = [item for item in items if (not data.get("label") or item["label"] == data["label"])
                    and (not data.get("tray") or item["tray"] == data["tray"])
                    and (not data.get("search") or data["search"].lower() in item["relative_path"].lower())
                    and matches(item)]
        if data.get("priority") == "mismatch":
            filtered.sort(key=lambda r: ({"fn": 0, "fp": 1, "mismatch": 2, "match": 4}.get(r["comparison"], 3), r["relative_path"]))
        page, size = max(1, int(data.get("page", 1))), min(100, max(1, int(data.get("page_size", 40))))
        page = min(page, max(1, (len(filtered) + size - 1) // size))
        for item in filtered[(page - 1) * size:page * size]:
            item["image_url"] = "/api/cleaning/image?" + urlencode({"dataset": data["dataset"], "relative": item["relative_path"]})
        return {"dataset": data["dataset"], "path": str(root), "counts": dict(totals), "trays": dict(trays),
                "assessment": assessment, "comparison_counts": dict(comparison_counts),
                "items": filtered[(page - 1) * size:page * size],
                "pagination": {"page": page, "pages": max(1, (len(filtered) + size - 1) // size), "total": len(filtered)}}

    def cleaning_item(self, data):
        root = self._cleaning_root(data)
        path = checked_image(root, data.get("relative"))
        digest = sha_file(path)
        predictions, _ = self._cleaning_predictions(data)
        item = {"relative_path": path.relative_to(root).as_posix()}
        return {**item, "sha256": digest, "model": self._cleaning_prediction(root, item, predictions, digest=digest)}

    def cleaning_image_info(self, data):
        from .image_io import load_rgb, display_statistics
        return display_statistics(load_rgb(checked_image(self._cleaning_root(data), data.get("relative"))))

    def cleaning_image(self, data):
        from .image_io import load_rgb, display_image, window_display
        path = checked_image(self._cleaning_root(data), data.get("relative"))
        image = load_rgb(path)
        preview = window_display(image, data.get("black", "min"), data.get("white", "max")) if data.get("window") == "1" else display_image(image)
        buffer = BytesIO()
        preview.save(buffer, format="PNG")
        return buffer.getvalue()

    def cleaning_move(self, data):
        with self.lock:
            self._idle_for_dataset_edit()
            root = self._cleaning_root(data)
            record = move_image(root, data.get("relative"), data.get("label"), data.get("expected_sha256"))
            return {"move": record, "catalog": self.cleaning_catalog({**data, "label": data.get("filter_label", "")})}

    def cleaning_undo(self, data):
        with self.lock:
            self._idle_for_dataset_edit()
            record = undo_move(self._cleaning_root(data))
            return {"move": record, "catalog": self.cleaning_catalog(data)}

    def dataset_trays(self, data):
        task = data.get("task", "vig")
        if task not in self.raw.get("tasks", {}):
            raise ValueError("Choose a configured task.")
        root = self._configured_path(data.get("path") or self.raw["tasks"][task].get("dataset_root", ""))
        items = dataset_items(root)
        roles = self.raw["tasks"][task].get("tray_roles", {})
        counts = {}
        for item in items:
            if item["label"] in ("good", "bad"):
                counts.setdefault(item["tray"], Counter())[item["label"]] += 1
        return {"path": str(root), "task": task, "trays": [{"tray": name, "counts": dict(count), "role": roles.get(name, "development")}
                                                          for name, count in sorted(counts.items())]}

    def save_tray_roles(self, data):
        with self.lock:
            self._idle_for_dataset_edit()
            catalog = self.dataset_trays(data)
            roles = data.get("roles")
            if not isinstance(roles, dict) or any(role not in TRAY_ROLES for role in roles.values()):
                raise ValueError("Tray roles must be development, classification or excluded.")
            if set(roles) - {row["tray"] for row in catalog["trays"]}:
                raise ValueError("Tray roles must refer to this dataset's trays.")
            return self.save_config({"task": catalog["task"], "dataset": catalog["path"]}, tray_roles=roles)

    def pick_path(self, data):
        if data.get("kind", "folder") not in ("folder", "file"):
            raise ValueError("Choose a folder or file dialog.")
        request = {"kind": data.get("kind", "folder"), "title": str(data.get("title", "Choose a local folder"))[:160],
                   "initial": str(data.get("initial", "")), "mustexist": data.get("mustexist", True) is not False}
        try:
            result = subprocess.run([sys.executable, "-m", "nilt.native_picker"], input=json.dumps(request),
                                    text=True, capture_output=True, timeout=300, cwd=str(Path(__file__).parent.parent))
            if result.returncode:
                raise RuntimeError("Native selection needs a desktop display and Python Tk. On Arch install tk; on Windows use the standard Python installer. Manual path entry remains available.")
            return json.loads(result.stdout)
        except subprocess.TimeoutExpired:
            raise ValueError("The folder dialog timed out. Open it again or paste a path.")

    def stop_workers(self, data):
        import psutil
        from .common import write_json
        mode = data.get("mode", "force")
        if mode not in ("force", "soft"):
            raise ValueError("Stop mode must be force or soft.")
        stopped = []
        with self.lock:
            for side in ("top", "bottom"):
                if self.roi_job({"side": side})["job"].get("status") in ("running", "starting", "unverified"):
                    self.roi_stop({"side": side})
                    stopped.append("roi:" + side)
            self._refresh_recovered_jobs()
            from .segmentation_bridge import state
            state(self)
            for job in self.jobs:
                # Worker ownership is checked again immediately before signalling.
                if job.get("status") not in ("running", "unverified"):
                    continue
                if self._process_state(job) != "running":
                    raise ValueError("Worker identity could not be verified; no unrelated process was stopped.")
                if mode == "soft":
                    if job["action"] in ("search", "resume-search") and job.get("run"):
                        write_json(Path(job["run"]) / "control.json", {"action": "cancel", "stop": True})
                    else:
                        (self.logs_root / (job["id"] + ".stop")).touch()
                    job["stop_requested"] = True
                else:
                    process = psutil.Process(job["pid"])
                    if abs(process.create_time() - job["process_created"]) > .01 or process.cmdline() != job["command"]:
                        raise ValueError("Worker identity changed before stopping; no unrelated process was signalled.")
                    processes = process.children(recursive=True) + [process]
                    identities = [(p, p.create_time()) for p in processes]
                    job["force_stopped"] = True
                    for p, created in identities:
                        try:
                            if p.create_time() == created:
                                p.terminate()
                        except psutil.NoSuchProcess:
                            pass
                    _, alive = psutil.wait_procs(processes, timeout=2)
                    for p in alive:
                        try:
                            if any(p.pid == original.pid and p.create_time() == created for original, created in identities):
                                p.kill()
                        except psutil.NoSuchProcess:
                            pass
                    job.update(status="stopped", message="Stopped by operator. Committed files are retained; the active batch may be incomplete.")
                    if job.get("workspace_output"):
                        from .common import read_json
                        output = Path(job["workspace_output"])
                        write_json(output / "status.json", {"status": "stopped", "error": job["message"]})
                        report = output / "report.json"
                        if report.is_file():
                            record = read_json(report)
                            if record.get("status") != "completed":
                                write_json(report, {**record, "status": "stopped", "error": job["message"]})
                self._persist_job(job)
                stopped.append(job["id"])
            for task, server in getattr(self, "segmentation_workspaces", {}).items():
                result = server.jobs.force_stop() if mode == "force" else server.jobs.stop()
                if result.get("status") != "idle":
                    stopped.append(task + ":" + str(result.get("job_id", "segmentation")))
        return {"stopped": stopped, "message": ("Stop requested for owned workers." if stopped else "No active owned worker.")}
