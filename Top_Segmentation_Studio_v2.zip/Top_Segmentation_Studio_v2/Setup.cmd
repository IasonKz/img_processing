@echo off
cd /d "%~dp0"
py -3.12 -m venv .venv
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -m pip install -r requirements-training.txt
if errorlevel 1 goto fail
echo Setup complete. Run Start.cmd.
pause
exit /b 0
:fail
echo Setup failed. Read the error above. Python 3.12 is recommended.
pause
exit /b 1
