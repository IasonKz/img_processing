"""Evaluation, deployment export and dataset export for the integrated studio."""
import csv
import json
import shutil
import time
import zipfile
from pathlib import Path
import numpy as np
from PIL import Image
from .common import CLASSES, atomic_json, read_json, safe_path, sha256, utc_now
from .inference import load_model, prepare_image, restore_probabilities, overlay


def checkpoint_from_trial(cfg, study_name, number):
    from .search import settings
    settings({'study_name':study_name})
    study=Path(cfg['output_dir'])/'studies'/study_name
    data=read_json(study/'summary.json')
    selected=next((t for t in data['trials'] if t['number']==int(number) and t['state']=='COMPLETE'),None)
    if not selected: raise ValueError('Choose a completed trial with a saved best checkpoint.')
    return study, safe_path(study,selected['attributes']['checkpoint'])


def evaluate_trial(cfg, request, job_root):
    from .search import evaluate
    study, checkpoint=checkpoint_from_trial(cfg,request['study_name'],request['trial'])
    role=request.get('split','validation')
    if role not in ('validation','test'):raise ValueError('Choose validation or test.')
    if role=='test':
        selected=study/'test_selection.json'
        if selected.exists() and read_json(selected)['trial']!=int(request['trial']):
            raise ValueError('The held-out test is locked to the previously selected trial. Compare models on validation.')
    split=read_json(study/'split.json'); records=read_json(study/'records.json')
    rows=[r for r in records if r['id'] in split[role+'_ids']]
    if not rows:raise ValueError('This study has no images in that split.')
    if role=='test': atomic_json(study/'test_selection.json',dict(trial=int(request['trial']),at=utc_now()))
    for row in rows:
        for field in ('image','mask'):
            if sha256(safe_path(study/'dataset',row[field]))!=row[field+'_sha256']: raise ValueError('Dataset checksum mismatch.')
    model,state,device=load_model(checkpoint,request.get('device','auto'))
    output=study/'evaluations'/f"{int(request['trial']):05d}_{role}"
    def check():
        if (Path(job_root)/'stop').exists():raise InterruptedError('Evaluation stopped.')
    metrics=evaluate(model,rows,study/'dataset',state['image_size'],device,output=output,check=check)
    return dict(status='completed',metrics=metrics,output_dir=str(output),split=role)


def predict_folder(cfg, request, job_root):
    import torch
    from .common import read_rgb, EXTENSIONS
    study,checkpoint=checkpoint_from_trial(cfg,request['study_name'],request['trial'])
    root=Path(request['input_dir']).expanduser().resolve()
    if not root.is_dir():raise ValueError('Prediction input must be an existing top image folder.')
    output=Path(cfg['output_dir'])/'predictions'/Path(job_root).name
    if output.is_relative_to(root) or root.is_relative_to(output): raise ValueError('Prediction input and output must be separate.')
    model,state,device=load_model(checkpoint,request.get('device','auto'))
    files=sorted(p for p in root.rglob('*') if p.suffix.lower() in EXTENSIONS and p.is_file())
    if not files:raise ValueError('No supported images found.')
    output.mkdir(parents=True,exist_ok=False)
    rows=[]; failures=[]; began=time.monotonic()
    with torch.inference_mode():
        for i,path in enumerate(files):
            if (Path(job_root)/'stop').exists():break
            try:
                image=read_rgb(path,cfg['max_image_pixels']); x,g=prepare_image(image,state['image_size'])
                prob=model(torch.from_numpy(x)[None].to(device)).softmax(1)[0].cpu().numpy()
                mask=restore_probabilities(prob,g)
                relative=path.relative_to(root)
                mask_file=Path('masks')/relative.parent/(relative.name+'.png')
                overlay_file=Path('overlays')/relative.parent/(relative.name+'.png')
                for dest,im in [(mask_file,Image.fromarray(mask)),(overlay_file,overlay(image,mask))]:
                    (output/dest).parent.mkdir(parents=True,exist_ok=True); im.save(output/dest)
                rows.append(dict(image=relative.as_posix(),inner_pixels=int((mask==1).sum()),outer_pixels=int((mask==2).sum()),mask=mask_file.as_posix(),overlay=overlay_file.as_posix()))
            except (OSError,ValueError) as exc: failures.append({'image':str(path),'error':str(exc)})
            atomic_json(Path(job_root)/'status.json',dict(status='running',processed=i+1,total=len(files),output_dir=str(output)))
    with (output/'predictions.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=['image','inner_pixels','outer_pixels','mask','overlay']);writer.writeheader();writer.writerows(rows)
    result=dict(status='stopped' if (Path(job_root)/'stop').exists() else 'completed',images=rows,failures=failures,
                output_dir=str(output),seconds=time.monotonic()-began,checkpoint_sha256=sha256(checkpoint),classes=CLASSES)
    atomic_json(output/'summary.json',result)
    if not rows and not (Path(job_root)/'stop').exists():raise ValueError('No images could be processed. See prediction summary.')
    return result


def export_model(cfg, request, job_root):
    import torch
    study,checkpoint=checkpoint_from_trial(cfg,request['study_name'],request['trial'])
    fmt=request.get('format','package')
    if fmt not in ('package','onnx'):raise ValueError('Choose package or onnx.')
    output=Path(cfg['output_dir'])/'packages'/Path(job_root).name; output.mkdir(parents=True)
    model,state,_=load_model(checkpoint,'cpu'); size=state['image_size']
    metadata={k:v for k,v in state.items() if k!='model_state_dict'}
    metadata.update(input='float32 NCHW RGB / 255, aspect-preserving fit and black pad',output='3 logits planes; unpad and resize probabilities before argmax',checkpoint_sha256=sha256(checkpoint))
    atomic_json(output/'metadata.json',metadata)
    if fmt=='onnx':
        import onnxruntime as ort
        import onnx
        path=output/'model.onnx'; x=torch.rand(1,3,size,size)
        torch.onnx.export(model,x,path,input_names=['image'],output_names=['logits'],opset_version=17,dynamo=False)
        onnx.checker.check_model(str(path))
        session=ort.InferenceSession(str(path),providers=['CPUExecutionProvider'])
        with torch.inference_mode(): reference=model(x).numpy()
        actual=session.run(None,{'image':x.numpy()})[0]
        if not np.allclose(reference,actual,rtol=1e-3,atol=1e-4):raise ValueError('ONNX verification failed; this export is not approved.')
        atomic_json(output/'verification.json',{'max_absolute_error':float(abs(reference-actual).max()),'fixed_input_shape':[1,3,size,size]})
    else:
        shutil.copy2(checkpoint,output/'model.pt')
        source=Path(__file__).parent
        shutil.copytree(source,output/'topseg',ignore=shutil.ignore_patterns('__pycache__','web'))
        (output/'predict.py').write_text('from topseg.inference import predict\nimport argparse\np=argparse.ArgumentParser()\np.add_argument("--input",required=True)\np.add_argument("--output",required=True)\np.add_argument("--device",default="cpu")\na=p.parse_args()\nfrom pathlib import Path\nprint(predict(Path(__file__).with_name("model.pt"),a.input,a.output,a.device))\n',encoding='utf-8')
        (output/'requirements.txt').write_text('torch>=2.5,<3\nsegmentation-models-pytorch==0.5.0\nnumpy>=1.26,<3\nPillow>=10.4,<13\nscipy>=1.11,<2\nPyYAML>=6,<7\n',encoding='utf-8')
    (output/'README.txt').write_text('TOP SEGMENTATION MODEL\nClasses: 0 background, 1 inner defect, 2 outer defect.\nSource images are unchanged. Predictions are not automatic part acceptance decisions.\nPT package: install requirements, then python predict.py --input TOP_FOLDER --output NEW_OUTPUT_FOLDER\nONNX: fixed input shape; see metadata.json. Model normalization is embedded in the graph.\n',encoding='utf-8')
    archive=output.with_suffix('.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for p in output.rglob('*'):
            if p.is_file(): z.write(p,p.relative_to(output))
    return {'status':'completed','file':str(archive),'output_dir':str(output)}


def export_dataset(cfg, request, job_root):
    from .project import Project
    output=Path(cfg['output_dir'])/'datasets'/Path(job_root).name
    Project(cfg).snapshot(output)
    # Exact semantic masks are architecture-independent. COCO RLE preserves holes.
    data=read_json(output/'dataset.json'); coco={'images':[],'annotations':[],'categories':[{'id':1,'name':'inner defect'},{'id':2,'name':'outer defect'}]}
    from scipy import ndimage
    for index,row in enumerate(data['records'],1):
        coco['images'].append({'id':index,'file_name':row['image'],'width':row['width'],'height':row['height']})
        mask=np.array(Image.open(output/row['mask']))
        for cls in (1,2):
            labels,count=ndimage.label(mask==cls)
            for n in range(1,count+1):
                component=labels==n; yy,xx=np.where(component); flat=component.flatten(order='F')
                changes=np.flatnonzero(flat[1:]!=flat[:-1])+1; cuts=np.r_[0,changes,len(flat)]; counts=np.diff(cuts).tolist()
                if flat[0]:counts.insert(0,0)
                coco['annotations'].append({'id':len(coco['annotations'])+1,'image_id':index,'category_id':cls,'segmentation':{'size':[row['height'],row['width']],'counts':counts},'area':int(component.sum()),'bbox':[int(xx.min()),int(yy.min()),int(xx.max()-xx.min()+1),int(yy.max()-yy.min()+1)],'iscrowd':0})
    atomic_json(output/'coco_components.json',coco)
    (output/'README.txt').write_text('Canonical semantic masks: 0 background, 1 inner defect, 2 outer defect, native image size.\nCOCO instances are connected components derived from semantic masks, not separately reviewed object identities. RLE preserves holes.\n',encoding='utf-8')
    archive=output.with_suffix('.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for p in output.rglob('*'):
            if p.is_file(): z.write(p,p.relative_to(output))
    return {'status':'completed','file':str(archive),'images':len(data['records'])}
