"""Real SwinV2 safetensors compatibility and strict parameter validation."""
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import timm
import torch
from safetensors.torch import save_file

from cvtester.catalog import select_model
from cvtester.checkpoints import load_safetensors_checkpoint
from cvtester.runner import load_model
from nilt.backbones import make_backbone


class SwinV2CheckpointTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.previous_threads = torch.get_num_threads()
        torch.set_num_threads(1)
        cls.temp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.temp.name)
        cls.spec = select_model('swinv2-tiny')
        cls.reference = timm.create_model(cls.spec.checkpoint, pretrained=False)
        cls.state = dict(cls.reference.state_dict())
        for name, buffer in cls.reference.named_buffers():
            if any(key in name for key in ('attn_mask', 'relative_position_index', 'relative_coords_table')):
                cls.state[name] = buffer
        assert any(name.endswith('attn_mask') for name in cls.state)
        cls.weights = cls.root/'model.safetensors'
        save_file(cls.state, cls.weights)
        (cls.root/'config.json').write_text(json.dumps({
            'architecture': cls.spec.checkpoint.split('.')[0], 'num_classes': 1000,
            'pretrained_cfg': cls.reference.pretrained_cfg}), encoding='utf-8')

    @classmethod
    def tearDownClass(cls):
        del cls.reference, cls.state
        cls.temp.cleanup()
        torch.set_num_threads(cls.previous_threads)

    def test_original_direct_load_reproduces_unexpected_attention_buffers(self):
        with self.assertRaisesRegex(RuntimeError, 'Unexpected key.*attn_mask'):
            self.reference.load_state_dict(self.state, strict=True)

    def test_studio_loader_restores_backbone_and_trains_binary_head(self):
        with patch('nilt.engine.weight_path', return_value=self.weights):
            model, head = make_backbone('swinv2-tiny', {'model_usage': 'commercial'}, pretrained=True)
        self.assertTrue(torch.equal(model.patch_embed.proj.weight, self.reference.patch_embed.proj.weight))
        self.assertEqual(head.out_features, 2)
        for parameter in model.parameters():
            parameter.requires_grad_(False)
        for parameter in head.parameters():
            parameter.requires_grad_(True)
        optimizer = torch.optim.AdamW(head.parameters(), lr=1e-4)
        before = head.weight.detach().clone()
        logits = model(torch.randn(2, 3, 64, 64))
        loss = torch.nn.functional.cross_entropy(logits, torch.tensor([0, 1]))
        self.assertTrue(torch.isfinite(loss))
        loss.backward()
        optimizer.step()
        self.assertFalse(torch.equal(before, head.weight))

    def test_standalone_loader_uses_same_compatibility_with_pinned_safe_weights(self):
        revision = 'a'*40
        info = SimpleNamespace(card_data={'license': self.spec.license}, sha=revision,
            siblings=[SimpleNamespace(rfilename=name) for name in ('config.json', 'model.safetensors')])
        def download(repo, filename, revision):
            return str(self.root/filename)
        with patch('huggingface_hub.HfApi.model_info', return_value=info), \
             patch('huggingface_hub.hf_hub_download', side_effect=download) as fetch:
            model, _, metadata = load_model('swinv2-tiny', 'commercial', 'cpu')
        self.assertEqual(metadata['revision'], revision)
        self.assertTrue(all(call.kwargs['revision'] == revision for call in fetch.call_args_list))
        with torch.inference_mode():
            output = model(torch.randn(1, 3, 256, 256))
        self.assertEqual(tuple(output.shape), (1, 1000))
        self.assertTrue(torch.isfinite(output).all())

    def test_real_parameter_errors_still_fail_strict_loading(self):
        key = 'patch_embed.proj.weight'
        for defect in ('missing', 'unexpected', 'shape'):
            with self.subTest(defect=defect):
                state = dict(self.state)
                if defect == 'missing':
                    del state[key]
                elif defect == 'unexpected':
                    state['invalid_parameter'] = torch.ones(1)
                else:
                    state[key] = state[key][:1].contiguous()
                path = self.root/'invalid.safetensors'
                save_file(state, path)
                with self.assertRaises(RuntimeError):
                    load_safetensors_checkpoint(self.reference, path, self.spec)


if __name__ == '__main__':
    unittest.main()
