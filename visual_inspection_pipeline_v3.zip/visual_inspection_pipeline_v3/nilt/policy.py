"""bad is the event of interest, despite its stored class index being zero."""
from __future__ import annotations

import numpy as np
from scipy.stats import beta
from sklearn.metrics import average_precision_score, roc_auc_score

POLICY_VERSION = "2.1.0-balanced-fallback"


def escape_upper_bound(missed, total, confidence=.95):
    """One-sided Clopper-Pearson bound for a FIXED rule and independent units."""
    if total == 0:
        return None
    if missed == total:
        return 1.0
    return float(beta.ppf(confidence, missed + 1, total - missed))


def check_scores(labels, scores):
    labels, scores = np.asarray(labels), np.asarray(scores, dtype=float)
    if labels.ndim != 1 or scores.ndim != 1:
        raise ValueError("Labels and scores must be one-dimensional.")
    if len(labels) != len(scores) or not len(labels):
        raise ValueError("Empty or mismatched labels/scores.")
    if not np.isin(labels, [0, 1]).all() or not np.isfinite(scores).all():
        raise ValueError("Invalid labels or nonfinite scores.")
    return labels.astype(int), scores


def metrics(labels, scores, threshold, groups=None, confidence=.95):
    labels, scores = check_scores(labels, scores)
    if not np.isscalar(threshold) or not np.isfinite(threshold):
        raise ValueError("Threshold must be a finite scalar.")
    bad = labels == 0
    rejected = scores >= threshold
    tp = int(np.sum(bad & rejected))
    fn = int(np.sum(bad & ~rejected))
    fp = int(np.sum(~bad & rejected))
    tn = int(np.sum(~bad & ~rejected))
    nb, ng = tp + fn, tn + fp
    groups = list(range(len(labels))) if groups is None else list(groups)
    if len(groups) != len(labels) or any(g is None or str(g) == "" for g in groups):
        raise ValueError("Groups must contain one nonempty identifier per image.")
    bad_groups = {}
    for is_bad, is_rejected, group in zip(bad, rejected, groups):
        if is_bad:
            # Conservative unit rule: any bad image of this unit accepted = missed unit.
            bad_groups[group] = bad_groups.get(group, False) or not bool(is_rejected)
    n_units = len(bad_groups)
    missed_units = sum(bad_groups.values())
    return {
        "n_images": len(labels), "n_bad": nb, "n_good": ng,
        "bad_detected_TP": tp, "bad_passed_as_good_FN": fn,
        "good_rejected_as_bad_FP": fp, "good_accepted_TN": tn,
        "bad_escape_rate": fn / nb if nb else None,
        "bad_recall": tp / nb if nb else None,
        "good_reject_rate": fp / ng if ng else None,
        "good_accept_rate": tn / ng if ng else None,
        "accepted_contamination": fn / (fn + tn) if fn + tn else None,
        "bad_precision": tp / (tp + fp) if tp + fp else None,
        "accuracy": (tp + tn) / len(labels),
        "balanced_accuracy": (tp / nb + tn / ng) / 2 if nb and ng else None,
        "predicted_bad_rate": (tp + fp) / len(labels),
        "all_one_class": tp + fp in (0, len(labels)),
        "always_good_accuracy": ng / len(labels),
        "always_bad_accuracy": nb / len(labels),
        "majority_baseline_accuracy": max(nb, ng) / len(labels),
        "constant_score_pr_auc_baseline": nb / len(labels),
        "pr_auc_bad": float(average_precision_score(bad, scores)) if nb and ng else None,
        "roc_auc_bad": float(roc_auc_score(bad, scores)) if nb and ng else None,
        "n_bad_units": n_units, "n_escaped_bad_units": missed_units,
        "bad_unit_escape_upper": escape_upper_bound(missed_units, n_units, confidence),
        "confidence": confidence,
    }


def threshold_curve(labels, scores):
    """All attainable decisions, including all-reject and all-accept endpoints.

    Equal scores are never split; scores may be unbounded anomaly distances.
    """
    labels, scores = check_scores(labels, scores)
    nb, ng = int(np.sum(labels == 0)), int(np.sum(labels == 1))
    if not nb or not ng:
        raise ValueError("Threshold tuning requires both good and bad.")
    values, inv = np.unique(scores, return_inverse=True)
    bad_at = np.bincount(inv, weights=(labels == 0).astype(int))
    good_at = np.bincount(inv, weights=(labels == 1).astype(int))
    fn = np.r_[0, np.cumsum(bad_at)[:-1]]
    fp = ng - np.r_[0, np.cumsum(good_at)[:-1]]
    with np.errstate(over="ignore"):
        upper = np.nextafter(values[-1], np.inf)
    if np.isfinite(upper):
        values = np.r_[values, upper]
        fn, fp = np.r_[fn, nb], np.r_[fp, 0]
    return {"threshold": values, "bad_escape_rate": fn / nb, "good_reject_rate": fp / ng,
            "balanced_accuracy": 1 - (fn / nb + fp / ng) / 2,
            "predicted_bad_rate": (nb - fn + fp) / (nb + ng)}


def _policy_limits(policy):
    result = []
    for name, default in (("max_bad_escape_rate", None), ("max_good_reject_rate", 1.0)):
        value = policy.get(name, default)
        if isinstance(value, (bool, str)) or value is None or not np.isscalar(value) or not np.isfinite(value) or not 0 <= value <= 1:
            raise ValueError(f"{name} must be a finite number between zero and one.")
        result.append(float(value))
    return result


def tune_threshold_details(labels, scores, policy):
    """Fit only on calibration data. A fallback is diagnostic, never a pass.

    Feasible: minimize good rejection subject to BOTH limits, preserving the
    existing preference for the largest admissible threshold. Infeasible:
    maximize balanced accuracy = 1 - (bad escape + good rejection)/2. This
    gives each class equal weight, rather than dividing losses by a near-zero
    safety target. Ties minimize the worse error, then bad escapes.
    """
    bad_limit, good_limit = _policy_limits(policy)
    curve = threshold_curve(labels, scores)
    bad_rate, good_rate = curve["bad_escape_rate"], curve["good_reject_rate"]
    values = curve["threshold"]
    valid = np.flatnonzero((bad_rate <= bad_limit + 1e-12) & (good_rate <= good_limit + 1e-12))
    if len(valid):
        index = int(valid[-1])
        mode = "both_targets_feasible"
    else:
        best = np.max(curve["balanced_accuracy"])
        tied = np.flatnonzero(np.abs(curve["balanced_accuracy"] - best) <= 1e-12)
        order = np.lexsort((good_rate[tied], bad_rate[tied], np.maximum(bad_rate[tied], good_rate[tied])))
        index = int(tied[order[0]])
        mode = "infeasible_balanced_accuracy_fallback"
    threshold = float(values[index])
    if policy.get("threshold_margin", False):
        if index:
            midpoint = float(values[index - 1] / 2 + values[index] / 2)
            # Adjacent float64 scores may not have a representable midpoint.
            if values[index - 1] < midpoint <= threshold:
                threshold = midpoint
        else:
            with np.errstate(over="ignore"):
                lower = float(np.nextafter(values[0], -np.inf))
            if np.isfinite(lower):
                threshold = lower
    best_ba = float(np.max(curve["balanced_accuracy"]))
    return {"threshold": threshold, "policy_version": POLICY_VERSION, "mode": mode,
            "targets_feasible": bool(len(valid)), "n_feasible_thresholds": int(len(valid)),
            "balanced_accuracy": float(curve["balanced_accuracy"][index]),
            "bad_escape_rate": float(bad_rate[index]), "good_reject_rate": float(good_rate[index]),
            "best_balanced_accuracy_on_calibration": best_ba,
            "better_than_constant_on_calibration": best_ba > .5 + 1e-12,
            "note": "Fitted on threshold split only. Fallback does not satisfy the requested limits and is not a production qualification."}


def tune_threshold(labels, scores, policy):
    return tune_threshold_details(labels, scores, policy)["threshold"]


def empirical_pass(m, policy):
    return (m["bad_escape_rate"] is not None and m["good_reject_rate"] is not None
            and m["bad_escape_rate"] <= policy["max_bad_escape_rate"] + 1e-12
            and m["good_reject_rate"] <= policy["max_good_reject_rate"] + 1e-12)


def evidence_pass(m, policy):
    bound = m["bad_unit_escape_upper"]
    return (empirical_pass(m, policy) and bound is not None
            and bound <= policy["max_bad_escape_rate"])


def candidate_targets_met(candidate, policy):
    calibration = candidate.get("threshold_metrics")
    return (empirical_pass(candidate["selection_metrics"], policy)
            and (calibration is None or empirical_pass(calibration, policy)))


def selection_key(candidate, policy):
    m = candidate["selection_metrics"]
    # Threshold is frozen before selection data is read. Do not tune here.
    if candidate_targets_met(candidate, policy):
        return (0, m["good_reject_rate"], m["bad_escape_rate"],
                -(m["pr_auc_bad"] or 0), len(candidate["members"]), candidate["name"])
    bad, good = m["bad_escape_rate"], m["good_reject_rate"]
    if bad is None or good is None:
        return (2, float("inf"), float("inf"), 1., 0., len(candidate["members"]), candidate["name"])
    return (1, (bad + good) / 2, max(bad, good), bad,
            -(m["pr_auc_bad"] or 0), len(candidate["members"]), candidate["name"])
