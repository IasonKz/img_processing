"""Deployment quality-review catalog, contained evidence access and requests."""
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode
import uuid

from .common import read_json
from .deployment_review import read_index, read_unit, inside, preview_asset


class DeploymentReviewDashboardMixin:
    def _quality_index(self, run, snapshot=None):
        if snapshot is None:
            snapshot = read_json(inside(run, "quality_review/current.json"))["snapshot"]
        if not isinstance(snapshot, str) or not snapshot or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-" for c in snapshot):
            raise ValueError("Choose a recorded quality-review snapshot.")
        folder = inside(run, "quality_review/snapshots/" + snapshot)
        files = [inside(folder, name) for name in ("index.json", "integrity.json")]

        def signature():
            return tuple((s.st_mtime_ns, s.st_ctime_ns, s.st_size, s.st_ino) for s in (path.stat() for path in files))

        with self.lock:
            cache = getattr(self, "_quality_index_cache", {})
            key, stamp = str(folder), signature()
            stored = cache.get(key)
            if stored and stored[0] == stamp:
                return stored[1]
            loaded = read_index(run, snapshot)
            if signature() == stamp:
                cache.pop(key, None)
                cache[key] = (stamp, loaded)
                while len(cache) > 4:
                    cache.pop(next(iter(cache)))
                self._quality_index_cache = cache
            return loaded

    def _deployment_run(self, value):
        root = (self.config.parent / "deployment" / "runs").resolve()
        path = self.checked_output(value, exists=True)
        if path.name == "report.json":
            path = path.parent
        if path.parent != root or path.is_symlink() or not (path / "report.json").is_file():
            raise ValueError("Choose a recorded deployment inspection.")
        report = read_json(path / "report.json")
        if report.get("status") != "completed":
            raise ValueError("Complete the inspection before opening its quality review.")
        return path

    def deployment_quality_catalog(self):
        runs, predictions = [], []
        for path in sorted((self.config.parent / "deployment" / "runs").glob("*/report.json"), reverse=True)[:200]:
            try:
                run = self._deployment_run(path)
                report = read_json(path)
                current = run / "quality_review" / "current.json"
                marker = read_json(current) if current.is_file() and not current.is_symlink() else {}
                runs.append({"path": str(run), "name": run.name, "pipeline": report.get("pipeline", {}).get("name"),
                             "started_utc": report.get("started_utc"), "review_ready": bool(marker),
                             "snapshot": marker.get("snapshot")})
            except (ValueError, OSError, KeyError, TypeError):
                continue
        segmentation = self.config.parent / "segmentation"
        for pattern in ("*/results/predictions/*/summary.json", "*/roi/*/*/results/predictions/*/summary.json"):
            for path in sorted(segmentation.glob(pattern), reverse=True)[:200]:
                try:
                    path = self.checked_output(path, exists=True)
                    summary = read_json(path)
                    if summary.get("status", "completed") != "completed":
                        continue
                    task = summary.get("task") or path.relative_to(segmentation).parts[0]
                    scope = summary.get("roi_scope") or (path.relative_to(segmentation).parts[2] if "/roi/" in path.as_posix() else "whole_image")
                    predictions.append({"path": str(path), "task": task, "scope": scope, "name": path.parent.name,
                                        "checkpoint_sha256": summary.get("checkpoint_sha256"), "images": len(summary.get("images", []))})
                except (OSError, ValueError, KeyError, TypeError):
                    continue
        return {"runs": runs, "sessions": [row for row in self.review_sessions() if row.get("progress", {}).get("status") == "completed"],
                "segmentation": predictions}

    def deployment_quality_request(self, data, export=False):
        run = self._deployment_run(data.get("run", ""))
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%f") + "_" + uuid.uuid4().hex[:8]
        if export:
            folder, index = self._quality_index(run, data.get("snapshot"))
            units = data.get("units", [])
            if not isinstance(units, list) or len(units) > 100000 or any(not isinstance(unit, str) for unit in units):
                raise ValueError("Selected units must be a list of recorded unit IDs.")
            if set(units) - {row["id"] for row in index["units"]}:
                raise ValueError("Selected units do not belong to this inspection.")
            settings = {"run": str(run), "snapshot": index["snapshot"], "units": units,
                        "include_images": data.get("include_images", True) is not False}
            output = run / "quality_review" / "reports" / stamp
        else:
            settings = {"run": str(run), "sessions": [], "segmentation": []}
            catalog = self.deployment_quality_catalog()
            for key in ("sessions", "segmentation"):
                values = data.get(key, [])
                if not isinstance(values, list) or len(values) > 100 or any(not isinstance(value, str) for value in values):
                    raise ValueError("Choose at most 100 recorded evidence sources of each type.")
                allowed = {row["path"] for row in catalog[key]}
                if any(value not in allowed for value in values):
                    raise ValueError("Select completed evidence from the available inspection catalog.")
                settings[key] = list(dict.fromkeys(values))
            if data.get("context_input"):
                context = self._configured_path(data["context_input"])
                if not context.is_dir() or context == run or run.is_relative_to(context) or context.is_relative_to(run):
                    raise ValueError("Additional view images must be outside the deployment results.")
                settings["context_input"] = str(context)
            output = run / "quality_review" / "snapshots" / stamp
        return settings, output

    def deployment_quality_detail(self, data):
        run = self._deployment_run(data.get("run", ""))
        folder, index = self._quality_index(run, data.get("snapshot"))
        units = [row for row in index["units"] if
                 (not data.get("search") or data["search"].lower() in (row["unit_id"] + " " + row["tray"]).lower())
                 and (not data.get("result") or row["review_status"] == data["result"])
                 and (not data.get("view") or row["views"].get(data["view"], {}).get("images", 0))]
        page = max(1, int(data.get("page", 1)))
        size = min(100, max(1, int(data.get("page_size", 25))))
        pages = max(1, (len(units) + size - 1) // size)
        page = min(page, pages)
        reports = []
        for path in sorted((run / "quality_review" / "reports").glob("*/report.json"), reverse=True)[:20]:
            try:
                record = read_json(path)
                if record.get("status") != "completed":
                    continue
                reports.append({"name": path.parent.name, "units": record["units"], "snapshot": record["snapshot"],
                    "html_url": self.file_url(path.with_name("report.html")), "zip_url": self.file_url(path.with_name("reports.zip")),
                    "json_url": self.file_url(path.with_name("evidence.json")), "csv_url": self.file_url(path.with_name("units.csv")),
                    "path": str(path.parent)})
            except (ValueError, OSError, KeyError):
                continue
        return {"run": str(run), "snapshot": index["snapshot"], "created_utc": index["created_utc"],
                "inspection": index["inspection"], "counts": index["counts"], "score_note": index["score_note"],
                "review_rule": index["review_rule"], "issues": index["issues"], "reports": reports,
                "units": units[(page-1)*size:page*size], "pagination": {"page": page, "pages": pages, "total": len(units)},
                "total_units": len(index["units"])}

    def deployment_quality_unit(self, data):
        run = self._deployment_run(data.get("run", ""))
        index, unit = read_unit(run, data.get("unit", ""), loaded=self._quality_index(run, data.get("snapshot")))
        assets = {}
        for item in unit["items"]:
            for asset_id in item["assets"]:
                asset = index["assets"][asset_id]
                params = {"run": str(run), "snapshot": index["snapshot"], "asset": asset_id}
                path = inside(run, asset["path"])
                assets[asset_id] = {**asset, "preview_url": "/api/deployment/quality/image?" + urlencode(params),
                                    "raw_url": self.file_url(path)}
        return {"unit": unit, "assets": assets,
                "distributions": {stat["distribution"]: index["distributions"][stat["distribution"]] for stat in unit["statistics"]},
                "snapshot": index["snapshot"], "score_note": index["score_note"]}

    def deployment_quality_image(self, data):
        run = self._deployment_run(data.get("run", ""))
        _, index = self._quality_index(run, data.get("snapshot"))
        window = {"black": data.get("black", "min"), "white": data.get("white", "max")} if data.get("window") == "1" else None
        return preview_asset(run, index, data.get("asset", ""), max_size=4096, window=window)

    def deployment_quality_image_info(self, data):
        from .image_io import load_rgb, display_statistics
        from .common import sha_file
        run = self._deployment_run(data.get("run", ""))
        _, index = self._quality_index(run, data.get("snapshot"))
        asset = index["assets"].get(data.get("asset", ""))
        if asset is None:
            raise ValueError("Choose a recorded image asset.")
        path = inside(run, asset["path"])
        if sha_file(path) != asset["sha256"]:
            raise ValueError("Frozen image evidence changed.")
        return display_statistics(load_rgb(path))
