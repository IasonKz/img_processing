from __future__ import annotations

import torch
import torchvision


def main() -> None:
    print(f"PyTorch: {torch.__version__}")
    print(f"Torchvision: {torchvision.__version__}")
    print(f"CUDA available: {torch.cuda.is_available()}")
    print(f"CUDA version reported by PyTorch: {torch.version.cuda}")
    if torch.cuda.is_available():
        print(f"GPU count: {torch.cuda.device_count()}")
        for index in range(torch.cuda.device_count()):
            properties = torch.cuda.get_device_properties(index)
            memory_gb = properties.total_memory / (1024**3)
            print(f"GPU {index}: {properties.name} | {memory_gb:.2f} GiB")
        tensor = torch.randn(1024, 1024, device="cuda")
        result = tensor @ tensor
        print(f"CUDA calculation succeeded: {float(result.mean()):.6f}")
    else:
        print("GPU training will NOT be used until a CUDA-enabled PyTorch build is installed.")


if __name__ == "__main__":
    main()
