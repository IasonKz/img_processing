"""Configuration formats preserve numeric contracts across worker boundaries."""
import json
from pathlib import Path
import tempfile
import unittest

from nilt.common import DEFAULTS, PROFILES, load_config, load_project, merge_dict, read_configuration
from nilt.dashboard import Dashboard


class ConfigurationFormatTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def test_json_exponents_remain_numbers_and_quoted_values_remain_strings(self):
        value = {'learning_rate': 1e-5, 'head_learning_rate': 3e-4,
                 'range': [1e-6, 1e-4], 'threshold': 1e20, 'note': '1e-05', 'enabled': True}
        for name in ('contract.json', 'contract.JSON', 'project.yaml'):
            with self.subTest(name=name):
                path = self.root/name
                path.write_text(json.dumps(value), encoding='utf-8-sig')
                loaded = read_configuration(path)
                self.assertEqual(loaded, value)
                self.assertIsInstance(loaded['learning_rate'], float)
                self.assertIsInstance(loaded['threshold'], float)
                self.assertIsInstance(loaded['note'], str)

    def test_yaml_block_and_flow_mappings_keep_existing_semantics(self):
        path = self.root/'config.yaml'
        path.write_text('learning_rate: 1.0e-5\nhead_learning_rate: 0.001\npretrained: true\n')
        self.assertEqual(read_configuration(path), {'learning_rate': 1e-5, 'head_learning_rate': .001, 'pretrained': True})
        path.write_text('{learning_rate: 0.00001, head_learning_rate: 0.001}')
        self.assertEqual(read_configuration(path), {'learning_rate': 1e-5, 'head_learning_rate': .001})

    def test_invalid_json_is_not_reinterpreted_as_yaml(self):
        path = self.root/'config.json'
        path.write_text('{learning_rate: 0.001}')
        with self.assertRaises(json.JSONDecodeError):
            read_configuration(path)

    def test_single_task_json_reload_preserves_all_training_and_search_values(self):
        cfg = merge_dict(merge_dict(DEFAULTS, PROFILES['laptop']), {'task': 'vig', 'profile': 'laptop', 'data_root': './data',
            'output_root': './results', 'weights_dir': './weights', 'models': ['resnet18'],
            'training': {'learning_rate': 1e-5, 'head_learning_rate': 2e-5, 'weight_decay': 1e-6},
            'search': {'space': {'learning_rate': [1e-6, 1e-4]}}})
        path = self.root/'training.json'
        path.write_text(json.dumps(cfg))
        for loaded in (load_config(path), load_project(path, task='vig')[0]):
            self.assertEqual(loaded['training'], cfg['training'])
            self.assertEqual(loaded['search'], cfg['search'])

    def test_project_json_uses_the_same_parser_in_dashboard_and_worker(self):
        raw = {'defaults': {'training': {'learning_rate': 1e-5, 'head_learning_rate': 2e-5}},
               'tasks': {'vig': {'dataset_root': './data'}}}
        path = self.root/'project.json'
        path.write_text(json.dumps(raw), encoding='utf-8-sig')
        app = Dashboard(path)
        self.assertEqual(app.raw, raw)
        self.assertEqual(app.v5_defaults({})['search']['space']['learning_rate']['low'], 1e-6)
        loaded = load_project(path, task='vig')[0]
        self.assertEqual(loaded['training']['learning_rate'], 1e-5)
        self.assertEqual(loaded['training']['head_learning_rate'], 2e-5)

    def test_invalid_learning_rates_remain_rejected(self):
        cfg = merge_dict(DEFAULTS, {'task': 'vig', 'profile': 'laptop', 'data_root': './data',
            'output_root': './results', 'weights_dir': './weights', 'models': ['resnet18']})
        path = self.root/'invalid.json'
        for key in ('learning_rate', 'head_learning_rate'):
            for value in (0, -1, float('nan'), float('inf'), True, '1e-05'):
                with self.subTest(key=key, value=value):
                    invalid = merge_dict(cfg, {'training': {key: value}})
                    path.write_text(json.dumps(invalid))
                    with self.assertRaisesRegex(ValueError, 'finite and positive'):
                        load_project(path, task='vig')


if __name__ == '__main__':
    unittest.main()
