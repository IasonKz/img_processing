@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\setup_directml_windows.ps1" %*
set "STUDIO_EXIT=%ERRORLEVEL%"
echo.
if not "%STUDIO_EXIT%"=="0" echo Setup did not complete. Read the error above; see docs\EXECUTION_V6.md.
pause
exit /b %STUDIO_EXIT%
