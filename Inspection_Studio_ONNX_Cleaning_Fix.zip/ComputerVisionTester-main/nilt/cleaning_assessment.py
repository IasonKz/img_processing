"""Read-only model assistance for dataset cleaning, separate from human tags."""
from datetime import datetime, timezone
from pathlib import Path
import numpy as np

from .common import read_json, write_json, sha_file
from .dataset_tools import dataset_items, checked_image


def load_source(kind, source, task, roi_scope):
    if kind == "decision":
        from .decisions import load_decision
        record, run, cfg, chosen = load_decision(source)
        stages = [{"index": 0, "name": record.get("name", chosen["name"]),
                   "record": record, "run": run, "cfg": cfg, "chosen": chosen, "decision_sha256": sha_file(source)}]
        if record["mode"] == "scores_only":
            raise ValueError("Choose a saved decision with a Good/Bad/Review rule, not scores-only.")
    elif kind == "workflow":
        from .inspection_flow import load_workflow
        record, stages = load_workflow(source)
    else:
        raise ValueError("Choose a model decision or an inspection workflow.")
    if any(stage["cfg"].get("task") != task or stage["cfg"].get("roi_scope", "whole_image") != roi_scope for stage in stages):
        raise ValueError("The cleaning model must match the selected task and ROI target.")
    return record, stages


def assess(settings, output, stop_check=None):
    """Use the same member scoring and frozen voting rules as normal inference."""
    from .workflow import predict_members
    from .decisions import classify_scores
    from .inspection_flow import aggregate_votes, _trace
    from .image_io import load_rgb
    from .engine import prepare_image
    output = Path(output)
    root, source = Path(settings["root"]).resolve(), Path(settings["source"]).resolve()
    report = {"format": "dataset_cleaning_assessment.v1", "status": "running", **settings,
              "created_utc": datetime.now(timezone.utc).isoformat(), "total": 0, "completed": 0}
    write_json(output / "report.json", report)
    if sha_file(source) != settings["source_sha256"]:
        raise ValueError("The selected decision changed. Choose it again before scoring.")
    record, stages = load_source(settings["kind"], source, settings["task"], settings["roi_scope"])

    def checkpoint():
        if stop_check and stop_check():
            raise InterruptedError("Cleaning assessment stopped; original images and tags are unchanged.")

    rows, results = [], []
    for item in dataset_items(root):
        checkpoint()
        path = checked_image(root, item["relative_path"])
        stat = path.stat()
        identity = {"relative_path": item["relative_path"], "file_sha256": sha_file(path),
                    "bytes": stat.st_size, "mtime_ns": stat.st_mtime_ns, "initial_label": item["label"]}
        try:
            prepare_image(load_rgb(path), stages[0]["cfg"])
            rows.append({**identity, "path": str(path), "true_class": ""})
        except (OSError, ValueError) as error:
            results.append({**identity, "status": "input_error", "prediction": "review", "error": str(error), "stage_results": []})
    report["total"] = len(rows) + len(results)
    write_json(output / "report.json", report)
    traces = [[_trace(s) for s in stages] for _ in rows]
    votes = [[] for _ in rows]
    pending = list(range(len(rows)))
    for index, stage in enumerate(stages):
        checkpoint()
        report.update(stage=stage["name"], completed=len(results))
        write_json(output / "report.json", report)
        if not pending:
            break
        cfg = {**stage["cfg"], "device": settings["device"]}
        scores, _ = predict_members(stage["run"], stage["chosen"]["members"], [rows[i] for i in pending], cfg,
                                    **({"stop_check": stop_check} if stop_check else {}))
        scores = np.asarray(scores, dtype=float)
        if scores.shape != (len(pending),) or not np.isfinite(scores).all():
            raise ValueError("Invalid cleaning assessment scores.")
        if stage["record"]["kind"] == "supervised" and np.any((scores < 0) | (scores > 1)):
            raise ValueError("Supervised bad scores must be in [0,1].")
        predictions = classify_scores(scores, stage["record"])
        next_pending = []
        for i, score, prediction in zip(pending, scores, predictions):
            checkpoint()
            if sha_file(rows[i]["path"]) != rows[i]["file_sha256"]:
                raise ValueError("An input changed during assessment: " + rows[i]["relative_path"])
            prediction = str(prediction)
            votes[i].append(prediction)
            traces[i][index] = _trace(stage, "evaluated", float(score), prediction)
            rule = record.get("rule") if settings["kind"] == "workflow" else None
            decisive = (rule == "any_bad" and prediction == "bad") or (rule == "all_bad" and prediction == "good")
            if decisive or index == len(stages) - 1:
                final = prediction if decisive or rule is None else aggregate_votes(votes[i], rule)
                for later in range(index + 1, len(stages)):
                    traces[i][later] = _trace(stages[later], "skipped", reason="earlier_stage_resolved_decision")
                results.append({key: value for key, value in rows[i].items() if key not in ("path", "true_class")} |
                               {"status": "ok", "prediction": final, "stage_results": traces[i],
                                "bad_score": float(score) if rule is None else None,
                                "score_type": stage["record"]["score_type"] if rule is None else "workflow_decision",
                                "threshold": stage["record"].get("threshold") if rule is None else None})
            else:
                next_pending.append(i)
        pending = next_pending
        # Retain completed rows at stage boundaries, including on interruption.
        write_json(output / "predictions.json", results)
    checkpoint()
    if sha_file(source) != settings["source_sha256"]:
        raise ValueError("The decision changed during assessment; results cannot be applied.")
    write_json(output / "predictions.json", sorted(results, key=lambda r: r["relative_path"]))
    report.update(status="completed", completed=len(results), stage="",
                  counts={label: sum(r["prediction"] == label for r in results) for label in ("good", "bad", "review")})
    write_json(output / "report.json", report)
    return report


def disagreement(label, prediction):
    """Bad is the positive class. Review/unsuitable are never reference negatives."""
    if label not in ("good", "bad") or not prediction or prediction.get("status") != "ok":
        return ""
    predicted = prediction.get("prediction")
    if label == "bad" and predicted == "good":
        return "fn"
    if label == "good" and predicted == "bad":
        return "fp"
    return "mismatch" if predicted and predicted != label else "match"
