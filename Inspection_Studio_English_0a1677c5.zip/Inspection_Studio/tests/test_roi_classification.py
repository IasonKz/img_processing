"""Scope isolation and original-unit split preservation, using synthetic crops."""
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

import numpy as np
from PIL import Image
import yaml

from nilt.common import load_project, read_json, write_csv, write_json
from nilt.dashboard import Dashboard
from nilt.data import audit, make_manifest
from nilt.roi.classification import configure_classification, inspect_dataset


class ROIClassificationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.whole = self.root / "original_top"
        self.whole.mkdir()
        self.base = self.root / "project.yaml"
        self.base.write_text(yaml.safe_dump({"schema_version": 3,
            "paths": {"output_root": "results", "weights_root": "weights"},
            "defaults": {"grouping": "tray_unit", "near_duplicate_distance": -1},
            "tasks": {"top": {"dataset_root": str(self.whole), "group_regex": "(?P<group>UNIT[0-9]+)",
                              "models": ["resnet18"], "training": {"batch_size": 7}},
                      "vig": {"dataset_root": str(self.whole)}}}), encoding="utf-8")
        self.app = Dashboard(self.base)

    def tearDown(self):
        self.temp.cleanup()

    def dataset(self, scope="corners", side="top"):
        root = self.root / "export" / scope
        mapping = []
        seed = 0
        # Every unit has both labels, with multiple crops. Enough validation
        # units allow three grouped calibration/selection partitions.
        for split, count in (("train", 3), ("val", 9), ("test", 3)):
            for unit in range(count):
                group = f"TRAY-{split}_UNIT-{unit}"
                for label in ("good", "bad"):
                    for roi in range(2):
                        path = root / split / label / f"{group}_{roi}.png"
                        path.parent.mkdir(parents=True, exist_ok=True)
                        pixels = np.random.default_rng(seed).integers(0, 256, (32, 32, 3), dtype=np.uint8)
                        Image.fromarray(pixels).save(path)
                        seed += 1
                        mapping.append({"relative_path": path.relative_to(root).as_posix(), "group": group})
        write_csv(root / "groups.csv", mapping)
        write_json(root / "roi_dataset.json", {"side": side, "roi_scope": scope, "export_id": "v1",
                   "template_version": "geometry1", "crop_version": "crop1"})
        return root

    def test_scope_roundtrip_preserves_whole_settings_and_base_file(self):
        original = self.base.read_bytes()
        dataset = self.dataset()
        result = configure_classification(self.app, {"side": "top", "roi_scope": "corners", "dataset": str(dataset)})
        self.assertEqual(result["dataset"], str(dataset))
        cfg = load_project(self.app.config, "laptop", "top")[0]
        self.assertEqual(cfg["roi_scope"], "corners")
        self.assertEqual(cfg["groups_csv"], str(dataset / "groups.csv"))
        self.assertEqual(cfg["training"]["batch_size"], 7)
        self.assertEqual(cfg["output_root"], str(self.root / "results" / "roi_classification" / "corners"))
        self.assertEqual(self.app._v5_resolved_config("laptop", "top")["output_root"], cfg["output_root"])
        result = configure_classification(self.app, {"side": "top", "roi_scope": "whole_image"})
        self.assertEqual(result["dataset"], str(self.whole))
        cfg = load_project(self.app.config, "laptop", "top")[0]
        self.assertEqual(cfg["group_regex"], "(?P<group>UNIT[0-9]+)")
        self.assertEqual(cfg["output_root"], str(self.root / "results"))
        self.assertEqual(self.base.read_bytes(), original)
        configure_classification(self.app, {"side": "top", "roi_scope": "corners"})
        self.assertEqual(self.app.bootstrap()["datasets"]["top"], str(dataset))

    def test_unconfigured_scope_does_not_reuse_whole_image_dataset(self):
        result = configure_classification(self.app, {"side": "top", "roi_scope": "label"})
        self.assertEqual(result["dataset"], "")
        self.assertFalse(result["config"]["task_enabled"]["top"])
        with self.assertRaisesRegex(ValueError, "scope changed"):
            self.app.command("audit", {"task": "top", "roi_scope": "corners"})
        configure_classification(self.app, {"side": "top", "roi_scope": "whole_image"})
        self.assertEqual(self.app.bootstrap()["datasets"]["top"], str(self.whole))

    def test_only_validation_units_subdivided_and_test_is_frozen(self):
        dataset = self.dataset("pins", "bottom")
        configure_classification(self.app, {"side": "bottom", "roi_scope": "pins", "dataset": str(dataset)})
        cfg = load_project(self.app.config, "laptop", "bottom")[0]
        records = audit(cfg, self.root / "audit")
        rows = make_manifest(cfg, records, self.root / "manifest")
        unit_splits = {}
        for row in rows:
            unit_splits.setdefault(row["source_group"], set()).add(row["split"])
            original = row["relative_path"].split("/")[0]
            if original in ("train", "test"):
                self.assertEqual(row["split"], original)
            else:
                self.assertIn(row["split"], ("val", "threshold", "selection"))
        self.assertTrue(all(len(splits) == 1 for splits in unit_splits.values()))
        self.assertEqual({row["split"] for row in rows}, {"train", "val", "threshold", "selection", "test"})

    def test_handoff_rejects_scope_mismatch_and_cross_split_units(self):
        dataset = self.dataset()
        with self.assertRaisesRegex(ValueError, "side/scope"):
            inspect_dataset(dataset, "top", "label")
        from nilt.common import read_csv
        rows = read_csv(dataset / "groups.csv")
        rows[-1]["group"] = rows[0]["group"]
        write_csv(dataset / "groups.csv", rows)
        with self.assertRaisesRegex(ValueError, "multiple"):
            inspect_dataset(dataset, "top", "corners")

    def test_save_config_and_reload_preserve_scope(self):
        dataset = self.dataset()
        self.app.save_config({"task": "top", "roi_scope": "corners", "dataset": str(dataset)})
        app = Dashboard(self.base)
        self.assertEqual(app.bootstrap()["roi_scopes"]["top"], "corners")
        self.assertEqual(app.bootstrap()["roi_datasets"]["top"]["whole_image"], str(self.whole))
        run = self.root / "results" / "roi_classification" / "corners" / "top" / "experiment1"
        write_json(run / "config.json", {"task": "top", "roi_scope": "corners"})
        write_json(run / "model_state.json", {"status": "PREPARED"})
        self.assertEqual(next(r for r in app.runs() if r["path"] == str(run))["roi_scope"], "corners")

    def test_preprocessing_selects_whole_images_and_preserves_other_roi_settings(self):
        corners, pins = self.dataset(), self.dataset("pins", "bottom")
        configure_classification(self.app, {"side": "top", "roi_scope": "corners", "dataset": str(corners)})
        configure_classification(self.app, {"side": "bottom", "roi_scope": "pins", "dataset": str(pins)})
        prepared = self.root / "prepared"
        for side in ("top", "bottom"):
            for label in ("good", "bad"):
                (prepared / side / label).mkdir(parents=True)
        job = {"id": "prepared1", "action": "preprocess", "status": "finished"}
        write_json(self.app.logs_root / "prepared1.preprocessing.json", {"complete": True, "output": str(prepared),
            "counts": {"top/good": 1, "bottom/bad": 1}})
        with patch.object(self.app, "_preprocessing_job", return_value=job), patch.object(self.app, "preprocessing_recorded_output", return_value=prepared):
            boot = self.app.preprocessing_use_dataset({"job": "prepared1", "task": "top"})
        self.assertEqual(boot["roi_scopes"]["top"], "whole_image")
        self.assertEqual(boot["datasets"]["top"], str(prepared / "top"))
        self.assertEqual(boot["roi_scopes"]["bottom"], "pins")
        self.assertEqual(boot["datasets"]["bottom"], str(pins))
        self.assertEqual(boot["roi_datasets"]["top"]["corners"], str(corners))
        self.assertEqual(boot["roi_datasets"]["bottom"]["whole_image"], str(prepared / "bottom"))
        configure_classification(self.app, {"side": "top", "roi_scope": "corners"})
        self.assertEqual(self.app.raw["tasks"]["top"]["groups_csv"], str(corners / "groups.csv"))


if __name__ == "__main__":
    unittest.main()
