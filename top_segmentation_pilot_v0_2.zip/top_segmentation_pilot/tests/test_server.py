"""Real local-server requests cover annotation integrity and request boundaries."""
import http.client
import json
from pathlib import Path
import tempfile
import threading
import unittest

import numpy as np
from PIL import Image

from topseg.classical import reclassify_mask
from topseg.common import load_config
from topseg.project import Project
from topseg.server import decode_rle, encode_rle, make_server


class MaskEncodingTests(unittest.TestCase):
    def test_round_trip_preserves_all_three_labels(self):
        expected = np.array([[0, 0, 1], [2, 2, 0]], dtype=np.uint8)
        np.testing.assert_array_equal(expected, decode_rle(encode_rle(expected), 3, 2))

    def test_rejects_invalid_or_incomplete_labels_counts(self):
        for runs in (None, [[3, 4]], [[True, 4]], [[1, True]], [[1, -1]], [[1, 5]], [[0, 3]], [[0, 4.0]], [[0, 4], [1, 1]]):
            with self.subTest(runs=runs), self.assertRaises(ValueError):
                decode_rle(runs, 2, 2)


class AnnotationHTTPTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        sources = self.root / 'sources'; sources.mkdir()
        image = np.full((48, 64, 3), 110, dtype=np.uint8)
        image[20:25, 30:35] = 20
        Image.fromarray(image).save(sources / 'unit-a.png')
        self.source_bytes = (sources / 'unit-a.png').read_bytes()
        config_path = self.root / 'project.yaml'
        config_path.write_text('input_dir: sources\nproject_dir: workspace\noutput_dir: output\n', encoding='utf-8')
        self.cfg = load_config(config_path)
        project = Project(self.cfg); project.import_images()
        self.image_id = project.items()[0]['id']
        self.server = make_server(self.cfg)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True); self.thread.start()
        self.host = f'127.0.0.1:{self.server.server_port}'

    def tearDown(self):
        self.server.shutdown(); self.server.server_close(); self.thread.join(5); self.temp.cleanup()

    def request(self, method, path, body=None, token=True, origin=True, host=None):
        connection = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=10)
        headers = {'Host': host or self.host}
        if token: headers['X-Session-Token'] = self.server.session_token
        if method == 'POST' and origin: headers['Origin'] = f'http://{self.host}'
        if body is not None:
            headers['Content-Type'] = 'application/json'; body = json.dumps(body)
        connection.request(method, path, body=body, headers=headers)
        response = connection.getresponse(); data = response.read(); status = response.status
        content_type = response.getheader('Content-Type'); connection.close()
        return status, json.loads(data) if content_type.startswith('application/json') else data

    def test_static_ui_and_api_authentication(self):
        status, page = self.request('GET', '/', token=False)
        self.assertEqual(status, 200); self.assertIn(self.server.session_token.encode(), page)
        self.assertIn(b'Approve clean', page)
        self.assertEqual(self.request('GET', '/api/project', token=False)[0], 403)
        self.assertEqual(self.request('GET', '/', host='untrusted.example')[0], 403)
        self.assertEqual(self.request('GET', '/api/project')[0], 200)

    def test_rejects_remote_or_missing_origin_and_missing_token(self):
        path = f'/api/image/{self.image_id}/annotation'
        for token, origin in ((False, True), (True, False)):
            self.assertEqual(self.request('POST', path, {}, token=token, origin=origin)[0], 403)

    def test_real_proposal_edit_approval_conflict_and_source_preservation(self):
        path = f'/api/image/{self.image_id}'
        status, opened = self.request('GET', path)
        self.assertEqual(status, 200); self.assertEqual(opened['status'], 'draft')
        self.assertGreater(opened['revision'], 0)
        mask = decode_rle(opened['mask_rle'], 64, 48); mask[:] = 0
        mask[4:9, 3:7] = 1; mask[24:26, 20:23] = 2
        payload = dict(mask_rle=encode_rle(mask), expected_revision=opened['revision'], approved=True, clean=False, roi=opened['roi'])
        status, saved = self.request('POST', path + '/annotation', payload)
        self.assertEqual(status, 200, saved); self.assertEqual(saved['status'], 'approved')
        np.testing.assert_array_equal(decode_rle(saved['mask_rle'], 64, 48), reclassify_mask(mask, opened['roi']))
        self.assertEqual(self.request('POST', path + '/annotation', payload)[0], 409)
        self.assertEqual(self.request('GET', path + '/rgb')[0], 200)
        self.assertEqual(self.request('GET', path + '/mask')[0], 200)
        self.assertEqual((self.root / 'sources' / 'unit-a.png').read_bytes(), self.source_bytes)
        # Regeneration is another draft revision and requires a current revision.
        status, proposal = self.request('POST', path + '/propose', {'roi': saved['roi'], 'expected_revision': saved['revision'], 'settings': {'sensitivity': 5}})
        self.assertEqual(status, 200, proposal); self.assertEqual(proposal['status'], 'draft')
        status, invalid = self.request('POST', path + '/annotation', {'mask_rle': [[0, 3072]], 'expected_revision': proposal['revision'], 'approved': True, 'clean': False})
        self.assertEqual(status, 400, invalid)
        status, clean = self.request('POST', path + '/annotation', {'mask_rle': [[0, 3072]], 'expected_revision': proposal['revision'], 'approved': True, 'clean': True})
        self.assertEqual(status, 200, clean); self.assertTrue(clean['clean'])

    def test_invalid_mask_and_boolean_revision_are_rejected(self):
        path = f'/api/image/{self.image_id}'
        _, opened = self.request('GET', path)
        self.assertEqual(self.request('POST', path + '/annotation', {'mask_rle': [[0, 3072]], 'expected_revision': True})[0], 400)
        self.assertEqual(self.request('POST', path + '/annotation', {'mask_rle': [[4, 3072]], 'expected_revision': opened['revision']})[0], 400)
        self.assertEqual(self.request('GET', '/../../project.yaml')[0], 404)



    def test_layers_visibility_overlap_deletion_and_polygon_relabel_over_http(self):
        path = f'/api/image/{self.image_id}'
        _, opened = self.request('GET', path)
        roi = {'type': 'polygon', 'points': [{'x': 24, 'y': 8}, {'x': 48, 'y': 8},
               {'x': 56, 'y': 16}, {'x': 56, 'y': 36}, {'x': 48, 'y': 44},
               {'x': 24, 'y': 44}, {'x': 16, 'y': 36}, {'x': 16, 'y': 16}]}
        first = np.zeros((48, 64), dtype=np.uint8); first[20:30, 10:35] = 1
        second = np.zeros_like(first); second[25:35, 25:45] = 1
        objects = [dict(id='first', name='Cross-border box', kind='rectangle', visible=False, mask_rle=encode_rle(first)),
                   dict(id='second', name='Overlapping circle', kind='circle', visible=True, mask_rle=encode_rle(second))]
        union = first | second
        payload = dict(mask_rle=encode_rle(union), objects=objects, roi=roi,
                       notes='Two independent footprints.', expected_revision=opened['revision'])
        status, saved = self.request('POST', path + '/annotation', payload)
        self.assertEqual(status, 200, saved)
        expected = reclassify_mask(union, roi)
        np.testing.assert_array_equal(decode_rle(saved['mask_rle'], 64, 48), expected)
        self.assertTrue((expected == 1).any()); self.assertTrue((expected == 2).any())
        self.assertEqual(saved['objects'], objects)
        _, reloaded = self.request('GET', path)
        self.assertEqual(reloaded['objects'], objects)
        self.assertEqual(reloaded['notes'], payload['notes'])
        # Hidden first footprint remains in the saved mask; deleting second restores it.
        status, deleted = self.request('POST', path + '/annotation', dict(
            mask_rle=encode_rle(first), objects=[objects[0]], roi=roi,
            expected_revision=saved['revision']))
        self.assertEqual(status, 200, deleted)
        actual = decode_rle(deleted['mask_rle'], 64, 48)
        np.testing.assert_array_equal(actual, reclassify_mask(first, roi))
        self.assertGreater(actual[27, 30], 0); self.assertEqual(actual[33, 40], 0)
        self.assertFalse(deleted['objects'][0]['visible'])
        self.assertEqual((self.root / 'sources' / 'unit-a.png').read_bytes(), self.source_bytes)

    def test_invalid_object_footprints_do_not_write_a_revision(self):
        path = f'/api/image/{self.image_id}'
        _, opened = self.request('GET', path)
        mask = np.zeros((48, 64), dtype=np.uint8); mask[12:18, 22:28] = 1
        valid = dict(id='one', name='Shape', kind='polygon', visible=True, mask_rle=encode_rle(mask))
        for objects in ([dict(valid, visible='false')], [dict(valid, mask_rle=[[2, 3072]])],
                        [valid, valid], [dict(valid, mask_rle=[[0, 3072]])]):
            with self.subTest(objects=objects):
                status, error = self.request('POST', path + '/annotation', dict(
                    mask_rle=encode_rle(mask), objects=objects, expected_revision=opened['revision']))
                self.assertEqual(status, 400, error)
                self.assertEqual(self.request('GET', path)[1]['revision'], opened['revision'])

    def test_detect_roi_is_nonmutating_and_checks_revision(self):
        path = f'/api/image/{self.image_id}'
        _, opened = self.request('GET', path)
        status, detected = self.request('POST', path + '/detect-roi', {'expected_revision': opened['revision']})
        self.assertEqual(status, 200, detected)
        self.assertIn('roi', detected); self.assertIn('found', detected['detection'])
        self.assertEqual(self.request('GET', path)[1], opened)
        self.assertEqual(self.request('POST', path + '/detect-roi', {'expected_revision': opened['revision'] - 1})[0], 409)

    def test_reject_restore_preserves_review_but_requires_new_approval(self):
        path = f'/api/image/{self.image_id}'
        _, opened = self.request('GET', path)
        empty = [[0, 64 * 48]]
        status, approved = self.request('POST', path + '/annotation', dict(
            mask_rle=empty, objects=[], expected_revision=opened['revision'], approved=True,
            clean=True, notes='Previously approved, now excluded.'))
        self.assertEqual(status, 200, approved)
        status, rejected = self.request('POST', path + '/reject', dict(
            expected_revision=approved['revision'], reason='Acquisition out of focus'))
        self.assertEqual(status, 200, rejected); self.assertEqual(rejected['status'], 'rejected')
        self.assertEqual(rejected['mask_rle'], empty); self.assertEqual(rejected['objects'], [])
        self.assertEqual(rejected['notes'], approved['notes'])
        self.assertEqual(self.request('GET', '/api/project')[1]['approved'], 0)
        self.assertEqual(self.request('POST', path + '/reject', {'expected_revision': approved['revision']})[0], 409)
        self.assertEqual(self.request('POST', path + '/annotation', dict(mask_rle=empty,
            objects=[], expected_revision=rejected['revision'], approved=True, clean=True))[0], 400)
        with self.assertRaisesRegex(ValueError, 'No reviewed'):
            self.server.project.snapshot(self.root / 'excluded_dataset')
        # Draft edits cannot silently put a rejected image back into the dataset.
        status, edited = self.request('POST', path + '/annotation', dict(mask_rle=empty,
            objects=[], expected_revision=rejected['revision'], notes=rejected['notes']))
        self.assertEqual(status, 200, edited); self.assertEqual(edited['status'], 'rejected')
        status, restored = self.request('POST', path + '/restore', {'expected_revision': edited['revision']})
        self.assertEqual(status, 200, restored); self.assertEqual(restored['status'], 'draft')
        self.assertFalse(restored['approved']); self.assertFalse(restored['clean'])
        self.assertEqual(restored['notes'], approved['notes']); self.assertEqual(restored['mask_rle'], empty)
        self.assertEqual((self.root / 'sources' / 'unit-a.png').read_bytes(), self.source_bytes)


if __name__ == '__main__':
    unittest.main()
