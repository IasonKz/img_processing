# Deployment quality review

**Classification → VIG → Deployment → Quality review** opens a completed folder inspection as a physical-unit gallery. Each unit has separate TOP, BOTTOM and VIG views, its recorded decisions, image evidence and a position within the current inspection's distributions. Optional reports can be generated for the selected unit or the entire inspection.

## Run and open an inspection

1. Freeze a saved VIG decision, Decision Lab system or workflow in **Run frozen pipeline**.
2. Select an incoming image folder or ZIP and start inspection. Mixed folders can contain `top/`, `bottom/` and `vig/` subfolders or recognizable tester capture names. The VIG pipeline processes identified VIG captures; TOP/BOTTOM images are retained as context previews.
3. Open **Quality review** from the completed run's history or the Deployment sidebar. New inspections create their initial review snapshot automatically. Older completed inspections can use **Create / update review**.
4. Select a unit, filter by routing result or view, or search for its unit/tray identity. The image controls select TOP/BOTTOM/VIG and originals, crops, model masks, model overlays or geometric ROI evidence. Click a thumbnail for a larger preview; Left/Right navigate the displayed evidence. **Open native evidence** opens the stored file at its original bit depth.

The current frozen deployment runner executes VIG recipes. This section does not automatically run or qualify a combined TOP/BOTTOM/VIG production pipeline.

## Link classification and segmentation outputs

Expand **Link additional inspection evidence**, select completed TOP/BOTTOM classification sessions and segmentation predictions from the same batch, then choose **Create / update review**. Completed VIG sessions can also be linked explicitly. **Additional view image folder** supplies context originals when they were not present in the deployment input; it does not classify or segment those images.

Only physical units present in the selected deployment inspection are added. Tester filenames such as `C00000083_Rc01Cc02_ViTopFinal.png` map to `C83:R1:C2`. Verified ROI crop manifests restore the original unit identity for crop filenames. Unrecognized captures remain separate with an unconfirmed identity instead of being joined by their basename. Sources containing no matching units are disclosed in the review.

New segmentation predictions record native source copies, source/checkpoint SHA-256, study/trial/model identity, semantic masks, overlays, defect pixel counts and per-pixel probability summaries. ROI predictions also retain the inspected crop, original source image, geometry mask/overlay and crop transform when the verified export provides them. Defect masks use background `0`, inner `1` and outer `2`; previews show inner defects in red and outer defects in blue. Geometric masks use cyan and describe the crop support region.

Earlier prediction outputs may still be linked when their original job request and images are available. Their missing inference-time hashes or probability summaries are identified as legacy evidence. Missing or changed files and inconsistent masks remain visible as unavailable evidence.

## Decisions, confidence evidence and statistics

Classification evidence displays the recorded BAD score, Good/Bad boundaries, decision margin, review reason and any evaluated pipeline stages. Skipped stages do not count as agreeing model votes. Anomaly distances and transformed system scores retain their own scales and thresholds.

Segmentation evidence displays inner/outer defect pixels, affected-area ratio and mean selected per-pixel probability. Scores and pixel probabilities are uncalibrated; they are not a calibrated probability that the complete unit is correct. Quality review does not infer ground-truth accuracy, FP or FN without independent labels.

Histograms and percentiles compare units **within this inspection**, using separate distributions for each view, ROI scope, model/recipe and threshold contract. One physical unit contributes one value per metric: the maximum recorded BAD score or defect-area ratio, and the minimum mean pixel probability. Repeated captures do not increase that unit's weight. Equal values use the midpoint of their percentile ranks. Percentiles describe the cohort and do not represent prediction correctness. Distributions show the cohort size, median and P05/P95; the orange marker identifies the selected unit.

Review routing is conservative:

- A recorded Bad quality decision routes the unit to **Bad**.
- Missing, unavailable or abstaining views route it to **Review**.
- **Good** requires quality decisions for TOP, BOTTOM and VIG and a confirmed unit identity. Good decisions on a subset of ROI crops alone do not certify a complete view.
- A segmentation mask alone supplies defect evidence; it has no implicit binary quality rule. A combined production verdict still requires an explicit deployed recipe and representative validation.

This review routing does not modify the original VIG predictions, exported Good/Bad/Review folders, operator annotations or training labels.

## Generate reports

Choose **Generate selected unit report** or **Generate all unit reports**. Reports are created only on request. **Include images and native evidence** includes embedded display previews and exact native originals/crops/masks. Disable it for a smaller metadata/statistics report.

Each completed report bundle contains:

| File | Contents |
| --- | --- |
| `report.html` | Local index of the selected unit reports |
| `units/<unit-id>.html` | Standalone English unit report with all three views, decisions, evidence and distributions; printable from a browser |
| `evidence.json` | Complete selected unit records, provenance, statistics and asset references |
| `units.csv` | One summary row per unit/view |
| `assets/` | Exact native evidence when images are included |
| `integrity.json` | Report bundle checksums |
| `reports.zip` | Portable report bundle, including relative native-evidence links |

Download the ZIP from **Generated reports**, open the HTML or use **Open folder**. Large exports can be opened from their output folder if they exceed the dashboard's existing 64 MiB file-download limit. Model weights are not duplicated into the reports.

Review snapshots live in `deployment/runs/<inspection>/quality_review/snapshots/<snapshot>/`; requested reports live in `quality_review/reports/<report>/`. SHA-256 checks protect recorded indexes, unit records and native image evidence. A rebuild publishes a new snapshot after completion; an interrupted rebuild retains the previous active snapshot. Managed worker logs and **Stop worker now** are available during review creation and report generation.

No additional dependencies or model downloads are required. Restart the dashboard after updating the project on Linux or Windows.

Executed checks and their limits are recorded in [Quality review verification](DEPLOYMENT_QUALITY_REVIEW_VERIFICATION.md).
