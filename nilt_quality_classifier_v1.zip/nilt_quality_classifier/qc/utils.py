from __future__ import annotations

import json
import logging
import os
import random
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import torch


def seed_everything(seed: int, deterministic: bool = False) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    if deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        try:
            torch.use_deterministic_algorithms(True, warn_only=True)
        except Exception:
            pass
    elif torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True


def choose_device(requested: str = "auto") -> torch.device:
    requested = str(requested).lower().strip()
    if requested == "auto":
        if torch.cuda.is_available():
            return torch.device("cuda")
        if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
            return torch.device("mps")
        return torch.device("cpu")

    if requested.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError(
            "CUDA was requested, but torch.cuda.is_available() is False. "
            "Install a CUDA-enabled PyTorch build and verify the NVIDIA driver."
        )
    if requested == "mps" and not (
        getattr(torch.backends, "mps", None) and torch.backends.mps.is_available()
    ):
        raise RuntimeError("MPS was requested but is not available.")
    return torch.device(requested)


def device_summary(device: torch.device) -> dict[str, Any]:
    summary: dict[str, Any] = {
        "device": str(device),
        "torch_version": torch.__version__,
        "cuda_available": bool(torch.cuda.is_available()),
    }
    if device.type == "cuda":
        summary.update(
            {
                "cuda_device_name": torch.cuda.get_device_name(device),
                "cuda_device_count": torch.cuda.device_count(),
                "cuda_version_reported_by_torch": torch.version.cuda,
            }
        )
    return summary


def timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def slugify(text: str) -> str:
    text = re.sub(r"[^A-Za-z0-9._-]+", "_", text.strip())
    return text.strip("_") or "run"


def make_run_dir(output_root: Path, run_name: str) -> Path:
    output_root.mkdir(parents=True, exist_ok=True)
    candidate = output_root / f"{slugify(run_name)}_{timestamp()}"
    index = 1
    while candidate.exists():
        candidate = output_root / f"{slugify(run_name)}_{timestamp()}_{index:02d}"
        index += 1
    candidate.mkdir(parents=True, exist_ok=False)
    return candidate


def setup_logging(log_path: Path | None = None, verbose: bool = True) -> logging.Logger:
    logger = logging.getLogger("quality_classifier")
    logger.setLevel(logging.DEBUG if verbose else logging.INFO)
    logger.handlers.clear()
    logger.propagate = False

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    stream = logging.StreamHandler(sys.stdout)
    stream.setLevel(logging.DEBUG if verbose else logging.INFO)
    stream.setFormatter(formatter)
    logger.addHandler(stream)

    if log_path is not None:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_path, encoding="utf-8")
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    return logger


def to_jsonable(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): to_jsonable(val) for key, val in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [to_jsonable(item) for item in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().tolist()
    if isinstance(value, (datetime,)):
        return value.isoformat()
    return value


def write_json(data: Any, path: str | Path) -> None:
    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as handle:
        json.dump(to_jsonable(data), handle, indent=2, ensure_ascii=False)


def copy_preserving_relative_path(
    source: Path,
    *,
    source_root: Path | None,
    destination_root: Path,
    fallback_prefix: str = "",
) -> Path:
    try:
        relative = source.resolve().relative_to(source_root.resolve()) if source_root else None
    except (ValueError, OSError):
        relative = None

    if relative is None:
        name = f"{fallback_prefix}{source.name}" if fallback_prefix else source.name
        relative = Path(name)

    destination = destination_root / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        stem = destination.stem
        suffix = destination.suffix
        counter = 2
        while destination.exists():
            destination = destination.with_name(f"{stem}__{counter}{suffix}")
            counter += 1
    shutil.copy2(source, destination)
    return destination


def chunked(items: list[Any], size: int) -> Iterable[list[Any]]:
    for start in range(0, len(items), size):
        yield items[start : start + size]


def human_count(value: int) -> str:
    return f"{value:,}".replace(",", " ")


def ensure_windows_spawn_safe() -> None:
    """No-op marker used by entry points for readable Windows guidance."""
    # Every executable script calls its main function under
    # ``if __name__ == '__main__'``.  That is the important requirement for
    # DataLoader workers on Windows.
    return None


def env_info() -> dict[str, Any]:
    return {
        "python": sys.version,
        "platform": sys.platform,
        "cwd": os.getcwd(),
        "torch": torch.__version__,
    }
