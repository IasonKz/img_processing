"""Dataset audit, deterministic grouped partitioning, and incremental lineage checks.

Decoded-image identity and explicitly enabled tray/row/column filename identities
are checked separately. A pixel hash alone is not a physical unit ID.
"""
from __future__ import annotations

from collections import Counter, defaultdict
import hashlib
import json
import math
import re
from pathlib import Path, PurePosixPath

import numpy as np
from PIL import Image, ImageOps
from scipy.fft import dctn

from .common import EXTENSIONS, LABELS, SPLITS, read_csv, read_json, write_csv, write_json

ALIASES = {"train": "train", "val": "val", "valid": "val", "validation": "val",
           "threshold": "threshold", "selection": "selection", "test": "test"}
EXCLUDED_TEST = "excluded_old_test_group"


def load_rgb(path):
    # Pillow exposes 16-bit-per-channel RGB/RGBA PNGs as 8-bit RGB/RGBA, so
    # checking only Image.mode would silently discard sensor precision.
    with Path(path).open("rb") as stream:
        header = stream.read(29)
    if header[:8] == b"\x89PNG\r\n\x1a\n" and header[12:16] == b"IHDR" and len(header) > 24 and header[24] > 8:
        raise ValueError("16-bit PNG images require an explicit intensity conversion first; implicit precision loss is not allowed.")
    with Image.open(path) as raw:
        if raw.mode.startswith("I") or raw.mode == "F":
            raise ValueError("16-bit/float images require an explicit intensity conversion first.")
        if getattr(raw, "n_frames", 1) != 1:
            raise ValueError("Multi-frame images require explicit frame extraction before ingestion.")
        return ImageOps.exif_transpose(raw).convert("RGB")


def pixel_signature(path):
    """Hash oriented decoded RGB pixels, independent of filename and file format."""
    im = load_rgb(path)
    h = hashlib.sha256()
    h.update(str(im.size).encode())
    h.update(im.tobytes())
    gray = np.asarray(im.convert("L").resize((32, 32)), dtype=float)
    low = dctn(gray, norm="ortho")[:8, :8].ravel()
    bits = low > np.median(low[1:])
    ph = sum(int(bit) << i for i, bit in enumerate(bits))
    return h.hexdigest(), f"{ph:016x}", im.width, im.height


class UnionFind:
    def __init__(self, n):
        self.parent = list(range(n))

    def find(self, x):
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a, b):
        a, b = self.find(a), self.find(b)
        self.parent[max(a, b)] = min(a, b)


class BKTree:
    """Hamming-distance search with an optional shared work budget.

    A budget limits node visits, insertions, and candidate comparisons. Exhausting
    it stops the review search; exact duplicate and label checks are never limited.
    """
    def __init__(self):
        self.root = None

    @staticmethod
    def spend(budget):
        if budget is None:
            return True
        if budget[0] <= 0:
            return False
        budget[0] -= 1
        return True

    def add(self, value, idx, budget=None):
        if self.root is None:
            if not self.spend(budget):
                return False
            self.root = [value, [idx], {}]
            return True
        node = self.root
        while self.spend(budget):
            dist = (value ^ node[0]).bit_count()
            if dist == 0:
                node[1].append(idx)
                return True
            if dist not in node[2]:
                node[2][dist] = [value, [idx], {}]
                return True
            node = node[2][dist]
        return False

    def query(self, value, radius, budget=None):
        stack = [self.root] if self.root else []
        while stack and self.spend(budget):
            node = stack.pop()
            dist = (value ^ node[0]).bit_count()
            if dist <= radius:
                yield node[1], dist
            stack.extend(child for edge, child in node[2].items()
                         if dist - radius <= edge <= dist + radius)


def _class_directories(root):
    dirs = {}
    for sub in root.iterdir():
        if sub.is_dir() and sub.name.lower() in LABELS:
            label = sub.name.lower()
            if label in dirs:
                raise ValueError(f"Ambiguous class directories under {root}: duplicate '{label}'.")
            dirs[label] = sub
    return dirs


def discover(root):
    """Discover good/bad trees, class/split trees, or split/class trees."""
    root = Path(root).expanduser().resolve()
    if not root.is_dir():
        raise FileNotFoundError(f"Dataset folder not found: {root}")
    found = []
    class_dirs = _class_directories(root)
    split_dirs = sorted(p for p in root.iterdir() if p.is_dir() and p.name.lower() in ALIASES)
    if class_dirs and split_dirs:
        raise ValueError("Mixed class-first and split-first dataset layout. Use one layout only.")

    def add_images(folder, label, split=None):
        for path in sorted(folder.rglob("*")):
            if not path.is_file() or path.suffix.lower() not in EXTENSIONS:
                continue
            if not path.resolve().is_relative_to(root):
                raise ValueError(f"Image symlink leaves data_root: {path.relative_to(root)}")
            parts = path.relative_to(folder).parts
            hint = split if split is not None else (ALIASES.get(parts[0].lower(), "") if len(parts) > 1 else "")
            found.append((path, label, hint))

    if class_dirs:
        if set(class_dirs) != set(LABELS):
            raise ValueError("Dataset must contain both good and bad class directories.")
        for label in LABELS:
            add_images(class_dirs[label], label)
    else:
        for sub in split_dirs:
            for label, folder in sorted(_class_directories(sub).items()):
                add_images(folder, label, ALIASES[sub.name.lower()])
    if not found or set(x[1] for x in found) != set(LABELS):
        raise ValueError("Need both good and bad images under good/bad, class/split, or split/class directories.")
    if any(x[2] for x in found) and not all(x[2] for x in found):
        raise ValueError("Mixed split/unsplit structure. Put all images in one consistent layout.")
    return found


def _group_scheme(cfg):
    if cfg.get("groups_csv") and cfg.get("group_regex"):
        raise ValueError("Set groups_csv or group_regex, not both.")
    if cfg.get("groups_csv"):
        return {"method": "csv"}
    if cfg.get("group_regex"):
        return {"method": "regex", "pattern": cfg["group_regex"]}
    if cfg.get("grouping") == "tray_unit":
        return {"method": "tray_unit", "version": 1, "physical_unit_ids_available": True}
    return {"method": "pixel_hash", "physical_unit_ids_available": False}


def tray_unit_identity(filename):
    """Strict physical unit key independent of view, exposure, date and zero padding.

    Accepted examples: C0000083_Rc09_Cc17_* and C00000083_Rc01Cc02_*.
    The parser refuses missing or repeated coordinates instead of silently
    splitting correlated views as different examples.
    """
    name = Path(filename).name
    trays = re.findall(r"(?<![A-Za-z0-9])C(\d+)(?=[_\-.\s]|$)", name, re.I)
    rows = re.findall(r"(?<![A-Za-z])Rc(\d+)", name, re.I)
    cols = re.findall(r"(?<![A-Za-z])Cc(\d+)", name, re.I)
    if len(trays) != 1 or len(rows) != 1 or len(cols) != 1:
        raise ValueError("Filename must identify exactly one tray C<number>, row Rc<number> and column Cc<number>. Supply groups_csv for other naming schemes.")
    tray, row, column = int(trays[0]), int(rows[0]), int(cols[0])
    return {"tray": f"C{tray}", "row": row, "column": column,
            "unit_id": f"C{tray}:R{row}:C{column}"}


def _safe_relative(value):
    value = str(value).replace("\\", "/").strip()
    parts = PurePosixPath(value)
    if not value or parts.is_absolute() or ".." in parts.parts or ":" in value:
        raise ValueError(f"Expected a safe dataset-relative path: {value!r}")
    return parts.as_posix()


def _aliases(row):
    raw = row.get("group_aliases")
    if raw:
        result = json.loads(raw) if isinstance(raw, str) else raw
        if not isinstance(result, list) or not result or not all(isinstance(v, str) and v for v in result):
            raise ValueError("Invalid group_aliases in dataset manifest.")
        return set(result)
    return {row["group"]}


def _source_groups(row):
    raw = row.get("source_groups")
    if raw:
        return set(json.loads(raw) if isinstance(raw, str) else raw)
    return {row.get("source_group") or row["group"]}


def _near_review(records, cfg):
    radius = int(cfg.get("near_duplicate_distance", 2))
    cap = int(cfg.get("near_duplicate_report_limit", 10000))
    max_work = int(cfg.get("near_duplicate_comparison_limit", 200000))
    if not -1 <= radius <= 64 or cap < 0 or max_work < 0:
        raise ValueError("Near-duplicate distance must be -1..64; report and comparison limits must be nonnegative.")
    if radius < 0:
        return [], {"near_duplicate_search_enabled": False, "near_duplicate_search_complete": False,
                    "near_duplicate_report_capped": False, "near_duplicate_work_used": 0}
    tree, near, budget = BKTree(), [], [max_work]
    complete = True
    for i, row in enumerate(records):
        if len(near) >= cap or budget[0] <= 0:
            complete = False
            break
        value = int(row["phash"], 16)
        for indices, dist in tree.query(value, radius, budget):
            for j in indices:
                if len(near) >= cap or not tree.spend(budget):
                    complete = False
                    break
                other = records[j]
                if other["pixel_hash"] != row["pixel_hash"]:
                    near.append({"path_a": other["relative_path"], "path_b": row["relative_path"],
                                 "distance": dist, "group_a": other["group"], "group_b": row["group"]})
            if not complete:
                break
        if not complete or not tree.add(value, i, budget):
            complete = False
            break
    return near, {"near_duplicate_search_enabled": True, "near_duplicate_search_complete": complete,
                  "near_duplicate_report_capped": not complete and len(near) >= cap,
                  "near_duplicate_work_used": max_work - budget[0],
                  "near_duplicate_work_limit": max_work}


def audit(cfg, out):
    out = Path(out)
    root = Path(cfg["data_root"]).expanduser().resolve()
    scheme = _group_scheme(cfg)
    mappings = {}
    if cfg.get("groups_csv"):
        for row in read_csv(cfg["groups_csv"]):
            if "relative_path" not in row or "group" not in row:
                raise ValueError("groups_csv requires the columns relative_path and group.")
            rel = _safe_relative(row["relative_path"])
            if rel in mappings or not row.get("group", "").strip():
                raise ValueError(f"Duplicate or blank group mapping: {rel}")
            mappings[rel] = row["group"].strip()
        if not mappings:
            raise ValueError("groups_csv is empty; provide a group for every image.")
    pattern = re.compile(cfg["group_regex"]) if cfg.get("group_regex") else None
    if pattern and "group" not in pattern.groupindex:
        raise ValueError("group_regex must contain a named capture (?P<group>...).")
    resize = cfg.get("resize", "pad")
    if resize not in ("pad", "fit"):
        raise ValueError("resize must be 'pad' (native scale) or 'fit' (explicit scaling). Tiling is not implemented.")
    if cfg.get("preserve_native_resolution", False) and resize != "pad":
        raise ValueError("preserve_native_resolution requires resize=pad; no source pixels may be resampled.")
    requested_size = cfg.get("image_size", "auto")
    limit = cfg.get("image_size_limit", 4096)
    if isinstance(limit, bool) or not isinstance(limit, int) or limit < 32:
        raise ValueError("image_size_limit must be an integer >=32.")
    if requested_size != "auto" and (isinstance(requested_size, bool) or not isinstance(requested_size, int) or requested_size < 32):
        raise ValueError("image_size must be 'auto' or an integer >=32.")
    if requested_size != "auto" and requested_size > limit:
        raise ValueError(f"image_size={requested_size} exceeds image_size_limit={limit}. Raise the limit explicitly if required.")
    records, problems = [], []
    for i, (path, label, hint) in enumerate(discover(root)):
        rel = path.relative_to(root).as_posix()
        try:
            pixel, phash, width, height = pixel_signature(path)
            if requested_size != "auto" and resize == "pad" and max(width, height) > requested_size:
                raise ValueError(f"{width}x{height} exceeds image_size={requested_size}; increase it, use 'auto', or explicitly set resize: fit.")
            if mappings:
                if rel not in mappings:
                    raise ValueError("Image missing from groups_csv (mapping must cover every image).")
                group = mappings[rel]
            elif pattern:
                match = pattern.search(rel)
                if not match or not match.group("group") or not match.group("group").strip():
                    raise ValueError("group_regex did not produce a nonempty group for this image.")
                group = match.group("group").strip()
            elif scheme["method"] == "tray_unit":
                group = tray_unit_identity(path.name)["unit_id"]
            else:
                group = "pixel:" + pixel
            identity = tray_unit_identity(path.name) if scheme["method"] == "tray_unit" else {}
            records.append({"path": str(path.resolve()), "relative_path": rel, "label": LABELS[label],
                            "class_name": label, "pixel_hash": pixel, "phash": phash,
                            "width": width, "height": height, "group": group,
                            "source_group": group, "split_hint": hint, **identity})
        except Exception as e:
            problems.append({"relative_path": rel, "error": str(e)})
        if (i + 1) % 250 == 0:
            print(f"Audit: {i + 1} images", flush=True)
    write_csv(out / "unreadable_or_invalid.csv", problems, ["relative_path", "error"])
    if problems:
        raise ValueError(f"{len(problems)} invalid images or mappings; inspect {out / 'unreadable_or_invalid.csv'}")
    resolved_size = max(32, max(max(r["width"], r["height"]) for r in records)) if requested_size == "auto" else requested_size
    # Patch-embedding stems in Swin/ConvNeXt use stride-4 convolutions without
    # input padding. Their later stages also downsample. Extend only the outer
    # canvas to a multiple of 32 so arbitrary native edge pixels are represented
    # rather than falling outside a final complete patch. One shared canvas is
    # used by EVERY candidate in this run; image pixels are never resampled.
    alignment = 32 if cfg.get("preserve_native_resolution", False) and any(
        name in ("convnext_tiny", "swin_t") for name in cfg.get("models", [])) else 1
    resolved_size = ((resolved_size + alignment - 1) // alignment) * alignment
    if resolved_size > limit:
        raise ValueError(f"Resolved image_size={resolved_size} (canvas alignment {alignment}) exceeds image_size_limit={limit}. Raise the limit explicitly. Images were not resized or cropped.")
    cfg["image_size"] = resolved_size
    cfg["image_size_requested"] = requested_size
    cfg["canvas_alignment"] = alignment

    uf = UnionFind(len(records))
    hash_first, group_first, hash_sources = {}, {}, defaultdict(set)
    duplicates, conflicts = [], []
    for i, row in enumerate(records):
        hash_sources[row["pixel_hash"]].add(row["source_group"])
        for field, seen in (("pixel_hash", hash_first), ("group", group_first)):
            key = row[field]
            if key in seen:
                uf.union(i, seen[key])
            else:
                seen[key] = i
        first = hash_first[row["pixel_hash"]]
        if first != i:
            other = records[first]
            report = {"path_a": other["relative_path"], "path_b": row["relative_path"],
                      "label_a": other["class_name"], "label_b": row["class_name"]}
            duplicates.append(report)
            if other["label"] != row["label"]:
                conflicts.append(report)
    write_csv(out / "exact_duplicates.csv", duplicates, ["path_a", "path_b", "label_a", "label_b"])
    write_csv(out / "label_conflicts.csv", conflicts, ["path_a", "path_b", "label_a", "label_b"])
    if conflicts:
        raise ValueError("Identical decoded pixels have both good and bad labels. Correct label_conflicts.csv first.")

    components = defaultdict(list)
    for i in range(len(records)):
        components[uf.find(i)].append(i)
    for indices in components.values():
        names = sorted({records[i]["source_group"] for i in indices})
        hints = {records[i]["split_hint"] for i in indices if records[i]["split_hint"]}
        if len(hints) > 1:
            raise ValueError(f"Same unit or identical image appears in different existing splits: {names[:3]}")
        for i in indices:
            records[i]["group"] = names[0]
            records[i]["group_aliases"] = json.dumps(names, ensure_ascii=False)
            records[i]["source_groups"] = json.dumps(sorted(hash_sources[records[i]["pixel_hash"]]), ensure_ascii=False)

    # Perceptual similarity is a bounded REVIEW hint, never a deletion or union rule.
    near, near_status = _near_review(records, cfg)
    write_csv(out / "near_duplicates_review.csv", near,
              ["path_a", "path_b", "distance", "group_a", "group_b"])
    write_csv(out / "all_images.csv", records)
    unique = [row for i, row in enumerate(records) if hash_first[row["pixel_hash"]] == i]
    write_csv(out / "groups_template.csv",
              [{"relative_path": r["relative_path"], "group": r["source_group"]} for r in records])
    write_json(out / "audit_summary.json", {
        "n_original_images": len(records), "n_unique_images": len(unique),
        "n_groups": len(set(r["group"] for r in unique)),
        "class_counts": dict(Counter(r["class_name"] for r in unique)),
        "class_group_counts": {label: len({r["group"] for r in unique if r["class_name"] == label}) for label in LABELS},
        "group_source": "csv" if mappings else "regex" if pattern else "tray_unit" if scheme["method"] == "tray_unit" else "unique image (unit IDs unavailable)",
        "grouping_scheme": scheme, "image_size_requested": requested_size, "image_size_resolved": resolved_size,
        "canvas_alignment": alignment,
        "canvas_note": "Whole native RGB image, centered padding only; patch-model canvas aligned to 32 when selected with native preservation.",
        "native_width_range": [min(r["width"] for r in unique), max(r["width"] for r in unique)],
        "native_height_range": [min(r["height"] for r in unique), max(r["height"] for r in unique)],
        "near_duplicate_rows": len(near), **near_status,
        "unused_group_mapping_rows": len(set(mappings) - {r["relative_path"] for r in records}),
        "notes": ["Near duplicates are reported, never silently deleted or merged.",
                  "Without physical unit IDs, distinct views of the same unit may leak across splits; supply groups_csv or group_regex.",
                  "Matching perceptual hashes alone does not establish image identity or label correctness."]})
    return unique


def _group_counts(records):
    groups = defaultdict(list)
    for row in records:
        if int(row["label"]) not in (0, 1) or not row.get("group"):
            raise ValueError("Every image requires label bad=0 or good=1 and a nonempty group.")
        groups[row["group"]].append(row)
    keys = sorted(groups)
    counts = np.array([[sum(int(r["label"]) == c for r in groups[g]) for c in (0, 1)] for g in keys], dtype=np.int64)
    return groups, keys, counts


def allocate(records, fractions, seed):
    """Deterministic grouped stratification, with guaranteed binary-class coverage.

    Mixed-label physical units remain atomic. A coverage seed is assigned to every
    partition before greedily allocating remaining units. Multiple bounded trials
    reduce imbalance without relying on random split luck for rare classes.
    """
    if not records or not fractions or any(not math.isfinite(v) or v <= 0 for v in fractions.values()):
        raise ValueError("Grouped partitioning requires data and positive finite split fractions.")
    keys = list(fractions)
    p = np.array(list(fractions.values()), dtype=float)
    p /= p.sum()
    grouped, names, counts = _group_counts(records)
    k = len(keys)
    support = (counts > 0).sum(axis=0)
    if len(names) < k or np.any(support < k):
        raise ValueError(f"Cannot create {k} grouped splits with both classes: {len(names)} independent groups, {int(support[0])} containing bad and {int(support[1])} containing good. Each class needs at least {k} distinct groups. Add independent labeled units or supply a valid split layout; do not divide one unit between splits.")
    totals = counts.sum(axis=0)
    target = p[:, None] * totals[None, :]
    denom = np.maximum(p[:, None] * totals[None, :] ** 2, 1.0)
    mixed = np.flatnonzero((counts > 0).all(axis=1))
    pure = [np.flatnonzero((counts[:, c] > 0) & (counts[:, 1-c] == 0)) for c in (0, 1)]
    rng = np.random.default_rng(seed)
    best, best_error = None, float("inf")
    n_trials = min(32, max(4, 20000 // max(len(names), 1)))
    for trial in range(n_trials):
        assignment = np.full(len(names), -1, dtype=np.int64)
        achieved = np.zeros((k, 2), dtype=np.int64)
        # Small coverage seeds preserve capacity for larger units. Randomized size
        # priorities allow alternatives when indivisible units distort ratios.
        def ordered(indices):
            if not len(indices):
                return []
            jitter = rng.uniform(.75, 1.25, len(indices)) if trial else np.ones(len(indices))
            return list(indices[np.argsort(counts[indices].sum(axis=1) * jitter, kind="stable")])
        mixed_order, pure_order = ordered(mixed), [ordered(x) for x in pure]
        slots = list(np.argsort(p, kind="stable")) if trial == 0 else list(rng.permutation(k))
        for pos, s in enumerate(slots):
            chosen = [mixed_order[pos]] if pos < min(len(mixed_order), k) else [pure_order[0].pop(0), pure_order[1].pop(0)]
            for g in chosen:
                assignment[g] = s
                achieved[s] += counts[g]
        remaining = np.flatnonzero(assignment < 0)
        jitter = rng.uniform(.9, 1.1, len(remaining)) if trial else np.ones(len(remaining))
        order = remaining[np.argsort(-np.sum(counts[remaining] / np.maximum(totals, 1), axis=1) * jitter, kind="stable")]
        for g in order:
            delta = np.sum(((achieved + counts[g] - target) ** 2 - (achieved - target) ** 2) / denom, axis=1)
            s = int(np.argmin(delta))
            assignment[g] = s
            achieved[s] += counts[g]
        error = float(np.sum((achieved - target) ** 2 / denom))
        if error < best_error:
            best, best_error = assignment.copy(), error
    result = []
    for i, name in enumerate(names):
        result.extend(dict(row, split=keys[int(best[i])]) for row in grouped[name])
    return result


def _manifest_fingerprint(rows):
    canonical = sorted((r["pixel_hash"], int(r["label"]), r["group"], r["split"],
                        sorted(_aliases(r)), sorted(_source_groups(r))) for r in rows)
    return hashlib.sha256(json.dumps(canonical, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()


def _validate_manifest(rows, require_all=True):
    group_splits, hash_splits, seen = defaultdict(set), defaultdict(set), {}
    for row in rows:
        split = row.get("split")
        if split not in (*SPLITS, EXCLUDED_TEST):
            raise ValueError(f"Unknown manifest split: {split}")
        if row["pixel_hash"] in seen:
            raise ValueError("Manifest contains duplicate decoded image hashes; run the dataset audit before partitioning.")
        seen[row["pixel_hash"]] = row
        protected = "test" if split == EXCLUDED_TEST else split
        group_splits[row["group"]].add(protected)
        for alias in _aliases(row):
            group_splits[alias].add(protected)
        hash_splits[row["pixel_hash"]].add(protected)
    if any(len(v) != 1 for v in group_splits.values()) or any(len(v) != 1 for v in hash_splits.values()):
        raise ValueError("Group leakage detected: one physical unit or duplicate image crosses dataset partitions.")
    if require_all:
        for split in SPLITS:
            if {int(r["label"]) for r in rows if r["split"] == split} != {0, 1}:
                raise ValueError(f"Split '{split}' must contain both classes. Add independent good and bad units to that partition.")


def _incremental(cfg, records, previous):
    previous = Path(previous)
    old_cfg = read_json(previous / "config.json")
    if old_cfg["task"] != cfg["task"]:
        raise ValueError("Cannot mix top/bottom/vig when updating a run.")
    if _group_scheme(old_cfg) != _group_scheme(cfg):
        raise ValueError("Grouping method or group_regex changed from the previous run. Keep the original unit-ID extraction for incremental updates, or create a new dataset lineage with a fresh independent test.")
    old = read_manifest(previous / "manifest.csv")
    _validate_manifest(old)
    old_summary = previous / "split_summary.json"
    if old_summary.exists():
        expected = read_json(old_summary).get("_metadata", {}).get("manifest_fingerprint")
        if expected and expected != _manifest_fingerprint(old):
            raise ValueError("Previous manifest integrity check failed. Restore its original manifest before updating.")
    hashes = {r["pixel_hash"]: r for r in old}
    current = {r["pixel_hash"]: r for r in records}
    if missing := set(hashes) - set(current):
        raise ValueError(f"Update is missing {len(missing)} old unique images. Use OLD + NEW labeled data together.")
    for pixel, old_row in hashes.items():
        row = current[pixel]
        if int(old_row["label"]) != int(row["label"]):
            raise ValueError("An old label changed. Re-labeling requires a new dataset lineage and fresh independent test, not incremental reuse.")
        if not _source_groups(old_row).issubset(_source_groups(row)):
            raise ValueError(f"Physical unit mapping changed for old image '{old_row['relative_path']}'. Preserve the original group IDs; changing them can leak held-out units into training.")

    # Join current components through all historical aliases. This preserves
    # physical identity even when a pixel duplicate connected multiple IDs.
    alias_old = {}
    for row in old:
        for alias in _aliases(row) | {row["group"]}:
            alias_old[alias] = row["group"]
    uf = UnionFind(len(records))
    identifiers = {}
    for i, row in enumerate(records):
        aliases = _aliases(row) | {row["group"]}
        ids = {("current", a) for a in aliases}
        ids |= {("old", alias_old[a]) for a in aliases if a in alias_old}
        if row["pixel_hash"] in hashes:
            ids.add(("old", hashes[row["pixel_hash"]]["group"]))
        for ident in ids:
            if ident in identifiers:
                uf.union(i, identifiers[ident])
            else:
                identifiers[ident] = i
    components = defaultdict(list)
    for i, row in enumerate(records):
        components[uf.find(i)].append(row)
    inherited, unassigned = [], []
    for rows in components.values():
        predecessors = [hashes[r["pixel_hash"]] for r in rows if r["pixel_hash"] in hashes]
        old_splits = {"test" if r["split"] == EXCLUDED_TEST else r["split"] for r in predecessors}
        if len(old_splits) > 1:
            raise ValueError("Current group mapping joins old splits. Resolve the unit mapping and create a new dataset lineage.")
        aliases = set().union(*(_aliases(r) for r in rows), *(_aliases(r) for r in predecessors))
        name = min(r["group"] for r in predecessors) if predecessors else min(aliases)
        for row in rows:
            row = dict(row, group=name, group_aliases=json.dumps(sorted(aliases), ensure_ascii=False))
            if old_splits:
                split = next(iter(old_splits))
                if row["pixel_hash"] in hashes:
                    split = hashes[row["pixel_hash"]]["split"]
                elif split == "test":
                    split = EXCLUDED_TEST
                inherited.append(dict(row, split=split))
            else:
                unassigned.append(row)
    # New independent groups enter development only. Allocate toward deficits,
    # retaining every existing partition and the frozen test-image identity set.
    development = [s for s in SPLITS if s != "test"]
    achieved = np.array([[sum(int(r["label"]) == c and r["split"] == s for r in inherited) for c in (0, 1)] for s in development])
    totals = achieved.sum(axis=0) + np.array([sum(int(r["label"]) == c for r in unassigned) for c in (0, 1)])
    p = np.array([cfg["split_fractions"][s] for s in development], dtype=float)
    p /= p.sum()
    target, denom = p[:, None] * totals, np.maximum(p[:, None] * totals ** 2, 1.0)
    rng = np.random.default_rng(cfg["split_seed"])
    if unassigned:
        grouped, names, counts = _group_counts(unassigned)
        order = np.argsort(-counts.sum(axis=1) * rng.uniform(.9, 1.1, len(names)), kind="stable")
        for g in order:
            hints = {r.get("split_hint", "") for r in grouped[names[g]]} - {""}
            if "test" in hints:
                raise ValueError("New independent images cannot be added to an existing frozen test. Use a separate external evaluation set.")
            allowed = [i for i, s in enumerate(development) if not hints or hints == {s} or (hints == {"val"} and s in ("val", "threshold", "selection"))]
            if not allowed:
                raise ValueError("New group has conflicting supplied development split hints.")
            delta = np.sum(((achieved + counts[g] - target) ** 2 - (achieved - target) ** 2) / denom, axis=1)
            chosen = min(allowed, key=lambda i: (delta[i], i))
            achieved[chosen] += counts[g]
            inherited.extend(dict(r, split=development[chosen]) for r in grouped[names[g]])
    for row in inherited:
        hint, split = row.get("split_hint", ""), row["split"]
        compatible = not hint or hint == split or (hint == "val" and split in ("threshold", "selection")) or (hint == "test" and split == EXCLUDED_TEST)
        if not compatible:
            raise ValueError("Existing folder split conflicts with the previous manifest.")
    return inherited, _manifest_fingerprint(old)


def make_manifest(cfg, records, out):
    if not records:
        raise ValueError("No audited dataset records are available.")
    # Callers cannot bypass duplicate identity protection by supplying raw rows.
    if len({r["pixel_hash"] for r in records}) != len(records):
        raise ValueError("Records contain duplicate decoded image hashes. Run audit before make_manifest.")
    previous = cfg.get("previous_run")
    parent_fingerprint = None
    if previous:
        result, parent_fingerprint = _incremental(cfg, records, previous)
    elif all(r.get("split_hint") for r in records):
        hints = {r["split_hint"] for r in records}
        if hints == {"train", "val", "test"}:
            dev = [r for r in records if r["split_hint"] == "val"]
            f = {k: cfg["split_fractions"][k] for k in ("val", "threshold", "selection")}
            result = allocate(dev, f, cfg["split_seed"])
            result += [dict(r, split=r["split_hint"]) for r in records if r["split_hint"] != "val"]
        elif hints == set(SPLITS):
            result = [dict(r, split=r["split_hint"]) for r in records]
        else:
            raise ValueError("Existing splits must be train/val/test, or all five train/val/threshold/selection/test.")
    elif any(r.get("split_hint") for r in records):
        raise ValueError("Mixed split/unsplit records cannot be partitioned safely.")
    else:
        result = allocate(records, cfg["split_fractions"], cfg["split_seed"])
    _validate_manifest(result)
    result.sort(key=lambda r: (r["split"], r["relative_path"]))
    write_csv(Path(out) / "manifest.csv", result)
    summary = {
        split: {"images": dict(Counter(r["class_name"] for r in result if r["split"] == split)),
                "groups": len({r["group"] for r in result if r["split"] == split}),
                "class_groups": {label: len({r["group"] for r in result if r["split"] == split and r["class_name"] == label}) for label in LABELS}}
        for split in SPLITS}
    # Show whether a weak result is concentrated in one acquisition tray. This
    # is descriptive accounting only: group allocation never optimizes metrics
    # or moves correlated views into different partitions to balance a tray.
    tray_rows = []
    for split in SPLITS:
        by_tray = {}
        for tray in sorted({r.get("tray", "") for r in result if r.get("tray")}):
            subset = [r for r in result if r["split"] == split and r.get("tray") == tray]
            counts = {label: sum(r["class_name"] == label for r in subset) for label in LABELS}
            by_tray[tray] = {"images": counts, "groups": len({r["group"] for r in subset})}
            tray_rows.append({"tray": tray, "split": split, "bad_images": counts["bad"],
                              "good_images": counts["good"], "groups": by_tray[tray]["groups"]})
        if by_tray:
            summary[split]["trays"] = by_tray
    if tray_rows:
        write_csv(Path(out) / "tray_split_summary.csv", tray_rows,
                  ["tray", "split", "bad_images", "good_images", "groups"])
    summary["_metadata"] = {"manifest_fingerprint": _manifest_fingerprint(result),
                            "parent_manifest_fingerprint": parent_fingerprint,
                            "grouping_scheme": _group_scheme(cfg),
                            "dataset_version": cfg.get("dataset_version", "unspecified"),
                            "excluded_old_test_group_images": sum(r["split"] == EXCLUDED_TEST for r in result),
                            "allocation": "grouped, class-coverage constrained, approximate stratification",
                            "test_identity_frozen_from_parent": bool(previous)}
    write_json(Path(out) / "split_summary.json", summary)
    return result


def read_manifest(path):
    rows = read_csv(path)
    for row in rows:
        row["label"] = int(row["label"])
        for key in ("width", "height", "row", "column"):
            if key in row and row[key] != "":
                row[key] = int(row[key])
        row["relative_path"] = _safe_relative(row["relative_path"])
    return rows
