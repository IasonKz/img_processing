"""Inspectable interrupted checkpoints and explicitly provisional inference."""
from __future__ import annotations

import math
from pathlib import Path
import shutil

from .common import DEFAULTS, EXTENSIONS, merge_dict, read_json, sha_file, write_csv, write_json


def list_partial_checkpoints(run):
    run = Path(run).resolve()
    records = []
    for path in sorted(run.glob("search/*/trial_*/partial.json")):
        try:
            record = read_json(path)
            checkpoint = path.parent / record.get("checkpoint", "partial.pt")
            valid = (record.get("usable_for_inference", False) and checkpoint.is_file()
                     and sha_file(checkpoint) == record.get("checkpoint_sha256"))
            records.append({**record, "model": path.parent.parent.name,
                            "trial_directory": path.parent.name,
                            "checkpoint": checkpoint.relative_to(run).as_posix() if valid else None,
                            "metadata": path.relative_to(run).as_posix(), "integrity_verified": bool(valid)})
        except (OSError, ValueError):
            continue
    return records


def classify_partial(checkpoint, input_dir, output_dir, device="cpu", threshold=.5):
    """Classify from partial.pt; every copied image remains in human_review.

    This command intentionally does not write selected.json or qualifying
    metrics. It accepts a committed partial checkpoint only, never an Optuna
    trial's final score, and uses the checkpoint's original input semantics.
    """
    from .engine import torch_modules, predict_checkpoint
    checkpoint = Path(checkpoint).resolve()
    input_dir, output_dir = Path(input_dir).resolve(), Path(output_dir).resolve()
    if not math.isfinite(float(threshold)) or float(threshold) < 0:
        raise ValueError("Threshold must be finite and nonnegative.")
    if not input_dir.is_dir():
        raise FileNotFoundError(f"Input folder not found: {input_dir}")
    if output_dir.is_relative_to(input_dir) or input_dir.is_relative_to(output_dir):
        raise ValueError("Choose an output folder separate from the input tree.")
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError("Choose a new or empty diagnostic output folder.")
    torch, _ = torch_modules()
    saved = torch.load(checkpoint, map_location="cpu", weights_only=True)
    if not saved.get("partial") or not saved.get("partial_inference_only"):
        raise ValueError("This command requires an explicitly saved partial.pt checkpoint.")
    if saved.get("kind") != "patchcore" and float(threshold) > 1:
        raise ValueError("Supervised bad-score thresholds must be between 0 and 1.")
    metadata_file = checkpoint.with_suffix(".json")
    if not metadata_file.is_file():
        raise ValueError("Keep partial.json alongside partial.pt so its committed checksum can be verified.")
    metadata = read_json(metadata_file)
    if not metadata.get("usable_for_inference") or sha_file(checkpoint) != metadata.get("checkpoint_sha256"):
        raise ValueError("Partial checkpoint integrity verification failed.")
    cfg = merge_dict(DEFAULTS, saved.get("model_config", {}))
    cfg.update(task=saved["task"], image_size=saved["image_size"], device=device, num_workers=0)
    rows = [{"path": str(path), "relative_path": path.relative_to(input_dir).as_posix()}
            for path in sorted(input_dir.rglob("*")) if path.is_file() and path.suffix.lower() in EXTENSIONS]
    if not rows:
        raise ValueError("No supported images found in the input folder.")
    scores, seconds = predict_checkpoint(checkpoint, rows, cfg)
    output_dir.mkdir(parents=True, exist_ok=True)
    review_dir = output_dir / "human_review"
    review_dir.mkdir(exist_ok=True)
    result = []
    for index, (row, score) in enumerate(zip(rows, scores)):
        relative_copy = Path("human_review") / f"{index:06d}__{Path(row['path']).name}"
        shutil.copy2(row["path"], output_dir / relative_copy)
        result.append({**row, "bad_score": float(score), "threshold": float(threshold),
                       "provisional_prediction": "bad" if float(score) >= threshold else "good",
                       "decision": "human_review", "review_required": True,
                       "model_status": "PARTIAL_UNVALIDATED", "operator_label": "",
                       "copied_path": relative_copy.as_posix()})
    write_csv(output_dir / "predictions.csv", result)
    summary = {"status": "PARTIAL_UNVALIDATED", "checkpoint": str(checkpoint),
               "checkpoint_sha256": sha_file(checkpoint), "n_images": len(result),
               "threshold": float(threshold), "seconds": seconds, "review_required": True,
               "note": "Diagnostic predictions only. Scores from unfinished training have not been calibrated or qualified."}
    write_json(output_dir / "prediction_summary.json", summary)
    return summary
