from __future__ import annotations

from collections import defaultdict
from pathlib import Path
import re

import numpy as np

from .common import LOG, UnionFind, file_sha256, output_dir, read_csv, write_csv, write_json
from .images import load_image, input_hash, image_qc, perceptual_signature


def audit(cfg: dict) -> tuple[list[dict], dict]:
    root = Path(cfg["paths"]["dataset_root"])
    report = output_dir(cfg) / "audit"
    report.mkdir(parents=True, exist_ok=True)
    if not root.is_dir():
        raise ValueError(f"Dataset folder does not exist: {root}")
    metadata: dict = {}
    meta_path = cfg["paths"].get("metadata_csv")
    if meta_path:
        for entry in read_csv(Path(meta_path)):
            if "relpath" not in entry:
                raise ValueError("Metadata needs a relpath column, e.g. good/part_001.png")
            rel = entry["relpath"].strip().replace("\\", "/")
            if rel in metadata:
                raise ValueError(f"Duplicate relpath in metadata: {rel}")
            metadata[rel] = entry
    regex = re.compile(cfg["data"]["group_regex"]) if cfg["data"].get("group_regex") else None
    valid, invalid, ignored = [], [], []
    thumbs, phashes = [], []
    extensions = {s.lower() for s in cfg["data"]["extensions"]}
    for semantic, label in (("good", 0), ("bad", 1)):
        sub = root / cfg["data"][semantic + "_folder"]
        if not sub.is_dir():
            raise ValueError(f"Missing class folder: {sub}. Input must contain good/ and bad/ (not train/val/)")
        files = sorted(sub.rglob("*") if cfg["data"].get("recursive", True) else sub.glob("*"))
        for path in files:
            if not path.is_file():
                continue
            if path.suffix.lower() not in extensions:
                ignored.append({"path": str(path), "reason": "UNSUPPORTED_EXTENSION"})
                continue
            if path.is_symlink() or root.resolve() not in path.resolve().parents:
                invalid.append({"path": str(path), "reason": "SYMLINK_OR_OUTSIDE_DATASET"})
                continue
            rel = path.relative_to(root).as_posix()
            try:
                image, native_hash = load_image(path, cfg["data"])
                qc, issues = image_qc(image, cfg["data"].get("qc", {}))
                if issues:
                    raise ValueError("QC:" + ";".join(issues))
                phash, thumb = perceptual_signature(image)
                row = {"sample_id": "img_" + f"{len(valid):07d}", "path": str(path.resolve()), "relpath": rel,
                       "label": label, "class_name": semantic, "width": image.width, "height": image.height,
                       "file_sha256": file_sha256(path), "pixel_sha256": native_hash,
                       "input_sha256": input_hash(image), "phash": f"{phash:016x}", **qc,
                       "unit_id": "", "tray_id": "", "batch_id": "", "requested_split": "", "keep": True}
                if regex:
                    match = regex.search(path.stem)
                    if not match:
                        raise ValueError(f"group_regex did not match {path.name}")
                    groups = match.groupdict()
                    if not groups:
                        raise ValueError("group_regex must use named groups, e.g. (?P<unit_id>...)")
                    for key in ("unit_id", "tray_id", "batch_id"):
                        row[key] = groups.get(key, "") or ""
                if meta_path:
                    if rel not in metadata:
                        raise ValueError(f"Missing metadata for {rel}")
                    for key in ("unit_id", "tray_id", "batch_id"):
                        row[key] = metadata[rel].get(key, "").strip()
                    row["requested_split"] = metadata[rel].get("split", "").strip()
                valid.append(row)
                thumbs.append(thumb)
                phashes.append(phash)
            except Exception as exc:
                invalid.append({"path": str(path), "reason": f"{type(exc).__name__}: {exc}"})
            if (len(valid) + len(invalid)) % 250 == 0:
                LOG.info("Audit: %s readable, %s invalid", len(valid), len(invalid))
    if not valid:
        write_csv(report / "invalid_images.csv", invalid, ["path", "reason"])
        raise ValueError("No valid images. See audit/invalid_images.csv")
    uf = UnionFind(len(valid))
    duplicates, conflicts, same_names, near_rows = [], [], [], []
    buckets = defaultdict(list)
    for i, row in enumerate(valid):
        # RGB input collisions matter even when source TIFF precision differs.
        buckets[row["input_sha256"]].append(i)
    for indices in buckets.values():
        if len(indices) < 2:
            continue
        first = indices[0]
        for i in indices[1:]:
            uf.union(first, i)
            record = {"a": valid[first]["relpath"], "b": valid[i]["relpath"],
                      "same_file_bytes": valid[first]["file_sha256"] == valid[i]["file_sha256"],
                      "same_native_pixels": valid[first]["pixel_sha256"] == valid[i]["pixel_sha256"],
                      "same_model_input": True, "cross_label": valid[first]["label"] != valid[i]["label"]}
            if record["cross_label"]:
                conflicts.append(record)
            else:
                duplicates.append(record)
                if cfg["audit"]["deduplicate_same_class"]:
                    valid[i]["keep"] = False
    names = defaultdict(list)
    for row in valid:
        names[Path(row["path"]).name.casefold()].append(row)
    for name, rows in names.items():
        if len(rows) > 1:
            same_names.append({"filename": name, "count": len(rows), "paths": " | ".join(r["relpath"] for r in rows)})

    group_by = cfg["data"].get("group_by", "auto")
    if group_by == "auto":
        group_by = "unit_id" if all(row["unit_id"] for row in valid) else "image"
    if group_by != "image" and not all(row[group_by] for row in valid):
        raise ValueError(f"group_by={group_by} requires a nonempty value for EVERY valid image")
    groups = {}
    for i, row in enumerate(valid):
        if group_by == "image":
            key = f"image:{i}"
        elif group_by == "unit_id":
            key = f"{row['batch_id']}::{row['tray_id']}::{row['unit_id']}"
        elif group_by == "tray_id":
            key = f"{row['batch_id']}::{row['tray_id']}"
        else:
            key = row["batch_id"]
        row["physical_group"] = key
        if key in groups:
            uf.union(groups[key], i)
        else:
            groups[key] = i

    near = cfg["audit"]["near_duplicates"]
    total_candidates, total_near = 0, 0
    near_complete = True
    if near["enabled"]:
        hashes = np.array(phashes, dtype=np.uint64)
        lookup = np.array([v.bit_count() for v in range(256)], dtype=np.uint8)
        thumbnails = np.stack(thumbs).reshape(len(thumbs), -1).astype(np.float32)
        for i in range(1, len(valid)):
            xor = np.bitwise_xor(hashes[:i], hashes[i])
            distance = lookup[xor.view(np.uint8).reshape(-1, 8)].sum(axis=1)
            candidates = np.flatnonzero(distance <= int(near["hamming_radius"]))
            # Skip identical model inputs already handled above.
            candidates = np.array([j for j in candidates if valid[j]["input_sha256"] != valid[i]["input_sha256"]], dtype=int)
            total_candidates += len(candidates)
            if total_candidates > int(near["max_candidate_pairs"]):
                near_complete = False
                break
            if not len(candidates):
                continue
            errors = np.sqrt(np.mean((thumbnails[candidates] - thumbnails[i])**2, axis=1))
            for j, rmse in zip(candidates, errors):
                if rmse > float(near["max_thumbnail_rmse"]):
                    continue
                total_near += 1
                if near["group_candidates"]:
                    uf.union(int(j), i)
                if len(near_rows) < int(near["max_report_pairs"]):
                    near_rows.append({"a": valid[int(j)]["relpath"], "b": valid[i]["relpath"],
                                      "hamming_distance": int(distance[j]), "thumbnail_rmse": float(rmse),
                                      "cross_label": valid[int(j)]["label"] != valid[i]["label"]})
    for i, row in enumerate(valid):
        row["group_id"] = f"g{uf.find(i):07d}"
    # All duplicate/physical links are retained even when redundant files are excluded.
    fatal = []
    if conflicts:
        fatal.append("IDENTICAL_INPUT_WITH_CONFLICTING_LABELS")
    if invalid and (cfg["audit"]["corrupt_policy"] == "stop" or meta_path or regex):
        fatal.append("INVALID_IMAGES_OR_METADATA")
    if not near_complete:
        fatal.append("NEAR_DUPLICATE_AUDIT_INCOMPLETE")
    if cfg["split"].get("require_physical_groups") and group_by == "image":
        fatal.append("PHYSICAL_GROUPS_REQUIRED")
    # Explicit split conflicts must not disappear when a duplicate is deduplicated.
    requested = defaultdict(set)
    for row in valid:
        if row["requested_split"]:
            requested[row["group_id"]].add(row["requested_split"])
    if any(len(s) > 1 for s in requested.values()):
        fatal.append("LINKED_IMAGES_ASSIGNED_TO_DIFFERENT_SPLITS")
    for row in valid:
        if len(requested[row["group_id"]]) == 1:
            row["requested_split"] = next(iter(requested[row["group_id"]]))
    warnings = []
    if group_by == "image":
        warnings.append("IMAGE_LEVEL_ONLY: unit/tray leakage cannot be ruled out; supply metadata or group_regex")
    if not near["enabled"] or not near["group_candidates"]:
        warnings.append("NEAR_DUPLICATE_GROUPING_DISABLED: near-copy leakage is not excluded")
    if group_by in {"image", "unit_id"}:
        warnings.append("No guarantee of held-out production trays/batches. Test on a genuinely new tray later")
    if total_near:
        warnings.append("Near-duplicates are candidates, not proof: a tiny real defect can change the true label")
    kept = [row for row in valid if row["keep"]]
    summary = {"valid_files": len(valid), "unique_inputs_retained": len(kept), "invalid_files": len(invalid),
               "conflicting_inputs": len(conflicts), "same_class_duplicates": len(duplicates),
               "same_filenames": len(same_names), "near_pairs": total_near, "near_candidates_checked": total_candidates,
               "near_complete": near_complete, "grouping": group_by, "groups": len({r['group_id'] for r in kept}),
               "class_counts": {c: sum(r["label"] == y for r in kept) for c, y in (("good", 0), ("bad", 1))},
               "warnings": warnings, "fatal_errors": fatal, "passed": not fatal}
    write_csv(report / "manifest_audit.csv", valid)
    write_csv(report / "duplicates.csv", duplicates, ["a", "b", "same_file_bytes", "same_native_pixels", "same_model_input", "cross_label"])
    write_csv(report / "conflicts.csv", conflicts, ["a", "b", "same_file_bytes", "same_native_pixels", "same_model_input", "cross_label"])
    write_csv(report / "near_duplicates.csv", near_rows, ["a", "b", "hamming_distance", "thumbnail_rmse", "cross_label"])
    write_csv(report / "same_filenames.csv", same_names, ["filename", "count", "paths"])
    write_csv(report / "invalid_images.csv", invalid, ["path", "reason"])
    write_csv(report / "ignored_files.csv", ignored, ["path", "reason"])
    write_csv(report / "metadata_template.csv", [{"relpath": r["relpath"], "unit_id": r["unit_id"], "tray_id": r["tray_id"],
                                                  "batch_id": r["batch_id"], "split": r["requested_split"]} for r in valid],
              ["relpath", "unit_id", "tray_id", "batch_id", "split"])
    write_json(report / "audit_summary.json", summary)
    for warning in warnings:
        LOG.warning(warning)
    LOG.info("Audit: %s", summary)
    return kept, summary
