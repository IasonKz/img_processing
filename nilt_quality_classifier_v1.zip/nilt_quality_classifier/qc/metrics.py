from __future__ import annotations

import math
import shutil
from pathlib import Path
from typing import Any, Iterable, Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    confusion_matrix,
    precision_recall_curve,
    precision_recall_fscore_support,
    roc_auc_score,
    roc_curve,
)

from .constants import INDEX_TO_LABEL
from .utils import write_json


def _safe_divide(numerator: float, denominator: float) -> float:
    return float(numerator / denominator) if denominator else float("nan")


def binary_metrics(
    y_true: Sequence[int] | np.ndarray,
    p_bad: Sequence[float] | np.ndarray,
    *,
    threshold: float,
) -> dict[str, Any]:
    y_true_array = np.asarray(y_true, dtype=np.int64)
    p_bad_array = np.asarray(p_bad, dtype=np.float64)
    if y_true_array.shape[0] != p_bad_array.shape[0]:
        raise ValueError("y_true and p_bad have different lengths")
    if y_true_array.size == 0:
        raise ValueError("Cannot compute metrics for an empty dataset")

    y_pred = (p_bad_array >= float(threshold)).astype(np.int64)
    tn, fp, fn, tp = confusion_matrix(y_true_array, y_pred, labels=[0, 1]).ravel()

    precision, recall, f1, support = precision_recall_fscore_support(
        y_true_array,
        y_pred,
        labels=[0, 1],
        zero_division=0,
    )

    result: dict[str, Any] = {
        "threshold_bad": float(threshold),
        "n": int(y_true_array.size),
        "actual_good": int((y_true_array == 0).sum()),
        "actual_bad": int((y_true_array == 1).sum()),
        "predicted_good": int((y_pred == 0).sum()),
        "predicted_bad": int((y_pred == 1).sum()),
        "true_good": int(tn),
        "false_reject": int(fp),  # actual GOOD, predicted BAD
        "false_pass": int(fn),  # actual BAD, predicted GOOD
        "true_bad": int(tp),
        "accuracy": float(accuracy_score(y_true_array, y_pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true_array, y_pred)),
        "good_precision": float(precision[0]),
        "good_recall": float(recall[0]),
        "good_f1": float(f1[0]),
        "good_support": int(support[0]),
        "bad_precision": float(precision[1]),
        "bad_recall": float(recall[1]),
        "bad_f1": float(f1[1]),
        "bad_support": int(support[1]),
        "false_pass_rate": _safe_divide(fn, tp + fn),
        "false_reject_rate": _safe_divide(fp, tn + fp),
        "accepted_yield": _safe_divide(tn + fn, y_true_array.size),
        "good_release_rate": _safe_divide(tn, tn + fp),
    }

    if len(np.unique(y_true_array)) == 2:
        result["roc_auc"] = float(roc_auc_score(y_true_array, p_bad_array))
        result["average_precision_bad"] = float(
            average_precision_score(y_true_array, p_bad_array)
        )
    else:
        result["roc_auc"] = float("nan")
        result["average_precision_bad"] = float("nan")
    return result


def release_policy_metrics(
    y_true: Sequence[int] | np.ndarray,
    decisions: Sequence[str],
) -> dict[str, Any]:
    """Metrics for a GOOD/BAD/REVIEW routing policy.

    Only items whose decision is ``good`` are considered released. Both BAD and
    REVIEW are held back from the production batch.
    """
    y_true_array = np.asarray(y_true, dtype=np.int64)
    decisions_array = np.asarray([str(value).lower() for value in decisions], dtype=object)
    if len(y_true_array) != len(decisions_array):
        raise ValueError("y_true and decisions have different lengths")

    released = decisions_array == "good"
    held = ~released
    actual_bad = y_true_array == 1
    actual_good = y_true_array == 0

    bad_released = int(np.logical_and(actual_bad, released).sum())
    bad_total = int(actual_bad.sum())
    good_released = int(np.logical_and(actual_good, released).sum())
    good_total = int(actual_good.sum())

    return {
        "released_count": int(released.sum()),
        "held_count": int(held.sum()),
        "review_count": int((decisions_array == "review").sum()),
        "bad_decision_count": int((decisions_array == "bad").sum()),
        "bad_released_count": bad_released,
        "release_false_pass_rate": _safe_divide(bad_released, bad_total),
        "good_released_count": good_released,
        "good_release_rate": _safe_divide(good_released, good_total),
        "overall_release_yield": _safe_divide(released.sum(), len(released)),
    }


def threshold_sweep(
    y_true: Sequence[int] | np.ndarray,
    p_bad: Sequence[float] | np.ndarray,
    *,
    steps: int = 1001,
) -> pd.DataFrame:
    """Compute threshold trade-offs efficiently on an evenly spaced grid."""
    y_true_array = np.asarray(y_true, dtype=np.int64)
    p_bad_array = np.asarray(p_bad, dtype=np.float64)
    if y_true_array.shape[0] != p_bad_array.shape[0] or y_true_array.size == 0:
        raise ValueError("y_true and p_bad must be non-empty and have the same length")

    thresholds = np.linspace(0.0, 1.0, max(int(steps), 2))
    bad_probabilities = np.sort(p_bad_array[y_true_array == 1])
    good_probabilities = np.sort(p_bad_array[y_true_array == 0])
    n_bad = len(bad_probabilities)
    n_good = len(good_probabilities)

    # With prediction BAD when p_bad >= threshold, searchsorted(side='left')
    # gives how many probabilities are strictly below each threshold.
    fn = np.searchsorted(bad_probabilities, thresholds, side="left")
    tn = np.searchsorted(good_probabilities, thresholds, side="left")
    tp = n_bad - fn
    fp = n_good - tn

    def divide(numerator: np.ndarray, denominator: np.ndarray) -> np.ndarray:
        output = np.full_like(numerator, np.nan, dtype=np.float64)
        np.divide(numerator, denominator, out=output, where=denominator != 0)
        return output

    bad_recall = divide(tp.astype(float), (tp + fn).astype(float))
    good_recall = divide(tn.astype(float), (tn + fp).astype(float))
    bad_precision = divide(tp.astype(float), (tp + fp).astype(float))
    false_pass_rate = divide(fn.astype(float), (tp + fn).astype(float))
    false_reject_rate = divide(fp.astype(float), (tn + fp).astype(float))
    balanced = np.nanmean(np.vstack([bad_recall, good_recall]), axis=0)
    accepted_yield = divide((tn + fn).astype(float), np.full_like(tn, len(y_true_array), dtype=float))

    return pd.DataFrame(
        {
            "threshold_bad": thresholds,
            "bad_recall": bad_recall,
            "false_pass_rate": false_pass_rate,
            "good_recall": good_recall,
            "false_reject_rate": false_reject_rate,
            "bad_precision": bad_precision,
            "balanced_accuracy": balanced,
            "accepted_yield": accepted_yield,
            "false_pass": fn.astype(int),
            "false_reject": fp.astype(int),
        }
    )


def choose_safety_threshold(
    y_true: Sequence[int] | np.ndarray,
    p_bad: Sequence[float] | np.ndarray,
    *,
    target_bad_recall: float = 0.99,
    max_false_pass_rate: float | None = None,
    fallback_threshold: float = 0.5,
    steps: int = 10001,
) -> tuple[float, dict[str, Any], pd.DataFrame]:
    y_true_array = np.asarray(y_true, dtype=np.int64)
    if int((y_true_array == 1).sum()) == 0:
        metrics = binary_metrics(y_true_array, p_bad, threshold=fallback_threshold)
        metrics["threshold_selection_note"] = (
            "No BAD validation examples were available; fallback threshold used."
        )
        return float(fallback_threshold), metrics, threshold_sweep(y_true, p_bad, steps=1001)

    target = float(target_bad_recall)
    if max_false_pass_rate is not None:
        target = max(target, 1.0 - float(max_false_pass_rate))
    target = min(max(target, 0.0), 1.0)

    sweep = threshold_sweep(y_true, p_bad, steps=steps)
    valid = sweep[sweep["bad_recall"] >= target - 1e-12]
    if valid.empty:
        selected = float(fallback_threshold)
        note = "No threshold met the requested safety target; fallback threshold used."
    else:
        # Among thresholds satisfying BAD recall, the largest threshold normally
        # maximizes GOOD recall / minimizes false rejects.
        best_good_recall = valid["good_recall"].max()
        finalists = valid[np.isclose(valid["good_recall"], best_good_recall)]
        selected = float(finalists["threshold_bad"].max())
        note = "Highest-yield threshold satisfying the validation BAD-recall target."

    selected_metrics = binary_metrics(y_true, p_bad, threshold=selected)
    selected_metrics["target_bad_recall"] = target
    selected_metrics["threshold_selection_note"] = note
    return selected, selected_metrics, sweep


def predictions_frame(
    *,
    paths: Sequence[str],
    unit_ids: Sequence[str],
    unit_ids_raw: Sequence[str],
    sources: Sequence[str],
    splits: Sequence[str],
    p_bad: Sequence[float],
    threshold: float,
    y_true: Sequence[int] | None = None,
) -> pd.DataFrame:
    p_bad_array = np.asarray(p_bad, dtype=np.float64)
    predicted = (p_bad_array >= float(threshold)).astype(np.int64)
    frame = pd.DataFrame(
        {
            "path": list(paths),
            "filename": [Path(path).name for path in paths],
            "unit_id": list(unit_ids),
            "unit_id_raw": list(unit_ids_raw),
            "source": list(sources),
            "split": list(splits),
            "p_good": 1.0 - p_bad_array,
            "p_bad": p_bad_array,
            "threshold_bad": float(threshold),
            "predicted_label": [INDEX_TO_LABEL[int(value)] for value in predicted],
            "predicted_index": predicted,
        }
    )
    if y_true is not None:
        true_array = np.asarray(y_true, dtype=np.int64)
        frame["true_label"] = [INDEX_TO_LABEL[int(value)] for value in true_array]
        frame["true_index"] = true_array
        frame["correct"] = true_array == predicted
        frame["error_type"] = ""
        frame.loc[(true_array == 1) & (predicted == 0), "error_type"] = "false_pass"
        frame.loc[(true_array == 0) & (predicted == 1), "error_type"] = "false_reject"
    return frame


def add_review_decisions(
    frame: pd.DataFrame,
    *,
    enabled: bool,
    good_max_p_bad: float | None,
    bad_min_p_bad: float | None,
) -> pd.DataFrame:
    output = frame.copy()
    if not enabled:
        output["decision"] = output["predicted_label"]
        return output

    if good_max_p_bad is None or bad_min_p_bad is None:
        raise ValueError("Review policy needs both good_max_p_bad and bad_min_p_bad")
    if float(good_max_p_bad) >= float(bad_min_p_bad):
        raise ValueError("good_max_p_bad must be smaller than bad_min_p_bad")

    output["decision"] = "review"
    output.loc[output["p_bad"] <= float(good_max_p_bad), "decision"] = "good"
    output.loc[output["p_bad"] >= float(bad_min_p_bad), "decision"] = "bad"
    return output


def save_confusion_matrix(
    y_true: Sequence[int],
    p_bad: Sequence[float],
    *,
    threshold: float,
    path: str | Path,
    title: str,
) -> None:
    y_pred = (np.asarray(p_bad) >= threshold).astype(np.int64)
    matrix = confusion_matrix(y_true, y_pred, labels=[0, 1])
    fig, ax = plt.subplots(figsize=(6, 5))
    image = ax.imshow(matrix)
    fig.colorbar(image, ax=ax)
    ax.set_xticks([0, 1], labels=["GOOD", "BAD"])
    ax.set_yticks([0, 1], labels=["GOOD", "BAD"])
    ax.set_xlabel("Predicted label")
    ax.set_ylabel("True label")
    ax.set_title(title)
    for row in range(2):
        for column in range(2):
            ax.text(column, row, str(matrix[row, column]), ha="center", va="center")
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def save_roc_curve(y_true: Sequence[int], p_bad: Sequence[float], path: str | Path) -> None:
    y_true_array = np.asarray(y_true)
    if len(np.unique(y_true_array)) < 2:
        return
    fpr, tpr, _ = roc_curve(y_true_array, p_bad)
    auc_value = roc_auc_score(y_true_array, p_bad)
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.plot(fpr, tpr, label=f"ROC-AUC = {auc_value:.4f}")
    ax.plot([0, 1], [0, 1], linestyle="--", label="Random")
    ax.set_xlabel("False positive rate")
    ax.set_ylabel("True positive rate / BAD recall")
    ax.set_title("ROC curve")
    ax.legend()
    ax.grid(True, alpha=0.25)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def save_precision_recall_curve(
    y_true: Sequence[int], p_bad: Sequence[float], path: str | Path
) -> None:
    y_true_array = np.asarray(y_true)
    if len(np.unique(y_true_array)) < 2:
        return
    precision, recall, _ = precision_recall_curve(y_true_array, p_bad)
    ap = average_precision_score(y_true_array, p_bad)
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.plot(recall, precision, label=f"Average precision = {ap:.4f}")
    ax.set_xlabel("BAD recall")
    ax.set_ylabel("BAD precision")
    ax.set_title("Precision-recall curve")
    ax.legend()
    ax.grid(True, alpha=0.25)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def save_threshold_tradeoff(sweep: pd.DataFrame, selected_threshold: float, path: str | Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.plot(sweep["threshold_bad"], sweep["bad_recall"], label="BAD recall")
    ax.plot(sweep["threshold_bad"], sweep["good_recall"], label="GOOD recall")
    ax.plot(sweep["threshold_bad"], sweep["accepted_yield"], label="Accepted yield")
    ax.axvline(selected_threshold, linestyle="--", label=f"Selected = {selected_threshold:.4f}")
    ax.set_xlabel("BAD decision threshold")
    ax.set_ylabel("Rate")
    ax.set_ylim(-0.02, 1.02)
    ax.set_title("Safety/yield threshold trade-off")
    ax.legend()
    ax.grid(True, alpha=0.25)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def save_training_history(history: pd.DataFrame, path: str | Path) -> None:
    if history.empty:
        return
    fig, ax = plt.subplots(figsize=(8, 5))
    if "train_loss" in history:
        ax.plot(history["epoch"], history["train_loss"], label="Train loss")
    if "validation_loss" in history:
        ax.plot(history["epoch"], history["validation_loss"], label="Validation loss")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Loss")
    ax.set_title("Training history")
    ax.legend()
    ax.grid(True, alpha=0.25)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def export_errors(
    predictions: pd.DataFrame,
    output_dir: str | Path,
    *,
    source_root: str | Path | None = None,
) -> dict[str, int]:
    output_root = Path(output_dir)
    source_root_path = Path(source_root).resolve() if source_root else None
    counts = {"false_pass": 0, "false_reject": 0}
    if "error_type" not in predictions.columns:
        return counts

    for error_type in counts:
        subset = predictions[predictions["error_type"] == error_type]
        destination_root = output_root / error_type
        for _, row in subset.iterrows():
            source = Path(str(row["path"]))
            if not source.is_file():
                continue
            try:
                relative = source.resolve().relative_to(source_root_path) if source_root_path else None
            except (ValueError, OSError):
                relative = None
            if relative is None:
                relative = Path(f"{row.get('unit_id', '')}__{source.name}")
            destination = destination_root / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            if destination.exists():
                destination = destination.with_name(
                    f"{destination.stem}__copy{destination.suffix}"
                )
            shutil.copy2(source, destination)
            counts[error_type] += 1
    return counts


def save_evaluation_bundle(
    *,
    output_dir: str | Path,
    name: str,
    y_true: Sequence[int],
    p_bad: Sequence[float],
    threshold: float,
    predictions: pd.DataFrame,
    threshold_sweep_frame: pd.DataFrame | None = None,
    export_error_images: bool = True,
    source_root: str | Path | None = None,
) -> dict[str, Any]:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    metrics = binary_metrics(y_true, p_bad, threshold=threshold)

    predictions.to_csv(output / f"{name}_predictions.csv", index=False, encoding="utf-8")
    write_json(metrics, output / f"{name}_metrics.json")
    save_confusion_matrix(
        y_true,
        p_bad,
        threshold=threshold,
        path=output / f"{name}_confusion_matrix.png",
        title=f"{name}: GOOD/BAD confusion matrix",
    )
    save_roc_curve(y_true, p_bad, output / f"{name}_roc_curve.png")
    save_precision_recall_curve(
        y_true, p_bad, output / f"{name}_precision_recall_curve.png"
    )
    if threshold_sweep_frame is not None:
        threshold_sweep_frame.to_csv(
            output / f"{name}_threshold_sweep.csv", index=False, encoding="utf-8"
        )
        save_threshold_tradeoff(
            threshold_sweep_frame,
            threshold,
            output / f"{name}_threshold_tradeoff.png",
        )

    if export_error_images:
        export_errors(
            predictions,
            output / f"{name}_misclassified",
            source_root=source_root,
        )
    return metrics


def markdown_metrics(metrics: dict[str, Any], title: str) -> str:
    def pct(key: str) -> str:
        value = metrics.get(key, float("nan"))
        return "n/a" if value is None or not math.isfinite(float(value)) else f"{100*float(value):.2f}%"

    return "\n".join(
        [
            f"# {title}",
            "",
            f"- Samples: **{metrics.get('n', 0)}**",
            f"- Threshold P(BAD): **{float(metrics.get('threshold_bad', 0.5)):.5f}**",
            f"- Accuracy: **{pct('accuracy')}**",
            f"- Balanced accuracy: **{pct('balanced_accuracy')}**",
            f"- BAD recall: **{pct('bad_recall')}**",
            f"- BAD precision: **{pct('bad_precision')}**",
            f"- False-pass rate (BAD → GOOD): **{pct('false_pass_rate')}**",
            f"- False passes: **{metrics.get('false_pass', 0)}**",
            f"- False-reject rate (GOOD → BAD): **{pct('false_reject_rate')}**",
            f"- False rejects: **{metrics.get('false_reject', 0)}**",
            f"- Accepted yield: **{pct('accepted_yield')}**",
            f"- ROC-AUC: **{metrics.get('roc_auc', float('nan')):.5f}**",
            f"- Average precision (BAD): **{metrics.get('average_precision_bad', float('nan')):.5f}**",
            "",
            "BAD is the positive class. Therefore a false negative is a false pass: a real BAD unit predicted as GOOD.",
        ]
    )
