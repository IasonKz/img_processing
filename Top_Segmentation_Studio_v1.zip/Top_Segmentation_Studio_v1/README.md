# Top Segmentation Studio 1.0

A local, English-language application for **top images only**, combining the actual JB annotation tool v0.2 with a new Optuna segmentation training workspace styled after Inspection Studio v5.

Start with **START_HERE.md**. The application opens at http://127.0.0.1:8765.

- Annotation: brush, circle, ellipse, rectangle, polygon, editable inner boundary and octagon, automatic classical defect proposals, per-object visibility/deletion, undo/redo, zoom, background drag to pan, notes, exclude/restore, approved clean images, native masks, immutable annotation revisions.
- **Save custom polygon** persists an inner-boundary template in the annotation project. New images use it automatically. Reuse at the same pixel positions or scale relative to image dimensions. Apply it to existing drafts, or explicitly include approved annotations; changed masks become drafts for review. Only marked defect pixels receive inner/outer labels.
- Search: 13 semantic architecture families and 20 ready-made architecture/backbone combinations, plus editable SMP/timm combinations. Preflight validates forward/backward compatibility on the selected device/resolutions/batch size.
- Controls: CPU/CUDA/automatic, arbitrary trial and time budgets, per-trial time budget, epochs, patience, image/batch sizes, learning-rate and weight-decay ranges, CE/Dice/Tversky, AdamW/Adam/SGD, TPE/random, median/Hyperband/no pruning, augmentation, mixed precision, BatchNorm statistics, seed and grouped train/validation/test allocation.
- Evidence: native-geometry IoU, Dice, precision, recall, confusion matrix, image overlays, live curves, trial/architecture/runtime comparisons, parallel-coordinate chart, CSV and fully offline HTML report.
- Deployment: native image-sized prediction masks/overlays/CSV, portable PyTorch package, numerically verified ONNX export, canonical semantic dataset and derived COCO RLE components.

**No image upload or cloud training.** All images, masks, studies, SQLite databases and reports remain on the computer running the application. One-time Python package installation requires an internet connection unless packages are already cached. The shipped plotting JavaScript is local; no CDN is used at runtime.

The classification v5 project is unchanged. This is a separate top segmentation application with one integrated annotation/training UI, not an in-place modification of the classification application.

## Models and initialization

Small U-Net plus SMP 0.5.0: U-Net, U-Net++, FPN, PSPNet, DeepLabV3, DeepLabV3+, LinkNet, MAnet, PAN, UPerNet, SegFormer and DPT. Ready-made encoders include ResNet18/34/50, MobileNetV2, EfficientNet-B0, MiT-B0/B2, ConvNeXt-Tiny, ViT-Small and DINOv2 ViT-Small.

This is broad **semantic segmentation** support, not a claim that every segmentation system can be trained by one backend. Mask2Former, SAM and YOLO instance-segmentation trainers are not integrated. DINOv2 here is a DPT encoder, not a detector or independent mask predictor. COCO component export is available for external instance trainers.

Default initialization is random; pretrained weights are **not included**. Explicit local encoder state dictionaries can be selected through custom model JSON. See docs/STUDIO_MODELS.md. No automatic download occurs during model search or prediction.

PAN needs sufficiently large input (256 px was checked). Some backbones have architectural constraints and unsupported combinations; Preflight reports them. The DPT/DINOv2 adapter repairs SMP 0.5's patch-14 pyramid reassembly and restores output geometry. Additional custom backbones must pass Preflight.

## Dataset and results

Canonical classes are `0=background`, `1=inner defect`, `2=outer defect`. The inner polygon is a geometric boundary, not a defect label. Images must currently be opaque, single-frame 8-bit RGB or grayscale; 16-bit/float images require an explicit conversion upstream. No automatic brightness/crop change is applied to top sources.

Each new study snapshots approved images/masks and allocates groups once. A resumed study uses its original frozen dataset. New approvals require a new study to enter training. Models are selected on validation; test is excluded from Optuna and locked to the first model selected for final evaluation. Exact image duplicates are deduplicated; use `group_regex` for repeated views of a physical unit or tray. The application cannot infer unit identity from arbitrary names.

Search continuation restores the Optuna study and completed trials, not the exact interrupted batch or sampler RNG stream. Best and last checkpoints survive; an interrupted trial is marked failed and subsequent trials continue. Budgets and device can change on resume; search space and split settings must stay fixed. Time/stop checks occur between batches and validation images, not by interrupting a running CUDA kernel.

Annotated masks retain native resolution. Training uses aspect-preserving resize and padding, with padding ignored. Predictions are restored to native geometry for evaluation. Very small defects can disappear at reduced training sizes; per-trial preprocessing reports count lost components. This release does not implement patch/tile training.

Scores in software tests use synthetic images and are not evidence of production accuracy. See docs/STUDIO_VALIDATION.md for executed checks and limits.

## Provenance

Derived from the user's `top_segmentation_pilot_v0_2.zip` and visual/workflow conventions in `Inspection_Studio_v5.zip`. Original v0.2 code and its documentation are retained under topseg/ and docs/; the latter describes the legacy CLI where it differs from the new studio. New studio documentation takes precedence for studio operation.

Primary API references used: https://smp.readthedocs.io/en/v0.5.0/models.html , https://smp.readthedocs.io/en/v0.5.0/encoders_timm.html , https://optuna.readthedocs.io/en/stable/reference/generated/optuna.create_study.html .
