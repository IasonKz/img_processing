# Interface verification

The local interface should be checked at the target screen size and browser before routine use. Verify that the active experiment identity, operation status, selected decision, and output destination remain visible and understandable.

The critical operator paths are setup, training progress, failed-trial inspection, candidate comparison, saving a decision, labeled classification, image review, and workflow composition. A preview or successful page load does not validate a trained model.

See [VALIDATION_REPORT.md](VALIDATION_REPORT.md) for software and destination-machine acceptance scope.
