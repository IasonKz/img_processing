# Studio v2 validation — 24 September 2026

Executed on Linux, Python 3.12, CPU. These checks establish software behavior on synthetic fixtures, not accuracy on production top images. Windows launchers and CUDA execution were not run in this environment.

## Executed checks

- `python3 -m pytest -q`: **111 tests passed, 45 subtests passed**. Includes original annotation/geometry/import/training tests and new v2 methods, profiles, preview, migration and diagnostics tests.
- `node tests/test_mask.js`: passed pixel-mask operations, exact unions/erasures, asymmetric rotated chamfer geometry, zero-cut rectangle and invalid geometry checks.
- `node tests/test_ui_controller.js`: passed **31 real HTTP requests** with a simulated DOM. Covers preview without a saved revision, retained manual additions/erasures/notes, undo reload, failed reference rollback, profile save/load and separate scope/exclusion polygons.
- Real headless Chromium: integrated Studio/annotation workflow passed with **no JavaScript page errors**. Actual pointer gestures draw geometry and annotations. Checks all four methods, reference selection/alignment, native 720×640 mask dimensions, failed preview preserving state, save/reopen, polygon/profile reuse on another image, unchanged originals, and viewport containment at desktop/laptop dimensions. Browser screenshots use generated demonstration images.
- Existing CPU Optuna integration passed: Small U-Net training, study continuation, grouped frozen split isolation, native-sized evaluation, export package and dataset generation. This release changes annotation; the v1 training architecture registry was retained.

## Significant invariants checked

1. Basic with Full image reproduces the original detector's labels for identical boundary/settings. Basic bypasses exclusions/structural filtering. Retained manual corrections can still change the displayed result.
2. Excluded labels/symbols are absent only from applicable automatic proposals; removing the exclusion or selecting Basic restores detection there. Manual defects remain allowed in those areas.
3. Ring modeling reduces regular circular texture while retaining a localized synthetic scratch. Complete annular defects can be absorbed by the radial model.
4. Coherent straight-edge modeling suppresses an expected die perimeter while retaining a synthetic local boundary chip. It is experimental and can suppress other damage aligned with expected structure.
5. Native central-die scope rejects a neighbouring die and retains a small central defect. Weak or missing evidence returns an explicit failure.
6. Reference tests retain defects after translation, small rotation and brightness changes. Missing, uniform, unrelated, differently sized and out-of-limit references are rejected. Current images cannot be their own reference.
7. Guided inner-boundary fitting preserves custom corner proportions, uses native pixels and keeps the exact prior on weak/circular/inconsistent evidence. Automatic boundary analysis no longer reduces images to 512 pixels. Native 2856×2848 synthetic checks were also run.
8. Preview does not mutate saved masks, approval, notes, history or revisions. Failed previews preserve the editor state. Save/Approve creates the next immutable revision.
9. Newly recorded manual additions and erasures survive reload, save and reopen. Old manually reviewed v1 proposal footprints are conservatively retained as legacy objects. Historical v1 erased regions cannot be reconstructed.
10. Saved profiles scale geometry, never image pixels. Saved polygon/profile changes do not rewrite reviewed annotations. Explicit polygon batch application preserves defect footprints and returns changed annotations to draft review.
11. Proposal diagnostics persist. Changed boundary/method/settings are marked stale until proposals are reloaded. A failed saved profile still allows a new target image to open for manual correction or a method change.
12. The expanded settings panel scrolls independently; its hidden accessibility labels no longer cause the iframe document and canvas to scroll out of view.

## Reproduction

From the extracted project root, install test dependencies in its Python environment if needed:

```bash
python -m pip install pytest playwright
python -m playwright install chromium
python -m pytest -q
node tests/test_mask.js
node tests/test_ui_controller.js
python tests/browser_studio_v2.py
```

Node is only needed for the JavaScript tests; Playwright/Chromium are only needed for the browser test. Runtime application use does not require them. The browser test creates a temporary synthetic project and writes screenshots under `docs/screenshots`.

## Practical limits

- No source production images or representative defect ground truth were available for measuring real precision/recall. The screenshots supplied for discussion are photos of an editor, not calibrated image data.
- Structure-aware and good-reference comparison remain experimental assistive methods. Exclusions do not establish a good label. Review the complete image before approval.
- Saved zone profiles scale with image dimensions; they do not track a part's translation/rotation. Reference comparison aligns its references, not the saved exclusion polygons.
- Sources and annotation masks retain native dimensions. Reference warping interpolates reference pixels. Neural training still uses the selected v1 image size with aspect-preserving resize/padding; this is not native tile training.
- A resumed study keeps its frozen v1/v2 dataset. Create a new study to include newly approved images or changed annotations.
