# Decision thresholds and human review

Version 6 adds a two-threshold option to the Decision Explorer and optional model-agreement checks to the Decision Lab. Existing trained checkpoints remain usable. Saving a changed rule creates a new immutable decision; it does not retrain or replace a model.

## Two thresholds

Choose **Triage** and set a lower good threshold and an upper bad threshold. Higher scores always mean more evidence for bad.

| Score | Automatic output |
| --- | --- |
| Below the good threshold | Good |
| At or above the good threshold, below the bad threshold | Review |
| At or above the bad threshold | Bad |

For example, good = 0.2 and bad = 0.8 sends scores in [0.2, 0.8) to review. Equal thresholds restore binary decisions, with a boundary tie assigned to bad. Thresholds on raw anomaly distances are not probabilities and need not lie between zero and one.

The Decision Lab also supports this band after weighted score fusion or stacking. A cascade uses its own pair at each stage. Images left unresolved after its last stage become Review.

## Optional agreement guard

Choose at least two different candidate sources in the Decision Lab. The guard can use:

- **Vote disagreement:** send an image to Review when the source votes are not unanimous. Each source has its own editable vote threshold.
- **Score standard deviation:** send an image to Review when the population standard deviation of its source scores exceeds `max_std`.
- **Either:** apply both checks.
- **Off:** use the ordinary score rule or cascade.

Vote thresholds default to 0.5 and `max_std` to 0.15. These operate on source scores after any configured calibration, before weighting or stacking. A source's ordinary saved threshold and the guard's vote threshold may differ; the trace records both. A guard can replace Good or Bad with Review; it cannot replace Review with an automatic verdict.

Scores must be comparable values in [0, 1]. A system containing PatchCore requires score calibration fitted only on the fit part of the threshold partition. The separate tune subset chooses decision thresholds. Supervised softmax scores can be compared without calibration, but are not guaranteed calibrated probabilities.

This is a pilot review rule. Standard deviation and model agreement are heuristics, not a calibrated probability of error. Correlated models can agree on the same wrong answer. Validation on independent data remains necessary.

**Cascade cost:** activating this guard evaluates every selected source for every valid image, even if an early stage could decide. All sources are needed to detect later disagreement. Disable the guard to restore ordinary early exit. Stage reports distinguish images reaching a routing stage from images scored for the guard.

The older ordered workflow builder also offers **Consensus**: every stage is evaluated, and only unanimous Good or unanimous Bad is automatic. Any disagreement or Review vote produces Review. This rule requires at least two different checkpoint sets; several thresholds on the same model do not constitute independent model votes.

## Review records and labels

Copies are stored under `predicted/review/`. Each prediction record includes `human_review`, `review_reason`, and source/stage traces. Agreement checks also record score standard deviation and their mode.

The model prediction, dataset reference label, and operator verdict remain separate. An operator can mark **Review** to request another human check, or record Good, Bad, Unknown, or Unreviewed. The **Needs review** filter shows unresolved automatic abstentions and explicit operator Review tags; a completed Good/Bad operator verdict closes that review item without rewriting its original prediction.

Review is never converted automatically into a training label. Dataset export includes only explicit operator-confirmed Good/Bad labels. Pending Review, Unknown, and Unreviewed are excluded and counted separately. Protected validation/test identities remain protected when exporting for fine-tuning.

## Interpretation and tuning

Reports include the review rate, automatic decision coverage, automatic accuracy, bad escapes, good rejects, and class-specific review counts. Accuracy is conditional on images actually decided; sending every image to Review produces zero coverage and undefined accuracy, not perfect accuracy. Error rates retain every valid labeled input of the corresponding class in their denominator.

Use calibration data to explore thresholds and review workload. Decision Lab supports manual choices and Optuna threshold/weight tuning; its decision-only sampler choices are TPE and Random. Training's expanded sampler selector is a separate control. A score-only exhaustive sweep is disabled when an agreement guard is active, since it would ignore source disagreements.

Freezing a rule precedes its selection report. Final-test evaluation remains an explicit separate operation and is never used for threshold or agreement tuning. Independent deployment validation must include both escaped defects and human-review workload.

## Configuration example

```json
{
  "kind": "weighted",
  "sources": [
    {"run": "results/vig/run-id", "candidate": "resnet18_seed42"},
    {"run": "results/vig/run-id", "candidate": "efficientnet_b0_seed42"}
  ],
  "weights": [1, 1],
  "thresholds": {"good": 0.2, "bad": 0.8},
  "uncertainty": {
    "mode": "either",
    "vote_thresholds": [0.5, 0.5],
    "max_std": 0.15
  },
  "tuning": {"method": "manual"}
}
```

Decision Lab systems and multi-model workflows use the native project runtime. They are not silently flattened into a single exported model decision. Keep the source runs and frozen system/workflow together when moving them to another computer.
