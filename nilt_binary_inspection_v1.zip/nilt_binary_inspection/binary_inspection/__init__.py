"""Local, auditable binary visual inspection. GOOD=0, BAD=1."""
__version__ = "1.0.0"
