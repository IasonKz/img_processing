"""Native OS folder/file selection in a short-lived local helper process."""
import json
import sys


def main():
    import tkinter as tk
    from tkinter import filedialog
    request = json.loads(sys.stdin.read())
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    try:
        options = {"parent": root, "title": request.get("title", "Choose a local folder")}
        if request.get("initial"):
            options["initialdir"] = request["initial"]
        if request.get("kind") == "file":
            value = filedialog.askopenfilename(**options)
        else:
            value = filedialog.askdirectory(mustexist=request.get("mustexist", True), **options)
        print(json.dumps({"path": value or "", "cancelled": not bool(value)}))
    finally:
        root.destroy()


if __name__ == "__main__":
    main()
