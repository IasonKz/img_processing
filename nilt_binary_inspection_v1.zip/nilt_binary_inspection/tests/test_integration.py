from pathlib import Path
from copy import deepcopy
import shutil

import pytest

from binary_inspection.common import read_json, read_csv
from binary_inspection.splitting import prepare
from binary_inspection.training import train_all
from binary_inspection.patchcore import train_patchcore
from binary_inspection.selector import select_pipeline
from binary_inspection.inference import evaluate, predict_folder
from conftest import make_dataset


@pytest.mark.integration
def test_end_to_end_cpu_with_anomaly_and_corrupt_input(config, tmp_path):
    root = Path(config["paths"]["dataset_root"])
    make_dataset(root, 40)
    config["anomaly"]["enabled"] = True
    config["selector"]["use_anomaly_veto"] = True
    config["data"]["group_regex"] = r"(?P<unit_id>unit_\d+)"
    config["data"]["group_by"] = "unit_id"
    config["models"]["second_test"] = {"enabled": True, "architecture": "resnet18", "input_size": 64, "strategy": "frozen"}
    prepare(config)
    train_all(config)
    train_patchcore(config)
    selector = select_pipeline(config)
    assert selector["chosen"]["members"]
    assert not (Path(config["paths"]["output_dir"]) / "evaluation" / "test_report.json").exists()
    report = evaluate(config)
    assert report["metrics"]["images"] > 0 and report["release_authorized"] is False
    # Resume skips completed models and preserves frozen selector/test report.
    train_all(config)
    train_patchcore(config)
    assert select_pipeline(config)["request_signature"] == selector["request_signature"]
    assert evaluate(config)["selector_sha256"] == report["selector_sha256"]
    new_images = tmp_path / "unseen"
    make_dataset(new_images, 2, seed=333)
    (new_images / "bad" / "broken.png").write_bytes(b"not an image")
    summary = predict_folder(config, new_images, tmp_path / "predictions")
    assert summary["images"] == 5 and summary["model_failure"] is None
    predicted = read_csv(tmp_path / "predictions" / "predictions.csv")
    broken = next(r for r in predicted if r["relpath"].endswith("broken.png"))
    assert broken["decision"] == "REVIEW" and "INVALID_IMAGE" in broken["reason"]
    # Existing trained artifacts cannot be silently reused with changed settings.
    altered = deepcopy(config)
    altered["training"]["head_lr"] *= 2
    with pytest.raises(ValueError, match="Training configuration changed"):
        select_pipeline(altered)
    altered = deepcopy(config)
    altered["anomaly"]["memory_size"] += 1
    with pytest.raises(ValueError, match="PatchCore configuration changed"):
        select_pipeline(altered)
    # Test-based selector retuning is explicitly rejected.
    config["selector"]["max_bad_escape_rate"] = .01
    with pytest.raises(ValueError, match="TEST already evaluated"):
        select_pipeline(config)
