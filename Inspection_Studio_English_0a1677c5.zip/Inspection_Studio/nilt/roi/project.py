"""Persistent, local ROI projects. Geometry approval and quality are independent.

The project root contains ``top/``, ``bottom/`` and a shared unit split ledger.
Mutating API methods accept dictionaries and return ``state`` plus a ``summary``.
Original images are referenced read-only. Exports are immutable snapshots.
"""
from __future__ import annotations

import copy
import csv
import hashlib
import json
import math
import re
import threading
import uuid
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from nilt.image_io import decoded_identity_bytes, load_rgb

_EXTENSIONS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"}
_LOCKS = {}
_LOCK_GUARD = threading.Lock()


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _atomic_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        temp.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
        temp.replace(path)
    finally:
        if temp.exists():
            temp.unlink()


def _digest(data):
    return hashlib.sha256(json.dumps(data, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()[:16]


def _read_json(path, default):
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else copy.deepcopy(default)


def _split_for(unit_id, seed, ratios):
    value = int(hashlib.sha256(f"{seed}:{unit_id}".encode()).hexdigest()[:12], 16) / float(16 ** 12)
    return "train" if value < ratios[0] else ("val" if value < ratios[0] + ratios[1] else "test")


class ROIProject:
    """One view's project under a shared root; methods are safe across instances.

    Optional ``progress(message, current, total)`` and ``cancelled()`` callbacks
    let a GUI run long operations in its existing background-job infrastructure.
    """

    def __init__(self, root, side):
        if side not in ("top", "bottom"):
            raise ValueError("ROI detection supports top and bottom only.")
        self.root = Path(root).expanduser().resolve()
        self.side = side
        self.directory = self.root / side
        self.path = self.directory / "project.json"
        self.progress = None
        self.cancelled = None
        with _LOCK_GUARD:
            self._lock = _LOCKS.setdefault(str(self.root), threading.RLock())
        self.directory.mkdir(parents=True, exist_ok=True)
        self.data = _read_json(self.path, {"schema": "roi_project.v1", "side": side,
            "created_at": _now(), "updated_at": _now(), "template": None,
            "images": [], "exports": [], "warnings": [], "experiments": []})

    def save(self):
        with self._lock:
            self.data["updated_at"] = _now()
            _atomic_json(self.path, self.data)

    def _reload(self):
        if self.path.exists():
            self.data = _read_json(self.path, {})

    def _ledger(self):
        return _read_json(self.root / "unit_splits.json", {"schema": "roi_unit_splits.v1", "units": {}, "checksums": {}, "aliases": {}, "blocked_units": {}})

    def _save_ledger(self, ledger):
        _atomic_json(self.root / "unit_splits.json", ledger)

    def _tick(self, message, current, total):
        if callable(self.cancelled) and self.cancelled():
            if getattr(self, "_active_ledger", None) is not None:
                self._save_ledger(self._active_ledger)
            self.save()
            raise RuntimeError("Operation cancelled; completed images have been saved.")
        if callable(self.progress):
            self.progress(message, current, total)

    def state(self):
        with self._lock:
            self._reload()
            result = copy.deepcopy(self.data)
            from .geometry import default_template
            result["default_template"] = default_template(self.side)
            result["project_root"] = str(self.root)
            result["project_path"] = str(self.path)
            images = result["images"]
            result["counts"] = {"images": len(images), "identity_unconfirmed": sum(not i.get("identity_confirmed") for i in images),
                "localized": sum(bool(i.get("annotation")) for i in images),
                "geometry_reviewed": sum(i.get("annotation", {}).get("geometry_reviewed", False) and not i.get("annotation", {}).get("template_stale", False) for i in images),
                "quality": dict(Counter(q for i in images for q in i.get("annotation", {}).get("quality", {}).values())),
                "splits": dict(Counter(i["split"] for i in images))}
            return result

    def _image(self, image_id):
        for image in self.data["images"]:
            if image["id"] == image_id:
                return image
        raise ValueError(f"Unknown image ID: {image_id}")

    def _verify_source(self, image):
        """Reject overwritten source pixels before reusing annotations or IDs."""
        path = Path(image["path"])
        if hashlib.sha256(path.read_bytes()).hexdigest() == image.get("file_checksum"):
            return
        decoded = load_rgb(path)
        checksum = hashlib.sha256(decoded_identity_bytes(decoded)).hexdigest()
        if checksum != image["checksum"]:
            raise ValueError(f"Source image changed since import: {image['name']}. Import it as a new image before localization/export.")

    def image_path(self, image_id):
        with self._lock:
            self._reload()
            return Path(self._image(image_id)["path"])

    def _audit(self, action, image_id=None, details=None):
        with (self.directory / "history.jsonl").open("a", encoding="utf-8") as handle:
            handle.write(json.dumps({"time": _now(), "action": action, "image_id": image_id, "details": details}, ensure_ascii=False, allow_nan=False) + "\n")

    def import_images(self, payload):
        """Import folder/good/bad or CSV (path,unit_id,tray,label).

        Explicit ``unit_id_strategy`` can be stem, parent or regex. Without one,
        provisional stem IDs are shown for review and cannot enter a dataset.
        A CSV unit_id is explicit. Splits are assigned before localization.
        """
        with self._lock:
            self._reload()
            ratios = payload.get("split_ratios", [.7, .15, .15])
            if isinstance(ratios, dict):
                ratios = [ratios.get(k, 0) for k in ("train", "val", "test")]
            if len(ratios) != 3 or any(not isinstance(v, (float, int)) or not math.isfinite(v) or v < 0 for v in ratios) or not math.isclose(sum(ratios), 1, abs_tol=1e-6):
                raise ValueError("split_ratios must be three non-negative numbers summing to 1.")
            strategy = payload.get("unit_id_strategy", "unconfirmed")
            if strategy not in ("stem", "parent", "regex", "unconfirmed"):
                raise ValueError("unit_id_strategy must be stem, parent or regex.")
            expression = payload.get("unit_id_regex", payload.get("unit_regex", ""))
            pattern = re.compile(expression) if strategy == "regex" else None
            if strategy == "regex" and not expression:
                raise ValueError("A unit ID regex with a capture group is required.")
            csv_path = payload.get("csv_path")
            folder = payload.get("folder", payload.get("path"))
            if not csv_path and folder and Path(folder).suffix.lower() == ".csv":
                csv_path, folder = folder, None
            entries = []
            if csv_path:
                source = Path(csv_path).expanduser().resolve()
                with source.open(newline="", encoding="utf-8-sig") as handle:
                    reader = csv.DictReader(handle)
                    if not reader.fieldnames or not ({"path", "image_path", "relative_path"} & set(reader.fieldnames)):
                        raise ValueError("CSV needs a path or image_path column; unit_id,tray,label are recommended.")
                    for row in reader:
                        value = row.get("path") or row.get("image_path") or row.get("relative_path")
                        if not value:
                            continue
                        candidate = Path(value).expanduser()
                        entries.append((candidate if candidate.is_absolute() else source.parent / candidate, row))
            elif folder:
                source = Path(folder).expanduser().resolve()
                if not source.is_dir():
                    raise ValueError("Input folder does not exist.")
                entries = [(p, {}) for p in sorted(source.rglob("*")) if p.is_file() and p.suffix.lower() in _EXTENSIONS]
            else:
                raise ValueError("Choose an image folder or CSV file.")
            ledger = self._ledger()
            ledger.setdefault("aliases", {})
            ledger.setdefault("blocked_units", {})
            self._active_ledger = ledger
            existing = {item["checksum"]: item for item in self.data["images"]}
            held_out = {str(v) for v in payload.get("test_trays", [])}
            imported = duplicates = 0
            errors, warnings = [], []
            for index, (candidate, row) in enumerate(entries):
                self._tick(f"Importing {candidate.name}", index, len(entries))
                try:
                    candidate = candidate.resolve()
                    decoded = load_rgb(candidate)
                    checksum = hashlib.sha256(decoded_identity_bytes(decoded)).hexdigest()
                    file_checksum = hashlib.sha256(candidate.read_bytes()).hexdigest()
                    unit_id = str(row.get("unit_id") or "").strip()
                    confirmed = bool(unit_id)
                    if not unit_id:
                        if strategy == "parent":
                            unit_id, confirmed = candidate.parent.name, True
                        elif strategy == "regex":
                            match = pattern.search(str(candidate))
                            if not match:
                                raise ValueError("Unit ID regex did not match.")
                            unit_id = match.groupdict().get("unit_id") or (match.group(1) if match.lastindex else match.group(0))
                            confirmed = True
                        else:
                            unit_id = candidate.stem
                            confirmed = strategy == "stem"
                    if not unit_id:
                        raise ValueError("An empty unit ID is not valid.")
                    tray = str(row.get("tray") or payload.get("tray") or "").strip()
                    # Hash duplicates in other views share their original unit even
                    # if the second importer proposed a different identifier.
                    def canonical(value):
                        seen = set()
                        while value in ledger["aliases"] and value not in seen:
                            seen.add(value)
                            value = ledger["aliases"][value]
                        return value
                    unit_id = canonical(unit_id)
                    previous = ledger["checksums"].get(checksum)
                    if previous and canonical(previous["unit_id"]) != unit_id:
                        original_unit = canonical(previous["unit_id"])
                        existing_unit = ledger["units"].get(unit_id)
                        original_record = ledger["units"].get(original_unit)
                        if existing_unit and original_record and existing_unit["split"] != original_record["split"]:
                            message = f"Duplicate links units {original_unit} and {unit_id} in different frozen splits. Both groups are quarantined; start a new project with corrected unit IDs."
                            ledger["blocked_units"][unit_id] = message
                            ledger["blocked_units"][original_unit] = message
                            warnings.append(message)
                            self._save_ledger(ledger)
                            raise ValueError(message)
                        ledger["aliases"][unit_id] = original_unit
                        warnings.append(f"Identical pixels join unit {unit_id} to {original_unit}; all its captures use this group.")
                        unit_id = original_unit
                    if unit_id in ledger["blocked_units"]:
                        raise ValueError(ledger["blocked_units"][unit_id])
                    if checksum in existing:
                        duplicates += 1
                        original = existing[checksum]
                        aliases = original.setdefault("aliases", [])
                        if str(candidate) != original["path"] and str(candidate) not in aliases:
                            aliases.append(str(candidate))
                        if row.get("label") and original.get("initial_label") and row["label"].lower() != original["initial_label"]:
                            warnings.append(f"Duplicate image has conflicting image label: {candidate.name}.")
                        continue
                    unit = ledger["units"].get(unit_id)
                    requested_test = bool(tray and tray in held_out)
                    if unit and requested_test and unit["split"] != "test":
                        raise ValueError(f"Unit {unit_id} already belongs to {unit['split']}; cannot move it into held-out test after import. Start a new project for a new split.")
                    if not unit:
                        split = "test" if requested_test else _split_for(unit_id, payload.get("seed", 42), ratios)
                        unit = ledger["units"][unit_id] = {"split": split, "created_at": _now(), "trays": []}
                    if tray and tray not in unit["trays"]:
                        unit["trays"].append(tray)
                    split = unit["split"]
                    ledger["checksums"][checksum] = {"unit_id": unit_id, "split": split}
                    label = str(row.get("label") or "").lower()
                    if not label:
                        label = next((part.lower() for part in reversed(candidate.parts[:-1]) if part.lower() in ("good", "bad")), "unknown")
                    if label not in ("good", "bad"):
                        label = "unknown"
                    image = {"id": checksum[:24], "name": candidate.name, "path": str(candidate), "checksum": checksum,
                        "file_checksum": file_checksum, "width": decoded.width, "height": decoded.height,
                        "unit_id": unit_id, "identity_confirmed": confirmed, "tray": tray, "split": split,
                        "initial_label": label, "source": str(source), "imported_at": _now(), "annotation": {}}
                    self.data["images"].append(image)
                    existing[checksum] = image
                    imported += 1
                    if imported % 25 == 0:
                        self._save_ledger(ledger)
                        self.save()
                except (OSError, ValueError) as error:
                    errors.append({"path": str(candidate), "error": str(error)})
            if any(not item.get("identity_confirmed") for item in self.data["images"]):
                warnings.append("Confirm unit IDs before dataset export. Filename stems are provisional; repeated captures of one unit must use the same ID across TOP and BOTTOM.")
            self.data["warnings"] = list(dict.fromkeys(self.data.get("warnings", []) + warnings))[-100:]
            self._save_ledger(ledger)
            self.save()
            self._active_ledger = None
            self._audit("import", details={"imported": imported, "duplicates": duplicates, "errors": errors})
            self._tick("Import complete", len(entries), len(entries))
            return {"state": self.state(), "summary": {"imported": imported, "duplicates": duplicates, "errors": errors, "warnings": warnings}}

    def save_template(self, payload):
        from .geometry import normalize_template
        with self._lock:
            self._reload()
            raw = copy.deepcopy(payload.get("template", payload))
            reference_id = payload.get("reference_image_id") or raw.get("reference_image_id")
            if reference_id:
                image = self._image(reference_id)
                if image["split"] != "train":
                    raise ValueError("Choose a training image for the geometry reference; validation/test must remain independent.")
                raw["reference_size"] = [image["width"], image["height"]]
            template = normalize_template(raw, self.side)
            template["reference_image_id"] = reference_id
            stable = {k: v for k, v in template.items() if k not in ("version", "updated_at")}
            template["version"] = _digest(stable)
            template["updated_at"] = _now()
            old = self.data.get("template")
            self.data["template"] = template
            if not old or old.get("version") != template["version"]:
                for image in self.data["images"]:
                    annotation = image.get("annotation", {})
                    if annotation:
                        annotation["template_stale"] = True
                        annotation["needs_review"] = True
            self.save()
            self._audit("template", details=template)
            return {"state": self.state(), "summary": {"template_version": template["version"], "rois": len(template.get("rois", []))}}

    def localize_images(self, payload):
        from .localization import localize
        with self._lock:
            self._reload()
            template = self.data.get("template")
            if not template:
                raise ValueError("Create a geometry template first.")
            selected = set(payload.get("image_ids") or [i["id"] for i in self.data["images"]])
            reference_id = template.get("reference_image_id")
            if reference_id:
                self._verify_source(self._image(reference_id))
            reference_path = self._image(reference_id)["path"] if reference_id else None
            localized = skipped = 0
            errors = []
            images = [i for i in self.data["images"] if i["id"] in selected]
            for index, image in enumerate(images):
                self._tick(f"Locating ROIs in {image['name']}", index, len(images))
                previous = image.get("annotation", {})
                if previous.get("geometry_reviewed") and not payload.get("replace_reviewed", False):
                    skipped += 1
                    continue
                if previous and not payload.get("force", False) and not previous.get("template_stale"):
                    skipped += 1
                    continue
                try:
                    self._verify_source(image)
                    localizer = getattr(self, "localizer", None)
                    method = payload.get("method", "cv")
                    if not callable(localizer) and method in ("segmentation", "hybrid"):
                        from .learning import localize_with_model
                        model_path = payload.get("model_path")
                        if not model_path:
                            raise ValueError("Select a trained ROI segmentation model first.")
                        result = localize_with_model(image["path"], template, model_path, reference_path=reference_path,
                            quarter_turn=payload.get("quarter_turn"), method=method)
                    elif method == "template" and not callable(localizer):
                        result = localize(image["path"], template, reference_path=None, quarter_turn=payload.get("quarter_turn"))
                    else:
                        result = (localizer or localize)(image["path"], template, reference_path=reference_path, quarter_turn=payload.get("quarter_turn"))
                    result = copy.deepcopy(result)
                    result.update({"geometry_status": "pending", "geometry_reviewed": False,
                        "template_version": template["version"], "template_stale": False,
                        "quality": {roi["id"]: "unknown" for roi in result.get("rois", [])},
                        "revision": previous.get("revision", 0) + 1, "updated_at": _now()})
                    if previous:
                        self._audit("replace_localization", image["id"], previous)
                    image["annotation"] = result
                    localized += 1
                    if localized % 10 == 0:
                        self.save()
                except (ValueError, OSError, RuntimeError) as error:
                    errors.append({"image_id": image["id"], "error": str(error)})
            self.save()
            self._tick("Localization complete", len(images), len(images))
            return {"state": self.state(), "summary": {"localized": localized, "skipped": skipped, "errors": errors}}

    def save_annotation(self, payload):
        """Review geometry and/or explicit ROI quality; geometry edits reset labels.

        Accepts ``{image_id, annotation:{...}}`` or fields at the top level.
        ``unit_id`` and ``identity_confirmed`` repair provisional import metadata.
        """
        with self._lock:
            self._reload()
            image = self._image(payload.get("image_id") or payload.get("id"))
            values = {**payload.get("annotation", {}), **{k: v for k, v in payload.items() if k != "annotation"}}
            before = copy.deepcopy(image)
            if "unit_id" in values or "identity_confirmed" in values:
                unit_id = str(values.get("unit_id", image["unit_id"])).strip()
                if not unit_id:
                    raise ValueError("Unit ID cannot be empty.")
                ledger = self._ledger()
                known = ledger["units"].get(unit_id)
                if known and known["split"] != image["split"]:
                    # Correcting identity moves this image to the established unit
                    # split, and invalidates old snapshots through a warning.
                    image["split"] = known["split"]
                if not known:
                    ledger["units"][unit_id] = {"split": image["split"], "created_at": _now(), "trays": [image["tray"]] if image["tray"] else []}
                image["unit_id"] = unit_id
                image["identity_confirmed"] = bool(values.get("identity_confirmed", True))
                ledger["checksums"][image["checksum"]] = {"unit_id": unit_id, "split": image["split"]}
                self._save_ledger(ledger)
                if self.data["exports"] and (before["unit_id"] != unit_id or before["split"] != image["split"]):
                    self.data["warnings"].append("Unit identity changed after an export. Create a new dataset snapshot before training; old snapshots retain their original splits.")
            annotation = copy.deepcopy(image.get("annotation") or {"rois": [], "quality": {}, "geometry_status": "pending", "geometry_reviewed": False})
            old_rois = {r["id"]: r for r in annotation.get("rois", [])}
            changed = []
            if "rois" in values:
                rois = copy.deepcopy(values["rois"])
                if not isinstance(rois, list):
                    raise ValueError("rois must be a list.")
                seen = set()
                for roi in rois:
                    roi_id = str(roi.get("id", ""))
                    if not roi_id or roi_id in seen or "/" in roi_id or "\\" in roi_id:
                        raise ValueError("Each ROI needs a unique safe ID.")
                    seen.add(roi_id)
                    points = roi.get("points")
                    shape = roi.get("shape", "polygon")
                    minimum = 1 if shape == "point" else (2 if shape == "circle" else 3)
                    if not isinstance(points, list) or len(points) < minimum or any(not isinstance(p, (list, tuple)) or len(p) != 2 or not all(isinstance(v, (int, float)) and math.isfinite(v) for v in p) for p in points):
                        raise ValueError(f"Invalid points for ROI {roi_id}.")
                    old = old_rois.get(roi_id, {})
                    support_changed = any(roi.get(k) != old.get(k) for k in ("points", "shape", "margin", "kind"))
                    point_changed = any(roi.get(k) != old.get(k) for k in ("points", "shape"))
                    explicit_observation = bool(roi.pop("confirm_observed", False)) or bool(roi.get("observed_confirmed", False))
                    observation_supplied = bool(roi.get("observed_points")) and roi.get("observed_points") != old.get("observed_points")
                    if support_changed:
                        changed.append(roi_id)
                        if point_changed:
                            roi["source"] = "manual"
                            # Moving an expected inspection region is not proof
                            # that the corresponding material is visible.
                            if not explicit_observation and not observation_supplied:
                                roi["observed_points"] = None
                                roi["observed_confirmed"] = False
                        roi.setdefault("expected_points", copy.deepcopy(old.get("expected_points", points)))
                    presence = roi.get("presence", old.get("presence", "unknown"))
                    if presence not in ("present", "absent", "unknown"):
                        raise ValueError("ROI presence must be present, absent or unknown.")
                    roi["presence"] = presence
                    if presence == "absent":
                        roi["observed_points"] = None
                        roi["observed_confirmed"] = False
                        roi["presence_source"] = "manual"
                    elif explicit_observation or observation_supplied:
                        observed = copy.deepcopy(points if explicit_observation else roi["observed_points"])
                        from .geometry import validate_points
                        roi["observed_points"] = validate_points(observed, shape)
                        roi["observed_confirmed"] = True
                        roi["observed_source"] = "manual"
                        roi["source"] = "manual"
                        roi["presence"] = "present"
                    roi.setdefault("kind", old.get("kind", roi_id))
                annotation["rois"] = rois
                annotation["quality"] = {r["id"]: ("unknown" if r["id"] in changed else annotation.get("quality", {}).get(r["id"], "unknown")) for r in rois}
                if changed:
                    annotation["geometry_reviewed"] = False
                    annotation["geometry_status"] = "pending"
                    annotation["needs_review"] = True
            for key in ("transform", "quarter_turn", "orientation", "notes"):
                if key in values:
                    annotation[key] = copy.deepcopy(values[key])
            if "geometry_reviewed" in values or "geometry_status" in values:
                reviewed = bool(values.get("geometry_reviewed", values.get("geometry_status") == "reviewed"))
                if reviewed:
                    required = {r["id"] for r in (self.data.get("template") or {}).get("rois", [])}
                    actual = {r["id"] for r in annotation.get("rois", [])}
                    if not actual or not required.issubset(actual):
                        raise ValueError("Geometry review requires all template ROIs, including inferred ROIs for missing features.")
                annotation["geometry_reviewed"] = reviewed
                annotation["geometry_status"] = "reviewed" if reviewed else "pending"
                annotation["needs_review"] = not reviewed
                if reviewed:
                    annotation["template_stale"] = False
                    annotation["template_version"] = (self.data.get("template") or {}).get("version")
            quality = values.get("quality", {})
            if not isinstance(quality, dict):
                raise ValueError("quality must map ROI IDs to good, bad or unknown.")
            for roi_id, label in quality.items():
                if roi_id not in {r["id"] for r in annotation.get("rois", [])}:
                    raise ValueError(f"Unknown ROI for quality label: {roi_id}")
                label = str(label).lower()
                if label in ("uncertain", "unlabeled"):
                    label = "unknown"
                if label not in ("good", "bad", "unknown"):
                    raise ValueError("Quality must be good, bad or unknown.")
                annotation.setdefault("quality", {})[roi_id] = label
            annotation["revision"] = annotation.get("revision", 0) + 1
            annotation["updated_at"] = _now()
            image["annotation"] = annotation
            self._audit("annotation_before_edit", image["id"], before)
            self.save()
            return {"state": self.state(), "summary": {"image_id": image["id"], "changed_rois": changed, "geometry_reviewed": annotation.get("geometry_reviewed", False)}}

    def export_datasets(self, payload):
        from .datasets import export_project
        with self._lock:
            self._reload()
            result = export_project(self, payload)
            self.data["exports"].append(result)
            self.data["crop_settings"] = copy.deepcopy(payload.get("crop_settings") or {})
            self.save()
            self._audit("export", details=result)
            return {**result, "state": self.state(), "summary": result.get("counts", {})}
