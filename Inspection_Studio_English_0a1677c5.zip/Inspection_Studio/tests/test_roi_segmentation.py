"""Real ROI exports, shared crop review, inherited splits and CPU model round trips.

Synthetic images establish data integrity and orchestration, not inspection accuracy.
"""
import copy
from http.server import ThreadingHTTPServer
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import threading
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import numpy as np
from PIL import Image
import pytest
import yaml

from nilt.common import read_json, write_json
from nilt.dashboard import Dashboard, make_handler
from nilt.roi.geometry import default_template
from nilt.segmentation_bridge import state, workspace
from topseg.inference import prepare_image
from topseg.native_images import read_native, save_png
from topseg.project import ConflictError, Project
from topseg.roi_sources import fixed_split, source_mapping


def export_fixture(app, side='bottom', native=True):
    """Use the real geometry, ledger and exporter, including multiple pins/unit."""
    from nilt.image_io import NativeImage
    project = app.roi_project({'side': side})
    for index, role in enumerate(('train', 'train', 'train', 'val', 'val', 'test')):
        folder = app.config.parent / 'source' / side / f'unit{index}'
        folder.mkdir(parents=True)
        dtype = np.uint16 if native else np.uint8
        pixels = np.random.default_rng(index + (70 if side == 'top' else 90)).integers(
            100 if native else 20, 50000 if native else 200, (128, 128, 3), dtype=dtype)
        save_png(folder / f'unit{index}.png', NativeImage(pixels) if native else Image.fromarray(pixels))
        result = project.import_images({'folder': str(folder), 'unit_id_strategy': 'parent',
                                        'split_ratios': [int(role == name) for name in ('train', 'val', 'test')]})
        assert not result['summary']['errors']
    template = default_template(side)
    kind = 'label' if side == 'top' else 'pins'
    template['rois'] = [row for row in template['rois'] if row['kind'] == kind][:2]
    reference = next(row for row in project.state()['images'] if row['split'] == 'train')
    project.save_template({'template': template, 'reference_image_id': reference['id']})
    assert project.localize_images({'method': 'template'})['summary']['localized'] == 6
    for row in project.state()['images']:
        rois = copy.deepcopy(row['annotation']['rois'])
        for roi in rois:
            roi['confirm_observed'] = True
        project.save_annotation({'image_id': row['id'], 'rois': rois, 'geometry_reviewed': True,
                                  'quality': {rois[0]['id']: 'bad'}})
    return project.export_datasets({}), kind


@pytest.fixture
def app(tmp_path):
    path = tmp_path / 'project.yaml'
    path.write_text(yaml.safe_dump({'schema_version': 3, 'tasks': {
        'vig': {'dataset_root': './vig'}, 'top': {'dataset_root': './top'},
        'bottom': {'dataset_root': './bottom'}}}))
    dashboard = Dashboard(path)
    yield dashboard
    for server in getattr(dashboard, 'segmentation_workspaces', {}).values():
        if server.jobs.current().get('status') in ('starting', 'running', 'unverified'):
            server.jobs.force_stop()
        if server.jobs.process:
            server.jobs.process.wait(timeout=20)
    for process in getattr(dashboard, '_roi_processes', {}).values():
        if process.poll() is None:
            process.terminate()
        process.wait(timeout=20)


def open_crops(app, export, kind):
    result = app.segmentation_prepare_crops({'side': export['side'], 'export_id': export['export_id'], 'kind': kind})
    server = workspace(app, export['side'], 0, kind=kind, export_id=export['export_id'])
    if server.jobs.process:
        assert server.jobs.process.wait(timeout=30) == 0, server.jobs.current()
    assert server.jobs.current()['status'] == 'completed', server.jobs.current()
    assert not server.jobs.current()['result']['invalid']
    return result, server


def approve_defects(project):
    for row in project.items():
        h, w = row['height'], row['width']
        mask = np.zeros((h, w), np.uint8)
        mask[h//3:2*h//3, w//3:2*w//3] = 1
        roi = {'type': 'polygon', 'points': [{'x': 0, 'y': 0}, {'x': w-1, 'y': 0},
                                            {'x': w-1, 'y': h-1}, {'x': 0, 'y': h-1}]}
        project.save_annotation(row['id'], mask, roi, expected_revision=row['revision'], approved=True)


@pytest.mark.parametrize('side', ['top', 'bottom'])
def test_shared_annotations_native_pixels_lineage_and_restart(app, side, tmp_path):
    export, kind = export_fixture(app, side)
    result, server = open_crops(app, export, kind)
    assert all(row['status'] == 'unannotated' for row in server.project.items())
    crop_rows = read_json(Path(export['path']) / 'crops_manifest.json')['samples']
    for row in server.project.items():
        crop = row['roi_source']
        assert crop in [{**r, 'relative_path': Path(r['path']).name} for r in crop_rows]
        assert row['group'] == crop['unit_id'] and row['fixed_split'] == crop['split']
        original = read_native(Path(export['path']) / crop['path'])
        stored = read_native(server.project.image_path(row['id']))
        assert np.asarray(stored).dtype == np.uint16
        np.testing.assert_array_equal(np.asarray(stored), np.asarray(original))
        assert np.asarray(server.project.display_image(row['id'])).dtype == np.uint8
    approve_defects(server.project)
    current_job = server.jobs.current()['job_id']
    _, same = open_crops(app, export, kind)
    assert same is server and same.jobs.current()['job_id'] == current_job
    reopened = Dashboard(app.config)
    recovered = state(reopened)
    assert result['context'] in recovered
    project = workspace(reopened, side, 0, kind=kind, export_id=export['export_id']).project
    assert all(row['status'] == 'approved' for row in project.items())
    row = project.items()[0]
    with pytest.raises(ConflictError):
        project.save_annotation(row['id'], np.zeros((row['height'], row['width']), np.uint8),
                                expected_revision=0, approved=True, clean=True)
    frozen = read_json(project.snapshot(tmp_path / 'frozen'))
    assert frozen['grouping'] == 'roi_unit_id'
    from topseg.training import inspect_training_masks
    inspect_training_masks(frozen['records'], tmp_path/'frozen', 64)
    split = fixed_split(frozen['records'], require_both=False)
    assert split['split_source'] == 'roi_detection_unit_ledger'
    assert set(split['test_ids']) == {r['id'] for r in frozen['records'] if r['fixed_split'] == 'test'}


def test_fixed_splits_reject_leakage_missing_roles_and_missing_defects():
    rows = [{'id': str(i), 'group': str(i), 'fixed_split': role, 'defect_classes': [1]}
            for i, role in enumerate(('train', 'val', 'test'))]
    from topseg.search import make_split
    from topseg.training import split_groups
    expected = fixed_split(rows, False)
    assert split_groups(rows, val_fraction=.8, seed=817, require_both=False) == expected
    assert make_split(rows, {'require_both': False}) == expected
    for changes, message in (({'group': '0'}, 'leakage'), ({'fixed_split': None}, 'original unit'),
                              ({'defect_classes': []}, 'validation crops')):
        bad = copy.deepcopy(rows)
        bad[1].update(changes)
        with pytest.raises(ValueError, match=message):
            fixed_split(bad, False)
    with pytest.raises(ValueError, match='training split lacks'):
        fixed_split(rows, True)
    with pytest.raises(ValueError, match='both original'):
        fixed_split([rows[0], rows[2]], False)
    with pytest.raises(ValueError, match='Predecessor unit roles'):
        split_groups(rows, previous={'2': 'train'}, require_both=False)


def test_changed_export_or_source_manifest_cannot_change_existing_project(app):
    export, kind = export_fixture(app)
    _, server = open_crops(app, export, kind)
    binding = server.cfg['roi_source']
    manifest = Path(binding['manifest'])
    original = manifest.read_bytes()
    changed = read_json(manifest)
    changed['samples'][0]['split'] = 'test'
    write_json(manifest, changed)
    with pytest.raises(ValueError, match='lineage changed'):
        source_mapping(server.cfg)
    manifest.write_bytes(original)
    row = server.project.items()[0]
    source = Path(export['path']) / row['roi_source']['path']
    source.write_bytes(b'changed')
    with pytest.raises(ValueError, match='pixels changed'):
        app.segmentation_prepare_crops({'side': 'bottom', 'export_id': export['export_id'], 'kind': kind})


def test_native_tensor_preserves_sub_eight_bit_intensity():
    from nilt.image_io import NativeImage
    image = np.full((32, 32, 3), 32000, np.uint16)
    image[:, 16:] += 1
    tensor, _ = prepare_image(NativeImage(image), 32)
    assert tensor.dtype == np.float32
    assert tensor[0, 0, 16] > tensor[0, 0, 0]
    assert tensor[0, 0, 16] == pytest.approx(32001/65535, abs=1e-7)


@pytest.fixture
def http(app):
    server = ThreadingHTTPServer(('127.0.0.1', 0), make_handler(app))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f'http://127.0.0.1:{server.server_port}'
    def request(path, data=None, token=None, dashboard=False):
        headers = {'Origin': base}
        if token:
            headers['X-Inspection-Token' if dashboard else 'X-Session-Token'] = token
        if data is not None:
            headers['Content-Type'] = 'application/json'
        try:
            response = urlopen(Request(base+path, data=json.dumps(data).encode() if data is not None else None,
                                       headers=headers), timeout=20)
        except HTTPError as error:
            response = error
        with response:
            body = response.read()
            return response.status, json.loads(body) if 'application/json' in response.headers.get('Content-Type', '') else body
    yield request
    server.shutdown()
    server.server_close()
    thread.join(timeout=10)


def test_crop_http_mounts_share_review_but_isolate_views_and_lock_source(app, http):
    code, _ = http('/segmentation/bottom/')
    assert code == 400
    tokens = []
    for side in ('top', 'bottom'):
        export, kind = export_fixture(app, side)
        code, catalog = http('/api/segmentation/catalog?side='+side)
        assert code == 200 and catalog['whole_image_available'] == (side == 'top')
        result, server = open_crops(app, export, kind)
        prefix = result['prefix']
        for route in ('/', '/annotate'):
            code, html = http(prefix+route)
            assert code == 200 and f'data-segmentation-context="{result["context"]}"'.encode() in html
            token = re.search(rb'name="session-token" content="([^"]+)"', html)[1].decode()
            assert token == server.session_token
        tokens.append(token)
        assert http(prefix+'/api/studio/state', token='foreign-token')[0] == 403
        code, data = http(prefix+'/api/studio/state', token=token)
        assert code == 200 and data['defaults']['require_both'] is False
        assert http(prefix+'/api/studio/config', {'input_dir': '/tmp/another-dataset'}, token=token)[0] == 400
        row = server.project.items()[0]
        code, rgb = http(prefix+'/api/image/'+row['id']+'/rgb', token=token)
        assert code == 200 and np.asarray(Image.open(io.BytesIO(rgb))).dtype == np.uint8
        code, _ = http('/api/segmentation/roi-crops', {'side': side, 'kind': kind, 'export_id': export['export_id']})
        assert code == 403
    assert tokens[0] != tokens[1]
    for data in ({'side': 'vig'}, {'side': 'bottom', 'kind': 'label', 'export_id': 'unused'},
                 {'side': 'bottom', 'kind': 'pins', 'export_id': '../escape'}):
        assert http('/api/segmentation/roi-crops', data, token=app.token, dashboard=True)[0] == 400


def test_roi_crop_search_evaluation_native_package_and_finetune(app, tmp_path):
    pytest.importorskip('torch')
    from topseg.search import run_search
    from topseg.operations import evaluate_trial, export_model, predict_folder
    from topseg.inference import load_model
    from topseg.training import train
    export, kind = export_fixture(app)
    _, server = open_crops(app, export, kind)
    approve_defects(server.project)
    raw = {'models': ['small_unet'], 'image_sizes': [64], 'batch_sizes': [2], 'losses': ['ce_dice'],
           'epochs': 1, 'trials': 1, 'device': 'cpu', 'cpu_threads': 1, 'study_name': 'roi_smoke',
           'require_both': False, 'val_fraction': .4, 'test_fraction': 0}
    job = tmp_path / 'smoke_job'
    job.mkdir()
    result = run_search(server.cfg, raw, job)
    assert result['best'] is not None
    root = Path(result['output_dir'])
    records = read_json(root/'records.json')
    split = read_json(root/'split.json')
    assert split == fixed_split(records, False)
    assert split['test_ids'], 'The requested fractions must not erase inherited held-out test units.'
    request = {'study_name': raw['study_name'], 'trial': result['best']['number'], 'device': 'cpu'}
    evaluated = evaluate_trial(server.cfg, {**request, 'split': 'test'}, job)
    assert evaluated['metrics']['images'] == len(split['test_ids'])
    predicted = predict_folder(server.cfg, {**request, 'input_dir': server.cfg['input_dir']}, job)
    assert len(predicted['images']) == len(records) and not predicted['failures']
    exported = export_model(server.cfg, {**request, 'format': 'package'}, job)
    package = Path(exported['output_dir'])
    assert '65535' in read_json(package/'metadata.json')['input']
    env = {**os.environ, 'PYTHONPATH': '', 'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1'}
    process = subprocess.run([sys.executable, 'predict.py', '--input', server.cfg['input_dir'],
                              '--output', str(tmp_path/'standalone_predictions')], cwd=package,
                             env=env, capture_output=True, text=True, timeout=45)
    assert process.returncode == 0, process.stderr
    assert read_json(tmp_path/'standalone_predictions/summary.json')['images_processed'] == len(records)
    cfg = copy.deepcopy(server.cfg)
    cfg['training'].update(epochs=1, batch_size=2, image_size=64, base_channels=4, cpu_threads=1)
    trained = train(cfg)
    updated = train(cfg, trained/'best.pt')
    _, checkpoint, _ = load_model(updated/'best.pt')
    assert checkpoint['native_input'] and checkpoint['group_split'] == split['group_split']


def test_localizer_training_alias_returns_model_to_roi_detection(app, http):
    pytest.importorskip('torch')
    export, _ = export_fixture(app, native=False)
    payload = {'side': 'bottom', 'dataset': export['segmentation']['path'], 'epochs': 1, 'size': 64,
               'batch_size': 2, 'device': 'cpu', 'cpu_threads': 1}
    assert http('/api/segmentation/localizer/train', payload)[0] == 403
    code, response = http('/api/segmentation/localizer/train', payload, token=app.token, dashboard=True)
    assert code == 200, response
    app._roi_processes[response['job']['id']].wait(timeout=45)
    job = app.roi_job({'side': 'bottom'})['job']
    assert job['status'] == 'completed', job
    model = Path(job['model_path'])
    assert model.is_file()
    catalog = app.segmentation_catalog({'side': 'bottom'})
    assert any(Path(row['model_path']) == model for row in catalog['experiments'])
    from nilt.roi.learning import predict
    image = app.roi_project({'side': 'bottom'}).state()['images'][0]
    prediction = predict(image['path'], model)
    assert prediction['probabilities'].shape == (1, 128, 128)
    app.roi_project({'side': 'bottom'}).save_annotation({'image_id': image['id'], 'geometry_reviewed': False})
    assert app.roi_project({'side': 'bottom'}).localize_images({
        'method': 'segmentation', 'model_path': str(model), 'force': True})['summary']['errors'] == []
    code, response = http('/api/segmentation/localizer/evaluate', {**payload, 'model_path': str(model)},
                           token=app.token, dashboard=True)
    assert code == 200, response
    app._roi_processes[response['job']['id']].wait(timeout=45)
    assert app.roi_job({'side': 'bottom'})['job']['status'] == 'completed'
