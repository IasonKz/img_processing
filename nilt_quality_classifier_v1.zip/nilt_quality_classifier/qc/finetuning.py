from __future__ import annotations

import copy
import random
from pathlib import Path
from typing import Any, Sequence

from .comparison import run_model_comparison
from .config import deep_update, get, resolve_path
from .data import (
    DEFAULT_UNIT_ID_REGEX,
    ImageRecord,
    load_manifest,
    merge_old_and_new_records,
    scan_labeled_root,
)
from .models import load_torch_checkpoint
from .pipeline import run_training
from .utils import write_json


def _sample_old_train_groups(
    records: Sequence[ImageRecord],
    fraction: float,
    seed: int,
) -> list[ImageRecord]:
    if fraction >= 1.0:
        return list(records)
    if fraction <= 0:
        raise ValueError("fine_tune.replay.old_train_fraction must be > 0")

    rng = random.Random(seed)
    fixed = [record for record in records if record.split != "train"]
    train = [record for record in records if record.split == "train"]
    selected_groups: set[str] = set()
    for label in (0, 1):
        groups = sorted({record.group for record in train if record.label == label})
        rng.shuffle(groups)
        keep = max(1, int(round(len(groups) * fraction)))
        selected_groups.update(groups[:keep])
    selected_train = [record for record in train if record.group in selected_groups]
    return fixed + selected_train


def run_fine_tuning(config: dict[str, Any]) -> dict[str, Any]:
    base_checkpoint_path = resolve_path(
        get(config, "fine_tune.base_checkpoint"), config=config, must_exist=True
    )
    if base_checkpoint_path is None:
        raise ValueError("Set fine_tune.base_checkpoint")
    base_checkpoint = load_torch_checkpoint(base_checkpoint_path, map_location="cpu")

    manifest_value = get(config, "fine_tune.base_manifest") or base_checkpoint.get("manifest_path")
    base_manifest_path = resolve_path(manifest_value, config=config, must_exist=True)
    if base_manifest_path is None:
        raise ValueError(
            "No base manifest was found. Set fine_tune.base_manifest to the original split_manifest.csv."
        )
    old_records = load_manifest(base_manifest_path)

    new_root = resolve_path(
        get(config, "fine_tune.new_dataset_root"), config=config, must_exist=True
    )
    if new_root is None:
        raise ValueError("Set fine_tune.new_dataset_root")

    seed = int(get(config, "project.seed", 42))
    old_records = _sample_old_train_groups(
        old_records,
        fraction=float(get(config, "fine_tune.replay.old_train_fraction", 1.0)),
        seed=seed,
    )
    new_records = scan_labeled_root(
        new_root,
        source=str(get(config, "fine_tune.new_source_name", new_root.name)),
        recursive=bool(get(config, "fine_tune.recursive", True)),
        extensions=get(config, "data.image_extensions", base_checkpoint.get("data_config", {}).get("image_extensions")),
        unit_id_regex=str(
            get(
                config,
                "data.unit_id_regex",
                base_checkpoint.get("data_config", {}).get("unit_id_regex", DEFAULT_UNIT_ID_REGEX),
            )
        ),
        sample_weight=float(get(config, "fine_tune.replay.new_sample_weight", 1.0)),
    )
    combined = merge_old_and_new_records(
        old_records,
        new_records,
        validation_fraction=float(get(config, "fine_tune.new_validation_fraction", 0.15)),
        test_fraction=float(get(config, "fine_tune.new_test_fraction", 0.15)),
        seed=seed,
        new_sample_weight=float(get(config, "fine_tune.replay.new_sample_weight", 1.0)),
    )

    # Preserve the exact model input preprocessing used by the base model, while
    # allowing explicit overrides such as augmentations in the fine-tune YAML.
    effective = copy.deepcopy(config)
    checkpoint_data_config = copy.deepcopy(base_checkpoint.get("data_config", {}) or {})
    current_data_config = copy.deepcopy(config.get("data", {}) or {})
    effective["data"] = deep_update(checkpoint_data_config, current_data_config)
    effective.setdefault("model", {})["architecture"] = str(base_checkpoint["architecture"])
    effective["model"]["pretrained"] = False
    effective["model"]["dropout"] = float(base_checkpoint.get("dropout", 0.0))

    result = run_training(
        effective,
        records_override=combined,
        initial_checkpoint=base_checkpoint_path,
        mode="fine_tune",
    )

    if bool(get(config, "fine_tune.compare_on_legacy_test", True)):
        run_dir = Path(result["run_dir"])
        comparison_config = {
            "benchmark": {
                "manifest_path": str(base_manifest_path),
                "splits": ["test"],
            },
            "models": [
                {"name": "base", "checkpoint": str(base_checkpoint_path)},
                {"name": "candidate", "checkpoint": str(result["best_model"])},
            ],
            "inference": {
                "device": get(config, "training.device", "auto"),
                "batch_size": get(config, "training.validation_batch_size", get(config, "training.batch_size", 16)),
                "num_workers": get(config, "training.num_workers", 4),
                "mixed_precision": get(config, "training.mixed_precision", True),
                "show_progress": get(config, "training.show_progress", True),
            },
            "comparison": {
                "output_folder": str(run_dir / "legacy_test_comparison"),
                "export_error_images": False,
            },
            "promotion_rules": copy.deepcopy(config.get("promotion_rules", {}) or {}),
        }
        comparison = run_model_comparison(comparison_config)
        result["legacy_test_comparison"] = comparison
        write_json(result, run_dir / "run_summary_with_comparison.json")

    return result
