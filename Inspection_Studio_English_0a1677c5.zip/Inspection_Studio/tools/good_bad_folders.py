"""Standalone entry point for the preprocessing engine also used by the dashboard.

Use the project Python environment. Edit CSV_FILES / OUTPUT_ROOT / TRAY_ROOT
below for the IDE Run button, or pass --csv and --output on the command line.
"""
from pathlib import Path
import sys

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from nilt import dataset_preparation as _engine
from nilt.dataset_preparation import *  # Preserve the original tool's public helpers.

CSV_FILES = [Path("./input/top_bottom/evaluation_results.csv"), Path("./input/vig/evaluation_results.csv")]
OUTPUT_ROOT = Path("./prepared_dataset")
TRAY_ROOT = None


def main(argv=None):
    return _engine.main(argv, csv_files=CSV_FILES, output_root=OUTPUT_ROOT, tray_root=TRAY_ROOT)


if __name__ == "__main__":
    sys.exit(main())
