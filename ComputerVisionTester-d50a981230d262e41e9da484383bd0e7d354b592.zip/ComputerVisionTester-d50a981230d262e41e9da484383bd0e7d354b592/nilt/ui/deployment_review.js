"use strict";
const DeploymentQuality = window.DeploymentQuality = (() => {
  let catalog = null, detail = null, selected = null, selectedId = "", page = 1, serial = 0, opening = false, stateSignature = "", pendingRun = "";
  let galleryLimit = 12, dialogPosition = 0, assetsShown = [];
  const on = (id, fn) => $(id).addEventListener("click", () => Promise.resolve().then(fn).catch(error => notify(error.message, true)));
  const esc = value => escapeHtml(String(value ?? ""));
  const fmt = value => Number.isFinite(value) ? number(value, 6) : "Not available";
  const status = value => ({not_inspected:"No quality decision", good:"Good", bad:"Bad", review:"Review", unavailable:"Unavailable"}[value] || value);
  function parameters(extra = {}) { return new URLSearchParams({run:$("qr-run").value, ...(detail?.run === $("qr-run").value && detail.snapshot ? {snapshot:detail.snapshot} : {}), ...extra}); }
  function selectedSources(kind) { return [...$("qr-" + kind).querySelectorAll("input:checked")].map(input => input.value); }
  function renderSources(kind, rows) {
    const selectedValues = new Set(selectedSources(kind));
    $("qr-" + kind).innerHTML = rows.length ? rows.map(row => {
      const task = row.task || row.metadata?.task || "";
      const scope = row.scope || row.roi_scope || "whole_image";
      const label = `${task.toUpperCase()} / ${scope} · ${row.name || row.id} ${row.metadata?.candidate || ""}`;
      return `<label class="qr-source"><input type="checkbox" value="${esc(row.path)}" ${selectedValues.has(row.path) ? "checked" : ""}><span>${esc(label)}<small>${esc(row.created_utc || row.checkpoint_sha256?.slice(0, 16) || row.path)}</small></span></label>`;
    }).join("") : '<p class="hint">No completed evidence is available.</p>';
  }
  async function loadCatalog(run) {
    catalog = await api("/api/deployment/quality/catalog");
    selectOptions("qr-run", catalog.runs.map(row => ({value:row.path, label:`${row.pipeline || row.name} · ${row.started_utc} · ${row.review_ready ? "Review ready" : "Create review"}`})), "Complete a folder inspection first", run || $("qr-run").value);
    renderSources("sessions", catalog.sessions);
    renderSources("segmentation", catalog.segmentation);
  }
  function reset(message) {
    detail = null; selected = null; selectedId = "";
    $("qr-summary").textContent = message;
    $("qr-units").textContent = "No unit selected.";
    $("qr-detail").innerHTML = '<div class="empty">Open a completed inspection to review its units.</div>';
    $("qr-reports").textContent = "No generated quality reports.";
    $("qr-export-unit").disabled = true; $("qr-export-all").disabled = true;
    $("qr-page").textContent = "";
  }
  async function open(run) {
    if (opening) {if(run)pendingRun=run;return;}
    opening = true;
    try {
      const previousRun = detail?.run;
      await loadCatalog(run);
      const row = catalog.runs.find(item => item.path === $("qr-run").value);
      if (!row) { reset("No completed deployment inspections yet."); return; }
      if (!row.review_ready) { reset("Select optional evidence, then choose Create / update review. Inspection predictions remain unchanged."); return; }
      if (previousRun !== row.path) {selectedId="";page=1;}
      detail = null;
      await loadUnits();
    } finally { opening = false; if(pendingRun){const next=pendingRun;pendingRun="";await open(next);} }
  }
  function renderReports() {
    $("qr-reports").innerHTML = detail.reports.length ? detail.reports.map(row => `<div class="qr-report"><strong>${row.units} unit report${row.units === 1 ? "" : "s"}</strong><span>${esc(row.name)} · ${esc(row.snapshot)}</span><div class="actions"><a href="${esc(row.html_url)}" target="_blank" rel="noopener" class="secondary small">Open reports</a><a href="${esc(row.zip_url)}" class="primary small">Download ZIP</a><a href="${esc(row.csv_url)}" class="secondary small">CSV</a><a href="${esc(row.json_url)}" class="secondary small">Evidence JSON</a><button class="secondary small" data-qr-folder="${esc(row.path)}">Open folder</button></div></div>`).join("") : "Reports are generated only when requested.";
  }
  async function loadUnits() {
    const request = ++serial;
    const result = await api("/api/deployment/quality?" + parameters({page, search:$("qr-search").value, result:$("qr-result").value, view:$("qr-unit-view").value}));
    if (request !== serial) return;
    detail = result; page = result.pagination.page;
    $("qr-summary").innerHTML = `<div class="qr-kpis">${[[result.total_units,"UNITS"],[result.counts.good || 0,"GOOD ROUTING"],[result.counts.bad || 0,"BAD ROUTING"],[result.counts.review || 0,"REVIEW ROUTING"]].map(([value,label])=>`<div><strong>${value}</strong><span>${label}</span></div>`).join("")}</div><p>${esc(result.inspection.pipeline?.name || "Inspection")} · ${esc(result.created_utc)}</p><p class="hint">${esc(result.review_rule)}</p>${result.issues.length ? `<details><summary>${result.issues.length} evidence issue(s)</summary><ul>${result.issues.map(issue=>`<li>${esc(issue)}</li>`).join("")}</ul></details>` : ""}`;
    $("qr-units").innerHTML = result.units.length ? result.units.map(unit => `<button type="button" class="qr-unit ${unit.id === selectedId ? "active" : ""}" data-qr-unit="${esc(unit.id)}"><strong>${esc(unit.unit_id)}</strong><span class="qr-badge ${esc(unit.review_status)}">${esc(status(unit.review_status))}</span><small>${unit.coverage}/3 views with quality decisions · ${unit.items} records${unit.issues ? ` · ${unit.issues} issues` : ""}</small><div>${["top","bottom","vig"].map(view=>`<span class="qr-view-label ${esc(unit.views[view].result)}">${view.toUpperCase()}: ${esc(status(unit.views[view].result))}</span>`).join("")}</div></button>`).join("") : '<p class="empty">No units match these filters.</p>';
    $("qr-page").textContent = `Page ${page} / ${result.pagination.pages} · ${result.pagination.total} matching units`;
    $("qr-prev-page").disabled = page <= 1; $("qr-next-page").disabled = page >= result.pagination.pages;
    $("qr-export-all").disabled = result.total_units === 0;
    renderReports();
    if (result.units.some(unit => unit.id === selectedId)) await loadUnit(selectedId);
    else if (result.units.length) await loadUnit(result.units[0].id);
    else { selected = null; selectedId = ""; $("qr-detail").textContent = "No unit matches these filters."; $("qr-export-unit").disabled = true; }
  }
  async function loadUnit(id) {
    const request = ++serial;
    const result = await api("/api/deployment/quality/unit?" + parameters({unit:id}));
    if (request !== serial) return;
    selected = result; selectedId = id; galleryLimit = 12;
    $("qr-export-unit").disabled = false;
    document.querySelectorAll("[data-qr-unit]").forEach(button => button.classList.toggle("active", button.dataset.qrUnit === id));
    renderUnit();
  }
  function histogram(distribution, metric) {
    const bins = distribution.bins, max = Math.max(1, ...bins.map(bin=>bin.count));
    const low = bins[0].low, high = bins[bins.length-1].high;
    const x = value => 35 + Math.max(0, Math.min(1, (value-low)/(high-low))) * 420;
    const bars = bins.map((bin,index)=>`<rect x="${35+index*420/bins.length}" y="${115-bin.count/max*90}" width="${Math.max(1,420/bins.length-2)}" height="${bin.count/max*90}" class="qr-hist-bar"/>`).join("");
    const threshold = (value, cls) => Number.isFinite(value) && value >= low && value <= high ? `<path d="M${x(value)},23 V118" class="${cls}"/>` : "";
    return `<svg viewBox="0 0 490 150" role="img" aria-label="Distribution of ${esc(distribution.name)} among ${distribution.units} units"><text x="8" y="15">Units</text>${bars}${threshold(distribution.good_threshold,"qr-hist-good")}${threshold(distribution.bad_threshold,"qr-hist-bad")}<path d="M${x(metric.value)},20 V118" class="qr-hist-unit"/><text x="35" y="140">${fmt(low)}</text><text x="380" y="140">${fmt(high)}</text></svg>`;
  }
  function renderUnit() {
    const unit = selected.unit;
    const views = ["top","bottom","vig"];
    $("qr-detail").innerHTML = `<div class="card qr-unit-header"><span class="eyebrow">UNIT QUALITY REVIEW</span><h2>${esc(unit.unit_id)}</h2><div class="qr-header-line"><span class="qr-badge ${esc(unit.review_status)}">${esc(status(unit.review_status))}</span><span>Tray ${esc(unit.tray)} · ${esc(unit.identity_status)} identity · ${unit.coverage}/3 quality decisions</span></div><div class="qr-views">${views.map(view=>`<button class="secondary ${$("qr-image-view").value===view ? "active" : ""}" data-qr-view="${view}"><strong>${view.toUpperCase()}</strong><span>${esc(status(unit.views[view].result))}</span><small>${unit.views[view].classification} classification · ${unit.views[view].segmentation} segmentation</small></button>`).join("")}</div>${unit.issues.length ? `<details><summary>${unit.issues.length} evidence issue(s)</summary><ul>${unit.issues.map(issue=>`<li>${esc(issue)}</li>`).join("")}</ul></details>` : ""}</div><article class="card"><h2>Image evidence</h2><p class="hint">Model masks: red inner defects, blue outer defects. Geometry masks: cyan support region. Image previews do not change native data.</p><div id="qr-gallery" class="qr-gallery"></div><button id="qr-more" type="button" class="secondary small" hidden>Show more evidence</button></article><article class="card"><h2>Decision and model evidence</h2><p class="hint">${esc(selected.score_note)} Positive decision margin indicates distance inside the recorded Good or Bad region. Review-band distances describe proximity to a boundary.</p><div id="qr-evidence"></div></article><article class="card"><h2>Position within this inspection</h2><p class="hint">Comparable views, ROI kinds, model recipes and thresholds stay in separate distributions. Each physical unit contributes one observation per metric; score and defect-area summaries use maxima, pixel-probability summaries use minima.</p><div id="qr-statistics" class="qr-statistics"></div></article>`;
    renderGallery(); renderEvidence(); renderStatistics();
    $("qr-more").addEventListener("click", () => {galleryLimit += 12; renderGallery();});
  }
  function visibleItems() { return selected.unit.items.filter(item => !$("qr-image-view").value || item.view === $("qr-image-view").value); }
  function renderGallery() {
    if (!selected) return;
    const kind = $("qr-image-kind").value;
    const seen = new Set(); assetsShown = [];
    for (const item of visibleItems()) for (const id of item.assets) {
      const asset = selected.assets[id], key = item.view + ":" + id;
      if (seen.has(key) || kind && asset.kind !== kind) continue;
      seen.add(key); assetsShown.push({asset, item});
    }
    $("qr-gallery").innerHTML = assetsShown.length ? assetsShown.slice(0,galleryLimit).map(({asset,item},position) => `<button class="qr-image" data-qr-asset="${esc(asset.id)}" data-qr-position="${position}"><img loading="lazy" src="${esc(asset.preview_url)}" alt="${esc(item.view + ' ' + asset.kind + ' ' + item.image)}"><span><b>${esc(item.view.toUpperCase())} / ${esc(item.roi?.roi_id || item.scope)}</b>${esc(asset.kind.replaceAll("_"," "))} · ${esc(item.kind)}<small>${esc(item.image)}</small></span></button>`).join("") : '<p class="empty">No recorded images match this view and evidence category.</p>';
    $("qr-more").hidden = assetsShown.length <= galleryLimit;
  }
  function renderEvidence() {
    if (!selected) return;
    $("qr-evidence").innerHTML = visibleItems().filter(item=>item.kind !== "image").map(item => {
      const e = item.evidence, p = item.pipeline;
      const values = item.kind === "classification" ? [[e.score,"BAD SCORE"],[e.good_threshold,"GOOD BELOW"],[e.bad_threshold,"BAD AT / ABOVE"],[e.decision_margin,"DECISION MARGIN"]] : [[e.inner_pixels,"INNER PIXELS"],[e.outer_pixels,"OUTER PIXELS"],[e.defect_area_ratio,"DEFECT AREA RATIO"],[e.mean_selected_pixel_probability,"MEAN PIXEL PROBABILITY"]];
      const stageRows = (e.stage_results || []).map(stage=>`<tr><td>${esc(stage.name || stage.candidate || stage.source)}</td><td>${esc(stage.status)}</td><td>${esc(stage.predicted_class || "Not evaluated")}</td><td>${fmt(stage.source_threshold != null ? stage.raw_score : stage.score)}</td><td>${fmt(stage.source_threshold ?? stage.good_threshold ?? stage.threshold)}</td><td>${fmt(stage.source_threshold ?? stage.bad_threshold ?? stage.threshold)}</td></tr>`).join("");
      return `<div class="qr-evidence-card"><h3>${esc(item.view.toUpperCase())} / ${esc(item.roi?.roi_id || item.scope)} · ${esc(item.kind)} <span class="qr-badge ${esc(item.prediction || item.status)}">${esc(status(item.prediction || item.status))}</span></h3><p>${esc(item.image)}</p><div class="qr-metrics">${values.map(([value,label])=>`<div><strong>${fmt(value)}</strong><span>${label}</span></div>`).join("")}</div><p class="hint">${esc(p.candidate || p.model_type || p.workflow_name || p.system_name || "Recorded recipe")}${p.trial != null ? ` · trial ${esc(p.trial)}` : ""} · ${esc(p.checkpoint_sha256 || p.decision_sha256 || p.workflow_sha256 || p.system_sha256 || "")}${e.review_reason ? ` · ${esc(e.review_reason)}` : ""}</p>${e.stage_agreement?.evaluated ? `<p>Stage agreement: ${e.stage_agreement.agreeing} / ${e.stage_agreement.decisions} recorded stage decisions · ${e.stage_agreement.evaluated} evaluated · ${e.stage_agreement.skipped} skipped</p>` : ""}${stageRows ? `<details><summary>Pipeline stages</summary><div class="table-scroll"><table><thead><tr><th>Stage</th><th>Status</th><th>Decision</th><th>Score</th><th>Good below</th><th>Bad at / above</th></tr></thead><tbody>${stageRows}</tbody></table></div></details>` : ""}${p.models?.length ? `<details><summary>Recorded model recipe</summary><pre>${esc(JSON.stringify(p.models,null,2))}</pre></details>` : ""}${item.issues.length ? `<ul>${item.issues.map(issue=>`<li>${esc(issue)}</li>`).join("")}</ul>` : ""}</div>`;
    }).join("") || '<p class="empty">No model output is available for this view.</p>';
  }
  function renderStatistics() {
    if (!selected) return;
    const metrics = selected.unit.statistics.filter(metric => !$("qr-image-view").value || selected.distributions[metric.distribution].view === $("qr-image-view").value);
    $("qr-statistics").innerHTML = metrics.map(metric => {const distribution = selected.distributions[metric.distribution]; return `<div class="qr-stat-card"><h3>${esc(distribution.view.toUpperCase())} / ${esc(distribution.scope)} · ${esc(distribution.name)}</h3><div class="qr-metrics"><div><strong>${fmt(metric.value)}</strong><span>THIS UNIT</span></div><div><strong>${number(metric.percentile,2)}</strong><span>PERCENTILE</span></div><div><strong>${distribution.units}</strong><span>COHORT UNITS</span></div></div>${histogram(distribution,metric)}<p class="hint">Orange: this unit · median ${fmt(distribution.median)} · P05 ${fmt(distribution.p05)} · P95 ${fmt(distribution.p95)}</p></div>`;}).join("") || '<p class="empty">No comparable recorded score or defect-area distribution is available.</p>';
  }
  function showAsset(id, position = assetsShown.findIndex(row=>row.asset.id===id)) {
    if (position < 0 || assetsShown[position]?.asset.id !== id) return;
    dialogPosition = position;
    const {asset,item} = assetsShown[position];
    $("qr-image-large").src = asset.preview_url; $("qr-image-large").alt = item.image;
    globalThis.ImageInspector?.open("qr-image",asset.preview_url);
    $("qr-image-title").textContent = `${selected.unit.unit_id} · ${item.view.toUpperCase()} · ${asset.kind.replaceAll("_"," ")}`;
    $("qr-image-caption").textContent = `${position+1} / ${assetsShown.length} · ${item.roi?.roi_id || item.scope} · ${item.image} · SHA-256 ${asset.sha256}`;
    $("qr-image-native-link").href = asset.raw_url;
    if (!$("qr-image-dialog").open) $("qr-image-dialog").showModal();
  }
  function stepAsset(direction) {
    const next = dialogPosition + direction;
    if (next >= 0 && next < assetsShown.length) showAsset(assetsShown[next].asset.id, next);
  }
  on("qr-open",()=>{page=1;return open();}); on("qr-refresh",()=>open());
  $("qr-run").addEventListener("change",()=>{page=1;selectedId="";open().catch(error=>notify(error.message,true));});
  $("qr-units").addEventListener("click",event=>{const button=event.target.closest("[data-qr-unit]");if(button)loadUnit(button.dataset.qrUnit).catch(error=>notify(error.message,true));});
  $("qr-detail").addEventListener("click",event=>{const image=event.target.closest("[data-qr-asset]"),view=event.target.closest("[data-qr-view]");if(image)showAsset(image.dataset.qrAsset,Number(image.dataset.qrPosition));if(view){$("qr-image-view").value=view.dataset.qrView;galleryLimit=12;renderUnit();}});
  for(const id of ["qr-result","qr-unit-view"])$(id).addEventListener("change",()=>{page=1;loadUnits().catch(error=>notify(error.message,true));});
  let searchTimer;$("qr-search").addEventListener("input",()=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>{page=1;loadUnits().catch(error=>notify(error.message,true));},250);});
  for(const id of ["qr-image-view","qr-image-kind"])$(id).addEventListener("change",()=>{galleryLimit=12;if(selected)renderUnit();});
  on("qr-prev-page",()=>{page--;return loadUnits();});on("qr-next-page",()=>{page++;return loadUnits();});
  on("qr-build",async()=>{if(!$("qr-run").value)throw Error("Choose a completed inspection.");await api("/api/action",{action:"deployment-quality-review",run:$("qr-run").value,sessions:selectedSources("sessions"),segmentation:selectedSources("segmentation"),context_input:$("qr-context").value});notify("Quality-review snapshot started. Monitor the operation log.");await refresh();});
  async function exportReports(all) {
    if(!detail || !all && !selectedId)throw Error("Open a unit quality review first.");
    await api("/api/action",{action:"deployment-quality-export",run:detail.run,snapshot:detail.snapshot,units:all?[]:[selectedId],include_images:$("qr-include-images").checked});
    notify(all ? "Batch report generation started." : "Unit report generation started.");await refresh();
  }
  on("qr-export-unit",()=>exportReports(false));on("qr-export-all",()=>exportReports(true));
  on("qr-context-browse",async()=>{const result=await api("/api/pick-path",{kind:"folder",title:"Choose additional TOP / BOTTOM / VIG view images",initial:$("qr-context").value});if(result.path)$("qr-context").value=result.path;});
  $("qr-reports").addEventListener("click",event=>{const button=event.target.closest("[data-qr-folder]");if(button)api("/api/open-folder",{path:button.dataset.qrFolder}).then(result=>notify(result.message)).catch(error=>notify(error.message,true));});
  $("deploy-history").addEventListener("click",event=>{const button=event.target.closest("[data-deployment-quality]");if(button){tab("deployment-quality");open(button.dataset.deploymentQuality).catch(error=>notify(error.message,true));}});
  on("qr-image-close",()=>$("qr-image-dialog").close());on("qr-image-previous",()=>stepAsset(-1));on("qr-image-next",()=>stepAsset(1));
  document.addEventListener("keydown",event=>{if(!$("qr-image-dialog").open || ["INPUT","TEXTAREA","SELECT"].includes(event.target.tagName))return;if(["ArrowLeft","ArrowRight"].includes(event.key)){event.preventDefault();stepAsset(event.key==="ArrowLeft"?-1:1);}});
  function stateChanged(state) {
    const busy=(state.jobs||[]).some(job=>["running","unverified"].includes(job.status))||Object.values(state.segmentation||{}).some(row=>["running","starting","unverified"].includes(row.job.status))||Object.values(state.roi_jobs||{}).some(row=>["running","starting","queued","stopping","unverified"].includes(row.status));
    $("qr-build").disabled=busy;$("qr-export-unit").disabled=busy||!selected;$("qr-export-all").disabled=busy||!detail;
    const signature=JSON.stringify([(state.jobs||[]).map(job=>[job.id,job.status]),(state.experiments?.deployment||[]).map(row=>[row.path,row.report.status,row.report.quality_review?.snapshot])]);
    if(activeTab==="deployment-quality" && signature!==stateSignature && !busy && !opening)open().catch(error=>notify(error.message,true));
    stateSignature=signature;
  }
  return {open,stateChanged};
})();
