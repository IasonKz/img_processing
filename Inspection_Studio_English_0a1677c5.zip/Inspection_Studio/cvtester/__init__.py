"""Tools for comparing pretrained ImageNet classifiers."""
