"use strict";
/* Descriptive development analytics. These views never request test data. */
const Analytics = (() => {
  const palette = ['#0076bd','#008779','#955cc0','#c77e13','#c14866','#50677d','#725d3c','#346842'];
  const labels = {validation_ap:'Validation average precision',validation_roc_auc:'Validation ROC AUC',validation_balanced_accuracy:'Validation balanced accuracy'};
  const state = {run:null,objective:'',model:'',parameter:'',log:true,dimensions:[],radarDimensions:null,radarLog:false,radarModels:null,performanceModels:null,data:null};
  const finite = value => (typeof value === 'number' || typeof value === 'string') && String(value).trim() !== '' && Number.isFinite(Number(value));
  const esc = value => escapeHtml(value);
  const valueOf = value => finite(value) ? Number(value) : null;
  function params(row) {
    try { const p = typeof row.params_json === 'string' ? JSON.parse(row.params_json) : row.params_json || row.params; return p && typeof p === 'object' && !Array.isArray(p) ? p : {}; } catch { return {}; }
  }
  function trials(data) {
    return (data.trials || []).map(row => ({...row,model:String(row.model || 'Unknown'),objective:row.objective || 'validation_ap',value:valueOf(row.value),trial:valueOf(row.trial),seconds:valueOf(row.seconds),parameters:params(row)}));
  }
  const complete = rows => rows.filter(row => row.state === 'COMPLETE' && row.value !== null && row.trial !== null);
  const colorFor = (model,models) => palette[Math.max(0,models.indexOf(model)) % palette.length];
  function options(values,selected,allLabel) { return (allLabel ? `<option value="">${allLabel}</option>` : '') + values.map(value => `<option value="${esc(value)}"${value===selected?' selected':''}>${esc(labels[value] || value)}</option>`).join(''); }
  function svg(id,label) { return `<svg id="${id}" class="chart analytics-chart" viewBox="0 0 560 225" role="img" aria-label="${esc(label)}"></svg>`; }
  function card(id,title,body,wide=false) { return `<article id="${id}" class="card analytics-card${wide?' analytics-wide':''}"><h2>${title}</h2>${body}</article>`; }
  function legend(models,allModels) { return `<div class="analytics-legend">${models.map(model=>`<span><i style="background:${colorFor(model,allModels)}"></i>${esc(model)}</span>`).join('')}</div>`; }
  function empty(message) { return `<p class="empty">${esc(message)}</p>`; }
  function line(id,sets,xLabel) {
    plot(id,sets.map(s=>({...s,hideLegend:true})),xLabel,[0,1]);
    // The shared helper's SVG is followed by a wrapping HTML legend for long lists.
  }
  function axes(xmin,xmax,xlabel,ylabel,xformat=null,xticks=null) {
    const X=v=>48+(v-xmin)/(xmax-xmin||1)*488, Y=v=>181-v*157;
    let markup='';
    for(let i=0;i<5;i++) { const y=i/4; markup+=`<line x1="48" y1="${Y(y)}" x2="536" y2="${Y(y)}" stroke="#e0e7ed"/><text x="40" y="${Y(y)+4}" text-anchor="end">${number(y,2)}</text>`; }
    for(const x of xticks || Array.from({length:5},(_,i)=>xmin+(xmax-xmin)*i/4))markup+=`<text x="${X(x)}" y="199" text-anchor="middle">${esc(xformat?xformat(x):number(x,1))}</text>`;
    markup+=`<text x="292" y="221" text-anchor="middle">${esc(xlabel)}</text><text x="48" y="13">${esc(ylabel)}</text>`;
    return {markup,X,Y};
  }
  function dots(id,rows,models,key,logScale=false,categories=null) {
    const valid=rows.filter(row=>key==='minutes'?row.seconds!==null&&row.seconds>=0:row.parameters[key]!==undefined&&row.parameters[key]!==null);
    const raw=row=>key==='minutes'?row.seconds/60:categories?categories.indexOf(String(row.parameters[key])):Number(row.parameters[key]);
    const eligible=valid.filter(row=>Number.isFinite(raw(row))&&(!logScale||raw(row)>0));
    if(!eligible.length) { $(id).innerHTML='<text x="280" y="110" text-anchor="middle">No matching completed trials</text>';return; }
    const xvalue=row=>logScale?Math.log10(raw(row)):raw(row);
    let xmin=Math.min(...eligible.map(xvalue)),xmax=Math.max(...eligible.map(xvalue));
    if(xmin===xmax){xmin-=.5;xmax+=.5;}
    const formatter=categories?v=>Number.isInteger(v)?categories[v]||'':'' : logScale?v=>Number(10**v).toExponential(1):null;
    const a=axes(xmin,xmax,key==='minutes'?'Recorded training minutes':key+(logScale?' · log scale':''),'Objective score',formatter,categories?categories.map((_,index)=>index):null);
    $(id).innerHTML=a.markup+eligible.map(row=>`<circle tabindex="0" cx="${a.X(xvalue(row))}" cy="${a.Y(row.value)}" r="5" fill="${colorFor(row.model,models)}" fill-opacity=".8" stroke="#fff" stroke-width="1"><title>${esc(row.model)} · trial ${row.trial}\n${esc(key)}: ${esc(key==='minutes'?number(raw(row),2):row.parameters[key])}\n${esc(labels[row.objective]||row.objective)}: ${number(row.value)}</title></circle>`).join('');
  }
  function parallel(id,rows,dimensions,models) {
    const usable=rows.filter(row=>dimensions.every(key=>row.parameters[key]!==undefined&&row.parameters[key]!==null&&row.parameters[key]!==''));
    if(!dimensions.length||!usable.length){$(id).innerHTML='<text x="280" y="110" text-anchor="middle">Select parameters shared by completed trials</text>';return;}
    const domains=dimensions.map(key=>{
      const values=usable.map(row=>row.parameters[key]),numeric=values.every(finite);
      return {key,numeric,min:numeric?Math.min(...values.map(Number)):0,max:numeric?Math.max(...values.map(Number)):1,categories:numeric?[]:[...new Set(values.map(String))]};
    });
    domains.push({key:'Objective',numeric:true,min:0,max:1});
    const X=index=>50+index/(domains.length-1)*470,Y=(row,d)=>{
      const v=d.key==='Objective'?row.value:row.parameters[d.key];
      const fraction=d.numeric?(d.max===d.min?0.5:(Number(v)-d.min)/(d.max-d.min)):(d.categories.length===1?0.5:d.categories.indexOf(String(v))/(d.categories.length-1));
      return 177-fraction*133;
    };
    const short=(text,max=19)=>text.length>max?text.slice(0,max-1)+'…':text;
    const axisNumber=value=>value!==0 && (Math.abs(value)<.001||Math.abs(value)>=10000)?value.toExponential(1):number(value,3);
    let markup=domains.map((d,i)=>`<line x1="${X(i)}" y1="44" x2="${X(i)}" y2="177" stroke="#b9c8d4"/><text x="${X(i)}" y="20" text-anchor="middle">${esc(short(d.key))}<title>${esc(d.key)}</title></text><text x="${X(i)}" y="37" text-anchor="middle">${esc(d.numeric?axisNumber(d.max):short(d.categories.at(-1)||'',13))}</text><text x="${X(i)}" y="194" text-anchor="middle">${esc(d.numeric?axisNumber(d.min):short(d.categories[0]||'',13))}</text>`).join('');
    const details=row=>`${row.model} · trial ${row.trial}\n${dimensions.map(key=>`${key}: ${row.parameters[key]}`).join('\n')}\nObjective: ${row.value}`;
    markup+=usable.map(row=>`<g data-chart-series="${esc(row.model+' · trial '+row.trial)}" tabindex="0" role="button"><polyline points="${domains.map((d,i)=>`${X(i)},${Y(row,d)}`).join(' ')}" fill="none" stroke="${colorFor(row.model,models)}" stroke-opacity=".28" stroke-width="1.5"><title>${esc(details(row))}</title></polyline></g>`).join('');
    $(id).innerHTML=markup;
    globalThis.ChartInteraction?.bind($(id),usable.map(row=>({key:row.model+' · trial '+row.trial,points:domains.map((d,i)=>({x:X(i),y:Y(row,d),label:details(row)}))})));
  }
  // Radar charts are descriptive profiles, never a combined optimization score.
  function bestByArchitecture(rows) {
    const best=new Map();
    for(const row of complete(rows)) {
      const previous=best.get(row.model);
      if(!previous||row.value>previous.value||(row.value===previous.value&&row.trial<previous.trial))best.set(row.model,row);
    }
    return [...best.values()].sort((a,b)=>b.value-a.value||a.model.localeCompare(b.model));
  }
  function radarChoices(items,selected,attribute) {
    return `<fieldset class="analytics-dimensions analytics-radar-choices"><legend>Visible series</legend>${items.map(item=>`<label><input type="checkbox" ${attribute}="${esc(item)}"${selected.includes(item)?' checked':''}>${esc(item)}</label>`).join('')}</fieldset>`;
  }
  function radarSVG(id,title,domains,series) {
    if(domains.length<3)return empty('Select at least three shared numeric axes to draw a radar. Exact values remain available below.');
    if(!series.length)return empty('Select at least one series with all required values.');
    const cx=330,cy=215,radius=144,point=(i,value)=>{const angle=-Math.PI/2+i/domains.length*Math.PI*2;return [cx+Math.cos(angle)*radius*value,cy+Math.sin(angle)*radius*value];};
    const points=values=>values.map((value,i)=>point(i,value).join(',')).join(' ');
    let markup='';
    for(let ring=1;ring<=4;ring++){const value=ring/4;markup+=`<polygon points="${points(domains.map(()=>value))}" class="analytics-radar-ring"/><text x="${cx+7}" y="${cy-radius*value-4}" class="analytics-radar-tick">${value.toFixed(2)}</text>`;}
    domains.forEach((domain,index)=>{
      const end=point(index,1),label=point(index,1.19),cos=Math.cos(-Math.PI/2+index/domains.length*Math.PI*2);
      const anchor=cos<-.2?'end':cos>.2?'start':'middle';
      const words=domain.label.replaceAll('_',' ').split(' '),lines=[''];
      for(const word of words){if(lines.at(-1).length+word.length>22)lines.push(word);else lines[lines.length-1]+=(lines.at(-1)?' ':'')+word;}
      markup+=`<line x1="${cx}" y1="${cy}" x2="${end[0]}" y2="${end[1]}" class="analytics-radar-spoke"/><text x="${label[0]}" y="${label[1]-4*(lines.length-1)}" text-anchor="${anchor}" class="analytics-radar-label"><title>${esc(domain.label+' · '+domain.description)}</title>${lines.map((text,i)=>`<tspan x="${label[0]}" dy="${i?13:0}">${esc(text)}</tspan>`).join('')}<tspan x="${label[0]}" dy="14" class="analytics-radar-scale">${esc(domain.scale||'0–1')}</tspan></text>`;
    });
    series.forEach(item=>{
      const details=item.values.map((value,index)=>`${domains[index].label}: ${item.raw[index]}`).join('\n');
      markup+=`<g class="analytics-radar-series" data-chart-series="${esc(item.name)}" tabindex="0" role="button"><polygon tabindex="0" data-radar-series="${esc(item.name)}" points="${points(item.values)}" fill="${item.color}" fill-opacity=".065" stroke="${item.color}" stroke-width="2.3"><title>${esc(item.name+'\n'+details)}</title></polygon>${item.values.map((value,index)=>{const p=point(index,value);return `<circle tabindex="0" cx="${p[0]}" cy="${p[1]}" r="4" fill="${item.color}" stroke="#fff" stroke-width="1.3"><title>${esc(item.name+'\n'+domains[index].label+': '+item.raw[index]+'\nNormalized position: '+value.toFixed(4))}</title></circle>`;}).join('')}</g>`;
    });
    return `<svg id="${id}" class="analytics-radar" viewBox="0 0 660 440" role="img" aria-label="${esc(title)}"><title>${esc(title)}</title>${markup}</svg>`;
  }
  function rawValue(value) {return finite(value)?String(value):'Not available';}
  function radarCell(value) {
    if(value===null||value===undefined)return '<td>Not available</td>';
    const shown=finite(value)?String(Number(Number(value).toPrecision(7))):String(value);
    return `<td title="${esc(value)}">${esc(shown)}</td>`;
  }
  function winnerRadar(done,models) {
    const winners=bestByArchitecture(done),names=winners.map(row=>row.model);
    if(!winners.length)return empty('Completed trials with recorded parameters will appear here. Failed, pruned, cancelled and unfinished trials are excluded.');
    const visible=(state.radarModels===null?names.slice(0,6):state.radarModels).filter(name=>names.includes(name)),chosen=winners.filter(row=>visible.includes(row.model));
    // Only shared numeric fields become axes. A missing or categorical field has no radial position.
    const keys=chosen.length?Object.keys(chosen[0].parameters).filter(key=>chosen.every(row=>finite(row.parameters[key]))).sort():[];
    const dimensions=(state.radarDimensions===null?keys.slice(0,6):state.radarDimensions).filter(key=>keys.includes(key));
    const domains=dimensions.map(key=>{
      const observed=done.filter(row=>finite(row.parameters[key])).map(row=>Number(row.parameters[key]));
      const log=state.radarLog&&observed.every(value=>value>0),values=observed.map(value=>log?Math.log10(value):value),min=Math.min(...values),max=Math.max(...values);
      return {key,label:key,min,max,log,scale:min===max?'Constant · center 0.5':log?'Log10 · observed range':'Linear · observed range',description:`${rawValue(Math.min(...observed))} to ${rawValue(Math.max(...observed))}${min===max?' (constant, plotted at 0.5)':''}`};
    });
    const series=chosen.map(row=>({name:`${row.model} · trial ${row.trial}`,color:colorFor(row.model,models),raw:domains.map(d=>row.parameters[d.key]),values:domains.map(d=>d.min===d.max?.5:((d.log?Math.log10(Number(row.parameters[d.key])):Number(row.parameters[d.key]))-d.min)/(d.max-d.min))}));
    const allKeys=[...new Set(chosen.flatMap(row=>Object.keys(row.parameters)))].sort();
    return `<p class="hint">Highest completed ${esc(labels[state.objective]||state.objective)} trial per architecture. This is a parameter profile, not a performance score: a larger polygon does not mean a better model.</p>`+
      radarChoices(names,visible,'data-radar-model')+
      `<fieldset class="analytics-dimensions"><legend>Shared numeric parameters · select 3–8 axes</legend>${keys.map(key=>`<label><input type="checkbox" data-radar-axis="${esc(key)}"${dimensions.includes(key)?' checked':''}>${esc(key)}</label>`).join('')||'<p class="hint">No shared numeric parameters for the selected series.</p>'}</fieldset>`+
      `<label class="analytics-radar-log"><input type="checkbox" id="analytics-radar-log"${state.radarLog?' checked':''}>Use logarithmic scales for strictly positive axes</label>`+
      `<div class="analytics-radar-layout"><div>${radarSVG('search-winner-radar','Winning trial hyperparameter profiles',domains,series)}${legend(chosen.map(row=>row.model),models)}</div>`+
      `<div class="analytics-radar-context"><h3>How to read this chart</h3><p>Each axis spans the observed values from all completed trials of the selected objective and architecture filter. These are observed ranges, not the configured search limits.</p><p>Constant parameters sit at 0.5. Nonpositive ranges always use linear scaling. Categories and absent values appear only in the table.</p><dl>${domains.map(d=>`<dt>${esc(d.key)}</dt><dd>${esc(d.description)} · ${d.log?'log10':'linear'}</dd>`).join('')}</dl></div></div>`+
      `<details class="analytics-radar-values" open><summary>Exact winning parameters</summary><p class="hint">Numeric display uses up to seven significant digits. Hover a cell for its full recorded value.</p><div class="table-scroll"><table><thead><tr><th>Architecture</th><th>Trial</th><th>${esc(labels[state.objective]||state.objective)}</th>${allKeys.map(key=>`<th>${esc(key)}</th>`).join('')}</tr></thead><tbody>${chosen.map(row=>`<tr><td>${esc(row.model)}</td><td>${row.trial}</td>${radarCell(row.value)}${allKeys.map(key=>radarCell(row.parameters[key])).join('')}</tr>`).join('')}</tbody></table></div></details>`;
  }
  function performanceRadar(candidates) {
    if(!candidates.length)return empty('Evaluated selection candidates will appear here.');
    const names=candidates.map(candidate=>candidate.name);
    const visible=state.performanceModels===null?names.slice(0,6):state.performanceModels;
    const chosen=candidates.filter(candidate=>visible.includes(candidate.name));
    const domains=[
      {key:'pr_auc_bad',label:'Average precision · bad',description:'Ranking quality; higher is better'},
      {key:'balanced_accuracy',label:'Balanced accuracy',description:'Mean recall across the two reference classes'},
      {key:'bad_escape_rate',label:'Bad detection',invert:true,description:'1 − bad escape rate; higher is better'},
      {key:'good_reject_rate',label:'Good acceptance',invert:true,description:'1 − good reject rate; higher is better'},
    ];
    const eligible=chosen.filter(candidate=>domains.every(d=>finite(candidate.selection_metrics[d.key])&&Number(candidate.selection_metrics[d.key])>=0&&Number(candidate.selection_metrics[d.key])<=1));
    const series=eligible.map(candidate=>({name:candidate.name,color:palette[candidates.indexOf(candidate)%palette.length],raw:domains.map(d=>d.invert?`1 − ${candidate.selection_metrics[d.key]} = ${1-Number(candidate.selection_metrics[d.key])}`:candidate.selection_metrics[d.key]),values:domains.map(d=>d.invert?1-Number(candidate.selection_metrics[d.key]):Number(candidate.selection_metrics[d.key]))}));
    const missing=chosen.filter(candidate=>!eligible.includes(candidate));
    return `<p class="hint">Selection split only. All four axes use the fixed 0–1 scale with higher values outward. Bad detection = 1 − bad escape; good acceptance = 1 − good rejection.</p>`+
      radarChoices(names,visible,'data-performance-model')+
      `<div class="analytics-radar-layout"><div>${radarSVG('model-performance-radar','Selection performance profiles across candidates',domains,series)}${legend(eligible.map(c=>c.name),names)}</div><div class="analytics-radar-context"><h3>Compare the operating point</h3><p>Average precision measures ranking across thresholds. The other axes describe the candidate's saved decision threshold on the selection split.</p><p>A radar is a visual comparison, not a new aggregate score. Check the confusion matrices and the exact rejection and escape rates before selecting a candidate.</p>${missing.length?`<p class="callout">No polygon for ${missing.map(c=>esc(c.name)).join(', ')}: at least one required metric is missing or outside 0–1. Missing values are never replaced with zero.</p>`:''}</div></div>`+
      `<details class="analytics-radar-values" open><summary>Exact selection metrics</summary><p class="hint">Numeric display uses up to seven significant digits. Hover a cell for its full value.</p><div class="table-scroll"><table><thead><tr><th>Candidate</th>${domains.map(d=>`<th>${esc(d.label)}</th>`).join('')}</tr></thead><tbody>${chosen.map(candidate=>`<tr><td>${esc(candidate.name)}</td>${domains.map(d=>{const value=valueOf(candidate.selection_metrics[d.key]);return radarCell(value===null?null:d.invert?1-value:value);}).join('')}</tr>`).join('')}</tbody></table></div></details>`;
  }
  function search(data) {
    const target=$('analytics-search');if(!target)return;
    const all=trials(data),models=[...new Set(all.map(row=>row.model))],objectives=[...new Set(all.map(row=>row.objective))];
    if(!objectives.includes(state.objective))state.objective=objectives[0]||'validation_ap';
    if(state.model&&!models.includes(state.model))state.model='';
    const scoped=all.filter(row=>row.objective===state.objective&&(!state.model||row.model===state.model)),done=complete(scoped),shownModels=models.filter(m=>!state.model||m===state.model);
    const keys=[...new Set(done.flatMap(row=>Object.keys(row.parameters)))].sort();
    if(!keys.includes(state.parameter))state.parameter=keys.includes('learning_rate')?'learning_rate':keys[0]||'';
    state.dimensions=state.dimensions.filter(key=>keys.includes(key));
    if(!state.dimensions.length)state.dimensions=keys.slice(0,4);
    const values=done.filter(row=>row.parameters[state.parameter]!==undefined&&row.parameters[state.parameter]!==null).map(row=>row.parameters[state.parameter]);
    const numeric=values.length>0&&values.every(finite),positive=numeric&&values.every(value=>Number(value)>0),categories=numeric?null:[...new Set(values.map(String))];
    target.innerHTML=`<div class="analytics-heading"><div><span class="eyebrow">SEARCH ANALYTICS</span><h2>Understand the search</h2><p class="hint">Development data only. Hover or focus a point for its recorded values.</p></div><div class="analytics-controls"><label>Architecture<select id="analytics-model">${options(models,state.model,'All architectures')}</select></label><label>Objective<select id="analytics-objective">${options(objectives,state.objective)}</select></label></div></div>`+
      `<div class="analytics-grid">`+
      card('search-overview','Completed trial objectives',svg('search-history-chart','Completed trial objective by architecture')+legend(shownModels,models)+'<p class="hint">Trial number is local to each architecture. A completed score is a validation result; failures and timeouts never become zero scores.</p>')+
      card('search-efficiency','Training time and score',svg('search-efficiency-chart','Training duration versus validation objective')+legend(shownModels,models)+'<p class="hint">Recorded training duration, not inference latency. Only completed trials with recorded duration are shown.</p>')+
      card('search-learning-overlay','Validation learning curves',svg('search-learning-chart','Validation average precision by epoch')+legend(shownModels,models)+'<p class="hint">Average precision for the bad class. One line per recorded trial; architecture colors are shared across charts.</p>')+
      card('search-status-breakdown','Trial outcomes',`<div class="analytics-outcomes">${['COMPLETE','PRUNED','FAILED','TIMEOUT','PAUSED','CANCELLED','RUNNING','WAITING'].map(status=>{const count=scoped.filter(row=>outcome(row)===status).length;return `<div><strong>${count}</strong><span>${status}</span><div class="analytics-track"><i style="width:${scoped.length?100*count/scoped.length:0}%"></i></div></div>`;}).join('')}</div><p class="hint">Counts use the active architecture and objective filters. A timeout records a budget stop, not poor predictive performance.</p>`)+
      card('search-parameter','Parameter and score',`<div class="analytics-controls"><label>Parameter<select id="analytics-parameter">${options(keys,state.parameter)}</select></label><label class="checkbox"><input id="analytics-log" type="checkbox"${state.log&&positive?' checked':''}${positive?'':' disabled'}>Logarithmic x-axis</label></div>`+svg('search-parameter-chart','Chosen hyperparameter versus validation objective')+'<p class="hint">Observed associations depend on the other parameters and trial budget. This chart is not causal parameter importance.</p>')+
      card('search-parallel','Parameter combinations',`<fieldset class="analytics-dimensions"><legend>Axes · select up to five</legend>${keys.map(key=>`<label><input type="checkbox" data-analytics-dimension="${esc(key)}"${state.dimensions.includes(key)?' checked':''}>${esc(key)}</label>`).join('')||'<p class="hint">Parameters appear after completed trials are recorded.</p>'}</fieldset>`+svg('search-parallel-chart','Parallel coordinates of actual trial parameters')+'<p class="hint">Each line is one completed trial with all selected parameters. Numeric axes use independent linear scales; categorical positions are arbitrary. Hover a line for exact values.</p>')+
      card('search-winner-profiles','Winning parameter profiles',winnerRadar(done,models),true)+
      '</div>';
    line('search-history-chart',shownModels.map(model=>({name:model,color:colorFor(model,models),points:done.filter(row=>row.model===model).sort((a,b)=>a.trial-b.trial).map(row=>[row.trial,row.value])})),'Trial');
    dots('search-efficiency-chart',done,models,'minutes');
    const histories=(data.histories||[]).filter(item=>{const model=historyModel(item.name,models);return model&&(!state.model||model===state.model);});
    line('search-learning-chart',histories.map(item=>({name:item.name,color:colorFor(historyModel(item.name,models),models),points:(item.history||[]).filter(row=>finite(row.epoch)&&finite(row.val_pr_auc_bad)).map(row=>[Number(row.epoch),Number(row.val_pr_auc_bad)])})),'Epoch');
    dots('search-parameter-chart',done,models,state.parameter,state.log&&positive,categories);
    parallel('search-parallel-chart',done,state.dimensions,models);
    for(const [id,key]of [['analytics-model','model'],['analytics-objective','objective'],['analytics-parameter','parameter']])$(id).addEventListener('change',event=>{state[key]=event.target.value;if(key!=='parameter'){state.radarModels=null;state.radarDimensions=null;}search(state.data);});
    $('analytics-log').addEventListener('change',event=>{state.log=event.target.checked;search(state.data);});
    target.querySelectorAll('[data-analytics-dimension]').forEach(input=>input.addEventListener('change',event=>{const key=event.target.dataset.analyticsDimension;if(event.target.checked){if(state.dimensions.length>=5){event.target.checked=false;return;}state.dimensions.push(key);}else state.dimensions=state.dimensions.filter(value=>value!==key);parallel('search-parallel-chart',done,state.dimensions,models);}));
    target.querySelectorAll('[data-radar-model]').forEach(input=>input.addEventListener('change',()=>{state.radarModels=[...target.querySelectorAll('[data-radar-model]')].filter(item=>item.checked).map(item=>item.dataset.radarModel);state.radarDimensions=null;search(state.data);}));
    target.querySelectorAll('[data-radar-axis]').forEach(input=>input.addEventListener('change',event=>{const checked=[...target.querySelectorAll('[data-radar-axis]')].filter(item=>item.checked);if(checked.length>8){event.target.checked=false;return;}state.radarDimensions=checked.map(item=>item.dataset.radarAxis);search(state.data);}));
    const radarLog=$('analytics-radar-log');if(radarLog)radarLog.addEventListener('change',event=>{state.radarLog=event.target.checked;search(state.data);});
    globalThis.ChartInteraction?.bindRadars(target);
  }
  function historyModel(name,models) { return models.find(model=>String(name).split('/').includes(model)||String(name).split('/').some(part=>part.startsWith(model+'_seed')))||null; }
  function outcome(row) {
    const value=String(row.outcome||row.state||'').toUpperCase();
    if(value.includes('CANCEL'))return 'CANCELLED';if(value.includes('TIMEOUT'))return 'TIMEOUT';if(value.includes('PAUSE'))return 'PAUSED';if(row.state==='FAIL'||value==='FAILED')return 'FAILED';return ['COMPLETE','PRUNED','RUNNING','WAITING'].includes(value)?value:String(row.state||'WAITING');
  }
  function comparison(data) {
    const host=$('analytics-compare');if(!host)return;
    const candidates=(data.candidates||[]).filter(candidate=>candidate.selection_metrics),metrics=[['pr_auc_bad','AP · bad',false],['balanced_accuracy','Balanced accuracy',false],['bad_escape_rate','Bad escape',true],['good_reject_rate','Good rejection',true]];
    host.innerHTML=`<div class="analytics-heading"><div><span class="eyebrow">SELECTION SPLIT</span><h2>Compare candidate decisions</h2><p class="hint">All values below come from the recorded selection split. AP describes ranking; escape and rejection depend on the saved decision threshold.</p></div></div>`+
      card('model-comparison','Performance across candidates',candidates.length?`<div class="analytics-comparison">${metrics.map(([key,label,lower])=>`<div><h3>${label}</h3><p class="hint">${lower?'Lower is better':'Higher is better'}</p>${candidates.map((candidate,index)=>{const value=valueOf(candidate.selection_metrics[key]);return `<div class="analytics-row"><span title="${esc(candidate.name)}">${esc(candidate.name)}</span><div class="analytics-track">${value===null?'':`<i style="width:${Math.max(0,Math.min(1,value))*100}%;background:${palette[index%palette.length]}"></i>`}</div><strong>${value===null?'Not available':number(value)}</strong></div>`;}).join('')}</div>`).join('')}</div>`:empty('Completed and evaluated candidates will appear here.'))+
      card('model-confusions','Confusion matrices · every candidate',`<div class="analytics-matrices">${candidates.map(candidate=>matrix(candidate)).join('')||empty('No candidate confusion matrices are available.')}</div><p class="hint">Counts and percentages within each true class are shown. Bad is the positive class. Repeated use of selection results for development does not provide independent test qualification.</p>`)+
      card('model-radar-profiles','Selection performance profiles',performanceRadar(candidates));
    host.querySelectorAll('[data-performance-model]').forEach(input=>input.addEventListener('change',()=>{state.performanceModels=[...host.querySelectorAll('[data-performance-model]')].filter(item=>item.checked).map(item=>item.dataset.performanceModel);comparison(state.data);}));
    globalThis.ChartInteraction?.bindRadars(host);
  }
  function matrix(candidate) {
    const m=candidate.selection_metrics,keys=['bad_detected_TP','bad_passed_as_good_FN','good_rejected_as_bad_FP','good_accepted_TN'];
    if(!m||!keys.every(key=>finite(m[key])))return '';
    const values=keys.map(key=>Number(m[key])),[tp,fn,fp,tn]=values;
    const cell=(value,total,label,correct)=>`<div class="${correct?'correct':'wrong'}"><strong>${value}</strong>${label}<small>${total?number(value/total*100,1)+'% of true '+(label==='TP'||label==='FN'?'bad':'good'):'No reference images'}</small></div>`;
    return `<section><h3>${esc(candidate.name)}</h3><div class="cm"><div class="axis">Reference / prediction</div><div class="axis">Bad</div><div class="axis">Good</div><div class="axis">Bad</div>${cell(tp,tp+fn,'TP',true)}${cell(fn,tp+fn,'FN',false)}<div class="axis">Good</div>${cell(fp,fp+tn,'FP',false)}${cell(tn,fp+tn,'TN',true)}</div><p class="hint">${tp+fn} bad / ${fp+tn} good reference images</p></section>`;
  }
  function render(data) {if(!data)return;if(state.run!==data.path){state.run=data.path;state.model='';state.objective='';state.parameter='';state.dimensions=[];state.radarDimensions=null;state.radarModels=null;state.performanceModels=null;state.radarLog=false;}state.data=data;search(data);comparison(data);}
  return {render};
})();
