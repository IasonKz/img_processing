"use strict";
(() => {
  const task = document.documentElement.dataset.segmentationContext || document.documentElement.dataset.segmentationTask;
  const studio = document.body.classList.contains("integrated-studio");
  const host = window.top.WorkspaceStudio;
  let scheduled = false, wasFocused = false;
  function resize() {
    scheduled = false;
    if (!window.frameElement) return;
    const height = Math.ceil(document.body.getBoundingClientRect().height);
    if (height > 0 && Math.abs(height - window.frameElement.getBoundingClientRect().height) > 1) {
      window.frameElement.style.height = height + "px";
      window.parent.dispatchEvent(new Event("embedded-content-resized"));
    }
  }
  function schedule() { if (!scheduled) { scheduled = true; requestAnimationFrame(resize); } }
  function layout() {
    const focus = !!window.top.document.fullscreenElement;
    document.body.classList.toggle("annotation-focus", focus);
    if (!studio) {
      document.body.style.setProperty("--workspace-height", window.top.innerHeight + "px");
      const viewport = document.getElementById("viewport");
      let top = viewport.getBoundingClientRect().top, owner = window;
      while (owner !== window.top) { top += owner.frameElement.getBoundingClientRect().top; owner = owner.parent; }
      const controls = [...document.querySelectorAll(".stage-footer,.action-bar")].reduce((height, el) => height + el.getBoundingClientRect().height, 0);
      document.body.style.setProperty("--canvas-height", Math.max(260, focus ? window.top.innerHeight - top - controls - 20 : Math.min(600, window.top.innerHeight * .54)) + "px");
      document.body.style.setProperty("--queue-height", Math.max(260, window.top.innerHeight - 440) + "px");
      if (focus !== wasFocused) requestAnimationFrame(() => window.TopsegEditor?.fit());
    }
    wasFocused = focus;
    document.querySelectorAll("iframe").forEach(frame => frame.contentWindow?.NiltEmbedded?.layout());
    schedule();
  }
  window.NiltEmbedded = {layout};
  if (studio) {
    document.addEventListener("topseg-tab-changed", event => { host?.segmentationChanged(task, event.detail); layout(); });
    document.querySelectorAll("#input-dir,#project-dir,#output-dir,#predict-input,#predict-output").forEach(input => {
      const row = document.createElement("div"); row.className = "browse-row";
      input.parentNode.insertBefore(row, input); row.appendChild(input);
      const button = document.createElement("button"); button.type = "button"; button.textContent = "Browse…";
      button.addEventListener("click", async () => {
        button.disabled = true;
        try {
          const result = await window.top.api("/api/pick-path", {kind: "folder", initial: input.value,
            mustexist: !["project-dir", "output-dir", "predict-output"].includes(input.id)});
          if (result.path) { input.value = result.path; input.dispatchEvent(new Event("change", {bubbles: true})); }
        } catch (error) { window.top.notify(error.message, true); } finally { button.disabled = false; }
      });
      row.appendChild(button);
    });
    host?.segmentationReady(task);
    if(document.documentElement.dataset.segmentationContext?.includes(':roi:')){
      const note=document.createElement('p');note.className='hint';note.textContent='ROI Detection owns the crop pixels and unit splits. This project shares defect annotations with ROI Detection; training preserves the original train/validation/test roles.';
      document.querySelector('main')?.prepend(note);
      for(const id of ['input-dir','project-dir','output-dir','group-regex','val-fraction','test-fraction']){
        const input=document.getElementById(id);if(input)input.disabled=true;
      }
      document.querySelectorAll('.browse-row button').forEach(button=>{if(button.parentElement.querySelector('#input-dir,#project-dir,#output-dir'))button.disabled=true;});
    }
  }
  const observer = new ResizeObserver(schedule);
  observer.observe(document.body);
  document.addEventListener("load", schedule, true);
  window.addEventListener("embedded-content-resized", schedule);
  window.addEventListener("resize", layout);
  document.fonts?.ready.then(schedule);
  window.NiltTheme?.apply(window.top.document.documentElement.dataset.theme);
  layout();
})();
