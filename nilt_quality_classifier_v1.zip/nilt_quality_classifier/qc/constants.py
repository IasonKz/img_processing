from __future__ import annotations

GOOD_LABEL = "good"
BAD_LABEL = "bad"

LABEL_TO_INDEX = {GOOD_LABEL: 0, BAD_LABEL: 1}
INDEX_TO_LABEL = {0: GOOD_LABEL, 1: BAD_LABEL}

DEFAULT_IMAGE_EXTENSIONS = [
    ".bmp",
    ".png",
    ".jpg",
    ".jpeg",
    ".tif",
    ".tiff",
]
