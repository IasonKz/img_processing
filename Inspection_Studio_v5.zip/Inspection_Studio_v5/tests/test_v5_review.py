"""Abstention accounting and operator-confirmed incremental dataset safety."""
import copy
from pathlib import Path
import shutil
import tempfile
import unittest

import numpy as np
from PIL import Image

from nilt.common import read_json, sha_file, write_csv, write_json
from nilt.data import read_manifest
from nilt.review import (append_prediction, decision_metrics, initialize_session,
                         save_review, session_detail)
from nilt.review_dataset import export_review_dataset, validate_update_config
from nilt.session_compare import compare_sessions


class ReviewV5(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.session = self.root / "sessions" / "one"
        initialize_session(self.session, metadata={"task": "top"})

    def append(self, name, label="good", prediction="review", color=(1, 2, 3), asset=None, **extra):
        target = self.session / "copies" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        if asset:
            shutil.copyfile(asset, target)
        else:
            Image.new("RGB", (32, 32), color).save(target)
        return append_prediction(self.session, {"relative_path": name, "reference_label": label,
            "prediction": prediction, "bad_score": .49, "threshold": .5,
            "copied_path": target.relative_to(self.session).as_posix(),
            "file_sha256": sha_file(target), **extra})

    def source_run(self):
        from test_integration_v2 import fixture_run
        run, data, rows = fixture_run(self.root)
        cfg = read_json(run / "config.json")
        groups = self.root / "original_groups.csv"
        write_csv(groups, [{"relative_path": r["relative_path"], "group": r["group"]} for r in rows])
        cfg["groups_csv"] = str(groups)
        write_json(run / "config.json", cfg)
        write_json(run / "integrity.json", {"config_sha256": sha_file(run / "config.json"),
                                           "manifest_sha256": sha_file(run / "manifest.csv")})
        return run, rows

    def test_abstention_accounting_preserves_all_class_denominators(self):
        rows = [{"reference_label": ref, "prediction": pred} for ref, pred in
                (("bad", "bad"), ("bad", "review"), ("bad", "good"),
                 ("good", "good"), ("good", "review"), ("good", "bad"))]
        met = decision_metrics(rows)
        self.assertEqual(met["n"], 4)
        self.assertEqual(met["n_labeled"], 6)
        self.assertEqual(met["accuracy"], .5)
        self.assertEqual(met["bad_escape_rate"], 1 / 3)
        self.assertEqual(met["good_reject_rate"], 1 / 3)
        self.assertEqual(met["bad_review_rate"], 1 / 3)
        self.assertEqual(met["good_review_rate"], 1 / 3)
        self.assertEqual(met["decision_coverage"], 2 / 3)
        self.assertEqual(met["review_rate"], 1 / 3)

    def test_all_review_is_not_perfect_accuracy(self):
        met = decision_metrics([{"reference_label": "bad", "prediction": "review"}])
        self.assertIsNone(met["accuracy"])
        self.assertEqual(met["decision_coverage"], 0)
        self.assertEqual(met["bad_review_rate"], 1)
        self.assertEqual(met["bad_detection_rate"], 0)

    def test_unknown_operator_label_never_falls_back_to_old_reference(self):
        record = self.append("one.png", prediction="good")
        save_review(self.session, record["id"], "unknown", "Insufficient evidence")
        metrics = session_detail(self.session)["metrics"]
        self.assertEqual(metrics["dataset_reference"]["accuracy"], 1)
        self.assertIsNone(metrics["effective_reference"]["accuracy"])
        with self.assertRaises(ValueError):
            save_review(self.session, record["id"], "review")

    def test_review_priority_and_stage_disagreement_filters(self):
        self.append("first.png", prediction="good")
        row = self.append("second.png", stage_results=[{"predicted_class": "good"}, {"predicted_class": "bad"}])
        detail = session_detail(self.session, sort="priority")
        self.assertEqual(detail["items"][0]["id"], row["id"])
        self.assertEqual(session_detail(self.session, prediction="review")["pagination"]["total"], 1)
        self.assertEqual(session_detail(self.session, filter="disagreement")["pagination"]["total"], 1)
        self.assertIn("abstained", detail["items"][0]["priority_reasons"])
        self.assertAlmostEqual(detail["items"][0]["threshold_distance"], .01)

    def test_review_sessions_compare_with_workload(self):
        self.append("one.png", label="bad")
        write_json(self.session / "summary.json", {"status": "completed", "elapsed_seconds": 1})
        other = self.root / "sessions" / "two"
        initialize_session(other)
        append_prediction(other, {"relative_path": "one.png", "reference_label": "bad", "prediction": "bad",
                                 "file_sha256": sha_file(self.session / "copies" / "one.png")})
        write_json(other / "summary.json", {"status": "completed", "elapsed_seconds": 1})
        compare = compare_sessions([self.session, other])
        self.assertEqual(compare["n_labeled"], 1)
        self.assertEqual(compare["sessions"][0]["metrics"]["review_rate"], 1)
        self.assertIsNone(compare["sessions"][0]["metrics"]["accuracy"])
        self.assertEqual(compare["sessions"][1]["metrics"]["accuracy"], 1)

    def test_export_requires_human_confirmation_not_reference_tag(self):
        self.append("unreviewed.png", label="bad", prediction="bad")
        with self.assertRaisesRegex(ValueError, "explicitly operator-confirmed"):
            export_review_dataset([self.session], self.root / "versions")

    def test_standalone_export_copies_only_confirmed_and_versions_history(self):
        confirmed = self.append("yes.png", label="bad")
        unknown = self.append("unknown.png", color=(2, 4, 8))
        self.append("untouched.png", color=(10, 1, 1))
        save_review(self.session, confirmed["id"], "bad", "Initial opinion")
        save_review(self.session, confirmed["id"], "good", "Confirmed after microscope")
        save_review(self.session, unknown["id"], "unknown")
        original_hash = sha_file(self.session / "copies" / "yes.png")
        result = export_review_dataset([self.session], self.root / "versions")
        self.assertFalse(result["ready_for_update"])
        self.assertIsNone(result["config_path"])
        images = list(Path(result["dataset_root"]).rglob("*.png"))
        self.assertEqual(len(images), 1)
        self.assertEqual(sha_file(images[0]), original_hash)
        self.assertEqual(sha_file(self.session / "copies" / "yes.png"), original_hash)
        record = read_json(Path(result["path"]) / "provenance.json")["images"][0]
        self.assertEqual(record["label"], "good")
        self.assertEqual(len(record["provenance"][0]["history"]), 2)
        self.assertEqual(result["counts"]["excluded_unknown"], 1)
        second = export_review_dataset([self.session], self.root / "versions")
        self.assertNotEqual(second["path"], result["path"])

    def test_duplicate_decoded_content_conflicting_labels_refused(self):
        one = self.append("one.png", color=(5, 6, 7))
        two = self.append("two.bmp", color=(5, 6, 7))
        save_review(self.session, one["id"], "good")
        save_review(self.session, two["id"], "bad")
        with self.assertRaisesRegex(ValueError, "Conflicting operator"):
            export_review_dataset([self.session], self.root / "versions")

    def test_duplicate_confirmed_identical_content_is_deduplicated(self):
        for name in ("one.png", "two.bmp"):
            row = self.append(name)
            save_review(self.session, row["id"], "good")
        result = export_review_dataset([self.session], self.root / "versions")
        self.assertEqual(result["counts"]["deduplicated_reviews"], 1)
        self.assertEqual(len(read_json(Path(result["path"]) / "provenance.json")["images"]), 1)

    def test_source_image_hash_must_match_before_export(self):
        row = self.append("one.png")
        save_review(self.session, row["id"], "good")
        Image.new("RGB", (32, 32), "black").save(self.session / "copies" / "one.png")
        with self.assertRaisesRegex(ValueError, "changed"):
            export_review_dataset([self.session], self.root / "versions")

    def test_incremental_export_preserves_all_splits_and_new_units_train_only(self):
        run, old = self.source_run()
        row = self.append("new.png", source_group="new_physical_unit")
        save_review(self.session, row["id"], "bad", "Verified scratch")
        result = export_review_dataset([self.session], self.root / "versions", run)
        self.assertTrue(result["ready_for_update"])
        cfg = validate_update_config(result["config_path"])
        self.assertEqual(cfg["previous_run"], str(run))
        self.assertTrue(cfg["pretrained"])
        manifest = read_manifest(Path(result["path"]) / "split_verification" / "manifest.csv")
        by_pixel = {r["pixel_hash"]: r for r in manifest}
        for prior in old:
            self.assertEqual(by_pixel[prior["pixel_hash"]]["split"], prior["split"])
            self.assertEqual(by_pixel[prior["pixel_hash"]]["label"], prior["label"])
        new = [r for r in manifest if r["pixel_hash"] not in {r["pixel_hash"] for r in old}]
        self.assertEqual(len(new), 1)
        self.assertEqual(new[0]["split"], "train")
        self.assertEqual(result["counts"]["preserved_holdout_images"], 16)
        self.assertEqual(result["counts"]["replayed_training_images"], 4)
        changed = read_json(result["config_path"])
        changed["epochs"] = 100
        write_json(result["config_path"], changed)
        with self.assertRaisesRegex(ValueError, "changed"):
            validate_update_config(result["config_path"])

    def test_protected_holdout_image_cannot_be_review_training(self):
        run, old = self.source_run()
        for split in ("val", "threshold", "selection", "test"):
            with self.subTest(split=split):
                sample = next(r for r in old if r["split"] == split)
                rec = self.append(split + ".png", asset=sample["path"])
                save_review(self.session, rec["id"], "bad")
                with self.assertRaisesRegex(ValueError, "protected"):
                    export_review_dataset([self.session], self.root / "versions", run)
                save_review(self.session, rec["id"], "unreviewed")

    def test_new_image_of_same_holdout_unit_is_blocked(self):
        run, old = self.source_run()
        group = next(r["group"] for r in old if r["split"] == "test")
        rec = self.append("different_view.png", source_group=group)
        save_review(self.session, rec["id"], "bad")
        with self.assertRaisesRegex(ValueError, "protected"):
            export_review_dataset([self.session], self.root / "versions", run)

    def test_changed_old_train_label_requires_new_lineage(self):
        run, old = self.source_run()
        sample = next(r for r in old if r["split"] == "train" and r["class_name"] == "bad")
        row = self.append("corrected.png", asset=sample["path"])
        save_review(self.session, row["id"], "good")
        with self.assertRaisesRegex(ValueError, "new dataset lineage"):
            export_review_dataset([self.session], self.root / "versions", run)

    def test_no_replay_cannot_sneak_old_partitions_into_training(self):
        with self.assertRaisesRegex(ValueError, "requires replay"):
            export_review_dataset([self.session], self.root / "versions", self.root / "old", include_replay=False)

    def test_external_evaluation_groups_are_protected(self):
        run, _ = self.source_run()
        write_json(run / "external_evaluation_ledger.json", [{"pixel_hashes": [], "groups": ["qualification-unit"]}])
        row = self.append("newview.png", source_group="qualification-unit")
        save_review(self.session, row["id"], "bad")
        with self.assertRaisesRegex(ValueError, "protected"):
            export_review_dataset([self.session], self.root / "versions", run)

    def test_added_image_cannot_bypass_export_validation(self):
        run, _ = self.source_run()
        row = self.append("reviewed.png", source_group="new-unit")
        save_review(self.session, row["id"], "good")
        result = export_review_dataset([self.session], self.root / "versions", run)
        target = Path(result["dataset_root"]) / "good" / "unreviewed.png"
        Image.new("RGB", (32, 32), "white").save(target)
        with self.assertRaisesRegex(ValueError, "inventory changed"):
            validate_update_config(result["config_path"])

    def test_edited_mapping_cannot_bypass_holdout_protection(self):
        run, _ = self.source_run()
        row = self.append("reviewed.png", source_group="new-unit")
        save_review(self.session, row["id"], "good")
        result = export_review_dataset([self.session], self.root / "versions", run)
        cfg = read_json(result["config_path"])
        write_csv(cfg["groups_csv"], [{"relative_path": "fake.png", "group": "fake"}])
        with self.assertRaisesRegex(ValueError, "group mapping changed"):
            validate_update_config(result["config_path"])

    def test_mutated_exported_bytes_are_detected(self):
        run, _ = self.source_run()
        row = self.append("reviewed.png", source_group="new-unit")
        save_review(self.session, row["id"], "good")
        result = export_review_dataset([self.session], self.root / "versions", run)
        target = next(Path(result["dataset_root"]).rglob("reviewed.png"))
        Image.new("RGB", (32, 32), "white").save(target)
        with self.assertRaisesRegex(ValueError, "exported image changed"):
            validate_update_config(result["config_path"])

    def test_export_cannot_write_inside_original_session(self):
        row = self.append("reviewed.png")
        save_review(self.session, row["id"], "good")
        with self.assertRaisesRegex(ValueError, "separate from original"):
            export_review_dataset([self.session], self.session / "new_dataset")
        self.assertFalse((self.session / "new_dataset").exists())


if __name__ == "__main__":
    unittest.main()
