"""Explicit checkpoints: architecture licenses do not imply weight licenses."""

from dataclasses import dataclass


@dataclass(frozen=True)
class ModelSpec:
    name: str
    family: str
    size: str
    checkpoint: str
    license: str

    @property
    def repo_id(self):
        return f"timm/{self.checkpoint}"

    @property
    def commercial(self):
        return self.license in {"mit", "apache-2.0"}

    @property
    def card_url(self):
        return f"https://huggingface.co/{self.repo_id}"


def _family(family, license, variants):
    return [ModelSpec(name, family, size, checkpoint, license)
            for name, size, checkpoint in variants]


MODELS = _family("ConvNeXt V2", "cc-by-nc-4.0", [
    ("convnextv2-atto", "atto", "convnextv2_atto.fcmae_ft_in1k"),
    ("convnextv2-femto", "femto", "convnextv2_femto.fcmae_ft_in1k"),
    ("convnextv2-pico", "pico", "convnextv2_pico.fcmae_ft_in1k"),
    ("convnextv2-nano", "nano", "convnextv2_nano.fcmae_ft_in1k"),
    ("convnextv2-tiny", "tiny", "convnextv2_tiny.fcmae_ft_in22k_in1k"),
    ("convnextv2-base", "base", "convnextv2_base.fcmae_ft_in22k_in1k"),
    ("convnextv2-large", "large", "convnextv2_large.fcmae_ft_in22k_in1k"),
    ("convnextv2-huge", "huge", "convnextv2_huge.fcmae_ft_in22k_in1k_384"),
]) + _family("ConvNeXt", "apache-2.0", [
    (f"convnext-{size}", size, f"convnext_{size}.fb_in22k_ft_in1k")
    for size in ("tiny", "small", "base", "large", "xlarge")
]) + _family("DeiT III", "apache-2.0", [
    (f"deit3-{size}", size, f"deit3_{size}_patch16_224.fb_in22k_ft_in1k")
    for size in ("small", "medium", "base", "large")
] + [("deit3-huge", "huge", "deit3_huge_patch14_224.fb_in22k_ft_in1k")]) + _family("Swin V2", "mit", [
    ("swinv2-tiny", "tiny", "swinv2_tiny_window8_256.ms_in1k"),
    ("swinv2-small", "small", "swinv2_small_window8_256.ms_in1k"),
    ("swinv2-base", "base", "swinv2_base_window12to16_192to256.ms_in22k_ft_in1k"),
    ("swinv2-large", "large", "swinv2_large_window12to16_192to256.ms_in22k_ft_in1k"),
]) + _family("EVA-02", "mit", [
    ("eva02-tiny", "tiny", "eva02_tiny_patch14_336.mim_in22k_ft_in1k"),
    ("eva02-small", "small", "eva02_small_patch14_336.mim_in22k_ft_in1k"),
    ("eva02-base", "base", "eva02_base_patch14_448.mim_in22k_ft_in22k_in1k"),
    ("eva02-large", "large", "eva02_large_patch14_448.mim_m38m_ft_in22k_in1k"),
]) + _family("EfficientNet V2", "apache-2.0", [
    (f"efficientnetv2-{size}", size, f"tf_efficientnetv2_{size}.in21k_ft_in1k")
    for size in ("s", "m", "l")
])
CATALOG = {spec.name: spec for spec in MODELS}


def select_model(name, purpose="commercial"):
    if purpose not in {"commercial", "research"}:
        raise ValueError("Purpose must be commercial or research")
    if name not in CATALOG:
        raise ValueError(f"Unknown model {name!r}; run cvtester list")
    spec = CATALOG[name]
    if purpose == "commercial" and not spec.commercial:
        raise ValueError(f"{name}: {spec.license} prohibits commercial use; "
                         "use --purpose research for noncommercial experiments")
    return spec


def check_metadata(spec, info):
    """Fail closed before downloading weights; bind every file to one revision."""
    card = info.card_data
    license = card.get("license") if card else None
    if license != spec.license:
        raise ValueError(f"{spec.name}: expected weight license {spec.license}, "
                         f"model card reports {license!r}; review the model card")
    if not info.sha or len(info.sha) != 40 or any(c not in "0123456789abcdef" for c in info.sha):
        raise ValueError("Model metadata did not supply a pinned commit SHA")
    files = {file.rfilename for file in info.siblings or []}
    if not {"model.safetensors", "config.json"}.issubset(files):
        raise ValueError("Checkpoint must provide model.safetensors and config.json")
    return info.sha
