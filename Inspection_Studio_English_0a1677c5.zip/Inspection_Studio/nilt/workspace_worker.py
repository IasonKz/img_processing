"""Managed long operations with persisted requests, reports and stop markers."""
from pathlib import Path
import sys
from .common import read_json, write_json


def run(request_file):
    path = Path(request_file).resolve()
    request = read_json(path)
    output = Path(request["output"])
    output.mkdir(parents=True, exist_ok=False)
    stop = Path(request["stop_file"])
    try:
        if request["action"] == "threshold-tune":
            from .threshold_tuning import run_experiment
            run_experiment(request["settings"], output, stop_check=stop.exists)
        elif request["action"] == "deploy-pipeline":
            from .pipeline_deployment import deploy
            deploy(request["settings"], output, stop_check=stop.exists)
        else:
            raise ValueError("Unknown workspace operation.")
        return 0
    except BaseException as error:
        from .engine import TrainingStopped
        cancelled = isinstance(error, (InterruptedError, KeyboardInterrupt, TrainingStopped)) or stop.exists()
        status = {"status": "stopped" if cancelled else "failed", "error": str(error)}
        write_json(output / "status.json", status)
        report = output / "report.json"
        if report.is_file():
            write_json(report, {**read_json(report), **status})
        print(f"{'STOPPED' if cancelled else 'FAILED'}: {error}", file=sys.stderr, flush=True)
        if cancelled:
            return 130
        raise
