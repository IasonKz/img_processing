"""Isolated synthetic workspace for the optional Playwright integration test."""
from pathlib import Path
import json
import sys
import tempfile

import numpy as np
from PIL import Image, ImageDraw

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from topseg.common import load_config, sha256
from topseg.project import Project
from topseg.server import make_server

with tempfile.TemporaryDirectory(prefix='topseg-browser-') as folder:
    root = Path(folder)
    source = root / 'source'; source.mkdir()
    for i in range(3):
        rng = np.random.default_rng(42 + i)
        image = Image.fromarray(np.clip(95 + rng.normal(0, 1, (640, 720, 3)), 0, 255).astype(np.uint8))
        draw = ImageDraw.Draw(image)
        draw.rounded_rectangle((85, 45, 635, 595), radius=28, fill=(146 + i, 146, 140), outline=(48, 50, 51), width=10)
        # Deliberately angular lens: the detector must retain the clipped corners.
        draw.polygon([(250, 130), (470, 130), (550, 210), (550, 430),
                      (470, 510), (250, 510), (170, 430), (170, 210)],
                     fill=(30, 40, 43), outline=(104, 106, 102), width=7)
        draw.line((295, 245, 323, 271), fill=(204, 210, 190), width=5)
        draw.rectangle((563, 188, 578, 202), fill=(43, 44, 42))
        image.save(source / f'top_unit_{i + 1:02d}.png')
    config = root / 'project.yaml'
    config.write_text('input_dir: source\nproject_dir: workspace\noutput_dir: output\n', encoding='utf-8')
    cfg = load_config(config); project = Project(cfg); project.import_images(); server = make_server(cfg)
    print(json.dumps({'url': f'http://127.0.0.1:{server.server_port}', 'root': str(root), 'sources': {p.name: sha256(p) for p in source.glob('*.png')}}), flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()
