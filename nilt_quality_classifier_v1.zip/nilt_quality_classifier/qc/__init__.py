"""Utilities for the binary GOOD/BAD image-classification pipeline.

The project deliberately uses GOOD=0 and BAD=1 everywhere.  BAD is therefore
considered the positive class when metrics such as recall and false-negative
rate are reported.
"""

from .constants import BAD_LABEL, GOOD_LABEL, INDEX_TO_LABEL, LABEL_TO_INDEX

__all__ = [
    "GOOD_LABEL",
    "BAD_LABEL",
    "LABEL_TO_INDEX",
    "INDEX_TO_LABEL",
]
