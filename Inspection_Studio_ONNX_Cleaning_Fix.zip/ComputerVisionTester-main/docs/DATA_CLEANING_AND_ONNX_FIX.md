# Data Cleaning, shared image viewer and ONNX export

This update is based on the supplied current repository. Its Classification / Segmentation / ROI Detection navigation, ROI scopes, annotations, crop pipelines, model registry, training settings and existing workstation changes are retained.

## Start and export

Extract the updated project and launch `Start.cmd` as before. Retry the selected model's ONNX export in **Reports & export**. A failed package created by this exporter can be retried in the same output folder; the existing failed attempt is preserved by the existing backup mechanism. A completed package is not overwritten.

The screenshot error `aten::_upsample_bicubic2d_aa` is handled by `nilt.export_support.export_onnx`. It represents native antialiased bicubic/bilinear resampling as separable ONNX matrices, derived from the installed ATen kernels. Antialiasing, boundary handling, fractional scale factors and `align_corners` are retained. The package still uses fixed input geometry and opset 17, and does not need ONNX Script.

For EVA, dynamic grid expressions and reshape dimensions are resolved from the traced fixed geometry. Rotary position tables are calculated with native Torch for each global/local grid during export. This prevents the legacy exporter's grid/reshape and rotary numerical discrepancies. Export registrations and temporary methods are restored, and the checkpoint and learned parameters remain unchanged. The member metadata records resizes, fixed reshapes and derived geometry tables.

Numerical tolerances and the decision agreement gate are unchanged. Export still compares with source checkpoint predictions on the reserved selection manifest; an invalid or disagreeing export is not published as a usable ZIP. The setup probe now exercises an actual antialiased resize, as well as CPU ONNX inference. `Setup-Export.cmd` remains available for a missing or broken ONNX environment; see `EXPORT_AND_VIEWER_FIXES.md`.

## Shared viewer

The existing fullscreen, fit, 100% pixels, wheel/button zoom, right/left/middle drag pan, native-depth brightness statistics and lower/upper display limits are shared by:

- Data Cleaning's embedded editor, with tags and commit actions visible in fullscreen.
- Classification image review and deployment unit evidence.
- Dataset/result image links and galleries opened inside the shared image dialog.
- ROI geometry editing, ROI crop previews and quality-label crop galleries.
- Full-image and ROI-crop segmentation annotation, and saved segmentation image comparisons.

Annotation editors retain their own polygon, point, brush, vertex and pan tools. Display controls change only the visible pixels. They do not change masks, ROI coordinates, saved crops, training preprocessing or model scores. Brightness limits are applied to native pixels before the display is converted to eight bits, including uint16 ROI crop previews. Clicking a gallery image opens the same inspector rather than a plain image tab. Modified clicks on links retain the usual browser behavior.

## Data Cleaning tags

Open a dataset containing the existing `good/` and `bad/` folders. `review/` and `unsuitable/` are also shown when present. The editor shows the saved human tag separately from its pending replacement.

| Key | Pending tag / action |
| --- | --- |
| D | Good |
| F | Bad |
| X | Unsuitable |
| P | Review |
| Enter | Commit the pending tag |
| Escape | Cancel the pending tag |
| Left / Right | Previous / next image |

The four tag buttons stage the same choices as the shortcuts. Neither a shortcut nor a tag button moves a file until **Enter / Commit tag**. Navigation clears an uncommitted choice with a status message. Text inputs and open dialogs retain their normal keyboard behavior. Commit verifies the image checksum and performs the existing collision-safe move; Undo restores the previous location. Current filters are retained after a move. Edits remain blocked while dataset-reading workers are active.

The current dataset, image, filters, model/assessment selection and checksum-bound pending tag are remembered per task and ROI scope in the local browser. Committed tags and the move journal are stored with the dataset. Existing project experiments and results retain their own storage.

The following browser-test capture uses a synthetic 16-bit image and synthetic model scores. It shows the fullscreen editor, independent human/model tags and a pending tag awaiting Enter.

![Synthetic fullscreen Data Cleaning check](validation/data_cleaning_onnx/SYNTHETIC-cleaning-fullscreen.png)

## Optional model assistance

**No model · manual tagging only** is available at all times. In that mode the editor shows only human tagging, and comparison filters are disabled.

For assistance, select a **Model decision** or **Inspection workflow** matching the current task and ROI scope. A model decision identifies the saved classifier/checkpoints and frozen thresholds. Scores-only decisions cannot make comparison tags. Use **Score dataset** to start a managed CPU/CUDA worker, or select an earlier completed assessment of that source. Saving a new model decision or workflow produces a separate assessment history.

Assessments reuse the existing `predict_members`, decision classification and frozen workflow voting rules. Models are loaded one stage at a time. Review abstentions and stage short-circuiting are preserved. Input errors are displayed as Review/error evidence and never become Good. Scoring includes all dataset class folders and reads originals without relabeling them. It does not train, tune thresholds or change a saved evaluation result.

The gallery/editor shows **MY SAVED TAG**, **PENDING**, and **MODEL** separately. Probability-based classifiers show the predicted class score; anomaly classifiers retain their native bad/anomaly score. Individual stage scores, thresholds, score types and skipped-stage reasons remain visible. These scores are not calibrated certainty estimates. Workflows show the final vote and each evaluated stage; there is no invented aggregate confidence.

| Filter | Compared with the current saved human tag |
| --- | --- |
| FN | Human Bad, model Good |
| FP | Human Good, model Bad |
| Mismatch | FN, FP, or a different model decision such as Review |
| Match | Matching human Good/Bad and model decision |
| Model Review / input error | Model abstention or invalid input |
| Unscored / changed image | Missing prediction, stale content, or input error |

**FN / FP / mismatches first** prioritizes these cases before matches. Human Review/Unsuitable tags are not treated as binary reference labels. Comparison counts use committed tags; a pending tag does not silently change FN/FP membership.

Model records are stored under `cleaning_assessments/<assessment-id>/`, with a source fingerprint, task/scope, stage evidence and file checksums. Relabeling and Undo reconnect scores through the move journal and content identity. A changed file is marked stale and needs a new assessment. Previous assessments remain available after closing the GUI. Worker progress/errors are retained with the experiment; committed image tags are independent of assessment success.

## Verification

Fixtures are synthetic and neural integration tests use random model weights, not production-quality claims. See `DATA_CLEANING_ONNX_VERIFICATION.md` for the actual checks and environment limits.
