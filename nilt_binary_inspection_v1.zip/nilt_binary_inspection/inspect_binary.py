#!/usr/bin/env python3
"""CLI entry point. Example: python inspect_binary.py run --config configs/top.yaml"""
import multiprocessing
from binary_inspection.cli import main

if __name__ == "__main__":
    multiprocessing.freeze_support()
    raise SystemExit(main())
