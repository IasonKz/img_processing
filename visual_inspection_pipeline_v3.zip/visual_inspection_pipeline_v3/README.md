# Visual Inspection Pipeline v3

Local image inspection with grouped data splits, profile-budgeted Optuna search,
full-ROI image handling, four decision modes and a local monitoring dashboard.
The initial configuration enables **VIG only**. Top/bottom remain available as
separate binary classification tasks when their data and settings are configured.

Start with [START_HERE.md](START_HERE.md) for the short Greek instructions, then
[Windows installation](docs/INSTALLATION.md) and the [v3 guide](docs/V3_GUIDE.md).
The v3 guide supersedes older v2/add-on instructions retained for reference.
Training/inference stay local after provisioning packages and public weights.
The dashboard uses loopback without a CDN; ONNX Runtime telemetry is disabled in
code. Hardware measurements are recorded locally for your experiment reports.

## Your three profiles

| Profile | Hardware target | Maximum cumulative search time |
|---|---|---:|
| `laptop` | CPU, conservative memory use | 2 hours |
| `workstation` | NVIDIA GPU, approximately 16 GB VRAM / 32–64 GB RAM | 6 hours |
| `workstation_large` | NVIDIA workstation with a larger search allowance | 12 hours |

These are cumulative elapsed-time ceilings, not estimates of model quality.
Resuming the same search uses its remaining allowance; it does not reset the
clock. A search can finish earlier. If its deadline arrives before selection finishes, it reports
pending selection rather than inventing a winner. A separately requested
`finalize-search` operation can evaluate already trained candidates.

## What is integrated

- Optuna studies per model with shared immutable splits and train/validation-only
  tuning; conditional parameters for supervised models and PatchCore.
- Exact decoded-image conflict checks, duplicate reports, and physical-unit
  grouping from tray + row + column identifiers.
- Whole-ROI preprocessing: no crop and no automatic resolution reduction. Padding
  can enlarge the network input canvas without discarding original pixels.
- VIG training augmentation limited to exact 0°, 90°, 180° and 270° rotations.
- Model/learning-curve comparison, telemetry, threshold exploration and local
  prediction exports.
- `policy`, `manual`, `argmax` and `scores_only` decisions saved separately from
  source model results. Metrics are calculated only when true labels are supplied.
- Final-test evaluation, versioned model management, training continuation and
  verified ONNX export where supported.

## Quick start after installation

Edit `tasks.vig.dataset_root` in `project.yaml`, keeping your original images in
`good` and `bad` subfolders. Then run from the project folder in PowerShell:

```powershell
.\.venv\Scripts\python.exe inspection.py doctor --config project.yaml --profile laptop --task vig
.\.venv\Scripts\python.exe inspection.py dashboard --config project.yaml
```

Open the local address printed by the dashboard. Or launch a search directly:

```powershell
.\.venv\Scripts\python.exe inspection.py search --config project.yaml --profile laptop --task vig
```

Use `workstation` or `workstation_large` on a configured CUDA machine. The scripts
in `scripts/` are convenience launchers; `.venv` must be recreated on each machine.

## Scope of validation

This release passed automated tests and a synthetic end-to-end run with real
pretrained ResNet18 weights, two training epochs, all four decision modes,
reports, and real ONNX export/inference for argmax and scores-only decisions.
See the [validation report](docs/VALIDATION_REPORT.md) for the final test count,
scope and environment.

You can repeat a small synthetic installation check locally:

```powershell
.\.venv\Scripts\python.exe scripts/smoke_v3.py --output ..\smoke_check
```

Add `--weights .\weights` to use already downloaded ResNet18 weights, and
`--with-onnx` after installing the export dependencies to include ONNX checks.
Use a new or empty output directory each time. This smoke test never downloads
weights or reads company images.

These checks validate software behavior. They do not measure defect-detection
performance on your company images. Windows/CUDA and your real dataset must also
pass the local preflight and a short first run.

Optuna searches the model families, configurations and time allowance supplied.
It cannot guarantee a globally best model or a particular bad-escape rate. A
model that fails your stated targets remains visibly unqualified, even when it
is the best candidate in the completed search.
