"""Fixed-entry-point worker for resumable local ROI dataset operations."""
from __future__ import annotations

import argparse
from pathlib import Path
import time
import traceback

from ..common import read_json, write_json


def run(request):
    from .project import ROIProject
    output = Path(request["output"])
    output.mkdir(parents=True, exist_ok=True)
    started = time.time()

    def status(**fields):
        write_json(output / "status.json", {"started": started, "updated": time.time(), **fields})

    try:
        action = request["action"]
        method = {"import": "import_images", "localize": "localize_images", "export": "export_datasets"}.get(action)
        if method is None:
            raise ValueError("Unsupported ROI dataset action.")
        project = ROIProject(request["root"], request["side"])
        project.progress = lambda message, current=0, total=0: status(status="running", message=message, current=current, total=total)
        project.cancelled = lambda: (output / "STOP").exists()
        status(status="running", message="Preparing ROI operation")
        result = getattr(project, method)(request.get("payload", {}))
        summary = result.get("summary", {})
        errors = summary.get("errors", []) or result.get("errors", [])
        success = summary.get("imported", summary.get("localized", summary.get("crops", 0)))
        if action == "export":
            export = result.get("export", result)
            errors = export.get("errors", errors)
            success = export.get("counts", {}).get("crops", success)
        if errors and not success and not summary.get("skipped", 0) and not summary.get("duplicates", 0):
            status(status="failed", error="No images were processed successfully; inspect the operation errors.",
                   message="ROI operation failed", result=result, has_errors=True)
        else:
            status(status="completed", message="ROI operation completed with issues; inspect its summary." if errors else "ROI operation completed",
                   result=result, has_errors=bool(errors))
        return result
    except Exception as exc:
        cancelled = (output / "STOP").exists()
        status(status="stopped" if cancelled else "failed", error=str(exc), message=str(exc))
        traceback.print_exc()
        raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--request", required=True)
    args = parser.parse_args()
    run(read_json(args.request))


if __name__ == "__main__":
    main()
