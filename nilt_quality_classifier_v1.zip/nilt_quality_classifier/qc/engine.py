from __future__ import annotations

import contextlib
import math
from collections.abc import Callable
from typing import Any, Sequence

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.optim import AdamW, SGD, Optimizer
from torch.optim.lr_scheduler import CosineAnnealingLR, ReduceLROnPlateau
from tqdm import tqdm

from .metrics import binary_metrics
from .models import (
    set_backbone_trainable,
    set_frozen_batchnorm_eval,
    split_backbone_and_head_parameters,
)


def make_grad_scaler(enabled: bool):
    if hasattr(torch, "amp") and hasattr(torch.amp, "GradScaler"):
        try:
            return torch.amp.GradScaler("cuda", enabled=enabled)
        except TypeError:
            return torch.amp.GradScaler(enabled=enabled)
    return torch.cuda.amp.GradScaler(enabled=enabled)


def autocast_context(device: torch.device, enabled: bool):
    if not enabled:
        return contextlib.nullcontext()
    if hasattr(torch, "amp") and hasattr(torch.amp, "autocast"):
        return torch.amp.autocast(device_type=device.type, enabled=True)
    return torch.cuda.amp.autocast(enabled=True)


def build_optimizer(model: nn.Module, architecture: str, config: dict[str, Any]) -> Optimizer:
    optimizer_name = str(config.get("optimizer", "adamw")).lower()
    backbone_lr = float(config.get("learning_rate", 3e-4))
    head_lr = float(config.get("head_learning_rate", backbone_lr))
    weight_decay = float(config.get("weight_decay", 1e-4))

    backbone_parameters, head_parameters = split_backbone_and_head_parameters(model, architecture)
    groups: list[dict[str, Any]] = []
    if backbone_parameters:
        groups.append({"params": backbone_parameters, "lr": backbone_lr, "name": "backbone"})
    if head_parameters:
        groups.append({"params": head_parameters, "lr": head_lr, "name": "head"})
    if not groups:
        raise ValueError("The model has no trainable parameters")

    if optimizer_name == "adamw":
        return AdamW(groups, lr=backbone_lr, weight_decay=weight_decay)
    if optimizer_name == "sgd":
        return SGD(
            groups,
            lr=backbone_lr,
            momentum=float(config.get("momentum", 0.9)),
            nesterov=bool(config.get("nesterov", True)),
            weight_decay=weight_decay,
        )
    raise ValueError(f"Unsupported optimizer: {optimizer_name}")


def build_scheduler(optimizer: Optimizer, config: dict[str, Any], epochs_remaining: int):
    scheduler_config = config.get("scheduler", {}) or {}
    scheduler_type = str(scheduler_config.get("type", "reduce_on_plateau")).lower()
    if scheduler_type in {"none", "off", "disabled"}:
        return None
    if scheduler_type == "reduce_on_plateau":
        return ReduceLROnPlateau(
            optimizer,
            mode=str(scheduler_config.get("mode", "min")),
            factor=float(scheduler_config.get("factor", 0.3)),
            patience=int(scheduler_config.get("patience", 3)),
            min_lr=float(scheduler_config.get("min_lr", 1e-7)),
        )
    if scheduler_type == "cosine":
        return CosineAnnealingLR(
            optimizer,
            T_max=max(int(scheduler_config.get("t_max", epochs_remaining)), 1),
            eta_min=float(scheduler_config.get("min_lr", 1e-7)),
        )
    raise ValueError(f"Unsupported scheduler.type: {scheduler_type}")


def optimizer_lrs(optimizer: Optimizer) -> dict[str, float]:
    result: dict[str, float] = {}
    for index, group in enumerate(optimizer.param_groups):
        name = str(group.get("name", f"group_{index}"))
        result[f"lr_{name}"] = float(group["lr"])
    return result


def train_one_epoch(
    model: nn.Module,
    loader,
    criterion: nn.Module,
    optimizer: Optimizer,
    scaler,
    *,
    device: torch.device,
    use_amp: bool,
    gradient_clip_norm: float | None,
    backbone_frozen: bool,
    show_progress: bool,
) -> float:
    model.train()
    if backbone_frozen:
        set_frozen_batchnorm_eval(model)

    total_loss = 0.0
    total_samples = 0
    iterator = tqdm(loader, desc="train", leave=False, disable=not show_progress)
    for batch in iterator:
        images = batch["image"].to(device, non_blocking=True)
        labels = batch["label"].to(device, non_blocking=True)
        optimizer.zero_grad(set_to_none=True)

        with autocast_context(device, use_amp):
            logits = model(images)
            loss = criterion(logits, labels)

        scaler.scale(loss).backward()
        if gradient_clip_norm is not None and gradient_clip_norm > 0:
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), gradient_clip_norm)
        scaler.step(optimizer)
        scaler.update()

        batch_size = int(labels.shape[0])
        total_loss += float(loss.detach().item()) * batch_size
        total_samples += batch_size
        iterator.set_postfix(loss=f"{float(loss.detach().item()):.4f}")

    return total_loss / max(total_samples, 1)


@torch.inference_mode()
def predict_labeled(
    model: nn.Module,
    loader,
    *,
    device: torch.device,
    criterion: nn.Module | None,
    use_amp: bool,
    show_progress: bool,
) -> dict[str, Any]:
    model.eval()
    total_loss = 0.0
    total_samples = 0
    labels_all: list[int] = []
    p_bad_all: list[float] = []
    paths: list[str] = []
    groups: list[str] = []
    unit_ids: list[str] = []
    unit_ids_raw: list[str] = []
    sources: list[str] = []
    splits: list[str] = []

    iterator = tqdm(loader, desc="evaluate", leave=False, disable=not show_progress)
    for batch in iterator:
        images = batch["image"].to(device, non_blocking=True)
        labels = batch["label"].to(device, non_blocking=True)
        with autocast_context(device, use_amp):
            logits = model(images)
            if criterion is not None:
                loss = criterion(logits, labels)
            probabilities = torch.softmax(logits, dim=1)[:, 1]

        batch_size = int(labels.shape[0])
        if criterion is not None:
            total_loss += float(loss.detach().item()) * batch_size
        total_samples += batch_size
        labels_all.extend(labels.detach().cpu().numpy().astype(int).tolist())
        p_bad_all.extend(probabilities.detach().float().cpu().numpy().tolist())
        paths.extend(list(batch["path"]))
        groups.extend(list(batch["group"]))
        unit_ids.extend(list(batch["unit_id"]))
        unit_ids_raw.extend(list(batch["unit_id_raw"]))
        sources.extend(list(batch["source"]))
        splits.extend(list(batch["split"]))

    return {
        "loss": (total_loss / max(total_samples, 1)) if criterion is not None else None,
        "y_true": np.asarray(labels_all, dtype=np.int64),
        "p_bad": np.asarray(p_bad_all, dtype=np.float64),
        "paths": paths,
        "groups": groups,
        "unit_ids": unit_ids,
        "unit_ids_raw": unit_ids_raw,
        "sources": sources,
        "splits": splits,
    }


@torch.inference_mode()
def predict_unlabeled(
    model: nn.Module,
    loader,
    *,
    device: torch.device,
    use_amp: bool,
    show_progress: bool,
) -> dict[str, Any]:
    model.eval()
    p_bad_all: list[float] = []
    paths: list[str] = []
    relative_paths: list[str] = []
    unit_ids: list[str] = []
    unit_ids_raw: list[str] = []

    iterator = tqdm(loader, desc="predict", leave=False, disable=not show_progress)
    for batch in iterator:
        images = batch["image"].to(device, non_blocking=True)
        with autocast_context(device, use_amp):
            logits = model(images)
            probabilities = torch.softmax(logits, dim=1)[:, 1]
        p_bad_all.extend(probabilities.detach().float().cpu().numpy().tolist())
        paths.extend(list(batch["path"]))
        relative_paths.extend(list(batch["relative_path"]))
        unit_ids.extend(list(batch["unit_id"]))
        unit_ids_raw.extend(list(batch["unit_id_raw"]))

    return {
        "p_bad": np.asarray(p_bad_all, dtype=np.float64),
        "paths": paths,
        "relative_paths": relative_paths,
        "unit_ids": unit_ids,
        "unit_ids_raw": unit_ids_raw,
    }


def _selection_value(
    selection_metric: str,
    validation_loss: float,
    metrics: dict[str, Any],
) -> tuple[float, str]:
    metric = selection_metric.lower().strip()
    if metric in {"loss", "validation_loss", "val_loss"}:
        return float(validation_loss), "min"
    aliases = {
        "average_precision": "average_precision_bad",
        "ap": "average_precision_bad",
        "pr_auc": "average_precision_bad",
        "bad_recall": "bad_recall",
        "balanced_accuracy": "balanced_accuracy",
        "roc_auc": "roc_auc",
        "bad_f1": "bad_f1",
    }
    key = aliases.get(metric, metric)
    value = float(metrics.get(key, float("nan")))
    if not math.isfinite(value):
        return float("-inf"), "max"
    return value, "max"


def _is_better(value: float, best: float | None, mode: str, min_delta: float) -> bool:
    if best is None:
        return True
    if mode == "min":
        return value < best - min_delta
    return value > best + min_delta


def fit_model(
    *,
    model: nn.Module,
    architecture: str,
    train_loader,
    validation_loader,
    criterion: nn.Module,
    device: torch.device,
    training_config: dict[str, Any],
    logger,
    checkpoint_callback: Callable[[str, dict[str, Any]], None] | None = None,
) -> dict[str, Any]:
    epochs = int(training_config.get("epochs", 50))
    freeze_epochs = int(training_config.get("freeze_backbone_epochs", 0))
    use_amp = bool(training_config.get("mixed_precision", True) and device.type == "cuda")
    gradient_clip = training_config.get("gradient_clip_norm", None)
    gradient_clip = None if gradient_clip is None else float(gradient_clip)
    show_progress = bool(training_config.get("show_progress", True))
    selection_metric = str(training_config.get("selection_metric", "average_precision"))
    early_config = training_config.get("early_stopping", {}) or {}
    early_enabled = bool(early_config.get("enabled", True))
    patience = int(early_config.get("patience", 10))
    min_delta = float(early_config.get("min_delta", 1e-4))

    set_backbone_trainable(model, architecture, trainable=freeze_epochs <= 0)
    optimizer = build_optimizer(model, architecture, training_config)
    scheduler = build_scheduler(optimizer, training_config, epochs)
    scaler = make_grad_scaler(use_amp)

    history_rows: list[dict[str, Any]] = []
    best_score: float | None = None
    best_mode = "max"
    best_epoch = 0
    best_state: dict[str, torch.Tensor] | None = None
    epochs_without_improvement = 0

    logger.info(
        "Training for up to %d epochs; backbone frozen for %d epoch(s); AMP=%s",
        epochs,
        freeze_epochs,
        use_amp,
    )

    for epoch in range(1, epochs + 1):
        if freeze_epochs > 0 and epoch == freeze_epochs + 1:
            logger.info("Unfreezing the backbone at epoch %d", epoch)
            set_backbone_trainable(model, architecture, trainable=True)
            optimizer = build_optimizer(model, architecture, training_config)
            scheduler = build_scheduler(optimizer, training_config, epochs - epoch + 1)
            scaler = make_grad_scaler(use_amp)

        backbone_frozen = epoch <= freeze_epochs
        train_loss = train_one_epoch(
            model,
            train_loader,
            criterion,
            optimizer,
            scaler,
            device=device,
            use_amp=use_amp,
            gradient_clip_norm=gradient_clip,
            backbone_frozen=backbone_frozen,
            show_progress=show_progress,
        )
        validation = predict_labeled(
            model,
            validation_loader,
            device=device,
            criterion=criterion,
            use_amp=use_amp,
            show_progress=show_progress,
        )
        validation_metrics = binary_metrics(
            validation["y_true"], validation["p_bad"], threshold=0.5
        )
        selection_value, selection_mode = _selection_value(
            selection_metric,
            float(validation["loss"]),
            validation_metrics,
        )
        best_mode = selection_mode

        row: dict[str, Any] = {
            "epoch": epoch,
            "train_loss": train_loss,
            "validation_loss": float(validation["loss"]),
            "validation_accuracy_at_0.5": validation_metrics["accuracy"],
            "validation_balanced_accuracy_at_0.5": validation_metrics["balanced_accuracy"],
            "validation_bad_recall_at_0.5": validation_metrics["bad_recall"],
            "validation_false_pass_rate_at_0.5": validation_metrics["false_pass_rate"],
            "validation_average_precision_bad": validation_metrics["average_precision_bad"],
            "selection_value": selection_value,
            "backbone_frozen": backbone_frozen,
            **optimizer_lrs(optimizer),
        }
        history_rows.append(row)

        improved = _is_better(selection_value, best_score, selection_mode, min_delta)
        if improved:
            best_score = selection_value
            best_epoch = epoch
            best_state = {
                name: tensor.detach().cpu().clone()
                for name, tensor in model.state_dict().items()
            }
            epochs_without_improvement = 0
        else:
            epochs_without_improvement += 1

        if scheduler is not None:
            if isinstance(scheduler, ReduceLROnPlateau):
                monitor = str((training_config.get("scheduler", {}) or {}).get("monitor", "validation_loss"))
                if monitor == "selection_metric":
                    scheduler.step(selection_value)
                else:
                    scheduler.step(float(validation["loss"]))
            else:
                scheduler.step()

        logger.info(
            "Epoch %03d | train loss %.5f | val loss %.5f | val BAD recall@0.5 %.3f | "
            "val AP %.4f | %s %.5f%s",
            epoch,
            train_loss,
            float(validation["loss"]),
            validation_metrics["bad_recall"],
            validation_metrics["average_precision_bad"],
            selection_metric,
            selection_value,
            " | BEST" if improved else "",
        )

        state_for_callback = {
            "epoch": epoch,
            "model_state": model.state_dict(),
            "optimizer_state": optimizer.state_dict(),
            "scheduler_state": scheduler.state_dict() if scheduler is not None else None,
            "scaler_state": scaler.state_dict(),
            "history": history_rows,
            "best_epoch": best_epoch,
            "best_score": best_score,
            "selection_metric": selection_metric,
            "selection_mode": best_mode,
        }
        if checkpoint_callback is not None:
            checkpoint_callback("last", state_for_callback)
            if improved:
                checkpoint_callback("best", state_for_callback)

        if early_enabled and epoch > freeze_epochs and epochs_without_improvement >= patience:
            logger.info(
                "Early stopping after epoch %d (no improvement for %d epochs)",
                epoch,
                epochs_without_improvement,
            )
            break

    if best_state is None:
        raise RuntimeError("Training completed without a valid best checkpoint")
    model.load_state_dict(best_state)
    model.to(device)
    return {
        "model": model,
        "history": pd.DataFrame(history_rows),
        "best_epoch": best_epoch,
        "best_score": best_score,
        "selection_metric": selection_metric,
        "selection_mode": best_mode,
    }
