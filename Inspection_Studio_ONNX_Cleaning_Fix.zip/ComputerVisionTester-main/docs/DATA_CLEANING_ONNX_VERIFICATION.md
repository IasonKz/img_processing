# Verification — 2026-10-08

Host: Linux, Python 3.12, CPU Torch 2.7.1 / TorchVision 0.22.1, timm 1.0.22, ONNX 1.18.0 and ONNX Runtime 1.22.0. Real browser checks used Playwright with Chromium 153. All images were generated synthetic fixtures; no user production model checkpoint was supplied.

## Completed checks

- `tests/test_onnx_antialias.py`: native ATen vs ONNX Runtime for bicubic and bilinear AA, enlargement, reduction, fractional scale, and both align-corners settings; model outputs and scoped registration are preserved.
- Real dynamic ViT positional embedding export, plus the repo's EVA-02 Tiny backbone with rotary geometry, full-image and global + patches inference. Both EVA grid sizes are retained in patch mode, methods are restored and positional parameters are unchanged. Strict existing score tolerances pass.
- Export/deployment/viewer/decision regression group: **61 passed**, with **22 subtests passed**. Includes actual supervised, ensemble, PatchCore, native uint16 triage and global + patches ONNX packages, standalone CPU inference and source-free package execution.
- `tests/test_cleaning_assessment.py`: **6 passed**. Mocked scores verify frozen workflow voting/short-circuiting, human/model separation, FN/FP semantics, relabel/undo identity, changed-content rejection, source/scope guards, cancellation and native display limits. A real random-weight ResNet18 assessment runs through the workspace worker on 20 images, produces finite decisions and leaves all source hashes unchanged.
- `tests/browser_data_cleaning.cjs`: actual local HTTP API and browser keyboard/mouse input. D/F/X/P remain pending until Enter; Escape cancels; relabel and Undo work; saved progress restores; optional model/manual modes and FN/FP/mismatch filters work; threshold evidence is shown; uint16 levels, fullscreen, zoom and right-button pan pass.
- `tests/browser_export_viewer.cjs`: native uint16 display, custom limits, fullscreen, image zoom/pan, chart selection and annotation gestures. New shared brightness/fullscreen controls preserve annotation masks and the existing canvas position/zoom.
- Existing ROI, review and decision UI stub checks pass. ROI/ROI-crop segmentation/server regression group: **25 passed**, with **13 subtests passed**. Python compilation and changed JavaScript syntax checks pass.
- `scripts/check_export.py` passes actual antialiased export and CPU inference.

Example commands from the project root:

```bash
python -m pytest tests/test_onnx_antialias.py tests/test_deployment.py tests/test_export_viewer.py tests/test_v3_decisions.py -q
python -m pytest tests/test_cleaning_assessment.py -q
python scripts/check_export.py
node tests/browser_data_cleaning.cjs /tmp/cleaning-evidence
node tests/browser_export_viewer.cjs /tmp/viewer-evidence
```

The browser scripts need local Playwright and Chromium. `STUDIO_PYTHON` and `STUDIO_BROWSER_EXECUTABLE` select their installed local executables. They do not intercept model responses to invent browser outcomes; the Data Cleaning comparison fixture explicitly uses saved synthetic scores.

## Broader run and limits

The broader repository run completed with **798 passed**, **538 subtests passed**, **1 optional-dependency skip**, **1 deselected**, and **3 failures**. It ran before the two extra EVA tests and real assessment worker test were added. The failures were unchanged process-liveness/telemetry checks (`test_live_run_lock_cannot_be_recovered`, `test_observer_delegates_restores_hooks_and_records_run`, `test_session_records_cpu_metadata_without_cuda_calls`). This managed host's Python PID is not present in the host `/proc` view, so psutil cannot inspect its own process. The deselected segmentation PID-identity test has the same host limitation. Those process-supervision modules were not modified.

The larger existing ROI browser workflow completed import, geometry review, quality labels and crop export, then its worker-backed crop import was interrupted in this host's process supervision. It is not reported as an end-to-end pass. Annotation display controls were independently verified against the actual annotation server, and crop-server/backend regressions passed.

Windows launcher/install scripts, CUDA inference and the user's actual trained checkpoint were not executed here. Export parity gates remain enabled for that checkpoint's local retry.
