"""Regression coverage for slim export and native-pixel display levels."""
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
import zipfile

import numpy as np
from PIL import Image

from nilt.export_support import export_dependencies
from nilt.image_io import NativeImage, display_statistics, window_display


class ExportDependencyDiagnostics(unittest.TestCase):
    def test_gpu_distribution_produces_valid_cpu_runtime_requirement_version(self):
        from nilt.deployment import _versions
        import importlib.metadata
        def version(name):
            if name == "onnxruntime":
                raise importlib.metadata.PackageNotFoundError(name)
            return "test"
        with patch("nilt.deployment.importlib.metadata.version", side_effect=version), patch.dict(sys.modules,{"onnxruntime":types.SimpleNamespace(__version__="1.22.0")}):
            self.assertEqual(_versions()["onnxruntime"],"1.22.0")

    def test_missing_package_names_running_python(self):
        error = ModuleNotFoundError("No module named 'onnx'", name="onnx")
        with patch("nilt.export_support.importlib.import_module", side_effect=error):
            with self.assertRaisesRegex(RuntimeError, "onnx is missing") as caught:
                export_dependencies()
        self.assertIn(sys.executable, str(caught.exception))
        self.assertIn("Setup-Export.cmd", str(caught.exception))

    def test_installed_but_broken_dll_is_not_reported_as_missing(self):
        with patch("nilt.export_support.importlib.import_module", side_effect=[types.SimpleNamespace(), ImportError("DLL load failed: native library")]):
            with self.assertRaisesRegex(RuntimeError, "onnxruntime is installed but cannot load") as caught:
                export_dependencies()
        self.assertIn("DLL load failed: native library", str(caught.exception))


class DisplayLevels(unittest.TestCase):
    def test_native_16bit_precision_is_used_before_display_conversion(self):
        pixels = np.repeat(np.array([[1001, 1002, 1003]], dtype=np.uint16)[:, :, None], 3, axis=2)
        image = NativeImage(pixels.copy())
        np.testing.assert_array_equal(np.asarray(window_display(image))[0,:,0], [0,128,255])
        np.testing.assert_array_equal(image.pixels, pixels)
        self.assertEqual(display_statistics(image)["range_max"],65535)

    def test_zero_or_custom_lower_limit_and_clipping(self):
        image = Image.fromarray(np.repeat(np.array([[0,50,100,200]], dtype=np.uint8)[:,:,None],3,axis=2))
        np.testing.assert_array_equal(np.asarray(window_display(image,50,100))[0,:,0],[0,0,255,255])
        np.testing.assert_array_equal(np.asarray(window_display(image,0,"max"))[0,:,0],[0,64,128,255])

    def test_constant_image_and_invalid_limits(self):
        image = Image.new("RGB", (3,3), (12,12,12))
        self.assertFalse(np.asarray(window_display(image)).any())
        for low,high in [(20,10),(-1,20),(0,256),(float("nan"),20),(12,12)]:
            with self.subTest(low=low,high=high), self.assertRaises(ValueError):
                window_display(image,low,high)


class ModelPackageDownload(unittest.TestCase):
    def test_catalog_lists_only_completed_package_zip(self):
        from nilt.dashboard import Dashboard
        from nilt.deployment import archive_package
        from tests.test_deployment import fake_package
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary)
            config=root/"project.yaml"
            config.write_text("paths:\n  output_root: ./results\ntasks:\n  vig:\n    dataset_root: ./data\n")
            app=Dashboard(config)
            (root/"packages").mkdir(exist_ok=True)
            package=fake_package(root/"packages/model")
            archive=archive_package(package)
            catalog=app.model_packages()
            self.assertEqual(len(catalog),1)
            self.assertEqual(catalog[0]["path"],str(archive))
            self.assertTrue(catalog[0]["url"].endswith("model.zip"))
            (root/"packages/unfinished.zip").write_bytes(b"incomplete")
            self.assertEqual(len(app.model_packages()),1)


@unittest.skipUnless(all(importlib.util.find_spec(name) for name in ("torch","torchvision","onnx","onnxruntime")), "Optional ML/export dependencies")
class GlobalPatchPortableExport(unittest.TestCase):
    def test_both_patch_aggregations_export_and_run_after_relocation(self):
        import torch
        import shutil
        from nilt import deployment, workflow
        from nilt.engine import make_model, save_checkpoint
        from nilt.common import sha_file
        from nilt.data import pixel_signature
        from nilt.runtime import PackageRunner, verify_package
        torch.set_num_threads(1)
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary)
            for aggregation in ("max","topk"):
                with self.subTest(aggregation=aggregation):
                    run=root/aggregation;run.mkdir()
                    cfg={"task":"vig","image_size":64,"resize":"pad","device":"cpu","cpu_threads":1,"num_workers":0,
                         "pretrained":False,"image_strategy":"global_patches","patches":{"size":32,"overlap":8,"chunk_size":2,
                         "aggregation":aggregation,"topk":3,"global_weight":.5},
                         "training":{"batch_size":1,"eval_batch_size":1,"amp":False},"policy":{}}
                    torch.manual_seed(41)
                    model,_=make_model("resnet18",cfg);model.eval()
                    save_checkpoint(run/"best.pt",model,cfg,"resnet18",41,0)
                    rows=[]
                    for i,color in enumerate(("white","black")):
                        path=root/f"{aggregation}{i}.png";Image.new("RGB",(56,52),color).save(path)
                        rows.append({"path":str(path),"relative_path":path.name,"label":i,"split":"selection","pixel_hash":pixel_signature(path)[0]})
                    (run/"config.json").write_text(json.dumps(cfg));(run/"manifest.csv").write_text("fixture")
                    (run/"selected.json").write_text(json.dumps({"name":"patch_fixture","threshold":.99,"status":"PILOT",
                        "members":[{"checkpoint":"best.pt","sha256":sha_file(run/"best.pt"),"architecture":"resnet18"}]}))
                    with patch.object(workflow,"open_run",return_value=(cfg,rows)):
                        output=deployment.export_package(run,root/(aggregation+"_package"))
                    archive=output.with_name(output.name+".zip")
                    with zipfile.ZipFile(archive) as bundle:
                        names=bundle.namelist()
                        self.assertIn("members/000/model.onnx",names)
                        self.assertNotIn("parity_predictions.csv",names)
                        self.assertNotIn("source_decision.json",names)
                        self.assertFalse(any(name.endswith((".pt",".png")) for name in names))
                        relocated=root/(aggregation+"_laptop");bundle.extractall(relocated)
                    shutil.rmtree(output);shutil.rmtree(run)
                    verify_package(relocated)
                    runner=PackageRunner(relocated)
                    self.assertTrue(0<=runner.score(rows[0]["path"])<=1)
                    self.assertEqual(json.loads((relocated/"export_validation.json").read_text())["status"],"passed")


if __name__ == "__main__":
    unittest.main()
