/* Controller integration WITHOUT a browser. A deliberately minimal DOM/canvas
 * harness dispatches pointer/control events into the unchanged app.js, while
 * fetch calls use the real Python server and synthetic image fixture.
 * This verifies event/state/persistence behavior, NOT layout or browser rendering.
 * Run from the project root: node tests/test_ui_controller.js
 */
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const {spawn} = require('node:child_process');
const readline = require('node:readline');
const ROOT = path.join(__dirname, '..');

class Element {
  constructor(tag = 'div') {
    this.tagName = tag.toUpperCase(); this.children = []; this.parentElement = null;
    this.dataset = {}; this.style = {}; this.listeners = {}; this.attributes = {};
    this.className = ''; this.textContent = ''; this.value = ''; this.checked = false; this.disabled = false;
    this.width = 0; this.height = 0; this.clientWidth = 1000; this.clientHeight = 800;
    this.classList = {
      contains: name => this.className.split(/\s+/).includes(name),
      add: (...names) => {this.className = [...new Set([...this.className.split(/\s+/).filter(Boolean), ...names])].join(' ');},
      remove: (...names) => {this.className = this.className.split(/\s+/).filter(x => !names.includes(x)).join(' ');},
      toggle: (name, force) => {const on = force ?? !this.classList.contains(name); this.classList[on ? 'add' : 'remove'](name); return on;}
    };
  }
  append(...items) { for (const item of items) {if (typeof item !== 'string') item.parentElement = this; this.children.push(item);} }
  appendChild(item) { this.append(item); return item; }
  replaceChildren(...items) {this.children = []; this.append(...items);}
  addEventListener(type, handler) {(this.listeners[type] ||= []).push(handler);}
  removeEventListener() {}
  async emit(type, props = {}) {
    const event = {target: this, currentTarget: this, preventDefault() {}, stopPropagation() {},
      button: 0, pointerId: 1, shiftKey: false, ctrlKey: false, metaKey: false, altKey: false, ...props};
    for (const handler of this.listeners[type] || []) await handler(event);
  }
  setAttribute(name, value) {this.attributes[name] = String(value); if (name === 'class') this.className = value;}
  getAttribute(name) {return this.attributes[name] ?? null;}
  focus() {document.activeElement = this;}
  blur() {document.activeElement = null;}
  setPointerCapture(id) {this.capture = id;}
  hasPointerCapture(id) {return this.capture === id;}
  releasePointerCapture() {this.capture = null;}
  getBoundingClientRect() {return {left: 0, top: 0, x: 0, y: 0, width: this.clientWidth, height: this.clientHeight};}
  showModal() {this.open = true;}
  close() {this.open = false;}
  scrollIntoView() {}
  matches(selector) {
    if (selector.startsWith('.')) return this.classList.contains(selector.slice(1));
    if (selector.startsWith('#')) return this.id === selector.slice(1);
    const attr = selector.match(/^\[([^=]+)(?:="?([^"\]]+)"?)?\]$/);
    if (attr) {const value = attr[1].startsWith('data-') ? this.dataset[attr[1].slice(5).replace(/-([a-z])/g, (_, c) => c.toUpperCase())] : this.getAttribute(attr[1]); return attr[2] === undefined ? value !== undefined && value !== null : value === attr[2];}
    return this.tagName === selector.toUpperCase();
  }
  querySelectorAll(selector) {
    const selectors = selector.split(',').map(x => x.trim().split(/\s+/).pop());
    const found = [];
    const visit = node => {for (const child of node.children) {if (!(child instanceof Element)) continue; if (selectors.some(x => child.matches(x))) found.push(child); visit(child);}};
    visit(this); return found;
  }
  querySelector(selector) {return this.querySelectorAll(selector)[0] || null;}
  closest(selector) {for (let node = this; node; node = node.parentElement) if (node.matches(selector)) return node; return null;}
  getContext() {
    if (!this.context) {
      const noop = () => {};
      this.context = {canvas: this, clearRect: noop, drawImage: noop, beginPath: noop, closePath: noop,
        moveTo: noop, lineTo: noop, arc: noop, ellipse: noop, stroke: noop, fill: noop,
        strokeRect: noop, fillRect: noop, setLineDash: noop, save: noop, restore: noop,
        translate: noop, scale: noop, setTransform: noop, strokeText: noop, fillText: noop,
        createImageData: (w, h) => ({data: new Uint8ClampedArray(w * h * 4), width: w, height: h}),
        putImageData: image => {this.pixels = image.data.slice();}};
    }
    return this.context;
  }
}
let document;
(async () => {
  let fixture;
  try {
    fixture = spawn(process.env.PYTHON || 'python', [path.join(__dirname, 'browser_fixture.py')], {cwd: ROOT, stdio: ['ignore', 'pipe', 'pipe']});
    fixture.stderr.on('data', x => process.stderr.write(x));
    const info = await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('Fixture startup timed out.')), 15000);
      readline.createInterface({input: fixture.stdout}).once('line', line => {clearTimeout(timer); try {resolve(JSON.parse(line));} catch (e) {reject(e);}});
      fixture.once('exit', code => {clearTimeout(timer); reject(new Error(`Fixture exited ${code}`));});
    });
    const html = await (await fetch(info.url)).text();
    const token = html.match(/name="session-token" content="([^"]+)"/)[1];
    const elements = new Map(); document = new Element('document'); document.activeElement = null;
    document.createElement = tag => new Element(tag);
    document.getElementById = id => {if (!elements.has(id)) throw new Error(`No HTML element #${id}`); return elements.get(id);};
    // Only tag attributes matter to controller behavior; structural layout is outside this test.
    for (const match of html.matchAll(/<([\w-]+)\s+([^>]*\b(?:id|data-tool)="[^"]+"[^>]*)>/g)) {
      const element = new Element(match[1]), attrs = match[2];
      for (const attribute of attrs.matchAll(/([\w-]+)="([^"]*)"/g)) {
        const [, name, value] = attribute; element.attributes[name] = value;
        if (name === 'id') {element.id = value; elements.set(value, element);}
        else if (name === 'class') element.className = value;
        else if (name === 'value') element.value = value;
        else if (name.startsWith('data-')) element.dataset[name.slice(5).replace(/-([a-z])/g, (_, c) => c.toUpperCase())] = value;
      }
      element.checked = /\bchecked\b/.test(attrs); element.open = /\bopen\b/.test(attrs); document.append(element);
    }
    const $ = id => document.getElementById(id);
    $('empty-state').append(new Element('h2'), new Element('p'));
    $('polarity').value = 'both'; $('show-mask').checked = true; $('show-roi').checked = true;
    const querySelector = document.querySelector.bind(document);
    document.querySelector = selector => selector.startsWith('meta[') ? {content: token} : querySelector(selector);
    const window = new Element('window'), errors = [], requests = [];
    const context = vm.createContext({document, window, console: {log() {}, warn() {}, error: e => errors.push(String(e))},
      Uint8Array, Uint8ClampedArray, Math, Number, String, Boolean, Object, Array, Set, Map,
      structuredClone, crypto: crypto.webcrypto, confirm: () => true, prompt: () => 'Synthetic exclusion',
      setTimeout: () => 0, clearTimeout() {},
      ResizeObserver: class {observe() {}},
      createImageBitmap: async blob => {const bytes = Buffer.from(await blob.arrayBuffer()); return {width: bytes.readUInt32BE(16), height: bytes.readUInt32BE(20), close() {}};},
      fetch: async (url, options = {}) => {
        requests.push({url, method: options.method || 'GET', payload: options.body ? JSON.parse(options.body) : null});
        return fetch(new URL(url, info.url), {...options, headers: {...options.headers, ...(options.method === 'POST' ? {Origin: info.url} : {})}});
      }});
    vm.runInContext(fs.readFileSync(path.join(ROOT, 'topseg/web/mask.js'), 'utf8'), context, {filename: 'mask.js'});
    vm.runInContext(fs.readFileSync(path.join(ROOT, 'topseg/web/app.js'), 'utf8'), context, {filename: 'app.js'});
    async function until(predicate, message) {
      const deadline = Date.now() + 15000;
      while (!predicate()) {if (errors.length) throw new Error(errors.join('\n')); if (Date.now() > deadline) throw new Error(message); await new Promise(resolve => setTimeout(resolve, 10));}
    }
    async function loaded(name) {await until(() => $('image-name').textContent === name && $('loading').classList.contains('hidden'), `Did not load ${name}`);}
    const counts = () => ['inner-count', 'outer-count'].map(id => Number(String($(id).textContent).replaceAll(',', '')));
    const rows = () => $('object-list').querySelectorAll('.object-row');
    const click = id => $(id).emit('click');
    async function tool(name) {await document.querySelectorAll('[data-tool]').find(x => x.dataset.tool === name).emit('click');}
    function screen(x, y) {
      const match = $('canvas-wrap').style.transform.match(/translate\(([^p]+)px, ([^p]+)px\) scale\(([^)]+)\)/);
      return {clientX: Number(match[1]) + x * Number(match[3]), clientY: Number(match[2]) + y * Number(match[3])};
    }
    async function drag(x0, y0, x1, y1) {
      const a = screen(x0, y0), b = screen(x1, y1); await $('viewport').emit('pointerdown', a);
      await $('viewport').emit('pointermove', b); await $('viewport').emit('pointerup', b);
    }
    async function record(name) {
      const headers = {'X-Session-Token': token};
      const project = await (await fetch(info.url + '/api/project', {headers})).json();
      return (await fetch(info.url + `/api/image/${project.items.find(x => x.relative_path === name).id}`, {headers})).json();
    }
    async function save() {await click('save-draft'); await until(() => /^Saved revision /.test($('save-state').textContent) && $('loading').classList.contains('hidden'), 'Save failed');}
    await loaded('top_unit_01.png'); await click('clear-mask'); assert.deepEqual(counts(), [0, 0]);
    await tool('octagon'); await drag(170, 130, 550, 510);
    await tool('circle'); await drag(312, 260, 337, 260);
    const circle = counts()[0]; assert(circle > 1800 && circle < 2100); assert.equal(rows().length, 1);
    await drag(332, 260, 357, 260); assert.equal(rows().length, 2);
    await rows().find(row => row.querySelector('.object-select').title === 'Select Circle 2').querySelector('.object-delete').emit('click'); assert.equal(rows().length, 1); assert.deepEqual(counts(), [circle, 0]);
    await click('undo'); assert.equal(rows().length, 2); await click('redo'); assert.equal(rows().length, 1);
    const visible = rows()[0].querySelector('.object-visible'); visible.checked = false; await visible.emit('change');
    assert.deepEqual(counts(), [circle, 0]); assert.equal($('mask-canvas').pixels[(260 * 720 + 312) * 4 + 3], 0);
    await click('undo'); assert.equal(rows()[0].querySelector('.object-visible').checked, true);
    await click('redo'); assert.equal(rows()[0].querySelector('.object-visible').checked, false);
    await save(); const hidden = await record('top_unit_01.png'); assert.equal(hidden.objects[0].visible, false); assert(hidden.mask_rle.some(x => x[0] === 1));
    await click('next'); await loaded('top_unit_02.png'); await click('previous'); await loaded('top_unit_01.png');
    assert.deepEqual(counts(), [circle, 0]); assert.equal(rows()[0].dataset.objectId, hidden.objects[0].id);
    assert.equal(rows()[0].querySelector('.object-visible').checked, false);
    assert.equal($('mask-canvas').pixels[(260 * 720 + 312) * 4 + 3], 0);
    const thumbnail = rows()[0].querySelector('canvas'); assert(thumbnail.pixels.some(value => value > 0), 'Shape thumbnail must contain occupied pixels.');
    const showAgain = rows()[0].querySelector('.object-visible'); showAgain.checked = true; await showAgain.emit('change');
    await tool('eraser'); await drag(312, 260, 320, 260); assert(counts()[0] < circle);
    await click('undo'); assert.deepEqual(counts(), [circle, 0]);
    await tool('octagon'); await drag(420, 360, 650, 590); assert.deepEqual(counts(), [0, circle]);
    await click('undo'); assert.deepEqual(counts(), [circle, 0]); await click('redo'); assert.deepEqual(counts(), [0, circle]); await click('undo');
    for (const name of ['brush', 'circle']) {
      await click('fit'); await tool(name); const transform = $('canvas-wrap').style.transform, before = counts(), objectCount = rows().length;
      await $('viewport').emit('pointerdown', {clientX: 5, clientY: 5});
      await $('viewport').emit('pointermove', {clientX: 35, clientY: 45}); await $('viewport').emit('pointerup', {clientX: 35, clientY: 45});
      assert.notEqual($('canvas-wrap').style.transform, transform); assert.deepEqual(counts(), before); assert.equal(rows().length, objectCount);
    }
    await click('fit'); await tool('brush'); const transform = $('canvas-wrap').style.transform;
    await drag(700, 500, 750, 500); assert.equal($('canvas-wrap').style.transform, transform); await click('undo');
    await tool('rectangle'); await drag(145, 280, 205, 340); assert(counts()[0] > circle && counts()[1] > 0);
    const beforeDetect = await record('top_unit_01.png'); await click('detect-roi');
    assert.equal((await record('top_unit_01.png')).revision, beforeDetect.revision);
    assert(requests.some(request => request.url.endsWith('/detect-roi')));
    await tool('polygon');
    for (const [x, y] of [[535, 300], [575, 300], [575, 350], [535, 350]]) await $('viewport').emit('pointerdown', screen(x, y));
    await document.emit('keydown', {key: 'Enter'}); assert.equal(rows().length, 3);
    await click('undo'); assert.equal(rows().length, 2); await click('redo'); assert.equal(rows().length, 3);
    await save(); await click('approve'); await loaded('top_unit_02.png');
    // Reject after an unsaved shape: the editor must save that shape first.
    await click('clear-mask'); await tool('circle'); await drag(310, 260, 330, 260); const secondCount = counts().reduce((a, b) => a + b, 0);
    await click('reject-next'); await loaded('top_unit_03.png');
    const rejected = await record('top_unit_02.png'); assert.equal(rejected.status, 'rejected');
    assert.equal(rejected.mask_rle.reduce((n, [label, length]) => n + (label ? length : 0), 0), secondCount);
    await click('clear-mask'); await click('approve-clean');
    await until(() => /2 \/ 2 approved.*1 excluded/.test($('progress-text').textContent), 'Approval did not finish');
    assert.equal($('image-name').textContent, 'top_unit_03.png');
    $('hide-rejected').checked = false; await $('hide-rejected').emit('change');
    const rejectedRow = $('image-list').querySelectorAll('.image-item').find(x => x.dataset.imageId === rejected.id);
    assert(rejectedRow); await rejectedRow.emit('click'); await loaded('top_unit_02.png');
    await click('restore-image'); await until(() => /Draft/i.test($('image-status').textContent), 'Restore did not return to draft');
    assert.equal((await record('top_unit_02.png')).status, 'draft');
    // v2 proposals are previews: retain manual additions, erasures and notes, with undo and no disk mutation.
    $('annotation-method').value='basic';await $('annotation-method').emit('change');
    $('keep-manual').checked=false;await click('regenerate');
    assert(rows().length>0,'Basic reload should generate synthetic defects');
    assert(requests.some(r=>r.url.endsWith('/proposal-preview')));
    const previewRevision=(await record('top_unit_02.png')).revision;
    await tool('circle');await drag(360,320,372,320);
    await tool('eraser');await drag(308,258,310,260);
    $('notes').value='Keep these review notes';await $('notes').emit('input');
    const editedCounts=counts();const manualRows=rows().filter(row=>row.querySelector('.object-select').title.includes('Circle'));
    assert(manualRows.length===1);$('keep-manual').checked=true;await click('regenerate');
    assert.equal((await record('top_unit_02.png')).revision,previewRevision,'Reload must not save a revision');
    assert.equal($('notes').value,'Keep these review notes');
    assert.equal($('mask-canvas').pixels[(258*720+308)*4+3],0,'Manual erasure must survive reload');
    assert($('mask-canvas').pixels[(320*720+360)*4+3]>0,'Manual addition must survive reload');
    assert.equal($('undo-reload').disabled,false);await click('undo-reload');assert.deepEqual(counts(),editedCounts);
    await save();const savedEdits=await record('top_unit_02.png');assert(savedEdits.manual_edits.erase_rle.some(([v])=>v===1));assert.equal(savedEdits.notes,'Keep these review notes');
    // A failed reference reload keeps annotations, history and notes intact.
    $('annotation-method').value='reference';await $('annotation-method').emit('change');const beforeFailure=counts(),rowsBeforeFailure=rows().length;
    await click('regenerate');assert.deepEqual(counts(),beforeFailure);assert.equal(rows().length,rowsBeforeFailure);assert.equal($('notes').value,'Keep these review notes');
    assert(errors.length===1&&/reference/i.test(errors[0]));errors.length=0;
    // Zones are separate geometry; save/load profile preserves regions without changing the inner boundary.
    $('annotation-method').value='exclusions';await $('annotation-method').emit('change');$('zone-category').value='label';await click('draw-zone');
    for(const [x,y]of [[100,60],[140,60],[140,90],[100,90]])await $('viewport').emit('pointerdown',screen(x,y));await document.emit('keydown',{key:'Enter'});
    assert.equal($('zone-list').querySelectorAll('.zone-row').length,1);
    $('detection-scope').value='custom';await $('detection-scope').emit('change');await click('draw-scope');
    for(const [x,y]of [[90,50],[630,50],[630,590],[90,590]])await $('viewport').emit('pointerdown',screen(x,y));await document.emit('keydown',{key:'Enter'});
    await click('save-profile');assert(/revision 1/.test($('profile-info').textContent));
    $('annotation-method').value='basic';await $('annotation-method').emit('change');await click('load-profile');assert.equal($('annotation-method').value,'exclusions');assert.equal($('detection-scope').value,'custom');
    await save();const finalRecord=await record('top_unit_02.png');assert.equal(finalRecord.automation.zones[0].category,'label');assert.equal(finalRecord.automation.scope_roi.type,'polygon');assert.deepEqual(finalRecord.roi,savedEdits.roi);
    assert.deepEqual(errors, []);
    for (const [name, hash] of Object.entries(info.sources)) assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(info.root, 'source', name))).digest('hex'), hash);
    console.log(`PASS: annotation controller + real HTTP server (${requests.length} requests); polygon ROI/detection, auto classes, closed polygon, overlapping layers/delete, display-only visibility, thumbnail pixels, erasure, undo/redo, save/reopen, background pan, originating-inside stroke, pending-edit rejection, skip excluded, restore, original hashes. v2 preview reload/manual preservation/failure rollback, reusable profile and independent zones. DOM/canvas simulated; browser rendering NOT tested.`);
  } catch (error) {console.error(error.stack || error); process.exitCode = 1;}
  finally {if (fixture) fixture.kill('SIGINT');}
})();
