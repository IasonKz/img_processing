# Configuration Reference

`project.yaml` is the configuration source. Use paths and settings here instead of changing application code. Relative paths resolve against the configuration file's directory. CLI output paths supplied directly as arguments resolve against the terminal's current directory.

## Project paths and grouping

| Key | Purpose |
| --- | --- |
| `input_dir` | Folder containing source top-view images; nested folders are scanned |
| `project_dir` | Working copies, revision history, and approval state |
| `output_dir` | Training runs and associated results |
| `group_regex` | Optional expression identifying a physical unit from a relative source path |
| `max_image_pixels` | Maximum native pixel count per imported image; default `25000000`, supported range `1` to `40000000` |
| `annotation.port` | Local browser server port; default `8765` |

Keep working and output folders outside the source image tree. Changing `input_dir` to a different dataset while reusing the same project can make provenance unclear; create a separate project for an unrelated annotation effort.

If filenames are `tray_A/unit_001_start.png` and `tray_A/unit_001_final.png`, an example grouping rule is:

```yaml
group_regex: '(?P<unit>tray_[^/]+/unit_[0-9]+)'
```

The named `unit` capture, or the first capture group, supplies the group identifier. Include the tray or other namespace if unit numbers repeat. A physical unit must not be split between training and validation. Without a grouping rule, pixel identity is used; this deduplicates exact copies but cannot identify different photographs of the same unit. Check imported groups before training.

The grouping rule is fixed when the annotation project is created. Changing it requires a separate annotation project. A filename that does not match a configured expression is reported as an invalid import rather than assigned an unrelated fallback group.

## Classical proposal settings

| Key under `classical` | Default | Effect |
| --- | ---: | --- |
| `background_sigma` | `8.0` | Scale in native pixels used to estimate smooth background |
| `sensitivity` | `4.0` | Detection threshold multiplier; larger values generally produce fewer proposals |
| `min_area` | `6` | Minimum connected candidate area in native pixels |
| `max_area_fraction` | `0.03` | Reject overly large components relative to image area |
| `boundary_guard` | `3` | Exclude a narrow band around the lens boundary from automatic proposals |
| `polarity` | `both` | Propose `dark`, `bright`, or both types of local contrast |

These controls generate a starting mask. Normal texture, reflections, lens edges, and uneven lighting can produce false positives; low-contrast defects can be missed. Adjust the ellipse before tuning sensitivity. A boundary guard only suppresses automatic proposals: manually label a real defect at the boundary when required.

The ellipse is stored per image as center coordinates `cx`, `cy` and radii `rx`, `ry`, measured in native image pixels. Automatic proposals inside the ellipse are labeled Inner; those outside are labeled Outer. Changing the ellipse does not redefine the meaning of existing manual labels.

## Training settings

| Key under `training` | Default | Purpose |
| --- | ---: | --- |
| `epochs` | `25` | Maximum number of passes through the training split |
| `batch_size` | `2` | Images per training batch |
| `learning_rate` | `0.001` | Optimizer learning rate |
| `image_size` | `512` | Square model input after aspect-preserving fit and padding |
| `base_channels` | `16` | Width of the small U-Net |
| `seed` | `42` | Split and training random seed |
| `val_fraction` | `0.2` | Requested validation share, subject to whole-group allocation |
| `patience` | `6` | Early-stopping patience in epochs |
| `device` | `cpu` | `cpu`, `cuda`, or `auto` |
| `num_workers` | `0` | Must be zero in this pilot; parallel loading is not implemented |
| `cpu_threads` | `4` | Torch CPU thread count used during training |
| `augment` | `true` | Apply random 90-degree rotations and horizontal flips to training image/mask pairs |
| `min_images` | `5` | Minimum number of approved images required to start |
| `require_both_defect_classes` | `true` | Require labeled examples of both foreground classes |

The full-resolution working image and annotation are preserved regardless of `image_size`. Reducing model input size can remove thin scratches and small marks. Increasing it above 600 is supported when model memory permits; keep the same preprocessing for comparisons between runs. Padding is ignored in loss and metrics.

`require_both_defect_classes: false` is for a deliberate partial-data experiment. A class with no examples cannot be learned or validated; do not interpret a missing class score as a successful result.

Set `augment: false` if rotation or reflection is inappropriate for the inspection task. Validation and inference do not use these random transformations.

## Minimal example

```yaml
input_dir: ../data/top
project_dir: ../work/top_annotations
output_dir: ../outputs/top_segmentation
group_regex: null

annotation:
  port: 8765

classical:
  background_sigma: 8.0
  sensitivity: 4.0
  min_area: 6
  max_area_fraction: 0.03
  boundary_guard: 3
  polarity: both

training:
  epochs: 25
  batch_size: 2
  learning_rate: 0.001
  image_size: 512
  base_channels: 16
  seed: 42
  val_fraction: 0.2
  patience: 6
  device: cpu
  num_workers: 0
  cpu_threads: 4
  augment: true
  min_images: 5
  require_both_defect_classes: true
```
