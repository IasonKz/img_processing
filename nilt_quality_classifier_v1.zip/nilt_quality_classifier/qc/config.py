from __future__ import annotations

import copy
import os
from pathlib import Path
from typing import Any, Mapping

import yaml


def load_yaml(path: str | Path) -> dict[str, Any]:
    config_path = Path(path).expanduser().resolve()
    if not config_path.is_file():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    with config_path.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle) or {}

    if not isinstance(data, dict):
        raise ValueError(f"The YAML root must be a mapping: {config_path}")

    data["_config_path"] = str(config_path)
    data["_config_dir"] = str(config_path.parent)
    return data


def save_yaml(data: Mapping[str, Any], path: str | Path) -> None:
    output = copy.deepcopy(dict(data))
    output.pop("_config_path", None)
    output.pop("_config_dir", None)
    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as handle:
        yaml.safe_dump(output, handle, sort_keys=False, allow_unicode=True)


def deep_update(base: dict[str, Any], updates: Mapping[str, Any]) -> dict[str, Any]:
    """Recursively update ``base`` and return a new dictionary."""
    result = copy.deepcopy(base)
    for key, value in updates.items():
        if (
            key in result
            and isinstance(result[key], dict)
            and isinstance(value, Mapping)
        ):
            result[key] = deep_update(result[key], value)
        else:
            result[key] = copy.deepcopy(value)
    return result


def get(config: Mapping[str, Any], dotted_key: str, default: Any = None) -> Any:
    current: Any = config
    for part in dotted_key.split("."):
        if not isinstance(current, Mapping) or part not in current:
            return default
        current = current[part]
    return current


def require(config: Mapping[str, Any], dotted_key: str) -> Any:
    value = get(config, dotted_key, None)
    if value is None or value == "":
        raise ValueError(f"Missing required configuration value: {dotted_key}")
    return value


def resolve_path(
    value: str | Path | None,
    *,
    config: Mapping[str, Any] | None = None,
    base_dir: str | Path | None = None,
    must_exist: bool = False,
) -> Path | None:
    if value is None or str(value).strip() == "":
        return None

    expanded = os.path.expandvars(os.path.expanduser(str(value).strip()))
    path = Path(expanded)

    if not path.is_absolute():
        if base_dir is None and config is not None:
            base_dir = config.get("_config_dir")
        if base_dir is not None:
            path = Path(base_dir) / path

    path = path.resolve()
    if must_exist and not path.exists():
        raise FileNotFoundError(f"Path does not exist: {path}")
    return path


def clean_for_serialization(config: Mapping[str, Any]) -> dict[str, Any]:
    output = copy.deepcopy(dict(config))
    output.pop("_config_path", None)
    output.pop("_config_dir", None)
    return output
