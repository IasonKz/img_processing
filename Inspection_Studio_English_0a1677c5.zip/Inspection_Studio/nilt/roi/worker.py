"""Subprocess entry point for cancellable, local ROI segmentation jobs."""
from __future__ import annotations

import argparse
import json
import sys
import traceback
from pathlib import Path


def main(argv=None):
    parser = argparse.ArgumentParser(description="Inspection Studio ROI segmentation worker")
    parser.add_argument("--request", required=True, help="JSON request containing action, dataset, output and options")
    args = parser.parse_args(argv)
    request = json.loads(Path(args.request).read_text(encoding="utf-8"))
    action = request.get("action", "train")
    if action not in ("train", "evaluate"):
        parser.error("The ROI worker supports action=train or evaluate.")
    from .learning import train, evaluate
    try:
        if action == "train":
            train(request["dataset"], request["output"], request.get("options", {}))
        else:
            evaluate(request["dataset"], request.get("model") or request["model_path"], request["output"],
                     split=request.get("options", {}).get("split", "test"))
    except Exception:
        traceback.print_exc()
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
