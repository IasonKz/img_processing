# Command reference

Run these commands from the folder containing `inspection.py` and `project.yaml`. The examples use PowerShell. Replace example paths before execution. Options shown as alternatives are not meant to be started simultaneously.

On Linux, use `.venv-studio5/bin/python` in place of `& $StudioPython`, forward-slash Linux paths, and `bash Start.sh` to launch the dashboard. See [INSTALLATION_LINUX.md](INSTALLATION_LINUX.md).

Read the interpreter selected during setup once per terminal:

```powershell
$StudioPython = (Get-Content .studio-python.txt -Raw).Trim()
```

No activation is required. `Start.cmd` performs the equivalent dashboard launch automatically.

## Help and environment

```powershell
& $StudioPython inspection.py --help
& $StudioPython inspection.py search --help
& $StudioPython -m pip check
& $StudioPython inspection.py doctor --config project.yaml --profile laptop --task vig
& $StudioPython inspection.py download-weights --config project.yaml --profile laptop --task vig
& $StudioPython inspection.py dashboard --config project.yaml
```

For a workstation, use `--profile workstation` or `--profile workstation_large` for resource checks and weights.

## Audit and search

```powershell
& $StudioPython inspection.py audit --config project.yaml --profile laptop --task vig
& $StudioPython inspection.py search --config project.yaml --profile laptop --task vig
```

Audit prepares an experiment with a manifest; it does not train. A new `search --config` creates a fresh experiment and performs its own audit.

GPU alternatives:

```powershell
& $StudioPython inspection.py search --config project.yaml --profile workstation --task vig
& $StudioPython inspection.py search --config project.yaml --profile workstation_large --task vig
```

Restrict model families or set an explicit time allowance:

```powershell
& $StudioPython inspection.py search --config project.yaml --profile laptop --task vig --models resnet18 efficientnet_b0 --hours 1
```

There is no profile time ceiling: `--hours` accepts any positive finite duration for a new search. A shorter run may produce no completed trial. Select execution independently with `--device`:

```powershell
& $StudioPython inspection.py search --config project.yaml --profile laptop --task vig --models efficientnet_b0 convnext_tiny --hours 24 --device cuda
```

This uses the laptop preset as a starting configuration but allocates a 24-hour CUDA search. Inspect training batch, AMP, trial count, and search space as well; a device/time override does not automatically optimize every other control.

## Continue or finalize

```powershell
& $StudioPython inspection.py search --run 'D:/Inspection/results/vig/RUN_ID'
& $StudioPython inspection.py search --run 'D:/Inspection/results/vig/RUN_ID' --device cuda
& $StudioPython inspection.py finalize-search --run 'D:/Inspection/results/vig/RUN_ID' --hours 0.5
```

Search resume retains the original configuration and remaining allowance. Finalize is a separately requested evaluation allowance for already trained candidates; it does not train new trials. Use `resume --run ...` only for the earlier non-Optuna `run` workflow.

After confirming an abandoned worker has stopped, the relevant resume command can accept `--recover-lock`. Do not use lock recovery to start simultaneous writers.

## Status, reports, and comparison

```powershell
& $StudioPython inspection.py status --run 'D:/Inspection/results/vig/RUN_ID'
& $StudioPython inspection.py status --config project.yaml --task vig
& $StudioPython inspection.py report --run 'D:/Inspection/results/vig/RUN_ID'
& $StudioPython inspection.py report --config project.yaml --task vig
& $StudioPython inspection.py compare --old-run 'D:/Inspection/results/vig/OLD_RUN' --new-run 'D:/Inspection/results/vig/NEW_RUN' --output 'D:/Inspection/comparisons/old-new'
```

Comparison evaluates compatible common records and fixed decisions. A model score on a different batch is not a paired comparison.

## Save a decision

Choose one mode:

```powershell
& $StudioPython inspection.py decision --run 'D:/Inspection/results/vig/RUN_ID' --mode policy --output-root decisions
& $StudioPython inspection.py decision --run 'D:/Inspection/results/vig/RUN_ID' --mode manual --threshold 0.65 --output-root decisions
& $StudioPython inspection.py decision --run 'D:/Inspection/results/vig/RUN_ID' --mode argmax --output-root decisions
& $StudioPython inspection.py decision --run 'D:/Inspection/results/vig/RUN_ID' --mode scores_only --output-root decisions
```

The example threshold is illustrative, not a recommended operating point. Add `--candidate NAME` for another recorded candidate. Keep the complete decision directory with its integrity record.

```powershell
& $StudioPython inspection.py threshold-review --run 'D:/Inspection/results/vig/RUN_ID' --thresholds 0.15 0.20 0.25 --output-root threshold_review
```

Threshold review uses calibration data and does not retrain the model.

## Classify and review images

```powershell
& $StudioPython inspection.py classify --decision 'D:/Inspection/decisions/DECISION_ID/decision.json' --input 'D:/Inspection/incoming/vig' --output-root classified --device cpu --copy-images
```

For actual reference labels in `good`/`bad` folders:

```powershell
& $StudioPython inspection.py classify --decision 'D:/Inspection/decisions/DECISION_ID/decision.json' --input 'D:/Inspection/reference/vig' --output-root classified --device cuda --copy-images --labeled
```

Add `--run 'D:/Relocated/RUN_ID'` only when supplying a verified relocated source for the saved decision. Operator review uses the dashboard and is recorded separately; there is no automatic rewrite of source labels.

## Compose and run a workflow

```powershell
& $StudioPython inspection.py workflow-create --spec workflow-spec.json --output-root workflows
& $StudioPython inspection.py workflow-run --workflow 'D:/Inspection/workflows/WORKFLOW_ID/workflow.json' --input 'D:/Inspection/reference/vig' --output-root classified --device cuda --labeled
```

See [WORKFLOWS.md](WORKFLOWS.md) for the JSON schema and rules. Copies are on by default for workflow execution; add `--no-copy-images` for tables without copied previews.

## Decision Lab systems

Create the JSON definition with the GUI's **Advanced system definition** or the example in [DECISION_LAB.md](DECISION_LAB.md). This uses a different artifact than a legacy `workflow.json`:

```powershell
& $StudioPython inspection.py system-preview --spec decision-spec.json
& $StudioPython inspection.py system-create --spec decision-spec.json --output-root decision_systems
& $StudioPython inspection.py system-run --system 'D:/Inspection/decision_systems/SYSTEM_ID/decision_system.json' --input 'D:/Inspection/reference/vig' --output-root classified --device cuda --labeled
```

Preview uses calibration only. Creation freezes the system before its separately marked selection report. Neither automatically reads final test. After freezing the complete system, request its final test explicitly:

```powershell
& $StudioPython inspection.py system-evaluate --system 'D:/Inspection/decision_systems/SYSTEM_ID/decision_system.json' --confirm-final-test
```

This tests the whole triage/ensemble/stacker/cascade, not an individual source model. Do not repeatedly retune after looking at the same final test.

## Export confirmed review labels

```powershell
& $StudioPython inspection.py review-export --sessions 'D:/Inspection/classified/SESSION_ID' --source-run 'D:/Inspection/results/vig/SOURCE_RUN' --output-root review_datasets
```

The returned generated configuration is valid only if the export reports `ready_for_update`. A source-run export requires replay and retains all old partitions; only old train plus eligible new confirmed units train. Omit `--source-run` for annotation-only export with no training-ready claim. See [IMAGE_REVIEW.md](IMAGE_REVIEW.md).

## Evaluate the fixed selected system

```powershell
& $StudioPython inspection.py evaluate --run 'D:/Inspection/results/vig/RUN_ID' --split final-test
& $StudioPython inspection.py evaluate --run 'D:/Inspection/results/vig/RUN_ID' --split external --input 'D:/Inspection/new_holdout/vig' --groups-csv 'D:/Inspection/new_holdout/groups.csv'
```

These commands evaluate the run's fixed selected system. They do not silently evaluate an unrelated manual decision or composed workflow. Revised decisions and recipes require their own frozen evaluation on independent labeled inputs.

Activation enforces configured checks and may be refused:

```powershell
& $StudioPython inspection.py activate --run 'D:/Inspection/results/vig/RUN_ID' --config project.yaml
```

Activation is not needed for development classification with a saved decision.

## Package, transfer, and restore

```powershell
& $StudioPython inspection.py package --run 'D:/Inspection/results/vig/RUN_ID' --kind training --output 'D:/Inspection/packages/vig-training'
& $StudioPython inspection.py restore --package 'D:/Inspection/packages/vig-training' --data-root 'D:/InspectionData/vig' --output 'D:/Inspection/restored/vig-run'
```

Transfer the matching dataset separately. A training package includes recorded study/checkpoint state, not the image dataset or a reusable virtual environment.

ONNX export requires optional export dependencies:

```powershell
& $StudioPython inspection.py package --run 'D:/Inspection/results/vig/RUN_ID' --kind inference --format onnx --output 'D:/Inspection/packages/vig-inference'
& $StudioPython inspection.py predict --model 'D:/Inspection/packages/vig-inference' --input 'D:/Inspection/incoming/vig' --output 'D:/Inspection/predictions/batch_001' --device cpu
```

To export an explicit decision, add `--decision 'D:/Inspection/decisions/DECISION_ID/decision.json'` to the package command. Use a new output directory. The source model, preprocessing, decision, and export parity checks remain part of the package identity.

## Add new training data

```powershell
& $StudioPython inspection.py update --config project.yaml --profile workstation --task vig --from-run 'D:/Inspection/results/vig/PREVIOUS_RUN'
```

Update creates a new version and retains lineage/holdout protections. For a fresh Optuna experiment from pretrained weights, use `search --config`. Do not edit frozen manifests or move inspected test records into training.

## Local synthetic software check

```powershell
& $StudioPython scripts/smoke_v3.py --output ../studio5_legacy_smoke
```

The output must be new or empty. This creates synthetic images and verifies a small workflow; it is not a model-quality test on real defects.
