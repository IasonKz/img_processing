"""PyCharm entry point: edit launcher.yaml, then press Run. Never edit this file."""
from pathlib import Path
import multiprocessing
import yaml

from binary_inspection.cli import main


def launch() -> int:
    root = Path(__file__).resolve().parent
    with (root / "launcher.yaml").open(encoding="utf-8") as handle:
        settings = yaml.safe_load(handle)
    action = str(settings.get("action", "audit"))
    configuration = Path(settings.get("config", "configs/top.yaml"))
    if not configuration.is_absolute():
        configuration = root / configuration
    args = [action, "--config", str(configuration)]
    for key, option in (("dataset_override", "--dataset"), ("run_output_override", "--output")):
        if settings.get(key):
            args.extend((option, str(settings[key])))
    if action == "train" and settings.get("model"):
        args.extend(("--model", str(settings["model"])))
    if action == "predict":
        if not settings.get("input"):
            raise ValueError("Set input in launcher.yaml before prediction")
        args.extend(("--input", str(settings["input"])))
        if settings.get("prediction_output"):
            args.extend(("--pred-output", str(settings["prediction_output"])))
    return main(args)


if __name__ == "__main__":
    multiprocessing.freeze_support()
    raise SystemExit(launch())
