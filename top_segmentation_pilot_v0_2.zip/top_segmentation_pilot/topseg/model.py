"""Small segmentation network. This module requires the optional PyTorch extra."""
from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F


class ConvBlock(nn.Module):
    def __init__(self, incoming: int, outgoing: int):
        super().__init__()
        groups = next(g for g in (8, 4, 2, 1) if outgoing % g == 0)
        self.layers = nn.Sequential(
            nn.Conv2d(incoming, outgoing, 3, padding=1, bias=False),
            nn.GroupNorm(groups, outgoing), nn.ReLU(inplace=True),
            nn.Conv2d(outgoing, outgoing, 3, padding=1, bias=False),
            nn.GroupNorm(groups, outgoing), nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.layers(x)


class SmallUNet(nn.Module):
    """Three encoder stages, bilinear decoder, three mutually exclusive labels."""
    def __init__(self, base_channels: int = 16):
        super().__init__()
        b = int(base_channels)
        if b < 4 or b > 64:
            raise ValueError("base_channels must be between 4 and 64.")
        self.encoder1, self.encoder2 = ConvBlock(3, b), ConvBlock(b, 2*b)
        self.encoder3, self.bridge = ConvBlock(2*b, 4*b), ConvBlock(4*b, 8*b)
        self.decoder3 = ConvBlock(12*b, 4*b)
        self.decoder2 = ConvBlock(6*b, 2*b)
        self.decoder1 = ConvBlock(3*b, b)
        self.head = nn.Conv2d(b, 3, 1)

    def forward(self, x):
        e1 = self.encoder1(x)
        e2 = self.encoder2(F.max_pool2d(e1, 2))
        e3 = self.encoder3(F.max_pool2d(e2, 2))
        z = self.bridge(F.max_pool2d(e3, 2))
        z = self.decoder3(torch.cat((F.interpolate(z, size=e3.shape[-2:], mode="bilinear", align_corners=False), e3), 1))
        z = self.decoder2(torch.cat((F.interpolate(z, size=e2.shape[-2:], mode="bilinear", align_corners=False), e2), 1))
        z = self.decoder1(torch.cat((F.interpolate(z, size=e1.shape[-2:], mode="bilinear", align_corners=False), e1), 1))
        return self.head(z)


def segmentation_loss(logits, target, class_weights):
    """Padding never enters either loss; background is omitted from Dice."""
    valid = target != 255
    if not bool(valid.any()):
        raise ValueError("Training sample contains only ignored pixels.")
    ce = F.cross_entropy(logits, target, weight=class_weights, ignore_index=255)
    probabilities = logits.softmax(1) * valid[:, None]
    safe_target = target.masked_fill(~valid, 0)
    one_hot = F.one_hot(safe_target, 3).permute(0, 3, 1, 2).to(logits.dtype) * valid[:, None]
    p, y = probabilities[:, 1:], one_hot[:, 1:]
    axes = (0, 2, 3)
    dice = (2 * (p*y).sum(axes) + 1) / (p.sum(axes) + y.sum(axes) + 1)
    return ce + 0.5 * (1 - dice.mean())
