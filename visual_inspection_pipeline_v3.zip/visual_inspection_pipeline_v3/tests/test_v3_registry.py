"""Preserve completed Optuna transactions when packaging a paused run."""
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

from nilt.common import read_json, sha_file
from nilt.registry import create_training_package, restore_training_package, _snapshot_sqlite
from test_integration_v2 import fixture_run


class OptunaSnapshotTests(unittest.TestCase):
    def test_wal_transactions_backed_up_under_lock_and_restore(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            run, data, _ = fixture_run(root)
            folder = run / "search"
            folder.mkdir()
            database = folder / "optuna.sqlite3"
            connection = sqlite3.connect(database)
            try:
                connection.execute("PRAGMA journal_mode=WAL")
                connection.execute("PRAGMA wal_autocheckpoint=0")
                connection.execute("CREATE TABLE trials(id INTEGER PRIMARY KEY, value REAL)")
                connection.execute("INSERT INTO trials VALUES (1, .82)")
                connection.commit()
                self.assertTrue(Path(str(database) + "-wal").exists())
                observed = []
                def snapshot(source, target):
                    observed.append((run / "operation.lock").is_file())
                    return _snapshot_sqlite(source, target)
                with patch("nilt.registry._snapshot_sqlite", side_effect=snapshot):
                    package = create_training_package(run, root / "package")
                self.assertEqual(observed, [True])
                packaged = package / "run/search/optuna.sqlite3"
                manifest = read_json(package / "package_manifest.json")
                self.assertEqual(manifest["files"]["run/search/optuna.sqlite3"], sha_file(packaged))
                self.assertFalse(list(package.rglob("*-wal")))
                self.assertFalse(list(package.rglob("*-shm")))
                # A later transaction in the source does not leak into the snapshot.
                connection.execute("INSERT INTO trials VALUES (2, .91)")
                connection.commit()
                restored = restore_training_package(package, data, root / "restored")
                with sqlite3.connect(restored / "search/optuna.sqlite3") as restored_db:
                    self.assertEqual(restored_db.execute("SELECT * FROM trials").fetchall(), [(1, .82)])
            finally:
                connection.close()

    def test_tampered_study_blocks_restore(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            run, data, _ = fixture_run(root)
            folder = run / "search"
            folder.mkdir()
            with sqlite3.connect(folder / "optuna.sqlite3") as connection:
                connection.execute("CREATE TABLE trials(id INTEGER)")
            package = create_training_package(run, root / "package")
            with sqlite3.connect(package / "run/search/optuna.sqlite3") as connection:
                connection.execute("INSERT INTO trials VALUES (7)")
            with self.assertRaisesRegex(ValueError, "integrity"):
                restore_training_package(package, data, root / "restored")
            self.assertFalse((root / "restored").exists())


if __name__ == "__main__":
    unittest.main()
