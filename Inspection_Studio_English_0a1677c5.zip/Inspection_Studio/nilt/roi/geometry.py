"""Versioned, normalized ROI geometry. Coordinates use EXIF-oriented images.

Templates describe expected geometry. They must never be used as observed
segmentation targets without a human check. Circles contain [centre, edge].
"""
from __future__ import annotations

from copy import deepcopy
import math
import re
import numpy as np

TEMPLATE_SCHEMA = "inspection_roi_template.v1"
LOCALIZATION_VERSION = "similarity-reference.v1"
CROP_VERSION = "native-context.v1"


def _polygon(roi_id, kind, points, margin=.15):
    return {"id": roi_id, "kind": kind, "shape": "polygon", "points": points,
            "margin": margin, "enabled": True}


def default_template(side):
    """Return an editable starter, NOT calibrated geometry for a real module."""
    side = str(side).lower()
    if side not in ("top", "bottom"):
        raise ValueError("ROI geometry supports top and bottom only.")
    outline = [[.08,.08],[.92,.08],[.92,.92],[.08,.92]]
    if side == "top":
        rois = [
            _polygon("label", "label", [[.16,.16],[.38,.16],[.38,.26],[.16,.26]]),
            _polygon("corner_TR", "corners", [[.75,.14],[.86,.14],[.86,.27],[.82,.27],[.82,.18],[.75,.18]]),
            _polygon("corner_BL", "corners", [[.14,.73],[.18,.73],[.18,.82],[.25,.82],[.25,.86],[.14,.86]]),
            _polygon("inner_area", "inner_area", [[.32,.23],[.68,.23],[.77,.32],[.77,.68],[.68,.77],[.32,.77],[.23,.68],[.23,.32]], .1),
            {"id":"lens", "kind":"lens", "shape":"circle", "points":[[.5,.5],[.67,.5]], "margin":.15, "enabled":True},
            {"id":"lens_center", "kind":"center", "shape":"point", "points":[[.5,.5]], "margin":.02, "enabled":False},
            {**_polygon("die_outline", "die_outline", outline, .03), "enabled":False},
        ]
    else:
        rois = [{"id":f"pin_r{r+1}_c{c+1}", "kind":"pins", "shape":"circle",
                 "points":[[.275+c*.15,.275+r*.15],[.310+c*.15,.275+r*.15]],
                 "margin":.6, "enabled":True} for r in range(4) for c in range(4)]
        rois += [_polygon("triangle", "triangle", [[.78,.78],[.87,.87],[.78,.87]], .25),
                 _polygon("square", "square", [[.83,.46],[.88,.46],[.88,.52],[.83,.52]], .3)]
    return {"schema":TEMPLATE_SCHEMA, "version":1, "side":side, "reference_size":[600,600],
            "coordinate_space":"image_normalized", "starter":True, "outline":outline,
            "notes":"Editable starter: fit to a real training image before use.", "rois":rois}


def _canonical_id(name):
    raw = str(name).strip()
    key = re.sub(r"[^a-z0-9]+", "_", raw.lower()).strip("_")
    aliases = {"inner_octagon":"inner_area", "inner":"inner_area", "camera_center":"lens_center",
               "centre":"lens_center", "center":"lens_center", "lens_centre":"lens_center",
               "rectangular_on_the_side":"square", "side_rectangle":"square", "rectangle":"square",
               "small_square":"square", "corner_tr":"corner_TR", "corner_bl":"corner_BL",
               "corner_tl":"corner_TL", "corner_br":"corner_BR"}
    return aliases.get(key, key)


def roi_kind(roi_id):
    key = str(roi_id).lower()
    if key.startswith("pin"):
        return "pins"
    if key.startswith("corner"):
        return "corners"
    return {"lens_center":"center"}.get(key, key)


def validate_points(points, shape, normalized=False):
    """Validate finite geometry without silently repairing malformed annotations."""
    values = np.asarray(points, dtype=float)
    if values.ndim != 2 or values.shape[1:] != (2,) or not np.isfinite(values).all():
        raise ValueError("ROI points must be finite [x,y] pairs.")
    count = len(values)
    if ((shape == "polygon" and count < 3) or (shape == "circle" and count != 2)
            or (shape == "point" and count != 1) or shape not in ("polygon","circle","point")):
        raise ValueError("A polygon requires >=3 points; a circle centre+edge; a point one pair.")
    if normalized and (np.any(values < 0) or np.any(values > 1)):
        raise ValueError("Template points must lie in normalized image coordinates [0,1].")
    if shape == "circle" and np.linalg.norm(values[1]-values[0]) < 1e-8:
        raise ValueError("Circle radius must be positive.")
    if shape == "polygon":
        area = abs(np.dot(values[:,0], np.roll(values[:,1],-1)) - np.dot(values[:,1], np.roll(values[:,0],-1))) / 2
        if area < 1e-10:
            raise ValueError("Polygon has zero area.")
    return values.tolist()


def normalize_template(payload, side=None):
    if not isinstance(payload, dict):
        raise ValueError("Geometry must be a JSON object.")
    payload = deepcopy(payload)
    imported = payload.get("schema") == "camera_geometry_annotation.v1"
    resolved_side = str(side or payload.get("side", "")).lower()
    if resolved_side not in ("top","bottom"):
        raise ValueError("Template side must be top or bottom.")
    if side and payload.get("side") and str(payload["side"]).lower() != resolved_side:
        raise ValueError("Template side does not match the selected side.")
    source = payload.get("source_image", {})
    dimensions = payload.get("reference_size") or [source.get("width_pixels",600),source.get("height_pixels",600)]
    if len(dimensions) != 2 or any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v < 2 or int(v) != v for v in dimensions):
        raise ValueError("reference_size must contain two integer image dimensions >=2.")
    dimensions = [int(v) for v in dimensions]
    rows, ids = [], set()
    for raw in payload.get("rois", []):
        roi_id = _canonical_id(raw.get("id") or raw.get("name") or raw.get("roi_id", ""))
        if not roi_id or roi_id in ids:
            raise ValueError("Every ROI must have a unique nonempty ID.")
        ids.add(roi_id)
        shape = {"Polygon ROI":"polygon", "Point / center":"point", "Circle":"circle"}.get(raw.get("shape"), str(raw.get("shape", "polygon")).lower())
        points = raw.get("image_normalized_points") if imported else raw.get("points")
        if points is None:
            points = raw.get("image_pixel_points")
            if points is None:
                raise ValueError(f"ROI {roi_id} has no image coordinates.")
            points = (np.asarray(points,float) / np.maximum(np.asarray(dimensions)-1,1)).tolist()
        points = validate_points(points, shape, normalized=True)
        margin = raw.get("margin", .25 if shape == "circle" else .15)
        if isinstance(margin, bool) or not isinstance(margin,(int,float)) or not math.isfinite(margin) or not 0 <= margin <= 5:
            raise ValueError("ROI margin must be between 0 and 5 times its bounding size.")
        kind = raw.get("kind") or roi_kind(roi_id)
        kind = {"pin":"pins", "corner":"corners", "inner_octagon":"inner_area", "side_rectangle":"square", "rectangular_on_the_side":"square"}.get(kind,kind)
        rows.append({**raw, "id":roi_id, "kind":kind, "shape":shape, "points":points,
                     "margin":float(margin), "enabled":bool(raw.get("enabled", kind not in ("center","die_outline")))})
    if not rows:
        raise ValueError("Template must contain at least one ROI.")
    outline = payload.get("outline")
    if outline is None:
        outline = next((r["points"] for r in rows if r["id"] == "die_outline"), None)
    if outline is not None:
        outline = validate_points(outline, "polygon", normalized=True)
    return {**payload, "schema":TEMPLATE_SCHEMA, "version":payload.get("version",1),
            "side":resolved_side, "reference_size":dimensions, "coordinate_space":"image_normalized",
            "starter":False if imported else bool(payload.get("starter",False)), "outline":outline, "rois":rows}


def transform_points(points, transform):
    matrix = np.asarray(transform, dtype=float)
    if matrix.shape == (2,3):
        matrix = np.vstack([matrix,[0,0,1]])
    if matrix.shape != (3,3) or not np.isfinite(matrix).all() or abs(np.linalg.det(matrix)) < 1e-12:
        raise ValueError("Transform must be a finite invertible 3x3 or 2x3 matrix.")
    values = np.asarray(points, dtype=float)
    result = np.c_[values, np.ones(len(values))] @ matrix.T
    if np.any(abs(result[:,2]) < 1e-10):
        raise ValueError("Transform maps geometry to infinity.")
    return (result[:,:2] / result[:,2:3]).tolist()


def template_to_rois(template, image_size, transform=None):
    template = normalize_template(template)
    reference_size = np.asarray(template["reference_size"],dtype=float)
    if transform is None:
        size = np.asarray(image_size,dtype=float)
        transform = np.diag([*(size-1)/(reference_size-1),1.])
    rows = []
    for roi in template["rois"]:
        original = (np.asarray(roi["points"]) * (reference_size-1)).tolist()
        points = transform_points(original,transform)
        rows.append({**deepcopy(roi), "points":points, "expected_points":deepcopy(points),
                     "observed_points":None, "reference_points":original,
                     "source":"inferred", "confidence":0., "geometry_review":"unreviewed"})
    return rows


def roi_bounds(roi):
    pts = np.asarray(roi["points"],float)
    if roi["shape"] == "circle":
        radius = np.linalg.norm(pts[1]-pts[0])
        return [float(pts[0,0]-radius),float(pts[0,1]-radius),float(pts[0,0]+radius),float(pts[0,1]+radius)]
    return [float(pts[:,0].min()),float(pts[:,1].min()),float(pts[:,0].max()),float(pts[:,1].max())]
