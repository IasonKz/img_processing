# Visual workspace and reports

Open `Start.cmd` to use the live workspace. The views cover setup, training, comparison, decisions, classification, inspection workflows, image review, and reports.

Standalone HTML reports can be generated from **Models & reports** or with `inspection.py report --run RUN_FOLDER`. A report reads recorded results; it does not start training.

See [OPERATOR_GUIDE.md](docs/OPERATOR_GUIDE.md) for daily use, [IMAGE_REVIEW.md](docs/IMAGE_REVIEW.md) for reference-label comparison, and [CLI_REFERENCE.md](docs/CLI_REFERENCE.md) for commands.

The retained `VISUAL_REPORT_DEMO.html` is a static interface example. It is not evidence about your dataset.
