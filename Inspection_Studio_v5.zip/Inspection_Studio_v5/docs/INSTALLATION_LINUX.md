# Linux and Arch Linux installation

Run commands in Bash from the extracted folder containing `inspection.py` and `project.yaml`. This guide uses a separate Python 3.12 environment. Do not replace Arch's system Python, use `sudo pip`, or copy a Windows virtual environment.

All package and public-weight downloads are provisioning operations. They do not require or upload inspection images. Offline training follows after provisioning.

## 1. Obtain Python 3.12

If Python 3.12 is already installed:

```bash
python3.12 --version
```

If it is not, install it through your approved software channel. One option, **when the approved `uv` tool is already available**, is:

```bash
uv python install 3.12
```

This installs a separate interpreter rather than replacing system Python. See [uv Python installation](https://docs.astral.sh/uv/guides/install-python/). Do not change a company-managed Python installation or bypass an installation restriction.

## 2. Create the project environment

Choose one route, only if `.venv-studio5` does not already exist. To check:

```bash
ls -ld .venv-studio5
```

`No such file or directory` is expected for a new project. If it exists, inspect/reuse it or choose another path; do not remove it blindly.

With an existing Python 3.12 executable:

```bash
python3.12 -m venv .venv-studio5
```

Or with uv:

```bash
uv venv --python 3.12 --seed .venv-studio5
```

Check the environment, then install base requirements:

```bash
.venv-studio5/bin/python -c "import sys; print(sys.executable); print(sys.version); assert sys.version_info[:2] == (3,12)"
.venv-studio5/bin/python -m pip install --upgrade pip
.venv-studio5/bin/python -m pip install -r requirements.txt
```

Stop on any error; do not continue to training with an incomplete installation.

## 3. Install one PyTorch variant

For a CPU laptop or CPU GUI/training test:

```bash
.venv-studio5/bin/python -m pip install torch==2.7.1 torchvision==0.22.1 --index-url https://download.pytorch.org/whl/cpu
```

For a compatible NVIDIA GPU/driver:

```bash
nvidia-smi
.venv-studio5/bin/python -m pip install torch==2.7.1 torchvision==0.22.1 --index-url https://download.pytorch.org/whl/cu128
```

The pinned pair and CUDA wheel choice match the project's Windows setup and the [PyTorch version matrix](https://pytorch.org/get-started/previous-versions/). This is not an instruction to install an arbitrary newer torch with an older torchvision. AMD/ROCm and non-NVIDIA acceleration are not configured by the workstation profiles in this release.

Verify:

```bash
.venv-studio5/bin/python -m pip check
.venv-studio5/bin/python -c "import torch, torchvision, optuna, sklearn; print(torch.__version__); print(torchvision.__version__); print('CUDA available:', torch.cuda.is_available())"
```

CUDA must print `True` before selecting explicit CUDA execution. A profile does not lock the device: Custom Optuna can choose CPU, CUDA, or Auto independently. After configuring the selected task and model list, **Check installation** / `doctor` performs additional model-resource checks. A successful import alone is not proof that every model fits GPU memory.

## 4. Open or reopen the GUI

```bash
bash Start.sh
```

Open the printed `http://127.0.0.1:8765` address. Leave the terminal open. Alternatives:

```bash
bash Start.sh --port 8766
bash Start.sh --no-browser
```

You can inspect the GUI without a dataset or public weights. Do not press Audit/Start search expecting a sample training result; those operations require real configured inputs.

For an existing verified environment at another path:

```bash
STUDIO_PYTHON=/absolute/path/to/environment/bin/python bash Start.sh
```

No shell activation is required. In PyCharm, select `.venv-studio5/bin/python` as this project's interpreter.

## 5. Configure data and provision weights

Change `tasks.vig.dataset_root` in `project.yaml` to an actual Linux folder containing `good` and `bad`, for example `/mnt/inspection/vig`. Windows `C:/...` paths are not Linux paths. Relative config paths resolve beside the config file.

For CPU:

```bash
.venv-studio5/bin/python inspection.py download-weights --config project.yaml --profile laptop --task vig
.venv-studio5/bin/python inspection.py doctor --config project.yaml --profile laptop --task vig
```

For the supplied GPU defaults, replace `laptop` with `workstation` or `workstation_large`. Custom execution can override the device separately. Download only selected supported architectures. Newly selected architectures may require additional public weights. Training itself must not silently download missing weights or fall back to random initialization.

## 6. Search without the GUI

CPU example:

```bash
.venv-studio5/bin/python inspection.py search --config project.yaml --profile laptop --task vig
```

GPU example:

```bash
.venv-studio5/bin/python inspection.py search --config project.yaml --profile workstation --task vig
```

Do not run this alongside an active GUI-launched search in the same experiment. Pause and wait for workers before shutting down. Closing a browser is not a stop command.

## Optional ONNX dependencies

```bash
.venv-studio5/bin/python -m pip install -r requirements-export.txt
.venv-studio5/bin/python -m pip check
```

ONNX support is limited to explicitly supported full-image model exports with parity checks. A global-plus-patches model or multi-model workflow is not automatically a single exportable ONNX graph.
