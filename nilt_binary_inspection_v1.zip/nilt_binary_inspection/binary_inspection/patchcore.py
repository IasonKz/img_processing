"""Native PatchCore-style implementation for an image-level anomaly veto.

Local pooled layer2/layer3 features, bounded patch reservoir, projected greedy
coreset, exact nearest-neighbor distances and neighborhood score reweighting.
It is NOT the Anomalib package and does not claim identical benchmark numbers.
Subsampling is explicitly bounded; validate its effect on small/rare defects.
"""
from __future__ import annotations

import gc
import math
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from .common import (LOG, choose_device, file_sha256, object_hash, output_dir, read_json,
                     seed_everything, torch_load, torch_save, write_json)
from .images import ImageTransform, make_loader
from .models import DEFAULT_MEAN, DEFAULT_STD, torchvision_factory
from .splitting import read_manifest, verify_manifest


class PatchFeatures(nn.Module):
    def __init__(self, backbone: str):
        super().__init__()
        model, _ = torchvision_factory(backbone, pretrained=False)
        if backbone not in {"resnet18", "wide_resnet50_2"}:
            raise ValueError("PatchCore supports resnet18 or wide_resnet50_2")
        self.stem = nn.Sequential(model.conv1, model.bn1, model.relu, model.maxpool)
        self.layer1, self.layer2, self.layer3 = model.layer1, model.layer2, model.layer3

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.layer1(self.stem(x))
        a = self.layer2(x)
        b = self.layer3(a)
        a = F.avg_pool2d(a, 3, stride=1, padding=1)
        b = F.avg_pool2d(b, 3, stride=1, padding=1)
        b = F.interpolate(b, size=a.shape[-2:], mode="bilinear", align_corners=False)
        return torch.cat((a, b), dim=1).flatten(2).transpose(1, 2).contiguous()


def initialize_features(cfg: dict) -> tuple[PatchFeatures, dict]:
    architecture = cfg["anomaly"]["backbone"]
    features = PatchFeatures(architecture)
    path = Path(cfg["paths"]["pretrained_dir"]) / f"{architecture}.pt"
    if not path.exists():
        if not cfg["training"].get("allow_random_initialization", False):
            raise FileNotFoundError(f"Missing {path}. Run download-weights first")
        LOG.warning("Random PatchCore backbone: SOFTWARE TEST ONLY")
        return features, {"mean": DEFAULT_MEAN, "std": DEFAULT_STD, "source": "RANDOM_TEST_ONLY"}
    payload = torch_load(path)
    model, _ = torchvision_factory(architecture, pretrained=False)
    model.load_state_dict(payload["state_dict"], strict=True)
    features.stem = nn.Sequential(model.conv1, model.bn1, model.relu, model.maxpool)
    features.layer1, features.layer2, features.layer3 = model.layer1, model.layer2, model.layer3
    return features, {"mean": payload.get("mean", DEFAULT_MEAN), "std": payload.get("std", DEFAULT_STD),
                      "source": payload["source"], "sha256": file_sha256(path)}


@torch.inference_mode()
def greedy_coreset(pool: torch.Tensor, count: int, projection_dim: int, device, seed: int) -> torch.Tensor:
    if pool.ndim != 2 or not len(pool):
        raise ValueError("Empty or malformed PatchCore pool")
    count = min(count, len(pool))
    if count < 1 or projection_dim < 1:
        raise ValueError("memory_size and projection_dim must be positive")
    generator = torch.Generator().manual_seed(seed)
    projection = torch.randn(pool.shape[1], min(projection_dim, pool.shape[1]), generator=generator) / math.sqrt(projection_dim)
    projected = (pool @ projection).to(device)
    chosen = [int(torch.randint(len(pool), (1,), generator=generator))]
    distances = torch.full((len(pool),), float("inf"), device=device)
    for step in range(count):
        center = projected[chosen[-1]]
        new_distances = ((projected - center) ** 2).sum(1)
        distances = torch.minimum(distances, new_distances)
        distances[chosen] = -1
        if step + 1 < count:
            chosen.append(int(distances.argmax()))
        if (step + 1) % 256 == 0:
            LOG.info("PatchCore coreset: %s/%s", step + 1, count)
    return pool[chosen].contiguous()


@torch.inference_mode()
def nearest_neighbors(queries: torch.Tensor, bank: torch.Tensor, chunk: int = 512) -> tuple[torch.Tensor, torch.Tensor]:
    all_dist, all_idx = [], []
    bank_norm = (bank * bank).sum(1)[None, :]
    for query in queries.split(chunk):
        squared = (query * query).sum(1, keepdim=True) + bank_norm - 2 * (query @ bank.T)
        distance, indices = squared.clamp_min_(0).min(dim=1)
        all_dist.append(distance.sqrt())
        all_idx.append(indices)
    return torch.cat(all_dist), torch.cat(all_idx)


@torch.inference_mode()
def image_anomaly_scores(embeddings: torch.Tensor, bank: torch.Tensor, neighbors: int, chunk: int) -> torch.Tensor:
    batch, n_patches, dim = embeddings.shape
    distance, indices = nearest_neighbors(embeddings.reshape(-1, dim), bank, chunk)
    distance, indices = distance.reshape(batch, n_patches), indices.reshape(batch, n_patches)
    raw, worst_patch = distance.max(dim=1)
    count = min(int(neighbors), len(bank))
    if count <= 1:
        return raw
    batch_indices = torch.arange(batch, device=embeddings.device)
    worst_embedding = embeddings[batch_indices, worst_patch]
    best_bank_index = indices[batch_indices, worst_patch]
    reference = bank[best_bank_index]
    support_distance = torch.cdist(reference[None], bank[None])[0]
    support_indices = support_distance.topk(count, largest=False, dim=1).indices
    support = bank[support_indices]
    differences = torch.linalg.vector_norm(worst_embedding[:, None, :] - support, dim=2)
    # Explicitly locate m* even if duplicate memory vectors tie in nearest search.
    original_distance = torch.linalg.vector_norm(worst_embedding - reference, dim=1)
    log_denom = torch.logsumexp(differences, dim=1)
    weight = 1 - torch.exp(original_distance - log_denom).clamp(0, 1)
    return raw * weight


def patchcore_signature(cfg: dict, data_sig: str) -> str:
    return object_hash({"anomaly": cfg["anomaly"], "data": data_sig,
                        "preprocessing": cfg["preprocessing"], "seed": int(cfg["project"]["seed"])})


def train_patchcore(cfg: dict) -> None:
    if not cfg["anomaly"]["enabled"]:
        LOG.info("PatchCore disabled explicitly")
        return
    verify_manifest(cfg)
    rows = [r for r in read_manifest(cfg) if r["split"] == "train" and r["label"] == 0]
    if not rows:
        raise ValueError("PatchCore needs GOOD images in TRAIN")
    device = choose_device(cfg)
    seed = int(cfg["project"]["seed"])
    seed_everything(seed, cfg["runtime"]["deterministic"])
    folder = output_dir(cfg) / "models" / "patchcore"
    folder.mkdir(parents=True, exist_ok=True)
    data_sig = read_json(output_dir(cfg) / "dataset.json")["signature"]
    signature = patchcore_signature(cfg, data_sig)
    status_path = folder / "status.json"
    if status_path.exists():
        status = read_json(status_path)
        if status["signature"] != signature:
            raise ValueError("PatchCore configuration changed. Use a new output_dir")
        if status.get("completed"):
            if file_sha256(folder / "best.pt") != status["checkpoint_sha256"]:
                raise ValueError("PatchCore checkpoint integrity failure")
            LOG.info("Skipping completed PatchCore model")
            return
    spec = cfg["anomaly"]
    rng = np.random.default_rng(seed)
    order = rng.permutation(len(rows))[:int(spec["max_train_images"])]
    selected_rows = [rows[int(i)] for i in order]
    model, norm = initialize_features(cfg)
    model.to(device).eval()
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    transform = ImageTransform(int(spec["input_size"]), norm["mean"], norm["std"], cfg["preprocessing"])
    loader = make_loader(selected_rows, cfg, transform, int(spec["batch_size"]))
    pool, priorities = None, None
    generator = torch.Generator().manual_seed(seed)
    write_json(status_path, {"completed": False, "signature": signature})
    with torch.inference_mode():
        for step, (images, _, _) in enumerate(loader):
            embedding = model(images.to(device)).cpu().float()
            samples = []
            for item in embedding:
                chosen = torch.randperm(len(item), generator=generator)[:int(spec["patches_per_image"])]
                samples.append(item[chosen])
            new = torch.cat(samples)
            keys = torch.rand(len(new), generator=generator)
            pool = new if pool is None else torch.cat((pool, new))
            priorities = keys if priorities is None else torch.cat((priorities, keys))
            if len(pool) > int(spec["pool_size"]):
                keep = priorities.topk(int(spec["pool_size"])).indices
                pool, priorities = pool[keep], priorities[keep]
            if (step + 1) % 50 == 0:
                LOG.info("PatchCore feature extraction batch %s/%s | reservoir %s", step + 1, len(loader), len(pool))
    bank = greedy_coreset(pool, int(spec["memory_size"]), int(spec["projection_dim"]), device, seed)
    payload = {"format_version": 1, "implementation": "native_patchcore_bounded_reservoir",
               "task": cfg["project"]["task"], "spec": spec, "data_cfg": cfg["data"],
               "preprocessing": cfg["preprocessing"], "normalization": norm, "dataset_signature": data_sig,
               "state_dict": {k: v.detach().cpu() for k, v in model.state_dict().items()}, "memory_bank": bank,
               "normal_train_ids": [r["sample_id"] for r in selected_rows], "signature": signature}
    torch_save(folder / "best.pt", payload)
    write_json(status_path, {"completed": True, "signature": signature, "normal_images": len(selected_rows),
                             "reservoir_patches": len(pool), "memory_patches": len(bank),
                             "checkpoint_sha256": file_sha256(folder / "best.pt"), "pretraining": norm})
    del model, pool, bank
    gc.collect()
    if device.type == "cuda":
        torch.cuda.empty_cache()


def score_patchcore(path: Path, rows: list[dict], cfg: dict, device) -> dict[str, float]:
    payload = torch_load(path)
    model = PatchFeatures(payload["spec"]["backbone"]).to(device)
    model.load_state_dict(payload["state_dict"], strict=True)
    model.eval()
    bank = payload["memory_bank"].to(device).float()
    spec = payload["spec"]
    norm = payload["normalization"]
    input_cfg = {**cfg, "data": payload["data_cfg"]}
    transform = ImageTransform(int(spec["input_size"]), norm["mean"], norm["std"], payload["preprocessing"])
    loader = make_loader(rows, input_cfg, transform, int(spec["batch_size"]))
    output = {}
    with torch.inference_mode():
        for images, _, ids in loader:
            embedding = model(images.to(device))
            scores = image_anomaly_scores(embedding, bank, int(spec["num_neighbors"]), int(spec["query_chunk"]))
            if not torch.isfinite(scores).all():
                raise RuntimeError("Non-finite PatchCore score")
            output.update({sample_id: float(score) for sample_id, score in zip(ids, scores.cpu())})
    del model, bank
    gc.collect()
    if device.type == "cuda":
        torch.cuda.empty_cache()
    return output
