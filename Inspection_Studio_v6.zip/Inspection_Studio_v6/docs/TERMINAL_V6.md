# Terminal logo

The supplied NILT logo rotates while the dashboard server is open in a supported
terminal. The URL and shutdown instructions remain visible. Closing a browser tab
does not stop the server or the animation. Press **Ctrl+C** in the terminal to
close the dashboard server; training workers already started run independently.
Pause or cancel a search in the dashboard when that is the intended action.

The animation uses the logo supplied with `nilt_terminal_spinner.zip`. It runs at
8 frames per second by default, with a maximum of 12. No network access or extra
package installation is needed beyond the normal application requirements.

PowerShell, Windows Terminal, and Linux terminals with ANSI support are supported.
Windows virtual terminal processing is enabled for the session and restored on
exit. Output redirected to a file, a terminal smaller than 40 columns by 12 rows,
or an IDE console without terminal support uses ordinary text output. Any new
console log or error stops the animation before printing, preserving diagnostics.
The original terminal screen and cursor are restored when the animation ends.

To disable the animation for the current PowerShell session:

```powershell
$env:NILT_TERMINAL_SPINNER = "0"
.\Start.cmd
```

To enable it again and optionally reduce refresh rate:

```powershell
$env:NILT_TERMINAL_SPINNER = "1"
$env:NILT_SPINNER_FPS = "5"
.\Start.cmd
```

On Linux:

```bash
NILT_TERMINAL_SPINNER=0 bash Start.sh
```

The animation indicates that the dashboard server is open. Training progress,
failure details, and model quality are shown in the dashboard, not inferred from
the animation.
