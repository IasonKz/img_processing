"""Operator API: recovered workers, bounded file access and auditable image review."""
from http.server import ThreadingHTTPServer
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import Mock, patch
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from nilt.common import write_json
from nilt.dashboard import Dashboard, PROJECT, make_handler
from nilt.review import initialize_session, append_prediction


class DashboardV4Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.config = self.root / "project.yaml"
        self.config.write_text("paths:\n  output_root: ./results\n  classification_output_root: ./classified\n"
                               "tasks:\n  vig:\n    dataset_root: ./data\n", encoding="utf-8")
        self.app = Dashboard(self.config)

    def tearDown(self):
        self.temp.cleanup()

    def experiment(self, path):
        path.mkdir(parents=True)
        write_json(path / "config.json", {"task": "vig", "models": ["resnet18"]})
        write_json(path / "model_state.json", {"status": "PREPARED"})
        return path

    def session(self):
        path = self.root / "classified" / "session1"
        initialize_session(path, total=1)
        image = path / "predicted" / "bad" / "example.png"
        image.parent.mkdir(parents=True)
        image.write_bytes(b"copied image bytes")
        item = append_prediction(path, {"relative_path": "good/example.png", "reference_label": "good",
                                       "prediction": "bad", "score": .7,
                                       "copied_path": "predicted/bad/example.png"})
        return path, image, item

    def worker(self, **overrides):
        import sys
        job = {"id": "known-worker", "action": "search", "pid": 123, "process_created": 100.0,
               "status": "running", "command": [sys.executable, "-u", str(PROJECT / "inspection.py"), "search"],
               "log": str(self.app.logs_root / "known-worker.log"), "started": 99., "lines": []}
        job.update(overrides)
        return job

    def process(self, job):
        process = Mock()
        process.create_time.return_value = job["process_created"]
        process.status.return_value = "running"
        process.is_running.return_value = True
        process.cmdline.return_value = job["command"]
        process.exe.return_value = job["command"][0]
        return process

    def test_external_run_registration_is_exact_and_persistent(self):
        run = self.experiment(self.root / "imported" / "run1")
        secret = run.parent / "secret.json"
        secret.write_text('{"private":true}')
        result = self.app.load_run({"path": str(run)})
        self.assertEqual(result["run"]["path"], str(run))
        self.assertEqual(self.app.checked_output(run / "config.json"), run / "config.json")
        with self.assertRaises(ValueError):
            self.app.checked_output(secret)
        reopened = Dashboard(self.config)
        self.assertIn(str(run), [entry["path"] for entry in reopened.runs()])
        with self.assertRaises(ValueError):
            reopened.checked_output(secret)

    def test_arbitrary_folders_and_invalid_run_configs_are_not_registered(self):
        for cfg in ({}, {"task": "unknown"}, {"task": "vig", "models": ["injected"]}):
            directory = self.root / "arbitrary"
            directory.mkdir(exist_ok=True)
            write_json(directory / "config.json", cfg)
            write_json(directory / "model_state.json", {})
            with self.assertRaises(ValueError):
                self.app.load_run({"path": str(directory)})
        self.assertNotIn(directory, self.app.output_roots)

    def test_saved_setup_and_profile_survive_restarting_from_base_config(self):
        dataset = self.root / "operator_data"
        dataset.mkdir()
        original = self.config.read_bytes()
        saved = self.app.save_config({"task": "vig", "dataset": str(dataset), "profile": "workstation",
                                      "output": str(self.root / "operator_results")})
        reopened = Dashboard(self.config).bootstrap()
        self.assertEqual(self.config.read_bytes(), original)
        self.assertEqual(reopened["active_config"], saved["config"])
        self.assertEqual(reopened["base_config"], str(self.config))
        self.assertEqual(reopened["datasets"]["vig"], str(dataset))
        self.assertEqual(reopened["profile"], "workstation")
        self.assertEqual(reopened["paths"]["output"], str(self.root / "operator_results"))

    def test_external_base_edits_take_precedence_over_saved_setup(self):
        dataset = self.root / "operator_data"
        dataset.mkdir()
        self.app.save_config({"task": "vig", "dataset": str(dataset)})
        self.config.write_text(self.config.read_text() + "profile: workstation_large\n")
        reopened = Dashboard(self.config).bootstrap()
        self.assertEqual(reopened["active_config"], str(self.config))
        self.assertEqual(reopened["profile"], "workstation_large")
        self.assertEqual(reopened["datasets"]["vig"], str(self.root / "data"))

    def test_explicit_different_config_does_not_load_base_snapshot(self):
        dataset = self.root / "operator_data"
        dataset.mkdir()
        self.app.save_config({"task": "vig", "dataset": str(dataset)})
        other = self.root / "another.yaml"
        other.write_text(self.config.read_text())
        reopened = Dashboard(other).bootstrap()
        self.assertEqual(reopened["active_config"], str(other))
        self.assertEqual(reopened["datasets"]["vig"], str(self.root / "data"))

    def test_snapshot_pointer_rejects_traversal_symlinks_and_invalid_yaml(self):
        settings = {"base_config": str(self.config), "base_sha256": self.app.base_config_sha256}
        for value in ("../project.dashboard.outside.yaml", "project.dashboard.../outside.yaml",
                      "project.dashboard..\\outside.yaml", "/project.dashboard.outside.yaml"):
            write_json(self.root / "studio_settings.json", dict(settings, snapshot=value))
            self.assertEqual(Dashboard(self.config).config, self.config)
        snapshot = self.root / "project.dashboard.invalid.yaml"
        snapshot.write_text("tasks: [not a mapping]\n")
        write_json(self.root / "studio_settings.json", dict(settings, snapshot=snapshot.name))
        self.assertEqual(Dashboard(self.config).config, self.config)
        snapshot.write_text("tasks: [unterminated\n")
        self.assertEqual(Dashboard(self.config).config, self.config)
        snapshot.unlink()
        try:
            snapshot.symlink_to(self.config)
        except OSError:
            return
        self.assertEqual(Dashboard(self.config).config, self.config)

    def test_invalid_setup_does_not_publish_snapshot_pointer(self):
        with self.assertRaises(ValueError):
            self.app.save_config({"task": "vig", "dataset": str(self.root / "missing")})
        self.assertFalse((self.root / "studio_settings.json").exists())

    def test_failed_trial_reports_the_actual_failure_without_score_fabrication(self):
        run = self.experiment(self.root / "results" / "vig" / "run1")
        failure = run / "search" / "resnet18" / "trial_00000" / "failure.json"
        write_json(failure, {"error": "Access denied", "traceback": "original traceback", "oom": False})
        (run / "trials.csv").write_text("model,trial,state,value\nresnet18,0,FAIL,\n")
        result = self.app.run_info(str(run))
        self.assertEqual(result["trials"][0]["value"], "")
        self.assertEqual(result["trials"][0]["failure"]["traceback"], "original traceback")
        self.assertEqual(result["failures"][0]["error"], "Access denied")

    def test_recovered_matching_worker_blocks_duplicate_jobs(self):
        job = self.worker()
        self.app._persist_job(job)
        with patch("psutil.Process", return_value=self.process(job)):
            reopened = Dashboard(self.config)
            self.assertEqual(reopened.jobs[0]["status"], "running")
            self.assertTrue(reopened.jobs[0]["detached"])
            with self.assertRaisesRegex(ValueError, "already running"):
                reopened.start("doctor", {"task": "vig", "profile": "laptop"})

    def test_reused_pid_cannot_become_a_dashboard_worker(self):
        job = self.worker()
        self.app._persist_job(job)
        process = self.process(job)
        process.create_time.return_value = job["process_created"] + 60
        with patch("psutil.Process", return_value=process):
            reopened = Dashboard(self.config)
        self.assertEqual(reopened.jobs[0]["status"], "ended")
        process.terminate.assert_not_called()
        process.kill.assert_not_called()

    def test_process_command_and_executable_are_both_verified(self):
        job = self.worker()
        for field, replacement in (("cmdline", ["unrelated-worker"]), ("exe", "/another/python")):
            process = self.process(job)
            getattr(process, field).return_value = replacement
            with patch("psutil.Process", return_value=process):
                self.assertEqual(self.app._process_state(job), "stopped")

    def test_worker_executable_uses_observed_identity_for_venv_launchers(self):
        job = self.worker(process_executable=str(self.root / "base-python.exe"))
        process = self.process(job)
        process.exe.return_value = job["process_executable"]
        with patch("psutil.Process", return_value=process):
            self.assertEqual(self.app._process_state(job), "running")
        process.exe.return_value = str(self.root / "unrelated.exe")
        with patch("psutil.Process", return_value=process):
            self.assertEqual(self.app._process_state(job), "stopped")

    def test_inaccessible_worker_is_explicit_and_blocks_duplicate(self):
        import psutil
        job = self.worker()
        self.app._persist_job(job)
        with patch("psutil.Process", side_effect=psutil.AccessDenied(pid=job["pid"])):
            reopened = Dashboard(self.config)
            self.assertEqual(reopened.jobs[0]["status"], "unverified")
            with self.assertRaises(ValueError):
                reopened.start("doctor", {})

    def test_recovered_worker_keeps_log_and_run_association(self):
        run = self.experiment(self.root / "results" / "vig" / "run1")
        job = self.worker()
        self.app._persist_job(job)
        Path(job["log"]).write_text("RUN: " + str(run) + "\n" + "Training epoch 2\n" * 500)
        with patch("psutil.Process", return_value=self.process(job)):
            reopened = Dashboard(self.config)
        self.assertEqual(reopened.jobs[0]["run"], str(run))
        self.assertIn("Training epoch 2", reopened.jobs[0]["lines"])

    def test_reviews_keep_reference_and_prediction_immutable(self):
        session, image, item = self.session()
        result = self.app.review_detail({"session": str(session), "filter": "errors", "limit": "1"})
        self.assertEqual(result["pagination"]["total"], 1)
        self.assertIn("/api/review-image?", result["items"][0]["image_url"])
        self.app.review_label({"session": str(session), "item_id": item["id"], "label": "bad", "note": "Verified"})
        updated = self.app.review_detail({"session": str(session)})["items"][0]
        self.assertEqual(updated["reference_label"], "good")
        self.assertEqual(updated["prediction"], "bad")
        self.assertEqual(updated["review"]["label"], "bad")
        self.assertEqual(self.app.review_image({"session": str(session), "item_id": item["id"]}), image)

    def test_gallery_cannot_serve_unregistered_or_escaping_assets(self):
        session, image, item = self.session()
        outside = self.root / "private.png"
        outside.write_bytes(b"private")
        with self.assertRaises(ValueError):
            self.app.review_detail({"session": str(self.root)})
        with self.assertRaises(ValueError):
            self.app.review_image({"session": str(session), "item_id": "../../private"})
        image.unlink()
        try:
            image.symlink_to(outside)
        except OSError:
            self.skipTest("Symbolic links unavailable")
        with self.assertRaises(ValueError):
            self.app.review_image({"session": str(session), "item_id": item["id"]})

    def test_review_http_routes_enforce_token_and_return_only_copied_asset(self):
        session, image, item = self.session()
        server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(self.app))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base = "http://127.0.0.1:" + str(server.server_port)
        try:
            with urlopen(base + "/api/review-sessions") as response:
                self.assertEqual(len(json.load(response)), 1)
            with urlopen(base + "/api/review?" + urlencode({"session": str(session)})) as response:
                detail = json.load(response)
            with urlopen(base + detail["items"][0]["image_url"]) as response:
                self.assertEqual(response.read(), image.read_bytes())
            body = json.dumps({"session": str(session), "item_id": item["id"], "label": "good"}).encode()
            request = Request(base + "/api/review-label", data=body, headers={"Content-Type": "application/json"})
            with self.assertRaises(HTTPError) as error:
                urlopen(request)
            self.assertEqual(error.exception.code, 403)
            request.add_header("X-Inspection-Token", self.app.token)
            with urlopen(request) as response:
                self.assertEqual(json.load(response)["label"], "good")
        finally:
            server.shutdown()
            server.server_close()
            thread.join(3)

    def test_weight_provision_is_explicit_argument_array(self):
        command = self.app.command("prepare-weights", {"task": "vig", "profile": "workstation"})
        self.assertIn("download-weights", command)
        self.assertEqual(command[command.index("--profile") + 1], "workstation")

    def test_workflow_creation_listing_and_execution_use_frozen_decisions(self):
        import numpy as np
        from nilt.common import sha_file
        from nilt.decisions import create_decision
        from test_integration_v2 import fixture_run
        run, dataset, _ = fixture_run(self.root)
        self.app.load_run({"path": str(run)})
        scores = run / "scores" / "patchcore_seed42"
        scores.mkdir(parents=True)
        np.save(scores / "threshold.npy", [8., 9., 1., 2.])
        write_json(scores / "provenance.json", {"candidate": "patchcore_seed42",
                   "manifest_sha256": sha_file(run / "manifest.csv"),
                   "files": {"threshold.npy": sha_file(scores / "threshold.npy")}})
        decision = create_decision(run, mode="manual", threshold=4., output_root=self.root / "decisions")
        definition = {"name": "Single stage check", "task": "top", "rule": "any_bad",
                      "stages": [{"name": "Surface inspection", "decision": str(decision)}]}
        result = self.app.create_workflow({"definition": definition})
        self.assertEqual(self.app.workflows()[0]["path"], result["path"])
        self.assertEqual(result["workflow"]["stages"][0]["threshold"], 4.)
        command = self.app.command("workflow-run", {"workflow": result["path"], "input": str(dataset),
                                   "output": str(self.root / "classified"), "labeled": True, "device": "cpu"})
        self.assertIn("--workflow", command)
        self.assertIn("--labeled", command)
        self.assertNotIn("--no-copy-images", command)


if __name__ == "__main__":
    unittest.main()
