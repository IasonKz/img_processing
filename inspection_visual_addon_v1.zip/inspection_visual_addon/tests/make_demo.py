"""Create an explicitly synthetic UI demonstration. Never trains or reads images."""
from pathlib import Path
import json
import sys
import tempfile

sys.path.insert(0,str(Path(__file__).resolve().parent))
from test_visual_addon import fixture,write_csv,write_json
from inspection_visual.report import build_report


def make_demo(output):
    with tempfile.TemporaryDirectory() as temp:
        root=Path(temp)
        run=fixture(root,'DEMO_run_01')
        model=run/'models/resnet18_seed42'
        write_csv(model/'history.csv',[dict(epoch=i,train_loss=1.1/(1+.1*i),val_loss=.92-.02*i,
            val_pr_auc_bad=.31+.01*i,val_bad_recall_at_0_5=.96,backbone_lr=.0001*(9-i)/8,seconds=180+i*4) for i in range(1,9)])
        write_json(model/'progress.json',dict(status='completed',best_epoch=8,current_epoch=8,total_epochs=8,device='SYNTHETIC CPU'))
        folder=model/'visual_telemetry/DEMO_SESSION'
        write_json(folder/'session.json',dict(status='completed',device='SYNTHETIC CPU',window_batches=25,
            measurement='Synthetic demonstration values; no hardware was benchmarked.'))
        write_csv(folder/'batch_windows.csv',[dict(epoch=(i-1)//10+1,batch_first=(i-1)%10*25+1,
            batch_last=((i-1)%10+1)*25,batches=25,images=25,seconds=3+i%6*.15,
            images_per_second=25/(3+i%6*.15),seconds_per_batch=(3+i%6*.15)/25,
            rss_mib=1200+(i%10)*20,cuda_allocated_mib='',cuda_reserved_mib='',completed=1) for i in range(1,81)])
        second=fixture(root,'DEMO_run_02')
        # Keep the same example performance; avoid implying a measured improvement.
        audit=root/'vig/DEMO_audit';write_json(audit/'config.json',dict(task='vig'))
        write_json(audit/'model_state.json',dict(status='PREPARED'))
        return build_report([audit,second,run],Path(output),demo=True)


if __name__=='__main__':make_demo(sys.argv[1])
