# Image review and reference labels

**Image review** displays the copied image, model prediction, reference tag, and operator review tag together. Records appear as classification or workflow execution publishes them. The gallery reads completed per-image records, so the entire batch need not finish before review begins.

## Three separate pieces of evidence

| Field | Source | Meaning |
| --- | --- | --- |
| Prediction | Saved model decision or composed workflow | What the software decided |
| Dataset reference | Original `good`/`bad` folder at classification time | Your original supplied tag |
| Operator review | Explicit good/bad/unknown/unreviewed action and note | A later human assessment, or an undecidable case |

The review operation does not overwrite the original image, move it to another source folder, or change the saved prediction. Operator tags and their history are stored separately in the classification output. Returning a record to unreviewed removes its current manual override, not its historical record.

## Review a batch

1. Classify with copied images enabled. For reference comparison, also mark the input as labeled.
2. In **Image review**, select the output session.
3. Filter by prediction, reference label, or review status. Inspect disagreements first when diagnosing errors. The v5 queue can prioritize errors, REVIEW abstentions, model disagreement, or distance to a decision boundary.
4. Open an image, compare the prediction and supplied tag, and record an operator tag plus a note where useful.
5. Inspect the resulting metric scope before interpreting accuracy or error rates.

The preview is read from a recorded output copy. A run made without image copies still has prediction records, but cannot show a copied-image preview. Unreadable or failed inputs are visible as errors and must not be interpreted as accepted good images.

An operator `unknown` tag means the image cannot yet be reliably labeled. It is different from a model's `review` abstention and from never having reviewed the image. Neither an unknown nor an unreviewed human tag becomes a training label. Queue priority is a heuristic, not a probability that the operator's label is wrong; inspect representative ordinary examples as well as difficult ones.

Use **Compare selected sessions** to compare two to four recorded classification or workflow sessions. Compare matched image identities with consistent reference labels; missing, changed, or unmatched inputs must not be treated as a measured improvement. This is the practical way to check whether an ordered workflow helps against the same labeled batch compared with its individual decisions.

## Metric scopes

| Scope | Denominator and labels | Suitable interpretation |
| --- | --- | --- |
| `dataset_reference` | Classified labeled records, using original tags | Prediction comparison with the supplied dataset |
| `reviewed_only` | Manually reviewed subset, using operator tags | Review progress and errors within that selected subset |
| `effective_reference` | Operator tag where present; otherwise original tag | A working corrected-label comparison |

These scopes answer different questions. Reviewing only disagreements creates a selected subset; its accuracy is not the accuracy of the entire batch or future production. Unlabeled, unreviewed records have no ground truth and do not produce an accuracy value.

Bad is the positive event: an actual bad predicted good is a **bad escape / false negative**. An actual good predicted bad is a **good reject / false positive**. For detailed formulas, see [MODELS_AND_METRICS.md](MODELS_AND_METRICS.md).

For a triage system, the reviewed-only/effective scopes also report automatic coverage, review workload, and accuracy on automatic decisions. A REVIEW output is not silently counted as correct or as a rejected bad. Compare selective accuracy together with coverage; sending all hard examples to humans changes the workload, not the underlying evidence.

## Stored records

- `review_session.json`: source decision/workflow and session identity.
- `review_progress.json`: live counts and status.
- `records/<id>.json`: atomic, complete prediction records.
- `predictions.jsonl`: incremental prediction journal.
- `reviews.json`: operator tags, notes, and history.
- `predicted/good`, `predicted/bad`, `predicted/review`: copies categorized by the relevant saved system's output.
- `copies/scored`: copied images for scores-only decisions.

## Export a controlled dataset revision

Review tags do not automatically retrain a model or rewrite the training dataset. The explicit **Review to training** action creates a new copied revision:

1. Complete human review of the selected session. Only explicit good/bad tags are eligible.
2. Choose a new output root outside the source images, experiment, and review session.
3. Select the replay source experiment when preparing an incremental update.
4. Keep **Include old training images for representative replay** enabled.
5. Use **Export confirmed dataset** and inspect counts, exclusions, notes, and readiness.
6. Use **Fine-tune from exported dataset** only when the export reports it is ready.

With a source experiment, the exporter copies **every old partition unchanged**, not only train. The training subset consists of old training replay plus eligible newly confirmed units; validation, threshold, selection, and test stay protected. New images cannot overlap a protected physical unit or protected file/decoded-pixel content. Exact content hashes, labels, source provenance, and physical-unit mapping are checked.

Conflicting labels in old training data require a deliberate new lineage/evaluation design, not an incremental update that silently rewrites historical truth. Ambiguous external group mappings, collapsed alias identities, or a path-dependent grouping rule that cannot be safely preserved cause an explicit rejection. Correct the data design instead of weakening these checks.

The exported revision records original/predicted/human tags and review history, session identities, image hashes, and lineage. Its generated update configuration is checked before fine-tuning. Changing images, image inventory, group mappings, or configuration after export invalidates that reviewed revision; create a new version instead.

Without a source experiment, export is allowed for annotation hand-off and curation, but it is **not automatically training-ready**. It does not invent old holdout identities or claim leakage safety. With a source experiment, disabling replay is rejected rather than silently changing the evaluation design.

Fine-tuning runs the existing controlled update workflow on the generated configuration. It creates a new experiment and does not overwrite the incumbent model. Keep the original experiment and compare performance on compatible unchanged evidence. This is operator-directed active learning, not automatic pseudo-labeling or autonomous retraining.

## Command-line export

From PowerShell in the project folder:

```powershell
$StudioPython = (Get-Content .studio-python.txt -Raw).Trim()
& $StudioPython inspection.py review-export --sessions 'D:/Inspection/classified/SESSION_ID' --source-run 'D:/Inspection/results/vig/SOURCE_RUN' --output-root review_datasets
```

The returned `config_path` is present only for an eligible update. The GUI validates and uses that exact configuration. For annotation-only export, omit `--source-run`; do not present that output as a qualified training revision.
