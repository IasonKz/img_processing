$ErrorActionPreference = "Stop"

Write-Host "Creating Python virtual environment .venv ..."
py -3 -m venv .venv

Write-Host "Activating .venv ..."
& .\.venv\Scripts\Activate.ps1

python -m pip install --upgrade pip

Write-Host ""
Write-Host "IMPORTANT: Install CUDA-enabled PyTorch and Torchvision using the command"
Write-Host "shown by the official selector: https://pytorch.org/get-started/locally/"
Write-Host "Choose Windows / Pip / Python / the CUDA option supported by this PC."
Write-Host "Run that command now in this PowerShell, then continue with:"
Write-Host ""
Write-Host "    pip install -r requirements.txt"
Write-Host "    python check_gpu.py"
Write-Host ""
