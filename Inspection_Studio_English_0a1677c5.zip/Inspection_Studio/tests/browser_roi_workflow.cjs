"use strict";
// Reproducible browser navigation + real local API test with synthetic images.
// Requires a locally installed Playwright Chromium. No route interception,
// model downloads, production images, or defect-quality claims.
// STUDIO_PYTHON=/path/to/python STUDIO_BROWSER_EXECUTABLE=/path/to/chrome \
//   node tests/browser_roi_workflow.cjs /tmp/roi-browser-evidence
const fs=require("node:fs"),path=require("node:path"),os=require("node:os"),assert=require("node:assert/strict");
const {spawn,spawnSync}=require("node:child_process"),net=require("node:net");
const {chromium}=require("playwright");
const repo=path.resolve(__dirname,".."),temporary=fs.mkdtempSync(path.join(os.tmpdir(),"inspection-roi-browser-"));
const output=path.resolve(process.argv[2]||path.join(os.tmpdir(),"inspection-roi-browser-evidence"));
const python=process.env.STUDIO_PYTHON||"python";
fs.mkdirSync(output,{recursive:true});
let browser,server,page,serverLog="";

const fixture=String.raw`
import csv,json,sys
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
from nilt.roi.geometry import default_template
root=Path(sys.argv[1]); size=256
for side in ('top','bottom'):
    (root/side).mkdir()
    rows=[]
    for i in range(3):
        image=Image.new('RGB',(size,size),(16,17,20)); draw=ImageDraw.Draw(image)
        draw.rectangle((20,20,235,235),fill=(66,67,68),outline=(210,210,210),width=3)
        if side=='bottom':
            for r in range(4):
                for c in range(4):
                    x,y=round((.275+c*.15)*(size-1)),round((.275+r*.15)*(size-1))
                    draw.ellipse((x-9,y-9,x+9,y+9),fill=(210-i-r,205-i-c,185+i))
            draw.polygon(((199,199),(222,222),(199,222)),fill=(230,230,230))
            draw.rectangle((212,118,224,132),fill=(210,210,210))
        else:
            draw.ellipse((84,84,171,171),outline=(190,190,190),width=5)
            draw.rectangle((40,40,96,66),fill=(190,190,190))
            draw.text((43,43),'REF '+str(i),fill=(15,15,15))
            draw.line(((192,37),(218,37),(218,68)),fill=(230,230,230),width=6)
            draw.line(((37,186),(37,216),(65,216)),fill=(230,230,230),width=6)
        # Unique pixels prevent synthetic copies from collapsing as duplicates.
        draw.point((24+i,24),fill=(120+i,90,80))
        filename=f'C83_Rc01_Cc{i+1:02d}_{side}.png'; image.save(root/side/filename)
        rows.append({'path':str(root/side/filename),'unit_id':f'C83:R1:C{i+1}','tray':'C83','label':'bad' if i==0 else 'good'})
    with (root/(side+'.csv')).open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['path','unit_id','tray','label']);writer.writeheader();writer.writerows(rows)
template=default_template('top');template.update(reference_size=[size,size],starter=False)
(root/'template.json').write_text(json.dumps(template))
(root/'project.yaml').write_text('schema_version: 3\nproject_name: SYNTHETIC_ROI_BROWSER\npaths:\n  output_root: ./results\n  weights_root: ./weights\ntasks:\n  vig:\n    dataset_root: ./vig\n  top:\n    dataset_root: ./top\n  bottom:\n    dataset_root: ./bottom\n')
`;

async function freePort(){return new Promise((resolve,reject)=>{const socket=net.createServer();socket.on("error",reject);socket.listen(0,"127.0.0.1",()=>{const port=socket.address().port;socket.close(()=>resolve(port));});});}
async function jobComplete(page,side){
  const deadline=Date.now()+120000;
  while(Date.now()<deadline){
    const result=await page.evaluate(async view=>api("/api/roi/job?side="+view),side);
    if(!["starting","running","unverified"].includes(result.job.status)){
      assert.equal(result.job.status,"completed",JSON.stringify(result.job));return result.job;
    }
    await new Promise(resolve=>setTimeout(resolve,250));
  }
  throw Error("ROI worker timeout for "+side);
}
async function post(page,endpoint,payload){return page.evaluate(async ({endpoint,payload})=>api(endpoint,payload),{endpoint,payload});}
async function state(page,side){return page.evaluate(async view=>api("/api/roi/state?side="+view),side);}

async function main(){
  const made=spawnSync(python,["-c",fixture,temporary],{cwd:repo,encoding:"utf8"});
  assert.equal(made.status,0,made.stderr);
  const port=await freePort(),base=`http://127.0.0.1:${port}`;
  server=spawn(python,["-u","inspection.py","dashboard","--config",path.join(temporary,"project.yaml"),"--port",String(port),"--no-browser"],{cwd:repo,stdio:["ignore","pipe","pipe"]});
  await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(Error("Dashboard startup timeout: "+serverLog)),20000);server.stdout.on("data",chunk=>{serverLog+=chunk.toString();if(serverLog.includes("Local dashboard:")){clearTimeout(timeout);resolve();}});server.stderr.on("data",chunk=>serverLog+=chunk.toString());server.once("exit",code=>{clearTimeout(timeout);reject(Error("Dashboard exited "+code+": "+serverLog));});});
  browser=await chromium.launch({headless:true,args:["--no-sandbox"],...(process.env.STUDIO_BROWSER_EXECUTABLE?{executablePath:process.env.STUDIO_BROWSER_EXECUTABLE}:{})});
  page=await browser.newPage({viewport:{width:1536,height:1024}});const errors=[];
  page.on("pageerror",error=>errors.push(error.message));
  await page.goto(base);await page.waitForFunction(()=>document.querySelector("#connection")?.textContent.includes("Connected"));
  assert.equal(await page.locator("[data-family]").count(),3);
  await page.locator('[data-family="segmentation"]').click();
  assert.equal(await page.locator('[data-workspace="top"]').isVisible(),true);
  assert.equal(await page.locator('[data-workspace="bottom"]').isVisible(),true);
  assert.equal(await page.locator('[data-workspace="vig"]').isVisible(),false);
  await page.locator('[data-family="roi"]').click();
  await page.locator('[data-workspace="top"]').click();
  assert.equal(await page.locator("#roi-navigation").isVisible(),true);
  await post(page,"/api/roi/import",{side:"top",csv_path:path.join(temporary,"top.csv"),split_ratios:[1,0,0]});
  await jobComplete(page,"top");
  let top=await state(page,"top");assert.equal(top.images.length,3);
  assert.deepEqual([...new Set(top.images.map(row=>row.split))],["train"]);
  const template=JSON.parse(fs.readFileSync(path.join(temporary,"template.json"),"utf8"));
  await post(page,"/api/roi/template",{side:"top",template,reference_image_id:top.images[0].id});
  await post(page,"/api/roi/localize",{side:"top",force:true});await jobComplete(page,"top");
  top=await state(page,"top");
  for(const row of top.images){
    assert.equal(row.annotation.rois.length,7);
    assert.equal(Object.values(row.annotation.quality).every(label=>label==="unknown"),true,"An image-level Bad tag must not label every ROI");
    await post(page,"/api/roi/annotation",{side:"top",image_id:row.id,geometry_reviewed:true});
  }
  top=await state(page,"top");
  assert.equal(top.counts.geometry_reviewed,3);
  assert.equal(Object.values(top.images[0].annotation.quality).every(label=>label==="unknown"),true,"Geometry approval must not approve quality");
  await page.locator('[data-roi-step="review"]').click();
  await page.screenshot({path:path.join(output,"SYNTHETIC-roi-review.png"),fullPage:true});
  for(const [index,row]of top.images.entries())await post(page,"/api/roi/annotation",{side:"top",image_id:row.id,quality:{label:index===0?"bad":"good"}});
  await post(page,"/api/roi/export",{side:"top",classification:true,segmentation:true});await jobComplete(page,"top");
  top=await state(page,"top");const exported=top.exports.at(-1);
  assert.equal(exported.counts.images,3);assert.equal(exported.counts.labeled_crops,3);
  const labelDataset=exported.classification.find(row=>row.kind==="label");assert.ok(labelDataset);
  assert.equal(fs.existsSync(path.join(labelDataset.path,"groups.csv")),true);
  // Open the actual crop editor in ROI Detection and save a reviewed negative.
  // Geometry/quality labels must not preapprove defect masks.
  await page.locator('[data-roi-step="annotations"]').click();
  await page.waitForFunction(()=>document.querySelector('#roi-seg-kind').options.length>0);
  await page.locator('#roi-seg-kind').selectOption('label');
  await page.locator('#roi-crop-annotate').click();
  const cropPrefix=`/segmentation/top/roi/label/${exported.export_id}`;
  await page.waitForFunction(prefix=>document.querySelector('#roi-crop-annotation-host iframe:not([hidden])')?.src.endsWith(prefix+'/annotate'),cropPrefix);
  const roiEditor=page.frameLocator('#roi-crop-annotation-host iframe:not([hidden])');
  await roiEditor.locator('#queue-total').filter({hasText:/^3$/}).waitFor();
  await roiEditor.locator('#save-draft:enabled').waitFor();
  assert.equal(await roiEditor.locator('#queue-total').innerText(),'3');
  const cropProject=()=>page.evaluate(async prefix=>{
    const doc=document.querySelector('#roi-crop-annotation-host iframe:not([hidden])').contentDocument;
    const token=doc.querySelector('meta[name="session-token"]').content;
    return fetch(prefix+'/api/project',{headers:{'X-Session-Token':token}}).then(r=>r.json());
  },cropPrefix);
  let crops=await cropProject();assert.equal(crops.items.filter(row=>row.status==='approved').length,0);
  page.on('dialog',dialog=>dialog.accept());
  await roiEditor.locator('#clear-mask').click();
  await roiEditor.locator('#notes').fill('Synthetic shared ROI crop review');
  await roiEditor.locator('#approve-clean').click();
  await page.waitForFunction(prefix=>{
    const doc=document.querySelector('#roi-crop-annotation-host iframe:not([hidden])')?.contentDocument;
    return doc?.querySelector('#progress-text')?.textContent.startsWith('1 / ');
  },cropPrefix);
  crops=await cropProject();const reviewed=crops.items.find(row=>row.status==='approved');assert.ok(reviewed);
  await page.screenshot({path:path.join(output,'SYNTHETIC-roi-crop-annotation.png'),fullPage:true});
  assert.equal(await page.locator('#roi-crop-annotation-host iframe:not([hidden])').evaluate(el=>el.clientWidth>900),true);
  // The Segmentation editor must use the exact same reviewed crop project.
  await page.locator('#roi-crop-train').click();
  await page.waitForFunction(()=>document.querySelector('#segmentation-target').value==='roi_crops'&&document.querySelector('#seg-crop-kind').value==='label');
  const cropStudio=page.frameLocator('#segmentation-host > iframe:not([hidden])');
  await cropStudio.locator('#tab-search.active').waitFor();
  assert.equal(await cropStudio.locator('#require-both').isChecked(),false);
  assert.equal(await cropStudio.locator('#val-fraction').isDisabled(),true);
  await page.locator('[data-segmentation-tab="annotation"]').click();
  const segmentationEditor=cropStudio.frameLocator('#annotation-frame');
  await segmentationEditor.locator('#save-draft:enabled').waitFor();
  await segmentationEditor.locator('.image-item').filter({hasText:reviewed.relative_path}).click();
  await segmentationEditor.locator('#notes').waitFor();
  await page.waitForFunction(note=>{
    const host=document.querySelector('#segmentation-host > iframe:not([hidden])')?.contentDocument;
    return host?.querySelector('#annotation-frame')?.contentDocument?.querySelector('#notes')?.value===note;
  },'Synthetic shared ROI crop review');
  assert.match(await segmentationEditor.locator('#image-status').innerText(),/Approved/);
  await page.locator('#annotation-fullscreen').click();
  await page.waitForFunction(()=>document.fullscreenElement?.id==='main-content');
  await page.locator('#annotation-fullscreen').click();
  await page.waitForFunction(()=>!document.fullscreenElement);
  await page.screenshot({path:path.join(output,'SYNTHETIC-segmentation-roi-shared.png'),fullPage:true});
  await page.locator('#seg-crop-return').click();
  await page.waitForFunction(()=>document.querySelector('#roi-seg-kind').value==='label'&&document.querySelector('#roi-navigation').hidden===false);
  // Localization training moved to Segmentation; its geometry stays in ROI.
  await page.locator('[data-roi-step="export"]').click();
  await page.locator('#roi-open-localizer').click();
  await page.waitForFunction(()=>document.querySelector('#segmentation-target').value==='roi_localizer');
  assert.equal(await page.locator('#roi-train').isVisible(),true);
  assert.equal(await page.locator('#roi-training-dataset').inputValue(),exported.segmentation.path);
  assert.equal(await page.locator('[data-segmentation-tab="search"]').isVisible(),false);
  await post(page,"/api/roi/classification",{side:"top",roi_scope:"label",dataset:labelDataset.path});
  await page.reload();await page.waitForFunction(()=>document.querySelector("#connection")?.textContent.includes("Connected"));
  await page.locator('[data-family="classification"]').click();
  await page.locator('[data-workspace="top"]').click();
  await page.locator("#classification-scope").selectOption("label");
  await page.waitForFunction(expected=>document.querySelector("#dataset").value===expected,labelDataset.path);
  assert.equal(await page.locator("#nav-search").isVisible(),true);
  await page.screenshot({path:path.join(output,"SYNTHETIC-roi-classification.png"),fullPage:true});
  await post(page,"/api/roi/import",{side:"bottom",csv_path:path.join(temporary,"bottom.csv"),split_ratios:[0,0,1]});
  await jobComplete(page,"bottom");const bottom=await state(page,"bottom");
  assert.equal(bottom.images.length,3);
  for(const row of bottom.images)assert.equal(row.split,top.images.find(item=>item.unit_id===row.unit_id).split,"Existing same-unit split must be reused across views");
  await page.locator('[data-family="roi"]').click();await page.locator('[data-workspace="bottom"]').click();
  assert.equal(await page.locator('[data-workspace="vig"]').isVisible(),false);
  await page.locator('[data-family="segmentation"]').click();
  await page.waitForFunction(()=>document.querySelector('#segmentation-target').value==='roi_crops');
  assert.equal(await page.locator('#segmentation-target option[value="whole_image"]').count(),0);
  assert.equal(await page.locator('#seg-empty').isVisible(),true);
  // BOTTOM crops also mount the common editor, with the correct view labels.
  await post(page,'/api/roi/template',{side:'bottom',template:bottom.default_template,reference_image_id:bottom.images[0].id});
  await post(page,'/api/roi/localize',{side:'bottom',method:'template'});await jobComplete(page,'bottom');
  for(const row of bottom.images)await post(page,'/api/roi/annotation',{side:'bottom',image_id:row.id,geometry_reviewed:true});
  await post(page,'/api/roi/export',{side:'bottom',classification:false,segmentation:true,kinds:['pins']});await jobComplete(page,'bottom');
  await page.locator('[data-family="roi"]').click();
  await page.locator('[data-roi-step="annotations"]').click();
  await page.waitForFunction(()=>document.querySelector('#roi-seg-kind').value==='pins');
  await page.locator('#roi-crop-annotate').click();
  const bottomEditor=page.frameLocator('#roi-crop-annotation-host iframe:not([hidden])');
  await bottomEditor.locator('#queue-total').filter({hasText:/^48$/}).waitFor();
  await bottomEditor.locator('#save-draft:enabled').waitFor();
  assert.ok(Number(await bottomEditor.locator('#queue-total').innerText())>=3);
  assert.match(await bottomEditor.locator('.properties-panel').innerText(),/BOTTOM ROI/);
  await page.locator('#roi-crop-fullscreen').click();
  await page.waitForFunction(()=>document.fullscreenElement?.id==='main-content');
  await page.locator('#roi-crop-fullscreen').click();
  await page.waitForFunction(()=>!document.fullscreenElement);
  await page.screenshot({path:path.join(output,'SYNTHETIC-bottom-roi-annotation.png'),fullPage:true});
  await page.locator('[data-family="segmentation"]').click();
  await page.locator('[data-workspace="top"]').click();
  await page.locator('#segmentation-target').selectOption('whole_image');
  await page.frameLocator('#segmentation-host > iframe:not([hidden])').locator('#tab-workspace.active').waitFor();
  await page.reload();await page.waitForFunction(()=>document.querySelector("#connection")?.textContent.includes("Connected"));
  assert.equal((await state(page,"top")).counts.geometry_reviewed,3);
  assert.equal((await state(page,"top")).exports.length,1);
  assert.deepEqual(errors,[]);
  const evidence={status:"passed",scope:"Synthetic live ROI exports, shared crop annotation in both sections, saved review round trip, Segmentation model search controls, fullscreen, moved localizer training, BOTTOM ROI-only and TOP whole-image navigation; no route interception",top_images:3,bottom_images:3,reviewed_top_images:3,labeled_crops:3,shared_crop_reviews:1,page_errors:errors,not_tested:["Production localization accuracy","Real defect classifier training or accuracy","Canvas drag ergonomics","Windows or GPU execution"]};
  fs.writeFileSync(path.join(output,"SYNTHETIC-roi-browser-verification.json"),JSON.stringify(evidence,null,2));console.log(JSON.stringify(evidence,null,2));
}
main().catch(async error=>{console.error(error);if(page){console.error(await page.locator('#notice').innerText());await page.screenshot({path:path.join(output,'FAILED-workflow.png'),fullPage:true});}if(serverLog)console.error(serverLog);process.exitCode=1;}).finally(async()=>{if(browser)await browser.close();if(server)server.kill("SIGINT");fs.rmSync(temporary,{recursive:true,force:true});});
