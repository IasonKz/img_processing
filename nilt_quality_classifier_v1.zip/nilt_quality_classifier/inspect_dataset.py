from __future__ import annotations

import argparse

from qc.audit import run_dataset_audit
from qc.config import load_yaml


def main() -> None:
    parser = argparse.ArgumentParser(description="Audit image dimensions, bit depth and duplicates.")
    parser.add_argument("--config", required=True, help="Path to a dataset-audit YAML file")
    args = parser.parse_args()
    result = run_dataset_audit(load_yaml(args.config))
    print(f"\nAudit output: {result['dataset_root']}")
    print(f"Warnings: {result['warnings']}")


if __name__ == "__main__":
    main()
