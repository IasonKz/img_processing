# Release verification — Inspection Studio 4.0.0

Verification date: 17 September 2026.

## Executed checks

| Check | Result |
| --- | --- |
| Complete Python test suite | 272 tests: 271 passed, 1 skipped; no failures |
| JavaScript syntax | Passed |
| Operator interface behavior tests | Passed using a dependency-free Node DOM harness |
| Python source compilation | Passed |
| English-only source and documentation scan | Passed |
| HTML element identifiers and local script/style references | Passed |
| Documented command examples | 80 examples parsed using the application argument parser |
| Windows setup's embedded CPU computation probe | Real ResNet18 forward/backward passed on CPU |

The full suite includes real CPU training on controlled synthetic data, Optuna
pause/resume and deadline behavior, fixed decisions, ONNX export parity,
quarter-turn augmentation, grouping and split integrity, report generation,
checkpoint integrity, and model package handling.

New workflow checks cover complete Boolean rule truth tables, conservative vote
ties, per-image early exits, skipped-stage records, unchanged source images,
decision/checkpoint tamper detection, invalid inputs, interrupted output, and
real CPU ResNet18 inference matching a one-stage workflow with the same decision.

Review checks cover publication during inference, copied-image identity,
immutable predictions, original labels, separate operator corrections/history,
pagination, filtering, unlabeled metrics, and matching input fingerprints for
session comparison. Comparison rejects changed image bytes, paths, or original
labels and does not use operator overrides as the original reference.

HTTP checks exercise session authorization, loopback access, path containment,
copied-image access, experiment registration, job recovery, process identity and
PID reuse, configuration persistence, and actual failure details.

The interface harness exercises all eight tabs, workflow editing/saving/running,
image review and notes, stage traces, comparison, explicit weight downloads,
failure rendering, text escaping, and preservation of typed input during polls.
It is a behavioral check, not a visual browser-layout check.

## Test environment

| Component | Version |
| --- | --- |
| Operating system | Linux |
| Python | 3.12.14 |
| PyTorch | 2.7.1+cpu |
| torchvision | 0.22.1+cpu |
| Optuna | 4.5.0 |
| NumPy | 2.3.5 |
| scikit-learn | 1.8.0 |
| ONNX | 1.22.0 |
| ONNX Runtime | 1.30.0 |
| Node.js | 24.19.0 |

## Checks requiring the destination computer

- Native Windows file locking: the Windows-specific reader-lock test was skipped
  on Linux. Simulated Windows access/sharing failures, retry limits, checkpoint
  retention and JSON/CSV atomic publishing were tested.
- Windows PowerShell and command launchers: source and embedded Python were
  checked, but the launchers were not executed on Windows.
- CUDA training, driver compatibility, VRAM limits, and workstation throughput:
  not measured in this CPU environment.
- Rendered browser layout: the available preview browser could not access the
  local server. HTTP and JavaScript behavior were tested; visual layout was not
  verified in a live browser.
- Customer image performance: no customer images or pretrained production
  checkpoints were used to measure accuracy, bad escapes, or good rejects.

Follow the installation acceptance steps in [VALIDATION_REPORT.md](VALIDATION_REPORT.md)
on each destination machine. Software test results do not establish industrial
qualification or defect-detection performance. Freeze the complete inspection
rule and validate it on independent representative images before production use.

## Repeat the software checks

From the project directory, using its configured environment:

```powershell
$StudioPython = (Get-Content .studio-python.txt -Raw).Trim()
& $StudioPython -m unittest discover -s tests -p 'test_*.py'
```

With Node.js available, the optional interface behavior check is:

```powershell
node tests/test_v4_ui.cjs
```

Node.js is needed only for this test; the application itself does not require it.
