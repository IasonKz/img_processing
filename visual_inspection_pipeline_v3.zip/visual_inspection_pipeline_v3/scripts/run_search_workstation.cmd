@echo off
setlocal
cd /d "%~dp0.."
if not exist ".venv\Scripts\python.exe" (
    echo Missing .venv. Follow START_HERE.md or docs\INSTALLATION.md first.
    pause
    exit /b 2
)
".venv\Scripts\python.exe" "inspection.py" search --config "project.yaml" --profile workstation --task vig %*
set "inspection_exit=%ERRORLEVEL%"
echo Search command finished with exit code %inspection_exit%.
pause
exit /b %inspection_exit%
