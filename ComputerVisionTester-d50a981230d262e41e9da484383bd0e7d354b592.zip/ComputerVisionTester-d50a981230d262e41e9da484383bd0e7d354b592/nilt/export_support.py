"""ONNX dependency checks in the exact interpreter running the exporter."""
from __future__ import annotations

import importlib
from pathlib import Path
import sys


def export_dependencies():
    modules = []
    for name in ("onnx", "onnxruntime"):
        try:
            modules.append(importlib.import_module(name))
        except Exception as error:
            requirements = Path(__file__).resolve().parent.parent / "requirements-export.txt"
            missing = isinstance(error, ModuleNotFoundError) and error.name == name
            reason = "is missing" if missing else "is installed but cannot load"
            raise RuntimeError(
                f"ONNX dependency {name} {reason} in {sys.executable}. "
                f"Original error: {type(error).__name__}: {error}\n"
                "Close the dashboard, run Setup-Export.cmd from this extracted project, then restart Start.cmd. "
                "It repairs the environment recorded by Start.cmd, without reinstalling PyTorch. "
                f'Alternatively run: "{sys.executable}" -m pip install --upgrade -r "{requirements}". '
                "On Windows, a DLL load failure may require the Microsoft Visual C++ x64 runtime; "
                "see docs/EXPORT_AND_VIEWER_FIXES.md."
            ) from error
    modules[1].disable_telemetry_events()
    if "CPUExecutionProvider" not in modules[1].get_available_providers():
        raise RuntimeError("The installed ONNX Runtime has no CPUExecutionProvider. Run Setup-Export.cmd.")
    return tuple(modules)
