# Changelog

## 0.2.0

- Added native-resolution polygon boundaries and a clipped-corner octagon default; old ellipses remain readable.
- Added optional local boundary detection with review/fallback metadata.
- Automatically assign every annotated pixel to Inner or Outer, including split annotations crossing the boundary and later boundary edits.
- Dragging from outside the image now pans with any drawing tool selected.
- Added reversible rejection, explicit restore to draft, and rejected-image dataset exclusion.
- Added persistent annotation objects with exact shape thumbnails, selection, hide/show and delete; hidden objects remain training labels.
- Included object and boundary changes in undo/redo, while preserving immutable saved revisions.
- Kept original-image preservation, local processing, approval rules, training commands and mask labels 0/1/2.

## 0.1.0

- Added local, one-image-at-a-time top-view annotation with manual Inner/Outer defect classes.
- Added classical contrast-based proposals guided by a per-image lens ellipse.
- Added editable native-resolution masks, revision history, explicit approval, and clean-negative approval.
- Added independent approved-data snapshots with physical-unit grouping.
- Added optional small U-Net training, per-class validation metrics, checkpoints, and native-geometry mask prediction.
- Separated the lightweight annotation environment from the PyTorch training dependency.

This release is a pilot for annotation and segmentation experiments. It includes no trained weights, real inspection dataset, or production accuracy certification.
