# TOP/BOTTOM ROI workflow

Start Inspection Studio with `Start.cmd` on Windows or `python inspection.py dashboard --config project.yaml` in the active Python environment.

| Section | Views | Responsibility |
| --- | --- | --- |
| **Classification** | TOP / BOTTOM / VIG | Train and apply whole-image or ROI-specific Good/Bad classifiers. |
| **Segmentation** | TOP / BOTTOM | Train TOP whole-image defect models, ROI crop defect models, and geometric ROI localizers. |
| **ROI Detection** | TOP / BOTTOM | Import images, define geometry, locate and review regions, assign quality labels, export datasets, and annotate crops. |

**Classification → TOP** supports Whole image, Corners, Label, Inner area and Lens. **Classification → BOTTOM** supports Whole image, Pins, Triangle and Side rectangle / square. VIG uses Whole image. The 16 BOTTOM pins share one classifier kind while retaining separate ROI IDs and results for each position.

## 1. Import and splits

In **ROI Detection**, select TOP or BOTTOM and open **Import & splits**. Supported inputs are image folders, `good/bad` folders and CSV manifests. Source files remain in their original locations and are required for crop export; retain them throughout the project lifecycle.

A CSV provides explicit source and unit identity. Relative paths are resolved against the CSV directory:

```csv
path,unit_id,tray,label
top/C83_Rc01_Cc01_top.png,C83_R1_C1,C83,good
top/C83_Rc01_Cc02_top.png,C83_R1_C2,C83,bad
```

Use the **same `unit_id` for the same physical module** across TOP, BOTTOM and repeated captures. View names, dates and capture numbers are not part of the unit identity. A filename stem is suitable only when it already identifies the physical unit without capture-specific suffixes.

Train, validation and test roles are assigned before crop generation and recorded in a shared TOP/BOTTOM split registry. Unknown or provisional unit IDs require confirmation before dataset export. Duplicate detection compares decoded pixels, including identical images saved under different names or formats. Resolve provenance and label conflicts before export.

For independent tray evaluation, designate the test tray during initial import. Units with committed roles cannot be freely reassigned from training to test. A different split policy requires a new project and evaluation.

## 2. Geometry template

Select a clear **training** image as the reference. The TOP starter includes label, two corners, inner area, lens and reference features. The BOTTOM starter includes a 4 × 4 pin grid, triangle and side square. Starter dimensions are editable guides and require calibration against the inspected modules.

Existing geometry can be imported from `camera_geometry_annotation.v1` JSON created by `tools/camera_geometry_annotator.py`. Coordinates must correspond to the same reference image. The standalone annotator runs with `python tools/camera_geometry_annotator.py` on a desktop with Tk support.

Define the geometry once and save it as a template. Localization transfers it to subsequent images using the estimated transform. Corner and pin IDs follow the canonical orientation of the reference. The lens center remains a reference point and does not require a crop.

Use **Load starter geometry**, select an ROI, and edit it with **Move / vertices** or redefine it with **Polygon / Circle / Point**. **Finish polygon** completes a polygon. For BOTTOM, **Generate 4 × 4 pin grid** creates 16 pins from the specified origin, X/Y spacing and radius; triangle and square remain separately editable. Finish with **Save geometry template**.

**Edit die outline** exposes the BOTTOM die reference polygon. It is stored with the template and does not add another inspection ROI: the evaluated regions remain 16 pins, triangle and square.

Each ROI stores its crop margin. Pin crops should include sufficient neighboring context to reveal bridges. The exported geometry mask is separate from the crop and does not remove that context.

## 3. Locate and review

Run localization and inspect the image queue with overlays. Automatic alignment compares against the reference at 0°, 90°, 180° and 270°, with additional small rotations, translations and scale changes. Contrast enhancement assists localization; exported crops use the original image pixels.

Review orientation, position and margin. Correct existing shapes where necessary. Ambiguous alignment remains pending review; inspect a sample of apparently successful results as well.

**Save corrections** stores the draft. **Approve geometry** permits crop export. The mouse wheel zooms, Space-drag pans, and Undo restores the previous edit. **Display contrast** changes the preview only.

A missing pin retains its expected ROI so that the region can be evaluated as Bad. Geometry approval confirms the crop location; it does not certify that a feature is present or Good.

Template changes mark previous annotations as stale. Recheck affected corrections, exports and quality labels before reuse.

## 4. Quality labels

In **Quality labels**, assign Good, Bad or Unknown to each ROI. The source folder label describes the complete image and is not automatically copied to individual regions.

Bulk assignment to Good is an explicit operator judgment and requires inspection of every affected region. Unknown and unconfirmed labels are excluded from binary training targets.

## 5. Dataset export and classification

**Export datasets** creates a new snapshot linking every crop to its source image, physical unit, ROI and split. Geometry-mask exports and labelled classification exports serve different training tasks.

**Rotate crops to canonical orientation** resamples crop pixels and records the transformation in the export recipe. **Normalize TOP corners to one orientation** additionally rotates the bottom-left corner by 180° for a shared corner classifier. Without these options, crops preserve the source pixel grid. Retain context around pin masks.

Select the labelled export in **Classification → TOP/BOTTOM → ROI kind**, then use Dataset & setup, Train & search, Compare models and Decision explorer. ROI classifiers have separate scopes from whole-image classifiers.

**Saved export** restores a previous snapshot's paths. Select a kind and use **Use dataset → Classification**. The whole-image configuration is retained when switching back to that scope.

The classification backend subdivides development `val` data into validation, threshold and selection roles while keeping units intact and reserving test data. These roles require sufficient independent Good and Bad units. A small export suitable for a software check may be insufficient for training.

## 6. Geometric ROI localizer training

Training is available under **Segmentation → TOP/BOTTOM → ROI localization · geometry masks**. Geometry annotation and model application remain in **ROI Detection**. The localizer learns region positions and shapes; quality classification is a separate task. Nested TOP regions use independent output channels so that masks can overlap.

Visible-shape confirmation is separate from expected crop geometry. Confirm the observed feature outline when visible, or mark the feature absent when it is missing. Moving an expected ROI or changing its margin does not establish a positive training mask.

| Control | Training meaning |
| --- | --- |
| **Confirm visible shape** | The reviewed visible outline becomes a positive mask. |
| **Feature absent** | The feature is confirmed absent; its expected ROI remains available for quality evaluation. |
| **Visibility unknown / occluded** | The visible material is uncertain; this region is excluded from positive and negative supervision. |

Persist these judgments with **Save corrections**. **Confirm all visible shapes** requires the same review for every affected region.

The compact ROI U-Net trains locally from random initialization without downloading pretrained weights. CPU and CUDA are supported. Training units are used for fitting, validation units for checkpoint selection, and test units for neither.

Each experiment records `model.json`, `best.pt`, `last.pt`, `history.json` and `status.json`. The mask threshold is a configured segmentation parameter, not a calibrated quality decision threshold.

Frozen-model evaluation reports Dice/IoU and the count of supervised pixels. These metrics measure geometric masks, not defect escape rates or the complete inspection pipeline.

## 7. Defect segmentation within crops

Under **ROI Detection → Crop annotations**, select an export and ROI kind to annotate defects in the cropped images. **Continue → Segmentation** opens the same project for model search. **Segmentation → ROI crops · defects** supports both TOP and BOTTOM; whole-image segmentation supports TOP only. Native pixels and physical-unit splits are inherited from the export. See [ROI segmentation](ROI_SEGMENTATION.md).

## Initial validation cycle

Use a small representative development set containing clean modules, rotations and difficult defects. Complete import, template calibration, localization, review and export. Visually inspect crops before extensive quality labeling or model training.

Synthetic tests verify software behavior. Localization reliability and defect-detection performance require separate measurements on representative production data and independent test trays.
