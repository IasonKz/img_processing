from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable

import torch
from torch import nn
from torchvision import models

SUPPORTED_ARCHITECTURES = (
    "resnet18",
    "resnet34",
    "resnet50",
    "efficientnet_b0",
    "efficientnet_b2",
    "convnext_tiny",
)


def create_model(
    architecture: str,
    *,
    pretrained: bool = True,
    num_classes: int = 2,
    dropout: float = 0.0,
) -> nn.Module:
    architecture = architecture.lower().strip()
    if architecture not in SUPPORTED_ARCHITECTURES:
        raise ValueError(
            f"Unsupported architecture '{architecture}'. "
            f"Choose one of: {', '.join(SUPPORTED_ARCHITECTURES)}"
        )

    if architecture == "resnet18":
        weights = models.ResNet18_Weights.DEFAULT if pretrained else None
        model = models.resnet18(weights=weights)
        features = model.fc.in_features
        model.fc = _classification_head(features, num_classes, dropout)
    elif architecture == "resnet34":
        weights = models.ResNet34_Weights.DEFAULT if pretrained else None
        model = models.resnet34(weights=weights)
        features = model.fc.in_features
        model.fc = _classification_head(features, num_classes, dropout)
    elif architecture == "resnet50":
        weights = models.ResNet50_Weights.DEFAULT if pretrained else None
        model = models.resnet50(weights=weights)
        features = model.fc.in_features
        model.fc = _classification_head(features, num_classes, dropout)
    elif architecture == "efficientnet_b0":
        weights = models.EfficientNet_B0_Weights.DEFAULT if pretrained else None
        model = models.efficientnet_b0(weights=weights)
        features = model.classifier[-1].in_features
        model.classifier[-1] = nn.Linear(features, num_classes)
        if dropout >= 0 and isinstance(model.classifier[0], nn.Dropout):
            model.classifier[0].p = dropout
    elif architecture == "efficientnet_b2":
        weights = models.EfficientNet_B2_Weights.DEFAULT if pretrained else None
        model = models.efficientnet_b2(weights=weights)
        features = model.classifier[-1].in_features
        model.classifier[-1] = nn.Linear(features, num_classes)
        if dropout >= 0 and isinstance(model.classifier[0], nn.Dropout):
            model.classifier[0].p = dropout
    elif architecture == "convnext_tiny":
        weights = models.ConvNeXt_Tiny_Weights.DEFAULT if pretrained else None
        model = models.convnext_tiny(weights=weights)
        features = model.classifier[-1].in_features
        model.classifier[-1] = nn.Linear(features, num_classes)
        if dropout > 0:
            # ConvNeXt's classifier is LayerNorm -> Flatten -> Linear. Insert
            # dropout immediately before the final layer.
            model.classifier = nn.Sequential(
                *list(model.classifier.children())[:-1],
                nn.Dropout(dropout),
                nn.Linear(features, num_classes),
            )
    else:  # pragma: no cover - guarded above
        raise AssertionError(architecture)

    return model


def _classification_head(features: int, num_classes: int, dropout: float) -> nn.Module:
    if dropout > 0:
        return nn.Sequential(nn.Dropout(dropout), nn.Linear(features, num_classes))
    return nn.Linear(features, num_classes)


def classifier_modules(model: nn.Module, architecture: str) -> list[nn.Module]:
    architecture = architecture.lower()
    if architecture.startswith("resnet"):
        return [model.fc]
    if architecture.startswith("efficientnet") or architecture.startswith("convnext"):
        return [model.classifier]
    raise ValueError(f"Unsupported architecture: {architecture}")


def set_backbone_trainable(model: nn.Module, architecture: str, trainable: bool) -> None:
    for parameter in model.parameters():
        parameter.requires_grad = trainable
    # The classifier must always remain trainable.
    for module in classifier_modules(model, architecture):
        for parameter in module.parameters():
            parameter.requires_grad = True


def set_frozen_batchnorm_eval(model: nn.Module) -> None:
    for module in model.modules():
        if isinstance(module, (nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d, nn.SyncBatchNorm)):
            module.eval()


def split_backbone_and_head_parameters(
    model: nn.Module,
    architecture: str,
) -> tuple[list[nn.Parameter], list[nn.Parameter]]:
    head_ids: set[int] = set()
    head_parameters: list[nn.Parameter] = []
    for module in classifier_modules(model, architecture):
        for parameter in module.parameters():
            if parameter.requires_grad:
                head_ids.add(id(parameter))
                head_parameters.append(parameter)

    backbone_parameters = [
        parameter
        for parameter in model.parameters()
        if parameter.requires_grad and id(parameter) not in head_ids
    ]
    return backbone_parameters, head_parameters


def count_parameters(model: nn.Module) -> dict[str, int]:
    return {
        "total": sum(parameter.numel() for parameter in model.parameters()),
        "trainable": sum(
            parameter.numel() for parameter in model.parameters() if parameter.requires_grad
        ),
    }


def load_torch_checkpoint(path: str | Path, map_location: str | torch.device = "cpu") -> dict[str, Any]:
    checkpoint_path = Path(path).expanduser().resolve()
    if not checkpoint_path.is_file():
        raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")
    try:
        checkpoint = torch.load(checkpoint_path, map_location=map_location, weights_only=False)
    except TypeError:
        checkpoint = torch.load(checkpoint_path, map_location=map_location)
    if not isinstance(checkpoint, dict) or "model_state" not in checkpoint:
        raise ValueError(f"Not a valid project checkpoint: {checkpoint_path}")
    return checkpoint


def model_from_checkpoint(
    path: str | Path,
    *,
    device: torch.device,
) -> tuple[nn.Module, dict[str, Any]]:
    checkpoint = load_torch_checkpoint(path, map_location=device)
    architecture = str(checkpoint["architecture"])
    model = create_model(
        architecture,
        pretrained=False,
        num_classes=int(checkpoint.get("num_classes", 2)),
        dropout=float(checkpoint.get("dropout", 0.0)),
    )
    model.load_state_dict(checkpoint["model_state"], strict=True)
    model.to(device)
    return model, checkpoint
