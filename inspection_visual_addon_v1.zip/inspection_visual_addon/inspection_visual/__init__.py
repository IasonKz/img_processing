"""Offline reporting and opt-in telemetry for Visual Inspection Pipeline v2."""
__version__ = "1.0.0"
