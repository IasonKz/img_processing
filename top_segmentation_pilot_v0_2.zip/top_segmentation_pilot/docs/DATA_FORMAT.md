# Data Format and Preservation

## Images and labels

Source images are read during import and converted into EXIF-normalized RGB PNG working copies without rescaling. Normalizing a rotated EXIF orientation can swap width and height. The application does not crop, align, brighten, or overwrite the source image. Keep the original source dataset as the acquisition record.

Supported file extensions are PNG, JPEG, TIFF, BMP, and WebP. Supply one opaque 8-bit frame per file. Multi-frame files, transparent images, and 16-bit/floating-point images require explicit conversion before import. The default import limit is 25 million pixels per image; the configuration can change it, but browser mask editing also needs sufficient memory.

A mask is a single-channel integer PNG with exactly the working image's width and height:

| Stored value | Meaning |
| ---: | --- |
| `0` | Background / no labeled defect |
| `1` | Inner defect |
| `2` | Outer defect |

Colored overlays are previews, not training masks. A label-mask PNG can look almost black in a normal image viewer because its values are only 0, 1, and 2. Do not threshold or recolor that file before training. The value `255` is reserved for ignored padding during model preprocessing and is not an annotation class.

The annotation interface displays one image at a time. All masks use native image coordinates. Zooming or changing display opacity affects presentation only.

## Annotation lifecycle

| State | Meaning | Included in datasets? |
| --- | --- | --- |
| Unannotated | No saved annotation yet | No |
| Draft | Automatic proposal or manually saved unfinished work | No |
| Approved | Operator accepted this exact saved revision | Yes |
| Rejected | Operator excluded an unsuitable image; original and annotations retained | No |

Rejecting an image creates a revision with status `rejected`. Restoring it creates a draft; it must be approved again to enter future datasets. Editing a rejected image does not silently restore it. Previously exported immutable snapshots are unchanged; create a new export after exclusions.

Opening an unannotated image generates a draft proposal. Proposal generation never approves the image. A clean image must have an all-background mask and explicit clean approval. A mask with defect pixels is not a clean negative.

Each save creates a new revision with its mask and annotation metadata. Earlier saved revisions remain in the history. Saving edited work as a draft removes that current revision from subsequent training exports until it is approved. Exported datasets are unaffected by later annotation edits.

The browser submits the revision it edited. If another tab or session has already changed that annotation, the server rejects the stale save rather than overwriting the newer revision. Reload the image to inspect the current state before applying changes again.

## Working project files

| Location within `project_dir` | Contents |
| --- | --- |
| `images/` | Imported PNG working copies |
| `annotations/` | Current annotation metadata/pointers |
| `history/` | Saved revision masks and metadata |

The project also records source paths, image identities, dimensions, grouping, and import status. Keep the entire working project together when backing up or moving annotations. Do not manually edit revision files while the application is running.

## Dataset snapshots

The dataset command creates a self-contained snapshot containing image copies, masks, and `dataset.json`. Training creates the same kind of snapshot inside its run directory. Only approved revisions are exported.

The manifest includes the label mapping, a dataset fingerprint, and image records with:

- Stable image ID and physical-unit group.
- Relative image and mask paths.
- Native image width and height.
- Approved annotation revision and clean-image status.

Snapshots are independent of subsequent annotation changes. Use a new output folder for each export. Retain the snapshot associated with a result so that a checkpoint can be traced to the exact approved masks used for training.

## Duplicate and group handling

Exact duplicate pixel images are deduplicated on import. Distinct photographs of a physical unit require an explicit `group_regex`; pixel deduplication alone cannot prevent this form of validation leakage. Inspect grouping whenever tray naming or acquisition naming changes.

This version uses a training/validation split for pilot development. It does not establish an independent production acceptance test. Maintain a separate set of newly annotated units for a later evaluation once annotation definitions and model settings stabilize.

## Annotation objects in version 0.2

Revision metadata includes an `objects` array. Each object stores a stable `id`, `name`, tool `kind`, boolean `visible`, and `mask_rle`: a binary (0/1) run-length encoding of its complete native-resolution footprint in row-major order. Previews are generated from these exact footprints; brush strokes and connected automatic proposals also appear in the list.

The union of **all** object footprints defines defect support, including hidden objects. The ROI assigns every supported pixel Inner or Outer. Visibility is only a display property. Deleting an object removes its contribution; overlapping pixels remain if another object still covers them. Erasing edits all intersecting footprints. Empty objects are removed. Saving persists the semantic PNG and object records together.

Version 0.1 stored only a flattened mask, so original drawing gestures cannot be recovered. When opened, connected parts of an old mask become selectable legacy objects; the old immutable revision is retained. Any changed Inner/Outer labels are shown as unsaved changes and stored only with the next save. New closed shapes and brush strokes remain distinct objects in subsequent saves.
