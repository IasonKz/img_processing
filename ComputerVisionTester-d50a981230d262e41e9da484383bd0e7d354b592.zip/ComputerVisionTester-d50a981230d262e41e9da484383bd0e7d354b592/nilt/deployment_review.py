"""Frozen per-unit inspection evidence, comparable distributions and local reports."""
from collections import Counter, defaultdict
from datetime import datetime, timezone
from io import BytesIO
import base64
import csv
import hashlib
import html
import json
import math
from pathlib import Path, PureWindowsPath
import shutil
from zipfile import ZipFile, ZIP_DEFLATED

import numpy as np
from PIL import Image

from .common import EXTENSIONS, read_json, sha_file, write_json
from .inspection_identity import VIEWS, capture_view, physical_unit, roi_crop_sources

FORMAT = "nilt_unit_quality_review_v1"
NOTE = "Scores and pixel probabilities are uncalibrated. Percentiles describe this inspection cohort, not correctness probabilities."


def _now():
    return datetime.now(timezone.utc).isoformat()


def _finite(value):
    try:
        number = float(value)
        return number if math.isfinite(number) else None
    except (ValueError, TypeError):
        return None


def inside(root, relative):
    if not isinstance(relative, str) or not relative or PureWindowsPath(relative).drive or "\\" in relative:
        raise ValueError("Choose a recorded relative evidence path.")
    path = Path(relative)
    candidate = (Path(root) / path).resolve()
    if path.is_absolute() or ".." in path.parts or not candidate.is_relative_to(Path(root).resolve()):
        raise ValueError("Evidence path escapes its inspection folder.")
    if (Path(root) / path).is_symlink():
        raise ValueError("Evidence files cannot be symbolic links.")
    return candidate


class Assets:
    def __init__(self, run, output, stop_check=None):
        self.run, self.output = Path(run).resolve(), Path(output).resolve()
        self.items = {}
        self.stop_check = stop_check

    def check(self):
        if self.stop_check and self.stop_check():
            raise InterruptedError("Quality review stopped; completed inspection records are retained.")

    def add(self, path, kind, expected=None):
        self.check()
        path = Path(path)
        if path.is_symlink() or not path.is_file() or path.suffix.lower() not in EXTENSIONS:
            raise ValueError("Recorded image evidence is missing or unsupported.")
        digest = sha_file(path)
        if expected and digest != expected:
            raise ValueError("Recorded image evidence changed after inference.")
        identity = hashlib.sha256((kind + ":" + digest).encode()).hexdigest()[:24]
        if identity in self.items:
            return identity
        if path.resolve().is_relative_to(self.run):
            target = path.resolve()
        else:
            target = self.output / "assets" / (identity + path.suffix.lower())
            target.parent.mkdir(exist_ok=True)
            with path.open("rb") as original, target.open("xb") as copy:
                while block := original.read(1024 * 1024):
                    self.check()
                    copy.write(block)
            if sha_file(target) != digest or sha_file(path) != digest:
                target.unlink(missing_ok=True)
                raise ValueError("Image evidence changed during snapshot creation.")
        self.items[identity] = {"id": identity, "kind": kind, "path": target.relative_to(self.run).as_posix(),
                                "sha256": digest, "bytes": target.stat().st_size}
        return identity


def score_evidence(row, metadata):
    score = _finite(row.get("bad_score", row.get("score")))
    high = _finite(row.get("bad_threshold", row.get("threshold", metadata.get("bad_threshold", metadata.get("threshold")))))
    low = _finite(row.get("good_threshold", metadata.get("good_threshold")))
    low = high if low is None else low
    prediction = row.get("prediction", row.get("predicted_class"))
    margin = None
    if score is not None:
        if prediction == "good" and low is not None:
            margin = low - score
        elif prediction == "bad" and high is not None:
            margin = score - high
        elif low is not None and high is not None:
            margin = min(abs(score - low), abs(score - high))
    stages = row.get("stage_results") or []
    evaluated = [s for s in stages if s.get("status") in ("ok", "evaluated")]
    voted = [s for s in evaluated if s.get("predicted_class") in ("good", "bad", "review")]
    return {"score": score, "score_type": row.get("score_type", metadata.get("score_type")),
            "good_threshold": low, "bad_threshold": high, "decision_margin": margin,
            "stage_agreement": {"agreeing": sum(s.get("predicted_class") == prediction for s in voted),
                                "decisions": len(voted), "evaluated": len(evaluated), "skipped": len(stages) - len(evaluated)},
            "stage_results": stages, "review_reason": row.get("review_reason"),
            "uncertainty": {key: row[key] for key in ("score_dispersion", "disagreement", "uncertainty") if key in row}}


def _identity(row, origin, context=None):
    source = (context or {}).get("source_image", {})
    return physical_unit(source.get("name") or source.get("path") or row.get("image") or row.get("relative_path", ""),
                         row.get("unit_id") or (context or {}).get("unit_id"),
                         row.get("tray") or (context or {}).get("tray"), origin=origin)


def _attach_roi(item, context, assets):
    if not context:
        return
    item["roi"] = {key: context.get(key) for key in
                   ("roi_id", "kind", "split", "unit_id", "annotation_revision", "template_version", "metadata")}
    source = context.get("source_image", {})
    item["roi"]["geometry"] = next((roi for roi in source.get("annotation", {}).get("rois", [])
                                     if roi.get("id") == context["roi_id"]), None)
    if source.get("path") and source.get("file_checksum"):
        item["assets"].append(assets.add(source["path"], "source", source["file_checksum"]))
    geometry = Path(context["export_root"]) / "crop_masks" / context["kind"] / Path(context["path"]).name
    if geometry.is_file():
        item["assets"].append(assets.add(geometry, "geometry_mask"))
    preview = Path(context["export_root"]) / "annotated_previews" / (context["image_id"] + ".png")
    if preview.is_file():
        item["assets"].append(assets.add(preview, "geometry_overlay"))


def _session_items(session, assets, unit_ids=None):
    from .review import _session, read_records, resolve_review_asset
    session, marker = _session(session)
    metadata = marker.get("metadata", {})
    view = marker.get("task")
    if view not in VIEWS:
        raise ValueError("Classification evidence must identify TOP, BOTTOM or VIG.")
    scope = marker.get("roi_scope", "whole_image")
    source_root = metadata.get("source_input") or metadata.get("input_root")
    context_map = roi_crop_sources(source_root) if scope != "whole_image" and source_root else {}
    for row in read_records(session):
        assets.check()
        candidates = [c for c in context_map.get(Path(row["relative_path"]).name, []) if c.get("sha256") == row.get("file_sha256")]
        context = candidates[0] if len(candidates) == 1 else None
        identity = _identity(row, str(session), context)
        if unit_ids is not None and identity["unit_id"] not in unit_ids:
            continue
        item = {"id": hashlib.sha256((str(session) + row["id"]).encode()).hexdigest()[:24],
                "view": view, "kind": "classification", "scope": scope, "image": row["relative_path"],
                "prediction": row.get("prediction"), "status": row.get("status", "ok"),
                "pipeline": metadata, "evidence": score_evidence(row, metadata), "assets": [], "issues": [],
                "source_sha256": row.get("file_sha256"), "identity": identity}
        try:
            if scope == "whole_image" and capture_view(row["relative_path"], view) != view:
                raise ValueError("Recorded recipe view conflicts with the capture view.")
            if row.get("copied_path"):
                item["assets"].append(assets.add(resolve_review_asset(session, row["id"]),
                                                 "source" if scope == "whole_image" else "crop", row.get("file_sha256")))
            else:
                item["issues"].append("No copied image was recorded for this prediction.")
            _attach_roi(item, context, assets)
        except (OSError, ValueError) as error:
            item["issues"].append(str(error))
            item["status"] = "unavailable"
        yield item


def _segmentation_items(summary_file, assets, unit_ids=None):
    summary_file = Path(summary_file).resolve()
    root = summary_file.parent
    summary = read_json(summary_file)
    if summary.get("status", "completed") != "completed":
        raise ValueError("Choose a completed segmentation prediction.")
    legacy = summary.get("schema") != "topseg_prediction_evidence.v1"
    request_file = root.parent.parent / "jobs" / root.name / "request.json"
    request = read_json(request_file) if legacy and request_file.is_file() else {}
    cfg, payload = request.get("cfg", {}), request.get("payload", {})
    view = summary.get("task") or cfg.get("task")
    input_root = summary.get("input_dir") or payload.get("input_dir")
    if view not in ("top", "bottom") or not input_root:
        raise ValueError("Segmentation output needs a recorded view and input folder.")
    rows = summary.get("images")
    if not isinstance(rows, list):
        with (root / "predictions.csv").open(encoding="utf-8-sig", newline="") as stream:
            rows = list(csv.DictReader(stream))
    context_map = roi_crop_sources(input_root)
    for row in rows:
        assets.check()
        digest = row.get("source_sha256")
        source = inside(root, row["source_image"]) if row.get("source_image") else inside(input_root, row["image"])
        current_digest = sha_file(source) if source.is_file() else None
        candidates = [c for c in context_map.get(Path(row["image"]).name, []) if c.get("sha256") == (digest or current_digest)]
        context = candidates[0] if len(candidates) == 1 else None
        identity = _identity(row, str(root), context)
        if unit_ids is not None and identity["unit_id"] not in unit_ids:
            continue
        scope = (row.get("roi") or {}).get("kind") or summary.get("roi_scope") or (context or {}).get("kind") or "whole_image"
        item = {"id": hashlib.sha256((str(root) + row["image"]).encode()).hexdigest()[:24],
                "view": view, "scope": scope, "kind": "segmentation", "image": row["image"],
                "prediction": None, "status": "ok", "assets": [], "issues": [],
                "source_sha256": digest, "identity": identity,
                "pipeline": {key: summary.get(key) for key in ("checkpoint_sha256", "model_type", "model_definition", "study_name", "trial")},
                "evidence": {"inner_pixels": int(row.get("inner_pixels", 0)), "outer_pixels": int(row.get("outer_pixels", 0)),
                             "width": row.get("width"), "height": row.get("height"), **row.get("pixel_evidence", {})}}
        if legacy:
            item["issues"].append("Legacy prediction: inference-time source hash and pixel probabilities were not recorded.")
        try:
            item["assets"].append(assets.add(source, "source" if scope == "whole_image" else "crop", digest))
            mask_path = inside(root, row["mask"])
            with Image.open(mask_path) as im:
                mask = np.asarray(im)
            with Image.open(source) as im:
                if mask.shape != (im.height, im.width):
                    raise ValueError("Semantic mask dimensions disagree with its inspected image.")
            if mask.ndim != 2 or not np.isin(mask, [0, 1, 2]).all():
                raise ValueError("Semantic mask must contain only background, inner and outer defect IDs.")
            if int((mask == 1).sum()) != item["evidence"]["inner_pixels"] or int((mask == 2).sum()) != item["evidence"]["outer_pixels"]:
                raise ValueError("Recorded defect counts disagree with the saved mask.")
            item["evidence"].update(width=int(mask.shape[1]), height=int(mask.shape[0]), pixels=int(mask.size),
                defect_area_ratio=float((mask != 0).mean()))
            item["assets"].extend([assets.add(mask_path, "mask"), assets.add(inside(root, row["overlay"]), "overlay")])
            if row.get("roi"):
                item["roi"] = row["roi"]
                for field, kind, expected in (("full_image", "source", row["roi"].get("full_image_sha256")),
                                               ("geometry_mask", "geometry_mask", None),
                                               ("geometry_overlay", "geometry_overlay", None)):
                    if row["roi"].get(field):
                        item["assets"].append(assets.add(inside(root, row["roi"][field]), kind, expected))
            else:
                _attach_roi(item, context, assets)
        except (OSError, ValueError) as error:
            item["status"] = "unavailable"
            item["issues"].append(str(error))
        yield item

    for failure in summary.get("failures", []):
        assets.check()
        name = str(failure.get("image", ""))
        path = Path(name)
        if path.is_absolute():
            if not path.is_relative_to(Path(input_root)):
                continue
            name = path.relative_to(input_root).as_posix()
        candidates = [c for c in context_map.get(Path(name).name, [])
                      if not failure.get("source_sha256") or c.get("sha256") == failure["source_sha256"]]
        context = candidates[0] if len(candidates) == 1 else None
        identity = _identity({"image": name}, str(root), context)
        if unit_ids is not None and identity["unit_id"] not in unit_ids:
            continue
        yield {"id": hashlib.sha256((str(root) + ":failed:" + name).encode()).hexdigest()[:24],
               "view": view, "scope": (context or {}).get("kind") or summary.get("roi_scope") or "whole_image",
               "kind": "segmentation", "image": name, "prediction": None, "status": "unavailable",
               "assets": [], "issues": ["Segmentation failed: " + str(failure.get("error", "No output was recorded."))],
               "source_sha256": failure.get("source_sha256"), "identity": identity,
               "pipeline": {key: summary.get(key) for key in ("checkpoint_sha256", "model_type", "model_definition", "study_name", "trial")},
               "evidence": {}}


def _metric_key(item, name, contract=None):
    pipeline = item["pipeline"]
    digest = pipeline.get("checkpoint_sha256") or pipeline.get("decision_sha256") or pipeline.get("workflow_sha256") or pipeline.get("system_sha256")
    contract = contract or {key: item["evidence"].get(key) for key in ("score_type", "good_threshold", "bad_threshold")}
    return hashlib.sha256(json.dumps([item["view"], item["scope"], digest or pipeline, name, contract], sort_keys=True).encode()).hexdigest()[:24]


def add_distributions(units):
    cohorts = defaultdict(dict)
    descriptors = {}
    for key, unit in units.items():
        for item in unit["items"]:
            if item["status"] != "ok":
                continue
            evidence = item["evidence"]
            metrics = [("BAD score", evidence.get("score"), None, "max")] if item["kind"] == "classification" else [
                ("Defect area ratio", evidence.get("defect_area_ratio"), None, "max"),
                ("Mean selected pixel probability", evidence.get("mean_selected_pixel_probability"), None, "min")]
            for stage in evidence.get("stage_results", []):
                if stage.get("status") not in ("ok", "evaluated"):
                    continue
                raw_scale = stage.get("source_threshold") is not None
                contract = {"stage": stage.get("index"), "source": stage.get("decision_sha256") or stage.get("source"),
                    "score_type": stage.get("score_type"),
                    "good_threshold": stage.get("source_threshold") if raw_scale else stage.get("good_threshold", stage.get("threshold")),
                    "bad_threshold": stage.get("source_threshold") if raw_scale else stage.get("bad_threshold", stage.get("threshold"))}
                metrics.append(("Stage " + str(stage.get("name") or stage.get("candidate") or stage.get("index")) + " score",
                                stage.get("raw_score") if raw_scale else stage.get("score"), contract, "max"))
            for name, value, contract, aggregate in metrics:
                value = _finite(value)
                if value is None:
                    continue
                identity = _metric_key(item, name, contract)
                reduce = min if aggregate == "min" else max
                cohorts[identity][key] = reduce(value, cohorts[identity].get(key, value))
                thresholds = contract or evidence
                descriptors[identity] = {"name": name, "view": item["view"], "scope": item["scope"], "pipeline": item["pipeline"],
                    "aggregation": ("Minimum" if aggregate == "min" else "Maximum") + " recorded value per unit; one observation per physical unit.",
                    "good_threshold": thresholds.get("good_threshold"), "bad_threshold": thresholds.get("bad_threshold")}
    distributions = {}
    for identity, values in cohorts.items():
        sample = np.asarray(list(values.values()), dtype=float)
        ordered = np.sort(sample)
        lower, upper = float(sample.min()), float(sample.max())
        if lower == upper:
            lower, upper = lower - .05, upper + .05
        counts, edges = np.histogram(sample, bins=min(20, max(1, int(math.sqrt(len(sample))))), range=(lower, upper))
        distributions[identity] = {**descriptors[identity], "id": identity, "units": len(sample),
            "min": float(sample.min()), "max": float(sample.max()), "mean": float(sample.mean()),
            "median": float(np.median(sample)), "std": float(sample.std()),
            "p05": float(np.quantile(sample, .05)), "p95": float(np.quantile(sample, .95)),
            "bins": [{"low": float(edges[i]), "high": float(edges[i+1]), "count": int(count)} for i, count in enumerate(counts)]}
        for key, value in values.items():
            percentile = 50 * (int(np.searchsorted(ordered, value, side="left")) + int(np.searchsorted(ordered, value, side="right"))) / len(sample)
            units[key]["statistics"].append({"distribution": identity, "value": value, "percentile": percentile})
    return distributions


def build_review(settings, output, stop_check=None):
    run = Path(settings["run"]).resolve()
    output = Path(output).resolve()
    if not output.is_relative_to(run / "quality_review" / "snapshots"):
        raise ValueError("Review snapshots must remain inside the selected inspection run.")
    output.mkdir(parents=True, exist_ok=True)
    report = read_json(run / "report.json")
    if report.get("status") != "completed" or not report.get("session"):
        raise ValueError("Complete the folder inspection before creating its quality review.")
    base = Path(report["session"]).resolve()
    if not base.is_relative_to(run) or not base.is_dir():
        raise ValueError("The deployment session must remain inside its run.")
    assets = Assets(run, output, stop_check)
    units, issues, sources = {}, [], []

    def add(item, primary=False):
        identity = item["identity"]
        key = hashlib.sha256(identity["unit_id"].encode()).hexdigest()[:24]
        if not primary and key not in units:
            return False
        if key not in units:
            units[key] = {**identity, "id": key, "items": [], "statistics": [], "views": {}, "issues": []}
        units[key]["items"].append(item)
        return True

    for item in _session_items(base, assets):
        add(item, True)
    sources.append({"kind": "classification", "path": str(base), "sha256": sha_file(base / "review_session.json")})
    unit_ids = {unit["unit_id"] for unit in units.values()}
    for session in dict.fromkeys(settings.get("sessions", [])):
        if Path(session).resolve() == base:
            continue
        matched = sum(add(item) for item in _session_items(session, assets, unit_ids))
        sources.append({"kind": "classification", "path": str(session), "matched": matched,
                        "sha256": sha_file(Path(session) / "review_session.json")})
        if not matched:
            issues.append("No units from the inspection matched classification session: " + str(session))
    for summary in dict.fromkeys(settings.get("segmentation", [])):
        matched = sum(add(item) for item in _segmentation_items(summary, assets, unit_ids))
        sources.append({"kind": "segmentation", "path": str(summary), "matched": matched, "sha256": sha_file(summary)})
        if not matched:
            issues.append("No units from the inspection matched segmentation output: " + str(summary))
    context_root = Path(settings.get("context_input") or report.get("resolved_input") or report["input"])
    if context_root.is_dir():
        for path in sorted(context_root.rglob("*")):
            assets.check()
            if not path.is_file() or path.suffix.lower() not in EXTENSIONS or path.is_symlink():
                continue
            relative = path.relative_to(context_root)
            if any(part.lower() in ("review", "unsuitable", "_debug", "_review") for part in relative.parts):
                continue
            try:
                view = capture_view(relative)
                identity = physical_unit(relative, origin=str(context_root))
                key = hashlib.sha256(identity["unit_id"].encode()).hexdigest()[:24]
                if view not in VIEWS or key not in units:
                    continue
                digest = sha_file(path)
                if any(item.get("source_sha256") == digest for item in units[key]["items"] if item["view"] == view):
                    continue
                asset = assets.add(path, "source")
                add({"id": hashlib.sha256((str(path) + digest).encode()).hexdigest()[:24], "view": view,
                     "scope": "whole_image", "kind": "image", "image": relative.as_posix(), "identity": identity,
                     "prediction": None, "status": "not_inspected", "assets": [asset], "issues": [],
                     "source_sha256": digest, "pipeline": {}, "evidence": {}})
            except (ValueError, OSError) as error:
                issues.append(str(error))
    distributions = add_distributions(units)
    counts = Counter()
    unit_index = []
    for key, unit in sorted(units.items(), key=lambda pair: (pair[1]["tray"], pair[1].get("row") or 0, pair[1].get("column") or 0, pair[1]["unit_id"])):
        assets.check()
        for view in VIEWS:
            items = [item for item in unit["items"] if item["view"] == view]
            decisions = [item for item in items if item["kind"] == "classification" and item["status"] == "ok"
                         and item["prediction"] in ("good", "bad", "review")]
            predictions = [item["prediction"] for item in decisions]
            uncertain = any(item["status"] not in ("ok", "not_inspected") for item in items)
            complete_view = any(item["scope"] == "whole_image" for item in decisions)
            result = "bad" if "bad" in predictions else "review" if "review" in predictions or uncertain or predictions and not complete_view else "good" if predictions else "not_inspected"
            if predictions and not complete_view:
                unit["issues"].append(view.upper() + " ROI decisions do not define a complete view-quality decision.")
            unit["views"][view] = {"result": result, "images": len(items), "classification": len(predictions),
                                   "segmentation": sum(item["kind"] == "segmentation" and item["status"] == "ok" for item in items)}
        results = [row["result"] for row in unit["views"].values()]
        unit["review_status"] = "bad" if "bad" in results else "good" if all(value == "good" for value in results) and unit["identity_status"] != "unconfirmed" else "review"
        unit["coverage"] = sum(row["classification"] > 0 for row in unit["views"].values())
        counts[unit["review_status"]] += 1
        unit["issues"] = list(dict.fromkeys(unit["issues"] + [message for item in unit["items"] for message in item["issues"]]))
        if unit["identity_status"] == "unconfirmed":
            unit["issues"].append("Physical unit identity is unconfirmed; this capture is not joined to other views.")
        target = output / "units" / (key + ".json")
        write_json(target, unit)
        unit_index.append({**{name: unit[name] for name in ("id", "unit_id", "tray", "row", "column", "identity_status", "views", "coverage", "review_status")},
                           "items": len(unit["items"]), "issues": len(unit["issues"]), "path": target.relative_to(output).as_posix(), "sha256": sha_file(target)})
    index = {"format": FORMAT, "status": "completed", "created_utc": _now(), "run": str(run), "snapshot": output.name,
        "inspection": {key: report.get(key) for key in ("pipeline", "pipeline_sha256", "input", "started_utc", "completed_utc", "counts")},
        "units": unit_index, "counts": dict(counts), "assets": assets.items, "distributions": distributions,
        "sources": sources, "issues": issues, "score_note": NOTE,
        "review_rule": "Any recorded Bad routes to Bad; otherwise incomplete, unavailable or abstaining views route to Review. Good requires quality decisions for TOP, BOTTOM and VIG. Review routing does not qualify a combined production pipeline."}
    write_json(output / "index.json", index)
    write_json(output / "integrity.json", {"sha256": sha_file(output / "index.json")})
    assets.check()
    write_json(run / "quality_review" / "current.json", {"snapshot": output.name, "sha256": sha_file(output / "index.json")})
    write_json(output / "report.json", {"status": "completed", "units": len(unit_index), "counts": dict(counts), "snapshot": output.name})
    print(f"QUALITY_REVIEW: {output}", flush=True)
    return index


def read_index(run, snapshot=None):
    run = Path(run).resolve()
    if snapshot is None:
        marker = read_json(inside(run, "quality_review/current.json"))
        snapshot = marker["snapshot"]
    if not isinstance(snapshot, str) or not snapshot or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-" for c in snapshot):
        raise ValueError("Choose a recorded quality-review snapshot.")
    folder = inside(run, "quality_review/snapshots/" + snapshot)
    path = inside(folder, "index.json")
    if sha_file(path) != read_json(inside(folder, "integrity.json")).get("sha256"):
        raise ValueError("Quality-review index changed. Create a new snapshot.")
    index = read_json(path)
    if index.get("format") != FORMAT or index.get("snapshot") != snapshot:
        raise ValueError("Choose a valid unit quality review.")
    return folder, index


def _read_unit_record(folder, row):
    path = inside(folder, row["path"])
    if sha_file(path) != row["sha256"]:
        raise ValueError("Unit evidence changed. Create a new snapshot.")
    return read_json(path)


def read_unit(run, unit_id, snapshot=None, loaded=None):
    folder, index = loaded if loaded is not None else read_index(run, snapshot)
    row = next((unit for unit in index["units"] if unit["id"] == unit_id), None)
    if row is None:
        raise ValueError("Choose a unit from this inspection.")
    return index, _read_unit_record(folder, row)


def preview_asset(run, index, asset_id, max_size=1600, window=None):
    from .image_io import load_rgb, display_image, window_display
    asset = index["assets"].get(asset_id)
    if asset is None:
        raise ValueError("Choose a recorded image asset.")
    path = inside(run, asset["path"])
    if sha_file(path) != asset["sha256"]:
        raise ValueError("Frozen image evidence changed.")
    if asset["kind"] in ("mask", "geometry_mask"):
        with Image.open(path) as image:
            array = np.asarray(image)
        if array.ndim != 2:
            raise ValueError("Recorded mask is not two-dimensional.")
        colored = np.zeros((*array.shape, 3), dtype=np.uint8)
        if asset["kind"] == "mask":
            colored[array == 1] = (242, 97, 102)
            colored[array == 2] = (57, 173, 234)
        else:
            colored[array != 0] = (59, 204, 184)
        image = Image.fromarray(colored)
    else:
        original = load_rgb(path)
        image = window_display(original, **window) if window is not None else display_image(original)
    image.thumbnail((max_size, max_size))
    buffer = BytesIO()
    image.save(buffer, format="PNG")
    return buffer.getvalue()


def _chart(distribution, value):
    bins = distribution["bins"]
    maximum = max((row["count"] for row in bins), default=1) or 1
    lo, hi = bins[0]["low"], bins[-1]["high"]
    bars = "".join(f'<rect x="{35 + i * 420 / len(bins):.1f}" y="{115 - row["count"] / maximum * 90:.1f}" width="{max(1, 420 / len(bins) - 2):.1f}" height="{row["count"] / maximum * 90:.1f}" fill="#0076bd"/>' for i, row in enumerate(bins))
    x = 35 + min(1, max(0, (value - lo) / (hi - lo))) * 420
    return f'<svg viewBox="0 0 490 150" role="img" aria-label="Unit distribution"><text x="8" y="15" fill="currentColor">Units</text>{bars}<path d="M{x:.1f},20 V118" stroke="#ed9858" stroke-width="3"/><text x="35" y="140" fill="currentColor">{lo:.5g}</text><text x="390" y="140" fill="currentColor">{hi:.5g}</text></svg>'


def render_unit_html(run, index, unit, include_images=True, title="Unit inspection report", stop_check=None, asset_links=None):
    escape = lambda value: html.escape(str(value if value is not None else "Not available"), quote=True)
    parts = [f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{escape(title)}</title><style>body{{font:14px system-ui;background:#0a1421;color:#e0ebf4;max-width:1150px;margin:32px auto;padding:20px}}article,section{{border:1px solid #294057;padding:18px;margin:15px 0;border-radius:6px}}img{{max-width:100%;max-height:600px;object-fit:contain;background:#050b13}}figure{{display:inline-block;width:min(46%,470px);vertical-align:top;margin:10px}}pre{{white-space:pre-wrap;overflow-wrap:anywhere;color:#b1cde0}}small,p{{line-height:1.6}}svg{{max-width:600px;width:100%}}h1,h2,h3{{color:#62b9ec}}@media print{{body{{background:white;color:#162a3c}}section,article{{break-inside:avoid}}pre{{color:#162a3c}}}}@media(max-width:650px){{figure{{width:95%}}}}</style></head><body>',
        f'<h1>NIL Technology · {escape(title)}</h1><h2>{escape(unit["unit_id"])}</h2><p>Tray: {escape(unit["tray"])} · Review routing: <b>{escape(unit["review_status"].upper())}</b> · Views with quality decisions: {unit["coverage"]}/3</p>',
        f'<p>{escape(index["review_rule"])}</p><p>{escape(NOTE)}</p>']
    for view in VIEWS:
        parts.append(f'<section><h2>{view.upper()} · {escape(unit["views"][view]["result"].upper())}</h2>')
        items = [item for item in unit["items"] if item["view"] == view]
        if not items:
            parts.append('<p>No image or model result was linked for this view.</p>')
        for item in items:
            if stop_check and stop_check():
                raise InterruptedError("Report generation stopped.")
            parts.append(f'<article><h3>{escape(item["scope"])} · {escape(item["kind"])} · {escape(item["image"])}</h3><p>Prediction: {escape(item["prediction"])} · Status: {escape(item["status"])}</p>')
            if item["kind"] == "classification":
                labels = (("BAD score", "score"), ("Good below", "good_threshold"), ("Bad at / above", "bad_threshold"), ("Decision margin", "decision_margin"))
            else:
                labels = (("Inner defect pixels", "inner_pixels"), ("Outer defect pixels", "outer_pixels"), ("Defect area ratio", "defect_area_ratio"), ("Mean selected pixel probability", "mean_selected_pixel_probability"))
            if item["kind"] != "image":
                parts.append('<p>' + ' · '.join('<b>' + label + ':</b> ' + escape(item['evidence'].get(field)) for label, field in labels) + '</p>')
            parts.append('<details><summary>Model, decision and ROI provenance</summary><pre>' + escape(json.dumps({"pipeline": item["pipeline"], "decision_evidence": item["evidence"], "roi": item.get("roi"), "source_sha256": item.get("source_sha256"), "issues": item["issues"]}, indent=2, ensure_ascii=False, allow_nan=False)) + '</pre></details>')
            if include_images:
                for asset_id in dict.fromkeys(item["assets"]):
                    if stop_check and stop_check():
                        raise InterruptedError("Report generation stopped.")
                    try:
                        preview = base64.b64encode(preview_asset(run, index, asset_id)).decode()
                        link = f'<a href="{escape(asset_links[asset_id])}">Native evidence</a>' if asset_links and asset_id in asset_links else ""
                        parts.append(f'<figure><img alt="{escape(index["assets"][asset_id]["kind"])}" src="data:image/png;base64,{preview}"><figcaption>{escape(index["assets"][asset_id]["kind"].replace("_", " "))} · {escape(asset_id)} {link}</figcaption></figure>')
                    except (OSError, ValueError) as error:
                        parts.append('<p>Image unavailable: ' + escape(error) + '</p>')
            parts.append('</article>')
        parts.append('</section>')
    parts.append('<section><h2>Position within this inspection</h2>')
    for metric in unit["statistics"]:
        distribution = index["distributions"][metric["distribution"]]
        parts.append(f'<h3>{escape(distribution["view"].upper())} / {escape(distribution["scope"])} · {escape(distribution["name"])}</h3><p>Value: {metric["value"]:.6g} · Percentile: {metric["percentile"]:.2f} · Cohort: {distribution["units"]} units</p>')
        parts.append(_chart(distribution, metric["value"]))
        parts.append('<p>' + escape(distribution["aggregation"]) + '</p>')
    parts.append('<h2>Provenance</h2><pre>' + escape(json.dumps({"snapshot": index["snapshot"], "created_utc": index["created_utc"], "inspection": index["inspection"], "sources": index["sources"], "issues": unit["issues"]}, indent=2, ensure_ascii=False)) + '</pre></section></body></html>')
    return "".join(parts)


def export_review(settings, output, stop_check=None):
    run, output = Path(settings["run"]).resolve(), Path(output).resolve()
    folder, index = read_index(run, settings.get("snapshot"))
    selected = set(settings.get("units", []))
    rows = [row for row in index["units"] if not selected or row["id"] in selected]
    if selected - {row["id"] for row in index["units"]} or not rows:
        raise ValueError("Choose units from the selected inspection snapshot.")
    if not output.is_relative_to(run / "quality_review" / "reports"):
        raise ValueError("Reports must remain inside their inspection run.")
    output.mkdir(parents=True, exist_ok=True)
    html_dir = output / "units"
    html_dir.mkdir(exist_ok=True)
    exported, json_units, csv_rows, exported_assets = [], [], [], {}
    for row in rows:
        if stop_check and stop_check():
            raise InterruptedError("Report generation stopped; finished unit reports are retained.")
        unit = _read_unit_record(folder, row)
        links = {}
        if settings.get("include_images", True):
            for item in unit["items"]:
                for asset_id in item["assets"]:
                    asset = index["assets"][asset_id]
                    source = inside(run, asset["path"])
                    if sha_file(source) != asset["sha256"]:
                        raise ValueError("Native evidence changed after the review snapshot.")
                    target = output / "assets" / (asset_id + source.suffix.lower())
                    target.parent.mkdir(exist_ok=True)
                    if asset_id not in exported_assets:
                        with source.open("rb") as original, target.open("xb") as copy:
                            while block := original.read(1024 * 1024):
                                if stop_check and stop_check():
                                    raise InterruptedError("Report evidence copy stopped.")
                                copy.write(block)
                        if sha_file(target) != asset["sha256"]:
                            raise ValueError("Native evidence changed during report export.")
                        exported_assets[asset_id] = {**asset, "path": target.relative_to(output).as_posix()}
                    links[asset_id] = "../" + exported_assets[asset_id]["path"]
        page = render_unit_html(run, index, unit, settings.get("include_images", True), stop_check=stop_check, asset_links=links)
        file = html_dir / (row["id"] + ".html")
        file.write_text(page, encoding="utf-8")
        exported.append({"unit_id": unit["unit_id"], "html": file.relative_to(output).as_posix()})
        json_units.append(unit)
        for view in VIEWS:
            csv_rows.append({"unit_id": unit["unit_id"], "tray": unit["tray"], "view": view,
                "review_status": unit["review_status"], **unit["views"][view]})
    write_json(output / "evidence.json", {"snapshot": index["snapshot"], "inspection": index["inspection"],
        "distributions": index["distributions"], "units": json_units, "assets": exported_assets, "sources": index["sources"], "score_note": NOTE})
    with (output / "units.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(csv_rows[0]))
        writer.writeheader()
        for row in csv_rows:
            writer.writerow({key: "'" + value if isinstance(value, str) and value.lstrip().startswith(("=", "+", "-", "@")) else value for key, value in row.items()})
    links = "".join(f'<li><a href="{html.escape(row["html"], quote=True)}">{html.escape(row["unit_id"])}</a></li>' for row in exported)
    (output / "report.html").write_text('<!doctype html><html lang="en"><meta charset="utf-8"><title>NILT unit quality review</title><body style="font:16px system-ui;max-width:1000px;margin:40px auto"><h1>NIL Technology · Unit quality review</h1><p>' + html.escape(NOTE) + '</p><ul>' + links + '</ul><p><a href="units.csv">Unit summary CSV</a> · <a href="evidence.json">Complete evidence JSON</a></p></body></html>', encoding="utf-8")
    write_json(output / "integrity.json", {file.relative_to(output).as_posix(): sha_file(file) for file in sorted(output.rglob("*")) if file.is_file()})
    with ZipFile(output / "reports.zip", "w", ZIP_DEFLATED) as zipped:
        for file in sorted(output.rglob("*")):
            if stop_check and stop_check():
                raise InterruptedError("Report archive generation stopped.")
            if file.is_file() and file.name not in ("reports.zip", "report.json"):
                zipped.write(file, file.relative_to(output).as_posix())
    result = {"status": "completed", "created_utc": _now(), "units": len(rows), "snapshot": index["snapshot"],
              "include_images": settings.get("include_images", True), "reports": exported,
              "archive_sha256": sha_file(output / "reports.zip")}
    write_json(output / "report.json", result)
    return result
