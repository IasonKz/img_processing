"""bad is the event of interest, despite its stored class index being zero."""
from __future__ import annotations

import numpy as np
from scipy.stats import beta
from sklearn.metrics import average_precision_score, roc_auc_score


def escape_upper_bound(missed, total, confidence=.95):
    """One-sided Clopper-Pearson bound for a FIXED rule and independent units."""
    if total == 0:
        return None
    if missed == total:
        return 1.0
    return float(beta.ppf(confidence, missed + 1, total - missed))


def check_scores(labels, scores):
    labels, scores = np.asarray(labels), np.asarray(scores, dtype=float)
    if labels.ndim != 1 or scores.ndim != 1:
        raise ValueError("Labels and scores must be one-dimensional.")
    if len(labels) != len(scores) or not len(labels):
        raise ValueError("Empty or mismatched labels/scores.")
    if not np.isin(labels, [0, 1]).all() or not np.isfinite(scores).all():
        raise ValueError("Invalid labels or nonfinite scores.")
    return labels.astype(int), scores


def metrics(labels, scores, threshold, groups=None, confidence=.95):
    labels, scores = check_scores(labels, scores)
    if not np.isscalar(threshold) or not np.isfinite(threshold):
        raise ValueError("Threshold must be a finite scalar.")
    bad = labels == 0
    rejected = scores >= threshold
    tp = int(np.sum(bad & rejected))
    fn = int(np.sum(bad & ~rejected))
    fp = int(np.sum(~bad & rejected))
    tn = int(np.sum(~bad & ~rejected))
    nb, ng = tp + fn, tn + fp
    groups = list(range(len(labels))) if groups is None else list(groups)
    if len(groups) != len(labels) or any(g is None or str(g) == "" for g in groups):
        raise ValueError("Groups must contain one nonempty identifier per image.")
    bad_groups = {}
    for is_bad, is_rejected, group in zip(bad, rejected, groups):
        if is_bad:
            # Conservative unit rule: any bad image of this unit accepted = missed unit.
            bad_groups[group] = bad_groups.get(group, False) or not bool(is_rejected)
    n_units = len(bad_groups)
    missed_units = sum(bad_groups.values())
    return {
        "n_images": len(labels), "n_bad": nb, "n_good": ng,
        "bad_detected_TP": tp, "bad_passed_as_good_FN": fn,
        "good_rejected_as_bad_FP": fp, "good_accepted_TN": tn,
        "bad_escape_rate": fn / nb if nb else None,
        "bad_recall": tp / nb if nb else None,
        "good_reject_rate": fp / ng if ng else None,
        "good_accept_rate": tn / ng if ng else None,
        "accepted_contamination": fn / (fn + tn) if fn + tn else None,
        "bad_precision": tp / (tp + fp) if tp + fp else None,
        "accuracy": (tp + tn) / len(labels),
        "pr_auc_bad": float(average_precision_score(bad, scores)) if nb and ng else None,
        "roc_auc_bad": float(roc_auc_score(bad, scores)) if nb and ng else None,
        "n_bad_units": n_units, "n_escaped_bad_units": missed_units,
        "bad_unit_escape_upper": escape_upper_bound(missed_units, n_units, confidence),
        "confidence": confidence,
    }


def tune_threshold(labels, scores, policy):
    """Largest threshold satisfying empirical FN constraint on threshold split only.

    A grouped sorted scan handles ties exactly and avoids a coarse threshold grid.
    The empirical operating point is fitted here; evidence comes from held-out data.
    """
    labels, scores = check_scores(labels, scores)
    if not 0 <= policy["max_bad_escape_rate"] <= 1:
        raise ValueError("max_bad_escape_rate must be between zero and one.")
    nb, ng = int(np.sum(labels == 0)), int(np.sum(labels == 1))
    if not nb or not ng:
        raise ValueError("Threshold tuning requires both good and bad.")
    values, inv = np.unique(scores, return_inverse=True)
    bad_at = np.bincount(inv, weights=(labels == 0).astype(int))
    good_at = np.bincount(inv, weights=(labels == 1).astype(int))
    # At threshold=v, all scores strictly below v are passed, equal scores rejected.
    fn = np.r_[0, np.cumsum(bad_at)[:-1]]
    fp = ng - np.r_[0, np.cumsum(good_at)[:-1]]
    valid = np.flatnonzero(fn / nb <= policy["max_bad_escape_rate"] + 1e-12)
    index = int(valid[-1])
    if policy.get("threshold_margin", False):
        # Preserve the exact fitted decisions while avoiding a cutoff on an observed score.
        if index > 0:
            return float(values[index - 1] / 2 + values[index] / 2)
        return float(values[0] - max(1e-6, abs(values[0]) * 1e-5))
    return float(values[index])


def empirical_pass(m, policy):
    return (m["bad_escape_rate"] is not None and m["good_reject_rate"] is not None
            and m["bad_escape_rate"] <= policy["max_bad_escape_rate"] + 1e-12
            and m["good_reject_rate"] <= policy["max_good_reject_rate"] + 1e-12)


def evidence_pass(m, policy):
    bound = m["bad_unit_escape_upper"]
    return (empirical_pass(m, policy) and bound is not None
            and bound <= policy["max_bad_escape_rate"])


def selection_key(candidate, policy):
    m = candidate["selection_metrics"]
    # First: actual constraints. Among passing models, retain more good parts.
    # Fallback: fewer escaping defects, then fewer rejected good parts.
    if empirical_pass(m, policy):
        return (0, m["good_reject_rate"], m["bad_escape_rate"],
                -(m["pr_auc_bad"] or 0), len(candidate["members"]), candidate["name"])
    return (1, m["bad_escape_rate"], m["good_reject_rate"],
            -(m["pr_auc_bad"] or 0), len(candidate["members"]), candidate["name"])
