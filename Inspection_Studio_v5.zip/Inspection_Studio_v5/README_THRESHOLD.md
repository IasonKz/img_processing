# Decision and threshold reference

Use **Decision explorer** to compare thresholds on calibration data and save a new decision. The original experiment selection remains unchanged.

| Mode | Behavior |
| --- | --- |
| Automatic policy | Attempts both the bad-escape and good-reject limits |
| Manual threshold | Predicts bad when the bad score is at least the supplied threshold |
| Standard classifier / argmax | Uses the larger supervised class output; binary softmax boundary is 0.5 |
| Scores only | Records scores without good/bad decisions |

Lower thresholds reject more images. Higher thresholds accept more images. Scores are not automatically calibrated defect probabilities. PatchCore uses model-specific anomaly distances, so argmax and a universal 0.5 boundary do not apply.

Save the decision before classifying or adding it to an inspection workflow. A slider preview alone does not modify a saved decision. Different thresholds require separate saved decisions and fresh evaluation of the changed behavior.

See [CLI_REFERENCE.md](docs/CLI_REFERENCE.md), [WORKFLOWS.md](docs/WORKFLOWS.md), and [MODELS_AND_METRICS.md](docs/MODELS_AND_METRICS.md).
