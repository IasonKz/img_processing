from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Iterable, Sequence

import numpy as np
import pandas as pd

from .data import DEFAULT_UNIT_ID_REGEX, canonicalize_unit_id, extract_unit_id


def normalize_column_name(value: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value).lower())


def resolve_column(frame: pd.DataFrame, requested: str) -> str:
    if requested in frame.columns:
        return requested
    normalized = normalize_column_name(requested)
    matches = [column for column in frame.columns if normalize_column_name(column) == normalized]
    if len(matches) == 1:
        return matches[0]
    if not matches:
        raise KeyError(
            f"Column '{requested}' not found. Available columns include: "
            + ", ".join(map(str, frame.columns[:30]))
        )
    raise KeyError(f"Column '{requested}' is ambiguous: {matches}")


def resolve_columns(
    frame: pd.DataFrame,
    *,
    exact_names: Sequence[str] | None,
    regexes: Sequence[str] | None,
) -> list[str]:
    selected: list[str] = []
    for name in exact_names or []:
        column = resolve_column(frame, str(name))
        if column not in selected:
            selected.append(column)

    for pattern in regexes or []:
        compiled = re.compile(str(pattern), flags=re.IGNORECASE)
        for column in frame.columns:
            if compiled.search(str(column)) and column not in selected:
                selected.append(str(column))

    if not selected:
        raise KeyError(
            "No label columns were selected. Set ground_truth.label_columns or "
            "ground_truth.label_column_regexes."
        )
    return selected


def _normalize_label_value(value: Any) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return ""
    text = str(value).strip().strip("'\"").lower()
    return re.sub(r"\s+", " ", text)


def _label_lookup(config: dict[str, Any]) -> dict[str, int]:
    mapping: dict[str, int] = {}
    explicit = config.get("value_mapping", {}) or {}
    for key, value in explicit.items():
        normalized = _normalize_label_value(key)
        label_text = str(value).strip().lower()
        if label_text in {"good", "pass", "p", "0"}:
            mapping[normalized] = 0
        elif label_text in {"bad", "fail", "f", "1"}:
            mapping[normalized] = 1
        else:
            raise ValueError(f"Unsupported mapped label '{value}' for value '{key}'")

    good_values = config.get("good_values", ["p", "pass", "good"])
    bad_values = config.get("bad_values", ["f", "fail", "bad"])
    for value in good_values:
        mapping[_normalize_label_value(value)] = 0
    for value in bad_values:
        mapping[_normalize_label_value(value)] = 1
    return mapping


def combine_row_labels(
    row: pd.Series,
    *,
    columns: Sequence[str],
    config: dict[str, Any],
    lookup: dict[str, int],
) -> tuple[int | None, str]:
    mapped: list[int | None] = []
    raw_values: list[str] = []
    for column in columns:
        raw = _normalize_label_value(row[column])
        raw_values.append(raw)
        mapped.append(lookup.get(raw) if raw else None)

    unknown_values = [raw for raw, value in zip(raw_values, mapped) if raw and value is None]
    if unknown_values:
        return None, f"unknown label value(s): {unknown_values}"

    combine = str(config.get("combine", "any_bad_else_good")).lower()
    missing_policy = str(config.get("missing_label_policy", "skip")).lower()
    available = [value for value in mapped if value is not None]

    if combine == "single":
        if len(columns) != 1:
            raise ValueError("combine=single requires exactly one label column")
        if mapped[0] is None:
            return None, "missing label"
        return int(mapped[0]), ""

    if combine in {"any_bad_else_good", "all_good_else_bad"}:
        if 1 in available:
            return 1, ""
        if missing_policy == "skip" and len(available) != len(columns):
            return None, "one or more labels missing"
        if available and all(value == 0 for value in available):
            return 0, ""
        return None, "no usable label"

    if combine == "majority":
        if missing_policy == "skip" and len(available) != len(columns):
            return None, "one or more labels missing"
        if not available:
            return None, "no usable label"
        bad_count = sum(value == 1 for value in available)
        good_count = sum(value == 0 for value in available)
        if bad_count == good_count:
            return None, "label vote tied"
        return (1 if bad_count > good_count else 0), ""

    raise ValueError(f"Unsupported ground_truth.combine: {combine}")


def load_ground_truth(
    csv_path: str | Path,
    config: dict[str, Any],
) -> tuple[pd.DataFrame, dict[str, Any]]:
    path = Path(csv_path).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"Ground-truth CSV not found: {path}")

    separator = str(config.get("separator", ";"))
    encoding = str(config.get("encoding", "utf-8-sig"))
    frame = pd.read_csv(
        path,
        sep=separator,
        encoding=encoding,
        dtype=str,
        keep_default_na=False,
        engine="python",
    )
    if frame.empty:
        raise ValueError(f"Ground-truth CSV is empty: {path}")

    unit_id_column = resolve_column(frame, str(config.get("unit_id_column", "Unit Identifier")))
    label_columns = resolve_columns(
        frame,
        exact_names=config.get("label_columns", []),
        regexes=config.get("label_column_regexes", []),
    )
    timestamp_column = None
    if config.get("timestamp_column"):
        timestamp_column = resolve_column(frame, str(config["timestamp_column"]))

    lookup = _label_lookup(config)
    unit_pattern = str(config.get("unit_id_regex", DEFAULT_UNIT_ID_REGEX))
    rows: list[dict[str, Any]] = []
    skipped: list[dict[str, Any]] = []

    for index, row in frame.iterrows():
        raw_unit = str(row[unit_id_column]).strip()
        _, canonical = extract_unit_id(raw_unit, unit_pattern)
        true_label, reason = combine_row_labels(
            row,
            columns=label_columns,
            config=config,
            lookup=lookup,
        )
        base = {
            "ground_truth_row": int(index) + 2,
            "unit_id_raw_ground_truth": raw_unit,
            "unit_id": canonical,
            "true_index": true_label,
            "true_label": "" if true_label is None else ("bad" if true_label == 1 else "good"),
            "ground_truth_reason": reason,
        }
        if timestamp_column:
            base["ground_truth_timestamp"] = str(row[timestamp_column]).strip()
        for column in label_columns:
            base[f"ground_truth__{column}"] = row[column]

        if true_label is None or not canonical:
            skipped.append(base)
        else:
            rows.append(base)

    truth = pd.DataFrame(rows)
    skipped_frame = pd.DataFrame(skipped)
    if truth.empty:
        raise ValueError("No usable labeled rows were found in the ground-truth CSV")

    duplicate_policy = str(config.get("duplicate_policy", "latest")).lower()
    duplicate_count = int(truth.duplicated("unit_id", keep=False).sum())
    if duplicate_count:
        if duplicate_policy == "error":
            duplicates = truth[truth.duplicated("unit_id", keep=False)]["unit_id"].unique()
            raise ValueError(f"Duplicate Unit Identifiers in ground truth: {duplicates[:20]}")
        if duplicate_policy == "latest":
            if timestamp_column and "ground_truth_timestamp" in truth.columns:
                truth = truth.sort_values("ground_truth_timestamp").drop_duplicates(
                    "unit_id", keep="last"
                )
            else:
                truth = truth.drop_duplicates("unit_id", keep="last")
        elif duplicate_policy == "first":
            truth = truth.drop_duplicates("unit_id", keep="first")
        else:
            raise ValueError(f"Unsupported duplicate_policy: {duplicate_policy}")

    summary = {
        "csv_path": str(path),
        "rows_total": int(len(frame)),
        "rows_usable": int(len(truth)),
        "rows_skipped": int(len(skipped_frame)),
        "duplicate_rows_detected": duplicate_count,
        "unit_id_column": unit_id_column,
        "label_columns": label_columns,
        "timestamp_column": timestamp_column,
    }
    return truth.reset_index(drop=True), {"summary": summary, "skipped": skipped_frame}
