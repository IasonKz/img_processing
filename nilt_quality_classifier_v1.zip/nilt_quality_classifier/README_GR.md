# Pipeline ταξινόμησης εικόνων GOOD / BAD

Το project είναι έτοιμο για:

- αρχική εκπαίδευση ενός binary classifier από **έναν μόνο φάκελο** που περιέχει `good/` και `bad/`,
- αυτόματο χειρισμό της ανισορροπίας GOOD/BAD,
- επιλογή συντηρητικού threshold ώστε να περιορίζεται το κρίσιμο σφάλμα **πραγματικό BAD → πρόβλεψη GOOD**,
- αναλυτικά metrics, curves, confusion matrices και αντιγραφή των λανθασμένων εικόνων,
- πρόβλεψη σε έναν καινούργιο φάκελο,
- αυτόματη σύγκριση με το `evaluation_results.csv`,
- μελλοντικό fine-tuning με παλιά + νέα δεδομένα χωρίς να αλλάζει ο κώδικας,
- σύγκριση base/candidate μοντέλων πάνω στο ίδιο παγωμένο test set,
- validation-only GPU sweep για ResNet18/34/50 και διαφορετικές αναλύσεις.

## Κρίσιμος ορισμός

Σε όλο το project ισχύει:

```text
GOOD = class 0
BAD  = class 1 = positive class
```

Άρα:

```text
πραγματικό BAD -> πρόβλεψη GOOD = false negative = false pass  [κρίσιμο]
πραγματικό GOOD -> πρόβλεψη BAD = false positive = false reject
```

Ο στόχος που έχει τεθεί στα έτοιμα configs είναι να δεχτούμε περισσότερα false rejects, εφόσον αυτό χρειάζεται για να μειωθούν τα false passes.

---

# 1. Δομή του project

```text
nilt_quality_classifier/
│
├── train.py
├── fine_tune.py
├── predict.py
├── external_test.py
├── evaluate.py
├── compare_models.py
├── prepare_dataset_from_csv.py
├── inspect_dataset.py
├── sweep.py
├── check_gpu.py
│
├── qc/                         # όλος ο κοινός Python κώδικας
│
├── configs/
│   ├── train_top.yaml
│   ├── train_bottom.yaml
│   ├── fine_tune_top.yaml
│   ├── fine_tune_bottom.yaml
│   ├── predict_top.yaml
│   ├── predict_bottom.yaml
│   ├── external_test_top.yaml
│   ├── external_test_bottom.yaml
│   ├── evaluate_top.yaml
│   ├── evaluate_bottom.yaml
│   ├── prepare_top_from_csv.yaml
│   ├── prepare_bottom_from_csv.yaml
│   ├── audit_dataset.yaml
│   ├── compare_models.yaml
│   └── sweep_top.yaml
│
├── requirements.txt
├── setup_windows.ps1
└── setup_after_pytorch.ps1
```

Τα Top και Bottom πρέπει να εκπαιδεύονται ως **δύο ανεξάρτητα μοντέλα**. Ο training κώδικας δεν περιμένει φάκελο `top/` ή `bottom/`. Το YAML δείχνει κάθε φορά στον έναν φάκελο που θέλεις.

---

# 2. Δομή του dataset

Για Top:

```text
C:/.../top_dataset/
├── good/
│   ├── C00000083_Rc01Cc01_....bmp
│   ├── C00000083_Rc01Cc02_....bmp
│   └── ...
└── bad/
    ├── C00000083_Rc03Cc12_....bmp
    └── ...
```

Για Bottom:

```text
C:/.../bottom_dataset/
├── good/
└── bad/
```

Δεν χρειάζεται να φτιάξεις χειροκίνητα `train/validation/test`. Το πρόγραμμα κάνει **group-safe split** και γράφει το αποτέλεσμα στο `split_manifest.csv`.

Το default regex αναγνωρίζει Unit Identifiers όπως:

```text
C00000083_Rc01Cc01
C00000083-Rc01Cc01
```

και τα μετατρέπει στην ίδια canonical μορφή. Όλες οι εικόνες του ίδιου unit πηγαίνουν στο ίδιο split ώστε να μη γίνει data leakage.

---

# 3. Εγκατάσταση σε Windows / PyCharm

Άνοιξε PowerShell μέσα στον φάκελο του project.

## Βήμα 1 — virtual environment

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\setup_windows.ps1
```

Το script δημιουργεί `.venv`, αλλά **δεν επιλέγει μόνο του CUDA build**, επειδή η σωστή εντολή εξαρτάται από την GPU/driver του workstation.

## Βήμα 2 — PyTorch με CUDA

Άνοιξε το επίσημο PyTorch installer selector:

```text
https://pytorch.org/get-started/locally/
```

Επίλεξε:

```text
OS: Windows
Package: Pip
Language: Python
Compute platform: κατάλληλη CUDA επιλογή
```

Τρέξε μέσα στο ενεργό `.venv` την εντολή που εμφανίζει η σελίδα.

## Βήμα 3 — υπόλοιπα packages και έλεγχος GPU

```powershell
.\setup_after_pytorch.ps1
```

ή χειροκίνητα:

```powershell
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python check_gpu.py
```

Το σωστό αποτέλεσμα πρέπει να περιέχει:

```text
CUDA available: True
GPU 0: ...
CUDA calculation succeeded: ...
```

Στο PyCharm όρισε interpreter:

```text
Settings -> Project -> Python Interpreter -> Existing environment
```

και επέλεξε:

```text
<project>/.venv/Scripts/python.exe
```

---

# 4. Πρώτα κάνε audit του dataset

Άλλαξε στο `configs/audit_dataset.yaml` μόνο:

```yaml
audit:
  dataset_root: "C:/.../top_dataset"
  output_folder: "C:/.../top_dataset_audit"
```

Μετά:

```powershell
python inspect_dataset.py --config configs/audit_dataset.yaml
```

Θα πάρεις:

```text
dataset_audit/
├── audit_summary.json
├── image_audit.csv
├── dimension_counts.csv
├── exact_duplicates.csv
├── CRITICAL_duplicates_across_good_bad.csv
└── unreadable_images.csv
```

Έλεγξε ιδιαίτερα:

- αν υπάρχουν unreadable εικόνες,
- αν υπάρχουν ακριβώς ίδιες εικόνες και στα `good/` και στα `bad/`,
- αν ανακατεύονται διαφορετικές αναλύσεις ή bit depths,
- αν οι εικόνες έχουν σωστό crop και σταθερό preprocessing.

Αν υπάρχει `CRITICAL_duplicates_across_good_bad.csv`, διόρθωσε πρώτα τα labels. Ένα δίκτυο δεν μπορεί να μάθει όταν η ακριβώς ίδια εικόνα δηλώνεται και GOOD και BAD.

---

# 5. Αρχική εκπαίδευση

Άνοιξε `configs/train_top.yaml` ή `configs/train_bottom.yaml`.

Οι δύο βασικές γραμμές που πρέπει να αλλάξεις είναι:

```yaml
project:
  output_root: "C:/.../quality_classifier_runs"

data:
  root: "C:/.../top_dataset"
```

Μετά:

```powershell
python train.py --config configs/train_top.yaml
```

ή:

```powershell
python train.py --config configs/train_bottom.yaml
```

## Τι κάνει αυτόματα

1. Διαβάζει μόνο `good/` και `bad/`.
2. Βρίσκει τα Unit Identifiers από τα filenames.
3. Φτιάχνει train/validation/test χωρίς να μοιράζει το ίδιο unit σε διαφορετικά splits.
4. Υπολογίζει class weights μόνο από το train split.
5. Φορτώνει pretrained ResNet.
6. Εκπαιδεύει αρχικά το head και μετά κάνει fine-tuning του backbone.
7. Χρησιμοποιεί GPU και mixed precision όταν υπάρχει CUDA.
8. Κρατά το καλύτερο checkpoint με βάση validation average precision.
9. Διαλέγει threshold αποκλειστικά από το validation set.
10. Κάνει την τελική αξιολόγηση στο frozen test set.

## Για το 85% GOOD / 15% BAD

Το config έχει:

```yaml
loss:
  type: weighted_cross_entropy
  class_weights:
    enabled: true
```

Τα weights υπολογίζονται αυτόματα από τα πραγματικά counts. Δεν χρειάζεται να γράψεις εσύ αριθμούς.

Το oversampling είναι αρχικά κλειστό:

```yaml
training:
  sampler:
    enabled: false
```

Αυτό είναι σκόπιμο. Ξεκίνα με weighted loss και safety threshold. Oversampling ή focal loss αξίζει να δοκιμαστεί αργότερα μόνο αν τα validation errors δείχνουν ότι χρειάζεται.

## Safety threshold

Το config έχει:

```yaml
threshold:
  target_bad_recall: 0.99
  max_false_pass_rate: 0.01
```

Το πρόγραμμα αναζητά το υψηλότερο threshold που ικανοποιεί τον στόχο BAD recall στο validation set. Το υψηλότερο επιτρεπτό threshold συνήθως κρατά καλύτερο GOOD yield χωρίς να παραβιάζει τον στόχο ασφαλείας.

Το threshold δεν επιλέγεται από το test set.

---

# 6. Αποτελέσματα κάθε run

Κάθε run δημιουργεί νέο timestamped φάκελο:

```text
quality_classifier_runs/
└── top_resnet18_v1_20260904_120000/
    ├── best_model.pt
    ├── last_model.pt
    ├── MODEL_REPORT.md
    ├── run_summary.json
    ├── config_resolved.yaml
    ├── split_manifest.csv
    ├── split_counts.json
    ├── class_weights.json
    ├── history.csv
    ├── training_history.png
    ├── run.log
    │
    ├── validation/
    │   ├── validation_predictions.csv
    │   ├── validation_metrics.json
    │   ├── validation_confusion_matrix.png
    │   ├── validation_precision_recall_curve.png
    │   ├── validation_roc_curve.png
    │   ├── validation_threshold_sweep.csv
    │   ├── validation_threshold_tradeoff.png
    │   └── validation_misclassified/
    │
    └── test/
        ├── test_predictions.csv
        ├── test_metrics.json
        ├── test_confusion_matrix.png
        ├── test_precision_recall_curve.png
        ├── test_roc_curve.png
        ├── test_threshold_sweep.csv
        ├── test_threshold_tradeoff.png
        └── test_misclassified/
            ├── false_pass/
            └── false_reject/
```

Το πρώτο αρχείο που ανοίγεις είναι:

```text
MODEL_REPORT.md
```

Το πιο σημαντικό metric είναι:

```text
false_pass = πραγματικό BAD που προβλέφθηκε GOOD
false_pass_rate = false_pass / όλα τα πραγματικά BAD
bad_recall = 1 - false_pass_rate
```

Το `accuracy` μόνο του δεν είναι αρκετό. Με 85% GOOD, ένα άχρηστο μοντέλο που προβλέπει πάντα GOOD θα έχει ήδη 85% accuracy.

## Σημαντική στατιστική προσοχή

Αν το test set έχει μόνο 10 ή 20 BAD εικόνες, ακόμα και μηδέν false passes δεν αποδεικνύει αξιόπιστα false-pass rate κάτω από 1%. Για σοβαρό production claim χρειάζεσαι αρκετά ανεξάρτητα BAD units και ιδανικά εντελώς νέα trays/runs.

---

# 7. Πρόβλεψη σε καινούργιο φάκελο

Άλλαξε στο `configs/predict_top.yaml`:

```yaml
inference:
  checkpoint: "C:/.../best_model.pt"
  input_folder: "C:/.../new_top_images"
```

Μετά:

```powershell
python predict.py --config configs/predict_top.yaml
```

Παράγει:

```text
predictions/
├── predictions.csv
├── prediction_summary.json
├── predicted_good/
├── predicted_bad/
└── uncertain_cases/
```

Το `predictions.csv` περιέχει:

```text
path
filename
unit_id
p_good
p_bad
threshold_bad
predicted_label
decision
```

Το `p_bad` είναι score του μοντέλου. Δεν πρέπει να ερμηνεύεται ως εγγυημένη φυσική πιθανότητα defect χωρίς ξεχωριστό calibration/validation.

## Προαιρετικό REVIEW

Στο prediction config μπορείς να ενεργοποιήσεις:

```yaml
review:
  enabled: true
  good_max_p_bad: 0.10
  bad_min_p_bad: null
```

Τότε:

```text
p_bad <= good_max       -> GOOD / release
ενδιάμεση περιοχή       -> REVIEW / hold
p_bad >= bad_min        -> BAD / hold
```

Το `bad_min_p_bad: null` χρησιμοποιεί το threshold του checkpoint. Οι αριθμοί της review ζώνης πρέπει να εγκριθούν από validation δεδομένα· δεν είναι universal constants.

---

# 8. Ένα command για νέο folder + evaluation_results.csv

Αυτό είναι το πιο πρακτικό production-style test.

Άλλαξε στο `configs/external_test_bottom.yaml`:

```yaml
inference:
  checkpoint: "C:/.../best_model.pt"
  input_folder: "C:/.../new_bottom_images_C00000084"

ground_truth:
  csv_path: "C:/.../C00000084/EvaluationResults/vi_top_bot/evaluation_results.csv"
```

Μετά:

```powershell
python external_test.py --config configs/external_test_bottom.yaml
```

Για Top:

```powershell
python external_test.py --config configs/external_test_top.yaml
```

Το command:

1. κάνει prediction σε όλες τις νέες εικόνες,
2. εξάγει Unit Identifier από filename,
3. διαβάζει το semicolon-separated `evaluation_results.csv`,
4. ενώνει `C..._Rc...Cc...` και `C...-Rc...Cc...` σωστά,
5. μετατρέπει `p/pass/good -> GOOD` και `f/fail/bad -> BAD`,
6. συγκρίνει prediction και ground truth,
7. δημιουργεί metrics, plots, false-pass και false-reject folders.

## Bottom labels

Το έτοιμο config χρησιμοποιεί:

```yaml
label_columns: ["Quality_VI_Bottom_Label"]
combine: single
```

## Top labels

Το έτοιμο config βρίσκει όλες τις Top label columns:

```yaml
label_column_regexes: ["^Quality_VI_Top_.*_Label$"]
combine: any_bad_else_good
```

Άρα:

```text
αν οποιοδήποτε Top label είναι fail -> συνολικό BAD
αν όλα είναι pass                -> συνολικό GOOD
```

Αν το πραγματικό business rule είναι διαφορετικό, άλλαξε μόνο το YAML. Ο κώδικας υποστηρίζει επίσης `single` και `majority`.

---

# 9. Μόνο αξιολόγηση ενός υπάρχοντος predictions.csv

```powershell
python evaluate.py --config configs/evaluate_bottom.yaml
```

ή:

```powershell
python evaluate.py --config configs/evaluate_top.yaml
```

Χρήσιμο όταν έχεις ήδη κάνει prediction και δεν θέλεις να ξανατρέξεις το μοντέλο.

Τα unmatched IDs γράφονται σε:

```text
unmatched_predictions.csv
unmatched_ground_truth.csv
```

Αν δεν γίνει κανένα match, έλεγξε πρώτα το `unit_id_regex` και το πραγματικό filename.

---

# 10. Δημιουργία good/bad dataset κατευθείαν από evaluation_results.csv

Για Bottom:

```powershell
python prepare_dataset_from_csv.py --config configs/prepare_bottom_from_csv.yaml
```

Για Top:

```powershell
python prepare_dataset_from_csv.py --config configs/prepare_top_from_csv.yaml
```

Το utility:

- διαβάζει labels,
- διαβάζει τις `..._Sources` columns,
- εφαρμόζει path replacements αν το CSV δημιουργήθηκε σε άλλο machine/user path,
- βρίσκει fallback εικόνες μέσα στο `MeasurementData/Results`,
- αντιγράφει τις εικόνες σε νέο `good/` ή `bad/`,
- δεν τροποποιεί τις originals,
- γράφει `prepared_manifest.csv`, `missing_images.csv` και `skipped_labels.csv`.

Για Bottom το έτοιμο config ψάχνει source path που περιέχει:

```text
ViBottomPostTarget
```

Για Top:

```text
ViTopFinal
```

Επιβεβαίωσε ότι αυτά είναι τα σωστά image types πριν χρησιμοποιήσεις το dataset για training.

---

# 11. Fine-tuning όταν έρθουν νέα δεδομένα

Μην εκπαιδεύεις το παλιό μοντέλο μόνο στα νέα δεδομένα. Αυτό μπορεί να προκαλέσει catastrophic forgetting.

Η σωστή δομή είναι:

```text
παλιό train split + νέο verified train split
                    ↓
            load old best_model.pt
                    ↓
              low-LR fine-tuning
                    ↓
               candidate model
```

Φτιάξε:

```text
C:/.../top_new_verified/
├── good/
└── bad/
```

Άλλαξε στο `configs/fine_tune_top.yaml`:

```yaml
fine_tune:
  base_checkpoint: "C:/.../old_run/best_model.pt"
  new_dataset_root: "C:/.../top_new_verified"
  new_source_name: "top_new_2026_10"
```

Μετά:

```powershell
python fine_tune.py --config configs/fine_tune_top.yaml
```

Το fine-tuning:

- φορτώνει το παλιό split manifest,
- κρατά αμετάβλητα τα παλιά validation/test assignments,
- βάζει νέο image του ήδη γνωστού Unit Identifier στο ίδιο split,
- κάνει group-safe split μόνο για εντελώς νέα units,
- κρατά όλο το παλιό train set,
- δίνει ελαφρώς μεγαλύτερη sampling πιθανότητα στα νέα data,
- χρησιμοποιεί μικρότερο learning rate,
- δημιουργεί νέο candidate checkpoint,
- συγκρίνει αυτόματα base και candidate στο **παλιό frozen test set**.

Τα αποτελέσματα της αυτόματης σύγκρισης είναι:

```text
new_run/legacy_test_comparison/
├── model_metrics.csv
├── side_by_side_predictions.csv
├── promotion_decision.json
└── comparison_summary.json
```

Το candidate δεν αντικαθιστά αυτόματα το base model.

---

# 12. Κανόνες promotion candidate model

Στο fine-tune/compare config υπάρχουν:

```yaml
promotion_rules:
  min_bad_recall: 0.99
  max_false_pass_rate: 0.01
  must_not_increase_false_pass_count: true
  max_false_reject_rate_increase: 0.05
  min_average_precision_delta: -0.01
```

Το `promotion_decision.json` δίνει:

```text
promote_candidate: true/false
reasons: [...]
```

Αυτό είναι safeguard, όχι τελική επιχειρηματική έγκριση. Η αποδοχή μοντέλου πρέπει να λαμβάνει υπόψη τον αριθμό BAD test units, το κόστος false reject και αλλαγές σε trays/illumination/process.

---

# 13. Χειροκίνητη σύγκριση δύο μοντέλων

Άλλαξε paths στο `configs/compare_models.yaml` και τρέξε:

```powershell
python compare_models.py --config configs/compare_models.yaml
```

Πάντα χρησιμοποίησε το `split_manifest.csv` του αρχικού/base run για frozen benchmark.

---

# 14. GPU hyperparameter sweep

Το `configs/sweep_top.yaml` έχει 12 validation-only experiments:

```text
ResNet18 / ResNet34 / ResNet50
×
384 / 512 input size
×
1e-4 / 3e-4 learning rate
```

Τρέξε:

```powershell
python sweep.py --config configs/sweep_top.yaml
```

Παράγει:

```text
quality_classifier_sweeps/
└── top_gpu_sweep_.../
    ├── shared_split_manifest.csv
    ├── leaderboard.csv
    ├── best_validation_experiment.json
    └── runs/
```

Το leaderboard ταξινομείται πρώτα με βάση validation false passes, μετά false rejects και μετά average precision.

**Μην επιλέγεις architecture/hyperparameters κοιτώντας επανειλημμένα το test set.** Το sweep απενεργοποιεί αυτόματα το test evaluation. Αφού επιλέξεις τη ρύθμιση από validation, πέρασέ τη στο κανονικό `train_top.yaml` και κάνε ένα τελικό run με:

```yaml
evaluation:
  evaluate_test: true
```

---

# 15. Πώς αξιοποιείς τα uncertain και τα λάθη

Μετά από κάθε external test, έλεγξε κυρίως:

```text
false_pass/       # πραγματικά BAD που θα περνούσαν
false_reject/     # πραγματικά GOOD που κρατήθηκαν
uncertain_cases/  # scores κοντά στο threshold
```

Το καλύτερο νέο training data συνήθως είναι:

- τα confirmed false passes,
- τα confirmed false rejects,
- τα low-confidence/borderline cases,
- νέα defect types,
- νέα trays ή illumination/process conditions.

Μετά από ανθρώπινο έλεγχο, βάλε τα verified images σε νέο `good/` και `bad/` dataset και χρησιμοποίησε `fine_tune.py`.

Μην προσθέτεις predictions ως labels χωρίς manual ή αξιόπιστο ground-truth verification. Διαφορετικά το μοντέλο μπορεί να εκπαιδεύεται πάνω στα δικά του λάθη.

---

# 16. Τι να αλλάξεις ανάλογα με τη GPU

Ξεκίνα με:

```yaml
data:
  input_size: 512
training:
  batch_size: 16
model:
  architecture: resnet18
```

Αν πάρεις CUDA out-of-memory:

```yaml
batch_size: 8
```

και μετά, αν χρειάζεται:

```yaml
input_size: 384
```

Αν υπάρχει αρκετή VRAM, δοκίμασε μέσω sweep:

```text
ResNet34
ResNet50
512×512
```

Με μικρό dataset, μεγαλύτερο δίκτυο δεν εγγυάται καλύτερη γενίκευση. Για μικροσκοπικά defects, η αύξηση input resolution συχνά είναι πιο ουσιαστική από την αύξηση του βάθους του ResNet.

---

# 17. 16-bit εικόνες

Το default config χρησιμοποιεί:

```yaml
uint16_scaling: fixed
fixed_min: 0
fixed_max: 65535
```

Αυτό κρατά σταθερή χαρτογράφηση έντασης μεταξύ εικόνων. Αν το audit/visual inspection δείξει ότι οι εικόνες γίνονται σχεδόν μαύρες επειδή χρησιμοποιούν μικρό τμήμα του 16-bit range, δοκίμασε:

```yaml
uint16_scaling: percentile
lower_percentile: 0.5
upper_percentile: 99.5
```

Όμως η per-image percentile scaling μπορεί να αλλάξει τη σχετική ένταση των defects. Σύγκρινε τις δύο επιλογές πάνω σε fixed validation set και κράτησε μία σταθερή επιλογή για training και inference. Το checkpoint αποθηκεύει το preprocessing ώστε τα νέα predictions να χρησιμοποιούν ακριβώς την ίδια ρύθμιση.

---

# 18. Τα configs που πιθανότατα θα χρησιμοποιείς καθημερινά

```text
1. configs/audit_dataset.yaml
2. configs/train_top.yaml ή train_bottom.yaml
3. configs/external_test_top.yaml ή external_test_bottom.yaml
4. configs/fine_tune_top.yaml ή fine_tune_bottom.yaml
5. configs/compare_models.yaml
6. configs/sweep_top.yaml, μόνο για controlled experiments
```

---

# 19. Συχνά προβλήματα

## `CUDA available: False`

Έχει εγκατασταθεί CPU-only PyTorch ή υπάρχει πρόβλημα driver/build. Επανέλαβε την εγκατάσταση από τον επίσημο PyTorch selector και ξανατρέξε:

```powershell
python check_gpu.py
```

## `CUDA out of memory`

Μείωσε πρώτα `batch_size`, μετά `input_size`. Κλείσε άλλα GPU processes.

## `The same Unit Identifier appears with both GOOD and BAD labels`

Το ίδιο unit βρέθηκε και στους δύο φακέλους. Έλεγξε το label ή το regex. Το πρόγραμμα σταματά σκόπιμα αντί να δημιουργήσει leakage/contradictory labels.

## `No predictions matched the ground-truth Unit Identifiers`

Άνοιξε `predictions.csv` και `evaluation_results.csv`. Έλεγξε αν το identifier έχει μορφή `C...Rc...Cc...` και προσαρμόσε `unit_id_regex`.

## `Column ... not found`

Το πραγματικό CSV έχει διαφορετικό header. Άνοιξε την πρώτη γραμμή και άλλαξε `label_columns` ή χρησιμοποίησε `label_column_regexes`.

## Training πολύ αργό

Έλεγξε ότι:

```text
CUDA available: True
training.device: auto
mixed_precision: true
```

Έλεγξε επίσης αν το dataset βρίσκεται σε αργό network drive. Για Windows, αν οι workers προκαλούν πρόβλημα, βάλε προσωρινά:

```yaml
num_workers: 0
persistent_workers: false
```

## Validation BAD recall 100% αλλά πολλά false rejects

Το safety threshold είναι πολύ συντηρητικό ή το μοντέλο δεν διαχωρίζει καλά τις κλάσεις. Κοίτα PR curve, threshold trade-off και misclassified images. Μην αυξήσεις απλώς το threshold χωρίς να ελέγξεις πόσα BAD θα περάσουν.

---

# 20. Προτεινόμενη πραγματική ροή εργασίας

```text
Top model:
    audit dataset
        -> initial train
        -> inspect false passes
        -> external tray test
        -> human verification
        -> collect difficult verified cases
        -> fine-tune candidate
        -> compare on frozen legacy test
        -> external test on a still-fresh tray
        -> approve/reject candidate

Bottom model:
    η ίδια ανεξάρτητη διαδικασία
```

Μην χρησιμοποιήσεις το ίδιο fresh tray επανειλημμένα για threshold/hyperparameter decisions και μετά το παρουσιάσεις ως ανεξάρτητο test. Μόλις επηρεάσει αποφάσεις, λειτουργεί ουσιαστικά ως validation data.
