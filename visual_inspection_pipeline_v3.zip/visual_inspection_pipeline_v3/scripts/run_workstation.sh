#!/usr/bin/env bash
set -euo pipefail
inspection_project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd -- "$inspection_project_dir"
exec python inspection.py run --config project.yaml --profile workstation "$@"
