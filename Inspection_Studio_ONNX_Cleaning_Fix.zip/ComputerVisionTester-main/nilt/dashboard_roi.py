"""Local ROI projects and durable workers, mounted in the existing dashboard."""
from __future__ import annotations

from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
import copy
import json
import os
import subprocess
import sys
import time

from .common import read_json, write_json


ACTIVE = {"starting", "running", "unverified"}


class ROIDashboardMixin:
    @property
    def roi_root(self):
        return self.config.parent / "roi_detection"

    @staticmethod
    def _roi_side(data):
        side = data.get("side", "top")
        if side not in ("top", "bottom"):
            raise ValueError("ROI Detection supports TOP and BOTTOM.")
        return side

    def roi_project(self, data):
        from .roi.project import ROIProject
        return ROIProject(self.roi_root, self._roi_side(data))

    def roi_state(self, data):
        with self.lock:
            result = self.roi_project(data).state()
            result["job"] = self.roi_job(data)["job"]
            models_root = self.roi_root / self._roi_side(data) / "models"
            experiments = []
            if models_root.is_dir():
                for directory in sorted(models_root.iterdir(), reverse=True):
                    if not directory.is_dir() or directory.is_symlink():
                        continue
                    record = {"id": directory.name, "path": str(directory), "model_path": str(directory / "best.pt")}
                    for name, key in (("status.json", "status"), ("model.json", "config"), ("history.json", "history")):
                        if (directory / name).is_file():
                            record[key] = read_json(directory / name)
                    experiments.append(record)
            result["experiments"] = experiments[:100]
            return result

    def roi_job(self, data):
        side = self._roi_side(data)
        pointer = self.roi_root / side / "last_job.json"
        if not pointer.is_file():
            return {"job": {"status": "idle", "side": side}}
        job = read_json(pointer)
        job_id = job.get("id", "")
        if not isinstance(job_id, str) or not job_id or any(c not in "0123456789TZ_-" for c in job_id):
            raise ValueError("Invalid recorded ROI job.")
        job_dir = self.roi_root / "jobs" / job_id
        status_path = Path(job["output"]) / "status.json"
        if not status_path.resolve().is_relative_to(self.roi_root.resolve()):
            raise ValueError("Invalid recorded ROI output.")
        if status_path.is_file():
            status = read_json(status_path)
            job.update({k: v for k, v in status.items() if k not in ("id", "side", "action", "output", "command", "pid", "process_created")})
        process = getattr(self, "_roi_processes", {}).get(job_id)
        if job.get("status") in ACTIVE:
            exit_code = process.poll() if process is not None else None
            if process is not None and exit_code is not None:
                # The worker may have atomically committed completion just after
                # the first status read; observe that commit before reporting failure.
                final = read_json(status_path) if status_path.is_file() else {}
                if final.get("status") not in ACTIVE and final.get("status"):
                    job.update(final)
                else:
                    job.update(status="failed", error=f"ROI worker exited ({exit_code}) without a completed status.")
            elif process is None:
                try:
                    import psutil
                    proc = psutil.Process(job["pid"])
                    verified = (job.get("process_created") is not None and
                                abs(proc.create_time() - job["process_created"]) < .01 and
                                proc.cmdline() == job.get("command"))
                    if not verified:
                        job.update(status="unverified", message="Worker ownership could not be verified; waiting for its recorded status.")
                except Exception:
                    job.update(status="interrupted", error="The ROI worker is no longer running. Saved annotations and previous exports are retained.")
        log = job_dir / "worker.log"
        if log.is_file():
            with log.open("rb") as handle:
                handle.seek(max(0, log.stat().st_size - 8000))
                job["lines"] = handle.read().decode("utf-8", "replace").splitlines()[-25:]
        if job.get("action") == "train" and job.get("status") == "completed":
            job["model_path"] = str(Path(job["output"]) / "best.pt")
        return {"job": job}

    def roi_busy(self):
        return any(self.roi_job({"side": side})["job"].get("status") in ACTIVE for side in ("top", "bottom"))

    def roi_mutate(self, action, data):
        if action not in ("template", "annotation"):
            raise ValueError("Unsupported ROI edit.")
        with self.lock:
            self._idle_for_dataset_edit()
            if self.roi_busy():
                raise ValueError("Wait for the ROI operation to finish before editing annotations.")
            project = self.roi_project(data)
            return getattr(project, "save_" + action)(data)

    def roi_start(self, action, data):
        if action not in ("import", "localize", "export", "train", "evaluate"):
            raise ValueError("Unsupported ROI operation.")
        side = self._roi_side(data)
        with self.lock:
            self._idle_for_dataset_edit()
            if self.roi_busy():
                raise ValueError("An ROI operation is already running.")
            # Initial validation also creates the project before spawning.
            self.roi_project(data)
            job_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%f")
            job_dir = self.roi_root / "jobs" / job_id
            job_dir.mkdir(parents=True)
            output = self.roi_root / side / ("models" if action == "train" else "evaluations") / job_id if action in ("train", "evaluate") else job_dir
            output.mkdir(parents=True, exist_ok=True)
            payload = copy.deepcopy(data)
            request = {"action": action, "root": str(self.roi_root), "side": side,
                       "payload": payload, "output": str(output)}
            module = "nilt.roi.task_worker"
            if action in ("train", "evaluate"):
                dataset_value = payload.get("dataset", "")
                if not isinstance(dataset_value, str) or not dataset_value.strip():
                    raise ValueError("Export and select an ROI segmentation dataset first.")
                dataset = self._configured_path(dataset_value)
                if not (dataset / "manifest.json").is_file():
                    raise ValueError("The segmentation dataset needs manifest.json.")
                manifest = read_json(dataset / "manifest.json")
                if manifest.get("side") != side:
                    raise ValueError("The segmentation dataset belongs to a different view.")
                request.update(dataset=str(dataset), options={**payload.get("options", {}), **{
                    k: payload[k] for k in ("epochs", "image_size", "batch_size", "device", "learning_rate", "cpu_threads") if k in payload}})
                if "size" in payload:
                    request["options"]["image_size"] = payload["size"]
                if action == "evaluate":
                    model_value = payload.get("model_path", "")
                    if not isinstance(model_value, str) or not model_value.strip():
                        raise ValueError("Select a trained ROI segmentation model first.")
                    request["model_path"] = str(self._configured_path(model_value))
                module = "nilt.roi.worker"
            request_path = job_dir / "request.json"
            write_json(request_path, request)
            command = [sys.executable, "-u", "-m", module, "--request", str(request_path)]
            job = {"id": job_id, "side": side, "action": action, "status": "starting", "started": time.time(),
                   "output": str(output), "command": command, "message": "Starting ROI operation"}
            write_json(output / "status.json", {"status": "starting", "message": job["message"]})
            kwargs = {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt" else {"start_new_session": True}
            with (job_dir / "worker.log").open("w", encoding="utf-8") as log:
                process = subprocess.Popen(command, cwd=str(Path(__file__).resolve().parent.parent),
                                           stdout=log, stderr=subprocess.STDOUT, **kwargs)
            job["pid"] = process.pid
            try:
                import psutil
                job["process_created"] = psutil.Process(process.pid).create_time()
            except Exception:
                job["process_created"] = None
            if not hasattr(self, "_roi_processes"):
                self._roi_processes = {}
            self._roi_processes[job_id] = process
            write_json(self.roi_root / side / "last_job.json", job)
            if self.roi_root not in self.output_roots:
                self.output_roots.append(self.roi_root)
            return {"job": job}

    def roi_stop(self, data):
        with self.lock:
            job = self.roi_job(data)["job"]
            if job.get("status") in ACTIVE:
                (Path(job["output"]) / "STOP").touch()
                return {"message": "Stop requested. The current image or training batch will finish; saved progress is retained."}
            return {"message": "No ROI operation is running."}

    def roi_image(self, data, crop=False, info=False):
        from .image_io import load_rgb, display_image, display_statistics, window_display, NativeImage
        project = self.roi_project(data)
        image_id = data.get("id", data.get("image_id", ""))
        path = project.image_path(image_id)
        if crop:
            import numpy as np
            from PIL import Image
            from .roi.crops import crop_roi
            image = next(row for row in project.data["images"] if row["id"] == image_id or row.get("image_id") == image_id)
            annotation = image.get("annotation", {})
            rois = annotation.get("rois", image.get("rois", []))
            roi = next((r for r in rois if r["id"] == data.get("roi")), None)
            if roi is None:
                raise ValueError("Localize this image before previewing its crops.")
            pixels, _, _ = crop_roi(path, roi, settings=project.data.get("crop_settings", {}), transform=annotation.get("transform"))
            if pixels.dtype == np.uint16:
                image = NativeImage(pixels)
            else:
                image = Image.fromarray(pixels)
        else:
            image = load_rgb(path)
        if info:
            return display_statistics(image)
        preview = window_display(image, data.get("black", "min"), data.get("white", "max")) if data.get("window") == "1" else display_image(image)
        buffer = BytesIO()
        preview.save(buffer, format="PNG")
        return buffer.getvalue()

    def roi_classification(self, data):
        from .roi.classification import configure_classification
        with self.lock:
            self._idle_for_dataset_edit()
            return configure_classification(self, data)
