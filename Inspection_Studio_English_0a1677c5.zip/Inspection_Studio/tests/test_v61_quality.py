import csv
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from nilt.quality import build_quality_report


class QualityReportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def save(self, root, name, value):
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value), encoding="utf-8")
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def run_data(self, name="run1", task="vig"):
        root = self.root / name
        root.mkdir()
        cfg_sha = self.save(root, "config.json", {"task": task, "dataset_fingerprint": "recorded-dataset-fingerprint",
                                                 "intensity": {"uint16_white_level": 65535}})
        self.save(root, "model_state.json", {"status": "TRAINED"})
        with (root / "manifest.csv").open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=["relative_path", "split", "class_name", "pixel_hash"])
            writer.writeheader()
            writer.writerows([
                {"relative_path": "bad/C0000083_Rc01_Cc02_vig.png", "split": "train", "class_name": "bad", "pixel_hash": "d" * 64},
                {"relative_path": "good/C00000083_Rc02Cc03_vig.png", "split": "test", "class_name": "good", "pixel_hash": "e" * 64},
                {"relative_path": "good/C0000084_Rc01_Cc01_vig.png", "split": "val", "class_name": "good", "pixel_hash": "f" * 64}])
        manifest_sha = hashlib.sha256((root / "manifest.csv").read_bytes()).hexdigest()
        self.save(root, "integrity.json", {"config_sha256": cfg_sha, "manifest_sha256": manifest_sha})
        self.save(root, "models/resnet18_seed42/progress.json", {"status": "completed", "best_val_pr_auc_bad": .82})
        self.save(root, "models/resnet18_seed42/completed.json", {"checkpoint_sha256": "a" * 64})
        return root

    def session(self, name="session1", task="vig", rows=None, status="completed", source=None):
        root = self.root / name
        root.mkdir()
        self.save(root, "review_session.json", {"format": "inspection_review_session_v4", "id": name,
                  "kind": "classification", "created_utc": "2026-09-28T00:00:00Z", "metadata": {"task": task}})
        self.save(root, "summary.json", {"status": status})
        rows = rows if rows is not None else [
            {"relative_path": "bad/C0000083_Rc01_Cc02_vig.png", "prediction": "good", "reference_label": "bad", "file_sha256": "a" * 64},
            {"relative_path": "good/C00000083_Rc02Cc03_vig.png", "prediction": "review", "reference_label": "good", "file_sha256": "b" * 64},
            {"relative_path": "good/C0000084_Rc01_Cc01_vig.png", "prediction": "bad", "reference_label": "good", "file_sha256": "c" * 64}]
        for i, row in enumerate(rows):
            self.save(root, f"records/{i}.json", {"id": str(i), "status": "ok", **row})
        self.save(root, "review_progress.json", {"status": status, "completed": len(rows), "total": len(rows)})
        if source:
            self.save(root, "applied_decision.json", {"task": task, "source_run_id": source.name,
                 "source_config_sha256": hashlib.sha256((source / "config.json").read_bytes()).hexdigest(),
                 "source_manifest_sha256": hashlib.sha256((source / "manifest.csv").read_bytes()).hexdigest(),
                 "candidate": {"name": "resnet18", "members": [{"sha256": "a" * 64}]}})
        return root

    def test_original_and_operator_references_stay_separate(self):
        session = self.session()
        self.save(session, "reviews.json", {"items": {"0": {"label": "good"}, "1": {"label": "review"}}})
        report = build_quality_report([], [session])
        s = report["sessions"][0]
        self.assertEqual(s["metrics_reference"]["bad_passed_as_good_FN"], 1)
        self.assertEqual(s["metrics_reference"]["good_rejected_as_bad_FP"], 1)
        self.assertEqual(s["metrics_reference"]["accuracy"], 0)
        self.assertEqual(s["metrics_operator"]["n_labeled"], 1)
        self.assertEqual(s["metrics_operator"]["accuracy"], 1)
        self.assertEqual(s["metrics_reference"]["confusion"]["matrix"], [[0, 1, 0], [1, 0, 1]])
        self.assertTrue(report["images"][0]["manual_reference_disagreement"])
        self.assertIn("not independent", s["metrics_operator"]["reference_basis"])

    def test_training_test_and_development_exposure_normalize_tray_padding(self):
        run = self.run_data()
        session = self.session(source=run)
        report = build_quality_report([run], [session])
        self.assertEqual(report["runs"][0]["status"], "TRAINED")
        self.assertEqual(report["runs"][0]["dataset"]["n_units"], 3)
        self.assertEqual({r["tray"] for r in report["trays"]}, {"C83", "C84"})
        self.assertEqual([r["training_exposure"] for r in report["images"]],
                         ["seen_in_training", "seen_in_test", "seen_in_development"])
        self.assertEqual(report["images"][0]["recorded_source_splits"], ["train"])

    def test_unknown_exposure_is_not_unseen(self):
        report = build_quality_report([], [self.session()])
        self.assertEqual(report["sessions"][0]["training_exposure"]["unknown"], 3)

    def test_missing_labels_do_not_become_accuracy(self):
        session = self.session(rows=[{"relative_path": "x.png", "prediction": "good", "file_sha256": "a" * 64}])
        report = build_quality_report([], [session])
        metrics = report["sessions"][0]["metrics_reference"]
        self.assertIsNone(metrics["accuracy"])
        self.assertIsNone(metrics["bad_escape_rate"])
        self.assertEqual(metrics["decision_coverage"], 1)
        json.dumps(report, allow_nan=False)

    def test_invalid_predictions_and_review_are_not_success(self):
        session = self.session(rows=[
            {"relative_path": "a.png", "reference_label": "bad", "prediction": "review"},
            {"relative_path": "b.png", "reference_label": "good", "prediction": "good", "status": "input_error"}])
        metrics = build_quality_report([], [session])["sessions"][0]["metrics_reference"]
        self.assertIsNone(metrics["accuracy"])
        self.assertEqual(metrics["n_labeled_unavailable"], 1)
        self.assertEqual(metrics["n_labeled_review"], 1)
        self.assertEqual(metrics["automatic_correct_rate"], 0)

    def test_existing_test_report_read_but_sealed_scores_never_opened(self):
        run = self.run_data()
        sealed = run / "scores" / "test.npy"
        sealed.parent.mkdir()
        sealed.write_bytes(b"sealed-data-not-a-numpy-file")
        report = build_quality_report([run], [])
        self.assertFalse(report["runs"][0]["final_test"]["available"])
        self.assertFalse(any(a["path"].startswith("scores") for a in report["artifacts"]))
        self.save(run, "final_test_summary.json", {"evaluation_role": "final-test", "metrics": {"accuracy": .91}})
        report = build_quality_report([run], [])
        self.assertEqual(report["runs"][0]["final_test"]["summary"]["metrics"]["accuracy"], .91)

    def test_unpublished_test_predictions_not_read(self):
        run = self.run_data()
        path = run / "final_test" / "predictions.csv"
        path.parent.mkdir()
        path.write_text("relative_path,true_class,predicted_class\na.png,bad,good\n", encoding="utf-8")
        report = build_quality_report([run], [])
        self.assertFalse(any(a["path"] == "final_test/predictions.csv" for a in report["artifacts"]))
        self.assertEqual(report["runs"][0]["final_test"]["prediction_rows"], [])

    def test_recorded_test_and_external_per_tray_metrics(self):
        run = self.run_data()
        for folder, summary in (("final_test", "final_test_summary.json"),
                                ("evaluations/batch1/predictions", "evaluations/batch1/summary.json")):
            self.save(run, summary, {"metrics": {"accuracy": .5}})
            path = run / folder / "predictions.csv"
            path.parent.mkdir(exist_ok=True)
            path.write_text("relative_path,true_class,predicted_class\n"
                            "C0000083_Rc01Cc02.png,bad,good\nC0000084_Rc01Cc02.png,good,good\n", encoding="utf-8")
        model = build_quality_report([run], [])["runs"][0]
        self.assertEqual(len(model["dataset_membership"]), 3)
        self.assertEqual(model["final_test"]["per_tray"][0]["metrics_reference"]["bad_escape_rate"], 1)
        self.assertEqual(len(model["external_evaluations"]), 1)
        self.assertEqual(len(model["external_evaluations"][0]["prediction_rows"]), 2)

    def test_common_fingerprint_comparison_not_filename(self):
        a = self.session("s1", rows=[{"relative_path": "a.png", "reference_label": "bad", "prediction": "bad", "file_sha256": "a" * 64}])
        b = self.session("s2", rows=[{"relative_path": "renamed.png", "reference_label": "bad", "prediction": "review", "file_sha256": "a" * 64},
                                    {"relative_path": "a.png", "reference_label": "good", "prediction": "good", "file_sha256": "b" * 64}])
        result = build_quality_report([], [a, b])["comparisons"][0]
        self.assertTrue(result["comparable"])
        self.assertEqual(result["common_images"], 1)
        self.assertEqual(result["decision_disagreements"], 1)
        self.assertEqual(result["coverage_b"], .5)
        self.assertIsNone(result["metrics_b"]["accuracy"])

    def test_cross_task_and_unknown_task_not_compared(self):
        a, b = self.session("s1"), self.session("s2", task="top")
        report = build_quality_report([], [a, b])
        self.assertFalse(report["comparisons"][0]["comparable"])
        self.assertEqual(report["summary"]["tasks"], ["top", "vig"])
        self.assertNotIn("accuracy", report["summary"])

    def test_conflicting_labels_and_duplicate_hashes_excluded_from_pairs(self):
        a = self.session("s1", rows=[{"relative_path": "a.png", "reference_label": "bad", "prediction": "bad", "file_sha256": "a" * 64},
                                     {"relative_path": "b.png", "reference_label": "bad", "prediction": "bad", "file_sha256": "b" * 64}])
        b = self.session("s2", rows=[{"relative_path": "a.png", "reference_label": "good", "prediction": "bad", "file_sha256": "a" * 64},
                                     {"relative_path": "b.png", "reference_label": "bad", "prediction": "good", "file_sha256": "b" * 64},
                                     {"relative_path": "c.png", "reference_label": "bad", "prediction": "good", "file_sha256": "b" * 64}])
        result = build_quality_report([], [a, b])["comparisons"][0]
        self.assertFalse(result["comparable"])
        self.assertEqual(result["reference_conflicts"], 1)
        self.assertEqual(result["excluded_ambiguous_fingerprints"], 1)

    def test_running_or_corrupt_sessions_are_provisional(self):
        session = self.session(status="running")
        self.assertTrue(build_quality_report([], [session])["sessions"][0]["provisional"])
        self.save(session, "summary.json", {"status": "completed"})
        (session / "records" / "0.json").write_text("not json", encoding="utf-8")
        report = build_quality_report([], [session])
        self.assertTrue(report["sessions"][0]["provisional"])
        self.assertGreater(report["summary"]["errors"], 0)
        self.assertTrue(any(a["status"] == "invalid" for a in report["artifacts"]))

    def test_symbolic_artifacts_are_not_followed(self):
        session = self.session()
        outside = self.root / "secret.json"
        outside.write_text('{"items": {}}', encoding="utf-8")
        try:
            (session / "reviews.json").symlink_to(outside)
        except (OSError, NotImplementedError):
            self.skipTest("Symbolic links unavailable")
        report = build_quality_report([], [session])
        artifact = next(a for a in report["artifacts"] if a["path"] == "reviews.json")
        self.assertIsNone(artifact["sha256"])
        self.assertEqual(artifact["status"], "invalid")
        self.assertTrue(any("Symbolic" in i["message"] for i in report["issues"]))

    def test_integrity_violation_does_not_assert_training_exposure(self):
        run = self.run_data()
        self.save(run, "integrity.json", {"manifest_sha256": "0" * 64})
        session = self.session(source=run)
        report = build_quality_report([run], [session])
        self.assertEqual(report["sessions"][0]["training_exposure"]["unknown"], 3)
        self.assertFalse(report["runs"][0]["dataset"]["integrity_valid"])

    def test_no_source_artifacts_modified(self):
        run = self.run_data()
        session = self.session(source=run)
        before = {str(p): p.read_bytes() for root in (run, session) for p in root.rglob("*") if p.is_file()}
        report = build_quality_report([run], [session], title="<script>Safe data</script>", notes="A detailed report")
        after = {str(p): p.read_bytes() for root in (run, session) for p in root.rglob("*") if p.is_file()}
        self.assertEqual(before, after)
        self.assertTrue(report["artifacts"])
        self.assertEqual(report["runs"][0]["models"][0]["checkpoint_hashes"]["binary_verified"], False)

    def test_empty_inputs_and_duplicates_rejected(self):
        with self.assertRaises(ValueError):
            build_quality_report([], [])
        session = self.session()
        with self.assertRaises(ValueError):
            build_quality_report([], [session, session])


if __name__ == "__main__":
    unittest.main()
