"""Classical local-contrast proposals, never ground-truth annotations."""
from __future__ import annotations
import math
import numpy as np
from scipy import ndimage
from .common import DEFAULTS


def default_roi(width, height):
    radius = .28 * min(width, height)
    return {'cx': width / 2, 'cy': height / 2, 'rx': radius, 'ry': radius}


def validate_roi(roi, width, height):
    roi = default_roi(width, height) if roi is None else dict(roi)
    if set(roi) != {'cx', 'cy', 'rx', 'ry'}:
        raise ValueError('Lens ROI requires cx, cy, rx, ry.')
    roi = {key: float(value) for key, value in roi.items()}
    if not all(math.isfinite(value) for value in roi.values()):
        raise ValueError('Lens ROI values must be finite.')
    if not (0 <= roi['cx'] <= width and 0 <= roi['cy'] <= height and
            1 <= roi['rx'] <= width and 1 <= roi['ry'] <= height):
        raise ValueError('Lens center must be inside the image; radii must be at least one pixel and no larger than the image.')
    return roi


def validate_settings(settings):
    cfg = dict(DEFAULTS['classical'])
    if settings:
        if set(settings) - set(cfg):
            raise ValueError('Unknown classical detector setting.')
        cfg.update(settings)
    for key, lower, upper in (('background_sigma', 1, 100), ('sensitivity', .5, 20),
                              ('max_area_fraction', .000001, 1)):
        cfg[key] = float(cfg[key])
        if not math.isfinite(cfg[key]) or not lower <= cfg[key] <= upper:
            raise ValueError(f'{key} must be finite in [{lower},{upper}].')
    for key, lower, upper in (('min_area', 1, 1000000), ('boundary_guard', 0, 100)):
        if isinstance(cfg[key], bool) or int(cfg[key]) != cfg[key] or not lower <= cfg[key] <= upper:
            raise ValueError(f'{key} must be an integer in [{lower},{upper}].')
        cfg[key] = int(cfg[key])
    if cfg['polarity'] not in ('both', 'dark', 'bright'):
        raise ValueError('polarity must be both, dark or bright.')
    return cfg


def suggest(image, roi=None, settings=None):
    rgb = np.asarray(image)
    if rgb.ndim != 3 or rgb.shape[2] != 3 or rgb.dtype != np.uint8:
        raise ValueError('Classical proposal input must be an 8-bit RGB image.')
    height, width = rgb.shape[:2]
    roi = validate_roi(roi, width, height)
    cfg = validate_settings(settings)
    gray = rgb.astype(np.float32) @ np.array([.299, .587, .114], dtype=np.float32)
    # Small smoothing suppresses sensor noise. A wider Gaussian models local illumination.
    smooth = ndimage.gaussian_filter(gray, .6, mode='reflect')
    background = ndimage.gaussian_filter(smooth, cfg['background_sigma'], mode='reflect')
    residual = smooth - background
    yy, xx = np.ogrid[:height, :width]
    radius = np.sqrt(((xx + .5 - roi['cx']) / roi['rx']) ** 2 + ((yy + .5 - roi['cy']) / roi['ry']) ** 2)
    inner = radius <= 1
    valid = np.ones((height, width), dtype=bool)
    guard = cfg['boundary_guard']
    if guard:
        valid &= np.abs(radius - 1) * min(roi['rx'], roi['ry']) > guard
        valid[:guard] = valid[-guard:] = False
        valid[:, :guard] = valid[:, -guard:] = False
    mask = np.zeros((height, width), dtype=np.uint8)
    thresholds, components = {}, {}
    for value, region in ((1, inner), (2, ~inner)):
        eligible = valid & region
        values = residual[eligible]
        name = 'inner' if value == 1 else 'outer'
        if not values.size:
            thresholds[name], components[name] = None, 0
            continue
        center = float(np.median(values))
        noise = max(1., 1.4826 * float(np.median(np.abs(values - center))))
        threshold = cfg['sensitivity'] * noise
        difference = residual - center
        selected = np.abs(difference) >= threshold if cfg['polarity'] == 'both' else (
            difference <= -threshold if cfg['polarity'] == 'dark' else difference >= threshold)
        labels, _ = ndimage.label(selected & eligible, structure=np.ones((3, 3), dtype=bool))
        counts = np.bincount(labels.ravel())
        keep = (counts >= cfg['min_area']) & (counts <= max(cfg['min_area'], cfg['max_area_fraction'] * height * width))
        keep[0] = False
        mask[keep[labels]] = value
        thresholds[name], components[name] = threshold, int(keep.sum())
    return mask, {'method': 'local_gaussian_residual_mad_components', 'automatic_proposal': True,
                  'review_required': True, 'thresholds_gray_levels': thresholds,
                  'components': components, 'inner_pixels': int((mask == 1).sum()),
                  'outer_pixels': int((mask == 2).sum()),
                  'low_contrast': bool(np.percentile(gray, 99) - np.percentile(gray, 1) < 8),
                  'note': 'Appearance anomalies are suggestions. Lens edges, markings and accepted texture can cause false positives; broad or low-contrast damage can be missed.'}
