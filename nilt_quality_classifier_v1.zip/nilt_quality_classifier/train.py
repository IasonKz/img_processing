from __future__ import annotations

import argparse
import multiprocessing as mp

from qc.config import load_yaml
from qc.pipeline import run_training


def main() -> None:
    parser = argparse.ArgumentParser(description="Train a GOOD/BAD image classifier.")
    parser.add_argument("--config", required=True, help="Path to a training YAML file")
    args = parser.parse_args()
    config = load_yaml(args.config)
    result = run_training(config, mode="train")
    print(f"\nBest model: {result['best_model']}")
    print(f"Run report: {result['run_dir']}/MODEL_REPORT.md")


if __name__ == "__main__":
    mp.freeze_support()
    main()
