"""Local, defect-oriented image classification. Fixed labels: bad=0, good=1."""
__version__ = "6.1.0"
