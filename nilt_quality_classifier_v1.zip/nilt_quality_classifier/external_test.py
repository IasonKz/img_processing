from __future__ import annotations

import argparse
import copy
import multiprocessing as mp
from pathlib import Path

from qc.config import load_yaml
from qc.evaluation import run_prediction_evaluation
from qc.inference import run_folder_prediction


def main() -> None:
    parser = argparse.ArgumentParser(
        description="One command: predict a new folder and compare with evaluation_results.csv."
    )
    parser.add_argument("--config", required=True, help="Path to an external-test YAML file")
    args = parser.parse_args()
    config = load_yaml(args.config)

    prediction_result = run_folder_prediction(config)
    evaluation_config = copy.deepcopy(config)
    evaluation_config.setdefault("predictions", {})["path"] = str(
        Path(prediction_result["output_folder"]) / "predictions.csv"
    )
    evaluation_config["predictions"]["source_root"] = prediction_result["input_folder"]
    evaluation_config.setdefault("evaluation", {})["output_folder"] = str(
        Path(prediction_result["output_folder"]) / "evaluation"
    )
    evaluation_result = run_prediction_evaluation(evaluation_config)

    print(f"\nPredictions: {prediction_result['output_folder']}/predictions.csv")
    print(f"Evaluation: {evaluation_result['output_folder']}")
    print(
        "False passes (real BAD predicted GOOD): "
        f"{evaluation_result['metrics']['false_pass']}"
    )


if __name__ == "__main__":
    mp.freeze_support()
    main()
