"""Low-cost terminal animation of the supplied NILT mark while the server runs.

The dashboard remains usable without a TTY. Unexpected console output stops the
animation before being printed, so errors and logs are never painted over.
"""
from __future__ import annotations

import math
import os
from pathlib import Path
import shutil
import sys
import threading
import time

LOGO = Path(__file__).with_name("assets") / "nilt_terminal_logo.png"
ENTER = "\x1b[?1049h\x1b[?25l\x1b[2J"
LEAVE = "\x1b[0m\x1b[?25h\x1b[?1049l"
BLUE = "\x1b[38;2;0;120;200m"


def _windows_ansi(stream):
    """Enable virtual terminal processing and return a restoration callback."""
    if os.name != "nt":
        return lambda: None
    import ctypes
    from ctypes import wintypes
    import msvcrt
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.GetConsoleMode.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
    kernel.SetConsoleMode.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    handle = wintypes.HANDLE(msvcrt.get_osfhandle(stream.fileno()))
    original = wintypes.DWORD()
    if not kernel.GetConsoleMode(handle, ctypes.byref(original)):
        raise OSError("Not a Windows console")
    if not kernel.SetConsoleMode(handle, original.value | 0x0004):
        raise OSError("Virtual terminal processing is unavailable")
    return lambda: kernel.SetConsoleMode(handle, original.value)


def logo_points(path=LOGO):
    """Use the upper symbol of the supplied logo, as in nilt_spin.py."""
    from PIL import Image
    with Image.open(path) as original:
        logo = original.convert("RGB")
    logo = logo.crop((0, 0, logo.width, max(1, int(logo.height * .72))))
    mask = logo.convert("L").point(lambda value: 255 if value > 35 else 0)
    bbox = mask.getbbox()
    if not bbox:
        raise ValueError("The terminal logo has no visible pixels")
    mask = mask.crop(bbox)
    width = 58
    height = max(6, round(width * mask.height / mask.width * .48))
    mask = mask.resize((width, height), Image.Resampling.LANCZOS)
    return [(x - (width - 1) / 2, -(y - (height - 1) / 2), z)
            for y in range(height) for x in range(width)
            if mask.getpixel((x, y)) > 100 for z in (-2., 0., 2.)]


def render_logo(points, angle, width, height, unicode=True):
    """Render one bounded frame without terminal control characters."""
    buffer = [" "] * (width * height)
    depths = [-math.inf] * len(buffer)
    ca, sa = math.cos(angle), math.sin(angle)
    tilt = .18 * math.sin(angle * .55)
    ct, st = math.cos(tilt), math.sin(tilt)
    scale = min(1., (width - 4) / 64., (height - 2) / 14.)
    shades = "░▒▓█" if unicode else ".:+#"
    for x, y, z in points:
        rx, rz = x * ca - z * sa, x * sa + z * ca
        ry, depth = y * ct - rz * st, y * st + rz * ct
        factor = scale * 72. / (72. + .8 * depth)
        sx, sy = int(width / 2 + rx * factor), int(height / 2 + ry * factor)
        if 0 <= sx < width and 0 <= sy < height:
            index = sx + sy * width
            if depth > depths[index]:
                depths[index] = depth
                light = .55 * ca + .45 * depth / 22.
                buffer[index] = shades[3 if light > .45 else 2 if light > .15 else 1 if light > -.15 else 0]
    return ["".join(buffer[y * width:(y + 1) * width]) for y in range(height)]


class _ConsoleOutput:
    """Restore the ordinary console before any external write."""
    def __init__(self, owner, stream):
        self.owner, self.stream = owner, stream

    def write(self, text):
        if text:
            self.owner.stop()
        return self.stream.write(text)

    def flush(self):
        return self.stream.flush()

    def __getattr__(self, name):
        return getattr(self.stream, name)


class TerminalLogo:
    def __init__(self, url, enabled=None, fps=None):
        self.url = url
        self.enabled = (os.environ.get("NILT_TERMINAL_SPINNER", "1").lower()
                        not in {"0", "false", "off", "no"}) if enabled is None else enabled
        try:
            requested = float(fps if fps is not None else os.environ.get("NILT_SPINNER_FPS", "8"))
            self.fps = min(12., max(1., requested)) if math.isfinite(requested) else 8.
        except (TypeError, ValueError):
            self.fps = 8.
        self.stream = sys.stdout
        self._stop = threading.Event()
        self._lock = threading.RLock()
        self._thread = None
        self._restore_mode = lambda: None
        self._active = False
        self._old_streams = None

    def start(self):
        if not self.enabled or not self.stream.isatty() or os.environ.get("TERM") == "dumb":
            return False
        size = shutil.get_terminal_size((80, 24))
        if size.columns < 40 or size.lines < 12:
            return False
        try:
            self._points = logo_points()
            try:
                "░▒▓█".encode(self.stream.encoding or "ascii")
                self._unicode = True
            except (LookupError, UnicodeError):
                self._unicode = False
            self._restore_mode = _windows_ansi(self.stream)
            self._old_streams = (sys.stdout, sys.stderr)
            self._active = True
            self.stream.write(ENTER)
            self.stream.flush()
            self._stdout_proxy = _ConsoleOutput(self, sys.stdout)
            self._stderr_proxy = _ConsoleOutput(self, sys.stderr)
            sys.stdout, sys.stderr = self._stdout_proxy, self._stderr_proxy
            self._thread = threading.Thread(target=self._run, name="nilt-terminal-logo", daemon=True)
            self._thread.start()
            return True
        except Exception:
            # Decorative output must never prevent the dashboard from opening.
            self.stop()
            return False

    def _run(self):
        started = time.monotonic()
        try:
            while not self._stop.is_set():
                size = shutil.get_terminal_size((80, 24))
                if size.columns < 40 or size.lines < 12:
                    break
                width, height = min(76, size.columns - 1), min(20, size.lines - 7)
                frame = render_logo(self._points, (time.monotonic() - started) * .8,
                                    width, height, self._unicode)
                lines = ["NIL TECHNOLOGY | Inspection Studio", self.url,
                         "Dashboard open. Ctrl+C closes the server.",
                         "Training jobs run independently.",
                         "Use Pause or Cancel search in the dashboard."]
                output = ("\x1b[H" + BLUE + "\r\n".join(row + "\x1b[K" for row in frame)
                          + "\x1b[0m\r\n" + "\r\n".join(line[:width] + "\x1b[K" for line in lines)
                          + "\x1b[J")
                with self._lock:
                    if self._stop.is_set():
                        break
                    self.stream.write(output)
                    self.stream.flush()
                self._stop.wait(1. / self.fps)
        except (OSError, ValueError, UnicodeError):
            pass
        finally:
            self.stop()

    def stop(self):
        self._stop.set()
        with self._lock:
            if self._old_streams is not None:
                if sys.stdout is getattr(self, "_stdout_proxy", None):
                    sys.stdout = self._old_streams[0]
                if sys.stderr is getattr(self, "_stderr_proxy", None):
                    sys.stderr = self._old_streams[1]
            if self._active:
                self._active = False
                try:
                    self.stream.write(LEAVE)
                    self.stream.flush()
                except (OSError, ValueError):
                    pass
            self._restore_mode()
            self._restore_mode = lambda: None
        if self._thread is not None and threading.current_thread() is not self._thread:
            self._thread.join(timeout=1.)
