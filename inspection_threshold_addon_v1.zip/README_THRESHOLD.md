# Αλλαγή threshold μετά το training — add-on v1.0

Για το `visual_inspection_pipeline_v2` (package version 2.0.0).
Δεν χρειάζεται νέο training, αλλαγή YAML, αλλαγή `selected.json` ή αντικατάσταση αρχείων του project.
Λειτουργεί τοπικά/offline, με τα ίδια εκπαιδευμένα μοντέλα και preprocessing.

## 1. Εγκατάσταση

Αντέγραψε το **threshold_addon.py** δίπλα στο `inspection.py`, στο βασικό φάκελο του project.
Δεν μπαίνει μέσα στο `.venv_vig`. Χρησιμοποιεί τις εξαρτήσεις που ήδη έχει το project.

Στο PowerShell, από εκείνον τον φάκελο:

```powershell
.\.venv_vig\Scripts\python.exe threshold_addon.py --help
```

## 2. Δοκιμή thresholds χωρίς training ή inference

Στην παρακάτω μεταβλητή βάλε τον πραγματικό φάκελο ενός ολοκληρωμένου run, που περιέχει το `selected.json`:

```powershell
$run = "results\vig\ΤΟ_RUN_ΣΟΥ"
.\.venv_vig\Scripts\python.exe threshold_addon.py --run "$run" --split threshold --thresholds 0.58041903 0.60 0.65 0.70 --output-root threshold_results
```

Το `0.58041903` είναι το όριο που αναφέρθηκε στην προηγούμενη συζήτηση. Αν το συγκεκριμένο run έχει διαφορετικό αρχικό threshold, χρησιμοποίησε εκείνο για την αρχική σύγκριση. Το αρχικό καταγράφεται επίσης στο νέο `summary.json` ως `original_threshold`.

Το script διαβάζει τα ήδη αποθηκευμένα scores του **επιλεγμένου μοντέλου** από το threshold split. Η σειρά των εικόνων προέρχεται από το manifest του run. Δεν φορτώνει τα βάρη, δεν εκπαιδεύει και δεν ξανατρέχει το μοντέλο.

Στο τέλος εμφανίζει το πλήρες path του νέου φακέλου και του `comparison.html`. Άνοιξε το HTML με διπλό κλικ.

Για κάθε όριο βλέπεις:

- πόσες εικόνες βγαίνουν good/bad,
- bad που πέρασαν ως good (FN),
- good που απορρίφθηκαν ως bad (FP),
- bad escape rate, good reject rate και accuracy.

Τα rates είναι στην κλίμακα 0–1: `0.05` = 5%. `None` σημαίνει ότι δεν υπάρχει η αντίστοιχη πραγματική κατηγορία για τον υπολογισμό του ποσοστού.

Για αντίγραφα εικόνων σε good/bad **ανά threshold**, πρόσθεσε `--copy-images`. Τα πρωτότυπα πρέπει να υπάρχουν ακόμη στις καταγεγραμμένες θέσεις και να μην έχουν αλλάξει. Χωρίς την επιλογή αυτή παράγονται μόνο τα αρχεία σύγκρισης και προβλέψεων, εξοικονομώντας χώρο.

## 3. Νέες εικόνες με χειροκίνητο threshold

Παράδειγμα για threshold 0.65:

```powershell
.\.venv_vig\Scripts\python.exe threshold_addon.py --run "$run" --input "D:\new_images\vig" --thresholds 0.65 --copy-images --device cpu --output-root classified_manual
```

Το input μπορεί να περιέχει εικόνες και υποφακέλους. Χωρίς `--labeled`, οι υποφάκελοι δεν θεωρούνται πραγματικές ετικέτες: παράγονται προβλέψεις και πλήθη, χωρίς accuracy ή άλλα metrics.

Αν έχεις **χειροκίνητα ελεγμένες πραγματικές ετικέτες**, ο φάκελος πρέπει να περιέχει `good/` και `bad/`. Τότε πρόσθεσε `--labeled`:

```powershell
.\.venv_vig\Scripts\python.exe threshold_addon.py --run "$run" --input "D:\new_labeled\vig" --labeled --thresholds 0.58 0.65 0.70 --copy-images --device cpu --output-root classified_manual
```

Το μοντέλο εκτελείται **μία φορά ανά εικόνα/μέλος ensemble**, ανεξάρτητα από το πλήθος thresholds. Μετά τα ίδια scores συγκρίνονται με κάθε όριο. Για workstation μπορείς να βάλεις `--device cuda`.

Τα predicted/good και predicted/bad ενός προηγούμενου αποτελέσματος **δεν είναι πραγματικές ετικέτες**. Μην τα χρησιμοποιήσεις ως labeled input χωρίς χειροκίνητο έλεγχο.

## 4. Δοκιμή άλλου ορίου στα ίδια scores

Βάλε στο `$result` το πλήρες path που τύπωσε η προηγούμενη εκτέλεση — τον φάκελο που περιέχει `summary.json` και `scores.json`, όχι τον επιμέρους threshold φάκελο:

```powershell
$result = "classified_manual\ΤΟ_ΑΠΟΤΕΛΕΣΜΑ_ΣΟΥ"
.\.venv_vig\Scripts\python.exe threshold_addon.py --from-results "$result" --thresholds 0.62 0.68 0.72 --copy-images --output-root classified_manual
```

Αυτό δημιουργεί νέο φάκελο δίπλα στον προηγούμενο και **δεν τρέχει ξανά το μοντέλο**. Για γρήγορη σύγκριση χωρίς νέα αντίγραφα εικόνων, αφαίρεσε `--copy-images`.

Το `--from-results` δέχεται αποτελέσματα αυτού του add-on, όχι οποιοδήποτε παλιό prediction CSV. Για παλιό training run χρησιμοποίησε το βήμα 2.

## 5. Κράτησε μία επιλογή για επόμενες παρτίδες

Κάθε υποφάκελος threshold περιέχει `decision.json`. Για να ξαναχρησιμοποιήσεις το συγκεκριμένο μοντέλο και όριο:

```powershell
.\.venv_vig\Scripts\python.exe threshold_addon.py --decision "threshold_results\ΤΟ_ΑΠΟΤΕΛΕΣΜΑ_ΣΟΥ\threshold_03_0.65\decision.json" --input "D:\next_batch\vig" --copy-images --device cpu --output-root classified_manual
```

Το path είναι παράδειγμα: πάρε τον ακριβή φάκελο από το αποτέλεσμά σου. Το `decision.json` συνδέεται με το run και το hash του `selected.json`, ώστε να μην εφαρμοστεί σιωπηρά σε διαφορετικό επιλεγμένο μοντέλο.

Αυτή η επιλογή ισχύει όταν καλείς **threshold_addon.py --decision ...**. Το παλιό `inspection.py predict`, το visual report και τα ήδη εξαγμένα ONNX packages εξακολουθούν να χρησιμοποιούν την αρχική τους ρύθμιση. Αυτό το add-on δουλεύει με source training runs· δεν τροποποιεί ONNX packages ή το ενεργό release. Κράτησε τον φάκελο του run στην ίδια θέση για τις αποθηκευμένες decision επιλογές.

## Τι αρχεία δημιουργούνται

Κάθε εκτέλεση δημιουργεί μοναδικό φάκελο timestamp + τυχαίου ID:

| Αρχείο / φάκελος | Περιεχόμενο |
|---|---|
| comparison.html / comparison.csv | Σύγκριση όλων των thresholds |
| summary.json | Μοντέλο, run, αρχικό και νέα thresholds, προέλευση scores |
| scores.json | Scores, εικόνες και ετικέτες για επαναχρησιμοποίηση |
| invalid_images.csv | Προβληματικές είσοδοι που δεν ταξινομήθηκαν |
| review/ | Αντίγραφα προβληματικών εισόδων όταν ζητούνται εικόνες |
| threshold_…/decision.json | Αποθηκευμένο όριο και σύνδεση με το μοντέλο |
| threshold_…/predictions.csv | Score, threshold και απόφαση για κάθε έγκυρη εικόνα |
| threshold_…/counts.json | Πλήθη predicted good/bad |
| threshold_…/metrics.json | Νέα metrics μόνο όταν υπάρχουν πραγματικές ετικέτες |
| threshold_…/predicted/good, bad | Αντίγραφα εικόνων με `--copy-images` |

Το output πρέπει να βρίσκεται εκτός dataset και εκτός training run. Αν αποτύχει μία εκτέλεση αφού δημιουργήσει φάκελο, το `summary.json` παραμένει `incomplete` και δεν επιτρέπεται replay από αυτόν. Αν δεν υπάρχει καμία έγκυρη εικόνα, σταματά με σφάλμα.

## Πώς ερμηνεύεται το όριο

Ο κανόνας παραμένει **score >= threshold → bad**, αλλιώς good. Η ισότητα ανήκει στο bad.
Μεγαλύτερο threshold = πιο ελαστικό. Μικρότερο = πιο αυστηρό.
Τα supervised bad scores συνήθως έχουν κλίμακα 0–1. Το PatchCore έχει διαφορετική κλίμακα anomaly score: μην μεταφέρεις τα ίδια αριθμητικά thresholds από διαφορετικό μοντέλο.

Χρησιμοποίησε το threshold/calibration σύνολο για να επιλέξεις όριο. Μετά έλεγξε τη σταθερή επιλογή σε ξεχωριστό αντιπροσωπευτικό σύνολο πραγματικά labeled εικόνων. Μην χρησιμοποιείς επανειλημμένα το τελικό test για να επιλέγεις όριο. Το add-on σκοπίμως δεν προσφέρει `--split test`.

Οι νέες μετρήσεις είναι περιγραφικές για τις έγκυρες εικόνες αυτού του δείγματος. Τα invalid αναφέρονται χωριστά και δεν μετρούν ως good. Η νέα χειροκίνητη απόφαση δεν κληρονομεί την αξιολόγηση της παλιάς· καταγράφεται ως `MANUAL_THRESHOLD_NOT_INDEPENDENTLY_VALIDATED`.

## Έλεγχοι αυτής της έκδοσης

Πέρασαν 5 αυτοματοποιημένα tests: ισότητα στο threshold, αλλαγή FN/FP, επαναχρησιμοποίηση scores, αντίγραφα και μοναδικοί φάκελοι, labeled/unlabeled συμπεριφορά, invalid images, αποθηκευμένη απόφαση, ανίχνευση αλλαγμένων εικόνων/scores, προστασία αρχικού run και anomaly score εκτός 0–1.
Η νέα inference διαδρομή ελέγχθηκε με προσομοιωμένα scores στο υπάρχον API. Δεν εκτελέστηκε πραγματικό PyTorch checkpoint εδώ, επειδή το διαθέσιμο περιβάλλον δεν έχει PyTorch ή το δικό σου εκπαιδευμένο μοντέλο. Το add-on καλεί την υπάρχουσα `nilt.workflow.predict_members` για την πραγματική inference στο δικό σου περιβάλλον.

Για επανεκτέλεση των tests, χρειάζονται τα tests του αρχικού v2 project και το `test_integration_v2.py` στο Python import path.
