"""Integrated local top-view annotation and segmentation training."""
__version__ = "2.0.0"
