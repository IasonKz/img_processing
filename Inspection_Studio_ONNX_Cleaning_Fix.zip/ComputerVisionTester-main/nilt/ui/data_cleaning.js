"use strict";
/* Human tags are staged locally; only Commit/Enter requests a checksum-checked move. */
window.DatasetCleaning = (() => {
  let catalog=null,item=null,index=-1,busy=false,generation=0,pending=null,history=[],pendingAssessment="",polling=false,lastHistory="";
  const scope=()=>({task:WorkspaceStudio.task(),roi_scope:WorkspaceStudio.roiScope()});
  const storageKey=()=>"inspection-cleaning.v1:"+scope().task+":"+scope().roi_scope;
  function stored(){try{return JSON.parse(localStorage.getItem(storageKey())||"{}");}catch{return {};}}
  function remember(){if(!catalog)return;try{localStorage.setItem(storageKey(),JSON.stringify({root:catalog.path,model:$("clean-model").value,assessment:$("clean-assessment").value,label:$("clean-filter").value,tray:$("clean-tray").value,search:$("clean-search").value,comparison:$("clean-comparison").value,priority:$("clean-priority").value,page:catalog.pagination.page,relative:item?.relative_path,pending,pending_assessment:pendingAssessment}));}catch{}}
  const on=(id,fn)=>$(id).addEventListener("click",()=>Promise.resolve().then(fn).catch(error=>notify(error.message,true)));
  const numberValue=value=>Number.isFinite(value)?number(value,6):"—";
  function assisted(){return !!$("clean-model").value;}
  function payload(){return {dataset:catalog?.dataset,...scope(),assessment:assisted()?$("clean-assessment").value:"",page:catalog?.pagination.page||1,label:$("clean-filter").value,tray:$("clean-tray").value,search:$("clean-search").value.trim(),comparison:assisted()&&$("clean-assessment").value?$("clean-comparison").value:"",priority:$("clean-priority").value};}
  function modelTag(row){if(!assisted())return "Manual only";if(!row)return "MODEL · NOT SCORED";if(row.status!=="ok")return "MODEL · "+row.status.toUpperCase();const probability=String(row.score_type||"").startsWith("bad_prob")&&row.bad_score>=0&&row.bad_score<=1&&["good","bad"].includes(row.prediction);return "MODEL · "+String(row.prediction||"REVIEW").toUpperCase()+(Number.isFinite(row.bad_score)?probability?" · class score "+numberValue(row.prediction==="good"?1-row.bad_score:row.bad_score):" · bad score "+numberValue(row.bad_score):"");}
  function render(c){
    catalog=c;$("clean-summary").textContent=Object.entries(c.counts).map(([label,n])=>`${label}: ${n}`).join(" · ")+(c.assessment?" · "+Object.entries(c.comparison_counts).map(([k,n])=>`${k.toUpperCase()}: ${n}`).join(" · "):"");
    selectOptions("clean-tray",[{value:"",label:"All trays"},...Object.keys(c.trays).sort().map(value=>({value,label:value}))],"All trays");
    const host=$("clean-gallery");host.className=c.items.length?"clean-gallery":"empty";
    host.innerHTML=c.items.length?c.items.map((row,i)=>`<button class="clean-thumb ${row.comparison||""}" data-clean-index="${i}"><img src="${escapeHtml(row.image_url)}" loading="lazy" alt="${escapeHtml(row.relative_path)}"><span><b>MY TAG · ${escapeHtml(row.label.toUpperCase())} · ${escapeHtml(row.tray)}</b>${escapeHtml(row.relative_path)}${assisted()?`<small>${escapeHtml(modelTag(row.model))}${row.comparison?" · "+row.comparison.toUpperCase():""}</small>`:""}</span></button>`).join(""):"No images match these filters.";
    $("clean-page").textContent=`Page ${c.pagination.page} / ${c.pagination.pages} · ${c.pagination.total} images`;
    $("clean-page-prev").disabled=c.pagination.page<=1;$("clean-page-next").disabled=c.pagination.page>=c.pagination.pages;
  }
  function tags(){
    $("clean-current-label").textContent=item?"MY SAVED TAG · "+item.label.toUpperCase():"";
    $("clean-pending-label").textContent=pending?"PENDING · "+pending.label.toUpperCase()+" · ENTER TO SAVE":"";
    $("clean-pending-label").hidden=!pending;$("clean-commit").disabled=!pending||busy;
    $("clean-model-label").textContent=item?modelTag(item.model):"";$("clean-model-label").hidden=!assisted();
    for(const label of ["good","bad","review","unsuitable"])$("clean-"+label).classList.toggle("active",pending?.label===label);
    const row=item?.model;
    $("clean-model-evidence").hidden=!assisted();
    if(!assisted())return;
    if(!row||row.status!=="ok"){$("clean-model-evidence").textContent=row?.error||"Score this dataset using the selected decision, or load a saved assessment.";return;}
    const traces=row.stage_results||[];
    $("clean-model-evidence").innerHTML=traces.map(stage=>`<div class="clean-stage"><strong>${escapeHtml(stage.name||stage.candidate||"Model")}</strong><span>${escapeHtml(stage.predicted_class?.toUpperCase()||stage.status)} · BAD score ${numberValue(stage.score)} · threshold ${numberValue(stage.bad_threshold??stage.threshold)}${Number.isFinite(stage.good_threshold)?" · GOOD threshold "+numberValue(stage.good_threshold):""}</span><small>${escapeHtml(stage.score_type||"")}${stage.reason?" · "+escapeHtml(stage.reason):""}</small></div>`).join("")+`<p class="hint">${row.score_type==="workflow_decision"?"Workflow decisions combine stage votes; there is no single probability for the combined decision. ":""}The shown model scores are not calibrated certainty estimates. My saved tag is used for FN/FP comparison.</p>`;
  }
  async function open(indexValue,restore=null){
    const row=catalog?.items[indexValue];const sequence=++generation;pending=null;item=null;index=indexValue;tags();
    if(!row){index=-1;$("clean-title").textContent="No image selected";$("clean-image").hidden=true;window.ImageInspector?.open("clean","");return;}
    busy=true;$("clean-viewport").setAttribute("aria-busy","true");$("clean-title").textContent=row.relative_path;
    if(window.ImageInspector)window.ImageInspector.open("clean",row.image_url);else{$("clean-image").src=row.image_url;$("clean-image").hidden=false;}
    document.querySelectorAll("[data-clean-index]").forEach(card=>card.classList.toggle("active",Number(card.dataset.cleanIndex)===indexValue));
    try{const details=await api("/api/cleaning/item?"+new URLSearchParams({...payload(),relative:row.relative_path}));if(sequence!==generation)return;item={...row,...details};if(restore?.relative===item.relative_path&&restore.sha256===item.sha256)pending=restore;}
    finally{if(sequence===generation){busy=false;$("clean-viewport").setAttribute("aria-busy","false");tags();remember();}}
  }
  async function load(page=1,retain=false){if(!catalog)return;const old=item?.relative_path,staged=pending;render(await api("/api/cleaning?"+new URLSearchParams({...payload(),page})));const next=retain?catalog.items.findIndex(row=>row.relative_path===old):-1;await open(next>=0?next:0,retain?staged:null);}
  async function step(direction){if(!catalog||busy)return;let next=index+direction;if(next<0&&catalog.pagination.page>1){render(await api("/api/cleaning?"+new URLSearchParams({...payload(),page:catalog.pagination.page-1})));next=catalog.items.length-1;}else if(next>=catalog.items.length&&catalog.pagination.page<catalog.pagination.pages){render(await api("/api/cleaning?"+new URLSearchParams({...payload(),page:catalog.pagination.page+1})));next=0;}if(next>=0&&next<catalog.items.length){if(pending)$("clean-status").textContent="Unsaved tag cleared when navigating. Use Enter to save a tag.";await open(next);}}
  function stage(label){if(!item||busy)return;pending={label,relative:item.relative_path,sha256:item.sha256};tags();remember();$("clean-status").textContent="Pending "+label.toUpperCase()+". Enter / Commit saves this tag; Escape cancels it.";}
  async function commit(){
    if(!pending||!item||busy)return;busy=true;tags();const old=index,next=catalog.items[index+1]?.relative_path;
    try{const result=await api("/api/cleaning/move",{...payload(),filter_label:$("clean-filter").value,relative:item.relative_path,label:pending.label,expected_sha256:pending.sha256});const saved=pending.label;pending=null;render(result.catalog);let nextIndex=catalog.items.findIndex(row=>row.relative_path===next);if(nextIndex<0)nextIndex=Math.min(old,catalog.items.length-1);await open(nextIndex);$("clean-status").textContent="Saved "+saved.toUpperCase()+". "+(result.move.unchanged?"Already in this folder.":"Undo is available.");}
    catch(error){notify(error.message,true);}
    finally{busy=false;tags();remember();}
  }
  function sourceValue(report){return JSON.stringify({kind:report.kind,source:report.source});}
  function assessmentOptions(){
    const source=$("clean-model").value;
    const rows=history.filter(row=>sourceValue(row)===source&&row.status==="completed");
    const previous=$("clean-assessment").value;
    selectOptions("clean-assessment",[{value:"",label:"No saved scores selected"},...rows.map(row=>({value:row.id,label:row.created_utc+" · "+row.completed+" images"}))],"No saved scores",previous);
    $("clean-assessment").disabled=!assisted();$("clean-score").disabled=!assisted()||!catalog;
    $("clean-comparison").disabled=!assisted()||!$("clean-assessment").value;
    if($("clean-comparison").disabled)$("clean-comparison").value="";
  }
  async function refreshHistory(){
    if(!catalog||polling)return;polling=true;
    try{const result=await api("/api/cleaning/assessments?"+new URLSearchParams({dataset:catalog.dataset,...scope()}));history=result.assessments;for(const row of history){const value=sourceValue(row);if(![...$("clean-model").options].some(option=>option.value===value)){const option=document.createElement("option");option.value=value;option.textContent="Saved assessment · "+row.name;$("clean-model").appendChild(option);}}const signature=JSON.stringify(history.map(r=>[r.id,r.status,r.completed,r.stage]));if(signature!==lastHistory){lastHistory=signature;const current=$("clean-assessment").value;assessmentOptions();const active=history.find(row=>row.id===pendingAssessment);if(active){$("clean-assessment-status").textContent=active.status+" · "+active.completed+" / "+active.total+" images"+(active.stage?" · "+active.stage:"")+(active.error?" · "+active.error:"");if(active.status==="completed"){pendingAssessment="";$("clean-assessment").value=active.id;assessmentOptions();await load(catalog.pagination.page,true);}else if(["failed","stopped"].includes(active.status))pendingAssessment="";}else if(current!==$("clean-assessment").value)await load(catalog.pagination.page,true);}}
    finally{polling=false;}
  }
  async function openDataset(restore=false){
    const saved=restore?stored():{};generation++;pending=null;item=null;
    render(await api("/api/cleaning/open",{path:$("clean-root").value,...scope()}));history=[];lastHistory="";pendingAssessment=saved.root===catalog.path?saved.pending_assessment||"":"";$("clean-assessment").value="";
    await refreshHistory();if(saved.root===catalog.path){for(const [id,key]of [["clean-filter","label"],["clean-tray","tray"],["clean-search","search"],["clean-priority","priority"]])if(saved[key]!=null)$(id).value=saved[key];$("clean-model").value=saved.model||"";assessmentOptions();$("clean-assessment").value=saved.assessment||history.find(row=>row.id===saved.pending_assessment&&row.status==="completed")?.id||"";assessmentOptions();$("clean-comparison").value=$("clean-comparison").disabled?"":saved.comparison||"";render(await api("/api/cleaning?"+new URLSearchParams({...payload(),page:saved.page||1})));await open(Math.max(0,catalog.items.findIndex(row=>row.relative_path===saved.relative)),saved.pending);}
    else{assessmentOptions();await open(0);}remember();
  }
  on("clean-open",()=>openDataset(true));
  $("clean-gallery").addEventListener("click",event=>{const button=event.target.closest("[data-clean-index]");if(button&&!busy)open(Number(button.dataset.cleanIndex)).catch(e=>notify(e.message,true));});
  for(const id of ["clean-filter","clean-tray","clean-comparison","clean-priority"])$(id).addEventListener("change",()=>load().catch(e=>notify(e.message,true)));
  let searchTimer;$("clean-search").addEventListener("input",()=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>load().catch(e=>notify(e.message,true)),250);});
  on("clean-previous",()=>step(-1));on("clean-next",()=>step(1));on("clean-page-prev",()=>load(catalog.pagination.page-1));on("clean-page-next",()=>load(catalog.pagination.page+1));
  for(const label of ["good","bad","review","unsuitable"])on("clean-"+label,()=>stage(label));on("clean-commit",commit);
  on("clean-undo",async()=>{if(busy)return;busy=true;try{const result=await api("/api/cleaning/undo",payload());pending=null;render(result.catalog);await open(0);$("clean-status").textContent="Last dataset move undone.";}finally{busy=false;tags();}});
  $("clean-model").addEventListener("change",()=>{pendingAssessment="";$("clean-assessment").value="";assessmentOptions();const row=history.find(r=>sourceValue(r)===$("clean-model").value&&r.status==="completed");if(row)$("clean-assessment").value=row.id;assessmentOptions();load(1,true).catch(e=>notify(e.message,true));});
  $("clean-assessment").addEventListener("change",()=>{assessmentOptions();load(1,true).catch(e=>notify(e.message,true));});
  on("clean-score",async()=>{if(!catalog||!assisted())return;const chosen=JSON.parse($("clean-model").value);const result=await api("/api/action",{action:"cleaning-assess",dataset:catalog.dataset,...scope(),...chosen,device:$("clean-device").value});pendingAssessment=result.job.workspace_output.split(/[\\/]/).pop();$("clean-assessment-status").textContent="Scoring started. Dataset tags stay unchanged.";remember();await refresh();});
  document.addEventListener("keydown",event=>{
    if(activeTab!=="cleaning"||event.repeat||event.ctrlKey||event.metaKey||event.altKey||event.target.isContentEditable||["INPUT","TEXTAREA","SELECT"].includes(event.target.tagName)||document.querySelector("dialog[open]"))return;
    const labels={d:"good",f:"bad",x:"unsuitable",p:"review"};const key=event.key.toLowerCase();
    if(labels[key]){event.preventDefault();stage(labels[key]);}else if(event.key==="Enter"){event.preventDefault();commit();}else if(event.key==="Escape"&&pending){event.preventDefault();pending=null;tags();remember();$("clean-status").textContent="Pending tag cancelled.";}else if(["ArrowLeft","ArrowRight"].includes(event.key)){event.preventDefault();step(event.key==="ArrowLeft"?-1:1).catch(e=>notify(e.message,true));}
  });
  function stateChanged(state){
    const previous=$("clean-model").value,saved=stored();
    const sources=[...(state.decisions||[]).filter(row=>row.mode!=="scores_only").map(row=>({value:JSON.stringify({kind:"decision",source:row.path}),label:"Model decision · "+row.name})),...(state.workflows||[]).map(row=>({value:JSON.stringify({kind:"workflow",source:row.path}),label:"Inspection workflow · "+row.name}))];
    // Retain sources of saved assessments even if the experiment list is paginated.
    for(const row of history){const value=sourceValue(row);if(!sources.some(s=>s.value===value))sources.push({value,label:"Saved assessment · "+row.name});}
    selectOptions("clean-model",[{value:"",label:"No model · manual tagging only"},...sources],"Manual only",previous||(!catalog?saved.model||"":""));assessmentOptions();
    const workerBusy=(state.jobs||[]).some(job=>["running","unverified"].includes(job.status));$("clean-score").disabled=workerBusy||!catalog||!assisted();
    if(!catalog&&saved.root)$("clean-root").value=saved.root;
    if(catalog&&activeTab==="cleaning")refreshHistory().catch(e=>notify(e.message,true));
  }
  function reset(){generation++;catalog=null;item=null;index=-1;pending=null;busy=false;history=[];pendingAssessment="";lastHistory="";$("clean-image").hidden=true;$("clean-gallery").textContent="Open this target's dataset.";$("clean-model").value="";$("clean-assessment").value="";assessmentOptions();tags();}
  setInterval(()=>{if(catalog&&activeTab==="cleaning")refreshHistory().catch(e=>notify(e.message,true));},3000);
  return {stateChanged,reset,stage,commit,openDataset};
})();
