"""Compare complete inspection sessions on exactly the same labeled images.

Human review edits are intentionally excluded. These are descriptive results
on the submitted input folder, not an independent production qualification.
"""
from __future__ import annotations

import json
import math
from pathlib import Path


def _json(path, default=None):
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def _session(path):
    path = Path(path).resolve()
    summary = _json(path / "summary.json", {})
    metadata = _json(path / "review_session.json", {})
    if summary.get("status") not in ("completed", "completed_with_input_errors"):
        raise ValueError("Only completed inspection sessions can be compared.")
    from .review import read_records
    records = read_records(path)
    if not records:
        raise ValueError("The session has no completed image predictions.")
    identity, valid = {}, []
    for record in records:
        relative = record.get("relative_path")
        digest = record.get("file_sha256", record.get("sha256"))
        if not relative or not isinstance(digest, str) or len(digest) != 64:
            raise ValueError("Image content fingerprints are required for a fair comparison.")
        if relative in identity:
            raise ValueError("Duplicate image paths in the session records.")
        reference = record.get("reference_label")
        prediction = record.get("prediction")
        identity[relative] = (digest, reference)
        if prediction not in ("good", "bad", "review"):
            raise ValueError("Scores-only or incomplete image decisions cannot be compared as classifiers.")
        valid.append(record)
    return path, summary, metadata, identity, valid


def _metrics(records):
    from .review import decision_metrics
    met = decision_metrics(records)
    tp, fn, fp, tn = (met[key] for key in ("bad_detected_TP", "bad_passed_as_good_FN",
                                         "good_rejected_as_bad_FP", "good_accepted_TN"))
    # Balanced accuracy is selective, like accuracy. Coverage is returned beside
    # it; class-conditional operating rates retain all true-class denominators.
    return {**met, "TP": tp, "FN": fn, "FP": fp, "TN": tn,
            "balanced_accuracy": (tp / (tp + fn) + tn / (tn + fp)) / 2 if tp + fn and tn + fp else None,
            "predicted_bad_rate": sum(r["prediction"] == "bad" for r in records) / len(records) if records else None}


def compare_sessions(paths):
    """Return a fair end-to-end comparison, never read a run's final-test data."""
    if not isinstance(paths, (list, tuple)) or not 2 <= len(paths) <= 4:
        raise ValueError("Choose two to four completed inspection sessions.")
    resolved = [Path(p).resolve() for p in paths]
    if len(set(resolved)) != len(resolved):
        raise ValueError("Choose different inspection sessions.")
    loaded = [_session(p) for p in resolved]
    expected = loaded[0][3]
    invalid_counts = [s.get("invalid_images", 0) for _, s, _, _, _ in loaded]
    if any(invalid_counts):
        raise ValueError("Sessions with invalid inputs cannot provide a complete comparison. Resolve the input errors and rerun.")
    if any(identity != expected for _, _, _, identity, _ in loaded[1:]):
        raise ValueError("Sessions must contain the same image paths, image bytes and original dataset labels.")
    sessions = []
    for path, summary, metadata, _, records in loaded:
        elapsed = summary.get("elapsed_seconds")
        if isinstance(elapsed, bool) or not isinstance(elapsed, (int, float)) or not math.isfinite(elapsed) or elapsed <= 0:
            elapsed = None
        sessions.append({"path": str(path), "name": path.name,
                         "kind": metadata.get("kind", "workflow" if (path / "applied_workflow.json").exists() else "classification"),
                         "status": summary["status"], "metrics": _metrics(records),
                         "elapsed_seconds": elapsed,
                         "images_per_second": len(records) / elapsed if elapsed else None})
    return {"comparable": True, "n_images": len(expected),
            "n_labeled": sessions[0]["metrics"]["n_labeled"], "reference": "dataset_labels",
            "sessions": sessions,
            "note": "Same submitted images and original labels. Review corrections are excluded. "
                    "Timing includes each session's setup and output copying. These results are not independent production qualification."}
