# VIG classification development plan

This workflow develops the VIG Good/Bad decision using reproducible experiments, independent physical-unit groups and a frozen final evaluation.

## Evaluation objectives

The reference inspection policy targets a bad escape rate of at most `1%` and a good rejection rate of at most `20%`. These are configured acceptance targets, not measured performance guarantees. Record confidence evidence and the number of independent Bad groups alongside point estimates. Aggregate accuracy alone does not establish acceptable inspection performance.

## Dataset preparation

1. Set `tasks.vig.dataset_root` to a labelled folder containing `good/` and `bad/` images.
2. Audit the dataset before training.
3. Resolve unreadable files, inconsistent image-depth assumptions, duplicate or conflicting labels, grouping failures and insufficient class counts per split.
4. Confirm physical-unit grouping. `tray_unit` is suitable only when tray/row/column identifies a unique unit. Reused tray slots across batches require a stronger group key or an explicit groups CSV.

## Baseline experiments

Run from the repository root in the active Python environment. Begin with a bounded CPU baseline:

```bash
python inspection.py audit --config project.yaml --profile laptop --task vig
python inspection.py search --config project.yaml --profile laptop --task vig --models resnet18 efficientnet_b0 --hours 2
```

After validating CUDA availability, a workstation baseline can use:

```bash
python inspection.py search --config project.yaml --profile workstation --task vig --models efficientnet_b0 convnext_tiny --hours 6 --device cuda
```

The same Python arguments apply in a Windows terminal with the project environment activated. Extended searches are described in [workstation search](WORKSTATION_50H.md).

## Experiment review

Review bad escapes first, followed by good false rejections. Distinguish label errors from model errors, and retain separate threshold, selection and final-test roles. Compare candidates using compatible evaluation records and freeze the selected decision before opening the final test.

Candidate branches include:

- `full_image` supervised training with exact VIG quarter-turn augmentation.
- `global_patches` for small defects missed by whole-image models.
- PatchCore-style detection when Bad examples are scarce or defect types vary.
- Two-threshold decisions when human review can reduce automatic decision errors.
- Decision Lab ensembles or guarded decisions after suitable source candidates have been independently compared.

## Data and evaluation controls

Keep final-test results outside threshold tuning and model selection. Apply augmentation during training instead of adding augmented copies to the source dataset. Retain separate TOP, BOTTOM and VIG decisions. Repeated captures of one physical unit are dependent observations. Any intensity-mapping change requires verified source sensor encoding and a consistent training/inference configuration.
