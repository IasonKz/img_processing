"""Conservative reference registration with four orientation hypotheses.

All photometric enhancements are temporary detection views. Registration uses a
similarity transform and records expected positions even when a pin is absent.
"""
from __future__ import annotations

import math
from pathlib import Path
import numpy as np
from ..image_io import load_rgb
from .geometry import normalize_template, template_to_rois, transform_points, roi_bounds, LOCALIZATION_VERSION


def _cv():
    try:
        import cv2
        return cv2
    except ImportError as exc:
        raise RuntimeError("ROI localization requires opencv-python-headless.") from exc


def _view(image):
    cv2 = _cv()
    values = np.asarray(image)
    gray = np.mean(values.astype(np.float32), axis=2) if values.ndim == 3 else values.astype(np.float32)
    low, high = np.percentile(gray,[1,99])
    gray = np.clip((gray-low)*255/max(float(high-low),1.),0,255).astype(np.uint8)
    return cv2.createCLAHE(clipLimit=2.,tileGridSize=(8,8)).apply(gray)


def _similarity(matrix):
    matrix = np.asarray(matrix,float)
    u, s, vt = np.linalg.svd(matrix[:2,:2])
    rotation = u @ vt
    if np.linalg.det(rotation) <= 0:
        raise ValueError("Reflected pose is not permitted.")
    if s.min() < 1e-8 or s.max()/s.min() > 1.12:
        raise ValueError("Registration is not a similarity transform.")
    result = np.eye(3)
    result[:2,:2] = rotation * float(np.mean(s))
    result[:2,2] = matrix[:2,2]
    return result


def _angle(matrix):
    return math.degrees(math.atan2(matrix[1,0],matrix[0,0])) % 360


def _angle_delta(a,b):
    return abs((a-b+180)%360-180)


def _initial(reference_size,image_size,quarter_turn=0):
    rw,rh = reference_size
    iw,ih = image_size
    scale = min((iw-1)/(rw-1),(ih-1)/(rh-1))
    angle = math.radians(quarter_turn*90)
    rotation = np.array([[math.cos(angle),-math.sin(angle)],[math.sin(angle),math.cos(angle)]])*scale
    translation = (np.array([iw,ih])-1)/2-rotation@((np.array([rw,rh])-1)/2)
    return np.array([[*rotation[0],translation[0]],[*rotation[1],translation[1]],[0,0,1]],float)


def _score(reference,target,warp):
    cv2 = _cv()
    height,width = reference.shape
    aligned = cv2.warpAffine(target,warp[:2].astype(np.float32),(width,height),flags=cv2.INTER_LINEAR|cv2.WARP_INVERSE_MAP)
    valid = cv2.warpAffine(np.ones_like(target,dtype=np.uint8),warp[:2].astype(np.float32),(width,height),flags=cv2.INTER_NEAREST|cv2.WARP_INVERSE_MAP).astype(bool)
    # Avoid borders and ignore areas outside the target image.
    valid[:3,:]=False; valid[-3:,:]=False; valid[:,:3]=False; valid[:,-3:]=False
    coverage = float(valid.mean())
    if coverage < .55 or valid.sum() < 64:
        return -1.,coverage
    a = cv2.GaussianBlur(reference,(7,7),0)[valid].astype(float)
    b = cv2.GaussianBlur(aligned,(7,7),0)[valid].astype(float)
    a -= a.mean(); b -= b.mean()
    correlation = float(np.dot(a,b)/max(np.linalg.norm(a)*np.linalg.norm(b),1e-10))
    return correlation,coverage


def _reference_candidates(reference,target,quarters):
    cv2 = _cv()
    # A bounded working resolution makes four ECC fits usable on a CPU.
    rh,rw = reference.shape; ih,iw = target.shape
    factor = min(1.,720/max(rw,rh,iw,ih))
    reference_small = cv2.resize(reference,(max(16,round(rw*factor)),max(16,round(rh*factor))))
    target_small = cv2.resize(target,(max(16,round(iw*factor)),max(16,round(ih*factor))))
    sh,sw = reference_small.shape; th,tw = target_small.shape
    reference_scale = np.diag([sw/rw,sh/rh,1.])
    target_scale = np.diag([tw/iw,th/ih,1.])
    candidates=[]
    initial=[]
    for quarter in quarters:
        initial.append((_initial([sw,sh],[tw,th],quarter),"ecc"))
    orb = cv2.ORB_create(nfeatures=1600,fastThreshold=8)
    k1,d1 = orb.detectAndCompute(reference_small,None)
    k2,d2 = orb.detectAndCompute(target_small,None)
    if d1 is not None and d2 is not None and len(k1)>=6 and len(k2)>=6:
        neighbors = cv2.BFMatcher(cv2.NORM_HAMMING).knnMatch(d1,d2,k=2)
        matches=[pair[0] for pair in neighbors if len(pair)==2 and pair[0].distance<.73*pair[1].distance]
        if len(matches)>=6:
            a=np.float32([k1[m.queryIdx].pt for m in matches]); b=np.float32([k2[m.trainIdx].pt for m in matches])
            fit,inliers=cv2.estimateAffinePartial2D(a,b,method=cv2.RANSAC,ransacReprojThreshold=3,maxIters=2000)
            if fit is not None and inliers is not None and inliers.sum()>=6:
                accepted=a[inliers.ravel().astype(bool)]
                spread=np.ptp(accepted,axis=0)/[sw,sh]
                angle=_angle(fit)
                if np.min(spread)>.18 and any(_angle_delta(angle,q*90)<30 for q in quarters):
                    initial.append((np.vstack([fit,[0,0,1]]),"orb_ecc"))
    for start,method in initial:
        angle=_angle(start)
        if not any(_angle_delta(angle,q*90)<35 for q in quarters):
            continue
        warp=start[:2].astype(np.float32)
        try:
            _,warp=cv2.findTransformECC(reference_small,target_small,warp,cv2.MOTION_AFFINE,
                (cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,70,1e-5),None,5)
            candidate=_similarity(np.vstack([warp,[0,0,1]]))
        except (cv2.error,ValueError):
            candidate=start
        scale=float(np.linalg.norm(candidate[:2,0]))
        expected=min(tw/sw,th/sh)
        if not .5*expected<=scale<=2*expected:
            continue
        if not any(_angle_delta(_angle(candidate),q*90)<35 for q in quarters):
            continue
        score,coverage=_score(reference_small,target_small,candidate)
        full=np.linalg.inv(target_scale)@candidate@reference_scale
        if any(_angle_delta(_angle(full),_angle(c["matrix"]))<8 and np.linalg.norm(full[:2,2]-c["matrix"][:2,2])<20 for c in candidates):
            existing=next(c for c in candidates if _angle_delta(_angle(full),_angle(c["matrix"]))<8 and np.linalg.norm(full[:2,2]-c["matrix"][:2,2])<20)
            if score>existing["score"]:
                existing.update(matrix=full,score=score,coverage=coverage,method=method)
        else:
            candidates.append({"matrix":full,"score":score,"coverage":coverage,"method":method})
    return sorted(candidates,key=lambda c:c["score"],reverse=True)


def _die_pose(gray,template,quarter):
    """Outline-only fallback. Cannot resolve a square die's orientation."""
    cv2=_cv()
    outline=template.get("outline")
    if outline is None:
        return None
    contours,_=cv2.findContours(cv2.Canny(gray,40,130),cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)
    h,w=gray.shape
    for contour in sorted(contours,key=cv2.contourArea,reverse=True):
        area=cv2.contourArea(contour)
        if not .12*w*h<area<.97*w*h:
            continue
        poly=cv2.approxPolyDP(contour,.03*cv2.arcLength(contour,True),True)
        if len(poly)!=4 or not cv2.isContourConvex(poly):
            continue
        box=cv2.boxPoints(cv2.minAreaRect(poly)).astype(float)
        center=box.mean(axis=0)
        angles=np.arctan2(box[:,1]-center[1],box[:,0]-center[0])
        box=box[np.argsort(angles)]
        box=np.roll(box,-int(np.argmin(box.sum(axis=1))),axis=0)
        source=np.asarray(outline,float)*(np.asarray(template["reference_size"])-1)
        if source.shape!=(4,2):
            return None
        target=np.roll(box,-int(quarter),axis=0)
        fit,_=cv2.estimateAffinePartial2D(source,target,method=cv2.LMEDS)
        if fit is not None:
            return np.vstack([fit,[0,0,1]])
    return None


def _circle_observations(gray,rois,confidence):
    cv2=_cv()
    for roi in rois:
        roi["confidence"]=round(float(confidence),4)
        if roi["shape"]!="circle":
            continue
        center=np.asarray(roi["points"][0]); radius=float(np.linalg.norm(np.asarray(roi["points"][1])-center))
        if radius<3:
            continue
        x0,y0=np.maximum(np.floor(center-radius*1.8).astype(int),0)
        x1,y1=np.minimum(np.ceil(center+radius*1.8).astype(int),[gray.shape[1],gray.shape[0]])
        if x1-x0<5 or y1-y0<5:
            continue
        region=gray[y0:y1,x0:x1]
        contours,_=cv2.findContours(cv2.Canny(region,50,130),cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)
        best=None
        for contour in contours:
            area=cv2.contourArea(contour); perimeter=cv2.arcLength(contour,True)
            if perimeter<=0 or area<math.pi*(radius*.55)**2 or area>math.pi*(radius*1.35)**2:
                continue
            circularity=4*math.pi*area/(perimeter*perimeter)
            (cx,cy),observed_radius=cv2.minEnclosingCircle(contour)
            observed=np.array([cx+x0,cy+y0])
            displacement=np.linalg.norm(observed-center)/radius
            if circularity>.65 and displacement<.65 and (best is None or circularity-displacement>best[0]):
                best=(circularity-displacement,observed,float(observed_radius))
        if best is not None and confidence>=.65:
            _,observed,r=best
            roi["observed_points"]=[observed.tolist(),(observed+[r,0]).tolist()]
            roi["source"]="detected"
        # Missing/occluded circles intentionally keep expected crop and inferred provenance.


def localize(image_path,template,reference_path=None,quarter_turn=None):
    template=normalize_template(template)
    if quarter_turn is not None and (isinstance(quarter_turn,bool) or int(quarter_turn)!=quarter_turn or int(quarter_turn) not in range(4)):
        raise ValueError("quarter_turn must be 0, 1, 2, 3 or null.")
    image=load_rgb(image_path); size=image.size
    gray=_view(image)
    reasons=[]; confidence=0.; ambiguity=True; method="template_only"; candidates=[]
    transform=_initial(template["reference_size"],size,int(quarter_turn or 0))
    if float(np.std(gray))<3:
        reasons.append("insufficient_image_contrast")
    elif reference_path is not None:
        reference=load_rgb(reference_path)
        if list(reference.size)!=template["reference_size"]:
            raise ValueError("Reference image dimensions do not match template reference_size.")
        reference_gray=_view(reference)
        if float(np.std(reference_gray))<3:
            reasons.append("insufficient_reference_contrast")
        else:
            candidates=_reference_candidates(reference_gray,gray,list(range(4)) if quarter_turn is None else [int(quarter_turn)])
            if candidates:
                best=candidates[0]; transform=best["matrix"]; method=best["method"]
                confidence=float(np.clip((best["score"]-.2)/.8,0,1)*min(best["coverage"]/.85,1))
                competitors=[c for c in candidates[1:] if _angle_delta(_angle(c["matrix"]),_angle(transform))>45]
                ambiguity=quarter_turn is None and bool(competitors) and best["score"]-competitors[0]["score"]<.06
                if quarter_turn is None and not competitors:
                    # Failure of the other hypotheses alone is not positive orientation evidence;
                    # asymmetric appearance of the reference supplies that evidence below.
                    ambiguity=False
                if ambiguity:
                    reasons.append("ambiguous_quarter_turn")
                if best["score"]<.65:
                    reasons.append("weak_reference_registration")
                if best["coverage"]<.85:
                    reasons.append("reference_partially_outside_image")
            else:
                reasons.append("reference_registration_failed")
    else:
        pose=_die_pose(gray,template,int(quarter_turn or 0))
        if pose is not None:
            transform=pose; confidence=.4; method="die_outline"
        reasons.append("reference_required_for_orientation_and_geometry_check")
    if template.get("starter"):
        reasons.append("starter_template_requires_calibration")
    if confidence<.7:
        reasons.append("low_localization_confidence")
    rois=template_to_rois(template,size,transform)
    _circle_observations(gray,rois,confidence)
    for roi in rois:
        bounds=roi_bounds(roi)
        if bounds[0]<0 or bounds[1]<0 or bounds[2]>=size[0] or bounds[3]>=size[1]:
            reasons.append("roi_outside_image:"+roi["id"])
    return {"version":LOCALIZATION_VERSION,"transform":transform.tolist(),"rois":rois,
            "confidence":round(confidence,4),"orientation_degrees":round(_angle(transform),4),
            "needs_review":bool(reasons),"reasons":list(dict.fromkeys(reasons)),"method":method,
            "orientation_manual":quarter_turn is not None,
            "candidates":[{"orientation_degrees":round(_angle(c["matrix"]),3),"score":round(c["score"],4)} for c in candidates]}
