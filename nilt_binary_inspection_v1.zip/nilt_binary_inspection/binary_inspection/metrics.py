from __future__ import annotations

from collections import defaultdict

import numpy as np
from scipy.stats import beta
from sklearn.metrics import average_precision_score, brier_score_loss, log_loss, roc_auc_score


def upper_binomial_bound(events: int, trials: int, confidence: float = 0.95) -> float | None:
    """One-sided exact Clopper-Pearson bound; IID Bernoulli assumption required."""
    if trials <= 0:
        return None
    if events < 0 or events > trials:
        raise ValueError("Invalid binomial counts")
    if events == trials:
        return 1.0
    return float(beta.ppf(confidence, events + 1, trials - events))


def safe_rate(numerator: int, denominator: int) -> float | None:
    return float(numerator / denominator) if denominator else None


def classification_metrics(labels, scores, decisions, groups=None, confidence: float = 0.95) -> dict:
    y, s, d = np.asarray(labels, int), np.asarray(scores, float), np.asarray(decisions, str)
    good, bad = y == 0, y == 1
    ng, nb = int(good.sum()), int(bad.sum())
    counts = {f"{label}_{decision.lower()}": int(((y == value) & (d == decision)).sum())
              for label, value in (("good", 0), ("bad", 1)) for decision in ("PASS", "REVIEW", "FAIL")}
    n_pass = int((d == "PASS").sum())
    output = {"images": len(y), "good": ng, "bad": nb, **counts,
              "bad_escape_rate": safe_rate(counts["bad_pass"], nb),
              "bad_escape_upper_bound_iid": upper_binomial_bound(counts["bad_pass"], nb, confidence),
              "good_false_fail_rate": safe_rate(counts["good_fail"], ng),
              "good_not_pass_rate": safe_rate(counts["good_fail"] + counts["good_review"], ng),
              "good_pass_rate": safe_rate(counts["good_pass"], ng),
              "bad_auto_fail_recall": safe_rate(counts["bad_fail"], nb),
              "bad_not_pass_rate_includes_review": safe_rate(counts["bad_fail"] + counts["bad_review"], nb),
              "review_rate": safe_rate(int((d == "REVIEW").sum()), len(y)),
              "pass_contamination_rate": safe_rate(counts["bad_pass"], n_pass),
              "correct_automatic_fraction": safe_rate(counts["good_pass"] + counts["bad_fail"], len(y)),
              "confidence_level": confidence,
              "ci_warning": "One-sided exact binomial bound assumes independent representative trials; not a certification"}
    finite = np.isfinite(s)
    if finite.sum() and len(np.unique(y[finite])) == 2:
        score = np.clip(s[finite], 1e-8, 1 - 1e-8)
        output.update({"average_precision": float(average_precision_score(y[finite], score)),
                       "roc_auc": float(roc_auc_score(y[finite], score)),
                       "brier": float(brier_score_loss(y[finite], score)),
                       "log_loss": float(log_loss(y[finite], score, labels=[0, 1]))})
    else:
        output.update({"average_precision": None, "roc_auc": None, "brier": None, "log_loss": None})
    if groups is not None:
        cluster = defaultdict(lambda: {"bad": False, "escaped": False})
        for label, decision, group in zip(y, d, groups):
            if label == 1:
                cluster[str(group)]["bad"] = True
                cluster[str(group)]["escaped"] |= decision == "PASS"
        n = sum(v["bad"] for v in cluster.values())
        k = sum(v["escaped"] for v in cluster.values())
        output.update({"bad_groups": n, "bad_groups_with_any_escape": k,
                       "bad_group_escape_rate": safe_rate(k, n),
                       "bad_group_escape_upper_bound_iid": upper_binomial_bound(k, n, confidence),
                       "group_bound_note": "Event is ANY BAD image escaping in a group, not per-image failure probability. Groups must themselves be independent"})
    return output


def reliability_bins(labels, scores, count: int = 10) -> list[dict]:
    y, scores = np.asarray(labels), np.asarray(scores)
    result = []
    for i in range(count):
        lo, hi = i / count, (i + 1) / count
        mask = np.isfinite(scores) & (scores >= lo) & ((scores < hi) if i + 1 < count else (scores <= hi))
        result.append({"lower": lo, "upper": hi, "n": int(mask.sum()),
                       "mean_score": float(scores[mask].mean()) if mask.any() else None,
                       "observed_bad_fraction": float(y[mask].mean()) if mask.any() else None})
    return result
