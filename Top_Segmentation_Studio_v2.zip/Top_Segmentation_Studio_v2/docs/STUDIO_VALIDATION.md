# Studio release validation

Validation date: 2026-09-24. All image-based tests used synthetic images, not company images. This verifies software behavior, not production segmentation performance.

## Executed

- Python: **73 tests passed, plus 31 subtests**. Includes the original v0.2 suite and new persistent-polygon, split isolation, Optuna continuation, mask reconstruction, test selection lock and export checks.
- JavaScript mask engine: raster geometry, labels, RLE, brush/erase, overlapping objects and visibility checks passed.
- Annotation controller plus actual HTTP server: 22 requests covering polygon ROI/detection, shapes, layers/delete, save/reopen, undo/redo, pan from background, skip/exclude/restore, and preservation of original file hashes.
- Real Chromium browser: integrated navigation; loading annotations in the same window; save/load custom polygon; launching an Optuna worker; two one-model/two-epoch CPU trials; chart/table display; validation evaluation; loading target/prediction overlays; exporting a PyTorch package. No page JavaScript errors.
- Model compatibility: all 20 bundled architecture/encoder pairs passed a CPU forward/backward check. 18 candidates were checked at 64 px; PAN and adapted DPT/DINOv2 were checked at 256 px. This is not an exhaustive check of every possible encoder, resolution, batch size or GPU.
- ONNX: Small U-Net checkpoint exported, passed the ONNX checker, and passed ONNX Runtime numerical comparison against PyTorch.
- Folder inference: all 12 synthetic top images produced native-size masks/overlays without decoding failures.
- Offline standalone HTML report generated successfully.
- Final visual inspection corrected a plot rendering restriction and replaced a WebGL-dependent parameter plot with an SVG-based equivalent.

## Limits

The execution environment was Linux/Python 3.12 on CPU. CUDA, Windows execution and long training runs on real production images were not exercised. Windows launchers use standard Python subprocess/path behavior and no Unix-only training shell commands, but should be checked on the target workstation. Additional custom SMP/timm pairs require Preflight. ONNX support depends on model operations and is validated per export.

The test runtime used torch 2.14.0, torchvision 0.29.0 and segmentation-models-pytorch 0.5.0. Requirements allow a compatible torch/torchvision pair >=2.5 / >=0.20. No pretrained weights were downloaded or used in tests. No trained production model is included.

Study continuation preserves the database, dataset and completed trials; exact mid-epoch resumption and restoration of Optuna sampler RNG state are not implemented. Last checkpoints retain model and optimizer data for inspection, but the UI starts another trial after an interruption. The annotation project retains old revision history when the saved boundary is applied in bulk.
