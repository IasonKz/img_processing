"use strict";
const $ = id => document.getElementById(id);
const escapeHtml = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const number = (v, digits=3) => v === null || v === undefined || v === "" || !Number.isFinite(Number(v)) ? "—" : Number(v).toFixed(digits);
const percent = v => v === null || v === undefined ? "—" : number(100 * Number(v), 1) + "%";
const duration = s => s===null || s===undefined || s==="" || !Number.isFinite(Number(s)) ? "—" : Math.max(0, Math.round(Number(s)/60)) + " min";
let boot, current, live, preview, token, polling = false, lastJobRun = null;
const descriptions = {
  setup:["Dataset & setup", "BUILD A RELIABLE BASELINE"], search:["Train & search", "FIND THE STRONGEST CANDIDATES"],
  compare:["Compare models", "EVIDENCE BEFORE SELECTION"], decision:["Decision explorer", "ONE CHECKPOINT, EXPLICIT DECISIONS"],
  predict:["Classify images", "APPLY A SAVED DECISION"], manage:["Models & reports", "REPRODUCIBLE AND PORTABLE"]
};
function notify(message, error=false) { $("notice").textContent=message; $("notice").className=error?"error":""; $("notice").hidden=false; }
async function api(path, data) {
  const opts = data ? {method:"POST",headers:{"Content-Type":"application/json","X-Inspection-Token":token},body:JSON.stringify(data)} : {};
  const response=await fetch(path,opts), result=await response.json();
  if(!response.ok) throw new Error(result.error || "Request failed");
  return result;
}
function selectOptions(id, items, empty, previous) {
  const element=$(id), old=previous ?? element.value;
  element.innerHTML=items.length ? items.map(item=>`<option value="${escapeHtml(item.value)}">${escapeHtml(item.label)}</option>`).join("") : `<option value="">${escapeHtml(empty)}</option>`;
  if(items.some(item=>item.value===old)) element.value=old;
}
function tab(name) {
  document.querySelectorAll(".tab").forEach(el=>el.classList.toggle("active",el.id==="tab-"+name));
  document.querySelectorAll("nav button").forEach(el=>el.classList.toggle("active",el.dataset.tab===name));
  $("page-title").textContent=descriptions[name][0]; $("page-eyebrow").textContent=descriptions[name][1];
}
function setup(data) {
  boot=data; token=data.token;
  selectOptions("task",data.tasks.map(value=>({value,label:value.toUpperCase()})),"No task",$("task").value||"vig");
  $("dataset").value=data.datasets[$("task").value]||"";
  $("output").value=data.paths.output; $("weights").value=data.paths.weights;
  $("config-path").textContent="Configuration: "+data.config;
  $("predict-input").value=data.paths.incoming; $("predict-output").value=data.paths.classified;
  $("package-output").value=data.paths.packages + (data.paths.packages.includes("\\")?"\\":"/") + "selected_model";
  $("models").innerHTML=data.models.map(model=>`<label><input type="checkbox" value="${escapeHtml(model)}">${escapeHtml(model)}</label>`).join("");
  profileModels();
  $("connection").textContent="Connected · 127.0.0.1";
}
function settings() { return {task:$("task").value,profile:$("profile").value}; }
function profileModels() {
  const defaults=boot.task_models?.[$("task").value]||boot.profile_models?.[$("profile").value]||["resnet18"];
  $("models").querySelectorAll("input").forEach(el=>{el.checked=defaults.includes(el.value);});
}
async function action(name, extra={}) {
  if(["search","audit"].includes(name) && $("dataset").value!==boot.datasets[$("task").value]) throw new Error("Save a configuration copy to apply the changed dataset path first.");
  if(["search","audit"].includes(name) && boot.task_enabled?.[$("task").value]===false) throw new Error("This task is disabled. Save its dataset settings first to enable it in a new configuration copy.");
  if(!["doctor","audit","search","classify"].includes(name) && !$("run-select").value) throw new Error("Choose an experiment first.");
  const result=await api("/api/action",{action:name,...settings(),run:$("run-select").value,...extra});
  notify("Operation started. Follow its progress and log below.");
  await refresh(); return result;
}
function table(id, columns, rows) {
  const element=$(id);
  if(!rows.length) { element.classList.add("empty");element.textContent="No recorded results yet.";return; }
  element.classList.remove("empty");
  element.innerHTML="<table><thead><tr>"+columns.map(c=>`<th>${escapeHtml(c[0])}</th>`).join("")+"</tr></thead><tbody>"+rows.map(row=>"<tr>"+columns.map(c=>`<td>${escapeHtml(typeof c[1]==="function"?c[1](row):row[c[1]])}</td>`).join("")+"</tr>").join("")+"</tbody></table>";
}
function plot(id, sets, xLabel="Epoch", limits=null) {
  const svg=$(id), all=sets.flatMap(s=>s.points).filter(p=>p.every(Number.isFinite));
  if(!all.length) {svg.innerHTML='<text x="280" y="110" text-anchor="middle">No recorded values yet</text>';return;}
  const left=47,right=541,top=20,bottom=178;
  let xmin=Math.min(...all.map(p=>p[0])), xmax=Math.max(...all.map(p=>p[0])), ymin=limits?limits[0]:Math.min(...all.map(p=>p[1])), ymax=limits?limits[1]:Math.max(...all.map(p=>p[1]));
  if(xmin===xmax) xmax=xmin+1;
  if(ymin===ymax) {ymin=Math.max(0,ymin-.05);ymax+=.05;}
  const X=v=>left+(v-xmin)/(xmax-xmin)*(right-left), Y=v=>bottom-(v-ymin)/(ymax-ymin)*(bottom-top);
  let html="";
  for(let i=0;i<5;i++){const v=ymin+(ymax-ymin)*i/4,y=Y(v);html+=`<line x1="${left}" y1="${y}" x2="${right}" y2="${y}" stroke="#e3eaf0"/><text x="${left-8}" y="${y+4}" text-anchor="end">${number(v,2)}</text>`;}
  for(let i=0;i<5;i++){const v=xmin+(xmax-xmin)*i/4;html+=`<text x="${X(v)}" y="195" text-anchor="middle">${number(v,xLabel==="Epoch"?0:3)}</text>`;}
  sets.forEach((s,i)=>{const pts=s.points.filter(p=>p.every(Number.isFinite));html+=`<polyline points="${pts.map(p=>X(p[0])+","+Y(p[1])).join(" ")}" stroke="${s.color}" stroke-width="2.5" fill="none"/>`;if(pts.length===1)html+=`<circle cx="${X(pts[0][0])}" cy="${Y(pts[0][1])}" r="3" fill="${s.color}"/>`;html+=`<text x="${left+i*170}" y="215" style="fill:${s.color}">${escapeHtml(s.name)}</text>`;});
  svg.innerHTML=html;
}
function chartHistory() {
  const item=$("history-select").value==="__live__" ? [...(current?.histories||[])].sort((a,b)=>b.updated-a.updated)[0] : current?.histories.find(h=>h.name===$("history-select").value), rows=item?.history||[];
  const points=key=>rows.filter(r=>r[key]!==null&&r[key]!==undefined&&r[key]!=="").map(r=>[Number(r.epoch),Number(r[key])]);
  plot("ap-chart",[{name:"Validation AP · bad",color:"#156ae8",points:points("val_pr_auc_bad")}],"Epoch",[0,1]);
  plot("loss-chart",[{name:"Train loss",color:"#156ae8",points:points("train_loss")},{name:"Validation loss",color:"#d17b20",points:points("val_loss")}]);
  const p=item?.progress||{}, last=rows.at(-1)||{};
  $("progress-detail").textContent=[item?.name,p.current_epoch?`Epoch ${p.current_epoch}/${p.total_epochs||"?"}`:null,p.batch?`Batch ${p.batch}/${p.batches||"?"}`:null,last.backbone_lr?`Backbone LR ${Number(last.backbone_lr).toExponential(2)}`:null,last.head_lr?`Head LR ${Number(last.head_lr).toExponential(2)}`:null,(p.stage||last.stage)?`Stage: ${p.stage||last.stage}`:null,p.ram_bytes?`RAM ${number(p.ram_bytes/2**30,2)} GiB`:null,p.vram_bytes?`VRAM ${number(p.vram_bytes/2**30,2)} GiB`:null,p.images_per_second?`${number(p.images_per_second,1)} images/s`:null,p.elapsed_seconds?`Recorded training ${duration(p.elapsed_seconds)}`:null].filter(Boolean).join("   ·   ");
}
function confusion(metrics) {
  if(!metrics||metrics.bad_detected_TP===undefined){$("confusion").className="empty";$("confusion").textContent="No selected candidate.";return;}
  $("confusion").className="cm";
  $("confusion").innerHTML='<div class="axis">True / predicted</div><div class="axis">Predicted bad</div><div class="axis">Predicted good</div><div class="axis">True bad</div>'+`<div class="correct"><strong>${metrics.bad_detected_TP}</strong>Detected · TP</div><div class="wrong"><strong>${metrics.bad_passed_as_good_FN}</strong>Escaped · FN</div>`+'<div class="axis">True good</div>'+`<div class="wrong"><strong>${metrics.good_rejected_as_bad_FP}</strong>Rejected · FP</div><div class="correct"><strong>${metrics.good_accepted_TN}</strong>Accepted · TN</div>`;
}
function renderRun(data) {
  current=data; const s=data.search||{};
  const remaining=s.status==="SEARCHING"&&s.deadline?Math.max(0,s.deadline-Date.now()/1000):s.remaining_seconds;
  $("search-summary").innerHTML=[[s.completed_trials,"Completed trials"],[s.pruned_trials,"Pruned trials"],[duration(remaining),"Time remaining"],[s.current_model||"—","Current architecture"]].map(([v,k])=>`<div><strong>${escapeHtml(v??"—")}</strong><span>${k}</span></div>`).join("");
  $("search-status").textContent=[s.status||data.state.status,s.stop_reason,s.failed_trials?`${s.failed_trials} failed trials`:null].filter(Boolean).join(" · ");
  table("trials-table",[["Architecture","model"],["Trial","trial"],["State","state"],["Outcome","outcome"],["Validation AP",r=>number(r.value)],["Time",r=>duration(r.seconds)]],data.trials);
  const hs=[{value:"__live__",label:"Follow current trial"},...data.histories.map(h=>({value:h.name,label:h.name}))];
  let choose=$("history-select").value;
  if(!hs.some(x=>x.value===choose)) choose="__live__";
  selectOptions("history-select",hs,"No trial history",choose);chartHistory();
  table("candidate-table",[["Candidate","name"],["AP · bad",c=>number(c.selection_metrics?.pr_auc_bad)],["Bad escape",c=>percent(c.selection_metrics?.bad_escape_rate)],["Good reject",c=>percent(c.selection_metrics?.good_reject_rate)],["Balanced acc.",c=>percent(c.selection_metrics?.balanced_accuracy)],["Accuracy",c=>percent(c.selection_metrics?.accuracy)],["Always-good acc.",c=>percent(c.selection_metrics?.always_good_accuracy)],["AP baseline",c=>number(c.selection_metrics?.constant_score_pr_auc_baseline)],["Both targets",c=>c.empirical_target_met?"MET on development splits":"NOT MET"]],data.candidates);
  confusion(data.selected.selection_metrics);
  $("selection-warning").textContent=data.selected.name ? `${data.selected.name}: ${data.selected.status||"Development selection"}. `+(data.selected.empirical_target_met?"Independent qualification is still required.":"The requested error targets are not jointly met. Adjusting a threshold cannot establish missing class separation.") : "A selected model is a development choice. Selection alone is not production qualification.";
  selectOptions("candidate",[{value:"selected",label:"Selected candidate"},...data.candidates.map(c=>({value:c.name,label:c.name}))],"No candidates");
  $("report-links").className=data.reports.length?"":"empty";
  $("report-links").innerHTML=data.reports.length?data.reports.map(r=>`<a class="report-link" href="${escapeHtml(r.url)}" target="_blank" rel="noopener">↗ ${escapeHtml(r.name)}</a>`).join(""):"No HTML reports saved yet.";
  $("run-path").textContent=data.path;
  const splitRows=Object.entries(data.splits).filter(([name,value])=>!name.startsWith("_")&&value.images).map(([name,value])=>({split:name,...value}));
  table("split-view",[["Split","split"],["Good images",r=>r.images.good||0],["Bad images",r=>r.images.bad||0],["Physical groups","groups"],["Trays",r=>Object.keys(r.trays||{}).join(", ")]],splitRows);
}
async function loadRun() {
  const run=$("run-select").value;
  if(!run) return;
  const data=await api("/api/run?"+new URLSearchParams({run}));renderRun(data);
}
async function refresh() {
  if(polling) return; polling=true;
  try {
    live=await api("/api/state");
    const old=$("run-select").value;
    selectOptions("run-select",live.runs.map(r=>({value:r.path,label:`${r.task||"?"} · ${r.name} · ${r.status}`})),"Choose an experiment",old);
    const job=live.jobs.at(-1), running=live.jobs.find(j=>j.status==="running");
    if(job?.run && job.run!==lastJobRun && live.runs.some(r=>r.path===job.run)){ $("run-select").value=job.run;lastJobRun=job.run;preview=null; }
    $("active-job").hidden=!running;
    if(running){$("job-title").textContent=running.action;$("job-meta").textContent=duration(Date.now()/1000-running.started)+(running.pause_requested?" · Pause requested":"");$("pause").hidden=!["search","resume-search"].includes(running.action);$("pause").disabled=!!running.pause_requested;}
    if(job){const log=$("console"), nearBottom=log.scrollHeight-log.scrollTop-log.clientHeight<70;log.textContent=job.lines.join("\n")||"Starting Python worker…";if(nearBottom)log.scrollTop=log.scrollHeight;$("log-status").textContent=`${job.action} · ${job.status}${job.exit_code!==undefined?" · exit "+job.exit_code:""}`;}
    selectOptions("decision-select",live.decisions.map(d=>({value:d.path,label:`${d.candidate||"model"} · ${d.mode}${d.threshold!==null&&d.threshold!==undefined?" · "+number(d.threshold,6):""} · ${d.name}`})),"Save a decision first");
    selectOptions("package-decision",[{value:"",label:"Run's original selected decision"},...live.decisions.filter(d=>d.source_run===$("run-select").value).map(d=>({value:d.path,label:`${d.candidate||"model"} · ${d.mode}${d.threshold!==null&&d.threshold!==undefined?" · "+number(d.threshold,6):""} · ${d.name}`}))],"Run's original selected decision");
    await loadRun(); $("connection").textContent="Connected · updated "+new Date().toLocaleTimeString();
  } catch(error){$("connection").textContent="Connection issue: "+error.message;} finally {polling=false;}
}
function modeChanged() {
  const mode=$("decision-mode").value;
  $("threshold-controls").hidden=mode!=="manual";
  $("mode-help").textContent={policy:"The policy fits calibration data. If both targets are infeasible, the result remains TARGET_NOT_MET.",manual:"Your threshold applies to this score scale. score ≥ threshold means bad. Saving creates a new decision version.",argmax:"Standard two-class classification uses the larger output. Equal softmax scores are treated as bad.",scores_only:"Scores are exported without class decisions. No confusion matrix or classification accuracy is calculated."}[mode];
  if(preview) updatePreview();
}
function activeThreshold() {
  const mode=$("decision-mode").value;
  return mode==="scores_only"?null:mode==="argmax"?.5:mode==="policy"?preview?.policy_decision?.threshold:Number($("threshold").value);
}
function updatePreview() {
  if(!preview) return;
  const mode=$("decision-mode").value, threshold=activeThreshold();
  if(mode==="argmax" && preview.score_type==="anomaly_distance") {$("preview-summary").textContent="Argmax does not apply to PatchCore anomaly scores. Choose policy, manual threshold or scores only.";$("gallery").textContent="";return;}
  const rows=preview.rows, nb=rows.filter(r=>r.true_class==="bad").length, ng=rows.length-nb;
  let fn=0,fp=0;
  for(const r of rows){if(r.true_class==="bad"&&r.score<threshold)fn++;if(r.true_class==="good"&&r.score>=threshold)fp++;}
  $("preview-summary").className="";
  $("preview-summary").innerHTML=threshold===null?`<p>${rows.length} calibration scores. Scores-only mode makes no good/bad decision.</p>`:`<div class="stats-grid">${[[percent(nb?fn/nb:null),"Bad escape"],[percent(ng?fp/ng:null),"Good reject"],[percent(nb&&ng?1-(fn/nb+fp/ng)/2:null),"Balanced accuracy"],[number(threshold,6),"Threshold"]].map(([v,k])=>`<div><strong>${v}</strong><span>${k}</span></div>`).join("")}</div><p class="hint">${fn} / ${nb} bad accepted · ${fp} / ${ng} good rejected · calibration only</p>`;
  plot("threshold-chart",[{name:"Bad escape",color:"#156ae8",points:preview.curve.map(r=>[r.threshold,r.bad_escape_rate])},{name:"Good reject",color:"#d17b20",points:preview.curve.map(r=>[r.threshold,r.good_reject_rate])}],"Threshold",[0,1]);
  const filter=$("gallery-filter").value;
  let gallery=rows.map(r=>({...r,predicted:threshold===null?null:r.score>=threshold?"bad":"good"}));
  if(filter==="errors") gallery=gallery.filter(r=>r.predicted&&r.predicted!==r.true_class);
  else if(filter!=="all") gallery=gallery.filter(r=>r.true_class===filter);
  gallery=gallery.slice(0,60);$("gallery").className="gallery"+(gallery.length?"":" empty");
  $("gallery").innerHTML=gallery.length?gallery.map(r=>`<div class="image-card">${r.image_url?`<a href="${escapeHtml(r.image_url)}" target="_blank" rel="noopener"><img src="${escapeHtml(r.image_url)}" alt="${escapeHtml(r.relative_path)}" loading="lazy"></a>`:"<div class='empty'>Image unavailable at configured path</div>"}<div class="image-caption ${r.predicted&&r.predicted!==r.true_class?"error":""}"><b>True ${escapeHtml(r.true_class)}${r.predicted?" → "+r.predicted:""}</b>Score ${number(r.score,5)}<br>${escapeHtml(r.relative_path)}</div></div>`).join(""):"No images match this filter. Scores-only mode has no decision errors.";
}
async function loadPreview() {
  if(!$("run-select").value) throw new Error("Choose a finalized experiment first.");
  preview=await api("/api/preview?"+new URLSearchParams({run:$("run-select").value,candidate:$("candidate").value}));
  const scores=preview.rows.map(r=>r.score), lo=Math.min(...scores), hi=Math.max(...scores), span=Math.max(hi-lo,1e-6), slider=$("threshold-slider");
  slider.min=String(lo-span*.01);slider.max=String(hi+span*.01);slider.step=String(span/1000);
  $("threshold").value=String(preview.threshold);slider.value=String(preview.threshold);updatePreview();
}
function bind(id,fn){$(id).addEventListener("click",async()=>{try{await fn();}catch(error){notify(error.message,true);}});}
document.querySelectorAll("nav button").forEach(button=>button.addEventListener("click",()=>tab(button.dataset.tab)));
$("task").addEventListener("change",()=>{$("dataset").value=boot.datasets[$("task").value]||"";profileModels();});
$("profile").addEventListener("change",()=>{const h=boot.profiles[$("profile").value];$("hours").max=h;$("hours").value=h;profileModels();});
$("run-select").addEventListener("change",async()=>{preview=null;$("preview-summary").textContent="Load scores for this candidate.";$("gallery").textContent="";try{await loadRun();}catch(e){notify(e.message,true);}});
$("history-select").addEventListener("change",chartHistory);
$("decision-mode").addEventListener("change",modeChanged);
$("candidate").addEventListener("change",()=>{preview=null;$("preview-summary").textContent="Load scores for this candidate.";$("gallery").textContent="";});
$("gallery-filter").addEventListener("change",updatePreview);
$("threshold-slider").addEventListener("input",()=>{$("threshold").value=$("threshold-slider").value;updatePreview();});
$("threshold").addEventListener("input",()=>{$("threshold-slider").value=$("threshold").value;updatePreview();});
bind("save-config",async()=>{setup(await api("/api/config",{task:$("task").value,dataset:$("dataset").value,output:$("output").value,weights:$("weights").value}));notify("Saved a new configuration copy. The original configuration is unchanged.");await refresh();});
bind("doctor",()=>action("doctor"));bind("audit",()=>action("audit"));
bind("start-search",async()=>{await action("search",{models:[...$("models").querySelectorAll("input:checked")].map(e=>e.value),hours:Number($("hours").value)});tab("search");});
bind("resume-search",()=>action("resume-search"));
bind("pause",async()=>{const result=await api("/api/pause",{run:$("run-select").value});notify(result.message);await refresh();});
bind("pause-selected",async()=>{const result=await api("/api/pause",{run:$("run-select").value});notify(result.message);await refresh();});
bind("refresh",refresh);
bind("finalize-search",()=>action("finalize-search"));
bind("load-preview",loadPreview);
bind("save-decision",async()=>{if($("decision-mode").value==="argmax"&&preview?.score_type==="anomaly_distance")throw new Error("PatchCore needs policy, manual threshold or scores only.");await action("decision",{mode:$("decision-mode").value,candidate:$("candidate").value,threshold:Number($("threshold").value),output:boot.paths.decisions});});
bind("classify",()=>action("classify",{decision:$("decision-select").value,input:$("predict-input").value,output:$("predict-output").value,device:$("predict-device").value,labeled:$("labeled").checked,copy_images:$("copy-images").checked}));
bind("refresh-report",()=>action("report"));
bind("open-folder",async()=>{if(!$("run-select").value)throw new Error("Choose an experiment first.");const result=await api("/api/open-folder",{path:$("run-select").value});notify(result.message);});
$("package-kind").addEventListener("change",()=>{$("package-decision").disabled=$("package-kind").value!=="inference";if($("package-decision").disabled)$("package-decision").value="";});
bind("package",()=>action("package",{output:$("package-output").value,kind:$("package-kind").value,decision:$("package-decision").value}));
(async()=>{try{setup(await api("/api/bootstrap"));modeChanged();await refresh();setInterval(refresh,3000);}catch(error){notify("Cannot start dashboard: "+error.message,true);}})();
