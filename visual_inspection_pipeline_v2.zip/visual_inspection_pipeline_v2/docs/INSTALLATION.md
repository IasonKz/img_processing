# Installation and Offline Provisioning

## Environment policy

The source requires Python 3.10 or later. Python 3.11 is a conservative environment choice when preparing compatible wheels. The actual delivery environment and executed checks are listed in [VALIDATION_REPORT.md](VALIDATION_REPORT.md); dependency version ranges alone do not certify every available combination or target operating system.

Use a separate virtual environment for this application. Install a compatible `torch`/`torchvision` pair from the same official wheel family. Do not combine a CPU `torch` build with an unrelated CUDA `torchvision` build. Select the GPU wheel source for the installed driver and operating system using the [official PyTorch installer](https://pytorch.org/get-started/locally/).

| Environment | Dependencies |
| --- | --- |
| Data audit and reporting | `requirements.txt` |
| Training and PyTorch inference | Base dependencies plus matched `torch` and `torchvision` |
| ONNX export and parity verification | Training environment plus `requirements-export.txt` |
| Standalone CPU inference | `requirements-runtime.txt`; no PyTorch required |

## Create an environment

Windows PowerShell:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip "setuptools>=68,<81" "wheel>=0.41,<1"
```

If local PowerShell policy disallows activation, run the commands with `.\.venv\Scripts\python.exe` directly; changing system policy is unnecessary. Windows Command Prompt may use `.venv\Scripts\activate.bat`.

Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip "setuptools>=68,<81" "wheel>=0.41,<1"
```

## CPU training environment

The following commands provision a CPU wheel family on Windows or Linux with a matching supported Python interpreter:

```bash
python -m pip install "torch>=2.5,<3" "torchvision>=0.20,<1" --index-url https://download.pytorch.org/whl/cpu
python -m pip install -r requirements.txt
python -m pip install -r requirements-export.txt
python -m pip install -e . --no-deps
python -m pip check
```

The export requirements are optional if only training is required. Do not run `requirements-training.txt` as a second generic reinstall after selecting a GPU wheel family; preserve the matched pair already installed.

## GPU training environment

1. Identify the workstation's NVIDIA GPU and installed driver.
2. Obtain the matched PyTorch installation command from the official installer for that operating system and supported CUDA wheel family.
3. Execute that command in the application environment. `torchaudio` is not required for this project.
4. Install the application dependencies:

```bash
python -m pip install -r requirements.txt
python -m pip install -r requirements-export.txt
python -m pip install -e . --no-deps
python -m pip check
python scripts/check_environment.py --require train --json environment.json
```

The workstation profile must report a usable configured device before training. GPU availability cannot be inferred from the presence of a package whose name includes CUDA.

## Provision pretrained weights

On an authorized internet-connected machine with PyTorch and torchvision installed:

```bash
python inspection.py download-weights --config project.yaml --profile workstation
```

The destination is the configured weights directory. Copy that complete directory to the offline system and configure `weights_root` accordingly. For a ResNet18-only pilot, use `--profile laptop`. PatchCore uses the weight file for its configured ResNet backbone; it does not require an Anomalib installation. The standalone `download_weights.py --output ./weights --models resnet18` command is also available for explicitly selecting public weight files.

| Backbone | Torchvision weight identifier | Expected local filename |
| --- | --- | --- |
| ResNet18 | `IMAGENET1K_V1` | `resnet18__IMAGENET1K_V1.pth` |
| ResNet50 | `IMAGENET1K_V2` | `resnet50__IMAGENET1K_V2.pth` |
| EfficientNet-B0 | `IMAGENET1K_V1` | `efficientnet_b0__IMAGENET1K_V1.pth` |
| ConvNeXt-Tiny | `IMAGENET1K_V1` | `convnext_tiny__IMAGENET1K_V1.pth` |
| Swin-T | `IMAGENET1K_V1` | `swin_t__IMAGENET1K_V1.pth` |

The download command retrieves public weights and records their SHA-256 values. It does not read or upload inspection images. Audit, training, and prediction load local resources and do not automatically download missing weights. `pretrained: false` is reserved for diagnostic/random-initialization experiments and is recorded in the run configuration.

## Offline wheel provisioning

Prepare a wheelhouse on a connected machine matching the destination operating system, architecture, Python minor version, and intended CPU/CUDA family. A Linux wheelhouse cannot be assumed to install on Windows.

For a CPU destination:

```bash
python -m pip download --only-binary=:all: --dest wheelhouse "torch>=2.5,<3" "torchvision>=0.20,<1" --index-url https://download.pytorch.org/whl/cpu
python -m pip download --only-binary=:all: --dest wheelhouse -r requirements.txt -r requirements-export.txt "setuptools>=68,<81" "wheel>=0.41,<1"
```

For a CUDA destination, substitute the approved CUDA wheel source in the first command. Retain all wheel dependencies downloaded by pip. On the offline destination, from the copied application directory:

```bash
python -m pip install --no-index --find-links ./wheelhouse -r requirements-training.txt -r requirements-export.txt
python -m pip install --no-index --find-links ./wheelhouse -e . --no-deps --no-build-isolation
python -m pip check
```

Install the local `setuptools` and `wheel` wheels first if the destination environment lacks the build requirements. Keep pretrained weights separate from Python wheels. A full offline transfer consists of the application, the wheelhouse, the weights directory, and the authorized image dataset or deployment package.

## Record a qualified environment

After installation and local acceptance checks:

```bash
python -m pip freeze > environment-lock.txt
python scripts/check_environment.py --json environment.json
```

Keep both files with the machine's acceptance record. A freeze file records resolved package versions but does not by itself preserve driver versions, wheel origins, operating system, or GPU compatibility. Retain the actual wheelhouse for reproducible offline reinstalls.

## Standalone ONNX CPU inference

On the receiving computer, install `requirements-runtime.txt` from the application release or the equivalent runtime requirements shipped in the exported package. The standalone package runner needs only NumPy, Pillow, and ONNX Runtime.

CUDA ONNX inference requires a compatible `onnxruntime-gpu` installation and matching runtime dependencies; do not install CPU and GPU ONNX Runtime distributions into one environment. Follow the [ONNX Runtime installation documentation](https://onnxruntime.ai/docs/install/). Export-time CPU parity does not certify a new CUDA provider; recheck reference-image decisions on the destination hardware.
