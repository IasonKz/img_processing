"""Run on the workstation after installing PyTorch. Uses synthetic images, no downloads.

python -m unittest discover -s tests -p test_torch.py -v
"""
import importlib.util
from pathlib import Path
import tempfile
import unittest

import numpy as np
from PIL import Image
import yaml

TORCH_AVAILABLE = importlib.util.find_spec("torch") is not None and importlib.util.find_spec("torchvision") is not None


@unittest.skipUnless(TORCH_AVAILABLE, "PyTorch/torchvision not installed")
class TorchIntegrationTests(unittest.TestCase):
    def test_all_architectures_forward_backward(self):
        import gc
        import torch
        from nilt.engine import WEIGHTS, make_model
        torch.set_num_threads(2)
        for name in WEIGHTS:
            with self.subTest(model=name):
                model, _ = make_model(name)
                model.eval()
                x = torch.randn(1, 3, 64, 64)
                y = model(x)
                self.assertEqual(tuple(y.shape), (1, 2))
                y.sum().backward()
                self.assertTrue(torch.isfinite(y).all())
                del model, x, y
                gc.collect()

    def test_full_train_export_predict_and_incremental_lifecycle(self):
        from nilt.workflow import new_run, run_training, final_test, predict_folder
        from nilt.common import DEFAULTS, merge_dict, read_json
        from nilt.data import read_manifest
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            data = tmp / "data"
            rng = np.random.default_rng(55)
            for label in ("good", "bad"):
                (data / label).mkdir(parents=True)
                for i in range(30):
                    arr = rng.integers(0, 40, (64, 64, 3), dtype=np.uint8)
                    if label == "bad":
                        arr[20:45, 20:45] = 230
                    Image.fromarray(arr).save(data / label / f"{i}.png")
            cfg = merge_dict(DEFAULTS, yaml.safe_load(
                (Path(__file__).resolve().parents[1] / "configs" / "top.yaml").read_text(encoding="utf-8")))
            cfg.update(data_root=str(data), output_root=str(tmp / "runs"), weights_dir=str(tmp / "weights"),
                       pretrained=False, image_size=64, models=["resnet18"], seeds=[42],
                       device="cpu", cpu_threads=2, ensembles=False, near_duplicate_distance=-1)
            cfg["training"].update(epochs=1, warmup_epochs=0, batch_size=4, eval_batch_size=4,
                                   accumulation_steps=1, amp=False)
            path = tmp / "config.yaml"
            path.write_text(yaml.safe_dump(cfg))
            run = run_training(new_run(path))
            selected = read_json(run / "selected.json")
            self.assertEqual(selected["task"], "top")
            self.assertTrue((run / "comparison_folders" / selected["name"] / "predicted" / "good").is_dir())
            first_test = final_test(run)
            self.assertIn("bad_passed_as_good_FN", first_test["metrics"])
            with self.assertRaises(ValueError):
                final_test(run)
            predict_folder(run, data, tmp / "predictions", labeled=True)
            self.assertEqual(read_json(tmp / "predictions" / "prediction_summary.json")["n_classified"], 60)
            # New independent data is added while all old images remain available.
            for label in ("good", "bad"):
                for i in range(8):
                    Image.fromarray(rng.integers(0, 255, (64, 64, 3), dtype=np.uint8)).save(data / label / f"new_{i}.png")
            cfg["previous_run"] = str(run)
            path.write_text(yaml.safe_dump(cfg))
            updated = run_training(new_run(path))
            names = [c["name"] for c in read_json(updated / "candidates.json")]
            self.assertIn("incumbent_frozen", names)
            self.assertTrue(any("finetune" in name for name in names))
            a = {r["pixel_hash"]: r["split"] for r in read_manifest(run / "manifest.csv")}
            b = {r["pixel_hash"]: r["split"] for r in read_manifest(updated / "manifest.csv")}
            self.assertTrue(all(b[k] == v for k, v in a.items()))
            result = final_test(updated)
            self.assertTrue(result["test_used_in_previous_generation"])
            self.assertFalse(result["statistical_target_supported"])


if __name__ == "__main__":
    unittest.main()
