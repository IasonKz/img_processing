# Daily operator guide

## Prepare the workspace

Open `Start.cmd` on Windows or `bash Start.sh` on Linux and keep its console open. The browser address is local to the same computer. The active experiment selector determines which recorded training run is shown; changing the selector does not start training.

In **Dataset & setup**, confirm the source dataset, results, and pretrained-weight folders. Use **Check installation** before the first training run on each computer. Public-weight downloads require an online connection; later training and inference use local files.

The source dataset contains trusted `good` and `bad` labels. Keep model outputs outside that folder. Never use a model's predicted folders as ground truth without a separate review.

## Train and monitor

1. In **Train & search**, choose `laptop`, `workstation`, or `workstation_large` and the model families to search.
2. Set the total time allowance. It is shared across the selected families. Profile values are editable suggestions; Custom Optuna has no profile-specific ceiling and can select CPU/CUDA/Auto independently.
3. Start one search. The software records a new experiment and immutable grouped split.
4. Watch completed epochs, the selected validation objective and AP, learning rates, stage, image throughput, and memory. A batch counter is progress through the current epoch, not a parameter search result.
5. Inspect the trial list and operation log. A failed trial needs its recorded error; it is not equivalent to pruning.

For manual search control, choose **Custom Optuna**, load the profile defaults, and set strategy/stopping, training, hyperparameter space, and optional image strategy. Use **Validate & preview contract** before starting. **Load profile defaults** resets the custom draft; it does not edit a saved experiment. See [CUSTOM_OPTUNA.md](CUSTOM_OPTUNA.md).

Training loss and validation loss may use different class weighting. Compare trends with that distinction in mind. Validation AP measures score ranking and is not classification accuracy at threshold 0.5.

**Pause active search** requests a stop. Wait until the worker reports it has stopped before moving files or replacing source code. Closing the browser or dashboard console is not a reliable stop for independently running jobs.

**Resume selected search** uses the original run and remaining budget. **Start Optuna search** creates a new experiment. Adding more model families or changing the configured training policy is a new experiment, not an edit to recorded history.

## Compare candidates

Open **Compare models** after candidates and comparison data exist. Inspect both bad escape and good reject, the number of evaluated images, balanced accuracy, ranking metrics, and processing cost. A high overall accuracy can result from accepting every image in a mostly-good dataset.

Use the combined model plots to compare AP, balanced accuracy, both error rates, and confusion matrices side by side. Search analytics show completed-objective history, learning curves, timing, and parameter relationships. A visual relationship is not proof that one parameter caused the improvement. See [SEARCH_AND_COMPARISON_CHARTS.md](SEARCH_AND_COMPARISON_CHARTS.md).

Only compare results that use compatible data and evaluation roles. Selection results support development choices. A final production claim requires representative independent evidence after the complete decision has been frozen.

## Save a decision

In **Decision explorer**, choose a completed candidate and one mode:

- **Automatic policy:** attempts both configured error limits.
- **Manual threshold:** explores a chosen bad-score boundary.
- **Standard classifier / argmax:** applies the supervised classifier's binary decision, equivalent to a 0.5 softmax boundary.
- **Scores only:** records a score without a class decision.

The explorer uses calibration data. Save the decision when the rule is settled. Previewing a threshold does not silently change an existing saved decision or the original selected model. PatchCore distances require their own threshold scale and cannot use argmax.

An infeasible policy is shown as unmet. Changing the threshold cannot create class separation that the model has not learned.

## Add review decisions or model combinations

Use **Decision lab** for a single-model Good/Review/Bad rule, weighted ensemble, held-out logistic stacking, or confidence cascade. Add finalized candidates sharing the same manifest. Set thresholds, weights/stages, and optional score calibration. Preview calibration performance, then freeze a new system before inspecting its separately labeled selection report.

Sweep and Optuna decision tuning work on fixed cached scores, not fresh image-model training. Learned stacking uses group-disjoint calibration-fit/tune subsets, not an automatic OOF neural-network training cycle. The target limits can remain infeasible. See [DECISION_LAB.md](DECISION_LAB.md).

The saved system can be selected in **Classify images**. REVIEW is an abstention that creates manual workload; it is not a correct prediction. Review rate, automatic coverage, and bad/good error counts must be read together.

## Classify and review

In **Classify images**, load a saved decision and choose the input folder. Select labeled input only when its `good`/`bad` folders contain your reference labels. Enable image copies for visual review. Start classification and open **Image review** to inspect records as they arrive.

Review shows prediction beside the original reference tag. Filter disagreements, actual bad accepted as good, or actual good rejected as bad. Apply an operator tag and optional note where a human review is needed. Original tags and model predictions remain recorded separately.

The copied output is a review artifact. Original images are neither moved nor relabeled. See [IMAGE_REVIEW.md](IMAGE_REVIEW.md) for metric scopes and data handling.

For the next fine-tuning cycle, use **Review to training** to export explicit human labels into a new revision. Select a source experiment and retain replay for a training-ready update. Protected holdout content/groups cannot enter training. The original source labels and prediction records remain unchanged.

## Build an inspection sequence

In **Inspection workflow**, add saved decisions as stages, set their order, and choose the final rule. Every stage has its own saved threshold/mode. Save a new recipe, then run it on a folder.

- **Any bad:** reject when a stage predicts bad; later stages are skipped for that image.
- **All bad:** reject only when every stage predicts bad; a good result ends the sequence for that image.
- **Majority:** execute all stages; ties reject as bad.

Inspect the per-image stage trace and final prediction in review. Evaluate the composed result against reference tags; improvements are not implied by adding stages. See [WORKFLOWS.md](WORKFLOWS.md).

## Reports and retained evidence

Use **Models & reports** to inspect saved experiments, decisions, logs, and reports. Preserve the complete experiment and decision folders with their integrity records. Keep your source data revision separately. For transfer to another computer, use a training package and restore against the matching dataset, or export a complete inference package.

The [command reference](CLI_REFERENCE.md) provides the equivalent operations for repeatable local scripts.
