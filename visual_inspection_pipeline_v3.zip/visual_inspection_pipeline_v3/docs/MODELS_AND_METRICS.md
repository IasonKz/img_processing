# Models, Data Roles, and Performance Metrics

## Operating objective

The primary objective is to constrain defective images accepted as good. Among candidates satisfying the configured defect-escape target, model selection favors retention of conforming images. Accuracy alone is not the selection objective.

Stored labels are `bad=0` and `good=1`. Reporting treats a defect as the positive event. Scores have a consistent direction: larger values mean stronger evidence for rejection.

| Actual | Predicted | Metric term |
| --- | --- | --- |
| bad | bad | True positive (TP), detected defect |
| bad | good | False negative (FN), defect escape |
| good | bad | False positive (FP), false rejection |
| good | good | True negative (TN), accepted conforming image |

For a fixed threshold, `score >= threshold` means `bad`. Equality is rejected. Thresholds belong to a complete model version; they are not interchangeable between architectures or preprocessing revisions.

## Candidate methods

| Model | Learning data | Role |
| --- | --- | --- |
| ResNet18 | Training good and bad | Small supervised baseline |
| ResNet50 | Training good and bad | Larger residual network |
| EfficientNet-B0 | Training good and bad | Compact alternative CNN |
| ConvNeXt-Tiny | Training good and bad | Modern convolutional alternative |
| Swin-T | Training good and bad | Windowed transformer alternative |
| PatchCore-style detector | Training good only | Anomaly detection when defect examples are scarce |

Supervised candidates fine-tune pretrained feature extractors and a two-class head. The output used for selection is the bad-class softmax score. A score between zero and one is not necessarily a calibrated probability of a defect. Performance depends on the image domain, label quality, input geometry, and available independent examples.

The laptop profile reduces the model roster and training budget. It does not silently resize images or substitute a different architecture when running an existing model. The workstation profile evaluates a broader roster and multiple seeds. Profile names are execution settings, not evidence of model quality.

### PatchCore implementation

This release implements a **PatchCore-style variant**, rather than a bit-for-bit reproduction of the published reference implementation. It uses a frozen ResNet18 or ResNet50 backbone, combines intermediate spatial features, samples a bounded reservoir of training-good patch features, and selects a representative coreset using a projected greedy distance procedure. The saved memory bank contains features in the original scoring space.

For inference, each query patch receives its nearest-memory-feature Euclidean distance. The image anomaly score is the maximum patch distance. Original PatchCore neighborhood reweighting is not implemented. Scores are finite nonnegative distances and are not constrained to the interval zero to one. The selected threshold is tuned for this scoring rule.

Only training-good images enter the memory bank. Validation, threshold, selection, and test good images must remain excluded. Adding good examples requires a new candidate bank and threshold evaluation; it does not update an active release in place.

The anomaly model can identify unusual appearances without seeing that defect type in training. It can also reject rare but acceptable variations, shadows, or focus differences. Good training data must represent the accepted variation in the process. A heatmap, when exported by a backend, is an anomaly visualization, not a defect-type label or a verified segmentation boundary.

## Input geometry and augmentation

The audited image envelope is fixed for each model version. `pad` preserves the source dimensions and centers RGB content on the declared square background; images exceeding the envelope fail instead of being silently reduced. `fit` explicitly performs aspect-preserving bilinear resize and then padding. Images are converted according to the supported RGB preprocessing path and normalized using the saved channel statistics.

Source-image crop and alignment are upstream operations. There is no automatic camera-die detector or start/final registration in this classifier. Verify that upstream preprocessing has not removed the defect information.

Training-only brightness, contrast, and small-angle rotation augmentation are configurable. For vig, intensity and geometric changes should start conservatively, because the quality signal may be a spatial brightness pattern. Held-out evaluation uses deterministic preprocessing without random augmentation.

High-resolution padding preserves small details in the input, but it does not guarantee that a particular backbone's feature resolution retains every small defect. Evaluate missed examples. This release does not implement tiles or weakly supervised tile aggregation.

## Data roles

| Split | Permitted use |
| --- | --- |
| `train` | Learn supervised weights or construct a PatchCore bank |
| `val` | Select supervised checkpoints and stop training |
| `threshold` | Fit one operating threshold per candidate |
| `selection` | Rank frozen model-plus-threshold candidates |
| `test` | Assess the final fixed selected system |

Splitting preserves physical-unit groups. Filename uniqueness does not establish independence. Use a globally unique group key, such as a tray/unit composite, for repeat images and before/after views. Exact duplicates cannot provide independent evidence. Potential near duplicates require review because a small difference may be a real defect.

The release uses fixed grouped partitions. Grouped cross-validation is not implemented. If the audit cannot populate all required splits with both classes, acquire additional independent examples or redesign the evaluation outside this fixed-split workflow. Do not treat a small, class-deficient split as a valid qualification set.

An update preserves prior held-out group membership. Images newly added for an already held-out physical unit remain held out. Old held-out images must not become training examples. If labels or grouping are revised in a way that invalidates the frozen experiment, create a new dataset/evaluation design and document the change.

## Imbalance handling

Class counts used for automatic imbalance handling are calculated from training data only. Supported strategies are unweighted loss, capped class-weighted loss, or a sampling strategy. Automatic selection records its effective settings in the run artifacts. Class weighting and oversampling are not applied together as a hidden default.

Many good examples may provide valuable variation; they are not discarded simply to make class counts equal. A small number of repeated bad images still represents few independent defects. Reweighting cannot create new defect variation. Evaluation sets retain their assigned composition and report the class denominators.

## Threshold and candidate selection

The threshold split selects an operating point against the configured empirical defect-escape limit. The candidate is then assessed on the separate selection split. A candidate passes the empirical policy only if both defect escapes and good rejections satisfy the configured limits.

With the supplied `threshold_margin: true` policy, the fitted operating point is placed inside an equivalent interval between adjacent observed scores, rather than exactly on a training threshold score. If every observed image is rejected, the threshold is placed just below the minimum score. This preserves the fitted threshold-set decisions while providing numerical separation from the observed boundary. It does not guarantee equivalent decisions on unseen images or across runtimes; export parity remains required.

If no candidate meets the policy, the ranked best candidate may still be recorded for diagnostic review, but its result is `TARGET_NOT_MET`; ranking first is not qualification. Ensembles average compatible supervised bad scores and receive their own tuned threshold. Raw PatchCore distances are not averaged with supervised softmax scores.

Candidate selection estimates can be optimistic after searching many models and seeds. The final test assesses the selected fixed rule. Repeated inspection of the same final test turns it into a development benchmark; collect a fresh independent holdout after substantial iterative development.

## Reported metrics

| Metric | Definition | Interpretation |
| --- | --- | --- |
| Defect escape rate | `FN / (TP + FN)` | Fraction of bad images accepted |
| Bad recall | `TP / (TP + FN)` | Fraction of bad images rejected |
| Good rejection rate | `FP / (TN + FP)` | Fraction of good images rejected |
| Good acceptance rate | `TN / (TN + FP)` | Retained conforming images |
| Accepted contamination | `FN / (FN + TN)` | Bad share of accepted images in this evaluation set |
| Bad precision | `TP / (TP + FP)` | Bad share of rejected images |
| Accuracy | `(TP + TN) / N` | Overall image-level correctness |
| PR-AUC for bad | Average precision over bad scores | Ranking quality across operating points |
| ROC-AUC | Bad-vs-good ranking measure | Supplementary ranking statistic |

Zero-denominator metrics are undefined and recorded as null, not as zero error or perfect performance. Precision and accepted contamination depend on the prevalence of bad images. Estimates from a deliberately enriched defect test set do not directly predict production contamination at another prevalence.

### Unit-level evidence

The report also records the number of independent bad groups and escaped bad groups. Its conservative group event is: **at least one bad image of that unit was accepted**. This differs from a physical downstream rule that rejects a unit whenever any inspection view is bad; use the reported rule consistently.

For a fixed rule on independent bad units, a one-sided Clopper-Pearson upper confidence bound quantifies uncertainty in the escape rate. For zero escapes among `n` independent bad units, the 95% upper bound is `1 - 0.05^(1/n)`. With 100 units this is approximately 2.95%; approximately 299 zero-escape independent units are needed for an upper bound below 1%.

The bound does not establish independence, correct labels, production representativeness, or future stability. Unknown grouping prevents a sound independence claim. A model may meet empirical limits while still lacking enough evidence to meet the confidence-bound release gate.

## Improvement experiments

Start with error review: identify missed defect types, false rejections, and tray-specific differences. Correct labels only after review, then version the corrected dataset. Add independent examples and retain old training coverage. Evaluate fine-tuning and fresh pretrained training against the unchanged previous model on the same comparison rows.

Change one meaningful factor at a time when diagnosing an issue: geometry, augmentation, imbalance strategy, backbone, training budget, or threshold policy. Every preprocessing or decision change creates a new candidate. Do not edit an active package's threshold or memory bank in place.
