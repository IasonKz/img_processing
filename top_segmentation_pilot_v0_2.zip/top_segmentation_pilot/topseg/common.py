"""Configuration and file operations shared by annotation and training."""
from __future__ import annotations
from contextlib import contextmanager
from datetime import datetime, timezone
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import tempfile

from PIL import Image, ImageOps

CLASSES = {'background': 0, 'inner': 1, 'outer': 2}
EXTENSIONS = {'.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff', '.webp'}
DEFAULTS = {
    'name': 'top_defect_segmentation', 'input_dir': './input/top',
    'project_dir': './annotation_project', 'output_dir': './results',
    'group_regex': None, 'max_image_pixels': 25_000_000,
    'annotation': {'port': 8765},
    'classical': {'background_sigma': 8.0, 'sensitivity': 4.0,
                  'min_area': 6, 'max_area_fraction': .03, 'boundary_guard': 3,
                  'polarity': 'both'},
    'training': {'epochs': 25, 'batch_size': 2, 'learning_rate': .001,
                 'image_size': 512, 'base_channels': 16, 'seed': 42,
                 'val_fraction': .2, 'patience': 6, 'device': 'cpu',
                 'num_workers': 0, 'min_images': 5, 'require_both_defect_classes': True,
                 'augment': True, 'cpu_threads': 4},
}


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def merge(base, changes):
    result = copy.deepcopy(base)
    for key, value in changes.items():
        result[key] = merge(result[key], value) if isinstance(value, dict) and isinstance(result.get(key), dict) else copy.deepcopy(value)
    return result


def load_config(path):
    import yaml
    path = Path(path).resolve()
    raw = yaml.safe_load(path.read_text(encoding='utf-8')) or {}
    if not isinstance(raw, dict):
        raise ValueError('The configuration must contain a YAML mapping.')
    unknown = set(raw) - set(DEFAULTS)
    if unknown:
        raise ValueError(f'Unknown configuration keys: {sorted(unknown)}')
    cfg = merge(DEFAULTS, raw)
    for key in ('input_dir', 'project_dir', 'output_dir'):
        target = Path(str(cfg[key])).expanduser()
        cfg[key] = str((path.parent / target).resolve() if not target.is_absolute() else target.resolve())
    source, project, output = (Path(cfg[key]) for key in ('input_dir', 'project_dir', 'output_dir'))
    if project.is_relative_to(source) or source.is_relative_to(project):
        raise ValueError('Input and annotation project must be separate directory trees.')
    if output.is_relative_to(source) or source.is_relative_to(output):
        raise ValueError('Input and results must be separate directory trees.')
    if output.is_relative_to(project) or project.is_relative_to(output):
        raise ValueError('Results and annotation project must be separate directory trees.')
    if not isinstance(cfg['max_image_pixels'], int) or isinstance(cfg['max_image_pixels'], bool) or not 1 <= cfg['max_image_pixels'] <= 40_000_000:
        raise ValueError('max_image_pixels must be an integer in [1,40000000].')
    if not isinstance(cfg['annotation']['port'], int) or not 0 <= cfg['annotation']['port'] <= 65535:
        raise ValueError('annotation.port must be an integer in [0,65535].')
    if cfg['group_regex']:
        import re
        pattern = re.compile(cfg['group_regex'])
        if not pattern.groups:
            raise ValueError('group_regex needs a capture group, preferably (?P<unit>...).')
    return cfg


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def atomic_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    content = json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False) + '\n'
    fd, temporary = tempfile.mkstemp(prefix=path.name + '.', suffix='.tmp', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def sha256(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def safe_path(root, relative):
    root = Path(root).resolve()
    path = (root / relative).resolve()
    if not path.is_relative_to(root) or path == root:
        raise ValueError('Asset path escapes the project directory.')
    return path


def read_rgb(path, max_pixels=25_000_000):
    with Image.open(path) as source:
        if getattr(source, 'n_frames', 1) != 1:
            raise ValueError('Multiframe images are unsupported; provide one frame per file.')
        if source.mode in ('I', 'F') or source.mode.startswith('I;16'):
            raise ValueError('16-bit/float images need explicit upstream conversion to 8-bit.')
        if source.width * source.height > max_pixels:
            raise ValueError(f'Image exceeds the configured {max_pixels} pixel limit.')
        if source.mode in ('RGBA', 'LA') or (source.mode == 'P' and 'transparency' in source.info):
            raise ValueError('Transparent images need explicit upstream compositing.')
        return ImageOps.exif_transpose(source).convert('RGB').copy()


@contextmanager
def project_lock(root):
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    lock = root / 'operation.lock'
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError as exc:
        raise RuntimeError('The project is busy. Retry after the active operation finishes. If the application crashed, stop all its processes before removing operation.lock.') from exc
    try:
        with os.fdopen(fd, 'w') as stream:
            json.dump({'pid': os.getpid(), 'created_at': utc_now()}, stream)
        yield
    finally:
        lock.unlink(missing_ok=True)
