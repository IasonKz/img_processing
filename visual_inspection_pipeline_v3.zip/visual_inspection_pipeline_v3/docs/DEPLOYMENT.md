# Portable ONNX Deployment

## Offline operation and runtime telemetry

Both the exporter and the standalone runtime call
`onnxruntime.disable_telemetry_events()` immediately after importing ONNX Runtime,
before creating an inference session. This is the
[official platform telemetry opt-out](https://onnxruntime.ai/docs/api/python/api_summary.html#onnxruntime.disable_telemetry_events).
If the opt-out call fails, initialization stops. The same setting is included in
the `runtime.py` copied into each newly exported package.

Image inference and export use local files. They do not download model weights or
upload images. Downloading public pretrained weights remains a separate explicit
setup command. The application's RAM/VRAM/timing logs are local experiment files;
they are separate from ONNX Runtime's platform telemetry.

## Package boundary

An inference package contains the complete fixed decision system: model members, preprocessing, threshold, class mapping, metadata, integrity checks, and a standalone runner. It does not contain the training dataset or optimizer state. A training checkpoint is retained separately for subsequent fine-tuning or continuation.

The entire package directory must be transferred. A single `model.onnx` file is insufficient when preprocessing is external, an ensemble has multiple members, weights use external data, or a PatchCore memory bank is present.

| Package artifact | Purpose |
| --- | --- |
| `package.json` | Package schema, member references, scoring type, and entry metadata |
| `preprocessing.json` | Fixed input geometry, RGB conversion, normalization, and pad/fit policy |
| `decision_policy.json` | Threshold and class mapping |
| `model_metadata.json` | Model identity, task, source version, and release metadata |
| `integrity.json` | Checksums for packaged artifacts |
| `export_validation.json` | PyTorch/ONNX reference score and decision comparison |
| `members/000/model.onnx` | First supervised model or PatchCore feature extractor |
| Additional member directories | Further ensemble members where selected |
| PatchCore `members/000/memory_bank.npy` | Frozen reference features used by the nearest-neighbor scorer |
| `predict.py` and `runtime.py` | Standalone folder inference without importing the training application |

## Export a selected version

Export requires the original training environment with PyTorch, torchvision, ONNX, and ONNX Runtime available. It must have access to the held-out reference images used for export parity checks. Use a new output directory:

```bash
python inspection.py package --run ./results/top/RUN_ID --kind inference --output ./packages/top_release
```

The ONNX graph uses a fixed image batch size of one and the model version's fixed spatial envelope. Different source-image dimensions are accepted only if the saved preprocessing can convert them to that envelope. A larger source image fails under `pad`; `fit` resizes only when that policy was part of the evaluated model.

Evaluation and deployment scoring use float32. Mixed precision, when enabled, is restricted to supervised training. Float32 does not imply identical arithmetic across execution providers, so reference-score and decision checks still apply.

Export checks a CPU FP32 source-model pass against the original archived selection scores, then verifies ONNX scores and decisions against the CPU source model on reference images. Review `export_validation.json`, especially maximum score differences and any threshold decision disagreements. Both numeric tolerance compliance and zero decision changes are required. A failed parity check must not be interpreted as a successful portable release. A numerically close score can still change a decision when it lies close to the threshold.

For PatchCore, ONNX provides feature extraction and the adjacent runtime applies the saved nearest-neighbor scoring method with `memory_bank.npy`. An ensemble retains all selected members and averages their compatible supervised bad scores. These are multi-file decision systems.

The exporter uses the explicit legacy `dynamo=False` route of [PyTorch ONNX export](https://docs.pytorch.org/docs/stable/onnx.html), with fixed input shapes and package-specific parity checks. Runtime installation follows the [official ONNX Runtime package guidance](https://onnxruntime.ai/docs/install/).

## Install on the receiving computer

Create a separate runtime environment using [INSTALLATION.md](INSTALLATION.md). For CPU-only inference, the necessary libraries are NumPy, Pillow, and ONNX Runtime. PyTorch, torchvision, the original dataset, and a GPU are not required.

Copy the entire package to the destination. Open a terminal inside it and run:

```bash
python predict.py --input C:/inspection/incoming/top --output C:/inspection/classified/top_batch_001 --device cpu
```

Linux example:

```bash
python predict.py --input /data/incoming/top --output /data/classified/top_batch_001 --device cpu
```

In the full application environment, the equivalent route is:

```bash
python inspection.py predict --model ./packages/top_release --input ./incoming/top --output ./classified/top_batch_001 --device cpu
```

Use a fresh output directory for each batch. Output must not be nested inside the input tree. Source images are copied to prediction folders; they are not moved or modified.

## Output

| Relative path | Contents |
| --- | --- |
| `predictions.csv` | Source identifier, class, score, threshold, and processing status |
| `inference_summary.json` | Batch counts, model/package identity, timing, and runtime information |
| `predicted/good/` | Successfully processed images accepted as good |
| `predicted/bad/` | Successfully processed images rejected as bad |
| `predicted/review/` | Inputs that could not be validly classified |

For a labeled evaluation input with `good` and `bad` folders:

```bash
python predict.py --input ./labeled_batch --output ./batch_review --device cpu --labeled
```

This additionally exports `errors/bad_to_good` and `errors/good_to_bad` and includes available labeled metrics. Invalid images receive no valid good/bad decision. Output filenames are collision-resistant so different tray directories may contain the same original filename.

Supervised scores are bad-class scores in the interval zero to one; they are not guaranteed calibrated probabilities. PatchCore scores are nonnegative anomaly distances with a model-specific scale. Decisions use `score >= threshold` as bad. Changing the threshold creates a different decision system requiring reevaluation.

## GPU runtime and cross-device checks

The runner accepts `--device cuda` or `--device auto` where the corresponding ONNX Runtime provider is installed. CPU and CUDA provider availability are recorded. The exporter validates CPU parity; a different provider or hardware configuration requires destination checks. Provider initialization or execution errors must be resolved rather than hidden by silently changing the requested provider.

Use a retained reference set containing representative good/bad images and cases near the threshold. Compare scores, decisions, invalid-image handling, and performance on the destination. Review every decision disagreement. A successfully loaded graph does not by itself establish equivalent production behavior.

CPU execution of a large model or PatchCore bank may be slow. Moving the package to a laptop does not make its model smaller. Lower resolution, reduced precision, quantization, bank reduction, and architecture substitution are separate candidates requiring evaluation and a new version; they are not automatic portability optimizations.

## Operational boundary

An exported package is a local folder-classification interface, not a PLC protocol adapter, production-line service, or camera acquisition driver. Integrations may consume the recorded class/score/status outputs, but must define how invalid inputs, missing images, and combined top/bottom/vig decisions are handled. This application evaluates each task independently and does not silently infer a multi-view physical-unit acceptance policy.

Never infer eligibility for production merely from the existence of an ONNX package. Inspect the source model's qualification metadata and retain the destination-machine validation record with the release.
