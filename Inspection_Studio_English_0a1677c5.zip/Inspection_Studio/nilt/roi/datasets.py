"""Immutable ROI crop/classification and independent-mask localization exports."""
from __future__ import annotations

import copy
import csv
import hashlib
import json
import re
import shutil
import uuid
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from nilt.image_io import load_rgb
from .project import _atomic_json, _digest, _now


DEFAULT_KINDS = {"top": ("corners", "label", "inner_area", "lens"), "bottom": ("pins", "triangle", "square")}


def _safe(value):
    result = re.sub(r"[^A-Za-z0-9_.-]", "_", str(value))
    if not result or result in (".", ".."):
        raise ValueError("Invalid export name.")
    return result


def _png(path, pixels):
    """Write RGB uint8/uint16 PNG without Pillow's uint16 RGB truncation."""
    import cv2
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    image = np.asarray(pixels)
    encoded = image[:, :, ::-1] if image.ndim == 3 and image.shape[2] == 3 else image
    success, data = cv2.imencode(".png", np.ascontiguousarray(encoded))
    if not success:
        raise ValueError(f"Could not encode {path.name}.")
    path.write_bytes(data.tobytes())


def _mask(shape, roi, points=None):
    import cv2
    mask = np.zeros(shape, np.uint8)
    points = np.asarray(points if points is not None else roi.get("points", []), dtype=float)
    if len(points) == 0:
        return mask
    if roi.get("shape") == "circle" and len(points) >= 2:
        center = tuple(np.rint(points[0]).astype(int))
        radius = max(0, round(float(np.linalg.norm(points[1] - points[0]))))
        cv2.circle(mask, center, radius, 255, -1)
    elif len(points) >= 3:
        cv2.fillPoly(mask, [np.rint(points).astype(np.int32)], 255)
    return mask


def _annotated_preview(pixels, rois):
    """Display-only RGB overlay; never used as a crop or a training target."""
    import cv2
    pixels = np.asarray(pixels)
    canvas = (np.rint(pixels.astype(np.float64) * (255 / 65535)).astype(np.uint8)
              if pixels.dtype == np.uint16 else pixels.astype(np.uint8).copy())
    for roi in rois:
        points = np.asarray(roi.get("points", []), dtype=float)
        if not len(points):
            continue
        color = (40, 200, 240) if roi.get("source") == "inferred" else (40, 230, 90)
        vertices = np.rint(points).astype(np.int32)
        if roi.get("shape") == "circle" and len(points) >= 2:
            cv2.circle(canvas, tuple(vertices[0]), max(1, round(float(np.linalg.norm(points[1]-points[0])))), color, 1)
        elif roi.get("shape") == "point":
            cv2.drawMarker(canvas, tuple(vertices[0]), color, markerSize=7, thickness=1)
        else:
            cv2.polylines(canvas, [vertices], True, color, 1)
        anchor = tuple(np.maximum(vertices.min(axis=0), [0, 12]))
        cv2.putText(canvas, roi["id"], anchor, cv2.FONT_HERSHEY_SIMPLEX, .3, color, 1, cv2.LINE_AA)
    return canvas


def _canonical(ledger, unit_id):
    seen = set()
    aliases = ledger.get("aliases", {})
    while unit_id in aliases and unit_id not in seen:
        seen.add(unit_id)
        unit_id = aliases[unit_id]
    return unit_id


def export_project(project, payload):
    from .crops import crop_roi
    from .geometry import CROP_VERSION, LOCALIZATION_VERSION

    template = project.data.get("template")
    if not template:
        raise ValueError("Create a geometry template before exporting datasets.")
    kinds = list(dict.fromkeys(payload.get("kinds") or DEFAULT_KINDS[project.side]))
    requested = set(payload.get("image_ids") or [i["id"] for i in project.data["images"]])
    images, skipped = [], []
    ledger = project._ledger()
    for image in project.data["images"]:
        if image["id"] not in requested:
            continue
        annotation = image.get("annotation", {})
        reasons = []
        if not image.get("identity_confirmed"):
            reasons.append("unit identity unconfirmed")
        if image["unit_id"] in ledger.get("blocked_units", {}) or _canonical(ledger, image["unit_id"]) in ledger.get("blocked_units", {}):
            reasons.append("duplicate identity conflict across splits")
        if not annotation.get("geometry_reviewed"):
            reasons.append("geometry unreviewed")
        if annotation.get("template_stale") or annotation.get("template_version") != template.get("version"):
            reasons.append("template changed; review geometry again")
        try:
            project._verify_source(image)
        except (ValueError, OSError) as error:
            reasons.append(str(error))
        if reasons:
            skipped.append({"image_id": image["id"], "reasons": reasons})
        else:
            images.append(image)
    if not images:
        details = "; ".join(dict.fromkeys(reason for item in skipped for reason in item["reasons"]))
        raise ValueError("No exportable images. Confirm unit IDs and review complete geometry under the current template first. " + details)
    if template.get("reference_image_id"):
        project._verify_source(project._image(template["reference_image_id"]))
    settings = copy.deepcopy(payload.get("crop_settings") or {})
    settings_version = _digest({"settings": settings, "implementation": CROP_VERSION})
    snapshot_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "_" + uuid.uuid4().hex[:8]
    directory = project.directory / "exports" / snapshot_id
    directory.mkdir(parents=True, exist_ok=False)
    classifier_rows = defaultdict(list)
    crop_rows, segmentation_samples, errors = [], [], []
    segmentation_channels = list(dict.fromkeys(r["kind"] for r in template.get("rois", []) if r.get("shape") != "point"))
    classification = bool(payload.get("classification", True))
    segmentation = bool(payload.get("segmentation", True))
    # Snapshot keeps exact recipe+annotations together; incomplete exports are
    # never registered in the project catalog after cancellation/failure.
    _atomic_json(directory / "recipe.json", {"schema": "roi_recipe.v1", "side": project.side,
        "template": template, "crop_settings": settings, "crop_version": settings_version,
        "localizer": {"implementation": LOCALIZATION_VERSION}, "models": {}, "thresholds": {},
        "decision": {"uncertain_localization": "review", "all_required_rois_good": "good", "any_bad": "bad"}})
    if template.get("reference_image_id"):
        ref = project._image(template["reference_image_id"])
        project._verify_source(ref)
        _png(directory / "reference.png", np.asarray(load_rgb(ref["path"])))
    try:
        for index, image in enumerate(images):
            project._tick(f"Exporting ROIs from {image['name']}", index, len(images))
            annotation = image["annotation"]
            unit_id = _canonical(ledger, image["unit_id"])
            _atomic_json(directory / "annotations" / f"{image['id']}.json", image)
            source_pixels = np.asarray(load_rgb(image["path"]))
            _png(directory / "annotated_previews" / f"{image['id']}.png", _annotated_preview(source_pixels, annotation.get("rois", [])))
            for roi in annotation.get("rois", []):
                kind = roi["kind"]
                if roi.get("shape") == "point" or kind not in kinds:
                    continue
                name = f"{image['id']}__{_safe(roi['id'])}.png"
                try:
                    pixels, mask, metadata = crop_roi(image["path"], roi, settings=settings, transform=annotation.get("transform"))
                    crop_path = directory / "crops" / _safe(kind) / name
                    _png(crop_path, pixels)
                    _png(directory / "crop_masks" / _safe(kind) / name, mask)
                    label = annotation.get("quality", {}).get(roi["id"], "unknown")
                    row = {"path": str(crop_path.relative_to(directory)), "image_id": image["id"], "unit_id": unit_id,
                        "tray": image["tray"], "roi_id": roi["id"], "kind": kind, "split": image["split"], "label": label,
                        "annotation_revision": annotation.get("revision", 0), "template_version": template["version"],
                        "source": roi.get("source", "inferred"), "metadata": metadata}
                    row["sha256"] = hashlib.sha256(crop_path.read_bytes()).hexdigest()
                    crop_rows.append(row)
                    if classification and label in ("good", "bad"):
                        target = directory / "classification" / _safe(kind) / image["split"] / label / name
                        target.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copyfile(crop_path, target)
                        classifier_rows[kind].append({**{k: v for k, v in row.items() if k != "metadata"},
                            "relative_path": str(target.relative_to(target.parents[2])).replace("\\", "/"), "group": unit_id})
                except (ValueError, RuntimeError, OSError) as error:
                    errors.append({"image_id": image["id"], "roi_id": roi["id"], "error": str(error)})
            if segmentation:
                pixels = source_pixels
                h, w = pixels.shape[:2]
                _png(directory / "segmentation" / "images" / f"{image['id']}.png", pixels)
                masks = {kind: np.zeros((h, w), np.uint8) for kind in segmentation_channels}
                valid = {kind: np.full((h, w), 255, np.uint8) for kind in segmentation_channels}
                for roi in annotation.get("rois", []):
                    kind = roi["kind"]
                    if kind not in masks or roi.get("shape") == "point":
                        continue
                    if roi.get("presence") == "absent":
                        continue
                    observed = roi.get("observed_points")
                    supervised = roi.get("source") in ("manual", "corrected", "detected")
                    if observed and supervised:
                        masks[kind] |= _mask((h, w), roi, observed)
                    else:
                        # An expected polygon locates where to inspect; it is not
                        # evidence that material is present there.
                        invalid = _mask((h, w), roi, roi.get("expected_points") or roi.get("points"))
                        valid[kind][invalid > 0] = 0
                record = {"image_id": image["id"], "unit_id": unit_id, "tray": image["tray"], "split": image["split"],
                    "image_path": f"images/{image['id']}.png", "masks": {}, "valid_masks": {}}
                for kind in segmentation_channels:
                    key = _safe(kind)
                    relative = f"masks/{image['id']}/{key}.png"
                    valid_relative = f"valid_masks/{image['id']}/{key}.png"
                    _png(directory / "segmentation" / relative, masks[kind])
                    _png(directory / "segmentation" / valid_relative, valid[kind])
                    record["masks"][kind] = relative
                    record["valid_masks"][kind] = valid_relative
                segmentation_samples.append(record)
        datasets = []
        for kind, rows in sorted(classifier_rows.items()):
            scope = directory / "classification" / _safe(kind)
            for split in ("train", "val", "test"):
                for label in ("good", "bad"):
                    (scope / split / label).mkdir(parents=True, exist_ok=True)
            with (scope / "groups.csv").open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
                writer.writeheader()
                writer.writerows(rows)
            metadata = {"schema": "roi_classification_dataset.v1", "side": project.side, "roi_scope": kind,
                "project": str(project.path), "snapshot": snapshot_id, "export_id": snapshot_id,
                "template_version": template["version"], "crop_version": settings_version}
            _atomic_json(scope / "roi_dataset.json", metadata)
            datasets.append({"kind": kind, "roi_scope": kind, "path": str(scope), "groups_path": str(scope / "groups.csv"),
                "counts": dict(Counter(row["split"] for row in rows)), "labels": dict(Counter(row["label"] for row in rows))})
        seg = None
        if segmentation:
            manifest = {"schema": "roi_segmentation_dataset.v1", "side": project.side, "channels": segmentation_channels,
                "classes": segmentation_channels, "template_version": template["version"], "samples": segmentation_samples,
                "mask_semantics": "Independent channels. 0 in valid_masks means unknown supervision, never background.",
                "template": template}
            _atomic_json(directory / "segmentation" / "manifest.json", manifest)
            seg = {"path": str(directory / "segmentation"), "manifest_path": str(directory / "segmentation" / "manifest.json"),
                "samples": len(segmentation_samples), "channels": segmentation_channels}
        result = {"schema": "roi_dataset_snapshot.v1", "export_id": snapshot_id, "created_at": _now(), "side": project.side,
            "path": str(directory), "template_version": template["version"], "crop_version": settings_version,
            "classification": datasets, "segmentation": seg, "skipped": skipped, "errors": errors,
            "counts": {"images": len(images), "crops": len(crop_rows), "labeled_crops": sum(len(v) for v in classifier_rows.values()),
                "segmentation_images": len(segmentation_samples), "skipped_images": len(skipped), "crop_errors": len(errors)}}
        _atomic_json(directory / "crops_manifest.json", {"schema": "roi_crops.v1", "samples": crop_rows})
        _atomic_json(directory / "manifest.json", result)
        project._tick("Export complete", len(images), len(images))
        return result
    except BaseException:
        # Retain completed files for diagnosis while clearly marking unusable
        # snapshots; they never appear as ready datasets in the catalog.
        _atomic_json(directory / "INCOMPLETE.json", {"error": "Export interrupted; rerun export to create a complete snapshot.", "time": _now()})
        raise
