"""Optional windowed training measurements without changing saved model semantics."""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import csv
import functools
import inspect
import json
import os
from pathlib import Path
import platform
import time
import uuid


def rss_mib():
    """Current main-process RSS, not system RAM and not a peak measurement."""
    try:
        import psutil
        return psutil.Process().memory_info().rss / 2**20
    except ImportError:
        pass
    except OSError:
        return None
    try:
        if os.name == "nt":
            import ctypes
            from ctypes import wintypes
            class Counters(ctypes.Structure):
                _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD)] + [
                    (name, ctypes.c_size_t) for name in ("PeakWorkingSetSize", "WorkingSetSize", "QuotaPeakPagedPoolUsage",
                        "QuotaPagedPoolUsage", "QuotaPeakNonPagedPoolUsage", "QuotaNonPagedPoolUsage", "PagefileUsage", "PeakPagefileUsage")]
            kernel = ctypes.WinDLL("kernel32", use_last_error=True)
            process = ctypes.WinDLL("psapi", use_last_error=True)
            kernel.GetCurrentProcess.restype = wintypes.HANDLE
            process.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(Counters), wintypes.DWORD]
            process.GetProcessMemoryInfo.restype = wintypes.BOOL
            value = Counters()
            value.cb = ctypes.sizeof(value)
            if process.GetProcessMemoryInfo(kernel.GetCurrentProcess(), ctypes.byref(value), value.cb):
                return value.WorkingSetSize / 2**20
        elif Path("/proc/self/statm").exists():
            return int(Path("/proc/self/statm").read_text().split()[1]) * os.sysconf("SC_PAGE_SIZE") / 2**20
    except (OSError, ValueError, AttributeError):
        pass
    return None


def save_json(path, data):
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(data, indent=2, allow_nan=False), encoding="utf-8")
    temp.replace(path)


class Session:
    columns = ["epoch", "batch_first", "batch_last", "batches", "images", "seconds",
               "seconds_per_batch", "images_per_second", "rss_mib", "cuda_allocated_mib",
               "cuda_reserved_mib", "completed"]

    def __init__(self, out, cfg, name, interval, torch, device):
        self.folder = Path(out) / "visual_telemetry" / (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ_") + uuid.uuid4().hex[:6])
        self.folder.mkdir(parents=True)
        self.cfg, self.interval, self.torch, self.device = cfg, interval, torch, device
        progress = Path(out) / "progress.json"
        self.epoch = json.loads(progress.read_text()).get("current_epoch", 0) if progress.is_file() else 0
        self.started = time.perf_counter()
        self.meta = dict(schema_version=1, model=name, status="running", created_at=datetime.now(timezone.utc).isoformat(),
                         platform=platform.platform(), machine=platform.machine(), cpu=platform.processor(),
                         logical_cpus=os.cpu_count(), python=platform.python_version(), torch=str(torch.__version__),
                         device=str(device), gpu_name=torch.cuda.get_device_name(device) if device.type == "cuda" else None,
                         image_size=cfg.get("image_size"), resize=cfg.get("resize"),
                         batch_size=cfg["training"]["batch_size"], accumulation_steps=cfg["training"]["accumulation_steps"],
                         cpu_threads=cfg.get("cpu_threads"), num_workers=cfg.get("num_workers"),
                         amp=bool(cfg["training"].get("amp") and device.type == "cuda"),
                         window_batches=interval, resumed_after_recorded_epoch=self.epoch,
                         measurement="Training windows include fetch, transfer, forward, backward and optimizer work; validation excluded. CUDA synchronized at window boundaries. Logging overhead excluded between windows.",
                         limitations="Memory is sampled at window end, main-process RSS only; no peak guarantee. Per-batch loss is not collected. Interrupted windows are excluded. Separate resume sessions may repeat an uncommitted epoch.")
        save_json(self.folder / "session.json", self.meta)
        self.stream = (self.folder / "batch_windows.csv").open("w", newline="", encoding="utf-8")
        self.writer = csv.DictWriter(self.stream, fieldnames=self.columns)
        self.writer.writeheader()
        self.stream.flush()

    def sync(self):
        if self.device.type == "cuda":
            self.torch.cuda.synchronize(self.device)

    def window(self, first, last, images, start):
        self.sync()
        seconds = time.perf_counter() - start
        count = last - first + 1
        gpu = self.device.type == "cuda"
        self.writer.writerow(dict(epoch=self.epoch, batch_first=first, batch_last=last,
                                  batches=count, images=images, seconds=seconds,
                                  seconds_per_batch=seconds/count, images_per_second=images/seconds if seconds else 0,
                                  rss_mib=rss_mib(),
                                  cuda_allocated_mib=self.torch.cuda.memory_allocated(self.device)/2**20 if gpu else None,
                                  cuda_reserved_mib=self.torch.cuda.memory_reserved(self.device)/2**20 if gpu else None,
                                  completed=1))
        self.stream.flush()

    def close(self, status):
        self.stream.close()
        self.meta.update(status=status, session_seconds=time.perf_counter()-self.started,
                         ended_at=datetime.now(timezone.utc).isoformat())
        save_json(self.folder / "session.json", self.meta)


class ObservedLoader:
    def __init__(self, base, session):
        self.base, self.session = base, session

    def __len__(self):
        return len(self.base)

    def __getattr__(self, key):
        return getattr(self.base, key)

    def __iter__(self):
        session = self.session
        session.epoch += 1
        iterator = iter(self.base)
        session.sync()
        start, first, images, count = time.perf_counter(), 1, 0, 0
        while True:
            try:
                batch = next(iterator)
            except StopIteration:
                if count >= first:
                    session.window(first, count, images, start)
                return
            # The caller performs its entire training step while this generator is suspended.
            # On an exception/interrupt, execution never returns here: no false completed record.
            yield batch
            count += 1
            images += len(batch[1])
            if count-first+1 >= session.interval:
                session.window(first, count, images, start)
                first, images = count+1, 0
                start = time.perf_counter()


@contextmanager
def observe_training(interval=25):
    if interval < 1:
        raise ValueError("Telemetry interval must be positive.")
    from nilt import engine
    if list(inspect.signature(engine.train_one).parameters)[:6] != ["name", "seed", "rows", "cfg", "out", "init_checkpoint"]:
        raise RuntimeError("Unsupported train_one API; this add-on targets Visual Inspection Pipeline v2.")
    original_train, original_loader = engine.train_one, engine.loader
    active = [None]
    runs = set()

    @functools.wraps(original_loader)
    def loader(*args, **kwargs):
        bound = inspect.signature(original_loader).bind(*args, **kwargs)
        base = original_loader(*args, **kwargs)
        return ObservedLoader(base, active[0]) if bound.arguments.get("training", False) and active[0] else base

    @functools.wraps(original_train)
    def train(name, seed, rows, cfg, out, init_checkpoint=None, **kwargs):
        runs.add(Path(out).resolve().parent.parent)
        # PatchCore fitting is not a supervised batch loop. Original behavior remains in force.
        if name == "patchcore":
            return original_train(name, seed, rows, cfg, out, init_checkpoint, **kwargs)
        torch, _ = engine.torch_modules()
        session = Session(out, cfg, name, interval, torch, engine.device_for(cfg))
        active[0], status = session, "interrupted_or_failed"
        try:
            value = original_train(name, seed, rows, cfg, out, init_checkpoint, **kwargs)
            status = "completed"
            return value
        finally:
            active[0] = None
            session.close(status)

    engine.train_one, engine.loader = train, loader
    try:
        yield runs
    finally:
        engine.train_one, engine.loader = original_train, original_loader
