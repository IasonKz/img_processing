"use strict";
/* Pointer values and persistent series selection for local SVG charts. */
window.ChartInteraction = (() => {
  const selections = new Map();
  let tip;
  function tooltip(text, event) {
    if (!tip) {
      tip = document.createElement("div"); tip.className = "chart-value-tooltip";
      tip.setAttribute("role", "tooltip"); document.body.appendChild(tip);
    }
    tip.textContent = text; tip.hidden = false;
    tip.style.left = Math.max(4, Math.min(event.clientX + 14, window.innerWidth - tip.offsetWidth - 8)) + "px";
    tip.style.top = Math.max(4, Math.min(event.clientY + 14, window.innerHeight - tip.offsetHeight - 8)) + "px";
  }
  function hide() { if (tip) tip.hidden = true; }
  function emphasize(svg, key) {
    const groups = [...svg.querySelectorAll("[data-chart-series]")];
    const chosen = groups.find(group => group.dataset.chartSeries === key);
    for (const group of groups) {
      group.classList.toggle("chart-selected", group === chosen);
      group.classList.toggle("chart-muted", !!chosen && group !== chosen);
      group.setAttribute("aria-pressed", String(group === chosen));
    }
    if (chosen) chosen.parentNode.appendChild(chosen);
  }
  function select(svg, key) {
    key = selections.get(svg.id) === key ? null : key;
    selections.set(svg.id, key); emphasize(svg, key);
  }
  function bind(svg, series) {
    if (!svg) return;
    hide();
    emphasize(svg, selections.get(svg.id));
    function nearest(event) {
      const rect = svg.getBoundingClientRect(), box = svg.viewBox.baseVal;
      const scale = Math.min(rect.width / box.width, rect.height / box.height);
      const x = (event.clientX - rect.left - (rect.width - box.width * scale) / 2) / scale + box.x;
      const y = (event.clientY - rect.top - (rect.height - box.height * scale) / 2) / scale + box.y;
      let best = null, distance = 14 / scale;
      for (const item of series) {
        for (let i = 0; i < item.points.length; i++) {
          const a = item.points[i], b = item.points[i + 1] || a;
          const dx = b.x - a.x, dy = b.y - a.y;
          const t = Math.max(0, Math.min(1, ((x - a.x) * dx + (y - a.y) * dy) / (dx * dx + dy * dy || 1)));
          const d = Math.hypot(x - a.x - dx * t, y - a.y - dy * t);
          if (d < distance || (Math.abs(d - distance) < .01 && item.key === selections.get(svg.id))) {
            distance = d; best = {item, point: t < .5 ? a : b};
          }
        }
      }
      return best;
    }
    svg.onpointermove = event => {
      const match = nearest(event);
      svg.style.cursor = match ? "pointer" : "default";
      if (match) tooltip(match.point.label, event); else hide();
    };
    svg.onpointerleave = hide;
    svg.onclick = event => {
      const group = event.target.closest?.("[data-chart-series]");
      const match = nearest(event);
      if (group || match) select(svg, group?.dataset.chartSeries || match.item.key);
      else { selections.delete(svg.id); emphasize(svg, null); }
    };
    svg.onkeydown = event => {
      const group = event.target.closest?.("[data-chart-series]");
      if (group && ["Enter", " "].includes(event.key)) { event.preventDefault(); select(svg, group.dataset.chartSeries); }
    };
    svg.onfocusin = event => {
      const group = event.target.closest?.("[data-chart-series]");
      if (group) { const rect = group.getBoundingClientRect(); tooltip(group.querySelector("title")?.textContent || group.dataset.chartSeries, {clientX:rect.left, clientY:rect.top}); }
    };
    svg.onfocusout = hide;
  }
  function bindRadars(root) {
    for (const svg of root.querySelectorAll("svg.analytics-radar")) {
      bind(svg,[...svg.querySelectorAll("[data-chart-series]")].map(group=>({key:group.dataset.chartSeries,points:[...group.querySelectorAll("circle")].map(circle=>({x:Number(circle.getAttribute("cx")),y:Number(circle.getAttribute("cy")),label:circle.querySelector("title")?.textContent||group.dataset.chartSeries}))})));
    }
  }
  return {bind, hide, bindRadars};
})();
