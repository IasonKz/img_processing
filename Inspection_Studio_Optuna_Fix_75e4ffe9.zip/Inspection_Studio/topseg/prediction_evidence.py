"""Native prediction evidence for unit inspection reports."""
from pathlib import Path
import shutil

import numpy as np

from .common import sha256


def pixel_evidence(probabilities, mask):
    selected = np.max(probabilities, axis=0)
    defects = mask != 0
    return {"mean_selected_pixel_probability": float(selected.mean()),
            "p05_selected_pixel_probability": float(np.quantile(selected, .05)),
            "mean_defect_pixel_probability": float(selected[defects].mean()) if defects.any() else None,
            "defect_pixels": int(defects.sum()), "pixels": int(mask.size),
            "defect_area_ratio": float(defects.mean()),
            "interpretation": "Uncalibrated per-pixel model probabilities; not a unit correctness probability."}


def capture_evidence(root, path, output, mask, probabilities, lineage, expected=None):
    from nilt.inspection_identity import physical_unit
    relative = path.relative_to(root)
    if path.is_symlink() or not path.resolve().is_relative_to(root):
        raise ValueError("Prediction image must remain inside the selected folder.")
    digest = sha256(path)
    if expected and digest != expected:
        raise ValueError("Source image changed during inference.")
    image_file = Path("images") / relative
    (output / image_file).parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, output / image_file)
    if sha256(output / image_file) != digest or sha256(path) != digest:
        raise ValueError("Source image changed while recording prediction evidence.")
    candidates = [row for row in lineage.get(path.name, []) if row.get("sha256") == digest]
    context = candidates[0] if len(candidates) == 1 else None
    source = context.get("source_image", {}) if context else {}
    identity = physical_unit(source.get("name") or source.get("path") or relative,
                             context.get("unit_id") if context else None,
                             context.get("tray") if context else None, origin=str(root))
    evidence = {**identity, "source_sha256": digest, "source_image": image_file.as_posix(),
                "width": int(mask.shape[1]), "height": int(mask.shape[0]),
                "pixel_evidence": pixel_evidence(probabilities, mask)}
    if context:
        evidence["roi"] = {key: context.get(key) for key in
            ("image_id", "unit_id", "tray", "roi_id", "kind", "split", "annotation_revision", "template_version", "metadata")}
        evidence["roi"]["export_root"] = context["export_root"]
        evidence["roi"]["geometry"] = next((roi for roi in source.get("annotation", {}).get("rois", [])
                                            if roi.get("id") == context["roi_id"]), None)
        original = Path(source.get("path", ""))
        expected = source.get("file_checksum")
        if expected and original.is_file() and not original.is_symlink() and sha256(original) == expected:
            destination = Path("source_images") / (str(context["image_id"]) + original.suffix.lower())
            (output / destination).parent.mkdir(exist_ok=True)
            if not (output / destination).exists():
                shutil.copyfile(original, output / destination)
            if sha256(output / destination) != expected:
                raise ValueError("ROI source image changed during evidence capture.")
            evidence["roi"].update(full_image=destination.as_posix(), full_image_sha256=expected)
        geometry = Path(context["export_root"]) / "crop_masks" / context["kind"] / Path(context["path"]).name
        if geometry.is_file() and not geometry.is_symlink():
            destination = Path("geometry_masks") / relative.with_suffix(".png")
            (output / destination).parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(geometry, output / destination)
            evidence["roi"]["geometry_mask"] = destination.as_posix()
        overlay = Path(context["export_root"]) / "annotated_previews" / (str(context["image_id"]) + ".png")
        if overlay.is_file() and not overlay.is_symlink():
            destination = Path("geometry_overlays") / overlay.name
            (output / destination).parent.mkdir(exist_ok=True)
            shutil.copyfile(overlay, output / destination)
            evidence["roi"]["geometry_overlay"] = destination.as_posix()
    return evidence
