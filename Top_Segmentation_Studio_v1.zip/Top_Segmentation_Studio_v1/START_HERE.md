# Start here — Top Segmentation Studio

## Windows (recommended Python 3.12)

1. Extract the ZIP into a new folder. Keep the whole folder structure.
2. Run **Setup.cmd** once. It creates `.venv` and installs dependencies.
3. Run **Start.cmd**. Keep its terminal open.
4. In **Workspace**, enter your top-image folder, annotation-project folder and results folder. Click **Save project settings**, then **Import top images**.

If you already have a working Python environment with the dependencies:

```powershell
python -m pip install -r requirements-training.txt
python segmentation.py studio --config project.yaml
```

For NVIDIA GPU use, install a matching PyTorch/torchvision CUDA build for the computer before running the requirements installation. The CUDA option errors clearly if CUDA is unavailable; use CPU/Automatic for initial UI checks. No laptop/workstation budget profiles are imposed.

## Linux

```bash
bash Setup.sh
bash Start.sh
```

Manual environment:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-training.txt
python segmentation.py studio --config project.yaml
```

To open the interface without installing neural-network packages:

```bash
python -m pip install -r requirements.txt
python segmentation.py studio --config project.yaml
```

The editor and project management work; neural search requires the training dependencies.

## Reuse the v0.2 annotation project

In Workspace, set **Annotation project folder** to the existing v0.2 `annotation_project` folder. Set **Top image folder** to the same original input folder and keep its existing group regex. Use a separate results folder. Save settings. Saved masks, annotation objects, exclusions and revision history are read directly, without reimporting or retagging them. Retain a copy of your old project before major annotation changes.

You can instead start with your existing project YAML:

```bash
python segmentation.py studio --config /path/to/old/project.yaml
```

No `good/bad` folder structure is required for segmentation. A chosen top folder may contain nested folders; all supported image files within it are considered for import. Do not select the tray root containing bottom/vig images.

## Set the inner polygon once

1. Open **Annotation**.
2. Choose **Boundary** and click vertices; press **Enter** to close. Drag its vertices to adjust. **Octagon** draws a rectangle with clipped corners.
3. In the right panel, choose **Relative to image size** (same shape scaled to each image) or **Exact pixels** (requires identical dimensions).
4. Leave **Use for new images** checked and click **Save custom polygon**.
5. New, unannotated images now use this boundary. It persists after closing/restarting the app.
6. For images already opened, click **Apply saved polygon to existing images**. By default this updates drafts. Check **Include approved images in batch** only when you also want those boundaries changed. Changed masks become drafts requiring approval again; old revisions are preserved.

**Use saved polygon on this image** applies it locally with undo support. Saving the template does not approve the current defect mask. The polygon only splits marked defects into inner/outer; it does not fill the inner region as a defect.

## Train and compare

1. Review and approve a representative set, including clean images and inner/outer defects across independent units/trays.
2. In **Model search**, select models, sizes, batch sizes, search ranges and budgets.
3. Run **Preflight selected models** to check architecture, memory and device compatibility.
4. Set a study name and click **Start / resume search**. `0` disables the corresponding trial/time limit. Setting both trials and hours to 0 runs until stopped.
5. Follow **Activity** and the live training curves. **Stop operation** requests a stop at a safe batch/image boundary.
6. In **Results & compare**, load a study. Compare validation metrics, trial states, runtime, learning curves and errors. **Restore search settings** restores its search space for continuation.
7. In **Inspect & predict**, choose a completed trial and evaluate validation. Inspect target/prediction overlays. Use held-out test only after selecting the final model.
8. Predict new top-image folders or use **Export** for a model package/dataset.

Pruned trials are stopped trials, not necessarily program errors. Failed trials show their actual error (for example insufficient GPU memory or incompatible custom encoder). Neither failed nor pruned trials are promoted as selected completed models.

ONNX export dependencies:

```bash
python -m pip install -r requirements-export.txt
```

## Where files go

Paths are relative to the YAML file unless absolute. Defaults:

- `input/top/`: your top images; never modified.
- `annotation_project/`: working copies, masks, immutable versions, saved polygon.
- `results/studies/<study>/`: frozen dataset, splits, Optuna SQLite, checkpoints, metrics.
- `results/predictions/`: prediction masks, overlays and CSV.
- `results/packages/`, `results/datasets/`, `results/reports/`: exported files.
- `results/jobs/`: live worker status, requests and logs.

Closing the browser does not stop a worker. Use **Stop operation** before shutting down if you want it stopped. After a system/process crash, resume the study; completed trials and saved checkpoints remain. An annotation `operation.lock` left by an abrupt crash should only be removed after all processes using that project have stopped.

## Greek quick note

Όλα αφορούν **top images**. Για το πολύγωνο: **Boundary/Octagon → Save custom polygon**. Για να εφαρμοστεί και σε ήδη ανοιγμένες εικόνες: **Apply saved polygon to existing images**. Το polygon και τα annotations αποθηκεύονται στο project, όχι μόνο στον browser. Το **Start / resume search** συνεχίζει το ίδιο Optuna study· αν αλλάξεις μοντέλα/search space ή προσθέσεις νέο training dataset, δώσε νέο study name.
