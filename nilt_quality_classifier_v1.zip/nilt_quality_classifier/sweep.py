from __future__ import annotations

import argparse
import multiprocessing as mp

from qc.config import load_yaml
from qc.sweep import run_sweep


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a validation-only hyperparameter sweep.")
    parser.add_argument("--config", required=True, help="Path to a sweep YAML file")
    args = parser.parse_args()
    result = run_sweep(load_yaml(args.config))
    print(f"\nSweep output: {result['sweep_dir']}")


if __name__ == "__main__":
    mp.freeze_support()
    main()
