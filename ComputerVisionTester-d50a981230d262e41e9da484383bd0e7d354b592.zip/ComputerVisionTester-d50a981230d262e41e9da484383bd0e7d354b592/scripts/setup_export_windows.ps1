[CmdletBinding()]
param([string]$OfflineWheelhouse = '')
$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$Record = Join-Path $ProjectRoot '.studio-python.txt'
if (-not (Test-Path -LiteralPath $Record)) { throw 'Run Setup.cmd first so Start.cmd and export use the same environment.' }
$PythonExe = (Get-Content -LiteralPath $Record -Raw).Trim()
if (-not (Test-Path -LiteralPath $PythonExe -PathType Leaf)) { throw 'The recorded environment is missing. Run Setup.cmd.' }
Push-Location $ProjectRoot
try {
    Write-Host "Repairing export in the dashboard environment: $PythonExe"
    $Source = @()
    if ($OfflineWheelhouse) { $Source = @('--no-index', '--find-links', (Resolve-Path -LiteralPath $OfflineWheelhouse).Path) }
    & $PythonExe -m pip install --upgrade @Source -r requirements-export.txt
    if ($LASTEXITCODE -ne 0) { throw 'Export dependency installation failed. Read the error above.' }
    & $PythonExe scripts/check_export.py
    if ($LASTEXITCODE -ne 0) { throw 'Packages installed but the import probe failed. See docs/EXPORT_AND_VIEWER_FIXES.md for Windows DLL repair.' }
    & $PythonExe -m pip check
    if ($LASTEXITCODE -ne 0) { throw 'The environment contains dependency conflicts. Read the report above.' }
    Write-Host 'Export is ready. Restart Start.cmd and create an ONNX inference package.'
}
finally { Pop-Location }
