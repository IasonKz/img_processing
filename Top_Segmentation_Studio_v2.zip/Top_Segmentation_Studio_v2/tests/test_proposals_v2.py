"""Behavioral tests for selectable native-resolution proposal approaches."""
import unittest

import numpy as np
from scipy import ndimage

from topseg.classical import roi_mask, suggest
from topseg.proposals import AUTOMATION_DEFAULTS, suggest_advanced, validate_automation


def rgb(gray):
    return np.repeat(np.clip(gray, 0, 255).astype(np.uint8)[..., None], 3, axis=2)


def box(x0, y0, x1, y1):
    return {'type': 'polygon', 'points': [{'x': x0, 'y': y0}, {'x': x1, 'y': y0},
                                          {'x': x1, 'y': y1}, {'x': x0, 'y': y1}]}


class ProposalMethodTests(unittest.TestCase):
    def test_basic_is_exact_original_even_with_all_exclusions_enabled(self):
        rng = np.random.default_rng(318)
        image = rgb(128 + rng.normal(0, 2, (231, 287)))
        image[90:98, 110:117] = 230
        image[26:33, 30:40] = 20
        image[170:178, 239:248] = 210
        roi = box(65, 45, 222, 199)
        settings = {'sensitivity': 3., 'boundary_guard': 1, 'min_area': 3}
        expected, _ = suggest(image, roi, settings)
        full_zone = {'id': 'all', 'name': 'all', 'category': 'custom', 'roi': box(0, 0, 287, 231)}
        actual, stats = suggest_advanced(image, roi, settings, {'method': 'basic', 'zones': [full_zone], 'exclude_eye': True})
        np.testing.assert_array_equal(actual, expected)
        self.assertEqual(stats['native_resolution'], [287, 231])
        self.assertIsNone(stats['effective_eye'])

    def test_exclusions_remove_symbols_but_basic_and_switch_restore_defect(self):
        image = np.full((200, 240, 3), 120, np.uint8)
        image[20:29, 22:36] = 230  # Printed mark, also stands in for a defect in an ignored zone.
        image[104:111, 107:113] = 230
        zone = {'id': 'label', 'name': 'Printed label', 'category': 'label', 'roi': box(16, 16, 45, 40)}
        automation = {'method': 'exclusions', 'zones': [zone]}
        excluded, _ = suggest_advanced(image, settings={'min_area': 3}, automation=automation)
        self.assertFalse(excluded[16:40, 16:45].any())
        self.assertEqual(excluded[107, 110], 1)
        restored, _ = suggest_advanced(image, settings={'min_area': 3}, automation={**automation, 'exclude_label': False})
        self.assertEqual(restored[24, 28], 2)
        basic, _ = suggest_advanced(image, settings={'min_area': 3}, automation={**automation, 'method': 'basic'})
        self.assertEqual(basic[24, 28], 2)

    def test_custom_scope_does_not_change_inner_outer_classification(self):
        image = np.full((180, 200, 3), 128, np.uint8)
        for y, x in ((90, 100), (90, 35), (90, 170)):
            image[y - 3:y + 4, x - 3:x + 4] = 240
        scope = box(20, 20, 135, 160)
        mask, _ = suggest_advanced(image, {'cx': 100, 'cy': 90, 'rx': 40, 'ry': 40},
                                    automation={'scope': 'custom', 'scope_roi': scope})
        self.assertEqual(mask[90, 100], 1)
        self.assertEqual(mask[90, 35], 2)
        self.assertEqual(mask[90, 170], 0)
        self.assertFalse(mask[~roi_mask(scope, 200, 180)].any())

    def test_central_scope_keeps_native_small_defect_and_rejects_neighbor(self):
        gray = np.full((620, 710), 25., np.float32)
        gray[195:435, 235:475] = 145
        gray[195:435, 535:705] = 145
        gray[310:314, 352:356] = 245  # Four-pixel native defect must survive.
        gray[310:314, 600:604] = 245
        mask, stats = suggest_advanced(rgb(gray), roi=box(270, 240, 440, 400),
                                      settings={'min_area': 3, 'boundary_guard': 0},
                                      automation={'scope': 'central'})
        self.assertEqual(mask.shape, gray.shape)
        self.assertEqual(mask[311, 353], 1)
        self.assertEqual(mask[311, 601], 0)
        scope = roi_mask(stats['effective_scope'], 710, 620)
        self.assertTrue(scope[300, 300])
        self.assertFalse(scope[300, 600])

    def test_central_failure_is_explicit_and_never_returns_blank_success(self):
        with self.assertRaisesRegex(ValueError, 'Central die.*Full image'):
            suggest_advanced(np.full((120, 140, 3), 100, np.uint8), automation={'scope': 'central'})

    def test_structure_removes_normal_rings_but_retains_local_scratch(self):
        yy, xx = np.mgrid[:240, :260]
        radius = np.hypot(xx + .5 - 130, yy + .5 - 120)
        eye = {'cx': 130, 'cy': 120, 'rx': 75, 'ry': 75}
        gray = np.full((240, 260), 125., np.float32)
        ring_area = radius < 73
        gray[ring_area] += 28 * np.sin(radius[ring_area] * .9)
        clean = rgb(gray)
        damaged = clean.copy()
        damaged[91:115, 155:159] = 240
        settings = {'sensitivity': 6, 'min_area': 3, 'boundary_guard': 1, 'max_area_fraction': .2}
        automation = {'method': 'structure', 'eye': eye}
        roi = box(35, 25, 225, 215)
        basic, _ = suggest(clean, roi, settings)
        structured, stats = suggest_advanced(clean, roi, settings, automation)
        scratch, _ = suggest_advanced(damaged, roi, settings, automation)
        interior = radius < 65
        self.assertGreater(np.count_nonzero(basic[interior]), 500)
        self.assertLess(np.count_nonzero(structured[interior]), .12 * np.count_nonzero(basic[interior]))
        self.assertGreater(np.count_nonzero(scratch[93:113, 155:159]), 45)
        self.assertTrue(stats['radial_model']['found'])
        self.assertAlmostEqual(stats['radial_model']['center']['x'], 130, delta=.5)
        self.assertTrue(any('annular' in warning for warning in stats['warnings']))

    def test_eye_exclusion_is_optional_and_zero_strength_restores_basic(self):
        image = np.full((140, 180, 3), 128, np.uint8)
        image[65:74, 85:94] = 245
        automation = {'method': 'structure', 'radial_strength': 0}
        basic, _ = suggest(image)
        structured, _ = suggest_advanced(image, automation=automation)
        np.testing.assert_array_equal(basic, structured)
        ignored, stats = suggest_advanced(image, automation={**automation, 'exclude_eye': True})
        self.assertEqual(ignored[70, 90], 0)
        self.assertIsNotNone(stats['effective_eye'])

    def test_structure_edges_suppresses_perimeter_but_not_interior_scratch(self):
        gray = np.full((300, 320), 30, np.float32)
        gray[60:240, 70:250] = 150
        gray[130:147, 158:161] = 245
        automation = {'method': 'structure', 'scope': 'central', 'suppress_edges': True,
                      'radial_strength': 0}
        mask, stats = suggest_advanced(rgb(gray), box(95, 85, 225, 215),
                                      {'boundary_guard': 0, 'min_area': 3, 'max_area_fraction': .2}, automation)
        self.assertEqual(mask[138, 159], 1)
        self.assertFalse(mask[65:230, 70:72].any())
        self.assertGreater(stats['suppressed_edge_pixels'], 0)

    def test_straight_edge_model_retains_a_local_boundary_chip(self):
        gray = np.full((300, 320), 30, np.float32)
        gray[60:240, 70:250] = 150
        gray[130:147, 70:75] = 30
        mask, stats = suggest_advanced(rgb(gray), box(95, 85, 225, 215),
                                      {'boundary_guard': 0, 'min_area': 3, 'max_area_fraction': .2},
                                      {'method': 'structure', 'scope': 'central', 'suppress_edges': True,
                                       'radial_strength': 0})
        self.assertEqual(mask[138, 72], 2)
        self.assertTrue(stats['edge_model']['found'])
        self.assertLess(np.count_nonzero(mask), 1000)

    def test_validation_rejects_ambiguous_regions_and_does_not_mutate_defaults(self):
        for invalid in ({'method': 'unknown'}, {'scope': 'custom'}, {'exclude_eye': 1},
                        {'radial_strength': float('nan')}, {'reference_ids': ['a', 'a']},
                        {'reference_rotation': True}, {'unknown': 1}):
            with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                validate_automation(invalid, 200, 100)
        cfg = validate_automation(None, 200, 100)
        cfg['zones'].append('changed')
        self.assertEqual(AUTOMATION_DEFAULTS['zones'], [])


class ReferenceTests(unittest.TestCase):
    @staticmethod
    def specimen():
        rng = np.random.default_rng(829)
        gray = 105 + ndimage.gaussian_filter(rng.normal(0, 17, (220, 250)), 1)
        gray[35:190, 40:210] += 35
        gray[49:59, 50:75] += 35
        gray[145:165, 180:186] -= 40
        yy, xx = np.mgrid[:220, :250]
        rr = np.hypot(xx - 125, yy - 110)
        circle = rr < 48
        gray[circle] += 14 * np.sin(rr[circle] * .6)
        return rgb(gray)

    def test_shifted_brightened_reference_preserves_new_defect(self):
        import cv2
        reference = self.specimen()
        shifted = cv2.warpAffine(reference, np.float32([[1, 0, 6], [0, 1, -4]]),
                                 (250, 220), borderMode=cv2.BORDER_REFLECT)
        current = np.clip(shifted.astype(float) * 1.12 + 8, 0, 255).astype(np.uint8)
        current[103:112, 124:131] = 235
        mask, stats = suggest_advanced(current, box(65, 45, 205, 185),
                                      {'min_area': 3, 'sensitivity': 4},
                                      {'method': 'reference', 'reference_ids': ['good'], 'reference_max_shift': 12},
                                      [('good', reference)])
        self.assertEqual(mask[107, 127], 1)
        self.assertLess(np.count_nonzero(mask), 600)
        alignment = stats['reference_alignments'][0]
        self.assertGreater(alignment['correlation'], .97)
        self.assertAlmostEqual(alignment['center_shift_pixels'][0], -6, delta=.4)
        self.assertAlmostEqual(alignment['center_shift_pixels'][1], 4, delta=.4)
        self.assertAlmostEqual(alignment['gain'], 1.12, delta=.04)

    def test_multiple_good_references_and_clean_image_do_not_force_proposals(self):
        reference = self.specimen()
        slightly_brighter = np.clip(reference.astype(int) + 4, 0, 255).astype(np.uint8)
        mask, stats = suggest_advanced(reference, automation={'method': 'reference', 'reference_ids': ['one', 'two']},
                                      references=[('one', reference), ('two', slightly_brighter)])
        self.assertFalse(mask.any())
        self.assertEqual(len(stats['reference_alignments']), 2)

    def test_native_shift_and_rotation_align_without_mutating_sources(self):
        import cv2
        reference = self.specimen()
        warp = cv2.getRotationMatrix2D((125, 110), 1.6, 1)
        warp[:, 2] += (4, -3)
        current = cv2.warpAffine(reference, warp, (250, 220), borderMode=cv2.BORDER_REFLECT)
        current[130:140, 110:116] = 240
        before_current, before_reference = current.copy(), reference.copy()
        mask, stats = suggest_advanced(current, settings={'min_area': 3},
                                      automation={'method': 'reference', 'reference_ids': ['rotated'],
                                                  'reference_rotation': 2, 'reference_max_shift': 8},
                                      references=[('rotated', reference)])
        self.assertGreater(np.count_nonzero(mask[131:139, 111:115]), 24)
        self.assertLess(np.count_nonzero(mask), 1000)
        self.assertAlmostEqual(abs(stats['reference_alignments'][0]['rotation_degrees']), 1.6, delta=.15)
        np.testing.assert_array_equal(current, before_current)
        np.testing.assert_array_equal(reference, before_reference)

    def test_reference_alignment_fails_closed_on_wrong_or_uninformative_images(self):
        source = self.specimen()
        cfg = {'method': 'reference', 'reference_ids': ['good'], 'reference_min_correlation': .99}
        unrelated = rgb(np.random.default_rng(883).integers(30, 230, (220, 250)))
        for reference in (unrelated, np.full_like(source, 120)):
            with self.subTest(uniform=bool(np.std(reference) == 0)), self.assertRaisesRegex(ValueError, 'Reference.*(alignment|texture|correlation)'):
                suggest_advanced(source, automation=cfg, references=[('good', reference)])

    def test_reference_shift_limits_and_missing_images_fail_closed(self):
        import cv2
        reference = self.specimen()
        shifted = cv2.warpAffine(reference, np.float32([[1, 0, 7], [0, 1, 0]]), (250, 220))
        cfg = {'method': 'reference', 'reference_ids': ['good'], 'reference_max_shift': 1}
        with self.assertRaisesRegex(ValueError, 'Reference.*(exceeded|converge|correlation)'):
            suggest_advanced(shifted, automation=cfg, references=[('good', reference)])
        for refs in (None, [], [('good', reference[:100])]):
            with self.subTest(refs=type(refs).__name__), self.assertRaises(ValueError):
                suggest_advanced(reference, automation=cfg, references=refs)


if __name__ == '__main__':
    unittest.main()
