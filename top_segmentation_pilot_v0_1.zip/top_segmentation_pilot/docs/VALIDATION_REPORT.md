# Validation Report

Release: **0.1.0 — Top Segmentation Pilot**

This report distinguishes software checks from model-performance evidence. No real inspection dataset or trained weights are included.

The Python suite completed **46 tests: 44 passed and 2 skipped** because PyTorch was unavailable. The separate JavaScript raster tests passed. All Python files and package metadata parsed successfully, and 18 documented command examples were checked against the implemented argument parser.

The exact Python test transcript is included in [validation/unit_tests.txt](validation/unit_tests.txt).

## Verified software behavior

- Classical local-contrast proposals on controlled image fixtures, including empty/low-contrast cases and Inner/Outer region assignment.
- Native image copying, source-file preservation, duplicate handling, grouping, invalid-input rejection, and image/mask consistency.
- Annotation revisions, stale-write rejection, explicit clean approval, approved-only dataset snapshots, and snapshot independence from later edits.
- Grouped training/validation logic, historical group-role preservation, image/mask fit-and-pad geometry, ignored padding, restored native geometry, per-class metrics, and disappearing-defect checks using tests that do not require Torch.
- Local HTTP API behavior and JavaScript raster drawing operations.
- CLI help, synthetic demo generation, image import, and dependency checks.
- Package metadata parsing, shell launcher syntax, and documentation command consistency.

The CLI demonstration generated and imported 12 synthetic images at 720 × 640 pixels. It exercises the local workflow and does not establish detection quality on actual inspection images.

## Environment

The delivery checks used Python 3.12.14, NumPy 2.3.5, Pillow 12.3.0, SciPy 1.17.0, and PyYAML 6.0.3. The core dependency check succeeded. The optional training dependency check correctly reported PyTorch as unavailable.

## Unexecuted neural checks

PyTorch was not installed in the verification environment. The included executable tests for the following behaviors were therefore skipped:

- A real small-U-Net forward/backward pass with ignored padding.
- An approved dataset passing through real training, checkpoint loading, fine-tuning, and native-geometry prediction.

Actual training speed, GPU execution, trained segmentation quality, and checkpoint behavior under a real Torch runtime remain to be verified on the target computer. The test suite includes the neural checks so that they run when Torch is installed; a skipped test is not a passing neural test.

## Browser verification limit

Six real HTTP integration tests and the standalone JavaScript raster tests passed. A Chromium binary was unavailable, and its bounded download attempt failed. Full browser interaction and visual layout therefore remain unverified in this environment; no browser screenshot or successful browser test is claimed.

The optional browser test creates its own synthetic project and exercises proposal loading, circle/polygon drawing, undo/redo, saving, approval, navigation, clean approval, and source preservation. It does not open an operator's annotation project.

## Reproduce checks

From the project root:

```bash
python segmentation.py doctor
python -m unittest discover -s tests -v
```

For JavaScript raster checks, with Node.js installed:

```bash
node tests/test_mask.js
```

Node.js is needed only for this developer test command, not for operating the browser annotation interface.

For the optional browser test, with Playwright and its Chromium binary already installed locally:

```bash
node tests/test_ui_browser.js
```

It uses `python` from the current environment to start an isolated fixture. Set `PYTHON` to another interpreter path if needed. A missing optional browser dependency returns exit code `77` (skipped), not a passing test.

After installing training support:

```bash
python segmentation.py doctor --training
python -m unittest discover -s tests -v
```

Complete a short trial with reviewed annotations before investing in a larger labeling or training run. Validate the annotation definitions and small-defect resolution on representative images. The pilot's development validation metrics do not certify a production pass/fail decision.
