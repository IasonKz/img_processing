# ROI architecture and data contract

Inspection Studio v6.2 provides dedicated ROI workflows. Classification, whole-image TOP defect segmentation, and TOP/BOTTOM ROI detection have separate navigation and responsibilities. Existing classification model families, search profiles, image-depth handling, and whole-image TOP segmentation remain the underlying backends.

## Responsibilities

| Workspace | Responsibility |
| --- | --- |
| Classification | Whole-image TOP/BOTTOM/VIG and classifier experiments on reviewed ROI crops. |
| Segmentation | Whole-image TOP defects, TOP/BOTTOM crop defect annotations/search/evaluation, and geometric ROI localizer training. |
| ROI Detection | Import source images, assign physical-unit splits, define geometry, localize/review ROIs, annotate ROI quality, export crops/geometry datasets, share crop defect annotations, and apply the trained ROI localizer. |

ROI-localization segmentation learns where selected regions are. It does not assign defect classes or Good/Bad quality labels. Whole-image TOP defect segmentation remains independent. Crop defect segmentation uses the same semantic studio engine with immutable ROI lineage and inherited splits; geometry localization retains its independent-channel engine. See [the shared workflow](ROI_SEGMENTATION.md).

## Geometry contract

Templates use `inspection_roi_template.v1`, normalized coordinates relative to the EXIF-oriented reference image, and a recorded reference width/height. `camera_geometry_annotation.v1` exports are accepted as input and converted from their image coordinates. A polygon has at least three vertices, a circle stores its center and a radius-defining point, and a point stores one coordinate pair.

The TOP starter contains `label`, `corner_TR`, `corner_BL`, `inner_area`, `lens`, `lens_center`, and `die_outline`. The latter two serve as disabled-by-default crop targets. BOTTOM contains 16 named pins (`pin_r1_c1` through `pin_r4_c4`), `triangle`, and `square` (the rectangular side feature). Starters are editable guides; their dimensions are not measurements of the inspected modules.

Every localized ROI retains expected geometry and optional observed geometry. Expected geometry supplies a crop even when an object is missing or damaged. This geometry must not be presented as an observed object boundary or as evidence that the object is good. Semantic IDs refer to the reference orientation, including when a capture is rotated by a multiple of 90 degrees.

## Independent evidence

The project keeps localization provenance, geometry review, and quality labels independent:

- `detected`, `inferred`, and manually edited geometry describe how position was obtained.
- Geometry approval establishes that the intended region is suitable for extraction.
- An explicit Good/Bad quality label establishes a supervised classification target. Unknown or absent labels are excluded from binary supervised export.

An image-level Bad tag is source metadata. It is not copied to all ROI targets. A localization failure or absent classifier result cannot support an automatic Good decision.

## Dataset lineage

Assign physical units and train/development/test roles before generating crops. TOP and BOTTOM records representing the same unit must share a unit ID and split. Exact decoded-image duplicates must not cross splits, even when their filenames or claimed units differ. A missing reliable unit ID must remain visible to the operator rather than silently being treated as proof of independence.

Each exported crop must remain traceable to source image, physical unit, tray, ROI ID, geometry/template version, crop settings, and split. Classification uses the existing grouped backend; a three-way train/val/test export is accepted by that backend, which subdivides the development `val` set into validation, threshold, and selection groups. This requires enough independently labeled units in development. The final test set remains held out.

Independent TOP masks are required because the inner area, lens, and other regions may overlap. A mutually exclusive class map would destroy that overlap. An expected support mask answers where to inspect; it is not necessarily the visible material silhouette. Inspection-support masks and visible-object segmentation targets need different interpretations for missing pins and damaged corners.

## Crop and model consistency

Localization may use contrast enhancement on a working copy. Crop pixel values come from the source image, with the same recorded crop procedure available to export and inference. Masks are separate from context crops so masking cannot erase a bridge between pins or a defect beyond an ideal outline. Crop margins are part of the recorded recipe.

Changes to a template, annotation, split, or crop recipe require new derived artifacts and new evaluation. Historical classifier experiments retain their recorded configuration. A trained classifier on manually corrected crops must also be evaluated with automatically localized crops before its complete workflow can be considered measured.

## Files and modules

`nilt/roi/geometry.py` defines the template and coordinate contract. `localization.py` implements conservative CV registration, `crops.py` is the shared native-depth extraction primitive, `project.py` owns saved annotations and physical-unit identity, and `datasets.py` creates snapshots. `classification.py` validates ROI exports and selects the existing classification backend. `learning.py` implements the separate ROI segmentation model and frozen mask evaluation; worker entry points keep long operations outside the HTTP handler. `nilt/dashboard_roi.py` mounts the ROI API in the existing loopback dashboard.

The dashboard stores `roi_detection/top/project.json`, `roi_detection/bottom/project.json`, and a shared `roi_detection/unit_splits.json`. Each view has an append-only `history.jsonl` audit and versioned `exports/<id>/` directories. Export contents are:

| Path | Meaning |
| --- | --- |
| `recipe.json`, `reference.png` | Template/crop configuration and reference pixels for this snapshot. |
| `annotations/*.json` | Source identity and reviewed per-image geometry/quality evidence. |
| `crops/<kind>/*.png`, `crop_masks/<kind>/*.png` | Context crops and separate masks, including unlabeled crops. |
| `crops_manifest.json` | Source-to-crop mapping, ROI ID, unit, split, crop transform, and validity metadata. |
| `classification/<kind>/<split>/<good-or-bad>/` | Only explicit binary quality targets. |
| `classification/<kind>/groups.csv`, `roi_dataset.json` | Physical-unit grouping and scope/version identity for classifier handoff. |
| `segmentation/manifest.json`, `images/`, `masks/`, `valid_masks/` | Independent-channel localization targets; zero valid-mask pixels contribute neither positive nor negative supervision. |
| `manifest.json` | Snapshot summary, included/skipped data, and crop failures. |

Interrupted exports retain an `INCOMPLETE.json` marker and are not registered as completed snapshots. A snapshot's initial recipe has no trained classifiers or calibrated quality thresholds; it is not a complete production classifier simply because it contains geometry and crops.

## Shared crop annotation bridge

`nilt/dashboard_segmentation.py` verifies completed owned ROI exports and binds a workspace per `side/kind/export`. `nilt/segmentation_bridge.py` mounts it at `/segmentation/<side>/roi/<kind>/<export>/`. Its annotation editor and the editor in ROI Detection use the same `Project` and session; source paths and group assignment cannot be changed through the mounted config API.

`source.json` freezes crop provenance/checksums. Native uint16 working copies and snapshots stay uint16; only the editor display is eight-bit. `topseg/roi_sources.py` assigns every approved crop to its original unit role and refuses missing training/validation defect support. Direct training, Optuna search, evaluation, prediction and model packages use compatible input precision and provenance. A held-out test role never becomes training because of search fractions or a changed seed.

The old `/api/roi/train` and `/api/roi/evaluate` routes remain compatible. The new `/api/segmentation/localizer/train` and `/evaluate` aliases call the same durable worker and retain existing model/history locations. BOTTOM whole-image mounting is refused; recovery still loads legacy workers for global stop. New crop workspaces are also recovered before their tabs are opened.

## ROI localization segmentation model

The local ROI model is a small U-Net trained from scratch with independent sigmoid output channels (`roi_segmentation_model.v1`). It makes no pretrained-weight downloads. Training uses train data for optimization and val data for checkpoint selection, with valid-mask-weighted loss. It stores `model.json`, `best.pt`, `last.pt`, `history.json`, and `status.json`. The default per-channel mask threshold is fixed at 0.5; the model metadata labels it as uncalibrated.

Frozen evaluation produces masked Dice/IoU with supervised and ignored pixel counts. These are semantic-mask metrics, not full ROI localization or quality-classification metrics. Missing positive training support is reported explicitly; it must not be interpreted as a successfully learned channel. CV, segmentation, and hybrid localization modes retain expected geometry while recording observed model components separately.

## Validation scope

Synthetic tests establish software behavior, lineage, failure handling, and GUI/API integration. They do not establish localization accuracy or defect-detection performance on production modules. Calibration of real geometry, representative defects, orientation ambiguity, and independent-tray performance requires representative production data.

The optional `tests/browser_roi_workflow.cjs` uses Playwright and an installed Chromium, an isolated temporary project, synthetic PNGs, and the actual local dashboard APIs. Set `STUDIO_PYTHON` to the project's Python if necessary and `STUDIO_BROWSER_EXECUTABLE` for a browser outside Playwright's managed location. It checks category navigation, persistent unit grouping, geometry/quality separation, shared crop review, fullscreen, the moved localizer controls, exports, and classifier handoff; it does not assess canvas ergonomics or production accuracy. Browser availability is a test-environment prerequisite, not an application dependency.
