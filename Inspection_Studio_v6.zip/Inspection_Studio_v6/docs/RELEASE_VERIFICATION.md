# Release verification — Inspection Studio 6.0.0

Verification date: 28 September 2026.

## Executed checks

Environment: Linux, Python 3.12, PyTorch 2.7.1+cpu, torchvision 0.22.1+cpu, Optuna 4.5.0, and the installed ONNX CPU runtime.

| Check | Result |
| --- | --- |
| Full Python regression suite | 430 tests run; 429 passed; 1 Windows-specific file-lock test skipped; no failures |
| Additional dashboard execution integration | 9 passed: checkpoint integrity, paths, DirectML device arguments, cancellation controls and authenticated HTTP route |
| JavaScript behavior harnesses | 5 passed: existing interface, custom search, analytics, radar charts, conditional review metrics |
| Firefox browser with real local server | Passed at desktop and laptop widths; no JavaScript errors |
| Custom search contract | Nine samplers, NSGA-II options, unrestricted 48-hour budget, intensity and device settings checked |
| Native unsigned 16-bit | PNG/TIFF decoding, EXIF orientation, tensors, identity hashes and no intermediate 8-bit truncation checked |
| ONNX deployment | Actual native 16-bit ResNet export and standalone inference; Good / Review / Bad parity checked |
| Cancellation | Actual CPU training interrupted during first epoch; saved partial weights loaded for diagnostic predictions |
| Supplied NILT terminal animation | Five tests and a Linux pseudo-terminal dashboard smoke check passed |
| DirectML | Device routing and error checks exercised with mocks; no physical Intel GPU execution |
| Dataset preparation | Native PNG round trip, unchanged VIG dimensions, explicit 8-bit quantization, provenance and folder output checked |

The browser used synthetic records for chart display and uncertainty-source examples. They are not production model scores. `validation/browser-report.json` identifies those fixtures. GPU selection in that check validates configuration, not hardware execution.

The full suite log is retained in `validation/unit_tests.txt`. Additional execution checks are in `validation/dashboard_execution.txt`; interface checks are in `validation/interface_tests.txt`.

## Practical limits

- Windows launchers, native file locking and process behavior require a destination-machine check. Linux results do not establish them.
- The separate DirectML installer performs a real forward/backward probe on the selected Windows adapter. A successful probe still does not qualify all architectures, image sizes or driver versions.
- CUDA/DirectML throughput, memory capacity and numerical behavior require target-hardware measurements.
- Uncertainty routing is a configurable heuristic; review cases remain abstentions. Conditional accuracy must be read alongside coverage and review workload.
- An unfinished checkpoint is diagnostic and is not promoted to a fully evaluated model. A forced kill can only retain already committed files.
- No production images were available for this release check. Defect detection quality, crop/alignment acceptance and operating thresholds require representative labelled images and a reserved final test.

## Repeat checks

PowerShell, from the extracted project folder:

```powershell
$StudioPython = (Get-Content .studio-python.txt -Raw).Trim()
& $StudioPython -m unittest discover -s tests -p 'test_*.py'
```

Linux:

```bash
.venv-studio6/bin/python -m unittest discover -s tests -p 'test_*.py'
```

Optional interface checks with Node.js:

```bash
node tests/test_v4_ui.cjs
node tests/test_v5_ui.cjs
node tests/test_v5_analytics.cjs
node tests/test_v6_radars.cjs
node tests/test_v6_review_metrics.cjs
```

`tests/browser_v6_smoke.cjs` additionally requires Playwright and Firefox for development verification. Node.js and Playwright are not runtime requirements for operators.
