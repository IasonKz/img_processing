# Preprocessing / Data processing

This first dashboard tab supports labelled CSVs and untagged tester folders.
`tools/good_bad_folders.py`, `tools/tray_untagged_preprocess.py` and
`inspection.py preprocess` share the image-processing engine in
`nilt/dataset_preparation.py`. Untagged capture discovery and export live in
`nilt/untagged_preparation.py`, adapted from the standalone
`tray_untagged_preprocess.py` without duplicating its geometry algorithms.
The original model-input and patch transformations remain in `nilt/preprocessing.py`.

## Prepare an untagged tester folder for classification

1. Select **Untagged tester folder → classification** in **Input mode**.
2. Enter or **Browse…** for the original tester folder. Supported inputs are a tray,
   a parent containing several trays, or `MeasurementData/Results` directly.
   When available, scanning prefers `MeasurementData/Results`. It skips
   `EvaluationResults` directories and symlinked files/directories.
3. Choose a **new or empty** output folder outside the input. Its sibling
   `__review` and, when enabled, `__debug` folders must also be new or empty.
   Source images are never moved or overwritten.
4. TOP/BOTTOM default to **Final / post**: captures such as `ViTopFinal` and
   `ViBottomPostTarget` are included; `ViTopStart` and `ViBottomStart` are skipped.
   VIG is included in every mode. **All** and **Start / pre** remain explicit
   alternatives. Unknown TOP/BOTTOM stages are included only in All.
   Use the same stage as the model's training data.
5. Match the training preparation's brightness, sensor white level and output
   depth. **Native** preserves uint8/uint16 precision by default. For the supplied
   standalone script's uint8 output, explicitly select **8-bit**. Both modes
   retain native spatial scale; TOP/BOTTOM alignment uses linear interpolation.
6. Run **Scan capture names** for counts and exclusions without writing images.
   Run **Prepare classification images** to process copies in a managed worker.
   **Stop after current image** preserves partial output and marks it cancelled;
   **Stop Python workers** can stop a stuck worker immediately.
7. Inspect the per-task counts, processing log and sibling crop overlays. For
   a complete preparation, select **VIG**, **TOP**, or **BOTTOM**, then click
   **Use prepared images → classify**. This opens that task's Whole image
   classification view, fills only its image folder, and disables reference
   labels. It also fills the inspection sequence input. Choose an appropriate
   saved decision, frozen system or sequence before starting classification.

Default capture recognition is case-insensitive: `ViTop…`, `ViBottom…`,
`FlatFieldBright`, and `ViVig…` at filename token boundaries. Alignment and
side captures are not selected. **Custom capture names** exposes optional
filename regex overrides. A filename matching several tasks stops the scan
before export. For custom TOP/BOTTOM tokens without a recognizable stage,
select All. Repeated filenames receive deterministic suffixes; no source is
silently replaced. Unsupported captures and stage exclusions are logged as
skipped and do not make an otherwise successful preparation incomplete.

```text
prepared_captures/
  vig/           processed PNGs, no labels
  top/           processed PNGs, no labels
  bottom/        processed PNGs, no labels
  preparation.json
  processing.jsonl
  summary.json
prepared_captures__debug/     full-size overlays when enabled
prepared_captures__review/    copies of originals that failed processing
```

Overlays and failed originals remain outside the recursive classification
input. Untagged preparations cannot become the training dataset through the
preprocessing handoff; existing training dataset settings stay in place.
Switching from an ROI classifier selects the saved Whole image configuration.
Incomplete or cancelled preparations require review and a fresh output folder
before automatic handoff. No good/bad labels or measured accuracy are invented.
Reports and job history survive dashboard restart.

## Prepare labelled CSVs for training

1. Enter one local evaluation CSV path per line. Multiple CSVs can provide
   VIG, TOP and BOTTOM together. Relative paths are resolved against the project
   configuration folder. CSVs use semicolons and the existing `Quality_VI_*_Label`
   and `Quality_VI_*_Sources` columns. `p` means good; `f` and `x` mean bad.
2. Choose a **new or empty** output folder. Existing datasets are never merged
   or overwritten. Optionally select a relocated tray root when source paths
   refer to another computer; matching preserves the full suffix below the tray.
3. Keep **Native** output depth to retain uint8/uint16 intensity precision.
   Select 8-bit only when explicit quantization is required. Leave sensor white
   level blank for the full uint16 range, or enter a verified sensor range such
   as 4095 for a known 12-bit encoding. Values above that level are rejected.
4. Choose VIG brightness normalization and full-size crop overlays. Brightness
   normalization changes intensities; disable it when absolute exposure matters.
5. Run **Check CSV references** to validate labels and file references. This
   writes an operation report, but no dataset images. It does not validate crops.
6. Run **Prepare dataset** and follow its progress in the results and operation
   log. Processing runs in a managed worker; closing the browser does not stop it.
7. Inspect counts and overlays. For a complete preparation, select a task and
   click **Use prepared dataset → setup**. This saves a configuration copy for
   all available prepared tasks and opens dataset setup. Audit before training.

Only one workspace operation runs at a time. **Stop after current image** requests
a cooperative stop before the next image. CSV validation finishes first. Partial
output is retained and is marked cancelled; prepare into a new folder to rerun.
Operation history and completed reports remain available after dashboard restart.

## Image processing

VIG retains full image dimensions and optionally applies gain/gamma brightness
normalization. TOP and BOTTOM detect the die, align and crop at native scale,
with 4% and 3% margins respectively. There is no fixed-size downsampling.
Alignment interpolates pixels, and material outside the crop is removed.
Review overlays for defects near the edges. Apply the same preparation to future
inference captures as to the training data.

The preparation produces:

```text
prepared_dataset/
  vig/good/      vig/bad/
  top/good/      top/bad/
  bottom/good/   bottom/bad/
  _debug/       full-size crop overlays when enabled
  _review/      originals that failed preparation
  preparation.json
  processing.jsonl
  summary.json
```

Original source images are unchanged. Unknown labels, empty source cells and
missing references are counted as omissions. Conflicting labels fail before
export. Failed images remain outside training folders with their manual label
and error recorded in the processing log. Incomplete preparations and CSV-only
checks cannot automatically become the training dataset.

## Dashboard identity

All tabs use the NILT logo and corporate blue (`#0076bd`), with
navy/black Night mode, optional Light mode, technical typography for paths/metrics,
and a dark operation log.
The layout supports desktop and mobile widths, keyboard focus and reduced motion.
Fonts, logo and styles require no external service.
