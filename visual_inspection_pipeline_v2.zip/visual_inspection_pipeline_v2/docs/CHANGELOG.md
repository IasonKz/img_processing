# Changelog

## 2.0.0

- Added project-level task configuration with CPU pilot and GPU workstation profiles.
- Added PatchCore-style normal-feature memory banks alongside the supervised roster.
- Added automatic image-envelope discovery without a fixed 600×600 assumption.
- Added tracked model state, immutable manifests, continuation checkpoints, and frozen-version comparison.
- Added ONNX packages with independent runtime scripts, package integrity, and parity verification.
- Added training-package relocation, current-model registration, and rollback support.
- Added English operator, installation, model-management, and deployment documentation.
- Retained defect-oriented decision policy, separate development/test roles, and image-folder exports.

### Scope limits

This release does not implement pairwise new-damage classification, camera-die cropping/alignment, tiled training, grouped cross-validation, automatic hyperparameter search, probability calibration, quantization, a graphical interface, or machine/PLC control. The PatchCore-style implementation differs from the published reference scoring method as documented in [MODELS_AND_METRICS.md](MODELS_AND_METRICS.md).

Actual test coverage and hardware acceptance status are recorded in [VALIDATION_REPORT.md](VALIDATION_REPORT.md). No accuracy or throughput is asserted for a customer dataset before the relevant experiment has run.
