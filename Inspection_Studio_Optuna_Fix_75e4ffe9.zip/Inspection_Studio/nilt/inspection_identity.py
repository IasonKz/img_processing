"""Physical-unit and capture-view identities shared by inspection evidence."""
import hashlib
import re
from pathlib import Path

from .data import tray_unit_identity

VIEWS = ("top", "bottom", "vig")


def capture_view(path, default=None):
    path = Path(str(path).replace("\\", "/"))
    views = {part.lower() for part in path.parts[:-1] if part.lower() in VIEWS}
    name = path.name
    for view in VIEWS:
        if re.search(rf"(?:^|[_\-.])(?:vi)?{view}(?:[A-Za-z0-9]*)(?=[_\-.]|$)", name, re.I):
            views.add(view)
    if re.search(r"(?:FlatFieldBright|BrightField|FlatFieldCorrected)", name, re.I):
        views.add("vig")
    if len(views) > 1:
        raise ValueError("Capture identifies conflicting inspection views: " + str(path))
    return next(iter(views), default)


def physical_unit(path, explicit=None, tray=None, origin=""):
    try:
        result = tray_unit_identity(Path(path).name)
        return {**result, "identity_status": "filename"}
    except ValueError:
        pass
    if explicit:
        match = re.fullmatch(r"C(\d+)[:_]R(?:c)?(\d+)[:_]C(?:c)?(\d+)", str(explicit), re.I)
        if match:
            t, r, c = map(int, match.groups())
            return {"unit_id": f"C{t}:R{r}:C{c}", "tray": f"C{t}", "row": r, "column": c,
                    "identity_status": "explicit"}
        if len(str(explicit)) > 512:
            raise ValueError("Unit identity exceeds 512 characters.")
        return {"unit_id": str(explicit), "tray": str(tray or "Unassigned"), "row": None,
                "column": None, "identity_status": "explicit"}
    digest = hashlib.sha256((str(origin) + ":" + str(path)).encode()).hexdigest()[:16]
    return {"unit_id": "Unassigned:" + digest, "tray": "Unassigned", "row": None,
            "column": None, "identity_status": "unconfirmed"}


def roi_crop_sources(input_root):
    """Read lineage only from an export containing the selected input folder."""
    from .common import read_json
    root = Path(input_root).resolve()
    for directory in (root, *list(root.parents)[:4]):
        manifest = directory / "crops_manifest.json"
        if not manifest.is_file() or manifest.is_symlink():
            continue
        data = read_json(manifest)
        if data.get("schema") != "roi_crops.v1":
            continue
        found = {}
        for row in data.get("samples", []):
            relative = Path(row.get("path", ""))
            candidate = (directory / relative).resolve()
            if relative.is_absolute() or ".." in relative.parts or not candidate.is_relative_to(directory):
                raise ValueError("ROI lineage contains an escaping crop path.")
            annotation = directory / "annotations" / (str(row["image_id"]) + ".json")
            if not annotation.resolve().is_relative_to(directory):
                raise ValueError("ROI source annotation escapes its export.")
            source = read_json(annotation) if annotation.is_file() and not annotation.is_symlink() else {}
            found.setdefault(candidate.name, []).append({**row, "export_root": str(directory),
                "source_image": source, "crop_path": str(candidate)})
        return found
    return {}
