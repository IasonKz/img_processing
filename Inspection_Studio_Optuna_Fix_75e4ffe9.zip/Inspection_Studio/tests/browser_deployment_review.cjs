"use strict";
// Real dashboard, managed worker, native evidence and report downloads.
// Fixtures and model outputs are synthetic; this verifies workflow behavior.
// STUDIO_PYTHON=/path/to/python STUDIO_BROWSER_EXECUTABLE=/path/to/chromium \
//   node tests/browser_deployment_review.cjs /tmp/deployment-review-browser
const fs=require("node:fs"),path=require("node:path"),os=require("node:os"),assert=require("node:assert/strict");
const {spawn,spawnSync}=require("node:child_process"),net=require("node:net");
const {chromium}=require("playwright");
const repo=path.resolve(__dirname,".."),temporary=fs.mkdtempSync(path.join(os.tmpdir(),"inspection-quality-browser-"));
const output=path.resolve(process.argv[2]||path.join(os.tmpdir(),"inspection-quality-browser-evidence"));
const python=process.env.STUDIO_PYTHON||"python";
fs.mkdirSync(output,{recursive:true});
let browser,server,page,serverLog="";
const fixture=String.raw`
import json,runpy,shutil,sys
from pathlib import Path
from nilt.common import read_json,write_json
from nilt.deployment_review import build_review
root=Path(sys.argv[1])
f=runpy.run_path('tests/test_deployment_review.py')['inspection_fixture'](root)
build_review({'run':str(f['run'])},f['run']/'quality_review/snapshots/initial')
second=f['run'].with_name('previous_inspection')
shutil.copytree(f['run'],second,ignore=shutil.ignore_patterns('quality_review'))
report=read_json(second/'report.json');report['session']=str(second/'sessions/vig')
write_json(second/'report.json',report)
build_review({'run':str(second)},second/'quality_review/snapshots/previous')
(root/'project.yaml').write_text('schema_version: 3\nproject_name: SYNTHETIC_QUALITY_REVIEW\npaths:\n  output_root: ./results\n  weights_root: ./weights\ntasks:\n  vig:\n    dataset_root: ./incoming/vig\n  top:\n    dataset_root: ./incoming/top\n  bottom:\n    dataset_root: ./incoming/bottom\n')
(root/'fixture.json').write_text(json.dumps({**{key:str(value) for key,value in f.items()},'previous':str(second)}))
`;
async function freePort(){return new Promise((resolve,reject)=>{const s=net.createServer();s.on("error",reject);s.listen(0,"127.0.0.1",()=>{const port=s.address().port;s.close(()=>resolve(port));});});}
async function request(endpoint){return page.evaluate(async endpoint=>api(endpoint),endpoint);}
async function waitOperation(){
  const deadline=Date.now()+60000;
  while(Date.now()<deadline){
    const state=await request('/api/state'),job=state.jobs[0];
    if(job && !['running','starting','unverified'].includes(job.status)){
      assert.equal(job.status,'finished',JSON.stringify(job));assert.equal(job.exit_code,0,JSON.stringify(job));await page.evaluate(()=>refresh());return;
    }
    await new Promise(resolve=>setTimeout(resolve,200));
  }
  throw Error('Quality-review worker timeout');
}
async function main(){
  const made=spawnSync(python,['-c',fixture,temporary],{cwd:repo,encoding:'utf8'});
  assert.equal(made.status,0,made.stderr);
  const f=JSON.parse(fs.readFileSync(path.join(temporary,'fixture.json'),'utf8'));
  const port=await freePort(),base=`http://127.0.0.1:${port}`;
  server=spawn(python,['-u','inspection.py','dashboard','--config',path.join(temporary,'project.yaml'),'--port',String(port),'--no-browser'],{cwd:repo,stdio:['ignore','pipe','pipe']});
  await new Promise((resolve,reject)=>{
    const timeout=setTimeout(()=>reject(Error('Dashboard startup timeout: '+serverLog)),20000);
    server.stdout.on('data',chunk=>{serverLog+=chunk.toString();if(serverLog.includes('Local dashboard:')){clearTimeout(timeout);resolve();}});
    server.stderr.on('data',chunk=>serverLog+=chunk.toString());
    server.once('exit',code=>{clearTimeout(timeout);reject(Error('Dashboard exited '+code+': '+serverLog));});
  });
  browser=await chromium.launch({headless:true,args:['--no-sandbox'],...(process.env.STUDIO_BROWSER_EXECUTABLE?{executablePath:process.env.STUDIO_BROWSER_EXECUTABLE}:{})});
  page=await browser.newPage({viewport:{width:1536,height:1024}});
  const errors=[];page.on('pageerror',error=>errors.push(error.message));
  await page.goto(base);
  await page.waitForFunction(()=>document.querySelector('#connection')?.textContent.includes('Connected'));
  await page.locator('#nav-deployment-quality').click();
  await page.waitForFunction(run=>document.querySelector('#qr-run').querySelector(`option[value="${run}"]`),f.run);
  await page.locator('#qr-run').selectOption(f.run);
  await page.waitForFunction(()=>document.querySelector('#qr-page').textContent.includes('3 matching units'));
  await page.waitForFunction(()=>document.querySelector('#qr-detail').textContent.includes('C83:R1:C1'));
  assert.equal(await page.locator('.qr-unit').count(),3);
  const nightColors=await page.evaluate(()=>({card:getComputedStyle(document.querySelector('#tab-deployment-quality .card')).backgroundColor,unit:getComputedStyle(document.querySelector('.qr-unit')).backgroundColor,image:getComputedStyle(document.querySelector('.qr-image')).backgroundColor}));
  for(const color of Object.values(nightColors))assert.equal([...color.matchAll(/\d+/g)].every(value=>Number(value[0])<100),true,JSON.stringify(nightColors));
  assert.match(await page.locator('#qr-detail').innerText(),/No quality decision/);
  assert.equal(await page.locator('#qr-gallery .qr-image').count(),3);
  await page.locator('#qr-gallery .qr-image').first().click();
  await page.locator('#qr-image-dialog[open]').waitFor();
  const first=await page.locator('#qr-image-title').innerText();
  await page.keyboard.press('ArrowRight');
  assert.notEqual(await page.locator('#qr-image-title').innerText(),first);
  await page.keyboard.press('ArrowLeft');
  assert.equal(await page.locator('#qr-image-title').innerText(),first);
  await page.locator('#qr-image-close').click();
  // Switching inspections must not reuse the previous snapshot ID.
  await page.locator('#qr-run').selectOption(f.previous);
  await page.waitForFunction(()=>document.querySelector('#qr-run').value.endsWith('previous_inspection')&&document.querySelector('#qr-page').textContent.includes('3 matching units'));
  await page.locator('#qr-refresh').click();
  await page.waitForFunction(()=>document.querySelector('#qr-detail h2')?.textContent==='C83:R1:C1');
  await page.locator('#qr-run').selectOption(f.run);
  await page.waitForFunction(()=>document.querySelector('#qr-detail h2')?.textContent==='C83:R1:C1');
  await page.locator('#tab-deployment-quality details.settings-group summary').click();
  for(const session of [f.top,f.bottom])await page.locator('#qr-sessions input').evaluateAll((inputs,value)=>{const input=inputs.find(input=>input.value===value);if(!input)throw Error('Missing session '+value);input.click();},session);
  await page.locator('#qr-segmentation input').evaluateAll((inputs,value)=>{const input=inputs.find(input=>input.value===value);if(!input)throw Error('Missing segmentation prediction');input.click();},f.segmentation);
  await page.locator('#qr-build').click();await waitOperation();
  await page.locator('#qr-refresh').click();
  await page.waitForFunction(()=>document.querySelector('#qr-detail').textContent.includes('1 segmentation'));
  const detail=await request('/api/deployment/quality?'+new URLSearchParams({run:f.run}));
  assert.deepEqual(detail.counts,{good:1,review:1,bad:1});
  assert.notEqual(detail.snapshot,'initial');
  await page.locator('#qr-image-kind').selectOption('mask');
  assert.equal(await page.locator('#qr-gallery .qr-image').count(),1);
  await page.locator('#qr-gallery .qr-image').first().click();
  await page.waitForFunction(()=>document.querySelector('#qr-image-large').complete&&document.querySelector('#qr-image-large').naturalWidth>0);
  assert.match(await page.locator('#qr-image-title').innerText(),/TOP · mask/);
  await page.locator('#qr-image-native').click();
  assert.match(await page.locator('#qr-image-viewport').getAttribute('class'),/native-size/);
  const nativeURL=await page.locator('#qr-image-native-link').getAttribute('href');
  const native=await page.request.get(base+nativeURL);assert.equal(native.status(),200);
  await page.locator('#qr-image-close').click();
  await page.locator('#qr-image-kind').selectOption('source');
  await page.locator('[data-qr-view="vig"]').click();
  assert.match(await page.locator('#qr-evidence').innerText(),/DECISION MARGIN/);
  assert.match(await page.locator('#qr-statistics').innerText(),/PERCENTILE/);
  assert.equal(await page.locator('#qr-gallery .qr-image').count(),1);
  await page.locator('#qr-image-view').selectOption('');
  await page.locator('#qr-result').selectOption('bad');
  await page.waitForFunction(()=>document.querySelectorAll('.qr-unit').length===1&&document.querySelector('.qr-unit strong')?.textContent==='C83:R1:C3');
  await page.locator('#qr-result').selectOption('');
  await page.locator('#qr-search').fill('C83:R1:C2');
  await page.waitForFunction(()=>document.querySelectorAll('.qr-unit').length===1&&document.querySelector('#qr-detail h2')?.textContent==='C83:R1:C2');
  await page.locator('#qr-search').fill('');
  await page.waitForFunction(()=>document.querySelectorAll('.qr-unit').length===3);
  await page.locator('[data-qr-unit]').first().click();
  await page.waitForFunction(()=>document.querySelector('#qr-detail h2')?.textContent==='C83:R1:C1');
  await page.locator('#qr-export-unit').click();await waitOperation();
  await page.locator('#qr-refresh').click();
  await page.waitForFunction(()=>document.querySelector('#qr-reports').textContent.includes('1 unit report'));
  const reports=await request('/api/deployment/quality?'+new URLSearchParams({run:f.run}));
  assert.equal(reports.reports[0].units,1);
  const zip=await page.request.get(base+reports.reports[0].zip_url);assert.equal(zip.status(),200);
  fs.writeFileSync(path.join(output,'SYNTHETIC-unit-report.zip'),await zip.body());
  const html=await page.request.get(base+reports.reports[0].html_url);assert.equal(html.status(),200);
  await page.locator('#qr-include-images').uncheck();
  await page.locator('#qr-export-all').click();await waitOperation();
  await page.locator('#qr-refresh').click();
  await page.waitForFunction(()=>document.querySelector('#qr-reports').textContent.includes('3 unit reports'));
  assert.equal(await page.locator('#qr-search').inputValue(),'');
  assert.equal(await page.locator('.qr-unit').count(),3);
  await page.locator('#tab-deployment-quality details.settings-group summary').click();
  for(const width of [1536,1024,760]){
    await page.setViewportSize({width,height:1024});
    await page.screenshot({path:path.join(output,`SYNTHETIC-quality-review-${width}.png`),fullPage:true});
    const overflow=await page.evaluate(()=>({page:document.documentElement.scrollWidth>innerWidth+1,main:document.querySelector('#main-content').scrollWidth>document.querySelector('#main-content').clientWidth+1}));
    assert.equal(overflow.page,false,JSON.stringify({width,overflow}));
    assert.equal(overflow.main,false,JSON.stringify({width,overflow}));
  }
  assert.deepEqual(errors,[]);
  fs.writeFileSync(path.join(output,'browser-report.json'),JSON.stringify({status:'passed',units:3,views:['top','bottom','vig'],realHTTP:true,managedWorkers:true,modelOutputs:'synthetic',checks:['unit previews and arrow navigation','cross-inspection snapshot switching','explicit classification and segmentation evidence','model masks and native downloads','score margins and cohort percentiles','unit filters','single-unit image report ZIP','batch metadata report','responsive page layout'],errors},null,2));
  process.stdout.write('PASS: deployment quality review, real managed workers, unit evidence, masks, distributions, report ZIP and responsive dashboard.\n');
}
main().catch(async error=>{
  fs.writeFileSync(path.join(output,'failure.txt'),String(error.stack));
  if(page)await page.screenshot({path:path.join(output,'SYNTHETIC-failure.png'),fullPage:true}).catch(()=>{});
  process.stderr.write(error.stack+'\n');process.exitCode=1;
}).finally(async()=>{
  if(browser)await browser.close();
  if(server){server.kill('SIGTERM');await new Promise(resolve=>{if(server.exitCode!==null)return resolve();server.once('exit',resolve);setTimeout(resolve,3000);});}
  fs.writeFileSync(path.join(output,'server.log'),serverLog);
  fs.rmSync(temporary,{recursive:true,force:true});
});
