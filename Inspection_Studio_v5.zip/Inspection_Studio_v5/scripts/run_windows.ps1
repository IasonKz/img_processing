[CmdletBinding()]
param(
    [ValidateSet('doctor', 'search', 'run')]
    [string]$Action = 'doctor',
    [ValidateSet('laptop', 'workstation', 'workstation_large')]
    [string]$Profile = 'laptop',
    [ValidateSet('vig', 'top', 'bottom')]
    [string]$Task = 'vig',
    [double]$Hours = 0
)

$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$Record = Join-Path $ProjectRoot '.studio-python.txt'
if (-not (Test-Path -LiteralPath $Record)) { throw 'Run Setup.cmd first.' }
$PythonExe = (Get-Content -LiteralPath $Record -Raw).Trim()
if (-not (Test-Path -LiteralPath $PythonExe -PathType Leaf)) { throw 'Recorded Python environment is missing. Run Setup.cmd on this computer.' }
$CommandArguments = @('inspection.py', $Action, '--config', 'project.yaml', '--profile', $Profile, '--task', $Task)
if ($Hours -ne 0) {
    if ($Action -ne 'search' -or $Hours -le 0) { throw '-Hours requires search and a positive allowance.' }
    $CommandArguments += @('--hours', $Hours.ToString([Globalization.CultureInfo]::InvariantCulture))
}
Push-Location $ProjectRoot
try {
    & $PythonExe @CommandArguments
    if ($LASTEXITCODE -ne 0) { throw "Operation failed with exit code $LASTEXITCODE. Read the error above." }
}
finally {
    Pop-Location
}
