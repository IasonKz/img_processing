# Start here — Inspection Studio 5

This is a local inspection-development release. Your images stay on this computer. It is not a certified production-line controller or a guarantee of a particular defect-detection rate.

## 1. Keep the previous version

Extract the entire archive into a **new, short local path**, for example `C:\Users\YOUR_NAME\InspectionStudio5`. This folder must contain `inspection.py`, `project.yaml`, `Setup.cmd`, `Start.cmd`, and `Start.sh`.

Do not replace your previous project, delete its virtual environment, or overlay old patch files. Move only the paths/settings you need; see [MIGRATION_V5.md](MIGRATION_V5.md).

## 2. Install once on each computer

### Windows 11

Install Python **3.12, 64-bit** through an approved software channel. Open PowerShell in this folder and run **one** setup command:

```powershell
# CPU laptop
.\Setup.cmd -Device cpu
```

```powershell
# NVIDIA workstation
.\Setup.cmd -Device cuda
```

Setup creates a separate environment, installs the matched packages, and tests computation on the selected device. It never removes an unrelated environment. If setup fails, read the error before continuing. Details: [Windows installation](docs/INSTALLATION.md).

After setup, launch or restart with:

```powershell
.\Start.cmd
```

`PS` means PowerShell. A visible `(venv)` prefix is not required: the launcher calls the selected interpreter directly.

### Arch Linux / other Linux

Follow [Linux installation](docs/INSTALLATION_LINUX.md) to create `.venv-studio5` with Python 3.12. Launch or restart with:

```bash
bash Start.sh
```

Do not replace Arch's system Python or copy a Windows virtual environment to Linux.

## 3. Preview the interface without images

Opening the dashboard does not require a real inspection dataset. Leave the sample data path in place, open the local address printed by the launcher, and inspect the views. Audit, training, and real classification need valid local inputs and will report missing data until configured. No fabricated training results are created.

Leave the launcher terminal open. The workspace is available at `http://127.0.0.1:8765` by default, on the same computer. To choose another port, use `Start.cmd -Port 8766` on Windows or `bash Start.sh --port 8766` on Linux.

## 4. Configure actual data

Edit the existing `tasks.vig.dataset_root` in `project.yaml`, for example:

```yaml
dataset_root: 'D:/InspectionData/vig'
```

On Linux, use a Linux path such as `/mnt/inspection/vig`. The folder must contain `good` and `bad` subfolders. Do not put predictions, review exports, results, or augmented copies inside the source dataset.

1. Choose the resource profile and a small model shortlist in **Train & search**.
2. Use **Download pretrained weights** once while online, then **Check installation**.
3. Audit the dataset and inspect duplicate, label, group, and split warnings.
4. Use profile defaults for the first run, or configure **Custom search** deliberately.
5. Start one search; watch trials, the operation log, and the search analytics.
6. Use the comparison plots and confusion matrices after completed candidates are available. Read the split label before comparing numbers.

Profiles initially suggest **2 hours**, **6 hours**, and **12 hours**. These are editable defaults, not limits. In **Custom Optuna**, select **CPU**, **CUDA**, or **Auto** independently of the profile, then set the total seconds, per-trial timeout, number of trials, and search ranges. Use `86400` seconds for 24 hours, for example. The total budget is shared across models and includes preparation/evaluation; it is not a promise of a particular number of trials.

## 5. Compare, decide, and review

After completed candidates exist, compare them on the recorded selection data. Use **Decision explorer** for a binary/scores-only decision, or **Decision lab** for Good / Review / Bad, weighted ensembles, held-out stacking, or cascades. Start with one model. Do not select a model on AP alone: compare bad escapes, good rejects, and review workload.

Classify a labeled local folder with copies enabled to inspect predictions beside your original tags in **Image review**. Human corrections remain separate from original images. Controlled review-dataset export and fine-tuning require holdout protection and representative replay; see [IMAGE_REVIEW.md](docs/IMAGE_REVIEW.md).

## 6. Pause and reopen safely

Use **Pause active search**, then wait for the worker to stop before changing code, moving files, or shutting down. Closing the browser does not pause training, and closing the dashboard console may leave its training worker running.

Reopen with the same launcher; no reinstallation is needed. Resume uses the original saved configuration and remaining allowance. A different model list, search space, decision recipe, or data revision is a new experiment. Do not reset trial states by editing the database.

Read [V5_DESIGN_AND_LIMITS.md](docs/V5_DESIGN_AND_LIMITS.md) for implemented features and boundaries, and [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) for error diagnosis.
