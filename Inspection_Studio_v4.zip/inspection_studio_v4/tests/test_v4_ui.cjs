/* Dependency-free browser-contract smoke tests. Run: node tests/test_v4_ui.cjs
 * This DOM harness exercises application handlers and API payloads; it does not
 * replace layout or native-browser verification on the deployment workstation.
 */
"use strict";
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const assert = require("node:assert/strict");
const ui = path.join(__dirname, "..", "nilt", "ui");
const decode = s => String(s).replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
const voidTags = new Set(["meta", "link", "input", "img", "hr", "br", "source"]);
class Element {
  constructor(tag, attributes={}) {
    this.tag = tag.toLowerCase(); this.attributes = {...attributes}; this.children = []; this.parentElement = null;
    this.handlers = {}; this._html = ""; this._text = ""; this._value = undefined;
    this.checked = "checked" in attributes; this.disabled = "disabled" in attributes;
    this.hidden = "hidden" in attributes; this.open = "open" in attributes;
    this.scrollHeight = 100; this.scrollTop = 0; this.clientHeight = 100;
    this.dataset = new Proxy({}, {get: (_, k) => this.attributes["data-" + String(k).replace(/[A-Z]/g, c => "-"+c.toLowerCase())],
      set: (_,k,v) => {this.attributes["data-" + String(k).replace(/[A-Z]/g,c=>"-"+c.toLowerCase())]=String(v);return true;}});
    this.classList = {toggle: (c,v) => {const a=new Set(this.className.split(/\s+/).filter(Boolean));if(v===undefined)v=!a.has(c);v?a.add(c):a.delete(c);this.className=[...a].join(" ");},
      add: c=>this.classList.toggle(c,true), remove: c=>this.classList.toggle(c,false),contains: c=>this.className.split(/\s+/).includes(c)};
  }
  get id(){return this.attributes.id||"";}
  get className(){return this.attributes.class||"";}
  set className(value){this.attributes.class=value;}
  get value(){
    if(this._value!==undefined)return this._value;
    if(this.tag==="select"){const all=this.querySelectorAll("option");return (all.find(o=>"selected"in o.attributes)||all[0])?.attributes.value||"";}
    return this.attributes.value||"";
  }
  set value(value){this._value=String(value);}
  set innerHTML(value){this._html=String(value);this._text="";this.children=[];this._value=undefined;parse(this._html,this);}
  get innerHTML(){return this._html;}
  set textContent(value){this._text=String(value);this._html=String(value);this.children=[];}
  get textContent(){return this._text||decode(this._html.replace(/<[^>]*>/g,""));}
  get lastElementChild(){return this.children.at(-1);}
  setAttribute(k,v){this.attributes[k]=String(v);}
  removeAttribute(k){delete this.attributes[k];}
  addEventListener(name,fn){(this.handlers[name]??=[]).push(fn);}
  showModal(){this.open=true;}
  close(){this.open=false;}
  matches(selector){
    if(selector.includes(":")){const [base,pseudo]=selector.split(":");return this.matches(base)&&(pseudo==="checked"?this.checked:false);}
    const attr=selector.match(/^(.*?)\[([^=\]]+)(?:=["']?([^\]"']+)["']?)?\]$/);
    if(attr)return (!attr[1]||this.matches(attr[1]))&&(attr[2]==="open"?this.open:attr[3]===undefined?attr[2]in this.attributes:this.attributes[attr[2]]===attr[3]);
    if(selector.startsWith("."))return this.classList.contains(selector.slice(1));
    if(selector.startsWith("#"))return this.id===selector.slice(1);
    return this.tag===selector.toLowerCase();
  }
  querySelectorAll(selector){
    const parts=selector.trim().split(/\s+/), leaf=parts.pop(), result=[];
    const walk=node=>{for(const child of node.children){if(child.matches(leaf)){let p=child.parentElement,idx=parts.length-1;while(p&&idx>=0){if(p.matches(parts[idx]))idx--;p=p.parentElement;}if(idx<0)result.push(child);}walk(child);}};
    walk(this);return result;
  }
  querySelector(selector){return this.querySelectorAll(selector)[0]||null;}
  closest(selector){let node=this;while(node){if(node.matches(selector))return node;node=node.parentElement;}return null;}
}
function parse(markup,root){
  const stack=[root], tags=markup.matchAll(/<!--[\s\S]*?-->|<![^>]*>|<\/?([A-Za-z][\w:-]*)([^>]*?)\/?\s*>/g);
  for(const match of tags){
    if(!match[1])continue;const tag=match[1].toLowerCase();
    if(match[0].startsWith("</")){for(let i=stack.length-1;i>0;i--)if(stack[i].tag===tag){stack.length=i;break;}continue;}
    const attrs={};for(const a of match[2].matchAll(/([^\s=\/]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g))attrs[a[1]]=decode(a[2]??a[3]??a[4]??"");
    const child=new Element(tag,attrs),parent=stack.at(-1);child.parentElement=parent;parent.children.push(child);
    if(!voidTags.has(tag)&&!match[0].endsWith("/>"))stack.push(child);
  }
}
const document=new Element("document");parse(fs.readFileSync(path.join(ui,"index.html"),"utf8"),document);
document.getElementById=id=>document.querySelectorAll("[id]").find(e=>e.id===id)||null;
const el=id=>{const e=document.getElementById(id);assert.ok(e,"Missing element "+id);return e;};
const metrics={n:2,accuracy:.5,bad_escape_rate:1,good_reject_rate:0,bad_detected_TP:0,bad_passed_as_good_FN:1,good_rejected_as_bad_FP:0,good_accepted_TN:1};
const decisions=[{path:"C:/decisions/a/decision.json",name:"A",candidate:"resnet18",mode:"manual",threshold:.3,source_run:"C:/results/run1"},{path:"C:/decisions/b/decision.json",name:"B",candidate:"efficientnet_b0",mode:"argmax",threshold:.5,source_run:"C:/results/run1"}];
const sessions=[{path:"C:/classified/session1",kind:"classification",progress:{status:"completed",total:2,completed:2}},{path:"C:/classified/session2",kind:"workflow",progress:{status:"completed",total:2,completed:2}}];
const items=[{id:"id1",relative_path:'bad/tray<script>alert(1)</script>.png',reference_label:"bad",prediction:"good",bad_score:.2,copied_path:"predicted/good/image.png",status:"ok",image_url:"/api/review-image?item_id=id1",review:{label:"unreviewed",note:""},reference_mismatch:true,stage_results:[{index:0,name:"First stage",status:"evaluated",score:.2,predicted_class:"good",threshold:.3},{index:1,name:"Second stage",status:"skipped",reason:"Previous decision ended cascade"}]},{id:"id2",relative_path:"good/image2.png",reference_label:"good",prediction:"good",bad_score:.1,copied_path:"predicted/good/image2.png",status:"ok",review:{label:"unreviewed",note:""},reference_mismatch:false}];
const workflows=[], calls=[];
const state=()=>({runs:[{path:"C:/results/run1",name:"run1",task:"vig",status:"READY"}],jobs:[],decisions,workflows,review_sessions:sessions,models:[]});
const run={path:"C:/results/run1",state:{status:"READY"},search:{completed_trials:1,failed_trials:1},trials:[{model:"resnet18",trial:0,state:"FAIL",outcome:"FAILED",seconds:30,failure:{error:"Permission denied <script>",traceback:"Traceback test"}}],histories:[],candidates:[],selected:{},splits:{},reports:[]};
const boot={token:"test-token",profile:"workstation",profiles:{laptop:2,workstation:6,workstation_large:12},tasks:["vig"],task_enabled:{vig:true},datasets:{vig:"C:/data/vig"},paths:{output:"C:/results",weights:"C:/weights",incoming:"C:/incoming",classified:"C:/classified",decisions:"C:/decisions",packages:"C:/packages",workflows:"C:/workflows"},profile_models:{laptop:["resnet18"],workstation:["resnet18","efficientnet_b0"]},models:["resnet18","efficientnet_b0"],config:"C:/project.yaml"};
async function fetchMock(url,options={}){
  const parsed=new URL(url,"http://localhost"), body=options.body?JSON.parse(options.body):null;calls.push({path:parsed.pathname,query:parsed.searchParams,body,options});let data;
  switch(parsed.pathname){
    case "/api/bootstrap":data=boot;break;
    case "/api/state":data=state();break;
    case "/api/run":data=run;break;
    case "/api/workflows":if(body){const d=body.definition;const record={...d,path:"C:/workflows/new/workflow.json",stages:d.stages.map((s,i)=>({...s,index:i,source_decision:s.decision,...decisions.find(x=>x.path===s.decision)}))};workflows.push(record);data={path:record.path,workflow:record};}else data=workflows;break;
    case "/api/review-sessions":data=sessions;break;
    case "/api/review":data={session:sessions[0],progress:sessions[0].progress,items:items.filter(i=>!parsed.searchParams.get("errors_only")||i.reference_mismatch),pagination:{page:1,page_size:24,total:2,pages:1},metrics:{dataset_reference:metrics,reviewed_only:metrics,effective_reference:metrics}};break;
    case "/api/review-label":items.find(i=>i.id===body.item_id).review={label:body.label,note:body.note};data={saved:true};break;
    case "/api/review-compare":data={comparable:true,n_images:2,n_labeled:2,sessions:body.sessions.map(p=>({path:p,name:p,kind:"classification",metrics,elapsed_seconds:10,images_per_second:.2})),note:"Matched original labels."};break;
    case "/api/action":data={job:"test"};break;
    case "/api/load-run":data={run,state:state()};break;
    default:throw new Error("Unmocked request "+url);
  }
  return {ok:true,json:async()=>JSON.parse(JSON.stringify(data))};
}
const context=vm.createContext({document,fetch:fetchMock,URLSearchParams,Date,Math,Number,String,Set,JSON,console,setTimeout,clearTimeout,setInterval:()=>0,queueMicrotask});
vm.runInContext(fs.readFileSync(path.join(ui,"app.js"),"utf8"),context,{filename:"app.js"});
const settle=async()=>{for(let i=0;i<8;i++)await new Promise(resolve=>setImmediate(resolve));};
async function emit(element,event){for(let e=element;e;e=e.parentElement)for(const fn of e.handlers[event]||[])await fn({target:element});await settle();}
const click=async id=>{const e=typeof id==="string"?el(id):id;assert.ok(!e.disabled,"Cannot click disabled "+e.id);await emit(e,"click");};
(async()=>{
  await settle();
  assert.equal(el("connection").textContent.startsWith("Connected"),true);
  assert.equal(el("profile").value,"workstation");assert.equal(el("hours").value,"6");assert.equal(el("predict-device").value,"cuda");
  assert.ok(el("trials-table").innerHTML.includes("Failure details"));assert.ok(el("trials-table").innerHTML.includes("Permission denied &lt;script&gt;"));
  for(const nav of document.querySelectorAll("nav button")){await click(nav);assert.ok(el("tab-"+nav.dataset.tab).classList.contains("active"));assert.equal(nav.attributes["aria-current"],"page");}
  await click("nav-workflow");
  assert.equal(el("workflow-stages").querySelectorAll("[data-stage]").length,1);
  await click("workflow-add");await click("workflow-add");
  assert.equal(el("workflow-stages").querySelectorAll("[data-stage]").length,3);
  let names=el("workflow-stages").querySelectorAll("[data-stage-name]");names[1].value="Second screen";await emit(names[1],"input");
  await click(el("workflow-stages").querySelectorAll("[data-stage-up]")[1]);
  assert.equal(el("workflow-stages").querySelectorAll("[data-stage-name]")[0].value,"Second screen");
  await click(el("workflow-stages").querySelectorAll("[data-stage-remove]")[2]);
  assert.equal(el("workflow-stages").querySelectorAll("[data-stage]").length,2);
  for(let i=0;i<2;i++){const select=el("workflow-stages").querySelectorAll("[data-stage-decision]")[i];select.value=decisions[i].path;await emit(select,"change");}
  el("workflow-rule").value="majority";await emit(el("workflow-rule"),"change");assert.ok(el("workflow-flow").innerHTML.includes("Count votes"));
  el("workflow-name").value="Three tray inspection";await click("workflow-save");
  const saved=calls.find(c=>c.path==="/api/workflows"&&c.body).body.definition;
  assert.equal(saved.rule,"majority");assert.deepEqual(saved.stages.map(s=>s.decision),decisions.map(d=>d.path));assert.equal(saved.stages[0].name,"Second screen");
  assert.equal(el("workflow-select").value,"C:/workflows/new/workflow.json");
  el("workflow-input").value="C:/validation";el("workflow-labeled").checked=true;await click("workflow-run");
  assert.equal(calls.filter(c=>c.path==="/api/action").at(-1).body.action,"workflow-run");
  assert.equal(calls.filter(c=>c.path==="/api/action").at(-1).body.labeled,true);
  assert.ok(el("tab-review").classList.contains("active"));
  assert.equal(el("review-gallery").querySelectorAll("[data-review-index]").length,2);
  assert.ok(el("review-gallery").innerHTML.includes("&lt;script&gt;"));assert.equal(el("review-gallery").querySelectorAll("script").length,0);
  await click(el("review-gallery").querySelectorAll("[data-review-index]")[0]);assert.equal(el("image-dialog").open,true);
  assert.ok(el("image-trace").innerHTML.includes("Previous decision ended cascade"));
  el("image-review-label").value="bad";el("image-review-note").value="Defect at the edge";await click("image-save-review");
  assert.deepEqual(calls.filter(c=>c.path==="/api/review-label").at(-1).body,{session:"C:/classified/session1",item_id:"id1",label:"bad",note:"Defect at the edge"});
  assert.ok(el("image-save-status").textContent.includes("saved"));await click("image-close");
  el("review-errors").checked=true;await emit(el("review-errors"),"change");assert.equal(el("review-gallery").querySelectorAll("[data-review-index]").length,1);
  const compareOptions=el("session-compare-options").querySelectorAll("input");compareOptions.forEach(e=>e.checked=true);await click("session-compare");
  assert.equal(calls.filter(c=>c.path==="/api/review-compare").at(-1).body.sessions.length,2);assert.ok(el("session-compare-result").innerHTML.includes("50.0%"));
  el("workflow-name").value="Unsaved draft stays";el("predict-input").value="C:/custom path";await click("refresh");
  assert.equal(el("workflow-name").value,"Unsaved draft stays");assert.equal(el("predict-input").value,"C:/custom path");
  await click("workflow-clear");await click("refresh");assert.equal(el("workflow-stages").querySelectorAll("[data-stage]").length,0);
  await click("download-weights");assert.equal(calls.filter(c=>c.path==="/api/action").at(-1).body.action,"prepare-weights");
  assert.ok(calls.filter(c=>c.body).every(c=>c.options.headers["X-Inspection-Token"]==="test-token"));
  console.log("PASS: UI bootstrap, navigation, failure details, sequence edits/save/run, review/labels/trace/filters, comparison, polling input preservation, explicit weights action, CSRF and text escaping.");
})().catch(error=>{console.error(error);process.exitCode=1;});
