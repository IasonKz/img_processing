[CmdletBinding()]
param(
    [ValidateSet('', 'cpu', 'cuda')]
    [string]$Device = '',
    [string]$EnvironmentPath = '',
    [string]$OfflineWheelhouse = '',
    [switch]$WithExport
)

$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot

function Invoke-Checked {
    param([string]$Executable, [string[]]$Arguments)
    & $Executable @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Command failed with exit code $LASTEXITCODE : $Executable $($Arguments -join ' ')"
    }
}

if (-not $Device) {
    Write-Host 'Inspection Studio 5 - Windows setup'
    Write-Host '1. Laptop / CPU'
    Write-Host '2. NVIDIA workstation / CUDA'
    $Choice = Read-Host 'Select 1 or 2'
    if ($Choice -eq '1') { $Device = 'cpu' }
    elseif ($Choice -eq '2') { $Device = 'cuda' }
    else { throw 'Select 1 or 2. Run Setup.cmd again.' }
}

if (-not $EnvironmentPath) {
    $EnvironmentPath = Join-Path $env:USERPROFILE "venvs\studio5-$Device"
}
$EnvironmentPath = [IO.Path]::GetFullPath($EnvironmentPath)
$PythonExe = Join-Path $EnvironmentPath 'Scripts\python.exe'
$MarkerPath = Join-Path $EnvironmentPath '.inspection-studio.json'

Push-Location $ProjectRoot
try {
    if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot 'inspection.py'))) {
        throw 'The project is incomplete: inspection.py is missing. Extract the complete archive first.'
    }
    if (Test-Path -LiteralPath $EnvironmentPath) {
        if (-not (Test-Path -LiteralPath $MarkerPath)) {
            throw "Refusing to modify an unrelated environment: $EnvironmentPath. Choose a new path with -EnvironmentPath."
        }
        $Marker = Get-Content -LiteralPath $MarkerPath -Raw | ConvertFrom-Json
        if ($Marker.application -ne 'Inspection Studio 5' -or $Marker.device -ne $Device) {
            throw 'Environment ownership or device does not match. Choose a new -EnvironmentPath.'
        }
    }
    else {
        if (-not (Get-Command py -ErrorAction SilentlyContinue)) {
            throw 'Python launcher py was not found. Install 64-bit Python 3.12; see docs/INSTALLATION.md.'
        }
        Invoke-Checked -Executable 'py' -Arguments @('-3.12', '-c', 'import sys; assert sys.maxsize > 2**32')
        Invoke-Checked -Executable 'py' -Arguments @('-3.12', '-m', 'venv', $EnvironmentPath)
        @{ application = 'Inspection Studio 5'; device = $Device } |
            ConvertTo-Json | Set-Content -LiteralPath $MarkerPath -Encoding UTF8
    }
    Invoke-Checked -Executable $PythonExe -Arguments @('-c', 'import sys; assert sys.version_info[:2] == (3, 12); assert sys.maxsize > 2**32; print(sys.version)')

    if ($OfflineWheelhouse) {
        $WheelhousePath = (Resolve-Path -LiteralPath $OfflineWheelhouse).Path
        if (-not (Test-Path -LiteralPath $WheelhousePath -PathType Container)) {
            throw 'OfflineWheelhouse must be a directory of matching Windows / Python 3.12 wheels.'
        }
        $SourceArguments = @('--no-index', '--find-links', $WheelhousePath)
        Invoke-Checked -Executable $PythonExe -Arguments (@('-m', 'pip', 'install') + $SourceArguments + @('-r', 'requirements.txt', 'torch==2.7.1', 'torchvision==0.22.1'))
        if ($WithExport) {
            Invoke-Checked -Executable $PythonExe -Arguments (@('-m', 'pip', 'install') + $SourceArguments + @('-r', 'requirements-export.txt'))
        }
    }
    else {
        Invoke-Checked -Executable $PythonExe -Arguments @('-m', 'pip', 'install', '--upgrade', 'pip')
        Invoke-Checked -Executable $PythonExe -Arguments @('-m', 'pip', 'install', '-r', 'requirements.txt')
        $TorchIndex = if ($Device -eq 'cuda') { 'https://download.pytorch.org/whl/cu128' } else { 'https://download.pytorch.org/whl/cpu' }
        Invoke-Checked -Executable $PythonExe -Arguments @('-m', 'pip', 'install', 'torch==2.7.1', 'torchvision==0.22.1', '--index-url', $TorchIndex)
        if ($WithExport) {
            Invoke-Checked -Executable $PythonExe -Arguments @('-m', 'pip', 'install', '-r', 'requirements-export.txt')
        }
    }

    Invoke-Checked -Executable $PythonExe -Arguments @('-m', 'pip', 'check')
    $DeviceCheck = @'
import sys
import torch
import torchvision
import optuna, sklearn, scipy, matplotlib, yaml, psutil
print('PyTorch:', torch.__version__)
print('torchvision:', torchvision.__version__)
assert torch.__version__.split('+')[0] == '2.7.1', 'Unexpected torch version'
assert torchvision.__version__.split('+')[0] == '0.22.1', 'Unexpected torchvision version'
mode = sys.argv[1]
if mode == 'cuda':
    if not torch.cuda.is_available():
        raise SystemExit('CUDA is unavailable. Check the NVIDIA driver and CUDA wheel before using a workstation profile.')
    item = torch.cuda.get_device_properties(0)
    print('GPU:', item.name)
    print('VRAM GiB:', round(item.total_memory / 2**30, 2))
elif torch.version.cuda is not None:
    raise SystemExit('CPU setup found a CUDA wheel. Use a new CPU environment or matching CPU wheelhouse.')
device = torch.device(mode)
model = torchvision.models.resnet18(weights=None).to(device)
loss = model(torch.randn(2, 3, 64, 64, device=device)).square().mean()
loss.backward()
assert torch.isfinite(loss), 'Device computation produced a non-finite loss'
if mode == 'cuda':
    torch.cuda.synchronize()
print('Model forward/backward check passed on', mode)
'@
    $ProbePath = Join-Path $EnvironmentPath 'studio_device_check.py'
    try {
        [IO.File]::WriteAllText($ProbePath, $DeviceCheck, (New-Object Text.UTF8Encoding $false))
        Invoke-Checked -Executable $PythonExe -Arguments @($ProbePath, $Device)
    }
    finally {
        Remove-Item -LiteralPath $ProbePath -ErrorAction SilentlyContinue
    }
    Set-Content -LiteralPath (Join-Path $ProjectRoot '.studio-python.txt') -Value $PythonExe -Encoding UTF8
    & $PythonExe -m pip freeze | Set-Content -LiteralPath (Join-Path $ProjectRoot 'environment-installed.txt') -Encoding UTF8
    if ($LASTEXITCODE -ne 0) { throw 'Could not record the installed package versions.' }
    Write-Host ''
    Write-Host 'Setup complete.'
    Write-Host "Python: $PythonExe"
    Write-Host 'Next: set the dataset path in project.yaml, then open Start.cmd.'
    Write-Host 'Download public model weights from Dataset & setup before training.'
    Write-Host 'No inspection images were read or uploaded by setup.'
}
finally {
    Pop-Location
}
