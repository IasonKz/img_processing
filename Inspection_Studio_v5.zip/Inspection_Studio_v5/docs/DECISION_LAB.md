# Decision Lab: triage, ensembles, stacking, and cascades

**Decision explorer** retains the single-candidate policy/manual/argmax/scores-only workflow. **Decision lab** adds versioned systems that may abstain or combine multiple trained candidates. **Inspection workflow** retains the earlier Boolean voting sequences. These are separate saved artifact formats.

## Before building a system

Complete model search/finalization so source candidates have checkpoints, preprocessing, calibration scores, selection scores, and their integrity records. Choose sources with **exactly the same audited manifest and split assignments**, even if their run directories differ. The same checkpoint cannot be counted twice. Every source must inspect the same task/image, not different top/bottom/VIG captures.

The source networks are frozen during Decision Lab fitting. No image-model retraining is triggered by a threshold sweep or decision preview.

## System types

| Kind | What runs on an image | How the final score/decision is obtained |
| --- | --- | --- |
| `triage` | One frozen candidate | Two score thresholds |
| `weighted` | All selected candidates | Nonnegative weights normalized to sum to one, then two thresholds |
| `stacking` | All selected candidates | Regularized logistic regression on standardized source scores, then two thresholds |
| `cascade` | Stages in the saved order, until an allowed final decision | Each stage has its own two thresholds and accept/reject controls |

All modes use the same triage boundary convention:

- `score < good`: GOOD.
- `score >= bad`: BAD.
- Otherwise: REVIEW.

`good` must not exceed `bad`. Equal thresholds produce an ordinary binary rule, with equality rejected as BAD. REVIEW means no automatic good/bad decision, not a newly learned defect class and not a correct prediction. Threshold examples such as 0.2/0.8 are starting values, not validated production settings.

### Weighted scores

Use raw supervised bad scores only when this comparison is meaningful. Optional **Fit score calibration before combining** fits a regularized logistic mapping for each source on the calibration-fit groups. It is required before directly averaging a PatchCore distance with supervised scores. Fitting a mapping is not proof that the resulting score remains calibrated on new production trays.

Weights are not automatically the models' AP values. Complementary mistakes matter more than adding near-duplicate models. Optuna can search the ensemble weights jointly with thresholds; manual weights remain available.

### Held-out stacking

The combiner learns from source predictions on a group-disjoint **calibration-fit** subset. It uses those means/scales and a regularized logistic model at inference. Smaller `C` increases regularization. The remaining **calibration-tune** groups determine operating thresholds. Neither subset trained the source image models.

This is held-out stacking, **not automatic out-of-fold retraining of the source networks**. It is less computationally expensive but can be unstable with little calibration data. At least four independent groups and both classes in fit and tune are required; meeting that minimum is not statistical adequacy. All parameters, group assignments, counts, and warnings are saved. The small logistic combiner learns coefficients from data; image backbones still use pretrained initialization.

### Confidence cascade

Each stage chooses a source candidate, name, good/bad thresholds, and whether it may finalize GOOD and/or BAD. REVIEW moves to the next stage. A disabled accept or reject branch also moves that outcome onward. If no stage makes an allowed final decision, the image remains REVIEW.

Use a conservative early-accept boundary: an early false GOOD never reaches a later model. Order affects compute and routing. The per-image trace records visited/skipped stages. This is not the same as the old `any_bad`/`all_bad` Boolean shortcut.

The current cascade uses source model stages. It does not embed an arbitrary frozen stacked system as a nested stage, and automatic search does not reorder architectures. Choose source order and accept/reject policy manually; Optuna can tune stage thresholds within that order.

## Tuning methods

| Method | Supported use | Limitations |
| --- | --- | --- |
| Manual | Every system | Operator-supplied thresholds; preview is calibration evidence |
| Sweep | Triage, weighted, or stacking with a fixed score | Evaluates attainable ordered threshold pairs, not a fabricated uniform score grid; stops at its time limit and records completeness |
| Optuna | All kinds; optional weight search for weighted ensembles | TPE/Random, bounded trials and seconds; uses cached calibration-tune scores |

Choose maximum bad escape, good reject, and review fractions. Advanced JSON also exposes their relative costs and explicit good/bad threshold ranges. Invalid proposals with `good > bad` are pruned. The optimizer prioritizes reducing target violations and then operating cost; infeasible targets remain visibly unmet. It does not invent independent evidence or guarantee a requested production rate.

Decision tuning is fast compared with image training, but its timeout is checked between score-level trials. It is not a hard process deadline. The supplied manual rule is retained as a baseline so a search is not forced to replace it with a worse proposal.

## GUI sequence

1. Open **Decision lab** and select the decision method.
2. Add source candidates; set weights or stage boundaries as appropriate.
3. Choose manual thresholds, sweep, or Optuna. Start with simple manual triage when diagnosing the score distribution.
4. Use **Preview calibration performance**. Examine raw counts, automation, review workload, and feasibility, not just selective accuracy.
5. Use **Freeze new system**. The frozen recipe is created before the separate selection report is computed.
6. Select the saved system and use **Classify with this system**, or choose it in **Classify images → Frozen Decision Lab system**.
7. Enable copied images and reference labels when available, then inspect Image review.

Changing form controls never modifies a frozen system. Use **Load as new draft** and save a new version. Preserve the complete system folder and source experiment artifacts.

## Evidence roles

Preview uses calibration data only. A learned combiner or calibrator consumes a separate fit subset before threshold tuning. Saving freezes the recipe, then opens selection scores for a descriptive report. Selection may already have selected the source candidates, so this is **not independent qualification**.

Final-test evaluation is an explicit later action on the frozen whole system, not automatic during preview or search. The GUI requires acknowledgment; the CLI requires `--confirm-final-test`. The exposure is recorded, and the action cannot be silently repeated as if the data were unseen. Repeatedly redesigning the system after looking at that test converts it to development evidence. Use new independent data for the next final claim.

## Metrics that matter with REVIEW

| Metric | Denominator |
| --- | --- |
| Bad escape rate | Actual bad predicted GOOD / all actual bad |
| Good reject rate | Actual good predicted BAD / all actual good |
| Review rate | REVIEW / all evaluated images |
| Automation rate | (GOOD + BAD decisions) / all evaluated images |
| Automatic accuracy | Correct GOOD/BAD decisions / all automatic decisions |
| Accepted contamination | Actual bad predicted GOOD / all predicted GOOD |

Always read automatic accuracy together with automation rate. Rejecting or reviewing almost everything can make selected metrics look attractive while leaving an unusable process. Empty denominators are undefined, not perfect results. REVIEW workload includes good and bad examples separately.

## Command line

Save a definition as `decision-spec.json`, replacing the example run path with a real finalized experiment:

```json
{
  "name": "VIG triage pilot",
  "kind": "triage",
  "sources": [{"run": "D:/Inspection/results/vig/RUN_ID", "candidate": "selected"}],
  "thresholds": {"good": 0.2, "bad": 0.8},
  "tuning": {
    "method": "sweep",
    "timeout_seconds": 60,
    "max_bad_escape_rate": 0.01,
    "max_good_reject_rate": 0.2,
    "max_review_rate": 0.3
  }
}
```

For an ensemble/stacker/cascade use the GUI's **Advanced system definition** to obtain the complete definition for the chosen sources and controls. Relative run paths in command-line definitions resolve beside the JSON file.

PowerShell, from the project folder:

```powershell
$StudioPython = (Get-Content .studio-python.txt -Raw).Trim()
& $StudioPython inspection.py system-preview --spec decision-spec.json
& $StudioPython inspection.py system-create --spec decision-spec.json --output-root decision_systems
```

Use the new saved `decision_system.json` path:

```powershell
& $StudioPython inspection.py system-run --system 'D:/Inspection/decision_systems/SYSTEM_ID/decision_system.json' --input 'D:/Inspection/incoming/vig' --output-root classified --device cuda --labeled
```

`--labeled` applies only when good/bad folders hold real human reference labels. Omit it for unlabelled inspection batches; use `--device cpu` on the laptop. Image copies are enabled by default. Linux uses `.venv-studio5/bin/python` in place of `& $StudioPython`.

Only after locking the complete system, explicitly evaluate its final test:

```powershell
& $StudioPython inspection.py system-evaluate --system 'D:/Inspection/decision_systems/SYSTEM_ID/decision_system.json' --confirm-final-test
```

## Saved artifacts and portability

- `decision_system.json`: source identities, fixed definition, fitted coefficients, partition provenance, tune metrics, and warnings.
- `decision_system_integrity.json`: checksum identity.
- `selection_report.json` and its integrity record: frozen-system selection evidence.
- Classification output: per-image records, predictions, copied Good/Bad/Review images, stage traces, and session metrics.

The recipe is not a bundle of every source checkpoint. Keep or relocate the complete referenced experiments and verify destination execution. Arbitrary v5 learned systems are not automatically exported as a single ONNX model. For a source model that supports ONNX, export still requires its own parity checks and does not substitute for whole-system validation.
