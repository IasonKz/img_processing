from __future__ import annotations

import csv
import hashlib
import json
import logging
import os
from pathlib import Path
import random
import re
import tempfile
from typing import Any

import numpy as np
import yaml

LOG = logging.getLogger("inspection")
SPLITS = ("train", "tune", "calibration", "selection", "test")
CLASS_MAP = {"good": 0, "bad": 1}


def merge(a: dict, b: dict) -> dict:
    out = dict(a)
    for key, value in b.items():
        out[key] = merge(out[key], value) if isinstance(value, dict) and isinstance(out.get(key), dict) else value
    return out


def load_config(path: str | Path, _seen: set | None = None) -> dict:
    path = Path(path).expanduser().resolve()
    seen = set() if _seen is None else set(_seen)
    if path in seen:
        raise ValueError("Circular YAML extends reference")
    seen.add(path)
    with path.open(encoding="utf-8") as handle:
        cfg = yaml.safe_load(handle)
    if not isinstance(cfg, dict):
        raise ValueError("Configuration must be a YAML mapping")
    parent = cfg.pop("extends", None)
    if parent:
        cfg = merge(load_config(path.parent / parent, seen), cfg)
    # Resolve once, at the most specific config. Inherited paths already resolved
    # by the parent remain absolute. Prefer paths in the task-specific YAML.
    for key, value in cfg.get("paths", {}).items():
        if value:
            raw = os.path.expandvars(os.path.expanduser(str(value)))
            p = Path(raw)
            if os.name != "nt" and re.match(r"^[A-Za-z]:[\\/]", raw):
                cfg["paths"][key] = raw  # preserve Windows examples on Linux
            else:
                cfg["paths"][key] = str(p.resolve() if p.is_absolute() else (path.parent / p).resolve())
    cfg["config_file"] = str(path)
    return cfg


def validate_config(cfg: dict) -> None:
    if cfg["project"]["task"] not in {"top", "bottom", "vig", "custom"}:
        raise ValueError("project.task must be top, bottom, vig or custom")
    fractions = cfg["split"]["fractions"]
    if set(fractions) != set(SPLITS) or abs(sum(fractions.values()) - 1) > 1e-6 or min(fractions.values()) <= 0:
        raise ValueError("Use positive train/tune/calibration/selection/test fractions summing to 1")
    root, output = Path(cfg["paths"]["dataset_root"]).resolve(), Path(cfg["paths"]["output_dir"]).resolve()
    if root == output or root in output.parents:
        raise ValueError("output_dir must be outside dataset_root (prevents recursive ingestion)")
    if cfg["data"]["good_folder"].casefold() == cfg["data"]["bad_folder"].casefold():
        raise ValueError("GOOD and BAD folder names must be different")
    if cfg["data"].get("group_by", "auto") not in {"auto", "image", "unit_id", "tray_id", "batch_id"}:
        raise ValueError("Invalid data.group_by")
    if cfg["audit"]["corrupt_policy"] not in {"stop", "exclude"}:
        raise ValueError("audit.corrupt_policy must be stop or exclude")
    for key in ("max_bad_escape_rate", "max_good_false_fail_rate"):
        if not 0 <= cfg["selector"][key] < 1:
            raise ValueError(f"selector.{key} must be in [0,1)")
    if not 0 < cfg["selector"]["confidence_level"] < 1:
        raise ValueError("Invalid confidence level")
    if not any(spec.get("enabled", True) for spec in cfg["models"].values()):
        raise ValueError("Enable at least one supervised classifier")
    if cfg["preprocessing"].get("mode") != "letterbox" or cfg["preprocessing"].get("resize_interpolation", "bilinear") != "bilinear":
        raise ValueError("This implementation supports letterbox with bilinear resize only")
    if cfg["prediction"].get("shadow_mode") is not True:
        raise ValueError("This package proposes PASS/REVIEW/FAIL but has no approved production release integration. Keep shadow_mode: true")
    for section, keys in (("training", ("epochs", "batch_size", "gradient_accumulation", "patience", "log_every_batches")),
                          ("anomaly", ("batch_size", "input_size", "max_train_images", "patches_per_image", "pool_size", "memory_size", "projection_dim", "num_neighbors", "query_chunk"))):
        for key in keys:
            if int(cfg[section][key]) < 1:
                raise ValueError(f"{section}.{key} must be positive")
    if int(cfg["training"]["epochs"]) < 1 or int(cfg["training"]["batch_size"]) < 1:
        raise ValueError("epochs and batch_size must be positive")
    for name, spec in cfg["models"].items():
        if spec.get("enabled", True) and spec["architecture"] == "dinov2_small" and int(spec["input_size"]) % 14:
            raise ValueError(f"{name}: DINOv2 input_size must be divisible by 14, e.g. 518")


def output_dir(cfg: dict) -> Path:
    return Path(cfg["paths"]["output_dir"])


def setup_logging(folder: Path | None = None) -> None:
    handlers: list = [logging.StreamHandler()]
    if folder:
        folder.mkdir(parents=True, exist_ok=True)
        handlers.append(logging.FileHandler(folder / "pipeline.log", encoding="utf-8"))
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", handlers=handlers, force=True)


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False, suffix=".tmp") as h:
        h.write(text)
        name = h.name
    os.replace(name, path)


def read_json(path: Path) -> Any:
    with path.open(encoding="utf-8") as h:
        return json.load(h)


def write_csv(path: Path, rows: list[dict], fields: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        fields = list(dict.fromkeys(key for row in rows for key in row))
    with tempfile.NamedTemporaryFile("w", encoding="utf-8-sig", newline="", dir=path.parent, delete=False, suffix=".tmp") as h:
        writer = csv.DictWriter(h, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
        name = h.name
    os.replace(name, path)


def read_csv(path: Path) -> list[dict]:
    with path.open(encoding="utf-8-sig", newline="") as h:
        # Our own CSVs are comma-delimited. Metadata can be semicolon-delimited.
        sample = h.read(8192)
        h.seek(0)
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",;")
        except csv.Error:
            dialect = csv.excel
        return list(csv.DictReader(h, dialect=dialect))


def file_sha256(path: Path) -> str:
    sha = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            sha.update(block)
    return sha.hexdigest()


def object_hash(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def seed_everything(seed: int, deterministic: bool = True) -> None:
    random.seed(seed)
    np.random.seed(seed)
    import torch
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = not deterministic
    torch.backends.cudnn.deterministic = deterministic
    torch.use_deterministic_algorithms(deterministic, warn_only=True)


def choose_device(cfg: dict):
    import torch
    choice = str(cfg["runtime"]["device"])
    if choice == "auto":
        choice = "cuda" if torch.cuda.is_available() else "cpu"
    if choice.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable. Install the matching GPU PyTorch build or set device: cpu")
    torch.set_num_threads(int(cfg["runtime"].get("cpu_threads", 4)))
    return torch.device(choice)


def torch_save(path: Path, payload: dict) -> None:
    import torch
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, temp)
    os.replace(temp, path)


def torch_load(path: Path, device="cpu"):
    import torch
    # No arbitrary pickle objects. Only load checkpoints you trust regardless.
    return torch.load(path, map_location=device, weights_only=True)


class UnionFind:
    def __init__(self, n: int):
        self.parent = list(range(n))

    def find(self, x: int) -> int:
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a: int, b: int) -> None:
        a, b = self.find(a), self.find(b)
        if a != b:
            self.parent[max(a, b)] = min(a, b)
