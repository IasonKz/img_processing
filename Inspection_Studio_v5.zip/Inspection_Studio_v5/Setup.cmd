@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\setup_windows.ps1" %*
set "STUDIO_EXIT=%ERRORLEVEL%"
echo.
if not "%STUDIO_EXIT%"=="0" echo Setup did not complete. Read the error above; see docs\INSTALLATION.md.
pause
exit /b %STUDIO_EXIT%
