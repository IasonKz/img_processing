"""Portable resource and release-gate tests with opaque, non-executable weights."""
from __future__ import annotations

from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

from nilt.common import read_json, sha_file, write_csv, write_json
from nilt.registry import create_training_package, restore_training_package, activate_run, _dependency_paths
from test_integration_v2 import fixture_run


def rewrite_fixture_config(run, **changes):
    cfg = read_json(run / "config.json")
    cfg.update(changes)
    write_json(run / "config.json", cfg)
    integrity = read_json(run / "integrity.json")
    integrity["config_sha256"] = sha_file(run / "config.json")
    write_json(run / "integrity.json", integrity)
    return cfg


class PortableResourcesTests(unittest.TestCase):
    def test_snapshot_holds_lock_during_copy_and_releases_it(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            run, _, _ = fixture_run(root)
            original_copy = shutil.copy2
            observed = []
            def copy(source, destination, *args, **kwargs):
                observed.append((run / "operation.lock").is_file())
                return original_copy(source, destination, *args, **kwargs)
            with patch("nilt.registry.shutil.copy2", side_effect=copy):
                package = create_training_package(run, root / "package")
            self.assertTrue(observed and all(observed))
            self.assertFalse((run / "operation.lock").exists())
            self.assertFalse(list(package.rglob("operation.lock")))

    def test_busy_run_refuses_packaging(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            run, _, _ = fixture_run(root)
            write_json(run / "operation.lock", {"pid": 123})
            with self.assertRaisesRegex(RuntimeError, "locked"):
                create_training_package(run, root / "package")
            self.assertTrue((run / "operation.lock").is_file())

    def test_incomplete_incremental_run_preserves_weights_predecessor_and_moved_paths(self):
        from nilt.data import read_manifest
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            old, _, _ = fixture_run(root, "old")
            current, data, rows = fixture_run(root, "current")
            weights = root / "weights"
            weights.mkdir()
            filename = "resnet18__IMAGENET1K_V1.pth"
            (weights / filename).write_bytes(b"Opaque local pretrained test weights")
            (weights / "unused_model.pth").write_bytes(b"Must not be packaged")
            for run in (old, current):
                rewrite_fixture_config(run, pretrained=True, models=["resnet18"])
            rewrite_fixture_config(current, previous_run=str(old))
            # Current run has not selected a candidate yet; last.pt is resumable state.
            (current / "selected.json").unlink()
            (current / "selection_integrity.json").unlink()
            for row in rows:
                source = Path(row["path"])
                destination = data / "relocated" / row["relative_path"]
                destination.parent.mkdir(parents=True, exist_ok=True)
                source.replace(destination)
                row["relative_path"] = "relocated/" + row["relative_path"]
                row["path"] = str(destination)
            write_csv(current / "manifest.csv", rows)
            integrity = read_json(current / "integrity.json")
            integrity["manifest_sha256"] = sha_file(current / "manifest.csv")
            write_json(current / "integrity.json", integrity)
            configs = {"main": (current / "config.json").read_bytes(), "old": (old / "config.json").read_bytes()}
            manifests = {"main": (current / "manifest.csv").read_bytes(), "old": (old / "manifest.csv").read_bytes()}
            package = create_training_package(current, root / "package")
            self.assertEqual(read_json(package / "run/dependency_locations.json"),
                             {"weights_dir": "dependencies/weights", "previous_run": "dependencies/previous"})
            self.assertTrue((package / "run/dependencies/previous/selected.json").is_file())
            self.assertEqual(len(list(package.rglob(filename))), 2)
            self.assertFalse(list(package.rglob("unused_model.pth")))
            moved = root / "new_computer_data"
            shutil.copytree(data, moved)
            for path in (old, current, weights, data, root / "old_data"):
                shutil.rmtree(path)
            restored = restore_training_package(package, moved, root / "restored")
            previous = restored / "dependencies/previous"
            self.assertEqual((restored / "config.json").read_bytes(), configs["main"])
            self.assertEqual((previous / "config.json").read_bytes(), configs["old"])
            self.assertEqual((restored / "manifest.csv").read_bytes(), manifests["main"])
            self.assertEqual((previous / "manifest.csv").read_bytes(), manifests["old"])
            resolved = _dependency_paths(restored, read_json(restored / "config.json"))
            self.assertEqual(Path(resolved["previous_run"]), previous)
            self.assertTrue((Path(resolved["weights_dir"]) / filename).is_file())
            location = read_json(previous / "data_location.json")
            for row in read_manifest(previous / "manifest.csv"):
                relative = location["image_paths"][row["pixel_hash"]]
                self.assertTrue(relative.startswith("relocated/"))
                self.assertTrue((Path(location["data_root"]) / relative).is_file())
            # Repack reuses the existing embedded snapshot instead of adding a second one.
            second_package = create_training_package(restored, root / "repacked")
            self.assertEqual(len(list(second_package.rglob("integrity.json"))), 2)
            self.assertTrue((second_package / "run/dependencies/previous/integrity.json").is_file())

    def test_missing_predecessor_hash_fails_restore_before_copy(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            old, _, _ = fixture_run(root, "old")
            current, data, rows = fixture_run(root, "current")
            rewrite_fixture_config(current, previous_run=str(old))
            rows.pop()
            write_csv(current / "manifest.csv", rows)
            integrity = read_json(current / "integrity.json")
            integrity["manifest_sha256"] = sha_file(current / "manifest.csv")
            write_json(current / "integrity.json", integrity)
            package = create_training_package(current, root / "package")
            with self.assertRaisesRegex(ValueError, "missing a predecessor image"):
                restore_training_package(package, data, root / "restored")
            self.assertFalse((root / "restored").exists())


class ActivationBindingTests(unittest.TestCase):
    def test_evaluation_must_identify_exact_selected_system(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            run, _, _ = fixture_run(root)
            rewrite_fixture_config(run, pilot=False)
            write_json(run / "final_test_summary.json",
                       {"empirical_target_met": True, "statistical_target_supported": True})
            with self.assertRaisesRegex(ValueError, "different selected system"):
                activate_run(run)


if __name__ == "__main__":
    unittest.main()
