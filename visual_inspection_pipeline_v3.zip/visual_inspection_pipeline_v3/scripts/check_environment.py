#!/usr/bin/env python3
"""Inspect installed dependencies without downloading or modifying the environment."""
from __future__ import annotations

import argparse
import importlib
import importlib.metadata
import json
import platform
from pathlib import Path
import sys

PACKAGES = {
    "numpy": "numpy", "Pillow": "PIL", "scipy": "scipy",
    "scikit-learn": "sklearn", "PyYAML": "yaml", "matplotlib": "matplotlib",
    "torch": "torch", "torchvision": "torchvision", "onnx": "onnx",
    "onnxruntime": "onnxruntime",
}
GROUPS = {
    "core": ("numpy", "Pillow", "scipy", "scikit-learn", "PyYAML", "matplotlib"),
    "train": ("numpy", "Pillow", "scipy", "scikit-learn", "PyYAML", "matplotlib", "torch", "torchvision"),
    "onnx": ("numpy", "Pillow", "onnxruntime"),
    "export": ("numpy", "Pillow", "torch", "torchvision", "onnx", "onnxruntime"),
}


def collect():
    packages = {}
    modules = {}
    for distribution, module in PACKAGES.items():
        try:
            loaded = importlib.import_module(module)
            modules[module] = loaded
            try:
                version = importlib.metadata.version(distribution)
            except importlib.metadata.PackageNotFoundError:
                version = str(getattr(loaded, "__version__", "unknown"))
            packages[distribution] = {"available": True, "version": version}
        except Exception as error:
            packages[distribution] = {"available": False, "error": f"{type(error).__name__}: {error}"}
    capabilities = {name: all(packages[item]["available"] for item in members)
                    for name, members in GROUPS.items()}
    result = {"python": platform.python_version(), "python_executable": sys.executable,
              "platform": platform.platform(), "packages": packages, "capabilities": capabilities,
              "cuda_available": False, "cuda_runtime": None, "gpu_names": [],
              "onnxruntime_providers": []}
    torch = modules.get("torch")
    if torch is not None:
        result["cuda_available"] = bool(torch.cuda.is_available())
        result["cuda_runtime"] = torch.version.cuda
        if result["cuda_available"]:
            result["gpu_names"] = [torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())]
    ort = modules.get("onnxruntime")
    if ort is not None:
        result["onnxruntime_providers"] = ort.get_available_providers()
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", metavar="PATH", help="Write the environment report as JSON.")
    parser.add_argument("--require", choices=(*GROUPS, "all"),
                        help="Return exit code 2 if the requested dependency group is unavailable.")
    args = parser.parse_args(argv)
    report = collect()
    print(f"Python: {report['python']} ({report['platform']})")
    for name, item in report["packages"].items():
        print(f"{name}: {item['version'] if item['available'] else 'UNAVAILABLE - ' + item['error']}")
    print("CUDA available:", report["cuda_available"])
    print("ONNX Runtime providers:", ", ".join(report["onnxruntime_providers"]) or "none")
    for name, available in report["capabilities"].items():
        print(f"Capability {name}: {'ready' if available else 'missing dependencies'}")
    if args.json:
        target = Path(args.json)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    requested = report["capabilities"].values() if args.require == "all" else (
        [report["capabilities"][args.require]] if args.require else [True])
    return 0 if all(requested) else 2


if __name__ == "__main__":
    raise SystemExit(main())
