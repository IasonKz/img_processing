# Automatic annotation in Studio v2

All methods generate proposals for human review. They do not approve an image, establish that an excluded region is good, or change source files. Use the same top-only annotation/training workspace as v1.

## Four selectable methods

| Annotation method | Behaviour | Main limitation |
| --- | --- | --- |
| **Basic — current detector** | Original local bright/dark anomaly detector. Ignores exclusion zones and structural suppression; honours the selected detection area. | Labels, symbols, rings and edges can be proposed as defects. |
| **Basic + exclusion zones** | Basic proposals with enabled label, orientation-symbol, lens-eye and custom zones omitted. | A real defect inside an excluded zone is also omitted. |
| **Structure-aware — experimental** | Uses a radial brightness model in the eye region and optional suppression of coherent long edges on a central/custom die perimeter, with enabled exclusions. | Can suppress genuine features resembling rings or edges. It does not recognize symbols semantically. |
| **Good-reference comparison — experimental** | Compares with aligned, brightness-adjusted, user-selected good references, with enabled exclusions. | Depends on representative references and reliable alignment. Normal variation can still produce proposals. |

**Basic + Full image** returns to the v1 proposal algorithm. Detector settings and retained manual corrections still affect the visible result. To see fresh unedited proposals, turn off **Keep manual additions and erasures** before reloading.

**Sensitivity** is a threshold multiplier: higher values produce fewer proposals. **Minimum defect area** is measured in native pixels. **Polarity** selects dark, bright or both kinds of local deviation. These controls do not teach the detector that a label or ring is normal.

## Switch, reload, edit, save

1. Choose **Annotation method** and its options.
2. Leave **Keep manual additions and erasures** on to retain hand-drawn defects and suppress pixels you erased from automatic proposals.
3. Click **Reload proposals**. It replaces the current automatic proposals in the editor preview. It does not save or approve the annotation.
4. Review the result. **Undo last reload** restores the state immediately before that reload. Later annotation/settings edits disable this dedicated button; use regular undo/redo to walk back through those later changes.
5. Use **Save draft** or **Approve & next** to commit the reviewed annotation.

Turning off retention allows a fresh replacement of manual additions and recorded erasures. If a proposal request fails, current annotations remain available for correction; the error is not a clean result. Reloading does not change the saved inner-polygon template. Changing settings alone does not recompute the mask: click **Reload proposals** to apply them. Saved diagnostics record when proposal settings have changed since their generation.

Eraser strokes and deletion of automatic proposal objects are recorded for later reloads. A manually drawn defect can still occupy a previously erased region: erasure suppression applies to automatic proposals. Deleting a manually drawn object removes that object; it does not instruct the detector to ignore that region forever. **Clear defect mask** also records the current automatic pixels as erased. These corrections persist after saving and reopening in v2.

Old v1 annotations have no record of previously erased proposals. Their saved masks remain intact; legacy manually corrected content is conservatively retained, but a regeneration may propose old erased pixels again. Review and erase those in v2 if needed. Hiding an object is a display action: hidden shapes remain in the saved mask. Use delete or the eraser to remove defects.

## Three different kinds of geometry

| Geometry | Purpose | Saved using |
| --- | --- | --- |
| **Inner boundary** | Labels marked defect pixels as inner (`1`) or outer (`2`); unmarked pixels are background (`0`). | **Save custom polygon**, plus each saved annotation. |
| **Detection area** | Limits where automatic proposals are generated. | **Save automation profile**, plus each saved annotation. |
| **Exclusion zones / eye** | Omits selected regions from applicable methods, or defines the eye region for radial analysis. | **Save automation profile**, plus each saved annotation. |

Drawing one type does not redefine the others. An inner polygon is not a filled defect mask. Exclusions never disable manual drawing.

### Detection area

- **Full image**: inspect the whole image, including visible neighbouring parts.
- **Central die — automatic**: attempt to locate the central die. Unreliable detection reports failure instead of silently using an arbitrary crop. Use **Custom area** or **Full image** if needed.
- **Custom area**: click **Draw detection area**, place polygon vertices and press **Enter**. This restricts proposals without cropping/resizing the source.

Selecting the central die is useful when full top images contain neighbouring dies and their edges. The central die can include both inner and outer defect regions; it is not the inner lens boundary.

### Exclusion zones and lens eye

Use **New zone category → Draw exclusion polygon** for the label, each orientation symbol or other repeated marks. Click vertices and press **Enter**. Select a zone to adjust its handles; remove obsolete zones with their × button.

**Label**, **Orientation symbols**, **Lens eye** and **Custom zones** are independent switches. A checked label/symbol/custom category needs a corresponding drawn zone; it does not find that feature automatically. Basic ignores all these exclusions.

Use **Draw lens eye ellipse** or the centre/radius fields under **Lens eye geometry** to define the central region. **Use automatic eye estimate** removes the explicit ellipse and estimates one centred on the inner boundary, with diameters 35% of its bounding-box width/height. Inspect the overlay before relying on that estimate.

With lens-eye exclusion enabled in an applicable method, proposals in that region are omitted. To analyze the rings with Structure-aware instead, leave lens-eye exclusion off. The radial model operates only in the eye region within the detection area and outside exclusions; other regions use local residuals.

**Ring suppression strength** controls the correction: 0 disables ring correction, values up to 1 blend it in, and values above 1 raise the radial detection threshold. **Suppress long straight edges** is optional and initially off. It addresses coherent steps on a detected central die or custom perimeter; if that boundary is unavailable, edges remain proposed with a warning. A complete circular defect or a defect along an expected edge can be suppressed. Compare with Basic whenever the result is uncertain.

### Reusable automation profile

**Save automation profile** stores method, detection area, zones, eye, method options and reference selection in the annotation project. **Use profile for new images** controls its use on images without saved annotations. Existing images retain their stored settings; use **Load profile on this image**, then **Reload proposals** and save to update one.

When loaded on a different image size, zone, custom-area and eye coordinates scale with width/height. Image and mask pixels are not resized. A profile does not estimate the part's position or rotation: if framing changes, adjust geometry and review the overlays. References must still meet the same-dimensions requirement. Detector threshold settings and the saved inner-polygon template are separate from the automation profile.

Saving a profile does not overwrite existing saved annotations. Saving a profile or polygon is itself a persistent project action, distinct from preview-only **Reload proposals**.

## Adjustable inner polygon

**Octagon** draws a chamfered rectangle, without requiring equal sides. Its initial cuts are 15% of width/height, replacing the v1 fixed 25% cuts. Under **Chamfered rectangle geometry**, set independent width/height, centre, rotation and each corner's **Cut X / Cut Y**. **Apply geometry to boundary** applies these values. With **Boundary** selected, drag individual vertices for further adjustment.

**Read current boundary dimensions** supplies a starting point for the geometry fields; inspect the result after applying parameters to a freely edited polygon. Numeric geometry describes a chamfered rectangle, while individually moved vertices can describe a more general polygon. Save the exact adjusted outline that matches your lens instead of relying on a default proportion.

The two **Boundary detection** modes are:

- **Follow current polygon edges**: guided fitting near the current polygon. Start with a close outline so the search is near the intended edges instead of an inner ring.
- **Find polygon automatically**: search for a central polygon without restricting fitting to the current sides in the same way.

Press **Detect inner boundary** to try the selected mode. Weak or inconsistent edges retain the previous outline with a review message. Detection is an aid, not a guarantee of the correct physical inner region.

Use **Save custom polygon** to persist the outline. **Relative to image size** scales only coordinates; **Exact pixels (same dimensions)** reuses pixel positions and requires matching image sizes. New images use the saved template when enabled. For an existing image use **Use saved polygon on this image**. **Apply saved polygon to existing images** updates drafts by default; **Include approved images in batch** explicitly includes approved annotations. Changed annotations become drafts and previous revisions remain available. Excluded images are not included in that batch.

## Good-reference comparison

Import candidates into the same annotation project. Select **one to eight images** you have personally checked as good, with the same pixel dimensions and comparable view/lighting as the current image. A filename, folder or annotation status is not automatic evidence that an image is good. The current image cannot be its own reference.

The method registers references at native dimensions using constrained rigid ECC alignment, adjusts brightness with a robust gain/offset estimate, and uses the pixelwise median of the aligned references for comparison. **Max shift (px)**, **Max rotation (°)** and **Minimum correlation** control acceptance. This is for small shifts/rotations in the same view; it does not replace upstream alignment of differently oriented or scaled parts. Warping interpolates reference pixels onto the current native grid. Areas outside valid coverage of any selected reference are not compared.

Missing references, mismatched dimensions or unreliable alignment produce an error instead of an empty accepted result. Choose better references, adjust controls, or switch to Basic. Reference selection is saved in the profile; when reviewing a reference image itself, choose other references or another method.

A reference can contain an unnoticed defect or fail to represent allowed manufacturing variation. Experimental results need review against real good and defective samples. No production accuracy claim follows from synthetic software tests.

## Resolution, saving and training

Annotation proposal analysis, inner-boundary detection and saved masks use the original pixel dimensions. No annotation method downsamples the source. Display zoom changes only the view; reference registration may interpolate reference pixels but keeps the current image dimensions.

Neural training remains the v1 pipeline: aspect-preserving resize to the selected training image size, followed by padding. Prediction masks are restored to native geometry. This does not recover detail lost during training preprocessing. There is no tile-training implementation in this release.

Only approved annotations enter a new frozen training dataset. Existing studies keep their original snapshots, so create a new study to include newly approved v2 annotations. Previewing proposals, saving an automation profile or skipping regions does not approve an image.
