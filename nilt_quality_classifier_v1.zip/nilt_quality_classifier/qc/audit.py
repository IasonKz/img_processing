from __future__ import annotations

from pathlib import Path
from typing import Any

import cv2
import numpy as np
import pandas as pd

from .config import get, resolve_path
from .data import (
    DEFAULT_UNIT_ID_REGEX,
    class_counts,
    scan_labeled_root,
    sha256_file,
)
from .utils import setup_logging, write_json


def run_dataset_audit(config: dict[str, Any]) -> dict[str, Any]:
    root = resolve_path(get(config, "audit.dataset_root"), config=config, must_exist=True)
    output = resolve_path(get(config, "audit.output_folder", "dataset_audit"), config=config)
    if root is None or output is None:
        raise ValueError("Set audit.dataset_root and audit.output_folder")
    output.mkdir(parents=True, exist_ok=True)
    logger = setup_logging(output / "audit.log")

    records = scan_labeled_root(
        root,
        source=root.name,
        recursive=bool(get(config, "audit.recursive", True)),
        extensions=get(config, "audit.image_extensions"),
        unit_id_regex=str(get(config, "audit.unit_id_regex", DEFAULT_UNIT_ID_REGEX)),
    )
    compute_hashes = bool(get(config, "audit.compute_sha256", True))
    rows: list[dict[str, Any]] = []
    unreadable: list[dict[str, str]] = []

    for index, record in enumerate(records, start=1):
        path = Path(record.path)
        array = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
        if array is None:
            unreadable.append({"path": str(path), "reason": "OpenCV could not read image"})
            continue
        height, width = array.shape[:2]
        channels = 1 if array.ndim == 2 else int(array.shape[2])
        rows.append(
            {
                "path": str(path),
                "label": record.label_name,
                "group": record.group,
                "width": int(width),
                "height": int(height),
                "channels": channels,
                "dtype": str(array.dtype),
                "minimum": float(np.min(array)),
                "maximum": float(np.max(array)),
                "mean": float(np.mean(array)),
                "std": float(np.std(array)),
                "sha256": sha256_file(path) if compute_hashes else "",
            }
        )
        if index % 250 == 0:
            logger.info("Audited %d/%d images", index, len(records))

    details = pd.DataFrame(rows)
    unreadable_frame = pd.DataFrame(unreadable)
    details.to_csv(output / "image_audit.csv", index=False, encoding="utf-8")
    unreadable_frame.to_csv(output / "unreadable_images.csv", index=False, encoding="utf-8")

    duplicates = pd.DataFrame()
    cross_label_duplicates = pd.DataFrame()
    if compute_hashes and not details.empty:
        duplicates = details[details.duplicated("sha256", keep=False)].sort_values("sha256")
        duplicates.to_csv(output / "exact_duplicates.csv", index=False, encoding="utf-8")
        conflicting_hashes = (
            duplicates.groupby("sha256")["label"].nunique().loc[lambda series: series > 1].index
        )
        cross_label_duplicates = duplicates[duplicates["sha256"].isin(conflicting_hashes)]
        cross_label_duplicates.to_csv(
            output / "CRITICAL_duplicates_across_good_bad.csv",
            index=False,
            encoding="utf-8",
        )

    dimension_counts = (
        details.groupby(["width", "height", "channels", "dtype"]).size().reset_index(name="count")
        if not details.empty
        else pd.DataFrame()
    )
    dimension_counts.to_csv(output / "dimension_counts.csv", index=False, encoding="utf-8")

    summary = {
        "dataset_root": str(root),
        "class_counts": class_counts(records),
        "images_scanned": len(records),
        "images_readable": len(details),
        "images_unreadable": len(unreadable_frame),
        "dimension_variants": int(len(dimension_counts)),
        "exact_duplicate_rows": int(len(duplicates)),
        "cross_label_duplicate_rows": int(len(cross_label_duplicates)),
        "warnings": [],
    }
    if len(cross_label_duplicates):
        summary["warnings"].append(
            "The same exact image exists in GOOD and BAD. Fix these labels before training."
        )
    if len(unreadable_frame):
        summary["warnings"].append("Some images are unreadable. Remove or replace them.")
    if len(dimension_counts) > 1:
        summary["warnings"].append(
            "Multiple image sizes/dtypes were detected. Verify that preprocessing is consistent."
        )
    write_json(summary, output / "audit_summary.json")
    logger.info("Audit complete: %s", summary)
    return summary
