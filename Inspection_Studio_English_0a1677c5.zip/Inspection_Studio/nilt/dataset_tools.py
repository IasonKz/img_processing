"""Explicit local dataset edits with collision-safe moves and an undo journal."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import uuid

from .common import EXTENSIONS, sha_file
from .data import tray_unit_identity

DATA_LABELS = ("good", "bad", "review", "unsuitable")
TRAY_ROLES = ("development", "classification", "excluded")


def classification_roles(config, root):
    """Current project roles apply only to its explicitly configured dataset."""
    import yaml
    config = Path(config).resolve()
    raw = yaml.safe_load(config.read_text(encoding="utf-8"))
    for task in raw.get("tasks", {}).values():
        dataset = Path(task.get("dataset_root", "")).expanduser()
        if not dataset.is_absolute():
            dataset = config.parent / dataset
        if dataset.resolve() == Path(root).resolve():
            return task.get("tray_roles", {})
    return None


def tray_name(path, root=None):
    try:
        return tray_unit_identity(Path(path).name)["tray"]
    except ValueError:
        parts = Path(path).relative_to(root).parts if root else ()
        return parts[1] if len(parts) > 2 else "Unassigned"


def dataset_items(root):
    root = Path(root).expanduser().resolve()
    if not root.is_dir() or not any((root / label).is_dir() for label in ("good", "bad")):
        raise ValueError("Choose a dataset folder containing good/ and bad/ images.")
    result = []
    for label in DATA_LABELS:
        folder = root / label
        if not folder.is_dir():
            continue
        for path in sorted(folder.rglob("*")):
            if not path.is_file() or path.suffix.lower() not in EXTENSIONS:
                continue
            if path.is_symlink() or not path.resolve().is_relative_to(root):
                raise ValueError("Dataset images must stay inside the selected folder.")
            relative = path.relative_to(root).as_posix()
            result.append({"id": hashlib.sha256(relative.encode()).hexdigest()[:24], "relative_path": relative,
                           "label": label, "tray": tray_name(path, root), "bytes": path.stat().st_size})
    return result


def checked_image(root, relative):
    root = Path(root).resolve()
    if not isinstance(relative, str) or "\\" in relative:
        raise ValueError("Choose a recorded dataset image.")
    path = root / relative
    if (Path(relative).is_absolute() or not Path(relative).parts or Path(relative).parts[0] not in DATA_LABELS
            or ".." in Path(relative).parts or path.is_symlink() or not path.resolve().is_relative_to(root)
            or not path.is_file() or path.suffix.lower() not in EXTENSIONS):
        raise ValueError("The dataset image is unavailable or outside its class folder.")
    return path


def _move(source, destination, digest):
    destination.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive creation keeps existing captures safe even if another application writes here.
    created = False
    try:
        with source.open("rb") as original, destination.open("xb") as target:
            created = True
            shutil.copyfileobj(original, target)
            target.flush()
            os.fsync(target.fileno())
    except BaseException:
        if created:
            destination.unlink(missing_ok=True)
        raise
    if sha_file(destination) != digest or sha_file(source) != digest:
        destination.unlink(missing_ok=True)
        raise ValueError("The image changed during the move; the source was retained.")
    source.unlink()


def _journal(root):
    journal = root / ".nilt-cleaning" / "moves.jsonl"
    if journal.is_symlink() or not journal.resolve().is_relative_to(root):
        raise ValueError("The cleaning journal must stay inside the dataset.")
    return journal


def move_image(root, relative, label, expected_sha256):
    root = Path(root).resolve()
    if label not in DATA_LABELS:
        raise ValueError("Destination must be good, bad, review or unsuitable.")
    source = checked_image(root, relative)
    digest = sha_file(source)
    if digest != expected_sha256:
        raise ValueError("This image changed since it was opened. Reload it before editing.")
    if Path(relative).parts[0] == label:
        return {"unchanged": True, "relative_path": relative}
    destination = root / label / Path(*Path(relative).parts[1:])
    journal = _journal(root)
    if destination.is_symlink() or not destination.resolve().is_relative_to(root):
        raise ValueError("The destination must stay inside the dataset.")
    if destination.exists():
        destination = destination.with_name(destination.stem + "__" + uuid.uuid4().hex[:12] + destination.suffix)
    _move(source, destination, digest)
    record = {"id": uuid.uuid4().hex, "utc": datetime.now(timezone.utc).isoformat(), "sha256": digest,
              "from": relative, "to": destination.relative_to(root).as_posix(), "action": "move"}
    journal.parent.mkdir(exist_ok=True)
    with journal.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(record) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    return record


def undo_move(root):
    root = Path(root).resolve()
    journal = _journal(root)
    if not journal.is_file():
        raise ValueError("No dataset move is available to undo.")
    records = [json.loads(line) for line in journal.read_text(encoding="utf-8").splitlines() if line.strip()]
    undone = {record.get("undo_of") for record in records if record.get("action") == "undo"}
    record = next((r for r in reversed(records) if r.get("action") == "move" and r["id"] not in undone), None)
    if record is None:
        raise ValueError("No dataset move is available to undo.")
    source = checked_image(root, record["to"])
    destination = root / record["from"]
    if not destination.resolve().is_relative_to(root) or destination.exists():
        raise ValueError("The original path is occupied. Undo will not overwrite it.")
    if sha_file(source) != record["sha256"]:
        raise ValueError("The moved image changed; undo was refused.")
    _move(source, destination, record["sha256"])
    result = {"id": uuid.uuid4().hex, "utc": datetime.now(timezone.utc).isoformat(), "action": "undo",
              "undo_of": record["id"], "from": record["to"], "to": record["from"], "sha256": record["sha256"]}
    with journal.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(result) + "\n")
    return result
