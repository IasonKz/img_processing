import contextlib
import io
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import torch
from PIL import Image

from cvtester.catalog import MODELS, check_metadata, select_model
from cvtester.cli import main
from cvtester.runner import benchmark, class_indices


class CatalogTests(unittest.TestCase):
    def test_every_catalog_entry_is_registered_classifier(self):
        import timm
        self.assertEqual(len({model.name for model in MODELS}), len(MODELS))
        for model in MODELS:
            with self.subTest(model=model.name):
                cfg = timm.get_pretrained_cfg(model.checkpoint)
                self.assertEqual(cfg.num_classes, 1000)
                self.assertEqual(cfg.hf_hub_id, model.repo_id)

    def test_noncommercial_weights_are_blocked_by_default(self):
        with self.assertRaisesRegex(ValueError, "prohibits commercial"):
            select_model("convnextv2-base")
        self.assertEqual(select_model("convnextv2-base", "research").license, "cc-by-nc-4.0")

    def test_commercial_alternative(self):
        self.assertTrue(select_model("convnext-base").commercial)

    def test_license_is_checked_before_dependencies_or_download(self):
        with contextlib.redirect_stderr(io.StringIO()) as error:
            result = main(["predict", "--model", "convnextv2-base", "--image", "missing.jpg"])
        self.assertEqual(result, 1)
        self.assertIn("prohibits commercial", error.getvalue())

    def test_changed_or_missing_license_is_rejected(self):
        spec = select_model("convnext-base")
        for card in ({}, {"license": "cc-by-nc-4.0"}):
            with self.assertRaisesRegex(ValueError, "expected weight license"):
                check_metadata(spec, SimpleNamespace(card_data=card))

    def test_pickle_only_checkpoint_is_rejected(self):
        info = SimpleNamespace(card_data={"license": "apache-2.0"}, sha="a" * 40,
                               siblings=[SimpleNamespace(rfilename="pytorch_model.bin")])
        with self.assertRaisesRegex(ValueError, "safetensors"):
            check_metadata(select_model("convnext-base"), info)

    def test_verified_revision_is_returned(self):
        info = SimpleNamespace(card_data={"license": "apache-2.0"}, sha="a" * 40,
             siblings=[SimpleNamespace(rfilename=n) for n in ("config.json", "model.safetensors")])
        self.assertEqual(check_metadata(select_model("convnext-base"), info), "a" * 40)
        info.sha = "main"
        with self.assertRaisesRegex(ValueError, "pinned commit"):
            check_metadata(select_model("convnext-base"), info)


class EvaluationTests(unittest.TestCase):
    def test_real_safetensors_loader_preprocessing_and_inference(self):
        import json
        import timm
        from safetensors.torch import save_file
        from cvtester.runner import predict

        spec = select_model("convnextv2-atto", "research")
        info = SimpleNamespace(card_data={"license": spec.license}, sha="a" * 40,
             siblings=[SimpleNamespace(rfilename=n) for n in ("config.json", "model.safetensors")])
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            # Locally initialized weights exercise loading without claiming pretrained accuracy.
            model = timm.create_model(spec.checkpoint, pretrained=False)
            save_file(model.state_dict(), root / "model.safetensors")
            config = {"architecture": "convnextv2_atto", "num_classes": 1000,
                      "pretrained_cfg": model.pretrained_cfg}
            (root / "config.json").write_text(json.dumps(config))
            Image.new("RGB", (128, 96), "red").save(root / "image.png")
            with patch("huggingface_hub.HfApi.model_info", return_value=info):
                with patch("huggingface_hub.hf_hub_download", side_effect=lambda repo, filename, revision: str(root / filename)) as download:
                    result = predict(spec.name, root / "image.png", "research")
            self.assertEqual(result["revision"], info.sha)
            self.assertEqual(len(result["predictions"]), 5)
            self.assertTrue(all(0 <= row["probability"] <= 1 for row in result["predictions"]))
            self.assertTrue(all(row["synset"].startswith("n") for row in result["predictions"]))
            self.assertEqual(download.call_count, 2)
            for call in download.call_args_list:
                self.assertEqual(call.kwargs["revision"], info.sha)

    def test_synsets_are_mapped_to_actual_outputs(self):
        self.assertEqual(class_indices(["n01443537", "n01440764"]), [1, 0])

    def test_unknown_custom_classes_require_mapping(self):
        with self.assertRaisesRegex(ValueError, "fine-tuning"):
            class_indices(["custom-class"])

    def test_invalid_class_maps_are_rejected(self):
        for mapping in ({}, {"a": 1000}, {"a": True}, {"a": "0"}):
            with self.assertRaises(ValueError):
                class_indices(["a"], mapping)
        with self.assertRaisesRegex(ValueError, "distinct"):
            class_indices(["a", "b"], {"a": 0, "b": 0})

    def test_accuracy_uses_mapping_and_all_samples(self):
        from torchvision.transforms import ToTensor

        class Classifier(torch.nn.Module):
            def forward(self, batch):
                logits = torch.zeros(len(batch), 1000)
                logits[:, 0] = 5
                logits[:, 1] = 10
                return logits

        with tempfile.TemporaryDirectory() as directory:
            for folder in ("goldfish", "tench"):
                target = Path(directory) / folder
                target.mkdir()
                Image.new("RGB", (16, 16), "white").save(target / "image.png")
            with patch("cvtester.runner.load_model", return_value=(Classifier(), ToTensor(), {})):
                result = benchmark("convnext-base", directory, batch_size=1,
                                   class_map={"goldfish": 1, "tench": 0})
        self.assertEqual(result["samples"], 2)
        self.assertEqual(result["top1"], 0.5)
        self.assertEqual(result["top5"], 1.0)
        self.assertGreater(result["forward_images_per_second"], 0)

    def test_comparison_reports_failures_and_keeps_successes(self):
        with patch("cvtester.runner.benchmark", side_effect=[ValueError("download failed"), {"model": "eva02-tiny"}]):
            with contextlib.redirect_stdout(io.StringIO()) as output:
                status = main(["benchmark", "--models", "convnext-tiny", "eva02-tiny",
                               "--dataset", "unused"])
        import json
        result = json.loads(output.getvalue())
        self.assertEqual(status, 1)
        self.assertEqual(result["results"], [{"model": "eva02-tiny"}])
        self.assertEqual(result["errors"][0]["model"], "convnext-tiny")


if __name__ == "__main__":
    unittest.main()
