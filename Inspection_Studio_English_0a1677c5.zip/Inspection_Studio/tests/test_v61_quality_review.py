"""Independent review cases for missing evidence and selective denominators."""
import csv
from pathlib import Path
import tempfile
import unittest

from nilt.common import write_json
from nilt.quality import build_quality_report, _metrics
from nilt.review import initialize_session, append_prediction, finish_session


class QualityIndependentReviewTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def run_fixture(self, name, relative):
        root = self.root / name
        write_json(root / "config.json", {"task": "vig"})
        write_json(root / "model_state.json", {"status": "TRAINED"})
        with (root / "manifest.csv").open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=["relative_path", "label", "split", "pixel_hash"])
            writer.writeheader()
            writer.writerow({"relative_path": relative, "label": 0, "split": "train", "pixel_hash": "1" * 64})
        return root

    def session_fixture(self, name="batch", total=1, completed=1):
        root = self.root / name
        initialize_session(root, metadata={"task": "vig"}, total=total)
        append_prediction(root, {"relative_path": "bad/C000099_Rc01Cc01.png", "reference_label": "bad",
                                 "prediction": "good", "file_sha256": "a" * 64})
        write_json(root / "summary.json", {"status": "completed", "task": "vig"})
        finish_session(root, status="completed", completed=completed)
        return root

    def test_status_reads_actual_model_state_contract(self):
        run = self.run_fixture("run_a", "bad/C000083_Rc01Cc01.png")
        report = build_quality_report([run], [])
        self.assertEqual(report["runs"][0]["status"], "TRAINED")

    def test_no_match_in_one_source_does_not_prove_no_match_in_unidentifiable_source(self):
        known = self.run_fixture("known", "bad/C000083_Rc01Cc01.png")
        unidentifiable = self.run_fixture("unidentifiable", "bad/anonymous.png")
        session = self.session_fixture()
        write_json(session / "applied_system.json", {"task": "vig", "sources": [
            {"source_run_id": known.name}, {"source_run_id": unidentifiable.name}]})
        report = build_quality_report([known, unidentifiable], [session])
        self.assertEqual(report["images"][0]["training_exposure"], "unknown")

    def test_completed_with_missing_expected_records_is_provisional(self):
        session = self.session_fixture(total=3, completed=1)
        report = build_quality_report([], [session])
        self.assertTrue(report["sessions"][0]["provisional"])
        self.assertTrue(report["issues"])
        self.assertEqual(report["sessions"][0]["counts"]["total"], 1)

    def test_completed_with_unreadable_record_count_is_provisional(self):
        session = self.session_fixture(total=3, completed=3)
        report = build_quality_report([], [session])
        self.assertTrue(report["sessions"][0]["provisional"])
        self.assertTrue(report["issues"])

    def test_error_and_review_denominators_remain_visible(self):
        rows = [
            {"reference_label": "bad", "prediction": "good", "status": "ok"},
            {"reference_label": "bad", "prediction": "review", "status": "ok"},
            {"reference_label": "bad", "prediction": None, "status": "input_error"},
            {"reference_label": "good", "prediction": "bad", "status": "ok"},
            {"reference_label": "good", "prediction": "good", "status": "ok"},
            {"reference_label": None, "prediction": "bad", "status": "ok"},
        ]
        m = _metrics(rows)
        self.assertEqual(m["n_bad"], 3)
        self.assertEqual(m["n_good"], 2)
        self.assertEqual(m["n_labeled"], 5)
        self.assertEqual(m["n_automatic"], 4)
        self.assertAlmostEqual(m["bad_escape_rate"], 1 / 3)
        self.assertAlmostEqual(m["good_reject_rate"], 1 / 2)
        self.assertAlmostEqual(m["selective_accuracy"], 1 / 3)
        self.assertAlmostEqual(m["decision_coverage"], 4 / 6)
        self.assertAlmostEqual(m["labeled_decision_coverage"], 3 / 5)
        self.assertEqual(m["n_labeled_unavailable"], 1)


if __name__ == "__main__":
    unittest.main()
