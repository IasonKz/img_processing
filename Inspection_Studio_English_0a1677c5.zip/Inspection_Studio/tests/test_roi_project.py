"""End-to-end ROI dataset invariants, independent of trained networks."""
import csv
import json
from pathlib import Path

import numpy as np
import pytest
from PIL import Image

from nilt.roi.project import ROIProject, _split_for
from nilt.roi.geometry import default_template


def image(path, tone):
    path.parent.mkdir(parents=True, exist_ok=True)
    pixels = np.full((120, 120, 3), tone, np.uint8)
    pixels[20:80, 30:90] = min(255, tone + 30)
    Image.fromarray(pixels).save(path)
    return path


def csv_file(path, rows):
    with path.open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=['path', 'unit_id', 'tray', 'label'])
        writer.writeheader()
        writer.writerows(rows)
    return path


def prepared(tmp_path, side='bottom', label='bad'):
    source = image(tmp_path / 'input' / label / 'unit1.png', 40)
    project = ROIProject(tmp_path / 'roi', side)
    project.import_images({'folder': str(source.parent.parent), 'unit_id_strategy': 'stem', 'split_ratios': [1, 0, 0]})
    item = project.data['images'][0]
    template = default_template(side)
    template['reference_size'] = [120, 120]
    project.save_template({'template': template, 'reference_image_id': item['id']})
    project.localize_images({'method': 'template'})
    return project, item['id']


def test_import_no_image_label_propagation_and_geometry_review(tmp_path):
    project, image_id = prepared(tmp_path)
    annotation = project.state()['images'][0]['annotation']
    assert len(annotation['rois']) == 18
    assert set(annotation['quality'].values()) == {'unknown'}
    project.save_annotation({'image_id': image_id, 'geometry_reviewed': True})
    annotation = project.state()['images'][0]['annotation']
    assert annotation['geometry_reviewed']
    assert set(annotation['quality'].values()) == {'unknown'}
    # Corrections survive a localization request, even one forcing retries.
    assert project.localize_images({'force': True})['summary']['skipped'] == 1


def test_split_shared_across_views_and_crops(tmp_path):
    top = image(tmp_path / 'top.png', 40)
    bottom = image(tmp_path / 'bottom.png', 70)
    root = tmp_path / 'projects'
    for side, source in [('top', top), ('bottom', bottom)]:
        path = csv_file(tmp_path / f'{side}.csv', [{'path': str(source), 'unit_id': 'physical-1', 'tray': 'T1', 'label': 'bad'}])
        project = ROIProject(root, side)
        project.import_images({'csv_path': str(path), 'seed': 24 if side == 'top' else 837, 'test_trays': ['T1']})
        assert project.state()['images'][0]['split'] == 'test'
    ledger = json.loads((root / 'unit_splits.json').read_text())
    assert list(ledger['units']) == ['physical-1']


def test_missing_pin_preserves_crop_and_explicit_bad(tmp_path):
    project, image_id = prepared(tmp_path)
    project.save_annotation({'image_id': image_id, 'geometry_reviewed': True, 'quality': {'pin_r1_c1': 'bad'}})
    result = project.export_datasets({})
    manifest = json.loads((Path(result['path']) / 'crops_manifest.json').read_text())
    assert len(manifest['samples']) == 18
    assert len(result['classification']) == 1
    assert result['classification'][0]['labels'] == {'bad': 1}
    rows = list(csv.DictReader(open(result['classification'][0]['groups_path'])))
    assert rows[0]['group'] == 'unit1'
    assert rows[0]['relative_path'].startswith('train/bad/')
    assert (Path(result['classification'][0]['path']) / rows[0]['relative_path']).is_file()
    assert (Path(result['path']) / 'annotations' / f'{image_id}.json').exists()
    # Inferred expected position is NOT a positive segmentation annotation.
    seg = json.loads(Path(result['segmentation']['manifest_path']).read_text())
    sample = seg['samples'][0]
    mask = np.array(Image.open(Path(result['segmentation']['path']) / sample['masks']['pins']))
    valid = np.array(Image.open(Path(result['segmentation']['path']) / sample['valid_masks']['pins']))
    assert mask.max() == 0
    assert valid.min() == 0 and valid.max() == 255


def test_unconfirmed_identity_and_stale_template_block_export(tmp_path):
    project, image_id = prepared(tmp_path)
    project.save_annotation({'image_id': image_id, 'geometry_reviewed': True, 'identity_confirmed': False})
    with pytest.raises(ValueError, match='No exportable'):
        project.export_datasets({})
    project.save_annotation({'image_id': image_id, 'identity_confirmed': True})
    template = project.state()['template']
    template['rois'][0]['margin'] += .1
    project.save_template({'template': template})
    with pytest.raises(ValueError, match='No exportable'):
        project.export_datasets({})


def test_geometry_edit_invalidates_quality_but_approval_does_not_label(tmp_path):
    project, image_id = prepared(tmp_path)
    project.save_annotation({'image_id': image_id, 'geometry_reviewed': True, 'quality': {'pin_r1_c1': 'good'}})
    rois = project.state()['images'][0]['annotation']['rois']
    rois[0]['points'][0][0] += 1
    project.save_annotation({'image_id': image_id, 'rois': rois})
    annotation = project.state()['images'][0]['annotation']
    assert annotation['quality']['pin_r1_c1'] == 'unknown'
    assert not annotation['geometry_reviewed']
    assert annotation['rois'][0]['source'] == 'manual'


def test_nested_top_masks_independent(tmp_path):
    project, image_id = prepared(tmp_path, 'top')
    rois = project.state()['images'][0]['annotation']['rois']
    for roi in rois:
        roi['source'] = 'manual'
        roi['observed_points'] = roi['points']
    project.save_annotation({'image_id': image_id, 'rois': rois, 'geometry_reviewed': True})
    exported = project.export_datasets({})['segmentation']
    sample = json.loads(Path(exported['manifest_path']).read_text())['samples'][0]
    inner = np.array(Image.open(Path(exported['path']) / sample['masks']['inner_area']))
    lens = np.array(Image.open(Path(exported['path']) / sample['masks']['lens']))
    assert inner[60, 60] == 255 and lens[60, 60] == 255


def test_duplicate_alias_unions_other_captures(tmp_path):
    first = image(tmp_path / 'first.png', 40)
    duplicate = tmp_path / 'duplicate.png'
    duplicate.write_bytes(first.read_bytes())
    other = image(tmp_path / 'other.png', 60)
    source = csv_file(tmp_path / 'images.csv', [
        {'path': str(first), 'unit_id': 'U1'}, {'path': str(duplicate), 'unit_id': 'U2'}, {'path': str(other), 'unit_id': 'U2'}])
    project = ROIProject(tmp_path / 'roi', 'bottom')
    result = project.import_images({'csv_path': str(source)})
    assert result['summary']['duplicates'] == 1
    assert {i['unit_id'] for i in result['state']['images']} == {'U1'}
    assert len({i['split'] for i in result['state']['images']}) == 1


def test_duplicate_frozen_conflict_quarantines_groups(tmp_path):
    units = {}
    for n in range(100):
        candidate = f'U{n}'
        units.setdefault(_split_for(candidate, 42, [.7, .15, .15]), candidate)
    train, test = units['train'], units['test']
    first, other = image(tmp_path / 'one.png', 40), image(tmp_path / 'two.png', 60)
    duplicate = tmp_path / 'copy.png'
    duplicate.write_bytes(first.read_bytes())
    source = csv_file(tmp_path / 'images.csv', [
        {'path': str(first), 'unit_id': train}, {'path': str(other), 'unit_id': test}, {'path': str(duplicate), 'unit_id': test}])
    project = ROIProject(tmp_path / 'roi', 'bottom')
    result = project.import_images({'csv_path': str(source)})
    assert result['summary']['errors']
    ledger = json.loads((project.root / 'unit_splits.json').read_text())
    assert set(ledger['blocked_units']) == {train, test}


def test_margin_change_does_not_invent_observed_shape(tmp_path):
    project, image_id = prepared(tmp_path)
    rois = project.state()['images'][0]['annotation']['rois']
    assert rois[0]['source'] == 'inferred'
    rois[0]['margin'] += .2
    project.save_annotation({'image_id': image_id, 'rois': rois, 'geometry_reviewed': True})
    roi = project.state()['images'][0]['annotation']['rois'][0]
    assert roi['source'] == 'inferred'
    assert not roi.get('observed_points')


def test_observation_confirmation_is_independent_of_quality_and_geometry(tmp_path):
    project, image_id = prepared(tmp_path)
    project.save_annotation({'image_id': image_id, 'geometry_reviewed': True, 'quality': {'pin_r1_c1': 'good'}})
    rois = project.state()['images'][0]['annotation']['rois']
    rois[0]['observed_confirmed'] = True
    result = project.save_annotation({'image_id': image_id, 'rois': rois})
    annotation = result['state']['images'][0]['annotation']
    assert annotation['geometry_reviewed']
    assert annotation['quality']['pin_r1_c1'] == 'good'
    assert annotation['rois'][0]['observed_points'] == annotation['rois'][0]['points']
    assert annotation['rois'][0]['presence'] == 'present'
    rois = annotation['rois']
    rois[0]['presence'] = 'absent'
    result = project.save_annotation({'image_id': image_id, 'rois': rois})
    annotation = result['state']['images'][0]['annotation']
    assert annotation['geometry_reviewed']
    assert annotation['quality']['pin_r1_c1'] == 'good'  # Does not silently relabel.
    assert not annotation['rois'][0]['observed_points']
    exported = project.export_datasets({})['segmentation']
    sample = json.loads(Path(exported['manifest_path']).read_text())['samples'][0]
    valid = np.array(Image.open(Path(exported['path']) / sample['valid_masks']['pins']))
    target = np.array(Image.open(Path(exported['path']) / sample['masks']['pins']))
    assert valid[33, 33] == 255 and target[33, 33] == 0


def test_cancel_retains_completed_imports(tmp_path):
    source = tmp_path / 'images'
    image(source / 'one.png', 40)
    image(source / 'two.png', 60)
    project = ROIProject(tmp_path / 'roi', 'bottom')
    project.cancelled = lambda: len(project.data['images']) >= 1
    with pytest.raises(RuntimeError, match='cancelled'):
        project.import_images({'folder': str(source), 'unit_id_strategy': 'stem'})
    resumed = ROIProject(tmp_path / 'roi', 'bottom')
    assert len(resumed.state()['images']) == 1
    result = resumed.import_images({'folder': str(source), 'unit_id_strategy': 'stem'})
    assert result['summary']['duplicates'] == 1
    assert len(result['state']['images']) == 2


def test_overwritten_source_never_reuses_old_annotations(tmp_path):
    project, image_id = prepared(tmp_path)
    project.save_annotation({'image_id': image_id, 'geometry_reviewed': True})
    image(project.image_path(image_id), 170)
    with pytest.raises(ValueError, match='Source image changed'):
        project.export_datasets({})
    with pytest.raises(ValueError, match='Source image changed'):
        project.localize_images({'force': True, 'replace_reviewed': True})


def test_export_native_depth_preserved_and_preview_separate(tmp_path):
    import cv2
    source = tmp_path / 'source' / 'unit16.png'
    source.parent.mkdir(parents=True)
    pixels = np.full((120, 120, 3), 40000, np.uint16)
    ok, encoded = cv2.imencode('.png', pixels)
    assert ok
    source.write_bytes(encoded.tobytes())
    project = ROIProject(tmp_path / 'roi', 'bottom')
    project.import_images({'folder': str(source.parent), 'unit_id_strategy': 'stem', 'split_ratios': [1, 0, 0]})
    image_id = project.state()['images'][0]['id']
    project.save_template({'template': default_template('bottom'), 'reference_image_id': image_id})
    project.localize_images({'method': 'template'})
    project.save_annotation({'image_id': image_id, 'geometry_reviewed': True, 'quality': {'pin_r1_c1': 'good'}})
    result = project.export_datasets({})
    crop = next((Path(result['path']) / 'crops' / 'pins').glob('*.png'))
    decoded = cv2.imdecode(np.frombuffer(crop.read_bytes(), np.uint8), cv2.IMREAD_UNCHANGED)
    assert decoded.dtype == np.uint16 and decoded.max() == 40000
    preview = Path(result['path']) / 'annotated_previews' / f'{image_id}.png'
    assert np.array(Image.open(preview)).dtype == np.uint8
