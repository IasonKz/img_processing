"""Local ROI semantic segmentation, independent of TOP defect segmentation.

The network has independent sigmoid channels: nested TOP regions can overlap.
Only explicitly supervised pixels contribute to training or validation. Torch is
loaded only when training or predicting; the annotation workflow stays usable
without it. Models are trained from scratch and never download weights.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import random
import time
from pathlib import Path

import numpy as np
from PIL import Image


MODEL_SCHEMA = "roi_segmentation_model.v1"
ARCHITECTURE = "roi_unet_small.v1"


def _write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False), encoding="utf-8")
    os.replace(temporary, path)


def _torch():
    try:
        import torch
    except ImportError as exc:
        raise RuntimeError("ROI segmentation training/inference requires the local PyTorch training environment. Install requirements-training.txt for the CPU or CUDA environment.") from exc
    return torch


def _manifest_path(dataset):
    path = Path(dataset).expanduser().resolve()
    if path.is_file():
        return path
    direct = path / "manifest.json"
    nested = path / "segmentation" / "manifest.json"
    if direct.exists():
        # The top-level export may also have its own (non-segmentation) manifest.
        meta = json.loads(direct.read_text(encoding="utf-8"))
        if meta.get("schema") == "roi_segmentation_dataset.v1" or not nested.exists():
            return direct
    if nested.exists():
        return nested
    raise ValueError("No segmentation/manifest.json was found. Export a reviewed ROI segmentation dataset first.")


def inspect_dataset(dataset, require_fit_splits=True):
    """Validate the split ledger and masks before importing optional torch."""
    manifest_path = _manifest_path(dataset)
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    if data.get("schema") != "roi_segmentation_dataset.v1":
        raise ValueError("Expected roi_segmentation_dataset.v1 manifest.")
    classes = data.get("channels", data.get("classes", []))
    if not classes or not all(isinstance(c, str) and c for c in classes) or len(set(classes)) != len(classes):
        raise ValueError("Segmentation channels must be unique nonempty class names.")
    if data.get("side") not in ("top", "bottom"):
        raise ValueError("ROI segmentation side must be top or bottom.")
    if not isinstance(data.get("samples"), list):
        raise ValueError("Segmentation samples must be a list.")
    counts = {"train": 0, "val": 0, "test": 0}
    units, images = {}, {}
    prepared = []
    for sample in data["samples"]:
        sample = dict(sample)
        split = {"validation": "val", "valid": "val"}.get(sample.get("split"), sample.get("split"))
        if split not in counts:
            raise ValueError("Every segmentation sample needs a train/val/test split.")
        unit = str(sample.get("unit_id") or "").strip()
        if not unit:
            raise ValueError("Every segmentation image must have a confirmed unit_id.")
        if unit in units and units[unit] != split:
            raise ValueError(f"Unit leakage: {unit} occurs in more than one split.")
        units[unit] = split
        source = sample.get("image_path")
        if not source:
            raise ValueError("Segmentation sample missing image_path.")
        path = (manifest_path.parent / source).resolve()
        if not path.is_file():
            raise ValueError(f"Segmentation source image not found: {path}")
        identity = str(sample.get("image_id") or path)
        if identity in images and images[identity] != split:
            raise ValueError(f"Image leakage: {identity} occurs in more than one split.")
        images[identity] = split
        for field in ("masks", "valid_masks"):
            mapping = sample.get(field)
            if not isinstance(mapping, dict) or set(mapping) != set(classes):
                raise ValueError(f"{field} must explicitly provide every channel, including absent shapes.")
            sample[field] = {c: str((manifest_path.parent / mapping[c]).resolve()) for c in classes}
            for mask in sample[field].values():
                if not Path(mask).is_file():
                    raise ValueError(f"Missing segmentation mask: {mask}")
        sample.update(image_path=str(path), split=split, unit_id=unit)
        counts[split] += 1
        prepared.append(sample)
    if require_fit_splits and (not counts["train"] or not counts["val"]):
        raise ValueError("ROI training requires both training and validation images from different units. Test images are never used for fitting.")
    return {**data, "classes": classes, "channels": classes, "samples": prepared,
            "counts": counts, "manifest_path": str(manifest_path),
            "manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest()}


def _image_array(path, image_size, intensity=None):
    from ..image_io import load_rgb, NativeImage, intensity_settings
    source = load_rgb(path)
    pixels = np.asarray(source, dtype=np.float32)
    if isinstance(source, NativeImage):
        levels = intensity_settings({"intensity": intensity or {}})
        pixels = np.clip((pixels - levels["uint16_black_level"]) /
                         (levels["uint16_white_level"] - levels["uint16_black_level"]), 0, 1)
    else:
        pixels /= 255.0
    original_size = source.size
    resized = np.stack([np.asarray(Image.fromarray(pixels[:, :, c]).resize(
        (image_size, image_size), Image.Resampling.BILINEAR), dtype=np.float32) for c in range(3)])
    return np.ascontiguousarray(resized), original_size


def _mask_array(path, size, expected_size):
    with Image.open(path) as image:
        if image.size != expected_size:
            raise ValueError(f"Mask size {image.size} differs from source {expected_size}: {path}")
        values = np.asarray(image.convert("L"))
        if np.any((values != 0) & (values != 255)):
            raise ValueError(f"ROI masks must be binary 0/255 PNGs: {path}")
        return (np.asarray(image.convert("L").resize((size, size), Image.Resampling.NEAREST)) > 127).astype(np.float32)


def _network(torch, channels, width=16):
    nn = torch.nn

    class Block(nn.Module):
        def __init__(self, a, b):
            super().__init__()
            self.net = nn.Sequential(nn.Conv2d(a, b, 3, padding=1), nn.GroupNorm(4, b), nn.ReLU(inplace=True),
                                     nn.Conv2d(b, b, 3, padding=1), nn.GroupNorm(4, b), nn.ReLU(inplace=True))

        def forward(self, x):
            return self.net(x)

    class SmallUNet(nn.Module):
        def __init__(self):
            super().__init__()
            self.enc1 = Block(3, width)
            self.enc2 = Block(width, width * 2)
            self.center = Block(width * 2, width * 4)
            self.dec2 = Block(width * 6, width * 2)
            self.dec1 = Block(width * 3, width)
            self.head = nn.Conv2d(width, channels, 1)

        def forward(self, x):
            a = self.enc1(x)
            b = self.enc2(torch.nn.functional.max_pool2d(a, 2))
            c = self.center(torch.nn.functional.max_pool2d(b, 2))
            c = self.dec2(torch.cat((torch.nn.functional.interpolate(c, size=b.shape[-2:], mode="bilinear", align_corners=False), b), 1))
            c = self.dec1(torch.cat((torch.nn.functional.interpolate(c, size=a.shape[-2:], mode="bilinear", align_corners=False), a), 1))
            return self.head(c)

    return SmallUNet()


def _loss(torch, logits, target, valid):
    bce = torch.nn.functional.binary_cross_entropy_with_logits(logits, target, reduction="none")
    bce = (bce * valid).sum() / valid.sum().clamp_min(1)
    predicted = logits.sigmoid() * valid
    truth = target * valid
    dims = (0, 2, 3)
    dice = (2 * (predicted * truth).sum(dims) + 1) / (predicted.sum(dims) + truth.sum(dims) + 1)
    active = valid.sum(dims) > 0
    return bce + (1 - dice[active]).mean() if bool(active.any()) else logits.sum() * 0


def _options(options):
    options = dict(options or {})
    result = {"epochs": 20, "batch_size": 4, "image_size": 256, "learning_rate": 0.001,
              "device": "auto", "seed": 42, "width": 16, "threshold": 0.5,
              "augment_rotations": True, "cpu_threads": 2, "intensity": {}, **options}
    for key, lo, hi in (("epochs", 1, 10000), ("batch_size", 1, 128), ("image_size", 32, 2048),
                        ("width", 4, 64), ("cpu_threads", 1, 128)):
        if isinstance(result[key], bool) or not isinstance(result[key], int) or not lo <= result[key] <= hi:
            raise ValueError(f"{key} must be an integer between {lo} and {hi}.")
    if result["width"] % 4:
        raise ValueError("Network width must be divisible by four.")
    if result["device"] not in ("auto", "cpu", "cuda"):
        raise ValueError("ROI segmentation supports auto, cpu or cuda.")
    for key, lo, hi in (("learning_rate", 0, 1), ("threshold", 0, 1)):
        value = result[key]
        if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value) or not lo < value < hi:
            raise ValueError(f"{key} must be finite and between {lo} and {hi}.")
    return result


def _supervision_counts(data, split):
    totals = {c: {"positive_pixels": 0, "supervised_pixels": 0} for c in data["classes"]}
    for sample in data["samples"]:
        if sample["split"] != split:
            continue
        for channel in data["classes"]:
            with Image.open(sample["masks"][channel]) as raw:
                mask = np.asarray(raw.convert("L")) > 127
            with Image.open(sample["valid_masks"][channel]) as raw:
                valid = np.asarray(raw.convert("L")) > 127
            if mask.shape != valid.shape:
                raise ValueError("Segmentation target and valid mask dimensions differ.")
            totals[channel]["positive_pixels"] += int(np.count_nonzero(mask & valid))
            totals[channel]["supervised_pixels"] += int(np.count_nonzero(valid))
    return totals


def train(dataset_dir, output_dir, options=None):
    """Train only on train; choose best checkpoint by masked validation loss."""
    output = Path(output_dir).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    status = {"status": "running", "stage": "validation", "started": time.time(), "epoch": 0, "progress": 0}

    def report(**values):
        status.update(values, updated=time.time())
        _write_json(output / "status.json", status)

    def stopped():
        return (output / "STOP").exists() or (output / "stop.flag").exists()

    try:
        report(message="Checking segmentation dataset and unit splits")
        data, opts = inspect_dataset(dataset_dir), _options(options)
        if (output / "model.json").exists() or (output / "last.pt").exists():
            raise ValueError("Choose a new output directory for each training experiment.")
        supervision = _supervision_counts(data, "train")
        unsupported = [c for c in data["classes"] if not supervision[c]["positive_pixels"]]
        if len(unsupported) == len(data["classes"]):
            raise ValueError("No confirmed positive shape pixels in the training split. Review observed geometry before training; inherited expected regions are not observed segmentation targets.")
        torch = _torch()
        torch.set_num_threads(opts["cpu_threads"])
        random.seed(opts["seed"])
        np.random.seed(opts["seed"])
        torch.manual_seed(opts["seed"])
        device = "cuda" if opts["device"] == "auto" and torch.cuda.is_available() else opts["device"]
        if device == "auto":
            device = "cpu"
        if device == "cuda" and not torch.cuda.is_available():
            raise ValueError("CUDA is selected but unavailable in this PyTorch environment.")
        classes = data["classes"]

        class Dataset(torch.utils.data.Dataset):
            def __init__(self, split):
                self.samples = [s for s in data["samples"] if s["split"] == split]
                self.augment = split == "train" and opts["augment_rotations"]

            def __len__(self):
                return len(self.samples)

            def __getitem__(self, index):
                sample = self.samples[index]
                image, dimensions = _image_array(sample["image_path"], opts["image_size"], opts["intensity"])
                masks = np.stack([_mask_array(sample["masks"][c], opts["image_size"], dimensions) for c in classes])
                valid = np.stack([_mask_array(sample["valid_masks"][c], opts["image_size"], dimensions) for c in classes])
                if not valid.any():
                    raise ValueError(f"No supervised pixels in sample {sample.get('image_id', index)}")
                if self.augment:
                    turns = random.randrange(4)
                    image, masks, valid = [np.rot90(a, turns, axes=(-2, -1)).copy() for a in (image, masks, valid)]
                return tuple(torch.from_numpy(a) for a in (image, masks, valid))

        training = torch.utils.data.DataLoader(Dataset("train"), batch_size=opts["batch_size"], shuffle=True, num_workers=0)
        validation = torch.utils.data.DataLoader(Dataset("val"), batch_size=opts["batch_size"], shuffle=False, num_workers=0)
        model = _network(torch, len(classes), opts["width"]).to(device)
        optimizer = torch.optim.AdamW(model.parameters(), lr=opts["learning_rate"])
        config = {"schema": MODEL_SCHEMA, "architecture": ARCHITECTURE, "side": data["side"], "classes": classes,
                  "channels": classes, "template_version": data.get("template_version"),
                  "dataset_sha256": data["manifest_sha256"], "dataset_counts": data["counts"], "options": opts,
                  "thresholds": {c: opts["threshold"] for c in classes}, "threshold_source": "fixed_not_calibrated",
                  "checkpoint": "best.pt", "normalization": "fixed_uint8_or_uint16_scale",
                  "geometry_policy": "expected_ROIs_preserved", "created": time.time()}
        config.update(training_supervision=supervision, unsupported_classes=unsupported)
        config["development_units"] = {split: sorted({s["unit_id"] for s in data["samples"] if s["split"] == split})
                                       for split in ("train", "val")}
        if isinstance(data.get("template"), dict):
            config["template"] = data["template"]
        _write_json(output / "model.json", config)
        history, best = [], float("inf")
        report(stage="training", device=device, epochs=opts["epochs"], counts=data["counts"], classes=classes,
               warnings=["No positive training pixels for channel: " + c for c in unsupported])
        for epoch in range(1, opts["epochs"] + 1):
            if stopped():
                report(status="stopped", stage="stopped", message="Stopped by user", finished=time.time())
                return status
            model.train()
            total_loss, batches = 0.0, 0
            for batch, (images, masks, valid) in enumerate(training):
                if stopped():
                    report(status="stopped", stage="stopped", message="Stopped by user", finished=time.time())
                    return status
                images, masks, valid = (x.to(device) for x in (images, masks, valid))
                optimizer.zero_grad(set_to_none=True)
                loss = _loss(torch, model(images), masks, valid)
                if not bool(torch.isfinite(loss)):
                    raise ValueError("Training produced a nonfinite loss.")
                loss.backward()
                optimizer.step()
                total_loss += float(loss.detach().cpu())
                batches += 1
                report(epoch=epoch, batch=batch + 1, batches=len(training),
                       progress=((epoch - 1) + (batch + 1) / len(training)) / opts["epochs"],
                       train_loss=total_loss / batches, message=f"Epoch {epoch}/{opts['epochs']}")
            model.eval()
            val_loss, val_batches = 0.0, 0
            intersection = np.zeros(len(classes), dtype=np.float64)
            denominator = np.zeros(len(classes), dtype=np.float64)
            support = np.zeros(len(classes), dtype=np.float64)
            with torch.no_grad():
                for images, masks, valid in validation:
                    if stopped():
                        report(status="stopped", stage="stopped", message="Stopped by user", finished=time.time())
                        return status
                    images, masks, valid = (x.to(device) for x in (images, masks, valid))
                    logits = model(images)
                    val_loss += float(_loss(torch, logits, masks, valid).cpu())
                    val_batches += 1
                    binary = (logits.sigmoid() >= opts["threshold"]).float() * valid
                    truth = masks * valid
                    intersection += (binary * truth).sum((0, 2, 3)).cpu().numpy()
                    denominator += (binary + truth).sum((0, 2, 3)).cpu().numpy()
                    support += valid.sum((0, 2, 3)).cpu().numpy()
            val_loss /= val_batches
            dice = {c: (float(2 * intersection[i] / denominator[i]) if denominator[i] else 1.0)
                    if support[i] else None for i, c in enumerate(classes)}
            metrics = {"epoch": epoch, "train_loss": total_loss / batches, "val_loss": val_loss,
                       "val_dice": dice, "val_supervised_pixels": dict(zip(classes, support.tolist()))}
            history.append(metrics)
            _write_json(output / "history.json", history)
            checkpoint = {"schema": MODEL_SCHEMA, "config": config,
                          "state_dict": {k: v.detach().cpu() for k, v in model.state_dict().items()},
                          "epoch": epoch, "metrics": metrics}
            temporary = output / "checkpoint.tmp"
            torch.save(checkpoint, temporary)
            os.replace(temporary, output / "last.pt")
            if val_loss < best:
                best = val_loss
                torch.save(checkpoint, temporary)
                os.replace(temporary, output / "best.pt")
                config.update(best_epoch=epoch, best_val_loss=best, metrics=metrics)
                _write_json(output / "model.json", config)
            report(metrics=metrics, best_epoch=config["best_epoch"], best_val_loss=best)
        report(status="completed", stage="completed", progress=1.0, model=str(output / "model.json"),
               checkpoint=str(output / "best.pt"), finished=time.time(), message="ROI segmentation training completed")
        return status
    except Exception as exc:
        report(status="failed", stage="failed", error=str(exc), message=str(exc), finished=time.time())
        raise


def predict(image_path, model_path, device="cpu"):
    """Return independent probability channels at the source image resolution.

    Output masks are model observations, never automatically confirmed geometry.
    Accept a model directory, model.json, or a weights-only-compatible checkpoint.
    """
    torch = _torch()
    path = Path(model_path).expanduser().resolve()
    config = None
    if path.is_dir():
        path = path / "model.json"
    if path.suffix.lower() == ".json":
        config = json.loads(path.read_text(encoding="utf-8"))
        checkpoint = (path.parent / config.get("checkpoint", "best.pt")).resolve()
    else:
        checkpoint = path
    loaded = torch.load(checkpoint, map_location="cpu", weights_only=True)
    if loaded.get("schema") != MODEL_SCHEMA:
        raise ValueError("Unsupported ROI segmentation checkpoint schema.")
    config = config or loaded["config"]
    if config.get("architecture") != ARCHITECTURE:
        raise ValueError("Unsupported ROI segmentation architecture.")
    if config.get("classes") != loaded["config"].get("classes"):
        raise ValueError("Model manifest classes do not match checkpoint classes.")
    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"
    if device not in ("cpu", "cuda") or (device == "cuda" and not torch.cuda.is_available()):
        raise ValueError("Requested ROI segmentation inference device is unavailable.")
    opts = config["options"]
    torch.set_num_threads(opts.get("cpu_threads", 2))
    model = _network(torch, len(config["classes"]), opts["width"])
    model.load_state_dict(loaded["state_dict"])
    model.to(device).eval()
    pixels, (width, height) = _image_array(image_path, opts["image_size"], opts.get("intensity", {}))
    with torch.no_grad():
        logits = model(torch.from_numpy(pixels)[None].to(device))
        probability = torch.nn.functional.interpolate(logits.sigmoid(), size=(height, width),
                                                      mode="bilinear", align_corners=False)[0].cpu().numpy()
    thresholds = config.get("thresholds", {})
    masks = {c: probability[i] >= float(thresholds.get(c, 0.5)) for i, c in enumerate(config["classes"])}
    return {"classes": config["classes"], "probabilities": probability, "masks": masks,
            "image_size": [width, height], "config": config}


def _components(prediction):
    import cv2
    result = {}
    for channel, kind in enumerate(prediction["classes"]):
        mask = prediction["masks"][kind].astype(np.uint8)
        count, labels, stats, centers = cv2.connectedComponentsWithStats(mask, connectivity=8)
        minimum = max(5, int(mask.size * .000025))
        regions = []
        for index in range(1, count):
            if stats[index, cv2.CC_STAT_AREA] < minimum:
                continue
            component = (labels == index).astype(np.uint8)
            contours, _ = cv2.findContours(component, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            contour = max(contours, key=cv2.contourArea)
            if len(contour) < 3:
                continue
            polygon = cv2.approxPolyDP(contour, max(1., cv2.arcLength(contour, True) * .008), True).reshape(-1, 2)
            if len(polygon) < 3:
                continue
            regions.append({"center": centers[index].tolist(), "polygon": polygon.astype(float).tolist(),
                            "area": int(stats[index, cv2.CC_STAT_AREA]),
                            "confidence": float(prediction["probabilities"][channel][component > 0].mean())})
        result[kind] = sorted(regions, key=lambda r: r["area"], reverse=True)[:64]
    return result


def _center(roi):
    points = np.asarray(roi["points"], dtype=float)
    return points[0] if roi["shape"] in ("circle", "point") else points.mean(axis=0)


def _matches(rois, components, distance_limit):
    """One observation can belong to only one expected ROI of the same kind."""
    from scipy.optimize import linear_sum_assignment
    matches = []
    for kind in {r["kind"] for r in rois}:
        expected = [r for r in rois if r["kind"] == kind and r["shape"] != "point"]
        observed = components.get(kind, [])
        if not expected or not observed:
            continue
        distances = np.linalg.norm(np.asarray([_center(r) for r in expected])[:, None, :] -
                                   np.asarray([r["center"] for r in observed])[None, :, :], axis=2)
        left, right = linear_sum_assignment(distances)
        for a, b in zip(left, right):
            if distances[a, b] <= distance_limit:
                matches.append((expected[a], observed[b], float(distances[a, b])))
    return matches


def _model_pose(template, size, components, quarter_turn):
    import cv2
    from .geometry import template_to_rois
    from .localization import _initial, _angle, _angle_delta
    diagonal = float(np.linalg.norm(size))
    candidates = []
    quarters = range(4) if quarter_turn is None else [quarter_turn]
    for quarter in quarters:
        transform = _initial(template["reference_size"], size, quarter)
        for _ in range(3):
            rows = template_to_rois(template, size, transform)
            matches = _matches(rows, components, diagonal * .17)
            if len(matches) < 3:
                break
            source = np.asarray([_center({**r, "points": r["reference_points"]}) for r, _, _ in matches], np.float32)
            target = np.asarray([o["center"] for _, o, _ in matches], np.float32)
            fit, inliers = cv2.estimateAffinePartial2D(source, target, method=cv2.RANSAC,
                                                      ransacReprojThreshold=max(2., diagonal * .015))
            if fit is None or inliers is None or int(inliers.sum()) < 3:
                break
            candidate = np.vstack([fit, [0, 0, 1]])
            if _angle_delta(_angle(candidate), quarter * 90) > 35:
                break
            transform = candidate
        rows = template_to_rois(template, size, transform)
        matches = _matches(rows, components, diagonal * .025)
        if len(matches) < 3:
            continue
        centers = np.asarray([o["center"] for _, o, _ in matches])
        if min(np.ptp(centers, axis=0) / np.asarray(size)) < .12:
            continue
        source_scale = min(np.asarray(size) / np.asarray(template["reference_size"]))
        scale = float(np.linalg.norm(transform[:2, 0]))
        if not .5 * source_scale <= scale <= 2 * source_scale:
            continue
        kinds = {r["kind"] for r, _, _ in matches}
        # Unique asymmetric classes are essential for canonical pin/corner IDs.
        asymmetric = bool(kinds.intersection({"triangle", "square", "label"}))
        expected_count = sum(r["shape"] != "point" and r["kind"] in components for r in rows)
        support = len(matches) / max(1, expected_count)
        residual = float(np.mean([distance for _, _, distance in matches])) / diagonal
        mean_probability = float(np.mean([o["confidence"] for _, o, _ in matches]))
        score = support * .45 + max(0., 1 - residual / .025) * .25 + mean_probability * .2 + .1 * asymmetric
        candidates.append({"transform": transform, "score": score, "asymmetric": asymmetric,
                           "support": support, "matches": len(matches), "residual": residual,
                           "orientation_degrees": _angle(transform)})
    candidates.sort(key=lambda c: c["score"], reverse=True)
    return candidates


def _attach_observations(result, components, size):
    """Record measured shapes, never replace expected shape or erase missing ROIs."""
    import cv2
    from .geometry import roi_bounds
    from .localization import _angle
    observed_by_id = {}
    for roi, component, distance in _matches(result["rois"], components, float(np.linalg.norm(size)) * .05):
        bounds = roi_bounds(roi)
        expected_area = max(1., (bounds[2] - bounds[0]) * (bounds[3] - bounds[1]))
        ratio = component["area"] / expected_area
        # Bridges/merged components are preserved in the input crop, not assigned
        # as a new ball centre or a replacement for several expected balls.
        if not .12 <= ratio <= 2.5:
            continue
        points = component["polygon"]
        observed_shape = "polygon"
        if roi["shape"] == "circle":
            center, radius = cv2.minEnclosingCircle(np.asarray(points, np.float32))
            points = [list(center), [center[0] + float(radius), center[1]]]
            observed_shape = "circle"
        roi.update(observed_points=points, observed_shape=observed_shape, source="detected",
                   observation_method="segmentation", observation_confidence=round(component["confidence"], 4),
                   observation_displacement_pixels=round(distance, 3))
        observed_by_id[roi["id"]] = component
    # Do not use a missing mask to assert absence or good quality. When overall
    # registration is reliable its expected ROI still supplies the classifier crop.
    for roi in result["rois"]:
        if roi["id"] not in observed_by_id:
            roi["segmentation_observation"] = "not_observed"
    result["segmentation"] = {"observed_roi_count": len(observed_by_id),
                              "component_counts": {k: len(v) for k, v in components.items()},
                              "confidence_kind": "uncalibrated_model_score"}
    result["orientation_degrees"] = round(_angle(np.asarray(result["transform"])), 4)
    return result


def localize_with_model(image_path, template, model_path, reference_path=None, quarter_turn=None, method="hybrid"):
    """Segmentation-only registration or CV registration with model observations."""
    from .geometry import normalize_template, template_to_rois, roi_bounds
    from .localization import localize, _initial
    template = normalize_template(template)
    if method not in ("segmentation", "hybrid"):
        raise ValueError("Model localization method must be segmentation or hybrid.")
    if quarter_turn is not None and (isinstance(quarter_turn, bool) or quarter_turn not in range(4)):
        raise ValueError("quarter_turn must be 0, 1, 2, 3 or null.")
    prediction = predict(image_path, model_path)
    if prediction["config"]["side"] != template["side"]:
        raise ValueError("Segmentation model side differs from the selected geometry template.")
    size = prediction["image_size"]
    components = _components(prediction)
    if method == "hybrid":
        result = localize(image_path, template, reference_path, quarter_turn)
        result["method"] = "hybrid:" + result["method"]
    else:
        candidates = _model_pose(template, size, components, quarter_turn)
        reasons = []
        if candidates:
            best = candidates[0]
            transform = best["transform"]
            confidence = best["score"]
            ambiguity = quarter_turn is None and (not best["asymmetric"] or
                         (len(candidates) > 1 and best["score"] - candidates[1]["score"] < .05))
            if ambiguity:
                reasons.append("ambiguous_model_orientation")
            if confidence < .8 or best["support"] < .5:
                reasons.append("weak_model_geometry_consistency")
        else:
            transform = _initial(template["reference_size"], size, int(quarter_turn or 0))
            confidence = 0.
            reasons.append("segmentation_registration_failed")
        result = {"version": "roi-segmentation-localization.v1", "transform": transform.tolist(),
                  "rois": template_to_rois(template, size, transform), "confidence": round(float(confidence), 4),
                  "method": "segmentation", "needs_review": bool(reasons), "reasons": reasons,
                  "orientation_manual": quarter_turn is not None,
                  "candidates": [{k: v for k, v in row.items() if k != "transform"} for row in candidates]}
        for roi in result["rois"]:
            roi["confidence"] = result["confidence"]
    if template.get("starter") and "starter_template_requires_calibration" not in result["reasons"]:
        result["reasons"].append("starter_template_requires_calibration")
    for roi in result["rois"]:
        bounds = roi_bounds({**roi, "points": roi["expected_points"]})
        if bounds[0] < 0 or bounds[1] < 0 or bounds[2] >= size[0] or bounds[3] >= size[1]:
            result["reasons"].append("roi_outside_image:" + roi["id"])
    result["reasons"] = list(dict.fromkeys(result["reasons"]))
    result["needs_review"] = bool(result["reasons"])
    result["model_schema"] = prediction["config"]["schema"]
    result["model_template_version"] = prediction["config"].get("template_version")
    if result["model_template_version"] != template.get("version"):
        result["reasons"].append("model_template_version_mismatch")
        result["needs_review"] = True
    unsupported = set(prediction["config"].get("unsupported_classes", []))
    if method == "segmentation" and any(r.get("enabled", True) and r["kind"] in unsupported for r in result["rois"]):
        result["reasons"].append("model_has_channels_without_positive_training_support")
        result["needs_review"] = True
    return _attach_observations(result, components, size)


def evaluate(dataset_dir, model_path, output_dir, split="test"):
    """Frozen segmentation evaluation. Never fits weights, thresholds or geometry."""
    if split not in ("test", "val"):
        raise ValueError("Frozen evaluation supports test or val only.")
    output = Path(output_dir).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    status = {"status": "running", "stage": "evaluation", "started": time.time(), "progress": 0}

    def report(**values):
        status.update(values, updated=time.time())
        _write_json(output / "status.json", status)

    try:
        report(message=f"Checking frozen {split} dataset")
        data = inspect_dataset(dataset_dir, require_fit_splits=False)
        samples = [s for s in data["samples"] if s["split"] == split]
        if not samples:
            raise ValueError(f"No {split} images in this segmentation dataset.")
        if (output / "evaluation.json").exists():
            raise ValueError("Choose a new output directory for each evaluation.")
        classes = data["classes"]
        counters = {c: {"intersection": 0, "predicted_pixels": 0, "target_pixels": 0,
                        "supervised_pixels": 0, "ignored_pixels": 0} for c in classes}
        records, config = [], None
        for index, sample in enumerate(samples):
            if (output / "STOP").exists() or (output / "stop.flag").exists():
                report(status="stopped", stage="stopped", finished=time.time(), message="Stopped by user")
                return status
            prediction = predict(sample["image_path"], model_path)
            config = prediction["config"]
            if config["side"] != data["side"] or set(prediction["classes"]) != set(classes):
                raise ValueError("Evaluation dataset side/classes must match the frozen model.")
            if split == "test":
                development = config.get("development_units")
                if not isinstance(development, dict):
                    raise ValueError("Model lacks development unit provenance; independent test isolation cannot be verified.")
                development_units = set(development.get("train", [])) | set(development.get("val", []))
                overlap = {s["unit_id"] for s in samples} & development_units
                if overlap:
                    raise ValueError("Test units overlap units used to train or select this model: " + ", ".join(sorted(overlap)[:10]))
            expected_dimensions = tuple(prediction["image_size"])
            row = {"image_id": sample.get("image_id"), "unit_id": sample["unit_id"], "metrics": {}}
            for channel in classes:
                arrays = []
                for field in ("masks", "valid_masks"):
                    with Image.open(sample[field][channel]) as raw:
                        if raw.size != expected_dimensions:
                            raise ValueError("Evaluation mask dimensions differ from original image.")
                        pixels = np.asarray(raw.convert("L"))
                        if np.any((pixels != 0) & (pixels != 255)):
                            raise ValueError("Evaluation masks must be binary 0/255.")
                        arrays.append(pixels > 127)
                truth, valid = arrays
                predicted = prediction["masks"][channel] & valid
                truth = truth & valid
                stats = {"intersection": int(np.count_nonzero(predicted & truth)),
                         "predicted_pixels": int(np.count_nonzero(predicted)),
                         "target_pixels": int(np.count_nonzero(truth)),
                         "supervised_pixels": int(np.count_nonzero(valid)),
                         "ignored_pixels": int(np.count_nonzero(~valid))}
                for key, value in stats.items():
                    counters[channel][key] += value
                row["metrics"][channel] = _segmentation_metrics(stats)
            records.append(row)
            report(image=index + 1, images=len(samples), progress=(index + 1) / len(samples),
                   message=f"Evaluated {index + 1}/{len(samples)} images")
        result = {"schema": "roi_segmentation_evaluation.v1", "split": split,
                  "model": str(Path(model_path).expanduser().resolve()), "model_schema": config["schema"],
                  "model_template_version": config.get("template_version"),
                  "thresholds": config["thresholds"], "threshold_source": config.get("threshold_source"),
                  "dataset_sha256": data["manifest_sha256"], "samples": len(samples),
                  "units": len({s["unit_id"] for s in samples}), "side": data["side"],
                  "metrics": {c: _segmentation_metrics(stats) for c, stats in counters.items()},
                  "per_image": records, "created": time.time(), "frozen": True,
                  "scope": "ROI semantic masks only; does not qualify localization, quality classifiers, or the full inspection pipeline."}
        _write_json(output / "evaluation.json", result)
        report(status="completed", stage="completed", progress=1, finished=time.time(),
               evaluation=str(output / "evaluation.json"), metrics=result["metrics"],
               message="Frozen ROI segmentation evaluation completed")
        return result
    except Exception as exc:
        report(status="failed", stage="failed", error=str(exc), message=str(exc), finished=time.time())
        raise


def _segmentation_metrics(stats):
    union = stats["predicted_pixels"] + stats["target_pixels"] - stats["intersection"]
    denominator = stats["predicted_pixels"] + stats["target_pixels"]
    active = bool(stats["supervised_pixels"])
    return {**stats, "dice": (2 * stats["intersection"] / denominator if denominator else 1.) if active else None,
            "iou": (stats["intersection"] / union if union else 1.) if active else None}
