"""Post-training threshold experiments for visual_inspection_pipeline_v2.

Copy beside inspection.py. Reuses nilt inference; never edits a training run.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import html
import json
import math
from pathlib import Path
import shutil
import sys
import uuid

import numpy as np

VERSION = "1.0.0"
RULE = "bad_if_score_greater_equal_threshold"


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8")


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_csv(path, rows, columns):
    with Path(path).open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def overlap(a, b):
    a, b = Path(a).resolve(), Path(b).resolve()
    return a.is_relative_to(b) or b.is_relative_to(a)


def validate_scores(rows, scores):
    scores = np.asarray(scores, dtype=float)
    if scores.ndim != 1 or len(scores) != len(rows) or not len(rows) or not np.isfinite(scores).all():
        raise ValueError("Empty, nonfinite or mismatched scores.")
    if len({r["relative_path"] for r in rows}) != len(rows):
        raise ValueError("Duplicate image paths in score records.")
    labels = [r.get("true_class", "") for r in rows]
    if not (all(v in ("good", "bad") for v in labels) or all(v == "" for v in labels)):
        raise ValueError("Labels must be present for every valid image or absent for all.")
    return scores


def load_source(args):
    """Return immutable score records, metadata, invalid inputs, protected roots."""
    if args.from_results:
        root = Path(args.from_results).resolve()
        meta = read_json(root / "summary.json")
        if meta.get("addon_version") != VERSION or meta.get("status") != "completed":
            raise ValueError("--from-results requires a completed threshold add-on result folder.")
        if digest(root / "scores.json") != meta["scores_sha256"]:
            raise ValueError("Cached scores changed.")
        data = read_json(root / "scores.json")
        rows, scores, invalid = data["rows"], data["scores"], data["invalid"]
        meta = {k: meta[k] for k in ("run", "candidate", "selected_sha256", "original_threshold", "score_type", "task", "source", "input_root")}
        protected = [root, meta["run"]]
        if meta["input_root"]:
            protected.append(meta["input_root"])
        return rows, validate_scores(rows, scores), meta, invalid, protected

    from nilt.workflow import open_run, load_selected, predict_members
    from nilt.common import safe_relative
    from nilt.runtime import discover_inputs, load_rgb, prepare_image
    decision = read_json(args.decision) if args.decision else None
    if decision and (decision.get("format") != "threshold_addon_decision_v1" or decision.get("rule") != RULE):
        raise ValueError("Unsupported decision file.")
    run = Path(args.run or decision["run"]).resolve()
    cfg, manifest = open_run(run)
    selected = load_selected(run)
    selected_hash = digest(run / "selected.json")
    if decision and decision["selected_sha256"] != selected_hash:
        raise ValueError("Decision file belongs to a different selected model.")
    if (run / "operation.lock").exists():
        raise ValueError("Training run is busy. Wait for the operation to finish.")
    if decision:
        args.thresholds = [decision["threshold"]]
    meta = {"run": str(run), "candidate": selected["name"], "selected_sha256": selected_hash,
            "original_threshold": float(selected["threshold"]), "score_type": selected.get("score_type", "bad_probability_uncalibrated"),
            "task": cfg["task"], "source": "", "input_root": None}
    invalid = []
    protected = [run, cfg["data_root"]]
    if args.input:
        root = Path(args.input).resolve()
        protected.append(root)
        meta.update(source="new_images", input_root=str(root))
        rows, backend_rows = [], []
        for row in discover_inputs(root, labeled=args.labeled):
            path = row["path"]
            record = {"path": str(path), "relative_path": row["relative_path"],
                      "true_class": row["true_class"] or ""}
            try:
                prepare_image(load_rgb(path), {"image_size": cfg["image_size"], "resize": cfg["resize"]})
                record["file_sha256"] = digest(path)
            except (OSError, ValueError) as exc:
                invalid.append({**record, "error": str(exc)})
                continue
            rows.append(record)
            backend_rows.append({"path": str(path), "relative_path": row["relative_path"]})
        if not rows:
            raise ValueError("No valid input images. " + json.dumps(invalid[:5], ensure_ascii=False))
        if args.device:
            cfg["device"] = args.device
        scores, _ = predict_members(run, selected["members"], backend_rows, cfg)
        # Detect source changes during inference, rather than caching mismatched pixels.
        for row in rows:
            if digest(row["path"]) != row["file_sha256"]:
                raise ValueError("Input changed during inference: " + row["path"])
    else:
        split = args.split or "threshold"
        meta["source"] = "saved_" + split + "_split"
        meta["input_root"] = str(Path(cfg["data_root"]).resolve())
        rows = [{"path": r["path"], "relative_path": r["relative_path"],
                 "true_class": "bad" if r["label"] == 0 else "good", "pixel_hash": r["pixel_hash"]}
                for r in manifest if r["split"] == split]
        path = safe_relative(run, "scores/" + selected["name"] + "/" + split + ".npy")
        scores = np.load(path, allow_pickle=False)
    return rows, validate_scores(rows, scores), meta, invalid, protected


def describe(rows, scores, threshold):
    bad_pred = scores >= threshold
    result = {"threshold": threshold, "n_images": len(rows), "predicted_good": int((~bad_pred).sum()), "predicted_bad": int(bad_pred.sum())}
    if rows[0].get("true_class"):
        truth = np.array([r["true_class"] == "bad" for r in rows])
        tp, fn = int((truth & bad_pred).sum()), int((truth & ~bad_pred).sum())
        fp, tn = int((~truth & bad_pred).sum()), int((~truth & ~bad_pred).sum())
        result.update(bad_detected_TP=tp, bad_passed_as_good_FN=fn, good_rejected_as_bad_FP=fp, good_accepted_TN=tn,
                      bad_escape_rate=fn / (tp + fn) if tp + fn else None,
                      good_reject_rate=fp / (fp + tn) if fp + tn else None,
                      accuracy=(tp + tn) / len(rows))
    return result


def execute(args):
    rows, scores, meta, invalid, protected = load_source(args)
    thresholds = [float(t) for t in (args.thresholds or [meta["original_threshold"]])]
    if not all(math.isfinite(t) for t in thresholds):
        raise ValueError("Thresholds must be finite numbers (not NaN or infinity).")
    thresholds = list(dict.fromkeys(thresholds))
    # No [0,1] restriction: PatchCore uses raw anomaly scores, and boundary
    # thresholds outside [0,1] can intentionally accept/reject all probabilities.
    parent = Path(args.output_root).resolve()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
    out = parent / (stamp + "_" + uuid.uuid4().hex[:8])
    if any(overlap(out, root) for root in protected):
        raise ValueError("--output-root must be separate from inputs, training run and source results.")
    if args.copy_images:
        for row in rows:
            if row.get("file_sha256"):
                valid = digest(row["path"]) == row["file_sha256"]
            else:
                from nilt.data import pixel_signature
                valid = pixel_signature(row["path"])[0] == row["pixel_hash"]
            if not valid:
                raise ValueError("Source image changed since scoring: " + row["path"])
    out.mkdir(parents=True, exist_ok=False)
    write_json(out / "summary.json", {"status": "incomplete", "addon_version": VERSION})
    write_json(out / "scores.json", {"rows": rows, "scores": scores.tolist(), "invalid": invalid})
    write_csv(out / "invalid_images.csv", invalid, ["path", "relative_path", "true_class", "error"])
    if args.copy_images and invalid:
        review = out / "review"
        review.mkdir()
        for i, row in enumerate(invalid):
            shutil.copy2(row["path"], review / (str(i) + "__" + Path(row["path"]).name))
    comparison = []
    for i, threshold in enumerate(thresholds):
        folder = out / (f"threshold_{i + 1:02d}_" + format(threshold, ".9g"))
        folder.mkdir()
        decision = {"format": "threshold_addon_decision_v1", **meta, "threshold": threshold, "rule": RULE,
                    "decision_status": "MANUAL_THRESHOLD_NOT_INDEPENDENTLY_VALIDATED"}
        write_json(folder / "decision.json", decision)
        stats = describe(rows, scores, threshold)
        stats["n_invalid_excluded"] = len(invalid)
        write_json(folder / "counts.json", {k: stats[k] for k in ("threshold", "n_images", "predicted_good", "predicted_bad", "n_invalid_excluded")})
        if rows[0].get("true_class"):
            write_json(folder / "metrics.json", {**stats, "note": "Descriptive image-level metrics on valid inputs; no independent-unit or production qualification claim."})
        if args.copy_images:
            for label in ("good", "bad"):
                (folder / "predicted" / label).mkdir(parents=True)
        predictions = []
        for row, score in zip(rows, scores):
            pred = "bad" if score >= threshold else "good"
            record = {"source_path": row["path"], "relative_path": row["relative_path"],
                      "true_class": row.get("true_class", ""), "predicted_class": pred,
                      "score": float(score), "threshold": threshold, "score_type": meta["score_type"],
                      "model_version": meta["run"] + "/" + meta["candidate"], "output_path": ""}
            if args.copy_images:
                path = Path(row["path"])
                name = hashlib.sha256(row["relative_path"].encode()).hexdigest()[:24] + "__" + path.stem[:65] + path.suffix
                destination = folder / "predicted" / pred / name
                shutil.copy2(path, destination)
                record["output_path"] = destination.relative_to(out).as_posix()
            predictions.append(record)
        write_csv(folder / "predictions.csv", predictions, list(predictions[0]))
        comparison.append({**stats, "folder": folder.name})
    columns = list(comparison[0])
    write_csv(out / "comparison.csv", comparison, columns)
    table = "<tr>" + "".join("<th>" + html.escape(k) + "</th>" for k in columns) + "</tr>"
    for row in comparison:
        table += "<tr>" + "".join("<td>" + html.escape(str(row[k])) + "</td>" for k in columns) + "</tr>"
    (out / "comparison.html").write_text('<!doctype html><meta charset="utf-8"><title>Threshold comparison</title><style>body{font:15px system-ui;margin:32px}table{border-collapse:collapse}td,th{padding:10px;border:1px solid #ccc}th{background:#eef3f8}</style><h1>Threshold comparison</h1><p>Bad if score &ge; threshold. Lower threshold = stricter.</p><p>Same model and scores for every row. Rates use 0–1 units; None means undefined. Metrics require labels. Invalid inputs are excluded and listed separately.</p><p>Manual experiments do not inherit the original decision system’s validation. Choose using calibration data and then assess the fixed choice on independent data.</p><table>' + table + '</table>', encoding="utf-8")
    write_json(out / "summary.json", {**meta, "addon_version": VERSION, "status": "completed", "created_at": stamp,
               "thresholds": thresholds, "scores_sha256": digest(out / "scores.json"), "labeled": bool(rows[0].get("true_class")),
               "n_invalid_excluded": len(invalid), "decision_status": "MANUAL_THRESHOLD_NOT_INDEPENDENTLY_VALIDATED"})
    print("Results: " + str(out), flush=True)
    print("Open: " + str(out / "comparison.html"), flush=True)
    return out


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    source = p.add_mutually_exclusive_group(required=True)
    source.add_argument("--run", help="Completed training run containing selected.json")
    source.add_argument("--from-results", help="Completed add-on result folder; reuse its scores without inference")
    source.add_argument("--decision", help="Saved decision.json from this add-on; use its model and threshold")
    data = p.add_mutually_exclusive_group()
    data.add_argument("--input", help="New image directory")
    data.add_argument("--split", choices=["threshold", "selection"], help="Archived scores; default threshold. Test split intentionally excluded from tuning.")
    p.add_argument("--thresholds", type=float, nargs="+", help="One or more manual thresholds; default original threshold")
    p.add_argument("--labeled", action="store_true", help="Input has true good/ and bad/ subfolders")
    p.add_argument("--copy-images", action="store_true", help="Create predicted/good and predicted/bad copies per threshold")
    p.add_argument("--device", choices=["cpu", "cuda", "auto"])
    p.add_argument("--output-root", default="threshold_results", help="Parent for a new unique result folder")
    args = p.parse_args(argv)
    if args.from_results and (args.input or args.split or args.labeled or args.device):
        p.error("--from-results uses its saved data, labels and scores; omit --input/--split/--labeled/--device.")
    if args.decision and (not args.input or args.thresholds):
        p.error("--decision requires --input and supplies the threshold itself; omit --thresholds.")
    if args.labeled and not args.input:
        p.error("--labeled is only for --input; archived splits already have labels.")
    try:
        execute(args)
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
