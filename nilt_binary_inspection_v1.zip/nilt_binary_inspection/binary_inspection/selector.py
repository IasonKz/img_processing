from __future__ import annotations

from itertools import combinations
from pathlib import Path

import numpy as np
from scipy.optimize import minimize
from scipy.special import expit

from .common import (LOG, choose_device, file_sha256, object_hash, output_dir, read_csv, read_json,
                     write_csv, write_json)
from .metrics import classification_metrics
from .patchcore import score_patchcore, patchcore_signature
from .splitting import read_manifest, verify_manifest
from .training import score_checkpoint, training_signature


def fit_monotone_sigmoid(features: np.ndarray, labels: np.ndarray, l2: float = 0.001) -> dict:
    """Regularized Platt/stacking model. Positive slopes preserve risk ordering.

    Fit only on held-out calibration data, never predictions on base TRAIN.
    """
    x = np.asarray(features, dtype=np.float64)
    if x.ndim == 1:
        x = x[:, None]
    y = np.asarray(labels, dtype=np.float64)
    if len(np.unique(y)) != 2 or not np.isfinite(x).all():
        raise ValueError("Calibration requires finite scores and both labels")
    mean, std = x.mean(0), np.maximum(x.std(0), 1e-6)
    z = (x - mean) / std
    initial = np.r_[np.ones(x.shape[1]) / x.shape[1], 0.0]
    def objective(v):
        logits = z @ v[:-1] + v[-1]
        loss = np.mean(np.logaddexp(0, logits) - y * logits) + 0.5 * l2 * np.sum(v[:-1] ** 2)
        error = expit(logits) - y
        grad = np.r_[z.T @ error / len(y) + l2 * v[:-1], error.mean()]
        return loss, grad
    fitted = minimize(objective, initial, jac=True, method="L-BFGS-B",
                      bounds=[(0, None)] * x.shape[1] + [(None, None)], options={"maxiter": 1000})
    if not fitted.success or not np.isfinite(fitted.x).all():
        raise RuntimeError(f"Calibration optimization failed: {fitted.message}")
    return {"mean": mean.tolist(), "std": std.tolist(), "weights": fitted.x[:-1].tolist(),
            "bias": float(fitted.x[-1]), "l2": l2}


def apply_sigmoid(features: np.ndarray, fitted: dict) -> np.ndarray:
    x = np.asarray(features, float)
    if x.ndim == 1:
        x = x[:, None]
    return expit(((x - fitted["mean"]) / fitted["std"]) @ np.asarray(fitted["weights"]) + fitted["bias"])


def combine(candidate: dict, logits: dict[str, np.ndarray], calibrators: dict) -> tuple[np.ndarray, np.ndarray]:
    members = candidate["members"]
    member_scores = np.column_stack([apply_sigmoid(logits[m], calibrators[m]) for m in members])
    kind = candidate["kind"]
    if kind == "single":
        score = member_scores[:, 0]
    elif kind == "mean_pair":
        score = member_scores.mean(1)
    elif kind == "max_pair":
        score = member_scores.max(1)
    elif kind == "stack_pair":
        score = apply_sigmoid(np.column_stack([logits[m] for m in members]), candidate["stacker"])
    else:
        raise ValueError(f"Unsupported fusion: {kind}")
    return score, member_scores


def eligibility(scores, members, settings: dict, anomaly=None, anomaly_threshold=None):
    scores, members = np.asarray(scores), np.asarray(members)
    finite = np.isfinite(scores) & np.isfinite(members).all(1)
    disagreement = members.max(1) - members.min(1)
    agreement = disagreement <= float(settings["disagreement_threshold"])
    can_pass = finite & agreement & (members.max(1) <= float(settings["pass_member_cap"]))
    can_fail = finite & agreement & (members.min(1) >= float(settings["fail_member_floor"]))
    if settings.get("use_anomaly_veto"):
        if anomaly is None or anomaly_threshold is None:
            raise ValueError("Selected policy requires PatchCore; missing scores must never disable its veto")
        can_pass &= np.isfinite(anomaly) & (np.asarray(anomaly) <= anomaly_threshold)
        # Missing anomaly inference means incomplete inspection, even for FAIL.
        can_fail &= np.isfinite(anomaly)
    return can_pass, can_fail, disagreement


def decide(scores, members, policy: dict, anomaly=None) -> tuple[np.ndarray, list[str]]:
    can_pass, can_fail, disagreement = eligibility(scores, members, policy["settings"], anomaly, policy.get("anomaly_threshold"))
    d = np.full(len(scores), "REVIEW", dtype=object)
    if policy.get("pass_threshold") is not None:
        d[can_pass & (scores < policy["pass_threshold"])] = "PASS"
    if policy.get("fail_threshold") is not None:
        d[can_fail & (scores >= policy["fail_threshold"])] = "FAIL"
    reasons = []
    for i, decision in enumerate(d):
        if decision == "PASS":
            reasons.append("LOW_RISK_ALL_REQUIRED_CHECKS_CLEAR")
        elif decision == "FAIL":
            reasons.append("HIGH_SUPERVISED_RISK_WITH_AGREEMENT")
        elif not np.isfinite(scores[i]) or not np.isfinite(members[i]).all():
            reasons.append("MISSING_OR_INVALID_MODEL_SCORE")
        elif policy["settings"].get("use_anomaly_veto") and (anomaly is None or not np.isfinite(anomaly[i])):
            reasons.append("MISSING_ANOMALY_SCORE")
        elif policy["settings"].get("use_anomaly_veto") and anomaly[i] > policy["anomaly_threshold"]:
            reasons.append("HIGH_ANOMALY_REVIEW_NOT_PROVEN_DEFECT")
        elif disagreement[i] > policy["settings"]["disagreement_threshold"]:
            reasons.append("MODEL_DISAGREEMENT")
        elif policy.get("disabled"):
            reasons.append("NO_VALID_AUTOMATIC_POLICY")
        else:
            reasons.append("AMBIGUOUS_OR_MEMBER_GUARD")
    return d, reasons


def fit_thresholds(labels, scores, members, settings: dict, anomaly=None, anomaly_threshold=None) -> dict:
    y = np.asarray(labels, int)
    scores = np.asarray(scores, float)
    eligible_pass, eligible_fail, _ = eligibility(scores, members, settings, anomaly, anomaly_threshold)
    n_bad, n_good = int((y == 1).sum()), int((y == 0).sum())
    if not n_bad or not n_good:
        raise ValueError("Selection needs GOOD and BAD examples")
    pass_threshold, fail_threshold = None, None
    best_good = 0
    # Group equal scores together: ties must never be split by row order.
    for score in np.unique(scores[eligible_pass]):
        accepted = eligible_pass & (scores <= score)
        bad_pass, good_pass = int(((y == 1) & accepted).sum()), int(((y == 0) & accepted).sum())
        if bad_pass / n_bad <= settings["max_bad_escape_rate"] and good_pass > best_good:
            pass_threshold = float(np.nextafter(score, np.inf))
            best_good = good_pass
    best_bad = 0
    for score in np.unique(scores[eligible_fail])[::-1]:
        if pass_threshold is not None and score < pass_threshold:
            continue
        rejected = eligible_fail & (scores >= score)
        good_fail, bad_fail = int(((y == 0) & rejected).sum()), int(((y == 1) & rejected).sum())
        if good_fail / n_good <= settings["max_good_false_fail_rate"] and bad_fail > best_bad:
            fail_threshold = float(score)
            best_bad = bad_fail
    return {"pass_threshold": pass_threshold, "fail_threshold": fail_threshold,
            "settings": settings, "anomaly_threshold": anomaly_threshold, "disabled": False}


def _score_development(cfg: dict, rows: list[dict], models: dict, include_anomaly: bool) -> dict:
    folder = output_dir(cfg)
    stage_rows = [r for r in rows if r["split"] in {"calibration", "selection"}]
    device = choose_device(cfg)
    output = {"sample_ids": [r["sample_id"] for r in stage_rows], "models": {}}
    for name, artifact in models.items():
        path = folder / artifact["path"]
        cache_path = folder / "scores" / f"{name}_development.json"
        cache_key = object_hash({"checkpoint": artifact["sha256"], "ids": output["sample_ids"],
                                 "data": read_json(folder / "dataset.json")["signature"]})
        if cache_path.exists() and read_json(cache_path).get("key") == cache_key:
            score = read_json(cache_path)["scores"]
        else:
            LOG.info("Scoring calibration and selection sets: %s", name)
            score, meta = score_checkpoint(path, stage_rows, cfg, device)
            if meta["dataset_signature"] != read_json(folder / "dataset.json")["signature"]:
                raise ValueError("Classifier trained on a different manifest")
            write_json(cache_path, {"key": cache_key, "scores": score})
        output["models"][name] = score
    if include_anomaly:
        path = folder / "models" / "patchcore" / "best.pt"
        cache_path = folder / "scores" / "patchcore_development.json"
        key = object_hash({"checkpoint": file_sha256(path), "ids": output["sample_ids"]})
        if cache_path.exists() and read_json(cache_path).get("key") == key:
            output["anomaly"] = read_json(cache_path)["scores"]
        else:
            output["anomaly"] = score_patchcore(path, stage_rows, cfg, device)
            write_json(cache_path, {"key": key, "scores": output["anomaly"]})
    return output


def select_pipeline(cfg: dict) -> dict:
    verify_manifest(cfg)
    folder = output_dir(cfg)
    rows = read_manifest(cfg)
    settings = dict(cfg["selector"])
    if settings["use_anomaly_veto"] and not cfg["anomaly"]["enabled"]:
        raise ValueError("Set selector.use_anomaly_veto: false explicitly when anomaly.enabled: false")
    dataset = read_json(folder / "dataset.json")
    models = {}
    for name, spec in cfg["models"].items():
        if not spec.get("enabled", True):
            continue
        path = folder / "models" / name / "best.pt"
        status = read_json(folder / "models" / name / "status.json")
        if not status.get("completed"):
            raise ValueError(f"Model {name} did not finish. Train it or explicitly disable it in a new run")
        if status.get("training_signature") != training_signature(cfg, spec, dataset["signature"]):
            raise ValueError(f"Training configuration changed for {name}. Use a new output_dir")
        digest = file_sha256(path)
        if digest != status["checkpoint_sha256"]:
            raise ValueError("Checkpoint changed since training")
        models[name] = {"path": path.relative_to(folder).as_posix(), "sha256": digest}
    anomaly_artifact = None
    if settings["use_anomaly_veto"]:
        path = folder / "models" / "patchcore" / "best.pt"
        status = read_json(path.parent / "status.json")
        if not status.get("completed") or file_sha256(path) != status["checkpoint_sha256"]:
            raise ValueError("PatchCore is missing, unfinished or changed")
        if status.get("signature") != patchcore_signature(cfg, dataset["signature"]):
            raise ValueError("PatchCore configuration changed. Use a new output_dir")
        anomaly_artifact = {"path": path.relative_to(folder).as_posix(), "sha256": file_sha256(path)}
    dataset = read_json(folder / "dataset.json")
    request_signature = object_hash({"dataset": dataset["signature"], "models": models, "selector": settings,
                                     "anomaly": anomaly_artifact, "anomaly_quantile": cfg["anomaly"]["good_quantile_for_veto"]})
    selector_path = folder / "selector.json"
    if selector_path.exists():
        existing = read_json(selector_path)
        if existing["request_signature"] == request_signature:
            LOG.info("Reusing frozen selector")
            return existing
        if (folder / "evaluation" / "test_report.json").exists():
            raise ValueError("TEST already evaluated. Do not retune against it. Use a new run and genuinely fresh confirmation test")
    scored = _score_development(cfg, rows, models, bool(anomaly_artifact))
    calibration = [r for r in rows if r["split"] == "calibration"]
    selection = [r for r in rows if r["split"] == "selection"]
    yc = np.array([r["label"] for r in calibration])
    ys = np.array([r["label"] for r in selection])
    zc = {m: np.array([scored["models"][m][r["sample_id"]] for r in calibration]) for m in models}
    zs = {m: np.array([scored["models"][m][r["sample_id"]] for r in selection]) for m in models}
    calibrators = {m: fit_monotone_sigmoid(zc[m], yc) for m in models}
    anomaly_threshold, anomaly_s = None, None
    if anomaly_artifact:
        normal = [scored["anomaly"][r["sample_id"]] for r in calibration if r["label"] == 0]
        quantile = float(cfg["anomaly"]["good_quantile_for_veto"])
        if not 0 < quantile < 1:
            raise ValueError("good_quantile_for_veto must be between 0 and 1")
        anomaly_threshold = float(np.quantile(normal, quantile, method="higher"))
        anomaly_s = np.array([scored["anomaly"][r["sample_id"]] for r in selection])
    candidates = []
    kinds = settings["candidates"]
    if not set(kinds) <= {"single", "mean_pair", "max_pair", "stack_pair"}:
        raise ValueError("Unknown selector candidate type")
    if "single" in kinds:
        candidates.extend({"name": m, "kind": "single", "members": [m]} for m in models)
    for a, b in combinations(models, 2):
        for kind in ("mean_pair", "max_pair", "stack_pair"):
            if kind not in kinds:
                continue
            candidate = {"name": f"{kind}__{a}__{b}", "kind": kind, "members": [a, b]}
            if kind == "stack_pair":
                candidate["stacker"] = fit_monotone_sigmoid(np.column_stack((zc[a], zc[b])), yc, float(settings["stacking_l2"]))
            candidates.append(candidate)
    if not candidates:
        raise ValueError("No model-selection candidates configured")
    leaderboard = []
    for candidate in candidates:
        score, members = combine(candidate, zs, calibrators)
        policy = fit_thresholds(ys, score, members, settings, anomaly_s, anomaly_threshold)
        decisions, _ = decide(score, members, policy, anomaly_s)
        stats = classification_metrics(ys, score, decisions, [r["group_id"] for r in selection], settings["confidence_level"])
        feasible = (stats["good_pass_rate"] or 0) >= settings["min_selection_good_pass_rate"]
        if settings["reject_weak_candidates"]:
            feasible &= (stats["roc_auc"] or 0) > 0.5
        candidate["policy"], candidate["selection_metrics"], candidate["feasible"] = policy, stats, bool(feasible)
        leaderboard.append({"candidate": candidate["name"], "kind": candidate["kind"], "members": " + ".join(candidate["members"]),
                            "number_of_classifiers": len(candidate["members"]), "feasible": bool(feasible),
                            "pass_threshold": policy["pass_threshold"], "fail_threshold": policy["fail_threshold"], **stats})
    feasible = [c for c in candidates if c["feasible"]]
    if feasible:
        maximum = max(c["selection_metrics"]["correct_automatic_fraction"] for c in feasible)
        pool = [c for c in feasible if c["selection_metrics"]["correct_automatic_fraction"] >= maximum - settings["complexity_tolerance"]]
        winner = min(pool, key=lambda c: (len(c["members"]), c["selection_metrics"]["bad_pass"],
                                         c["selection_metrics"]["good_fail"], -c["selection_metrics"]["correct_automatic_fraction"]))
        status = "EXPERIMENTAL_SELECTED"
    else:
        winner = max(candidates, key=lambda c: c["selection_metrics"]["correct_automatic_fraction"])
        winner["policy"] = {**winner["policy"], "pass_threshold": None, "fail_threshold": None, "disabled": True}
        status = "NO_FEASIBLE_POLICY_ALL_REVIEW"
        LOG.warning("No candidate meets the minimum automation requirement. Selector remains REVIEW-only")
    result = {"schema_version": 1, "task": cfg["project"]["task"], "class_map": {"good": 0, "bad": 1},
              "dataset_signature": dataset["signature"], "request_signature": request_signature, "status": status,
              "chosen": winner, "calibrators": {m: calibrators[m] for m in winner["members"]},
              "models": {m: models[m] for m in winner["members"]}, "anomaly": anomaly_artifact,
              "input_data_cfg": cfg["data"], "preprocessing": cfg["preprocessing"],
              "audit_warnings": dataset["audit"]["warnings"], "grouping": dataset["audit"]["grouping"],
              "production_release_authorized": False,
              "score_semantics": "BAD risk score; calibration is conditional on the calibration sample distribution. Not a production failure probability guarantee",
              "selection_warning": "Thresholds and candidate were optimized on selection, so its reported bounds are descriptive, not post-selection guarantees. Final test is untouched"}
    write_csv(folder / "selector_leaderboard.csv", leaderboard)
    write_json(folder / "selector_candidates.json", candidates)
    write_json(folder / "calibration_models.json", calibrators)
    development_rows = []
    for r in calibration + selection:
        development_rows.append({"sample_id": r["sample_id"], "relpath": r["relpath"], "label": r["label"], "split": r["split"],
                                 **{f"{m}_logit": scored["models"][m][r["sample_id"]] for m in models},
                                 **({"anomaly_score": scored["anomaly"][r["sample_id"]]} if anomaly_artifact else {})})
    write_csv(folder / "development_scores.csv", development_rows)
    write_json(selector_path, result)
    LOG.info("Chosen selector: %s | status %s", winner["name"], status)
    return result
