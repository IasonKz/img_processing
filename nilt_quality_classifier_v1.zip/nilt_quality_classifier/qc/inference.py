from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import pandas as pd
import torch

from .config import get, resolve_path
from .data import (
    DEFAULT_UNIT_ID_REGEX,
    ImageRecord,
    build_labeled_loader,
    build_transforms,
    build_unlabeled_loader,
    scan_unlabeled_folder,
)
from .engine import predict_labeled, predict_unlabeled
from .metrics import add_review_decisions, predictions_frame
from .models import model_from_checkpoint
from .utils import choose_device, make_run_dir, setup_logging, write_json


def checkpoint_threshold(checkpoint: dict[str, Any], override: float | None = None) -> float:
    if override is not None:
        return float(override)
    threshold = checkpoint.get("threshold_bad")
    if threshold is None:
        raise ValueError(
            "The checkpoint has no tuned threshold. Set inference.threshold_bad in the config."
        )
    return float(threshold)


def predict_labeled_records(
    *,
    checkpoint_path: str | Path,
    records: Sequence[ImageRecord],
    device_request: str = "auto",
    batch_size: int = 16,
    num_workers: int = 4,
    mixed_precision: bool = True,
    threshold_override: float | None = None,
    show_progress: bool = True,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    device = choose_device(device_request)
    model, checkpoint = model_from_checkpoint(checkpoint_path, device=device)
    data_config = checkpoint.get("data_config", {}) or {}
    transform = build_transforms(data_config, training=False)
    loader = build_labeled_loader(
        records,
        transform=transform,
        image_loading_config=data_config.get("image_loading", {}) or {},
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=device.type == "cuda",
        persistent_workers=num_workers > 0,
        sampler_config={"enabled": False},
        seed=42,
    )
    output = predict_labeled(
        model,
        loader,
        device=device,
        criterion=None,
        use_amp=bool(mixed_precision and device.type == "cuda"),
        show_progress=show_progress,
    )
    threshold = checkpoint_threshold(checkpoint, threshold_override)
    frame = predictions_frame(
        paths=output["paths"],
        unit_ids=output["unit_ids"],
        unit_ids_raw=output["unit_ids_raw"],
        sources=output["sources"],
        splits=output["splits"],
        p_bad=output["p_bad"],
        threshold=threshold,
        y_true=output["y_true"],
    )
    return frame, checkpoint


def _copy_predictions(
    frame: pd.DataFrame,
    *,
    input_root: Path,
    output_root: Path,
) -> dict[str, int]:
    counts: dict[str, int] = {"good": 0, "bad": 0, "review": 0}
    for _, row in frame.iterrows():
        decision = str(row["decision"]).lower()
        source = Path(str(row["path"]))
        try:
            relative = source.resolve().relative_to(input_root.resolve())
        except ValueError:
            relative = Path(str(row.get("relative_path", source.name)))
        destination = output_root / f"predicted_{decision}" / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            destination = destination.with_name(
                f"{destination.stem}__copy{destination.suffix}"
            )
        shutil.copy2(source, destination)
        counts.setdefault(decision, 0)
        counts[decision] += 1
    return counts


def _copy_uncertain(
    frame: pd.DataFrame,
    *,
    output_root: Path,
    reference_threshold: float,
    top_n: int,
) -> int:
    if top_n <= 0:
        return 0
    subset = frame.copy()
    subset["distance_to_threshold"] = (subset["p_bad"] - reference_threshold).abs()
    subset = subset.nsmallest(min(top_n, len(subset)), "distance_to_threshold")
    uncertain_dir = output_root / "uncertain_cases"
    count = 0
    for _, row in subset.iterrows():
        source = Path(str(row["path"]))
        destination = uncertain_dir / f"{row['p_bad']:.5f}__{source.name}"
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            destination = destination.with_name(
                f"{destination.stem}__copy{destination.suffix}"
            )
        shutil.copy2(source, destination)
        count += 1
    subset.to_csv(uncertain_dir / "uncertain_cases.csv", index=False, encoding="utf-8")
    return count


def run_folder_prediction(config: dict[str, Any]) -> dict[str, Any]:
    checkpoint_path = resolve_path(
        get(config, "inference.checkpoint"), config=config, must_exist=True
    )
    input_root = resolve_path(
        get(config, "inference.input_folder"), config=config, must_exist=True
    )
    if checkpoint_path is None or input_root is None:
        raise ValueError("Set inference.checkpoint and inference.input_folder")

    output_value = get(config, "inference.output_folder")
    if output_value:
        output_root = resolve_path(output_value, config=config)
        assert output_root is not None
        output_root.mkdir(parents=True, exist_ok=True)
    else:
        base = resolve_path(get(config, "project.output_root", "predictions"), config=config)
        assert base is not None
        output_root = make_run_dir(base, str(get(config, "project.name", "prediction")))

    logger = setup_logging(output_root / "prediction.log")
    device = choose_device(str(get(config, "inference.device", "auto")))
    model, checkpoint = model_from_checkpoint(checkpoint_path, device=device)
    data_config = checkpoint.get("data_config", {}) or {}

    records = scan_unlabeled_folder(
        input_root,
        recursive=bool(get(config, "inference.recursive", True)),
        extensions=get(config, "inference.image_extensions", data_config.get("image_extensions")),
        unit_id_regex=str(
            get(config, "inference.unit_id_regex", data_config.get("unit_id_regex", DEFAULT_UNIT_ID_REGEX))
        ),
    )
    transform = build_transforms(data_config, training=False)
    batch_size = int(get(config, "inference.batch_size", 16))
    num_workers = int(get(config, "inference.num_workers", 4))
    loader = build_unlabeled_loader(
        records,
        transform=transform,
        image_loading_config=data_config.get("image_loading", {}) or {},
        batch_size=batch_size,
        num_workers=num_workers,
        pin_memory=device.type == "cuda",
        persistent_workers=num_workers > 0,
    )
    output = predict_unlabeled(
        model,
        loader,
        device=device,
        use_amp=bool(get(config, "inference.mixed_precision", True) and device.type == "cuda"),
        show_progress=bool(get(config, "inference.show_progress", True)),
    )
    threshold_override = get(config, "inference.threshold_bad")
    threshold = checkpoint_threshold(
        checkpoint,
        None if threshold_override is None else float(threshold_override),
    )

    p_bad = np.asarray(output["p_bad"], dtype=np.float64)
    frame = pd.DataFrame(
        {
            "path": output["paths"],
            "relative_path": output["relative_paths"],
            "filename": [Path(path).name for path in output["paths"]],
            "unit_id": output["unit_ids"],
            "unit_id_raw": output["unit_ids_raw"],
            "p_good": 1.0 - p_bad,
            "p_bad": p_bad,
            "threshold_bad": threshold,
            "predicted_label": np.where(p_bad >= threshold, "bad", "good"),
        }
    )

    review = get(config, "inference.review", {}) or {}
    review_enabled = bool(review.get("enabled", False))
    bad_min = review.get("bad_min_p_bad")
    if bad_min is None:
        bad_min = threshold
    frame = add_review_decisions(
        frame,
        enabled=review_enabled,
        good_max_p_bad=(
            None if review.get("good_max_p_bad") is None else float(review["good_max_p_bad"])
        ),
        bad_min_p_bad=float(bad_min),
    )
    frame["checkpoint"] = str(checkpoint_path)
    frame.to_csv(output_root / "predictions.csv", index=False, encoding="utf-8")

    copy_counts = {"good": 0, "bad": 0, "review": 0}
    if bool(get(config, "inference.copy_images", True)):
        copy_counts = _copy_predictions(
            frame,
            input_root=input_root,
            output_root=output_root,
        )

    uncertain_count = _copy_uncertain(
        frame,
        output_root=output_root,
        reference_threshold=threshold,
        top_n=int(get(config, "inference.export_uncertain_top_n", 100)),
    )
    summary = {
        "checkpoint": str(checkpoint_path),
        "input_folder": str(input_root),
        "output_folder": str(output_root),
        "number_of_images": len(frame),
        "threshold_bad": threshold,
        "review_enabled": review_enabled,
        "decision_counts": frame["decision"].value_counts(dropna=False).to_dict(),
        "copied_counts": copy_counts,
        "uncertain_exported": uncertain_count,
    }
    write_json(summary, output_root / "prediction_summary.json")
    logger.info("Predicted %d images. Results: %s", len(frame), output_root / "predictions.csv")
    return summary
