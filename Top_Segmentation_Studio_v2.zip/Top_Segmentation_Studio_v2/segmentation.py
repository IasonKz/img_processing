"""Command interface for local top-view defect annotation and pilot segmentation."""
from __future__ import annotations
import argparse
import importlib.metadata
import importlib.util
import json
from pathlib import Path
import sys


def parser():
    root = argparse.ArgumentParser(description='Top-view defect annotation and lightweight segmentation.')
    root.add_argument('--version', action='version', version='top-segmentation-studio 2.0.0')
    commands = root.add_subparsers(dest='command', required=True)
    for command, help_text in [('studio', 'Open the integrated annotation and training studio.'),
                               ('init', 'Import native RGB working copies from the configured input folder.'),
                               ('annotate', 'Open the local annotation application.'),
                               ('status', 'Show annotation counts and training readiness.'),
                               ('dataset', 'Export a frozen dataset of approved annotations only.'),
                               ('train', 'Train a small U-Net on approved annotations.')]:
        p = commands.add_parser(command, help=help_text)
        p.add_argument('--config', required=True, type=Path)
        if command in ('annotate', 'studio'):
            p.add_argument('--no-browser', action='store_true')
            p.add_argument('--port', type=int)
        elif command == 'dataset':
            p.add_argument('--output', required=True, type=Path)
        elif command == 'train':
            p.add_argument('--init-checkpoint', type=Path)
    p = commands.add_parser('predict', help='Predict masks and overlays for a folder of new top-view images.')
    p.add_argument('--checkpoint', required=True, type=Path)
    p.add_argument('--input', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    p.add_argument('--device', choices=['cpu', 'cuda', 'auto'], default='cpu')
    p = commands.add_parser('demo', help='Create a small synthetic input and a ready-to-edit configuration.')
    p.add_argument('--output', required=True, type=Path)
    p = commands.add_parser('doctor', help='Check locally installed dependencies.')
    p.add_argument('--training', action='store_true')
    return root


def doctor(training=False):
    names = {'numpy': 'numpy', 'Pillow': 'PIL', 'scipy': 'scipy', 'PyYAML': 'yaml'}
    if training:
        names['torch'] = 'torch'
    dependencies = {}
    ready = True
    for distribution, module in names.items():
        try:
            __import__(module)
            dependencies[distribution] = {'version': importlib.metadata.version(distribution), 'status': 'available'}
        except (ImportError, OSError, RuntimeError) as exc:
            dependencies[distribution] = {'status': 'unavailable', 'error': str(exc)}
            ready = False
    print(json.dumps({'ready': ready, 'training_requested': training, 'dependencies': dependencies}, indent=2))
    return 0 if ready else 3


def demo(output):
    import numpy as np
    from PIL import Image, ImageDraw
    import yaml
    from topseg.common import atomic_json
    output = Path(output).resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError('Demo output must be new or empty.')
    images = output / 'input'
    images.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(718)
    for i in range(12):
        height, width = 640, 720
        base = np.clip(rng.normal(165, 1.2, (height, width, 3)), 0, 255).astype(np.uint8)
        image = Image.fromarray(base)
        draw = ImageDraw.Draw(image)
        draw.rectangle((38, 25, 682, 615), fill=(132 + i, 132 + i, 132 + i), outline=(185, 185, 185), width=4)
        draw.polygon([(235, 140), (485, 140), (540, 195), (540, 445),
                      (485, 500), (235, 500), (180, 445), (180, 195)],
                     fill=(78 + i, 80 + i, 82 + i), outline=(210, 210, 210), width=3)
        if i % 4 != 0:
            offset = int(rng.integers(-45, 45))
            draw.ellipse((335 + offset, 285, 345 + offset, 295), fill=(215, 215, 215))
            draw.line((90, 120 + i * 9, 118, 130 + i * 9), fill=(32, 32, 32), width=4)
        image.save(images / f'unit_{i:03d}_top.png')
    config = {'name': 'synthetic_top_demo', 'input_dir': './input', 'project_dir': './annotations',
              'output_dir': './results', 'group_regex': r'(unit_\d+)',
              'training': {'epochs': 3, 'image_size': 256, 'base_channels': 8, 'min_images': 5}}
    (output / 'project.yaml').write_text(yaml.safe_dump(config, sort_keys=False), encoding='utf-8')
    atomic_json(output / 'demo_info.json', {'synthetic': True, 'images': 12, 'purpose': 'Annotation and software demonstration only; not defect-detection performance evidence.'})
    print(f'Demo created: {output}\nOpen: python segmentation.py annotate --config "{output / "project.yaml"}"')
    return 0


def run(args):
    if args.command == 'doctor':
        return doctor(args.training)
    if args.command == 'demo':
        return demo(args.output)
    if args.command == 'predict':
        from topseg.inference import predict
        result = predict(args.checkpoint, args.input, args.output, args.device)
        print(json.dumps(result, indent=2, default=str))
        return 0
    from topseg.common import load_config
    from topseg.project import Project
    cfg = load_config(args.config)
    if args.command == 'studio':
        from topseg.studio_server import serve_studio
        if args.port is not None: cfg['annotation']['port'] = args.port
        serve_studio(cfg,args.config,not args.no_browser)
        return 0
    if args.command == 'train':
        from topseg.training import train
        result = train(cfg, init_checkpoint=args.init_checkpoint)
        print(f'Training result: {result}')
        return 0
    project = Project(cfg)
    if args.command == 'init':
        report = project.import_images()
        print(json.dumps(report, indent=2))
        return 2 if report['invalid'] else 0
    if args.command == 'annotate':
        if not project.items():
            report = project.import_images()
            print(json.dumps(report, indent=2))
        if not project.items():
            raise ValueError('No valid imported images. Check input_dir and import_report.json.')
        if args.port is not None:
            if not 0 <= args.port <= 65535:
                raise ValueError('Port must be in [0,65535].')
            cfg['annotation']['port'] = args.port
        from topseg.server import serve
        serve(cfg, open_browser=not args.no_browser)
        return 0
    if args.command == 'status':
        items = project.items()
        counts = {key: sum(row['status'] == key for row in items) for key in ('unannotated', 'draft', 'approved', 'rejected')}
        counts.update(total_images=len(items), approved_clean=sum(row['status'] == 'approved' and row['clean'] for row in items),
                      approved_groups=len({row['group'] for row in items if row['status'] == 'approved'}))
        print(json.dumps({'project_dir': str(project.root), 'counts': counts,
                          'grouping': 'regex' if cfg['group_regex'] else 'pixel_identity',
                          'note': 'Training performs final data, grouping and class-support validation.'}, indent=2))
        return 0
    if args.command == 'dataset':
        print(f'Frozen dataset: {project.snapshot(args.output)}')
        return 0
    raise ValueError('Unsupported command.')


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        return run(args)
    except KeyboardInterrupt:
        print('\nStopped by operator.', file=sys.stderr)
        return 130
    except (ValueError, KeyError, FileNotFoundError, FileExistsError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        return 2
    except (RuntimeError, ImportError, OSError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        return 3


if __name__ == '__main__':
    raise SystemExit(main())
