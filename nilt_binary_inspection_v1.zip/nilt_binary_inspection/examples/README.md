# Παράδειγμα metadata — δεν είναι πραγματικό dataset

Το `metadata_example.csv` δείχνει μόνο τη μορφή. Τα filenames είναι φανταστικά.
Χρησιμοποίησε το `audit/metadata_template.csv` του δικού σου run και συμπλήρωσε
μία εγγραφή για **κάθε** εικόνα. Το relpath είναι σε σχέση με τον γονικό φάκελο
των good και bad και περιλαμβάνει `good/` ή `bad/`.

Τα start / post του ίδιου φυσικού unit πρέπει να έχουν κοινό unit_id / tray_id.
Η επανάληψη του U001 σε διαφορετικό tray επιτρέπεται: το unit group περιλαμβάνει
το διαθέσιμο batch και tray ως namespace.

Άφησε το split κενό σε **όλες** τις γραμμές για αυτόματο grouped splitting.
Για δικό σου διαχωρισμό, συμπλήρωσε **όλες** τις γραμμές με μία από τις τιμές
`train`, `tune`, `calibration`, `selection`, `test`. Τα μέλη κάθε group πρέπει
να έχουν την ίδια τιμή. Το παράδειγμα των πέντε γραμμών δεν επαρκεί για training.

Ρύθμιση, στο task YAML:

```yaml
paths:
  metadata_csv: 'D:/AI_Data/top_metadata.csv'
data:
  group_by: unit_id
split:
  require_physical_groups: true
```

Για αυστηρό held-out tray πείραμα, χρησιμοποίησε `group_by: tray_id` και αρκετά
ανεξάρτητα trays. Μόνο τρία trays δεν αρκούν για πέντε μη επικαλυπτόμενα tray-level
σύνολα. Μην τα υποκαταστήσεις με duplicate εικόνες για να περάσει ο έλεγχος.
