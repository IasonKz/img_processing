# Contributing

## Language and documentation

Use English for interface text, documentation, comments, examples and release notes. Describe product behavior, operating steps and validation evidence in neutral technical language. Keep examples independent of individual users, workstation names and personal filesystem paths.

Document configuration fields and operator controls using their actual names. Use relative paths for bundled project configurations and explain their resolution base. Separate configured acceptance targets, synthetic test results and measured production performance. Preserve upstream licenses and attribution notices.

## Compatibility

Changes to classification, ROI detection and segmentation must preserve physical-unit grouping, held-out evaluation roles, native image depth and artifact provenance. Annotation migrations must retain existing revisions. Changes to portable exports must include the corresponding inference dependencies and metadata.

## Validation

Use the existing tests relevant to the change. Representative ROI and segmentation checks are:

```bash
python -m pytest -q tests/segmentation tests/test_roi_geometry.py tests/test_roi_context.py tests/test_roi_project.py tests/test_roi_learning.py tests/test_roi_dashboard.py tests/test_roi_classification.py tests/test_roi_segmentation.py tests/test_workspace_studio.py tests/test_v6_image_depth.py tests/test_dashboard_preprocessing.py tests/test_untagged_preparation.py
node tests/test_roi_ui.cjs
python -m pytest -q tests/test_deployment_review.py tests/test_workspace_studio.py
```

Browser checks require Playwright and Chromium; their executable and Python environment can be selected through `STUDIO_BROWSER_EXECUTABLE` and `STUDIO_PYTHON`. See [ROI segmentation verification](docs/ROI_SEGMENTATION_VERIFICATION.md) for scope and limitations.

`node tests/browser_deployment_review.cjs /tmp/deployment-review-evidence` verifies the quality-review dashboard against real local APIs and managed workers with synthetic model outputs. It covers unit browsing, evidence categories, keyboard navigation, report ZIPs and responsive layouts.

`python tests/smoke_classification_dashboard.py --output NEW_OUTPUT --weights-dir WEIGHTS_CACHE` runs actual pretrained ResNet18 CPU searches through the dashboard API for laptop/workstation profiles and both profile/custom modes. Add `--allow-download` only when verified public weights may be downloaded. The output directory must be new. See [classification Optuna verification](docs/CLASSIFICATION_OPTUNA_FIX_VERIFICATION.md).

Update `RELEASE_FILES.sha256` when release files change. Generate source archives from a committed Git revision so that virtual environments, caches, model weights, local datasets and runtime results are excluded. Validate archive integrity before distribution. Preserve experiment and dataset backups separately from source releases.
