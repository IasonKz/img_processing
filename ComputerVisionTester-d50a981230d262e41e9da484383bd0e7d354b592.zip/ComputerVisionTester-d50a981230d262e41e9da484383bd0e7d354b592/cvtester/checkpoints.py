"""Load verified safetensors checkpoints with architecture-specific compatibility."""


def load_safetensors_checkpoint(model, path, spec):
    from safetensors.torch import load_file

    state = load_file(str(path))
    if spec.family == "Swin V2":
        from timm.models.swin_transformer_v2 import checkpoint_filter_fn

        # Derived attention buffers are rebuilt by timm rather than restored.
        state = checkpoint_filter_fn(state, model)
    return model.load_state_dict(state, strict=True)
