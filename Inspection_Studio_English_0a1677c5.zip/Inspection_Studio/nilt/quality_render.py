"""Portable, evidence-only quality-report rendering and safe export.

The renderer has no network, JavaScript, model inference or dataset mutation.
It displays the snapshot produced by ``quality.build_quality_report``.
"""
from __future__ import annotations

import base64
import csv
import hashlib
import html
import json
import math
import os
from pathlib import Path
import shutil
import tempfile
from typing import Any


BLUE = "#0078b8"
TEAL = "#1c8178"
RED = "#bd4941"
AMBER = "#b87c17"
GRAY = "#7d8d9b"
PALETTE = (BLUE, TEAL, AMBER, RED, GRAY, "#74648a")


def _esc(value: Any) -> str:
    return html.escape(str(value), quote=True)


def _json(value: Any, *, indent: int | None = None) -> str:
    return json.dumps(value, ensure_ascii=False, allow_nan=False, indent=indent)


def _number(value: Any) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value) if math.isfinite(value) else None


def _text(value: Any) -> str:
    if value is None or value == "":
        return "Not recorded"
    if isinstance(value, bool):
        return "Yes" if value else "No"
    if isinstance(value, (dict, list)):
        return _json(value, indent=2)
    return str(value)


def _rate(value: Any) -> str:
    number = _number(value)
    return f"{number:.1%}" if number is not None else "Not available"


def _metric(value: Any) -> str:
    number = _number(value)
    return f"{number:.4f}" if number is not None else "Not available"


def _mapping(value: Any) -> dict:
    return value if isinstance(value, dict) else {}


def _rows(value: Any) -> list[dict]:
    return [row for row in value if isinstance(row, dict)] if isinstance(value, list) else []


def _table(rows: list[dict], columns: list[tuple[str, str]], *, limit: int | None = None) -> str:
    if not rows:
        return '<p class="empty">No recorded evidence for this section.</p>'
    visible = rows if limit is None else rows[:limit]
    header = "".join(f'<th scope="col">{_esc(title)}</th>' for _, title in columns)
    body = "".join("<tr>" + "".join(f"<td>{_esc(_text(row.get(key)))}</td>" for key, _ in columns) + "</tr>"
                   for row in visible)
    note = (f'<p class="note">Showing {len(visible):,} of {len(rows):,} rows. All rows are included in the CSV and JSON exports.</p>'
            if len(visible) < len(rows) else "")
    return f'<div class="table-scroll"><table><thead><tr>{header}</tr></thead><tbody>{body}</tbody></table></div>{note}'


def _details(title: str, value: Any) -> str:
    return f'<details><summary>{_esc(title)}</summary><pre>{_esc(_json(value, indent=2))}</pre></details>'


def _svg_open(title: str, width: int, height: int, description: str = "") -> str:
    return (f'<svg xmlns="http://www.w3.org/2000/svg" role="img" viewBox="0 0 {width} {height}">'
            f'<title>{_esc(title)}</title><desc>{_esc(description)}</desc>')


def _bar_chart(title: str, entries: list[tuple[str, Any]], *, rate: bool = False,
               color: str = BLUE, description: str = "") -> str:
    """One explicit scale; missing measurements have no bar, never zero bars."""
    if not entries:
        return '<p class="empty">No chart data recorded.</p>'
    total = len(entries)
    entries = entries[:40]
    width, left, right, row_height = 920, 330, 105, 34
    height = 62 + row_height * len(entries)
    finite = [_number(value) for _, value in entries]
    maximum = 1.0 if rate else max([value for value in finite if value is not None] + [1.0])
    span = width - left - right
    output = [_svg_open(title, width, height, description)]
    for tick in range(5):
        value = maximum * tick / 4
        x = left + span * tick / 4
        label = f"{value:.0%}" if rate else f"{value:g}"
        output.append(f'<line x1="{x:g}" x2="{x:g}" y1="20" y2="{height-22}" stroke="#e2e8ed"/>'
                      f'<text x="{x:g}" y="14" text-anchor="middle" class="axis">{label}</text>')
    for index, ((label, value), numeric) in enumerate(zip(entries, finite)):
        y = 32 + row_height * index
        shown_label = label if len(label) <= 48 else label[:45] + "…"
        output.append(f'<text x="{left-14}" y="{y+15}" text-anchor="end" class="label"><title>{_esc(label)}</title>{_esc(shown_label)}</text>')
        if numeric is None or numeric < 0:
            output.append(f'<text x="{left+6}" y="{y+15}" class="axis">Not available</text>')
            continue
        bar_width = min(numeric / maximum, 1) * span
        result = _rate(numeric) if rate else f"{numeric:g}"
        output.append(f'<rect x="{left}" y="{y}" width="{bar_width:g}" height="22" rx="3" fill="{color}"/>'
                      f'<text x="{left+span+12}" y="{y+15}" class="label">{_esc(result)}</text>')
    output.append("</svg>")
    note = (f'<p class="note">Chart preview: first 40 of {total:,} groups. The corresponding table and data exports retain every group.</p>'
            if total > 40 else "")
    return '<div class="chart">' + "".join(output) + "</div>" + note


def _confusion_chart(metrics: dict, title: str, *, allow_binary: bool = False) -> str:
    confusion = _mapping(metrics.get("confusion"))
    matrix = confusion.get("matrix")
    if not (isinstance(matrix, list) and len(matrix) == 2 and all(isinstance(row, list) and len(row) == 3 for row in matrix)):
        keys = (("bad_detected_TP", "bad_passed_as_good_FN", "bad_sent_to_review"),
                ("good_rejected_as_bad_FP", "good_accepted_TN", "good_sent_to_review"))
        if not all(key in metrics for row in keys for key in row):
            binary = (("bad_detected_TP", "bad_passed_as_good_FN"), ("good_rejected_as_bad_FP", "good_accepted_TN"))
            if allow_binary and all(key in metrics for row in binary for key in row):
                keys = binary
            else:
                return '<p class="empty">Confusion counts were not recorded.</p>'
        matrix = [[metrics[key] for key in row] for row in keys]
    values = [_number(value) for row in matrix for value in row]
    if any(value is None or value < 0 for value in values):
        return '<p class="empty">Confusion counts are unavailable or invalid.</p>'
    maximum = max(values + [1])
    labels = ("Predicted bad", "Predicted good", "Human review")[:len(matrix[0])]
    width = 620 if len(labels) == 3 else 475
    output = [_svg_open(title, width, 248, "Rows: manual bad, manual good. Columns: " + ", ".join(labels) + ".")]
    for col, label in enumerate(labels):
        output.append(f'<text x="{215+col*155}" y="27" text-anchor="middle" class="label">{label}</text>')
    for row, label in enumerate(("Manual bad", "Manual good")):
        output.append(f'<text x="125" y="{99+row*84}" text-anchor="end" class="label">{label}</text>')
        for col in range(len(labels)):
            value = float(matrix[row][col])
            opacity = .08 + .7 * value / maximum
            output.append(f'<rect x="{140+155*col}" y="{43+84*row}" width="149" height="78" rx="5" fill="{BLUE}" fill-opacity="{opacity:.3f}"/>'
                          f'<text x="{215+155*col}" y="{91+84*row}" text-anchor="middle" font-size="25" fill="{"#fff" if opacity > .52 else "#193647"}">{value:g}</text>')
    output.append(f'<text x="{width//2}" y="233" text-anchor="middle" class="axis">{"Unknown labels and unavailable decisions are reported separately." if len(labels) == 3 else "Recorded binary decision counts."}</text></svg>')
    return '<div class="chart">' + "".join(output) + "</div>"


def _history_number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (ValueError, TypeError):
        return None
    return number if math.isfinite(number) else None


def _learning_curve(history: list[dict], title: str, fields: tuple[tuple[str, str, str], ...], *, unit_interval: bool = False) -> str:
    series = []
    for field, label, color in fields:
        points = []
        for row in history:
            epoch, value = _history_number(row.get("epoch")), _history_number(row.get(field))
            if epoch is not None and epoch >= 0 and value is not None and value >= 0:
                points.append((epoch, value))
        if points:
            series.append((label, color, sorted(points)))
    if not series:
        return '<p class="empty">No numeric epoch history was recorded for this chart.</p>'
    all_points = [point for _, _, points in series for point in points]
    low_x, high_x = min(x for x, _ in all_points), max(x for x, _ in all_points)
    high_y = 1.0 if unit_interval else max(max(y for _, y in all_points) * 1.08, .01)
    width, height, left, right, top, bottom = 650, 280, 58, 20, 26, 48
    span_x, span_y = width - left - right, height - top - bottom
    def coords(x, y):
        px = left + span_x * ((x-low_x) / (high_x-low_x) if high_x > low_x else .5)
        py = top + span_y * (1 - min(y / high_y, 1))
        return px, py
    output = [_svg_open(title, width, height, "Recorded per-epoch measurements. Missing values are not inferred.")]
    for tick in range(5):
        y = top + span_y * tick / 4
        value = high_y * (1 - tick / 4)
        output.append(f'<line x1="{left}" x2="{width-right}" y1="{y:g}" y2="{y:g}" stroke="#e2e8ed"/>'
                      f'<text x="{left-8}" y="{y+4:g}" text-anchor="end" class="axis">{value:.3g}</text>')
        x = left + span_x * tick / 4
        epoch = low_x + (high_x - low_x) * tick / 4
        output.append(f'<text x="{x:g}" y="{height-bottom+18}" text-anchor="middle" class="axis">{epoch:g}</text>')
    output.append(f'<text x="{left+span_x/2:g}" y="{height-5}" text-anchor="middle" class="axis">Recorded epoch</text>')
    for index, (label, color, points) in enumerate(series):
        selected = points if len(points) <= 2000 else points[::max(1, math.ceil(len(points)/2000))] + [points[-1]]
        path = " ".join(f"{x:.2f},{y:.2f}" for x, y in (coords(epoch, value) for epoch, value in selected))
        output.append(f'<polyline points="{path}" fill="none" stroke="{color}" stroke-width="2.5"/>')
        if len(selected) <= 50:
            for epoch, value in selected:
                x, y = coords(epoch, value)
                output.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="2.5" fill="{color}"><title>{_esc(label)}; epoch {epoch:g}: {value:.6g}</title></circle>')
        legend_x = left + index * 235
        output.append(f'<line x1="{legend_x}" x2="{legend_x+20}" y1="12" y2="12" stroke="{color}" stroke-width="3"/>'
                      f'<text x="{legend_x+27}" y="16" class="label">{_esc(label)}</text>')
    output.append('</svg>')
    note = '<p class="note">Chart points are subsampled for long histories; complete recorded history remains in report.json.</p>' if any(len(p) > 2000 for _, _, p in series) else ''
    return '<div class="chart">' + "".join(output) + '</div>' + note


def _metrics_rows(metrics: dict) -> list[dict]:
    definitions = [
        ("n_total", "Input image records", False), ("n_labeled", "Known manual labels", False),
        ("n_bad", "Manual bad", False), ("n_good", "Manual good", False),
        ("n_automatic", "Automatic good/bad decisions", False), ("n_review", "Human-review decisions", False),
        ("n_unavailable", "Unavailable decisions", False),
        ("bad_escape_rate", "Bad accepted / all manual bad", True),
        ("good_reject_rate", "Good rejected / all manual good", True),
        ("review_rate", "Review / all input records", True),
        ("decision_coverage", "Automatic decisions / all input records", True),
        ("selective_accuracy", "Accuracy on automatically decided labeled images only", True),
        ("accepted_contamination", "Manual bad / labeled accepted images", True),
    ]
    return [{"metric": label, "value": _rate(metrics.get(key)) if rate else metrics.get(key)}
            for key, label, rate in definitions]


def _flatten(prefix: str, value: Any) -> dict:
    """Flatten nested mappings for stable tabular exports; arrays remain JSON."""
    if isinstance(value, dict):
        output = {}
        for key, child in value.items():
            name = f"{prefix}.{key}" if prefix else str(key)
            output.update(_flatten(name, child))
        return output
    return {prefix: _json(value) if isinstance(value, list) else value}


def _model_rows(report: dict) -> list[dict]:
    result = []
    for run in _rows(report.get("runs")):
        for model in _rows(run.get("models")):
            progress = _mapping(model.get("progress"))
            result.append({"run_id": run.get("id"), "task": run.get("task"),
                           "name": model.get("name"), "path": model.get("path"),
                           "completed": bool(model.get("completed")), "status": progress.get("status"),
                           "validation_ap": progress.get("best_val_pr_auc_bad"),
                           "validation_ap_source": "progress.best_val_pr_auc_bad" if "best_val_pr_auc_bad" in progress else None,
                           "current_epoch": progress.get("current_epoch"), "best_epoch": progress.get("best_epoch"),
                           "elapsed_seconds": progress.get("elapsed_seconds"),
                           "parameters": model.get("parameters"), "checkpoint_hashes": model.get("checkpoint_hashes")})
    return result


def _recorded_metric_rows(report: dict) -> list[dict]:
    """Keep every selection/test measurement distinct, with no pooled averages."""
    result = []
    for run in _rows(report.get("runs")):
        selection = _mapping(run.get("selection"))
        for candidate in _rows(selection.get("candidates")):
            metrics = _mapping(candidate.get("selection_metrics"))
            result.append({"run_id": run.get("id"), "task": run.get("task"), "partition": "selection",
                           "candidate": candidate.get("name"), "threshold": candidate.get("threshold"),
                           "AP_bad": metrics.get("pr_auc_bad"), "bad_escape_rate": metrics.get("bad_escape_rate"),
                           "good_reject_rate": metrics.get("good_reject_rate"), "metrics": metrics})
        evaluations = [("final_test", "final test", _mapping(run.get("final_test")))] + [
            (str(item.get("id", "unknown")), "external evaluation", item) for item in _rows(run.get("external_evaluations"))]
        for evaluation_id, partition, evaluation in evaluations:
            if not evaluation.get("available"):
                continue
            summary = _mapping(evaluation.get("summary"))
            result.append({"run_id": run.get("id"), "task": run.get("task"), "partition": partition, "evaluation_id": evaluation_id,
                           "candidate": summary.get("name", summary.get("candidate")),
                           "threshold": summary.get("threshold"), "AP_bad": _mapping(summary.get("metrics")).get("pr_auc_bad"),
                           "metrics": summary})
    return result


def _recorded_evaluation_rows(report: dict, key: str) -> list[dict]:
    result = []
    for run in _rows(report.get("runs")):
        evaluations = [("final_test", _mapping(run.get("final_test")))] + [
            (str(item.get("id", "unknown")), item) for item in _rows(run.get("external_evaluations"))]
        for evaluation_id, evaluation in evaluations:
            if not evaluation.get("available"):
                continue
            for row in _rows(evaluation.get(key)):
                result.append({**row, "run_id": run.get("id"), "task": run.get("task"),
                               "evaluation_id": evaluation_id, "evaluation_role": evaluation.get("role", row.get("evaluation_role"))})
    return result


def _evaluation_trays(evaluation: dict) -> str:
    """Historical test rows stay separate from later inspection-session rows."""
    rows = []
    for tray in _rows(evaluation.get("per_tray")):
        metrics, counts = _mapping(tray.get("metrics_reference")), _mapping(tray.get("counts"))
        rows.append({"tray": tray.get("tray"), "task": tray.get("task"), "units": tray.get("n_units"),
                     "records": counts.get("total", metrics.get("n_total")), "labeled": metrics.get("n_labeled"),
                     "manual_bad": metrics.get("n_bad"), "manual_good": metrics.get("n_good"),
                     "predicted_bad": counts.get("bad"), "predicted_good": counts.get("good"),
                     "review": counts.get("review"), "no_decision": counts.get("no_decision"),
                     "escape_count": metrics.get("bad_passed_as_good_FN"), "reject_count": metrics.get("good_rejected_as_bad_FP"),
                     "escape": _rate(metrics.get("bad_escape_rate")), "reject": _rate(metrics.get("good_reject_rate")),
                     "labeled_coverage": _rate(metrics.get("labeled_decision_coverage")),
                     "accuracy": _rate(metrics.get("selective_accuracy"))})
    text = ('<h4>Recorded test predictions by tray</h4><p class="note">This table uses previously saved evaluation predictions and their original manual labels. '
            'It is not pooled with inspection sessions. Unknown references and unavailable decisions cannot establish correctness; '
            'coverage is reported alongside selective accuracy.</p>')
    text += _table(rows, [("tray", "Tray"), ("task", "Task"), ("records", "Records"), ("units", "Units"),
                         ("labeled", "Manual labels"), ("manual_bad", "Manual bad"), ("manual_good", "Manual good"),
                         ("escape_count", "Bad accepted"), ("reject_count", "Good rejected"),
                         ("escape", "Bad escape"), ("reject", "Good reject"), ("review", "Review"),
                         ("no_decision", "Unavailable"), ("labeled_coverage", "Labeled auto coverage"), ("accuracy", "Selective accuracy")])
    text += ('<p class="note">Full rows are exported in recorded_evaluation_predictions.csv and recorded_evaluation_trays.csv, '
             'with run and evaluation identifiers retained. No additional model evaluation was performed.</p>')
    if evaluation.get("note"):
        text += f'<p class="note">{_esc(evaluation["note"])}</p>'
    return text


def _tray_status(tray: dict) -> str:
    if tray.get("quality_status"):
        return str(tray["quality_status"])
    metrics = _mapping(tray.get("metrics_reference"))
    if (_number(metrics.get("n_unavailable")) or 0) > 0:
        return "Incomplete decisions — investigate"
    if (_number(metrics.get("n_review")) or 0) > 0:
        return "Human review required"
    counts = _mapping(tray.get("counts"))
    predicted = _mapping(counts.get("predictions", counts.get("prediction")))
    bad = predicted.get("bad", counts.get("bad"))
    if (_number(bad) or 0) > 0:
        return "Model flagged bad images"
    if bad == 0 and (_number(metrics.get("n_automatic")) or 0) > 0:
        return "No model-flagged bad images"
    return "See recorded decisions"


CSS = """
:root{color-scheme:light}*{box-sizing:border-box}body{margin:0;background:#eef3f6;color:#183041;font:14px/1.55 system-ui,-apple-system,Segoe UI,sans-serif}
main{max-width:1340px;margin:auto;padding:32px}header{border-top:5px solid #0078b8;background:white;padding:30px 34px;display:flex;gap:28px;align-items:center}
.brand{width:155px;height:auto;flex-shrink:0}h1{font-size:31px;letter-spacing:-.6px;margin:0 0 7px}h2{font-size:22px;margin:0 0 14px}h3{font-size:17px;margin:24px 0 10px}h4{margin:16px 0 8px}
p{margin:9px 0}.eyebrow{text-transform:uppercase;letter-spacing:.15em;font-size:11px;font-weight:700;color:#617988}.meta,.note,.axis,.empty{color:#5e7484}.note{font-size:12px}.empty{padding:18px;background:#f5f8fa}
nav{display:flex;gap:8px;flex-wrap:wrap;padding:16px 0}a{color:#006da5}nav a{background:white;padding:8px 13px;border:1px solid #d7e2e9;text-decoration:none;border-radius:4px}
section{padding:27px 30px;margin:16px 0;background:white;border:1px solid #dbe4ea;border-radius:7px;break-inside:avoid-page}.subsection{border-top:1px solid #dbe4ea;margin-top:25px;padding-top:18px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:24px}.notice{border-left:4px solid #b87c17;padding:13px 18px;background:#fff8e8}.warning{color:#923e26}.table-scroll{overflow:auto}table{border-collapse:collapse;width:100%;font-size:12px}
th,td{padding:10px 11px;border-bottom:1px solid #e1e8ed;text-align:left;vertical-align:top;white-space:pre-wrap;overflow-wrap:anywhere}th{color:#3f5b6d;background:#f0f5f8;font-weight:650}tr:nth-child(even) td{background:#fafcfd}
details{margin:12px 0;border:1px solid #dbe4ea;border-radius:4px;padding:10px 13px}summary{cursor:pointer;font-weight:600}pre{font:11px/1.5 ui-monospace,SFMono-Regular,Consolas,monospace;white-space:pre-wrap;overflow-wrap:anywhere;max-height:620px;overflow:auto}
.chart{padding:12px 0}.chart svg{width:100%;height:auto;display:block}.label{font:12px system-ui,sans-serif;fill:#274253}.axis{font:11px system-ui,sans-serif;fill:#6b7e8a}.stat-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.stat{padding:18px;background:#f0f6fa;border-radius:5px}.stat b{font-size:27px;display:block;color:#0078b8}.stat span{color:#587081;font-size:12px}
footer{padding:20px 0;color:#627989;font-size:12px}.path{font-family:ui-monospace,Consolas,monospace;font-size:12px}.notes{white-space:pre-wrap;overflow-wrap:anywhere}
@media(max-width:850px){main{padding:14px}.grid{grid-template-columns:1fr}.stat-grid{grid-template-columns:1fr 1fr}header{padding:22px;flex-direction:column;align-items:flex-start}section{padding:20px}h1{font-size:25px}}
@media print{body{background:white;font-size:11px}main{max-width:none;padding:0}header,section{border-radius:0;box-shadow:none}nav{display:none}section{padding:16px 0;border:0;border-top:1px solid #ccd8e0;break-inside:auto}.grid{grid-template-columns:1fr 1fr}.table-scroll{overflow:visible}table{font-size:9px}th,td{padding:5px}.chart{break-inside:avoid}details pre{max-height:none;overflow:visible}footer{border-top:1px solid #ccd8e0}a{color:inherit;text-decoration:none}}
"""


def render_quality_report(report: dict) -> str:
    """Return a self-contained HTML document without embedded executable data."""
    if not isinstance(report, dict):
        raise TypeError("The quality report must be a mapping.")
    # Reject invalid snapshots before producing plausible-looking output.
    _json(report)
    title = str(report.get("title") or "Inspection quality report")
    runs, sessions = _rows(report.get("runs")), _rows(report.get("sessions"))
    trays, images = _rows(report.get("trays")), _rows(report.get("images"))
    models = _model_rows(report)
    asset = Path(__file__).parent / "ui" / "NIL-logo.png"
    logo = ('<img class="brand" alt="NIL Technology" src="data:image/png;base64,' +
            base64.b64encode(asset.read_bytes()).decode("ascii") + '">' if asset.is_file() else "")
    body = [f'<header>{logo}<div><div class="eyebrow">Inspection Studio · Evidence record</div><h1>{_esc(title)}</h1>'
            f'<div class="meta">Generated UTC: {_esc(_text(report.get("generated_utc")))}</div></div></header>',
            '<nav><a href="#overview">Overview</a><a href="#training">Training provenance</a><a href="#models">Model performance</a>'
            '<a href="#sessions">Inspection sessions</a><a href="#trays">Tray comparison</a><a href="#comparison">Matched comparison</a>'
            '<a href="#images">Image records</a><a href="#traceability">Traceability</a></nav>',
            '<section id="overview"><h2>Scope and interpretation</h2>',
            '<div class="notice">This is a recorded-evidence report, not a physical quality certificate or a production qualification. '
            'A model decision is an estimate. Human review is an abstention, not a correct automatic decision. '
            'Scores are not calibrated probabilities unless separately demonstrated. Training, selection and final-test measurements are kept distinct.</div>',
            '<div class="stat-grid">' + "".join(f'<div class="stat"><b>{count:,}</b><span>{label}</span></div>' for count, label in
                ((len(runs), "Recorded training runs"), (len(sessions), "Inspection sessions"), (len(trays), "Session / tray groups"),
                 (len(images), "Image prediction records"))) + '</div>',
            '<p class="note">Image prediction records may describe the same physical image in several sessions. Counts are not pooled as independent samples.</p>']
    if report.get("notes"):
        body.append(f'<h3>Operator notes</h3><p class="notes">{_esc(report["notes"])}</p>')
    body.append(_details("Report summary", report.get("summary", {})))
    issues = _rows(report.get("issues"))
    if issues:
        body.append('<h3>Evidence limitations and warnings</h3>' + _table(issues, [("severity", "Severity"), ("path", "Artifact"), ("message", "Finding")]))
    body.append('</section><section id="training"><h2>Training provenance</h2><p>Recorded dataset membership, tray exposure, configuration and checkpoints. Missing records are shown as missing, not reconstructed from filenames.</p>')
    for run in runs:
        dataset = _mapping(run.get("dataset"))
        body.append(f'<div class="subsection"><h3>{_esc(_text(run.get("id")))} · {_esc(_text(run.get("task")))}</h3>'
                    f'<p class="path">{_esc(_text(run.get("path")))}</p>')
        body.append(_table([{"status": run.get("status"), "fingerprint": dataset.get("fingerprint"),
                            "n_images": dataset.get("n_images"), "n_units": dataset.get("n_units"),
                            "manifest_sha256": dataset.get("manifest_sha256")}],
                           [("status", "Run status"), ("n_images", "Images"), ("n_units", "Units"), ("fingerprint", "Dataset fingerprint"), ("manifest_sha256", "Manifest SHA-256")]))
        splits = dataset.get("split_counts")
        if isinstance(splits, dict):
            entries = [(str(key), value if _number(value) is not None else _mapping(value).get("images", _mapping(value).get("total", _mapping(value).get("n_images")))) for key, value in splits.items()]
            body.append('<h4>Recorded split sizes</h4>' + _bar_chart("Recorded split sizes", entries))
        training_trays = _rows(dataset.get("tray_counts"))
        if training_trays:
            body.append('<h4>Dataset membership by tray</h4>' + _bar_chart("Dataset images by tray", [(str(row.get("tray", "unknown")), row.get("images")) for row in training_trays]))
            body.append(_table(training_trays, [("tray", "Tray"), ("images", "Images"), ("good", "Manual good"), ("bad", "Manual bad"),
                                               ("unknown_label", "Unknown labels"), ("units", "Physical units"), ("splits", "Split membership")]))
        body.append(_details("Split and tray membership", {"split_counts": dataset.get("split_counts"), "tray_counts": dataset.get("tray_counts")}))
        body.append('<p class="note">Exact recorded image membership, labels, split assignments and fingerprints are retained in dataset_membership.csv and report.json. Source images are not copied.</p>')
        body.append(_details("Training configuration", run.get("config", {})))
        body.append(_details("Training model records and learning histories", run.get("models", [])))
        body.append('</div>')
    if not runs:
        body.append('<p class="empty">No training run was included. No claim about unseen trays can be established from inspection sessions alone.</p>')
    body.append('</section><section id="models"><h2>Model performance</h2><p>Validation AP describes score ranking during development, not acceptance accuracy. Comparisons across different datasets or splits are descriptive only.</p>')
    if models:
        entries = [(f"{row['run_id']} / {row['name']}", row.get("validation_ap")) for row in models]
        body.append('<h3>Recorded validation AP (bad)</h3>' + _bar_chart("Validation AP by recorded model", entries, rate=True))
        body.append(_table(models, [("run_id", "Run"), ("name", "Model / trial"), ("completed", "Completed"), ("status", "Status"),
                                   ("validation_ap", "Recorded validation AP"), ("best_epoch", "Best epoch"), ("elapsed_seconds", "Training seconds")]))
    histories = [(run, model) for run in runs for model in _rows(run.get("models")) if _rows(model.get("history"))]
    if histories:
        body.append('<h3>Recorded learning curves</h3><p>Training and validation loss may use different class weighting; their absolute values need not match. These are development curves, not final-test measurements.</p>')
        body.append(f'<p class="note">Showing {min(len(histories), 12)} of {len(histories)} model/trial histories in source order. All recorded histories are retained in report.json and the training evidence panels.</p>')
        for run, model in histories[:12]:
            label = f"{run.get('id', 'Run')} / {model.get('name', 'Model')}"
            body.append(f'<div class="subsection"><h4>{_esc(label)}</h4><div class="grid"><div>' +
                        _learning_curve(_rows(model.get("history")), label + " validation AP", (("val_pr_auc_bad", "Validation AP (bad)", BLUE),), unit_interval=True) +
                        '</div><div>' + _learning_curve(_rows(model.get("history")), label + " training and validation loss",
                            (("train_loss", "Training loss", BLUE), ("val_loss", "Validation loss", AMBER))) + '</div></div></div>')
    measurements = _recorded_metric_rows(report)
    body.append('<h3>Selection and final-test evidence</h3><p>Final-test data is displayed only when a stored test result already exists. Generating this report does not run another test or select a winner.</p>')
    body.append(_table(measurements, [("run_id", "Run"), ("partition", "Partition"), ("evaluation_id", "Evaluation ID"), ("candidate", "Candidate"), ("threshold", "Threshold"), ("AP_bad", "AP (bad)")]))
    for run in runs:
        final = _mapping(run.get("final_test"))
        summary = _mapping(final.get("summary"))
        metrics = _mapping(summary.get("metrics"))
        if final.get("available") and metrics:
            body.append(f'<div class="subsection"><h3>{_esc(_text(run.get("id")))} · Recorded final test</h3>'
                        f'<p>Candidate: {_esc(_text(summary.get("candidate", summary.get("name"))))} · Threshold: {_esc(_text(summary.get("threshold")))} · AP (bad): {_esc(_metric(metrics.get("pr_auc_bad")))}</p>')
            body.append('<div class="grid"><div>' + _confusion_chart(metrics, "Previously recorded final-test confusion", allow_binary=True) +
                        '</div><div>' + _bar_chart("Recorded final-test operating metrics", [
                            ("Bad escape / manual bad", metrics.get("bad_escape_rate")),
                            ("Good reject / manual good", metrics.get("good_reject_rate")),
                            ("Bad recall", metrics.get("bad_recall", metrics.get("bad_detection_rate"))),
                            ("Accuracy (recorded definition)", metrics.get("accuracy"))], rate=True) + '</div></div>')
            body.append(_table([{key: summary.get(key) for key in ("empirical_target_met", "statistical_target_supported", "test_used_in_previous_generation", "evaluation_role")}],
                               [("empirical_target_met", "Empirical targets met"), ("statistical_target_supported", "Recorded statistical support"),
                                ("test_used_in_previous_generation", "Test reused in previous generation"), ("evaluation_role", "Evaluation role")]))
            body.append('<p class="note">The report displays stored results and qualification flags without independently verifying their assumptions. Repeatedly inspected test data is not fresh validation.</p></div>')
        if final.get("available"):
            body.append(f'<div class="subsection"><h3>{_esc(_text(run.get("id")))} · Final-test tray evidence</h3>' + _evaluation_trays(final) + '</div>')
        for evaluation in _rows(run.get("external_evaluations")):
            if not evaluation.get("available"):
                continue
            external_summary = _mapping(evaluation.get("summary"))
            external_metrics = _mapping(external_summary.get("metrics"))
            body.append(f'<div class="subsection"><h3>{_esc(_text(run.get("id")))} · Recorded external evaluation · {_esc(_text(evaluation.get("id")))}</h3>'
                        f'<p>Task: {_esc(_text(run.get("task")))} · Candidate: {_esc(_text(external_summary.get("candidate", external_summary.get("name"))))} · '
                        f'Threshold: {_esc(_text(external_summary.get("threshold")))} · AP (bad): {_esc(_metric(external_metrics.get("pr_auc_bad")))}</p>')
            if external_metrics:
                body.append('<div class="grid"><div>' + _confusion_chart(external_metrics, "Previously recorded external-evaluation confusion", allow_binary=True) +
                            '</div><div>' + _bar_chart("Recorded external-evaluation operating metrics", [
                                ("Bad escape / manual bad", external_metrics.get("bad_escape_rate")),
                                ("Good reject / manual good", external_metrics.get("good_reject_rate")),
                                ("Bad recall", external_metrics.get("bad_recall", external_metrics.get("bad_detection_rate"))),
                                ("Accuracy (recorded definition)", external_metrics.get("accuracy"))], rate=True) + '</div></div>')
            body.append(_evaluation_trays(evaluation))
            body.append(_details("Stored external-evaluation summary and qualification flags", external_summary))
            body.append('</div>')
        body.append(_details(f"{run.get('id', 'Run')}: selected candidate and stored final-test results", {"selection": run.get("selection"), "final_test": run.get("final_test")}))
    body.append('</section><section id="sessions"><h2>Inspection sessions and manual-label comparison</h2><p>Original dataset labels and later operator judgments are separate reference sources. Reviewing a model prediction is not an independent blinded evaluation.</p>')
    for session in sessions:
        reference = _mapping(session.get("metrics_reference"))
        operator = _mapping(session.get("metrics_operator"))
        body.append(f'<div class="subsection"><h3>{_esc(_text(session.get("id")))} · {_esc(_text(session.get("task")))}</h3>'
                    f'<p>Status: {_esc(_text(session.get("status")))} · Provisional model: {_esc(_text(session.get("provisional")))}</p>')
        body.append('<div class="grid"><div><h4>Original dataset labels</h4>' + _confusion_chart(reference, "Original manual labels versus model decisions") +
                    _table(_metrics_rows(reference), [("metric", "Metric / denominator"), ("value", "Value")]) + '</div><div><h4>Operator-labeled subset</h4>' +
                    _confusion_chart(operator, "Operator judgments versus model decisions") +
                    _table(_metrics_rows(operator), [("metric", "Metric / denominator"), ("value", "Value")]) + '</div></div>')
        body.append(_details("Model, decision policy, input counts and prior training exposure", {key: session.get(key) for key in
                    ("path", "created_utc", "model_identity", "decision_identity", "metadata", "counts", "training_exposure")}))
        body.append('</div>')
    if not sessions:
        body.append('<p class="empty">No inspection sessions were included.</p>')
    body.append('</section><section id="trays"><h2>Tray-by-tray quality assessment</h2><p>These are model-based image decisions per session and tray, not a physical tray pass certificate. Error rates use known manual labels; unlabeled images cannot establish model correctness.</p>')
    tray_table = []
    for tray in trays:
        met = _mapping(tray.get("metrics_reference"))
        tray_table.append({"session_id": tray.get("session_id"), "task": tray.get("task"), "tray": tray.get("tray"), "assessment": _tray_status(tray),
                           "n_units": tray.get("n_units"), "n_total": met.get("n_total"), "n_labeled": met.get("n_labeled"),
                           "escape": _rate(met.get("bad_escape_rate")), "reject": _rate(met.get("good_reject_rate")),
                           "review": _rate(met.get("review_rate")), "coverage": _rate(met.get("decision_coverage")),
                           "training_exposure": tray.get("training_exposure")})
    body.append(_table(tray_table, [("session_id", "Session"), ("task", "Task"), ("tray", "Tray"), ("assessment", "Model-based assessment"),
                                  ("n_total", "Records"), ("n_labeled", "Manual labels"), ("escape", "Bad escape"), ("reject", "Good reject"),
                                  ("review", "Review"), ("coverage", "Coverage"), ("training_exposure", "Prior exposure")]))
    labels = [f"{row.get('session_id', '')} / {row.get('task', '')} / {row.get('tray', '')}" for row in trays]
    if trays:
        body.append('<h3>Tray image counts</h3>' + _bar_chart("Image records per session and tray", [(label, _mapping(row.get("metrics_reference")).get("n_total")) for label, row in zip(labels, trays)]))
        body.append('<div class="grid">')
        for key, label, color in (("bad_escape_rate", "Bad escape / manual bad", RED), ("good_reject_rate", "Good reject / manual good", AMBER),
                                  ("review_rate", "Human review / all records", BLUE), ("decision_coverage", "Automatic coverage / all records", TEAL)):
            body.append(f'<div><h3>{_esc(label)}</h3>' + _bar_chart(label, [(name, _mapping(row.get("metrics_reference")).get(key)) for name, row in zip(labels, trays)], rate=True, color=color) + '</div>')
        body.append('</div>')
    body.append('</section><section id="comparison"><h2>Matched-image model comparison</h2><p>Disagreement is meaningful only on matched image content and the same task. Models agreeing does not establish correctness. Label conflicts and unmatched images must not be silently discarded.</p>')
    comparisons = _rows(report.get("comparisons"))
    body.append(_table([{key: value for key, value in row.items() if not isinstance(value, (dict, list))} for row in comparisons],
                       [(key, key.replace("_", " ").capitalize()) for key in dict.fromkeys(key for row in comparisons for key, value in row.items() if not isinstance(value, (dict, list)))]))
    comparison_entries = []
    for row in comparisons:
        first = row.get("session_a", row.get("left_session_id", row.get("left", "A")))
        second = row.get("session_b", row.get("right_session_id", row.get("right", "B")))
        comparison_entries.append((f"{first} vs {second}", row.get("disagreement_rate")))
    if comparison_entries:
        body.append('<h3>Disagreement on matched decisions</h3>' + _bar_chart("Matched decision disagreement", comparison_entries, rate=True, color=AMBER))
    body.append(_details("Complete matched comparison evidence", comparisons))
    body.append('</section><section id="images"><h2>Image-level traceability</h2><p>All prediction records are supplied in images.csv and report.json. Original labels, later operator labels, model decisions and their disagreement flags remain distinct.</p>')
    body.append(_table(images, [("session_id", "Session"), ("task", "Task"), ("tray", "Tray"), ("unit_id", "Unit"), ("relative_path", "Image"),
                               ("reference_label", "Original manual label"), ("operator_label", "Operator label"), ("prediction", "Model decision"),
                               ("reference_mismatch", "Dataset-label mismatch"), ("operator_mismatch", "Operator mismatch"),
                               ("review_reason", "Review reason"), ("score", "Recorded score"), ("status", "Input status")], limit=250))
    body.append('</section><section id="traceability"><h2>Audit trail and definitions</h2><p>Source hashes identify the evidence files read when this snapshot was created. They do not certify label correctness or prevent later edits. The export manifest hashes every delivered report artifact except the manifest itself.</p>')
    body.append(_table(_rows(report.get("artifacts")), [("root", "Source root"), ("path", "Source artifact"), ("kind", "Kind"), ("status", "Status"), ("bytes", "Bytes"), ("sha256", "SHA-256")]))
    body.append(_details("Metric and provenance definitions", report.get("definitions", {})))
    body.append('<p>For a PDF, open report.html in a browser and select Print → Save as PDF. Expand the required configuration and evidence panels before printing. CSV files contain the full row sets and are the preferred format for detailed investigation.</p></section>')
    body.append('<footer>NIL Technology · Inspection Studio · Local report. No remote assets, analytics or external services are used by this document.</footer>')
    csp = "default-src 'none'; img-src data:; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'"
    return ('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            f'<meta http-equiv="Content-Security-Policy" content="{_esc(csp)}"><title>{_esc(title)}</title><style>{CSS}</style></head><body><main>' +
            "".join(body) + '</main></body></html>')


def _csv_cell(value: Any) -> Any:
    """Prevent spreadsheet formula evaluation while keeping UTF-8 names intact."""
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        value = _json(value)
    if isinstance(value, str):
        # Excel and LibreOffice can ignore initial whitespace before a formula.
        if value.lstrip(" \t\r\n").startswith(("=", "+", "-", "@")) or value.startswith(("\t", "\r", "\n")):
            return "'" + value
    return value


def _write_csv(path: Path, records: list[dict]) -> None:
    flat = [_flatten("", row) for row in records]
    columns = list(dict.fromkeys(key for row in flat for key in row)) or ["status"]
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=[_csv_cell(column) for column in columns])
        writer.writeheader()
        for row in flat:
            writer.writerow({_csv_cell(key): _csv_cell(value) for key, value in row.items()})


def export_quality_report(report: dict, output: Path) -> dict:
    """Publish a complete snapshot into a new or empty directory, never merge.

    Rendering and serialization finish in an owned sibling staging directory.
    An existing empty directory may be removed immediately before the rename;
    non-empty outputs and symlinks are always rejected without deleting data.
    """
    output = Path(output).expanduser()
    if output.is_symlink():
        raise ValueError("Choose a real report directory, not a symbolic link.")
    if output.exists() and (not output.is_dir() or any(output.iterdir())):
        raise FileExistsError("Choose a new or empty quality-report output directory.")
    payload = _json(report, indent=2)
    page = render_quality_report(report)
    output.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=f".{output.name}-report-", dir=output.parent))
    try:
        (staging / "report.html").write_text(page, encoding="utf-8")
        (staging / "report.json").write_text(payload + "\n", encoding="utf-8")
        csv_sets = {"images": _rows(report.get("images")), "trays": _rows(report.get("trays")),
                    "dataset_membership": [row for run in _rows(report.get("runs")) for row in _rows(run.get("dataset_membership"))],
                    "recorded_evaluation_predictions": _recorded_evaluation_rows(report, "prediction_rows"),
                    "recorded_evaluation_trays": _recorded_evaluation_rows(report, "per_tray"),
                    "sessions": _rows(report.get("sessions")), "models": _model_rows(report),
                    "measurements": _recorded_metric_rows(report), "comparisons": _rows(report.get("comparisons")),
                    "disagreements": _rows(report.get("disagreements")), "artifacts": _rows(report.get("artifacts")),
                    "issues": _rows(report.get("issues"))}
        for name, rows in csv_sets.items():
            _write_csv(staging / f"{name}.csv", rows)
        files = []
        for path in sorted(staging.iterdir()):
            files.append({"name": path.name, "bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
        manifest = {"format": "inspection_quality_export_v1", "report_format": report.get("format"),
                    "generated_utc": report.get("generated_utc"), "files": files,
                    "note": "Source evidence is recorded in report.json. This manifest does not hash itself. No source images are copied."}
        (staging / "export_manifest.json").write_text(_json(manifest, indent=2) + "\n", encoding="utf-8")
        # Recheck after all potentially expensive rendering and writes.
        if output.is_symlink():
            raise ValueError("The report output became a symbolic link; export was not published.")
        if output.exists():
            if not output.is_dir() or any(output.iterdir()):
                raise FileExistsError("The report output is no longer empty; nothing was overwritten.")
            output.rmdir()  # Only an explicitly validated empty output directory.
        os.rename(staging, output)
    finally:
        if staging.exists():
            shutil.rmtree(staging)
    root = output.resolve()
    return {"directory": str(root), "html": str(root / "report.html"), "json": str(root / "report.json"),
            "csv_files": [str(root / f"{name}.csv") for name in csv_sets],
            "manifest": str(root / "export_manifest.json"), "files": files}
