"""Preset routing and editable contracts; no Intel hardware is required."""
from pathlib import Path
import tempfile
import unittest

import yaml

from inspection import build_parser
from nilt.common import PROFILES, load_config, load_project, validate_config
from nilt.control import PROFILE_DEFAULT_BUDGETS
from nilt.dashboard import Dashboard, PROFILE_HOURS


class LaptopIGPUProfileTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.config = self.root / "project.yaml"
        self.config.write_text("schema_version: 3\ntasks:\n  vig:\n    dataset_root: ./images\n", encoding="utf-8")

    def tearDown(self):
        self.temp.cleanup()

    def test_cpu_default_is_not_replaced(self):
        cfg = load_project(self.config)[0]
        self.assertEqual(cfg["profile"], "laptop")
        self.assertEqual(cfg["device"], "cpu")
        self.assertEqual(PROFILES["laptop"]["device"], "cpu")

    def test_old_project_uses_new_builtin_preset_without_rewriting_source(self):
        original = self.config.read_bytes()
        cfg = load_project(self.config, profile="laptop_igpu")[0]
        self.assertEqual(cfg["device"], "directml:0")
        self.assertEqual(cfg["training"]["batch_size"], 1)
        self.assertEqual(cfg["training"]["accumulation_steps"], 8)
        self.assertFalse(cfg["training"]["amp"])
        self.assertEqual(cfg["num_workers"], 0)
        self.assertEqual(cfg["search"]["total_budget_seconds"], 7200)
        self.assertEqual(self.config.read_bytes(), original)

    def test_supplied_project_has_explicit_igpu_profile(self):
        project = Path(__file__).resolve().parents[1] / "project.yaml"
        cfg = load_project(project, profile="laptop_igpu", task="vig")[0]
        self.assertEqual(cfg["device"], "directml:0")
        self.assertEqual(cfg["models"], ["resnet18", "efficientnet_b0"])
        self.assertTrue(cfg["pretrained"])
        self.assertTrue(cfg["preserve_native_resolution"])

    def test_old_single_task_config_accepts_igpu_profile(self):
        self.config.write_text("task: vig\ndata_root: images\noutput_root: results\nweights_dir: weights\n", encoding="utf-8")
        self.assertEqual(load_config(self.config, "laptop_igpu")["device"], "directml:0")
        with self.assertRaisesRegex(ValueError, "Profile"):
            load_config(self.config, "does_not_exist")

    def test_explicit_overrides_still_win(self):
        raw = yaml.safe_load(self.config.read_text())
        raw["profiles"] = {"laptop_igpu": {"device": "directml:2", "search": {"total_budget_seconds": 48 * 3600}}}
        self.config.write_text(yaml.safe_dump(raw), encoding="utf-8")
        cfg = load_project(self.config, "laptop_igpu")[0]
        self.assertEqual(cfg["device"], "directml:2")
        self.assertEqual(cfg["search"]["total_budget_seconds"], 48 * 3600)

    def test_gui_bootstrap_and_custom_defaults_are_consistent(self):
        app = Dashboard(self.config)
        boot = app.bootstrap()
        self.assertEqual(boot["profiles"]["laptop_igpu"], 2)
        self.assertEqual(boot["profile_devices"]["laptop_igpu"], "directml:0")
        self.assertEqual(boot["profile_models"]["laptop_igpu"], ["resnet18", "efficientnet_b0"])
        defaults = app.v5_defaults({"profile": "laptop_igpu", "task": "vig"})
        self.assertEqual(defaults["device"], "directml:0")
        self.assertFalse(defaults["training"]["amp"])

    def test_igpu_search_supports_long_custom_budget_and_other_adapter(self):
        app = Dashboard(self.config)
        custom = app.v5_defaults({"profile": "laptop_igpu", "task": "vig"})
        custom["search"]["total_budget_seconds"] = 48 * 3600
        custom["device"] = "directml:2"
        result = app.v5_search_config({"profile": "laptop_igpu", "task": "vig",
                                      "models": ["resnet18"], "custom": custom}, persist=False)
        self.assertEqual(result["resolved_config"]["device"], "directml:2")
        self.assertEqual(result["resolved_config"]["search"]["total_budget_seconds"], 48 * 3600)

    def test_igpu_preset_search_without_custom_uses_requested_hours(self):
        app = Dashboard(self.config)
        result = app.v5_search_config({"profile": "laptop_igpu", "task": "vig",
                                      "models": ["resnet18"], "hours": 5}, persist=False)
        self.assertEqual(result["resolved_config"]["search"]["total_budget_seconds"], 5 * 3600)
        self.assertEqual(result["resolved_config"]["device"], "directml:0")

    def test_cli_and_supervisor_share_registered_profiles(self):
        parser = build_parser()
        for command in ("run", "search", "audit", "doctor", "download-weights"):
            args = parser.parse_args([command, "--config", str(self.config), "--profile", "laptop_igpu"])
            self.assertEqual(args.profile, "laptop_igpu")
        self.assertEqual(PROFILE_DEFAULT_BUDGETS["laptop_igpu"], 7200)
        self.assertEqual(PROFILE_HOURS["laptop_igpu"], 2)

    def test_weight_network_settings_are_explicit_and_validated(self):
        cfg = load_project(self.config, "laptop_igpu")[0]
        self.assertTrue(cfg["download_missing_weights"])
        for profile in PROFILES:
            candidate = load_project(self.config, profile)[0]
            self.assertTrue(candidate["download_missing_weights"])
        cfg["download_missing_weights"] = False
        validate_config(cfg)
        cfg["download_missing_weights"] = "true"
        with self.assertRaisesRegex(ValueError, "download_missing_weights"):
            validate_config(cfg)
        cfg["download_missing_weights"] = True
        for value in (0, -1, float("nan"), float("inf"), True, "15"):
            cfg["weight_download_timeout_seconds"] = value
            with self.assertRaisesRegex(ValueError, "weight_download_timeout_seconds"):
                validate_config(cfg)


if __name__ == "__main__":
    unittest.main()
