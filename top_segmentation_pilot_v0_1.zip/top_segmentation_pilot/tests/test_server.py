"""Real local-server requests cover annotation integrity and request boundaries."""
import http.client
import json
from pathlib import Path
import tempfile
import threading
import unittest

import numpy as np
from PIL import Image

from topseg.common import load_config
from topseg.project import Project
from topseg.server import decode_rle, encode_rle, make_server


class MaskEncodingTests(unittest.TestCase):
    def test_round_trip_preserves_all_three_labels(self):
        expected = np.array([[0, 0, 1], [2, 2, 0]], dtype=np.uint8)
        np.testing.assert_array_equal(expected, decode_rle(encode_rle(expected), 3, 2))

    def test_rejects_invalid_or_incomplete_labels_counts(self):
        for runs in (None, [[3, 4]], [[True, 4]], [[1, True]], [[1, -1]], [[1, 5]], [[0, 3]], [[0, 4.0]], [[0, 4], [1, 1]]):
            with self.subTest(runs=runs), self.assertRaises(ValueError):
                decode_rle(runs, 2, 2)


class AnnotationHTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.temp.name)
        sources = cls.root / 'sources'; sources.mkdir()
        image = np.full((48, 64, 3), 110, dtype=np.uint8)
        image[20:25, 30:35] = 20
        Image.fromarray(image).save(sources / 'unit-a.png')
        cls.source_bytes = (sources / 'unit-a.png').read_bytes()
        config_path = cls.root / 'project.yaml'
        config_path.write_text('input_dir: sources\nproject_dir: workspace\noutput_dir: output\n', encoding='utf-8')
        cls.cfg = load_config(config_path)
        project = Project(cls.cfg); project.import_images()
        cls.image_id = project.items()[0]['id']
        cls.server = make_server(cls.cfg)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True); cls.thread.start()
        cls.host = f'127.0.0.1:{cls.server.server_port}'

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close(); cls.thread.join(5); cls.temp.cleanup()

    def request(self, method, path, body=None, token=True, origin=True, host=None):
        connection = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=10)
        headers = {'Host': host or self.host}
        if token: headers['X-Session-Token'] = self.server.session_token
        if method == 'POST' and origin: headers['Origin'] = f'http://{self.host}'
        if body is not None:
            headers['Content-Type'] = 'application/json'; body = json.dumps(body)
        connection.request(method, path, body=body, headers=headers)
        response = connection.getresponse(); data = response.read(); status = response.status
        content_type = response.getheader('Content-Type'); connection.close()
        return status, json.loads(data) if content_type.startswith('application/json') else data

    def test_static_ui_and_api_authentication(self):
        status, page = self.request('GET', '/', token=False)
        self.assertEqual(status, 200); self.assertIn(self.server.session_token.encode(), page)
        self.assertIn(b'Approve clean', page)
        self.assertEqual(self.request('GET', '/api/project', token=False)[0], 403)
        self.assertEqual(self.request('GET', '/', host='untrusted.example')[0], 403)
        self.assertEqual(self.request('GET', '/api/project')[0], 200)

    def test_rejects_remote_or_missing_origin_and_missing_token(self):
        path = f'/api/image/{self.image_id}/annotation'
        for token, origin in ((False, True), (True, False)):
            self.assertEqual(self.request('POST', path, {}, token=token, origin=origin)[0], 403)

    def test_real_proposal_edit_approval_conflict_and_source_preservation(self):
        path = f'/api/image/{self.image_id}'
        status, opened = self.request('GET', path)
        self.assertEqual(status, 200); self.assertEqual(opened['status'], 'draft')
        self.assertGreater(opened['revision'], 0)
        mask = decode_rle(opened['mask_rle'], 64, 48); mask[:] = 0
        mask[4:9, 3:7] = 1; mask[24:26, 20:23] = 2
        payload = dict(mask_rle=encode_rle(mask), expected_revision=opened['revision'], approved=True, clean=False, roi=opened['roi'])
        status, saved = self.request('POST', path + '/annotation', payload)
        self.assertEqual(status, 200, saved); self.assertEqual(saved['status'], 'approved')
        np.testing.assert_array_equal(decode_rle(saved['mask_rle'], 64, 48), mask)
        self.assertEqual(self.request('POST', path + '/annotation', payload)[0], 409)
        self.assertEqual(self.request('GET', path + '/rgb')[0], 200)
        self.assertEqual(self.request('GET', path + '/mask')[0], 200)
        self.assertEqual((self.root / 'sources' / 'unit-a.png').read_bytes(), self.source_bytes)
        # Regeneration is another draft revision and requires a current revision.
        status, proposal = self.request('POST', path + '/propose', {'roi': saved['roi'], 'expected_revision': saved['revision'], 'settings': {'sensitivity': 5}})
        self.assertEqual(status, 200, proposal); self.assertEqual(proposal['status'], 'draft')
        status, invalid = self.request('POST', path + '/annotation', {'mask_rle': [[0, 3072]], 'expected_revision': proposal['revision'], 'approved': True, 'clean': False})
        self.assertEqual(status, 400, invalid)
        status, clean = self.request('POST', path + '/annotation', {'mask_rle': [[0, 3072]], 'expected_revision': proposal['revision'], 'approved': True, 'clean': True})
        self.assertEqual(status, 200, clean); self.assertTrue(clean['clean'])

    def test_invalid_mask_and_boolean_revision_are_rejected(self):
        path = f'/api/image/{self.image_id}'
        _, opened = self.request('GET', path)
        self.assertEqual(self.request('POST', path + '/annotation', {'mask_rle': [[0, 3072]], 'expected_revision': True})[0], 400)
        self.assertEqual(self.request('POST', path + '/annotation', {'mask_rle': [[4, 3072]], 'expected_revision': opened['revision']})[0], 400)
        self.assertEqual(self.request('GET', '/../../project.yaml')[0], 404)


if __name__ == '__main__':
    unittest.main()
