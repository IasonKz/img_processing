"""Standalone reports embed their plotting runtime for offline use."""
import html
from pathlib import Path
from .common import read_json


def export_report(cfg,request,job_root):
    from .search import settings
    import plotly.graph_objects as go
    from plotly.subplots import make_subplots
    settings({'study_name':request['study_name']})
    root=Path(cfg['output_dir'])/'studies'/request['study_name']; data=read_json(root/'summary.json')
    trials=[t for t in data['trials'] if t['state']=='COMPLETE']
    if not trials:raise ValueError('No completed trials to report.')
    fig=make_subplots(rows=2,cols=2,subplot_titles=['Search history','Model comparison','Accuracy and runtime','Class IoU'])
    fig.add_trace(go.Scatter(x=[t['number'] for t in trials],y=[t['value'] for t in trials],mode='lines+markers',name='Validation score'),1,1)
    fig.add_trace(go.Bar(x=[str(t['number'])+': '+t['params']['model'] for t in trials],y=[t['value'] for t in trials],name='Trials'),1,2)
    fig.add_trace(go.Scatter(x=[t['seconds'] for t in trials],y=[t['value'] for t in trials],mode='markers',text=[t['params']['model'] for t in trials],name='Seconds'),2,1)
    for cls in ('inner','outer'):
        fig.add_trace(go.Bar(x=[t['number'] for t in trials],y=[t['attributes']['validation']['classes'][cls]['iou'] for t in trials],name=cls),2,2)
    fig.update_layout(height=950,template='plotly_white',title='Top Segmentation Studio • '+data['study_name'])
    table='<table><tr><th>Trial</th><th>Model</th><th>State</th><th>Score</th><th>Error</th></tr>'
    for t in data['trials']:
        table+='<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in [t['number'],t['params'].get('model',''),t['state'],t['value'],t['attributes'].get('error','')])+'</tr>'
    table+='</table>'
    document='<!doctype html><html lang="en"><meta charset="utf-8"><title>Top segmentation report</title><style>body{font:15px system-ui;padding:30px;background:#f5f7fa;color:#152b40}table{border-collapse:collapse;width:100%;background:white}td,th{padding:10px;border-bottom:1px solid #dce4eb;text-align:left}h1{font-size:30px}</style><h1>Top segmentation experiment</h1><p>Validation comparison on one frozen, grouped dataset. These charts do not represent independent test or production acceptance performance.</p>'+fig.to_html(full_html=False,include_plotlyjs=True)+table+'</html>'
    output=Path(cfg['output_dir'])/'reports';output.mkdir(parents=True,exist_ok=True)
    path=output/(request['study_name']+'_'+Path(job_root).name+'.html');path.write_text(document,encoding='utf-8')
    return {'status':'completed','file':str(path)}
