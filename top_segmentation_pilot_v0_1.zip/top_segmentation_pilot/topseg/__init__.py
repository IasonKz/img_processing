"""Local annotation and lightweight top-view defect segmentation."""
__version__ = '0.1.0'
