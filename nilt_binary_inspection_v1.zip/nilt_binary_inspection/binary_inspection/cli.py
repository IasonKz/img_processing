from __future__ import annotations

import argparse
import importlib
import importlib.metadata
import json
import multiprocessing
from pathlib import Path
import platform
import sys

from .common import load_config, validate_config, setup_logging, output_dir, LOG, write_json


def doctor(cfg: dict) -> dict:
    details = {"python": sys.version, "platform": platform.platform(), "packages": {}}
    for package in ("torch", "torchvision", "timm", "numpy", "scipy", "scikit-learn", "Pillow", "PyYAML"):
        try:
            details["packages"][package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            details["packages"][package] = "MISSING"
    import torch
    details["cuda_available"] = torch.cuda.is_available()
    details["torch_cuda_version"] = torch.version.cuda
    details["gpus"] = [torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())]
    details["cpu_threads"] = torch.get_num_threads()
    details["task"] = cfg["project"]["task"]
    details["cached_weights"] = sorted(p.name for p in Path(cfg["paths"]["pretrained_dir"]).glob("*.pt"))
    if not (output_dir(cfg) / "environment.json").exists():
        write_json(output_dir(cfg) / "environment.json", details)
    write_json(output_dir(cfg) / "environment_latest.json", details)
    print(json.dumps(details, ensure_ascii=False, indent=2))
    return details


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(description="Local binary visual inspection. GOOD=0, BAD=1. No segmentation or automatic production release.")
    commands = root.add_subparsers(dest="command", required=True)
    for name in ("doctor", "download-weights", "audit", "prepare", "verify-data", "train", "train-anomaly", "select", "evaluate", "predict", "run"):
        child = commands.add_parser(name)
        child.add_argument("--config", default="configs/top.yaml", help="YAML path; defaults to configs/top.yaml")
        child.add_argument("--dataset", help="Override the folder containing good/ and bad/")
        child.add_argument("--output", help="Override the versioned training run directory")
        if name == "train":
            child.add_argument("--model", help="Only this named model, e.g. convnext_tiny")
        if name == "predict":
            child.add_argument("--input", required=True, help="New flat/recursive image folder, good/bad folder, or one image")
            child.add_argument("--pred-output", help="New directory for CSV, report and optional copies")
    return root


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        cfg = load_config(args.config)
        if args.dataset:
            cfg["paths"]["dataset_root"] = str(Path(args.dataset).expanduser().resolve())
        if args.output:
            cfg["paths"]["output_dir"] = str(Path(args.output).expanduser().resolve())
        validate_config(cfg)
        setup_logging(output_dir(cfg))
        if args.command == "doctor":
            doctor(cfg)
        elif args.command == "download-weights":
            from .models import download_weights
            download_weights(cfg)
        elif args.command == "audit":
            from .audit import audit
            _, report = audit(cfg)
            return 0 if report["passed"] else 2
        elif args.command == "prepare":
            from .splitting import prepare
            prepare(cfg)
        elif args.command == "verify-data":
            from .splitting import verify_manifest
            verify_manifest(cfg)
        elif args.command == "train":
            from .training import train_all
            train_all(cfg, args.model)
        elif args.command == "train-anomaly":
            from .patchcore import train_patchcore
            train_patchcore(cfg)
        elif args.command == "select":
            from .selector import select_pipeline
            select_pipeline(cfg)
        elif args.command == "evaluate":
            from .inference import evaluate
            evaluate(cfg)
        elif args.command == "predict":
            from .inference import predict_folder
            summary = predict_folder(cfg, Path(args.input).expanduser().resolve(), Path(args.pred_output) if args.pred_output else None)
            return 2 if summary["model_failure"] else 0
        elif args.command == "run":
            from .splitting import prepare
            from .training import train_all
            from .patchcore import train_patchcore
            from .selector import select_pipeline
            from .inference import evaluate
            doctor(cfg)
            prepare(cfg)
            train_all(cfg)
            train_patchcore(cfg)
            select_pipeline(cfg)
            evaluate(cfg)
        return 0
    except KeyboardInterrupt:
        LOG.error("Interrupted. Completed models and best checkpoints are preserved. Re-running restarts only unfinished training; no implicit epoch resume")
        return 130
    except Exception:
        LOG.exception("Pipeline stopped. No production release is authorized")
        return 2


if __name__ == "__main__":
    multiprocessing.freeze_support()
    raise SystemExit(main())
