"use strict";
/* Shared display-only inspector. Levels are applied to native pixels on the server. */
window.ImageInspector = (() => {
  const viewers = new Map();
  const headers = () => { const token=document.querySelector('meta[name="session-token"]')?.content;return token?{"X-Session-Token":token}:{}; };
  function mount(prefix, options={}) {
    if(viewers.has(prefix))return viewers.get(prefix);
    const dialog = options.container || document.getElementById(prefix + "-dialog"), img = options.img || document.getElementById(prefix + "-large");
    const viewport = options.viewport || document.getElementById(prefix + "-viewport");
    if (!dialog || !img || !viewport) return;
    const toolbar = options.toolbar || dialog.querySelector(".image-toolbar");
    const controls = document.createElement("div"); controls.className = "viewer-controls";
    controls.innerHTML = `<div class="viewer-zoom"><button type="button" data-viewer="out" class="secondary small" aria-label="Zoom out">−</button><span data-viewer="zoom">Fit</span><button type="button" data-viewer="in" class="secondary small" aria-label="Zoom in">+</button><button type="button" data-viewer="fullscreen" class="secondary small">⛶ Full screen</button>${prefix === "image" ? '<button type="button" data-viewer="details" class="secondary small">Image details</button>' : ''}</div><div class="viewer-levels"><label class="checkbox"><input data-viewer="normalize" type="checkbox">Normalize display brightness</label><label>Lower<select data-viewer="low-mode"><option value="0">0</option><option value="min">Image min</option><option value="custom">Custom</option></select></label><input data-viewer="low" type="number" step="any" min="0" hidden aria-label="Custom lower display limit"><label>Upper<select data-viewer="high-mode"><option value="max">Image max</option><option value="custom">Custom</option></select></label><input data-viewer="high" type="number" step="any" min="0" hidden aria-label="Custom upper display limit"><button data-viewer="apply" type="button" class="secondary small">Apply levels</button><button data-viewer="reset" type="button" class="secondary small">Reset display</button><span data-viewer="levels" class="hint" role="status">Display only · scroll to zoom, drag to pan</span></div>`;
    toolbar.after(controls); dialog.classList.add("inspector-container");if(!options.canvas)viewport.classList.add("inspector-viewport");
    const control = name => controls.querySelector(`[data-viewer="${name}"]`);
    const state = {dialog, img, viewport, base:"", scale:1, x:0, y:0, fit:true, stats:null, generation:0, drag:null};
    function render() {
      if(options.canvas){control("zoom").textContent=Math.round(options.getScale()*100)+"%";return;}
      img.style.width = img.naturalWidth * state.scale + "px"; img.style.height = img.naturalHeight * state.scale + "px";
      img.style.left = state.x + "px"; img.style.top = state.y + "px";
      control("zoom").textContent = Math.round(state.scale * 100) + "%";
    }
    function fit() {
      if(options.canvas){options.fit();render();return;}
      if (!img.naturalWidth || !viewport.clientWidth || !viewport.clientHeight) return;
      state.fit = true; state.scale = Math.min(viewport.clientWidth / img.naturalWidth, viewport.clientHeight / img.naturalHeight);
      viewport.classList.remove("native-size");
      state.x = (viewport.clientWidth - img.naturalWidth * state.scale) / 2;
      state.y = (viewport.clientHeight - img.naturalHeight * state.scale) / 2; render();
    }
    function zoom(scale, x=viewport.clientWidth/2, y=viewport.clientHeight/2) {
      if(options.canvas){state.fit=false;options.zoom(scale);render();return;}
      if (!img.naturalWidth) return;
      scale = Math.max(.01, Math.min(32, scale));
      const ratio = scale / state.scale;
      state.x = x - (x - state.x) * ratio; state.y = y - (y - state.y) * ratio;
      state.scale = scale; state.fit = false; render();
      viewport.classList.toggle("native-size", scale === 1);
    }
    function note() {
      if (state.stats) control("levels").textContent = `${state.stats.bit_depth}-bit · min ${state.stats.min} · max ${state.stats.max} · display only`;
    }
    function apply() {
      if (!state.base) return;
      const low = control("low-mode").value, high = control("high-mode").value;
      control("low").hidden = low !== "custom"; control("high").hidden = high !== "custom";
      const url = new URL(state.base, location.href);
      if (control("normalize").checked) {
        if (!state.stats) { control("levels").textContent = "Reading native pixel levels…"; return; }
        const a = low === "min" ? state.stats.min : low === "custom" ? Number(control("low").value) : 0;
        const b = high === "max" ? state.stats.max : Number(control("high").value);
        if (!Number.isFinite(a) || !Number.isFinite(b) || a < 0 || b > state.stats.range_max || a > b || (a === b && (low === "custom" || high === "custom"))) {
          control("levels").textContent = `Use 0 ≤ lower < upper ≤ ${state.stats.range_max}.`; return;
        }
        url.searchParams.set("window", "1"); url.searchParams.set("black", low === "min" ? "min" : String(a));
        url.searchParams.set("white", high === "max" ? "max" : String(b));
      }
      setImage(url.pathname + url.search); note();
    }
    let displayGeneration=0,blobURL=null;
    async function setImage(url){
      const generation=++displayGeneration;
      if(!Object.keys(headers()).length){img.src=url;return;}
      try{const response=await fetch(url,{headers:headers()});if(!response.ok)throw Error("Cannot display this image.");const blob=await response.blob();if(generation!==displayGeneration)return;if(blobURL)URL.revokeObjectURL(blobURL);blobURL=URL.createObjectURL(blob);img.src=blobURL;}
      catch(error){if(generation===displayGeneration)control("levels").textContent=error.message;}
    }
    state.open = async base => {
      if(base){const original=new URL(base,location.href);for(const key of ["window","black","white"])original.searchParams.delete(key);base=original.pathname+original.search;}
      state.base = base || ""; state.fit = true; state.stats = null;
      const generation = ++state.generation; img.hidden = !base || !!options.canvas;if(base)setImage(base);else{displayGeneration++;img.removeAttribute("src");}
      if (!base) return;
      control("levels").textContent = "Reading native pixel levels…";
      try {
        const url = new URL(base, location.href);
        url.pathname += "-info";
        const response = await fetch(url.pathname + url.search,{headers:headers()});
        const data = await response.json();
        if (!response.ok) throw Error(data.error || "Image information unavailable");
        if (generation !== state.generation) return;
        state.stats = data;
        control("low").max = control("high").max = String(data.range_max);
        if (!control("low").value) control("low").value = "0";
        if (!control("high").value) control("high").value = String(data.max || data.range_max);
        note(); apply();
      } catch (error) { if (generation === state.generation) control("levels").textContent = error.message; }
    };
    img.onload = () => { if(options.onImage)options.onImage(img);if (state.fit) fit(); else render(); };
    img.onerror = () => { if (state.base) control("levels").textContent = "Cannot display this image. Check the display limits or reset display."; };
    img.draggable = false;
    for(const [name,action]of [["fit",fit],["native",()=>zoom(1)]]){let button=document.getElementById(prefix+"-"+name);if(!button){button=document.createElement("button");button.type="button";button.id=prefix+"-"+name;button.className="secondary small";button.textContent=name==="fit"?"Fit image":"100% pixels";toolbar.appendChild(button);}button.onclick=action;}
    control("in").onclick = () => zoom((options.getScale?options.getScale():state.scale) * 1.25);
    control("out").onclick = () => zoom((options.getScale?options.getScale():state.scale) / 1.25);
    control("apply").onclick = apply;
    ["normalize", "low-mode", "high-mode"].forEach(name => control(name).addEventListener("change", apply));
    ["low", "high"].forEach(name => control(name).addEventListener("keydown", event => { if (event.key === "Enter") { event.preventDefault(); apply(); } }));
    control("reset").onclick = () => { control("normalize").checked=false; control("low-mode").value="0"; control("high-mode").value="max"; apply(); fit(); };
    control("fullscreen").onclick = async () => {
      try { if (document.fullscreenElement === dialog) await document.exitFullscreen(); else await dialog.requestFullscreen(); }
      catch { dialog.classList.toggle("viewer-expanded"); layout(); }
    };
    if (control("details")) control("details").onclick = () => { dialog.classList.toggle("viewer-show-details"); fit(); };
    function layout() { control("fullscreen").textContent = document.fullscreenElement === dialog || dialog.classList.contains("viewer-expanded") ? "⛶ Exit full screen" : "⛶ Full screen"; if (state.fit) requestAnimationFrame(fit); }
    document.addEventListener("fullscreenchange", layout);
    document.addEventListener("keydown",event=>{if(event.key==="Escape"&&dialog.classList.contains("viewer-expanded")){event.preventDefault();dialog.classList.remove("viewer-expanded");layout();}});
    dialog.addEventListener("close", () => { if (document.fullscreenElement === dialog) document.exitFullscreen().catch(()=>{}); dialog.classList.remove("viewer-expanded"); });
    dialog.addEventListener("cancel", event => { if(dialog.classList.contains("viewer-expanded")){event.preventDefault();dialog.classList.remove("viewer-expanded");layout();} });
    if(!options.canvas){
    viewport.addEventListener("wheel", event => { event.preventDefault(); const rect=viewport.getBoundingClientRect(); zoom(state.scale*Math.exp(-event.deltaY*.0015),event.clientX-rect.left,event.clientY-rect.top); }, {passive:false});
    viewport.addEventListener("contextmenu", event=>event.preventDefault());
    viewport.addEventListener("pointerdown", event => { if(![0,1,2].includes(event.button)||!img.naturalWidth)return; event.preventDefault(); state.drag={id:event.pointerId,x:event.clientX,y:event.clientY,originX:state.x,originY:state.y}; state.fit=false;viewport.setPointerCapture(event.pointerId);viewport.classList.add("is-panning"); });
    viewport.addEventListener("pointermove", event => { const drag=state.drag;if(!drag||drag.id!==event.pointerId)return;state.x=drag.originX+event.clientX-drag.x;state.y=drag.originY+event.clientY-drag.y;render(); });
    function end(event) { if(state.drag?.id!==event.pointerId)return;state.drag=null;viewport.classList.remove("is-panning");if(viewport.hasPointerCapture(event.pointerId))viewport.releasePointerCapture(event.pointerId); }
    ["pointerup","pointercancel","lostpointercapture"].forEach(name=>viewport.addEventListener(name,end));
    }
    new ResizeObserver(() => { if(state.fit)fit(); }).observe(viewport);
    viewers.set(prefix,state);
    state.sync=()=>{if(options.canvas)state.fit=false;render();};return state;
  }
  mount("image"); mount("qr-image");
  mount("clean",{container:document.getElementById("clean-editor"),img:document.getElementById("clean-image")});
  function inspect(source,title="Image inspection"){
    let dialog=document.getElementById("asset-dialog");
    if(!dialog){dialog=document.createElement("dialog");dialog.id="asset-dialog";dialog.innerHTML='<div class="dialog-header"><h2 id="asset-title"></h2><button id="asset-close" type="button" class="secondary">Close</button></div><div class="image-toolbar"></div><div id="asset-viewport" class="image-viewport"><img id="asset-large" alt="Inspection image"></div>';document.body.appendChild(dialog);document.getElementById("asset-close").onclick=()=>dialog.close();mount("asset");}
    const url=new URL(source,location.href);if(url.origin!==location.origin&&url.protocol!=="blob:")return;
    if(url.pathname.startsWith("/images/")||url.pathname.startsWith("/results/"))source="/api/viewer/image?"+new URLSearchParams({source:url.pathname});
    document.getElementById("asset-title").textContent=title; if(!dialog.open)dialog.showModal();viewers.get("asset").open(source);
  }
  document.addEventListener("click",event=>{
    const anchor=event.target.closest("a"),img=event.target.closest("img");
    if(event.defaultPrevented||event.ctrlKey||event.metaKey||event.shiftKey||event.button)return;
    const source=anchor?.getAttribute("href")||img?.dataset.viewerSource||img?.getAttribute("src");
    if(!source||img?.closest(".inspector-viewport,.clean-thumb,[data-review-index],[data-qr-image]"))return;
    if(anchor&&!/\.(png|jpe?g|bmp|tiff?|webp)(?:\?|$)|\/api\/.*(?:image|crop)/i.test(source))return;
    if(!anchor&&!img)return;
    if(img&&!(img.closest(".gallery,.roi-quality-card,#roi-crop-preview,.preview-grid,.inspection-previews")||img.dataset.viewerSource))return;
    event.preventDefault();inspect(source,img?.alt||anchor?.textContent||"Image inspection");
  });
  return {open:(prefix,base)=>viewers.get(prefix)?.open(base),fit:prefix=>document.getElementById(prefix+"-fit")?.click(),mount,inspect,
    canvas:(prefix,options)=>{const img=new Image();return mount(prefix,{...options,img,canvas:true});}};
})();
