/* Discrete native-resolution raster operations shared by the UI and tests. */
(function (root) {
  'use strict';
  function decode(runs, total) {
    const out = new Uint8Array(total); let offset = 0;
    for (const pair of runs) {
      const [value, count] = pair;
      if (![0, 1, 2].includes(value) || !Number.isInteger(count) || count <= 0 || offset + count > total) throw new Error('Invalid mask data.');
      out.fill(value, offset, offset + count); offset += count;
    }
    if (offset !== total) throw new Error('Incomplete mask data.');
    return out;
  }
  function encode(mask) {
    if (!mask.length) return [];
    const result = []; let start = 0;
    for (let i = 1; i <= mask.length; i++) {
      if (i === mask.length || mask[i] !== mask[start]) { result.push([mask[start], i - start]); start = i; }
    }
    return result;
  }
  function box(w, h, x0, y0, x1, y1, visit) {
    const left = Math.max(0, Math.floor(Math.min(x0, x1))), right = Math.min(w - 1, Math.ceil(Math.max(x0, x1)));
    const top = Math.max(0, Math.floor(Math.min(y0, y1))), bottom = Math.min(h - 1, Math.ceil(Math.max(y0, y1)));
    for (let y = top; y <= bottom; y++) for (let x = left; x <= right; x++) visit(x, y, x + y * w);
  }
  function ellipse(mask, w, h, cx, cy, rx, ry, value) {
    if (!(rx > 0 && ry > 0)) return;
    box(w, h, cx - rx, cy - ry, cx + rx, cy + ry, (x, y, index) => {
      if (((x + 0.5 - cx) / rx) ** 2 + ((y + 0.5 - cy) / ry) ** 2 <= 1) mask[index] = value;
    });
  }
  function stroke(mask, w, h, a, b, diameter, value) {
    const radius = Math.max(0.5, diameter / 2), length = Math.hypot(b.x - a.x, b.y - a.y);
    const steps = Math.max(1, Math.ceil(length / Math.max(0.5, radius / 2)));
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      ellipse(mask, w, h, Math.floor(a.x + (b.x - a.x) * t) + 0.5, Math.floor(a.y + (b.y - a.y) * t) + 0.5, radius, radius, value);
    }
  }
  function rectangle(mask, w, h, a, b, value) {
    const left = Math.min(a.x, b.x), right = Math.max(a.x, b.x), top = Math.min(a.y, b.y), bottom = Math.max(a.y, b.y);
    box(w, h, left, top, right, bottom, (x, y, index) => { if (x + 0.5 >= left && x + 0.5 <= right && y + 0.5 >= top && y + 0.5 <= bottom) mask[index] = value; });
  }
  function polygon(mask, w, h, points, value) {
    if (points.length < 3) return;
    box(w, h, Math.min(...points.map(p => p.x)), Math.min(...points.map(p => p.y)), Math.max(...points.map(p => p.x)), Math.max(...points.map(p => p.y)), (x, y, index) => {
      const px = x + 0.5, py = y + 0.5; let inside = false;
      for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
        const a = points[i], b = points[j];
        if ((a.y > py) !== (b.y > py) && px < (b.x - a.x) * (py - a.y) / (b.y - a.y) + a.x) inside = !inside;
      }
      if (inside) mask[index] = value;
    });
  }
  function counts(mask) {
    const result = [0, 0, 0]; for (const value of mask) result[value]++; return result;
  }
  root.TopsegMask = {decode, encode, ellipse, stroke, rectangle, polygon, counts};
})(typeof window === 'undefined' ? globalThis : window);
