"""Explicit device selection and the optional Windows DirectML backend."""
from __future__ import annotations

import importlib
import platform
import re


def validate_device_name(value):
    value = str(value).lower().strip()
    if not re.fullmatch(r"(?:auto|cpu|cuda(?::\d+)?|directml(?::\d+)?)", value):
        raise ValueError("Device must be auto, cpu, cuda[:index] or directml[:index].")
    return value


def directml_devices():
    """Read adapters without choosing one or silently changing backend."""
    if platform.system() != "Windows":
        raise RuntimeError("This release's DirectML integration requires native Windows. Select cpu or cuda here.")
    try:
        dml = importlib.import_module("torch_directml")
    except (ImportError, OSError, RuntimeError) as exc:
        raise RuntimeError("DirectML is not installed in this interpreter. Run Setup-DirectML.cmd and restart with Start.cmd. "
                           "Keep DirectML separate from the CPU/CUDA environment. " + str(exc)) from exc
    count = int(dml.device_count())
    if count < 1:
        raise RuntimeError("DirectML found no adapters. Update the GPU driver or explicitly select cpu.")
    return dml, [{"index": i, "name": str(dml.device_name(i)), "device": f"directml:{i}"} for i in range(count)]


def resolve_directml(value, torch, probe=True):
    value = validate_device_name(value)
    dml, adapters = directml_devices()
    index = int(value.split(":", 1)[1]) if ":" in value else 0
    if index >= len(adapters):
        raise ValueError(f"DirectML adapter {index} is unavailable. Available adapters: {adapters}")
    device = dml.device(index)
    if probe:
        try:
            # Verify transfer, forward arithmetic, autograd and return transfer.
            x = torch.tensor([[1., 2.], [3., 4.]], dtype=torch.float32, device=device, requires_grad=True)
            loss = (x @ x).sum()
            loss.backward()
            if not bool(torch.isfinite(loss.detach().cpu()).all()) or not bool(torch.isfinite(x.grad.detach().cpu()).all()):
                raise RuntimeError("Nonfinite device probe output")
        except Exception as exc:
            raise RuntimeError(f"DirectML adapter {index} ({adapters[index]['name']}) failed its forward/backward probe: {exc}. "
                               "The application has not switched to CPU.") from exc
    return device


def device_report():
    """Optional doctor information; absence is reported rather than fatal."""
    try:
        _, adapters = directml_devices()
        return {"available": True, "adapters": adapters, "experimental": True,
                "note": "Adapter discovery is not a model-specific compatibility or speed guarantee."}
    except Exception as exc:
        return {"available": False, "adapters": [], "experimental": True, "reason": str(exc)}
