"""V5 GUI contracts: validation, immutable settings and workspace boundaries."""
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from nilt.common import read_json, write_json
from nilt.dashboard import Dashboard


class DashboardV5Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        config = self.root / 'project.yaml'
        config.write_text('tasks:\n  vig:\n    enabled: true\n    dataset_root: ./missing\n', encoding='utf-8')
        self.app = Dashboard(config)

    def tearDown(self):
        self.temp.cleanup()

    def payload(self):
        custom = self.app.v5_defaults({})
        custom['search']['total_budget_seconds'] = 3600
        return {'profile': 'laptop', 'task': 'vig', 'models': ['efficientnet_b0'],
                'hours': 1, 'custom': custom}

    def test_custom_defaults_do_not_require_images(self):
        defaults = self.app.v5_defaults({})
        self.assertIn('space', defaults['search'])
        self.assertEqual(defaults['image_strategy'], 'full_image')

    def test_validation_does_not_create_snapshot(self):
        result = self.app.v5_search_config(self.payload(), persist=False)
        self.assertTrue(result['valid'])
        self.assertEqual(result['resolved_config']['search']['total_budget_seconds'], 3600)
        self.assertFalse(list(self.app.logs_root.glob('search_contract*')))

    def test_custom_snapshot_is_independent_of_project_changes(self):
        target = self.app.v5_search_config(self.payload())
        recorded = target.read_bytes()
        self.app.raw['defaults'] = {'image_size': 123}
        self.assertEqual(target.read_bytes(), recorded)
        self.assertTrue(read_json(target)['pretrained'])

    def test_invalid_budget_and_duplicate_models_are_rejected(self):
        data = self.payload()
        for hours in (-1, 0, float('nan')):
            with self.assertRaises(ValueError):
                self.app.v5_search_config(dict(data, custom=None, hours=hours), persist=False)
        with self.assertRaises(ValueError):
            self.app.v5_search_config(dict(data, models=['resnet18', 'resnet18']), persist=False)

    def test_exact_custom_seconds_override_rounded_preset_hours(self):
        data = self.payload()
        data['custom']['search']['total_budget_seconds'] = 1937
        result = self.app.v5_search_config(data, persist=False)
        self.assertEqual(result['resolved_config']['search']['total_budget_seconds'], 1937)
        command = self.app.command('search', data)
        self.assertNotIn('--hours', command)
        self.assertEqual(read_json(command[command.index('--config') + 1])['search']['total_budget_seconds'], 1937)

    def test_long_budget_and_cuda_are_independent_of_profile(self):
        data = self.payload()
        data['custom']['device'] = 'cuda'
        data['custom']['search']['total_budget_seconds'] = 48 * 3600
        result = self.app.v5_search_config(data, persist=False)['resolved_config']
        self.assertEqual(result['device'], 'cuda')
        self.assertEqual(result['search']['total_budget_seconds'], 48 * 3600)

    def test_weight_provisioning_uses_selected_architectures(self):
        command = self.app.command('prepare-weights', {'task': 'vig', 'profile': 'laptop', 'models': ['convnext_tiny']})
        self.assertEqual(command[command.index('--models') + 1:], ['convnext_tiny'])

    def test_exclusive_decision_action_blocks_new_work(self):
        with self.app._v5_exclusive('decision-preview'):
            with self.assertRaises(ValueError):
                with self.app._v5_exclusive('decision-save'):
                    pass
        self.assertIsNone(self.app._v5_operation)

    def test_final_test_needs_explicit_acknowledgement(self):
        path = self.root / 'decision_systems' / 's1' / 'decision_system.json'
        write_json(path, {'name': 'system'})
        with self.assertRaises(ValueError):
            self.app.command('system-evaluate', {'system': str(path)})
        cmd = self.app.command('system-evaluate', {'system': str(path), 'confirm_final_test': True})
        self.assertIn('system-evaluate', cmd)

    def test_preview_rejects_unregistered_sources(self):
        with self.assertRaises(ValueError):
            self.app.v5_system_preview({'definition': {'sources': [{'run': '/not/a/run'}]}})

    def test_review_finetune_uses_verified_config(self):
        path = self.root / 'review_datasets' / 'set1' / 'update_config.json'
        run = self.root / 'results' / 'vig' / 'r1'
        write_json(path, {})
        write_json(run / 'config.json', {'task': 'vig'})
        cfg = {'previous_run': str(run), 'profile': 'laptop', 'task': 'vig'}
        with patch('nilt.review_dataset.validate_update_config', return_value=cfg) as validate:
            cmd = self.app.command('review-finetune', {'config': str(path)})
        validate.assert_called_once_with(path)
        self.assertIn('update', cmd)
        self.assertIn(str(run), cmd)


if __name__ == '__main__':
    unittest.main()
