"""Small, approved-data-only segmentation experiment with explicit provenance."""
from __future__ import annotations

import csv
from datetime import datetime, timezone
import html
import json
import math
import os
from pathlib import Path
import random
import time
import uuid

import numpy as np
from PIL import Image
from scipy import ndimage

from .inference import (CLASSES, confusion_matrix, fit_geometry, load_model,
                        metrics_from_confusion, overlay, prepare_image, prepare_mask,
                        require_torch, restore_probabilities, select_device)


def split_groups(records, val_fraction=0.2, seed=42, previous=None, require_both=True):
    """Allocate physical units together; preserve every known predecessor role."""
    if not 0 < float(val_fraction) < 1:
        raise ValueError("val_fraction must lie strictly between 0 and 1.")
    groups = {}
    for row in records:
        key = str(row.get("group", "")).strip()
        if not key:
            raise ValueError("Every dataset record requires a nonempty group identifier.")
        groups.setdefault(key, []).append(row)
    if len(groups) < 2:
        raise ValueError("At least two independent groups are required for train/validation splitting.")
    old = dict(previous or {})
    if any(role not in ("train", "validation") for role in old.values()):
        raise ValueError("Predecessor group split contains an unknown role.")
    fixed = {key: old[key] for key in groups if key in old}
    free = sorted(key for key in groups if key not in fixed)
    required = {1, 2} if require_both else set()
    available = {c for rows in groups.values() for row in rows for c in row.get("defect_classes", [])}
    if require_both and not required.issubset(available):
        raise ValueError("The approved dataset must contain both inner and outer defect pixels.")
    if not available:
        raise ValueError("The approved dataset contains no defect pixels; segmentation training requires labeled defects.")
    required = required or available
    rng, best = random.Random(int(seed)), None
    target = len(records) * float(val_fraction)
    # Search reproducible group allocations, never splitting images from one unit.
    for attempt in range(192):
        shuffled = free[:]
        rng.shuffle(shuffled)
        assigned = dict(fixed)
        nval = sum(len(groups[g]) for g, role in assigned.items() if role == "validation")
        for g in shuffled:
            choose_val = nval < target
            if attempt and rng.random() < .20:
                choose_val = not choose_val
            assigned[g] = "validation" if choose_val else "train"
            nval += len(groups[g]) if choose_val else 0
        train = [r for r in records if assigned[str(r["group"])] == "train"]
        validation = [r for r in records if assigned[str(r["group"])] == "validation"]
        if not train or not validation:
            continue
        train_classes = {c for r in train for c in r.get("defect_classes", [])}
        val_classes = {c for r in validation for c in r.get("defect_classes", [])}
        if not required.issubset(train_classes):
            continue
        score = (len(required-val_classes), abs(len(validation)-target), tuple(sorted(assigned.items())))
        if best is None or score < best[0]:
            best = (score, assigned)
    if best is None:
        raise ValueError("Cannot create a grouped split with the required training classes. Add independently grouped labeled images; predecessor validation groups cannot move into training.")
    result = best[1]
    return {"group_split": result,
            "train_ids": [r["id"] for r in records if result[str(r["group"])] == "train"],
            "validation_ids": [r["id"] for r in records if result[str(r["group"])] == "validation"],
            "validation_missing_classes": [name for name, value in CLASSES.items() if value and value in required
                and not any(value in r.get("defect_classes", []) for r in records if result[str(r["group"])] == "validation")],
            "preserved_predecessor_groups": len(fixed), "seed": int(seed), "requested_validation_fraction": float(val_fraction)}


def inspect_training_masks(records, dataset_root, image_size):
    """Collect train preparation evidence including completely lost components."""
    from .common import safe_path
    findings = []
    for row in records:
        mask = np.asarray(Image.open(safe_path(dataset_root, row["mask"])))
        if mask.ndim != 2 or not np.isin(mask, [0, 1, 2]).all():
            raise ValueError(f"Invalid dataset mask for {row['id']}.")
        if mask.shape != (int(row["height"]), int(row["width"])):
            raise ValueError(f"Dataset mask geometry does not match image metadata for {row['id']}.")
        row["defect_classes"] = [i for i in (1, 2) if (mask == i).any()]
        g = fit_geometry(row["width"], row["height"], image_size)
        lost, components = {}, {}
        for name, label in (("inner", 1), ("outer", 2)):
            labeled, count = ndimage.label(mask == label)
            resized_components = np.asarray(Image.fromarray(labeled.astype(np.int32)).resize(
                (g["resized_width"], g["resized_height"]), Image.Resampling.NEAREST))
            present = np.unique(resized_components)
            lost[name] = int(count - (present != 0).sum())
            components[name] = int(count)
        findings.append({"id": row["id"], "native_width": row["width"], "native_height": row["height"],
                         "resized_width": g["resized_width"], "resized_height": g["resized_height"],
                         "components": components, "lost_components": lost})
    return findings


def _load_native(row, root):
    from .common import read_rgb, safe_path
    image = read_rgb(safe_path(root, row["image"]), max_pixels=int(row["width"]) * int(row["height"]))
    mask = np.asarray(Image.open(safe_path(root, row["mask"])), dtype=np.uint8)
    if image.size != (int(row["width"]), int(row["height"])):
        raise ValueError(f"Snapshot image geometry changed for {row['id']}.")
    return image, mask


def _checkpoint_save(path, payload):
    torch = require_torch()
    temporary = Path(str(path) + ".tmp")
    torch.save(payload, temporary)
    os.replace(temporary, path)


def _validate(model, rows, root, size, device, weights, destination=None):
    torch = require_torch()
    from .model import segmentation_loss
    from .common import atomic_json
    model.eval()
    matrix = np.zeros((3, 3), dtype=np.int64)
    losses, entries = [], []
    if destination is not None:
        destination = Path(destination)
        destination.mkdir(parents=True, exist_ok=True)
    with torch.inference_mode():
        for row in rows:
            image, target = _load_native(row, root)
            array, geometry = prepare_image(image, size)
            small_mask = prepare_mask(target, geometry)
            logits = model(torch.from_numpy(array)[None].to(device))
            loss = segmentation_loss(logits, torch.from_numpy(small_mask.astype(np.int64))[None].to(device), weights)
            losses.append(float(loss.item()))
            predicted = restore_probabilities(logits.softmax(1)[0].cpu().numpy(), geometry)
            cm = confusion_matrix(target, predicted)
            matrix += cm
            item_metrics = metrics_from_confusion(cm)
            entry = {"id": row["id"], "group": row["group"],
                     "inner_iou": item_metrics["classes"]["inner"]["iou"], "outer_iou": item_metrics["classes"]["outer"]["iou"],
                     "inner_dice": item_metrics["classes"]["inner"]["dice"], "outer_dice": item_metrics["classes"]["outer"]["dice"]}
            if destination is not None:
                # IDs in verified snapshots are not trusted as filesystem paths.
                import hashlib
                stem = hashlib.sha256(str(row["id"]).encode()).hexdigest()[:24]
                entry.update(mask=f"{stem}.mask.png", overlay=f"{stem}.overlay.png", target=f"{stem}.target.png")
                Image.fromarray(predicted).save(destination/entry["mask"])
                overlay(image, predicted).save(destination/entry["overlay"])
                overlay(image, target).save(destination/entry["target"])
            entries.append(entry)
    metrics = metrics_from_confusion(matrix)
    metrics.update(loss=float(np.mean(losses)), images=len(rows), geometry="native image; predictions restored from fit/pad")
    if destination is not None:
        atomic_json(destination/"metrics.json", metrics)
        with (destination/"predictions.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(entries[0]))
            writer.writeheader(); writer.writerows(entries)
    return metrics


def _report(run, state):
    escaped = html.escape(json.dumps(state, indent=2, ensure_ascii=False, allow_nan=False))
    body = """<!doctype html><html lang="en"><meta charset="utf-8"><title>Segmentation experiment report</title>
<style>body{font:16px system-ui;max-width:1050px;margin:36px auto;padding:0 20px;color:#1c2938}pre{background:#eef2f6;padding:20px;white-space:pre-wrap}a{color:#145ba0}</style>
<h1>Top segmentation experiment</h1><p>Development validation supports model iteration. It is not an independent final test or evidence of production acceptance performance.</p>
<p><a href="history.csv">Training history</a> · <a href="split.json">Group allocation</a> · <a href="dataset/dataset.json">Approved dataset snapshot</a> · <a href="validation/predictions.csv">Validation image results</a></p>
<p>Labels: background 0, inner defect 1, outer defect 2. Image padding is excluded from training loss; evaluation uses the original image geometry. Inner is red; outer is blue.</p><pre>""" + escaped + "</pre></html>"
    (run/"report.html").write_text(body, encoding="utf-8")


def train(cfg, init_checkpoint=None):
    from .common import atomic_json, read_json, sha256, utc_now
    from .project import Project
    torch = require_torch()
    from .model import SmallUNet, segmentation_loss
    cfg = json.loads(json.dumps(cfg, default=str))
    settings = cfg["training"]
    epochs, batch_size, size = int(settings["epochs"]), int(settings["batch_size"]), int(settings["image_size"])
    if epochs < 1 or batch_size < 1 or not 32 <= size <= 4096:
        raise ValueError("epochs and batch_size must be positive; image_size must be between 32 and 4096.")
    learning_rate = float(settings["learning_rate"])
    if not math.isfinite(learning_rate) or learning_rate <= 0:
        raise ValueError("learning_rate must be positive and finite.")
    base = int(settings["base_channels"])
    if not 4 <= base <= 64:
        raise ValueError("base_channels must lie between 4 and 64.")
    device = select_device(settings.get("device", "cpu"))
    seed = int(settings.get("seed", 42))
    torch.set_num_threads(max(1, int(settings.get("cpu_threads", min(4, os.cpu_count() or 1)))))
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    if hasattr(torch.backends, "cudnn"):
        torch.backends.cudnn.deterministic, torch.backends.cudnn.benchmark = True, False
    previous = None
    if init_checkpoint:
        model, previous, _ = load_model(init_checkpoint, str(device))
        if previous["base_channels"] != base or previous["image_size"] != size:
            raise ValueError("Fine-tuning requires the predecessor base_channels and image_size. Keep preprocessing fixed for this pilot.")
        if previous.get("group_regex") != cfg.get("group_regex"):
            raise ValueError("Fine-tuning requires the predecessor group_regex so held-out units cannot silently move into training.")
    else:
        model = SmallUNet(base).to(device)
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "_" + uuid.uuid4().hex[:8]
    run = Path(cfg["output_dir"])/"runs"/run_id
    run.mkdir(parents=True, exist_ok=False)
    state = {"schema_version": 1, "run_id": run_id, "status": "preparing", "created_at": utc_now(),
             "model_type": "small_unet_v1", "classes": CLASSES, "pretrained": False,
             "device": str(device), "torch_version": str(torch.__version__), "base_channels": base,
             "parameter_count": sum(p.numel() for p in model.parameters()), "image_size": size,
             "input_normalization": "RGB / 255", "resize": "aspect-preserving fit, black pad, mask pad ignored (255)",
             "initial_checkpoint": str(Path(init_checkpoint).resolve()) if init_checkpoint else None,
             "initial_checkpoint_sha256": sha256(Path(init_checkpoint)) if init_checkpoint else None,
             "evaluation_scope": "development validation, not independent final test", "warnings": []}
    atomic_json(run/"config.json", cfg); atomic_json(run/"model_state.json", state)
    started = time.perf_counter()
    try:
        snapshot_path = Path(Project(cfg).snapshot(run/"dataset"))
        dataset = read_json(snapshot_path)
        if dataset.get("classes") != CLASSES:
            raise ValueError("Dataset class mapping is incompatible with this model.")
        root, records = snapshot_path.parent, dataset["records"]
        if len(records) < max(2, int(settings.get("min_images", 5))):
            raise ValueError("Too few approved images for training. Approve more images or explicitly lower training.min_images (minimum 2).")
        preparation = inspect_training_masks(records, root, size)
        atomic_json(run/"preprocessing_report.json", {"image_size": size, "images": preparation})
        lost = sum(sum(r["lost_components"].values()) for r in preparation)
        if lost:
            state["warnings"].append(f"{lost} annotated defect components disappear during training resize. Increase training.image_size and inspect preprocessing_report.json.")
        split = split_groups(records, settings.get("val_fraction", .2), seed,
                             previous=previous.get("group_split") if previous else None,
                             require_both=bool(settings.get("require_both_defect_classes", True)))
        train_ids, val_ids = set(split["train_ids"]), set(split["validation_ids"])
        train_rows = [r for r in records if r["id"] in train_ids]
        val_rows = [r for r in records if r["id"] in val_ids]
        if split["validation_missing_classes"]:
            state["warnings"].append("Validation lacks target pixels for: " + ", ".join(split["validation_missing_classes"]) + ". Per-class evidence is incomplete.")
        atomic_json(run/"split.json", split)
        state.update(dataset_fingerprint=dataset["fingerprint"], approved_images=len(records), train_images=len(train_rows),
                     validation_images=len(val_rows), independent_groups=len(split["group_split"]),
                     group_definition="configured physical unit or pixel identity; correctness depends on group_regex", status="training")
        pixel_counts = np.zeros(3, dtype=np.int64)
        for row in train_rows:
            image, target = _load_native(row, root)
            _, geometry = prepare_image(image, size)
            small_mask = prepare_mask(target, geometry)
            pixel_counts += np.bincount(small_mask[small_mask != 255], minlength=3)
        if any(pixel_counts[c] == 0 for c in (1, 2) if any(c in r["defect_classes"] for r in train_rows)):
            raise ValueError("An entire training defect class disappeared during resize. Increase training.image_size.")
        class_weights = np.ones(3, dtype=np.float32)
        for c in (1, 2):
            if pixel_counts[c]:
                class_weights[c] = min(10.0, max(1.0, math.sqrt(max(1, pixel_counts[0])/pixel_counts[c])))
        weights = torch.tensor(class_weights, dtype=torch.float32, device=device)
        state.update(class_weights=class_weights.tolist(), training_pixel_counts=pixel_counts.tolist(),
                     loss="weighted cross entropy + 0.5 foreground soft Dice; padding ignored", augmentation=bool(settings.get("augment", True)))
        if previous:
            state["previous_model_on_current_validation"] = _validate(model, val_rows, root, size, device, weights)
            state["comparison_note"] = "Same development validation images; predecessor group roles preserved. Repeated validation is not independent test evidence."
        for warning in state["warnings"]:
            print("Warning: " + warning, flush=True)
        optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=1e-4)
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="min", patience=2, factor=.5)
        # No DataLoader worker processes: simple per-batch loading is reliable on Windows.
        # num_workers is a reserved pilot configuration field, always zero here.
        if int(settings.get("num_workers", 0)) != 0:
            raise ValueError("The pilot loader uses num_workers: 0. Parallel loading is not implemented.")
        history, best_score, best_epoch, stalled = [], -math.inf, 0, 0
        patience = max(1, int(settings.get("patience", 6)))
        atomic_json(run/"model_state.json", state)
        for epoch in range(1, epochs+1):
            epoch_start = time.perf_counter()
            model.train()
            order = list(range(len(train_rows)))
            random.shuffle(order)
            total_loss, sample_count = 0.0, 0
            for offset in range(0, len(order), batch_size):
                arrays, masks = [], []
                for index in order[offset:offset+batch_size]:
                    image, target = _load_native(train_rows[index], root)
                    array, geometry = prepare_image(image, size)
                    target = prepare_mask(target, geometry)
                    if settings.get("augment", True):
                        rotations = random.randrange(4)
                        array, target = np.rot90(array, rotations, (1, 2)), np.rot90(target, rotations)
                        if random.random() < .5:
                            array, target = array[:, :, ::-1], target[:, ::-1]
                    arrays.append(np.ascontiguousarray(array)); masks.append(np.ascontiguousarray(target, dtype=np.int64))
                x, y = torch.from_numpy(np.stack(arrays)).to(device), torch.from_numpy(np.stack(masks)).to(device)
                optimizer.zero_grad(set_to_none=True)
                loss = segmentation_loss(model(x), y, weights)
                if not bool(torch.isfinite(loss)):
                    raise RuntimeError("Training loss became nonfinite; no model was promoted.")
                loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0); optimizer.step()
                total_loss += loss.item()*len(arrays); sample_count += len(arrays)
            validation = _validate(model, val_rows, root, size, device, weights)
            if not math.isfinite(validation["loss"]):
                raise RuntimeError("Validation loss became nonfinite.")
            criterion = "foreground_mean_iou" if validation["foreground_target_classes"] else "negative_validation_loss"
            score = validation["foreground_mean_iou"] if criterion == "foreground_mean_iou" else -validation["loss"]
            if score is None or not math.isfinite(score):
                raise RuntimeError("Validation has no usable selection metric.")
            scheduler.step(validation["loss"])
            improved = score > best_score + 1e-8
            if improved:
                best_score, best_epoch, stalled = score, epoch, 0
            else:
                stalled += 1
            record = {"epoch": epoch, "train_loss": total_loss/sample_count, "validation_loss": validation["loss"],
                      "foreground_mean_iou": validation["foreground_mean_iou"], "foreground_mean_dice": validation["foreground_mean_dice"],
                      "inner_iou": validation["classes"]["inner"]["iou"], "outer_iou": validation["classes"]["outer"]["iou"],
                      "learning_rate": optimizer.param_groups[0]["lr"], "seconds": time.perf_counter()-epoch_start}
            history.append(record)
            checkpoint = {"schema_version": 1, "model_type": "small_unet_v1", "classes": CLASSES,
                          "image_size": size, "base_channels": base, "epoch": epoch, "run_id": run_id,
                          "max_image_pixels": int(cfg.get("max_image_pixels", 25_000_000)),
                          "dataset_fingerprint": dataset["fingerprint"], "group_regex": cfg.get("group_regex"),
                          "group_split": {**(previous.get("group_split", {}) if previous else {}), **split["group_split"]},
                          "model_state_dict": {k: v.detach().cpu().clone() for k, v in model.state_dict().items()},
                          "validation_metrics": validation, "normalization": "RGB / 255", "pretrained": False}
            if improved:
                _checkpoint_save(run/"best.pt", checkpoint)
            checkpoint.update(optimizer_state_dict=optimizer.state_dict(), scheduler_state_dict=scheduler.state_dict(),
                              torch_rng_state=torch.get_rng_state(), python_rng_state=random.getstate(),
                              best_epoch=best_epoch, best_score=best_score)
            _checkpoint_save(run/"last.pt", checkpoint)
            with (run/"history.csv").open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=list(record))
                writer.writeheader(); writer.writerows(history)
            state.update(last_epoch=epoch, best_epoch=best_epoch, selection_metric=criterion,
                         best_selection_score=best_score, latest_validation=validation,
                         elapsed_seconds=time.perf_counter()-started, updated_at=utc_now())
            atomic_json(run/"model_state.json", state); _report(run, state)
            print(f"Epoch {epoch}/{epochs}: train_loss={record['train_loss']:.4f}, validation_loss={validation['loss']:.4f}, {criterion}={score:.4f}", flush=True)
            if stalled >= patience:
                break
        model, best_checkpoint, _ = load_model(run/"best.pt", str(device))
        final_metrics = _validate(model, val_rows, root, size, device, weights, run/"validation")
        state.update(status="completed", completed_at=utc_now(), best_checkpoint="best.pt", last_checkpoint="last.pt",
                     best_checkpoint_sha256=sha256(run/"best.pt"), last_checkpoint_sha256=sha256(run/"last.pt"),
                     best_validation=final_metrics, elapsed_seconds=time.perf_counter()-started,
                     stopped_early=len(history)<epochs)
        if previous:
            old = state["previous_model_on_current_validation"]
            state["comparison"] = {"previous": old, "current": final_metrics,
                "foreground_mean_iou_delta": final_metrics["foreground_mean_iou"]-old["foreground_mean_iou"]
                    if final_metrics["foreground_mean_iou"] is not None and old["foreground_mean_iou"] is not None else None}
            atomic_json(run/"comparison.json", state["comparison"])
        atomic_json(run/"model_state.json", state); _report(run, state)
    except BaseException as exc:
        state.update(status="interrupted" if isinstance(exc, KeyboardInterrupt) else "failed", error=str(exc), updated_at=utc_now(), elapsed_seconds=time.perf_counter()-started)
        atomic_json(run/"model_state.json", state); _report(run, state)
        raise
    return run
