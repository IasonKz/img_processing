"""Search lifecycle checks plus real CPU training on tiny synthetic images.

The tiny network keeps correctness checks fast; it is not a performance claim
about any user dataset or the pretrained model families.
"""
from __future__ import annotations

import importlib.util
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch

import numpy as np
from PIL import Image

from nilt.common import DEFAULTS, merge_dict, read_json, sha_file, write_csv, write_json
from nilt.data import pixel_signature
from nilt.search import search_settings, suggest_config

AVAILABLE = all(importlib.util.find_spec(name) for name in ("optuna", "torch", "torchvision"))


def fixture(root, models=None):
    root = Path(root)
    run, data = root / "run", root / "data"
    run.mkdir()
    rows = []
    for label in (0, 1):
        for split in ("train", "val", "threshold", "selection", "test"):
            for i in range(2):
                path = data / f"{label}_{split}_{i}.png"
                path.parent.mkdir(exist_ok=True)
                rng = np.random.default_rng(len(rows) + 3)
                pixels = rng.integers(10 + label * 100, 60 + label * 100, (16, 16, 3), dtype=np.uint8)
                Image.fromarray(pixels).save(path)
                rows.append({"path": str(path), "relative_path": path.name, "label": label,
                             "class_name": "bad" if label == 0 else "good", "group": path.stem,
                             "split": split, "pixel_hash": pixel_signature(path)[0]})
    cfg = merge_dict(DEFAULTS, {
        "task": "vig", "profile": "laptop", "pilot": True, "pretrained": False,
        "data_root": str(data), "output_root": str(root / "results"), "weights_dir": str(root / "weights"),
        "device": "cpu", "cpu_threads": 1, "num_workers": 0, "image_size": 32, "resize": "pad",
        "models": models or ["resnet18"], "seeds": [42], "ensembles": False, "export_images": False,
        "augmentation": {"rotation90": True, "brightness": 0, "contrast": 0, "rotation_degrees": 0},
        "training": {"epochs": 2, "patience": 5, "batch_size": 2, "eval_batch_size": 2,
                     "accumulation_steps": 1, "amp": False},
        "search": {"total_budget_seconds": 120, "max_trials_per_model": 1,
                   "minimum_trial_seconds": .001, "min_finetune_epochs": 1,
                   "space": {"mode": ["head_only"], "scheduler": ["constant"],
                             "imbalance": ["none"], "effective_batch_size": [2]}},
    })
    write_json(run / "config.json", cfg)
    write_csv(run / "manifest.csv", rows)
    write_json(run / "data_location.json", {"data_root": str(data)})
    write_json(run / "integrity.json", {"config_sha256": sha_file(run / "config.json"),
                                       "manifest_sha256": sha_file(run / "manifest.csv")})
    return run, cfg, rows


def tiny_model(*args, **kwargs):
    import torch
    model = torch.nn.Sequential(torch.nn.Conv2d(3, 4, 3, padding=1), torch.nn.ReLU(),
                                torch.nn.AdaptiveAvgPool2d(1), torch.nn.Flatten(), torch.nn.Linear(4, 2))
    return model, model[-1]


@unittest.skipUnless(AVAILABLE, "Search integration requires Optuna and PyTorch")
class SearchIntegrationTests(unittest.TestCase):
    def test_real_cpu_training_selection_and_no_test_access(self):
        from nilt import engine, search, workflow
        seen = []
        original = engine.train_one

        def recorded(*args, **kwargs):
            seen.append({r["split"] for r in args[2]})
            return original(*args, **kwargs)

        with tempfile.TemporaryDirectory() as temporary:
            run, _, rows = fixture(temporary)
            test_hashes = {row["path"]: sha_file(row["path"]) for row in rows if row["split"] == "test"}
            with patch.object(engine, "make_model", tiny_model), patch.object(engine, "train_one", recorded):
                search.run_search(run)
            self.assertEqual(seen, [{"train", "val"}])
            selected = read_json(run / "selected.json")
            self.assertEqual(selected["members"][0]["architecture"], "resnet18")
            self.assertIn("config", selected["members"][0])
            self.assertFalse((run / "final_test_summary.json").exists())
            self.assertEqual(test_hashes, {path: sha_file(path) for path in test_hashes})
            self.assertEqual(read_json(run / "search_status.json")["status"], "SELECTED")
            self.assertEqual(len(read_json(run / "search_shortlist.json")["candidates"]), 1)
            actual = workflow.member_runtime_config(run, selected["members"][0], workflow.open_run(run)[0])
            self.assertEqual(actual["training"]["mode"], "head_only")
            config = run / selected["members"][0]["config"]
            config.write_text(config.read_text() + " ", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "configuration changed"):
                workflow.member_runtime_config(run, selected["members"][0], workflow.open_run(run)[0])

    def test_operator_pause_preserves_optuna_trial_then_resumes_checkpoint(self):
        from nilt import engine, search
        original = engine.train_one
        with tempfile.TemporaryDirectory() as temporary:
            run, cfg, _ = fixture(temporary)

            def pause_after_epoch(*args, **kwargs):
                callback = kwargs["progress_callback"]

                def callback_and_pause(progress):
                    callback(progress)
                    write_json(run / "control.json", {"action": "pause"})
                kwargs["progress_callback"] = callback_and_pause
                return original(*args, **kwargs)

            with patch.object(engine, "make_model", tiny_model), patch.object(engine, "train_one", pause_after_epoch):
                search.run_search(run)
            self.assertEqual(read_json(run / "search_status.json")["status"], "SEARCH_PAUSED")
            self.assertTrue((run / "search/resnet18/trial_00000/last.pt").exists())
            study = search._study("resnet18", cfg, run)
            self.assertEqual([t.state.name for t in study.trials], ["RUNNING"])
            with patch.object(engine, "make_model", tiny_model):
                search.run_search(run, resume=True)
            study = search._study("resnet18", cfg, run)
            self.assertEqual([t.state.name for t in study.trials], ["COMPLETE"])
            self.assertEqual(read_json(run / "search_status.json")["status"], "SELECTED")

    def test_deadline_starts_no_trial_and_trial_spaces_are_conditional(self):
        import optuna
        from nilt import search
        with tempfile.TemporaryDirectory() as temporary:
            run, cfg, _ = fixture(temporary)
            with patch("nilt.engine.train_one", side_effect=AssertionError("Must not train beyond deadline")):
                search.run_search(run, deadline=time.time() - 1)
            self.assertEqual(read_json(run / "search_status.json")["total_trials"], 0)
            study = optuna.create_study()
            trial = study.ask()
            proposed = suggest_config(trial, "resnet18", cfg)
            self.assertNotIn("learning_rate", trial.params)
            self.assertEqual(proposed["image_size"], cfg["image_size"])
            pc_trial = study.ask()
            suggest_config(pc_trial, "patchcore", cfg)
            self.assertEqual(set(pc_trial.params), {"coreset_size", "projection_dim"})

    def test_requested_model_without_complete_trial_marks_comparison_incomplete(self):
        from nilt import search, engine
        original = engine.train_one
        with tempfile.TemporaryDirectory() as temporary:
            run, _, _ = fixture(temporary, models=["resnet18", "efficientnet_b0"])

            def fail_second(name, *args, **kwargs):
                if name == "efficientnet_b0":
                    raise RuntimeError("CUDA out of memory: synthetic injected lifecycle failure")
                return original(name, *args, **kwargs)

            with patch.object(engine, "make_model", tiny_model), patch.object(engine, "train_one", fail_second):
                search.run_search(run)
            self.assertFalse(read_json(run / "selected.json")["comparison_complete"])
            status = read_json(run / "search_status.json")
            self.assertEqual(status["failed_trials"], 1)
            self.assertEqual(status["completed_trials"], 1)
            self.assertIn("OOM", (run / "trials.csv").read_text())

    def test_fixed_seed_confirmations_keep_every_seed_and_report_variation(self):
        from nilt import search, engine
        with tempfile.TemporaryDirectory() as temporary:
            run, cfg, _ = fixture(temporary)
            cfg["seeds"] = [42, 123]
            write_json(run / "config.json", cfg)
            integrity = read_json(run / "integrity.json")
            integrity["config_sha256"] = sha_file(run / "config.json")
            write_json(run / "integrity.json", integrity)
            with patch.object(engine, "make_model", tiny_model):
                search.run_search(run)
            shortlist = read_json(run / "search_shortlist.json")
            self.assertTrue(shortlist["confirmations_finalized"])
            candidate = shortlist["candidates"][0]
            self.assertEqual(set(candidate["validation_seed_scores"]), {"42", "123"})
            self.assertEqual(len(candidate["members"]), 2)
            self.assertTrue(candidate["confirmation_complete"])
            self.assertIsNotNone(candidate["validation_seed_ap_std"])
            self.assertEqual(read_json(run / "search_confirmations.json")[0]["state"], "COMPLETE")
            self.assertEqual(len(read_json(run / "selected.json")["members"]), 2)

    def test_pruning_waits_for_each_trials_finetuning_stage(self):
        from nilt import search
        with tempfile.TemporaryDirectory() as temporary:
            run, cfg, rows = fixture(temporary)
            cfg["training"]["epochs"] = 4
            cfg["search"]["min_finetune_epochs"] = 2
            cfg["search"]["space"]["mode"] = ["full"]
            study = search._study("resnet18", cfg, run)
            reached = []

            def report_stages(*args, **kwargs):
                callback = kwargs["progress_callback"]
                for epoch, fine in ((1, 0), (2, 1), (3, 2)):
                    reached.append(epoch)
                    callback({"epoch": epoch, "best_val_pr_auc_bad": .5,
                              "val_pr_auc_bad": .5, "finetune_epochs": fine})
                raise AssertionError("Trial should be pruned after two fine-tuning epochs.")

            with patch("nilt.engine.train_one", report_stages), patch("optuna.trial.Trial.should_prune", return_value=True) as should_prune:
                result = search._run_trial(run, "resnet18", study, rows, cfg, {"resnet18": study},
                                           time.time() + 60, time.time() + 60)
            self.assertEqual(result, "pruned")
            self.assertEqual(reached, [1, 2, 3])
            self.assertEqual(should_prune.call_count, 1)
            self.assertEqual(study.trials[0].state.name, "PRUNED")

    def test_classic_training_cooperative_pause_is_not_failure(self):
        from nilt import workflow, engine
        with tempfile.TemporaryDirectory() as temporary:
            run, _, _ = fixture(temporary)
            checkpoint = run / "models/resnet18_seed42/last.pt"
            with patch.object(engine, "make_model", tiny_model):
                returned = workflow.run_training(run, stop_check=lambda: checkpoint.exists())
            self.assertEqual(returned, run)
            self.assertEqual(read_json(run / "model_state.json")["status"], "PAUSED")
            self.assertTrue(checkpoint.exists())
            self.assertFalse((run / "failed_candidates.json").exists())
            self.assertFalse((run / "operation.lock").exists())
            with patch.object(engine, "make_model", tiny_model):
                workflow.run_training(run)
            self.assertTrue((run / "selected.json").exists())

    def test_patchcore_confirmations_are_diagnostics_and_keep_primary_exportable(self):
        """Orchestration test: opaque checkpoints verify membership, not inference."""
        from nilt import search
        with tempfile.TemporaryDirectory() as temporary:
            run, cfg, rows = fixture(temporary, models=["patchcore"])
            cfg["seeds"] = [42, 123]
            primary = run / "search/patchcore/trial_00000"
            primary.mkdir(parents=True)
            checkpoint = primary / "best.pt"
            checkpoint.write_bytes(b"opaque primary PatchCore checkpoint")
            write_json(primary / "config.json", cfg)
            member = {"checkpoint": checkpoint.relative_to(run).as_posix(), "sha256": sha_file(checkpoint),
                      "architecture": "patchcore", "config": (primary / "config.json").relative_to(run).as_posix(),
                      "config_sha256": sha_file(primary / "config.json")}
            shortlist = {"candidates": [{"name": "patchcore_trial00000", "architecture": "patchcore",
                                         "val_pr_auc_bad": .65, "members": [member]}], "failures": []}

            def fake_confirmation(name, seed, rows, cfg, target, **kwargs):
                target.mkdir(parents=True, exist_ok=True)
                path = target / "best.pt"
                path.write_bytes(b"opaque diagnostic PatchCore checkpoint")
                write_json(target / "completed.json", {"checkpoint_sha256": sha_file(path), "best_val_pr_auc_bad": .85})
                return path

            with patch("nilt.engine.train_one", fake_confirmation):
                result = search._confirm_shortlist(run, shortlist, cfg, rows, time.time() + 60)
            candidate = result["candidates"][0]
            self.assertEqual(candidate["members"], [member])
            self.assertEqual(candidate["val_pr_auc_bad"], .65)
            self.assertEqual(candidate["validation_seed_scores"], {"42": .65, "123": .85})
            self.assertTrue(candidate["confirmation_complete"])
            self.assertEqual(candidate["confirmation_aggregation"], "diagnostic_only_primary_seed_retained")
            record = read_json(run / "search_confirmations.json")[0]
            self.assertEqual(record["state"], "COMPLETE")
            self.assertEqual(record["role"], "diagnostic_only")
            self.assertFalse(record["used_for_prediction"])
            self.assertTrue((run / record["checkpoint"]).exists())


if __name__ == "__main__":
    unittest.main()
