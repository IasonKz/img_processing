"""Exact threshold decisions on explicit operator-supplied labelled datasets."""
from collections import defaultdict
from fractions import Fraction
import heapq
import math
from pathlib import Path
import time

import numpy as np

from .common import LABELS, sha_file, write_csv, write_json

GOALS = ("min_fp", "min_fn", "min_mistakes", "fp_fn_ratio")


def options(value):
    result = {"mode": "double", "goal": "min_fp", "fp_weight": 10., "fn_weight": 5.,
              "review_weight": .05, "max_review_rate": 1., **(value or {})}
    if result["mode"] not in ("single", "double") or result["goal"] not in GOALS:
        raise ValueError("Choose single/double thresholds and a supported error goal.")
    for key in ("fp_weight", "fn_weight", "review_weight", "max_review_rate"):
        v = result[key]
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v < 0:
            raise ValueError(f"{key} must be finite and nonnegative.")
    if result["max_review_rate"] > 1 or not result["fp_weight"] + result["fn_weight"]:
        raise ValueError("Review rate must be at most one and at least one error weight must be positive.")
    return result


def counts(labels, scores, low, high):
    labels, scores = np.asarray(labels), np.asarray(scores, dtype=float)
    bad, good = labels == 0, labels == 1
    return {"fp": int(np.sum(good & (scores >= high))), "fn": int(np.sum(bad & (scores < low))),
            "tp": int(np.sum(bad & (scores >= high))), "tn": int(np.sum(good & (scores < low))),
            "review": int(np.sum((scores >= low) & (scores < high))), "n": len(labels),
            "n_good": int(good.sum()), "n_bad": int(bad.sum())}


def _key(fp, fn, review, ng, nb, n, cfg):
    if cfg["goal"] == "min_fp":
        return fp, fn, review
    if cfg["goal"] == "min_fn":
        return fn, fp, review
    if cfg["goal"] == "min_mistakes":
        return fp + fn, review, fp, fn
    cost = (Fraction(str(cfg["fp_weight"])) * fp / ng + Fraction(str(cfg["fn_weight"])) * fn / nb
            + Fraction(str(cfg["review_weight"])) * review / n)
    return cost, fp + fn, review, fp, fn


def optimize(labels, scores, config=None, stop_check=None):
    """Optimize every distinct attainable decision, including all-equal score ties.

    For double thresholds, the objective separates into lower/upper terms. A
    sliding prefix minimum gives the exact best pair in O(k log k), instead of
    materializing k² pairs. The review limit bounds the permitted prefix window.
    Fraction costs keep weighted tie-breaking exact.
    """
    cfg = options(config)
    labels, scores = np.asarray(labels), np.asarray(scores, dtype=float)
    if (labels.ndim != 1 or scores.shape != labels.shape or not len(labels)
            or not np.isfinite(scores).all() or not set(labels.tolist()) <= {0, 1}):
        raise ValueError("Supply matching finite scores and good/bad labels.")
    ng, nb, n = int(np.sum(labels == 1)), int(np.sum(labels == 0)), len(labels)
    if not ng or not nb:
        raise ValueError("The combined tuning datasets must contain both good and bad examples.")
    values = np.unique(scores)
    above = np.nextafter(values[-1], np.inf)
    if not np.isfinite(above):
        raise ValueError("Scores are too large to represent an all-good threshold.")
    values = np.r_[values, above]
    order = np.argsort(scores, kind="stable")
    indices = np.searchsorted(scores[order], values, side="left")
    bad_prefix = np.r_[0, np.cumsum(labels[order] == 0)][indices]
    good_prefix = np.r_[0, np.cumsum(labels[order] == 1)][indices]
    single, frontier, heap, best, best_key = [], [], [], None, None
    review_limit = math.floor(cfg["max_review_rate"] * n + 1e-12)
    for j, threshold in enumerate(values):
        if stop_check and stop_check():
            raise InterruptedError("Threshold tuning stopped by operator.")
        fp, fn = ng - int(good_prefix[j]), int(bad_prefix[j])
        single.append({"good_threshold": float(threshold), "bad_threshold": float(threshold),
                       "fp": fp, "fn": fn, "review": 0, "mistakes": fp + fn})
        if cfg["mode"] == "single":
            i = j
        else:
            if cfg["goal"] == "fp_fn_ratio":
                prefix_cost = (Fraction(str(cfg["fn_weight"])) * fn / nb
                               - Fraction(str(cfg["review_weight"])) * int(indices[j]) / n)
                prefix_key = (prefix_cost, fn, -int(indices[j]), -j)
            else:
                prefix_key = (fn, -int(indices[j]), -j)
            heapq.heappush(heap, (prefix_key, j))
            minimum_index = int(indices[j]) - review_limit
            while heap and indices[heap[0][1]] < minimum_index:
                heapq.heappop(heap)
            i = heap[0][1]
        low_fn = int(bad_prefix[i])
        review = int(indices[j] - indices[i])
        key = _key(fp, low_fn, review, ng, nb, n, cfg)
        row = {"good_threshold": float(values[i]), "bad_threshold": float(threshold),
               "fp": fp, "fn": low_fn, "review": review, "mistakes": fp + low_fn}
        frontier.append(row)
        if best_key is None or key < best_key:
            best, best_key = row, key
    ranked = sorted(frontier, key=lambda r: _key(r["fp"], r["fn"], r["review"], ng, nb, n, cfg))
    metrics = counts(labels, scores, best["good_threshold"], best["bad_threshold"])
    metrics.update(mistakes=metrics["fp"] + metrics["fn"], review_rate=metrics["review"] / n,
                   fp_rate=metrics["fp"] / ng, fn_rate=metrics["fn"] / nb)
    return {"config": cfg, "best": {**best, **metrics}, "single_curve": single,
            "frontier": ranked[:50], "unique_score_boundaries": len(values), "complete": True,
            "attainable_combinations": len(values) if cfg["mode"] == "single" else len(values) * (len(values) + 1) // 2,
            "algorithm": "exact single sweep" if cfg["mode"] == "single" else "exact prefix optimization of all attainable pairs"}


def run_experiment(request, output, stop_check=None):
    from .decisions import _candidate
    from .workflow import open_run, predict_members
    from .common import EXTENSIONS
    from .dataset_tools import tray_name
    run = Path(request["run"]).resolve()
    cfg, manifest = open_run(run)
    candidate = _candidate(run, request.get("candidate", "selected"))
    cfg = {**cfg, "device": request.get("device", "cpu")}
    datasets = request.get("datasets")
    if not isinstance(datasets, list) or not datasets:
        raise ValueError("Add at least one labelled dataset.")
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    write_json(output / "status.json", {"status": "running", "datasets": len(datasets)})
    records, started = [], time.monotonic()
    for number, dataset in enumerate(datasets, 1):
        root = Path(dataset["path"]).expanduser().resolve()
        if not root.is_dir() or any(not (root / label).is_dir() for label in ("good", "bad")):
            raise ValueError("Tuning datasets need good/ and bad/ folders.")
        # The operator supplies cleaned labels; do not rerun dataset audit/cleaning.
        supplied = []
        for label in ("good", "bad"):
            for path in sorted((root / label).rglob("*")):
                if path.is_file() and path.suffix.lower() in EXTENSIONS:
                    if path.is_symlink() or not path.resolve().is_relative_to(root):
                        raise ValueError("Tuning images must stay inside their dataset.")
                    supplied.append({"path": path, "relative_path": path.relative_to(root).as_posix(), "true_class": label})
        selected_trays = dataset.get("trays", [])
        excluded_trays = dataset.get("excluded_trays", [])
        rows = [{"path": str(row["path"]), "relative_path": row["relative_path"], "label": LABELS[row["true_class"]],
                 "tray": tray_name(row["path"], root)} for row in supplied
                if (not selected_trays or tray_name(row["path"], root) in selected_trays)
                and tray_name(row["path"], root) not in excluded_trays]
        if not rows:
            raise ValueError(f"No labelled images in dataset {root} for the selected trays.")
        print(f"Scoring dataset {number}/{len(datasets)}: {root} ({len(rows)} images)", flush=True)
        scores, _ = predict_members(run, candidate["members"], rows, cfg, stop_check=stop_check)
        for row, score in zip(rows, scores):
            records.append({"dataset": number, "dataset_name": dataset.get("name") or root.name,
                            "dataset_root": str(root), "relative_path": row["relative_path"], "tray": row["tray"],
                            "label": row["label"], "score": float(score), "file_sha256": sha_file(row["path"])})
        write_json(output / "status.json", {"status": "running", "completed_datasets": number, "images": len(records)})
    result = optimize([r["label"] for r in records], [r["score"] for r in records], request.get("options"), stop_check)
    best = result["best"]
    groups = defaultdict(list)
    for row in records:
        groups[(row["dataset"], row["dataset_name"], row["tray"])].append(row)
    breakdown = [{"dataset": key[0], "dataset_name": key[1], "tray": key[2],
                  **counts([r["label"] for r in rows], [r["score"] for r in rows], best["good_threshold"], best["bad_threshold"])}
                 for key, rows in groups.items()]
    overlap_paths = {str(Path(row["path"]).resolve()) for row in manifest}
    overlap = sum(str(Path(row["dataset_root"]) / row["relative_path"]) in overlap_paths for row in records)
    report = {**result, "run": str(run), "task": cfg["task"], "candidate": candidate["name"],
              "roi_scope": cfg.get("roi_scope", "whole_image"),
              "datasets": datasets, "per_tray": breakdown, "elapsed_seconds": time.monotonic() - started,
              "source_scope": "operator-supplied threshold tuning data", "development_path_overlap": overlap,
              "score_type": candidate.get("score_type", "bad_probability_uncalibrated"),
              "qualification_status": "EXPLORATORY_THRESHOLD_TUNING", "models": candidate["members"]}
    write_csv(output / "scores.csv", records)
    write_csv(output / "single_thresholds.csv", result["single_curve"])
    write_csv(output / "threshold_candidates.csv", result["frontier"])
    write_csv(output / "per_tray.csv", breakdown)
    write_json(output / "report.json", report)
    write_json(output / "status.json", {"status": "completed", "images": len(records)})
    print(f"TUNING: {output}", flush=True)
    return report
