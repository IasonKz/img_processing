#!/usr/bin/env bash
set -euo pipefail

studio_project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
studio_python="${STUDIO_PYTHON:-$studio_project_dir/.venv-studio5/bin/python}"

if [[ ! -x "$studio_python" ]]; then
    printf '%s\n' 'Python environment not found. See docs/INSTALLATION_LINUX.md.' >&2
    printf '%s\n' 'Create .venv-studio5 or set STUDIO_PYTHON to an existing Python executable.' >&2
    exit 1
fi

cd -- "$studio_project_dir"
exec "$studio_python" inspection.py dashboard --config project.yaml "$@"
