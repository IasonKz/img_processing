"use strict";
// Full local API/export path using synthetic saved evidence. No route interception.
const {firefox}=require('playwright'),{spawn}=require('node:child_process');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),out=path.resolve(process.argv[2]||path.join(os.tmpdir(),'inspection-v61-e2e'));
const temporary=fs.mkdtempSync(path.join(os.tmpdir(),'inspection-v61-evidence-'));
fs.mkdirSync(out,{recursive:true});
const save=(base,name,obj)=>{const p=path.join(base,name);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,JSON.stringify(obj));};
const hash=value=>crypto.createHash('sha256').update(value).digest('hex');
fs.writeFileSync(path.join(temporary,'project.yaml'),'schema_version: 3\nproject_name: SYNTHETIC_BROWSER_CHECK\npaths:\n  output_root: ./results\n  weights_root: ./weights\n  incoming_root: ./incoming\n  classification_output_root: ./classified\ntasks:\n  vig:\n    enabled: true\n    dataset_root: ./data/vig\n');
const run=path.join(temporary,'results','vig','SYNTHETIC_run');
save(run,'config.json',{task:'vig',models:['resnet18'],device:'cpu',dataset_fingerprint:'SYNTHETIC_RENDERING_ONLY'});
save(run,'model_state.json',{status:'TRAINED',note:'SYNTHETIC fixture; no actual training'});
save(run,'models/resnet18/progress.json',{status:'completed',best_epoch:4,best_val_pr_auc_bad:.75});
save(run,'models/resnet18/completed.json',{checkpoint_sha256:'a'.repeat(64)});
const originals=Array.from({length:12},(_,i)=>({relative_path:`${i%3===0?'bad':'good'}/C000008${i<6?3:4}_Rc01_Cc${String(i+1).padStart(2,'0')}_vig.png`,reference_label:i%3===0?'bad':'good',file_sha256:hash('SYNTHETIC IMAGE '+i)}));
fs.writeFileSync(path.join(run,'manifest.csv'),'relative_path,split,class_name,file_sha256\n'+originals.map((r,i)=>`${r.relative_path},${i<6?'train':i<9?'val':'test'},${r.reference_label},${r.file_sha256}`).join('\n')+'\n');
save(run,'final_test_summary.json',{evaluation_role:'SYNTHETIC recorded final test',metrics:{accuracy:1},note:'Synthetic rendering only'});
fs.mkdirSync(path.join(run,'final_test'),{recursive:true});fs.writeFileSync(path.join(run,'final_test','predictions.csv'),'relative_path,true_class,predicted_class\n'+originals.slice(9).map(r=>`${r.relative_path},${r.reference_label},${r.reference_label}`).join('\n')+'\n');
for(let k=0;k<2;k++){
 const session=path.join(temporary,'classified','SYNTHETIC_session_'+k);const records=originals.map((r,i)=>({id:String(i),status:'ok',...r,prediction:i===1?'review':i===0&&k===0?'good':r.reference_label,bad_score:i%3===0?.9:.1}));
 save(session,'review_session.json',{format:'inspection_review_session_v4',id:path.basename(session),kind:'classification',created_utc:'2026-09-28T00:00:00Z',metadata:{task:'vig',candidate:'SYNTHETIC_'+k}});
 save(session,'review_progress.json',{status:'completed',completed:12,total:12});save(session,'summary.json',{status:'completed'});
 for(const [i,r]of records.entries())save(session,`records/${i}.json`,r);
 save(session,'reviews.json',{items:{0:{label:'good',note:'Synthetic operator reference'},2:{label:'bad',note:'Synthetic operator reference'}}});
 save(session,'applied_decision.json',{task:'vig',source_run_id:path.basename(run),source_config_sha256:hash(fs.readFileSync(path.join(run,'config.json'))),source_manifest_sha256:hash(fs.readFileSync(path.join(run,'manifest.csv'))),candidate:{name:'SYNTHETIC_model_'+k},mode:'triage',good_threshold:.2,bad_threshold:.8});
}
const server=spawn(process.env.STUDIO_PYTHON||'python',['inspection.py','dashboard','--config',path.join(temporary,'project.yaml'),'--port','18767','--no-browser'],{cwd:root,stdio:['ignore','pipe','pipe']});
let browser,serverLog='',errors=[];
async function main(){
 await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Startup timeout '+serverLog)),20000);server.stdout.on('data',c=>{serverLog+=c.toString();if(serverLog.includes('Local dashboard:')){clearTimeout(timer);resolve();}});server.stderr.on('data',c=>serverLog+=c.toString());server.once('exit',code=>{clearTimeout(timer);reject(Error('Dashboard exited '+code+' '+serverLog));});});
 browser=await firefox.launch({headless:true,env:{...process.env,MOZ_DISABLE_CONTENT_SANDBOX:'1'},firefoxUserPrefs:{'security.sandbox.content.level':0}});
 const context=await browser.newContext({viewport:{width:1460,height:1080}}),page=await context.newPage();page.on('pageerror',error=>errors.push(error.message));
 await page.goto('http://127.0.0.1:18767');await page.waitForFunction(()=>document.querySelector('#connection').textContent.includes('Connected'));
 await page.locator('#nav-quality').click();await page.waitForFunction(()=>document.querySelectorAll('#quality-sessions input').length===2);
 await page.locator('#quality-task').selectOption('vig');assert.equal(await page.locator('#quality-sessions input').count(),2,'Actual nested metadata.task is filterable');
 await page.locator('#quality-title').fill('SYNTHETIC end-to-end evidence verification');await page.locator('#quality-notes').fill('Synthetic saved records only. No real model training or performance claim.');
 await page.locator('#quality-select-runs').click();await page.locator('#quality-select-sessions').click();
 const previewResponse=page.waitForResponse(response=>response.url().endsWith('/api/quality/preview'));await page.locator('#quality-preview').click();
 const response=await previewResponse;assert.equal(response.status(),200);const report=(await response.json()).report;
 assert.equal(report.images.length,24);assert.equal(report.sessions.length,2);assert.equal(report.sessions[0].metrics_reference.n_labeled,12);assert.equal(report.sessions[0].metrics_operator.n_labeled,2);
 assert.equal(report.trays.length,4);assert.equal(report.comparisons[0].common_images,12);assert.equal(report.comparisons[0].decision_disagreements,1);
 assert.equal(report.runs[0].final_test.per_tray.length,1);assert.ok(await page.locator('#quality-evidence svg').count()>1);
 const trainingCard=page.locator('#quality-evidence > article').filter({has:page.locator('h2',{hasText:'Training provenance'})});await trainingCard.locator('details.quality-run').first().evaluate(e=>e.open=true);await trainingCard.locator('summary',{hasText:'Recorded final-test evidence'}).click();assert.match(await trainingCard.textContent(),/published prediction records/);await trainingCard.screenshot({path:path.join(out,'SYNTHETIC-training-and-recorded-test.png')});
 const trayCard=page.locator('#quality-evidence > article').filter({has:page.locator('h2',{hasText:'Tray quality and decision outcomes'})});await trayCard.screenshot({path:path.join(out,'SYNTHETIC-real-api-trays.png')});
 await page.locator('#quality-reference').selectOption('operator');const references=page.locator('#quality-evidence > article').filter({has:page.locator('h2',{hasText:'Prediction versus reference'})});await references.locator('details.quality-run').first().evaluate(e=>e.open=true);assert.match(await references.textContent(),/2 labeled/);await references.screenshot({path:path.join(out,'SYNTHETIC-operator-reference.png')});
 const exportResponse=page.waitForResponse(response=>response.url().endsWith('/api/quality/export'));await page.locator('#quality-export').click();const resultResponse=await exportResponse;assert.equal(resultResponse.status(),200);const result=await resultResponse.json();
 const html=await page.request.get('http://127.0.0.1:18767'+result.html_url);assert.equal(html.status(),200);assert.match(await html.text(),/SYNTHETIC end-to-end evidence verification/);
 const files=[];for(const link of result.file_links){const response=await page.request.get('http://127.0.0.1:18767'+link.url);assert.equal(response.status(),200,link.name);files.push({name:link.name,status:response.status()});}
 assert.ok(files.some(f=>f.name.endsWith('.csv')));assert.ok(files.some(f=>f.name.endsWith('.json')));assert.deepEqual(errors,[]);
 const evidence={status:'passed',scope:'SYNTHETIC on-disk fixtures through actual local API, report builder, GUI, export and download routes; no interception',image_records:report.images.length,sessions:report.sessions.length,tray_records:report.trays.length,operator_labeled_per_session:2,paired_images:report.comparisons[0].common_images,html_status:html.status(),downloads:files,page_errors:errors,not_tested:['Windows Intel GPU training','real model quality']};
 fs.writeFileSync(path.join(out,'SYNTHETIC-e2e-verification.json'),JSON.stringify(evidence,null,2));console.log(JSON.stringify(evidence,null,2));
}
main().catch(error=>{console.error(error);console.error(serverLog);process.exitCode=1;}).finally(async()=>{if(browser)await browser.close();server.kill('SIGINT');fs.rmSync(temporary,{recursive:true,force:true});});
