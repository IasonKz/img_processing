"""Local annotation and lightweight top-view defect segmentation."""
__version__ = '0.2.0'
