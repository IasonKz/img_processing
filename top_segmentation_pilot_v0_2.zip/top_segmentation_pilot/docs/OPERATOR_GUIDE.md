# Annotation Operator Guide

## Start or continue a project

```bash
python segmentation.py annotate --config project.yaml
```

The command imports working copies automatically when the project is empty and starts the local interface. Existing annotations remain available. The input can contain nested folders; the browser shows one image at a time rather than processing all images into automatically approved labels.

For an import without opening the browser:

```bash
python segmentation.py init --config project.yaml
python segmentation.py status --config project.yaml
```

Run `init` again whenever new image files are added to an existing project's input folder. It imports new copies and preserves existing annotations. Restart or refresh the annotation interface afterward. `annotate` does not rescan an already populated project automatically.

To start the server without automatically opening a browser:

```bash
python segmentation.py annotate --config project.yaml --no-browser
```

Open the printed URL on the same computer. The server binds only to `127.0.0.1`. Keep the terminal running throughout the annotation session.

## Define the annotation consistently

**Inner** and **Outer** identify defect pixels in two inspection regions. They do not mean that the complete inner lens area or entire outer module area should be painted.

Before a labeling session, use the same defect acceptance definitions for every image. Include accepted texture as background. Include scratches, marks, or other unwanted features only when they meet the intended defect definition. Keep boundaries as close to the visible defect as practical; very generous circles also label healthy pixels and will teach that expanded shape to the network.

Use the yellow inner polygon to define the Inner/Outer division. Every annotated pixel is classified automatically from this boundary. Moving the boundary reclassifies existing defect pixels immediately; it does not fill healthy parts of the image. An annotation spanning the boundary contains both classes.

Try **Detect inner boundary** for a local image-based proposal. Inspect the result before approval. When detection cannot identify a reliable contour, use the manual boundary tools. A default clipped-corner octagon is an initial estimate, not a verified contour. Existing ellipse boundaries remain supported.

## Review the automatic proposal

Opening an image for the first time creates a saved **draft** with classical suggestions. The detector:

1. Converts the working RGB image to brightness and applies mild smoothing.
2. Estimates a slowly varying background with a wider Gaussian filter.
3. Subtracts that background to obtain local contrast.
4. Estimates a robust contrast threshold separately inside and outside the inner boundary.
5. Keeps connected components within the configured area limits and assigns their defect class.

The detector excludes the configured lens-boundary band and image-border band. It can flag acceptable texture, reflections, and edges. It can also miss broad or low-contrast defects. An empty proposal means only that no candidates passed these settings.

Adjust the polygon and proposal settings before detailed manual work. Generating proposals again creates a new draft and replaces the current working mask with a fresh detector result. Previously saved revisions remain in the project history; unsaved browser edits are not a saved revision.

## Correct the mask

| Tool | Intended use |
| --- | --- |
| Brush | Paint irregular defect shapes; class is automatic |
| Circle | Drag from center to edge to fill a round defect |
| Ellipse | Drag between opposite bounding-box corners to fill an oval defect |
| Polygon | Trace a defect boundary using several points |
| Rectangle | Mark a rectangular area |
| Eraser | Return selected pixels to background |
| Boundary tools | Draw the inner polygon or an octagon, and adjust its vertices |
| Pan and zoom | Inspect details without changing image or mask resolution |
| Undo / redo | Revert or restore edits in the current browser editing session |

Inner and Outer are location labels; no manual class selection is needed. The eraser removes pixels from every intersecting annotation. Lower overlay opacity, or hide an individual annotation in the list, to inspect its fit against the source image.

The interface retains discrete class indices at native resolution. Zoom affects the display only. Use the on-screen tool hints for drawing gestures and shortcuts.

Click polygon vertices, then press Enter to close the polygon. Hold Shift while drawing a defect ellipse to constrain it to a circle. Brush size is measured in native image pixels.

Start a drag on the background outside the displayed image to pan with any tool selected. A drag that starts inside the image remains a drawing gesture even if it crosses the edge. Space + drag, the middle mouse button and the Pan tool also remain available.

## Keyboard shortcuts

| Shortcut | Action |
| --- | --- |
| `B`, `C`, `E` | Brush, Circle, Ellipse |
| `P`, `R`, `X` | Polygon, Box, Erase |
| `L`, `H` | Inner boundary, Pan |
| `O` | Draw an octagon by dragging its bounding box |
| `Delete` | Delete the selected annotation object |
| `Enter`, `Escape` | Finish polygon, cancel current shape |
| `Space` + drag | Pan image |
| Mouse wheel, `+`, `-` | Zoom |
| `0`, `M` | Fit image, show/hide mask |
| `Ctrl+Z`, `Ctrl+Shift+Z` | Undo, redo |
| `Ctrl+S` | Save draft |
| `Page Up`, `Page Down` | Previous, next image |

Use Command instead of Control on macOS. The **Shortcuts** button opens the same reference in the interface. Text fields retain ordinary text-entry behavior.

## Save and approve

| Action | Result |
| --- | --- |
| Save draft | Save unfinished work as a new revision; exclude it from future datasets |
| Approve and continue | Save the current reviewed defect mask as approved and advance |
| Approve clean and continue | Explicitly approve an empty mask as a clean negative and advance |
| Exclude image & next | Preserve the image and saved work, exclude it from future datasets, and advance |
| Restore image as draft | Restore a rejected image for review; a new approval is required |
| Previous / next | Navigate between images; resolve the unsaved-work prompt when shown |

Do not approve an image merely because the automatic proposal looks plausible at low zoom. Review it first. Real clean images are useful training examples and should be explicitly approved rather than left unannotated.

For a clean image with false-positive proposals, use **Clear defect mask**, inspect the full image, then choose **Approve clean & next**. The clean action requires an empty mask; it does not silently discard remaining defect pixels.

Editing a previously approved image does not change already exported datasets. Save the revised annotation and approve it again to include the new revision in the next export. A draft remains excluded even if an earlier revision was approved.

Undo history includes annotation objects, visibility, deletion and boundary edits. Its memory budget is bounded, so larger images or more complex annotations may retain fewer steps. This editor history does not replace saved revision history. Save important work before closing the browser or stopping the terminal.

Rejection is reversible and never deletes originals. Rejected images remain inspectable and are excluded from future dataset exports even if an older revision was approved. Restore to draft, review, and approve again to include them. Existing exported datasets are immutable and must be regenerated when exclusions should take effect.

## Inspect individual annotations

Open the annotation list to see each closed shape, brush stroke, or connected automatic proposal with a thumbnail. Select an item to highlight it. Toggle its visibility to compare its contour with the image. Delete it to remove its contribution to the mask; undo restores a deletion.

Visibility affects the overlay only: hidden objects still count as annotations and enter the saved training mask. Save the draft or approve the image to persist visibility and deletion changes. Overlapping objects retain their own footprints; deleting one does not erase the part covered by another.

Old flattened masks become connected legacy objects because the earlier version did not record individual strokes. Newly created shapes are retained independently when the image is reopened.

## Export the reviewed data

```bash
python segmentation.py dataset --config project.yaml --output outputs/top_dataset_v1
```

The command creates a new independent dataset with approved image and mask copies. Re-running training also snapshots approved annotations automatically, so a separate export is optional for training and useful for dataset review or transfer.

Record the snapshot fingerprint with any reported result. If the reviewed masks change, create a new dataset snapshot and training run rather than modifying an existing result directory.
