"""Data-integrity tests using generated images; no network or production data."""
from __future__ import annotations

import copy
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
from PIL import Image

from nilt.common import SPLITS, read_csv, read_json, write_csv, write_json
from nilt.data import audit, allocate, discover, make_manifest, read_manifest


def config(root):
    return {"task": "top", "data_root": str(root), "image_size": "auto", "image_size_limit": 4096,
            "resize": "pad", "split_seed": 42,
            "split_fractions": {"train": .55, "val": .1, "threshold": .1, "selection": .1, "test": .15},
            "near_duplicate_distance": -1}


def synthetic_rows(n=30):
    return [{"path": f"/dataset/{label}/{i}.png", "relative_path": f"{label}/{i}.png",
             "class_name": label, "label": cls, "pixel_hash": f"hash_{label}_{i}",
             "group": f"unit_{label}_{i}", "split_hint": ""}
            for label, cls in (("bad", 0), ("good", 1)) for i in range(n)]


def save_image(path, seed, size=(32, 32)):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    values = np.random.default_rng(seed).integers(0, 256, (*size[::-1], 3), dtype=np.uint8)
    Image.fromarray(values).save(path)


class DiscoveryAndAuditTests(unittest.TestCase):
    def test_recursive_class_first_and_split_first_layouts(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            for mode in ("unsplit", "class_first", "split_first"):
                root = tmp / mode
                for c, label in enumerate(("good", "bad")):
                    if mode == "unsplit":
                        path = root / label / "tray" / "nested" / "image.PNG"
                    elif mode == "class_first":
                        path = root / label / "validation" / "tray" / "image.PNG"
                    else:
                        path = root / "valid" / label / "tray" / "image.PNG"
                    save_image(path, c)
                records = discover(root)
                self.assertEqual(len(records), 2)
                self.assertEqual({r[2] for r in records}, {"" if mode == "unsplit" else "val"})

    def test_mixed_layout_is_rejected_without_silently_ignoring_images(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            save_image(root / "good" / "image.png", 1)
            save_image(root / "bad" / "image.png", 2)
            save_image(root / "test" / "good" / "image.png", 3)
            with self.assertRaisesRegex(ValueError, "Mixed class-first"):
                discover(root)

    def test_auto_native_size_above_600(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "images"
            save_image(root / "good" / "a.png", 1, (913, 701))
            save_image(root / "bad" / "b.png", 2, (702, 733))
            cfg = config(root)
            rows = audit(cfg, Path(tmp) / "audit")
            self.assertEqual(cfg["image_size"], 913)
            self.assertEqual({(r["width"], r["height"]) for r in rows}, {(913, 701), (702, 733)})
            self.assertEqual(read_json(Path(tmp) / "audit" / "audit_summary.json")["image_size_requested"], "auto")

    def test_auto_small_inputs_have_minimum_canvas_32(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "images"
            for i, label in enumerate(("good", "bad")):
                save_image(root / label / "a.png", i, (11, 19))
            cfg = config(root)
            audit(cfg, Path(tmp) / "audit")
            self.assertEqual(cfg["image_size"], 32)

    def test_limit_never_silently_resizes_and_fit_is_explicit(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "images"
            for i, label in enumerate(("good", "bad")):
                save_image(root / label / "a.png", i, (150, 100))
            cfg = dict(config(root), image_size_limit=128)
            with self.assertRaisesRegex(ValueError, "Images were not resized"):
                audit(cfg, Path(tmp) / "audit")
            cfg.update(image_size=64, resize="pad")
            with self.assertRaisesRegex(ValueError, "invalid images"):
                audit(cfg, Path(tmp) / "audit")
            cfg["resize"] = "fit"
            rows = audit(cfg, Path(tmp) / "audit")
            self.assertTrue(all(r["width"] == 150 for r in rows))
            self.assertEqual(cfg["image_size"], 64)

    def test_empty_or_ambiguous_group_sources_are_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            write_csv(root / "groups.csv", [], ["relative_path", "group"])
            cfg = dict(config(root), groups_csv=str(root / "groups.csv"))
            with self.assertRaisesRegex(ValueError, "empty"):
                audit(cfg, root / "audit")
            cfg["group_regex"] = r"(?P<group>UNIT[0-9]+)"
            with self.assertRaisesRegex(ValueError, "not both"):
                audit(cfg, root / "audit")

    def test_csv_windows_paths_preserve_explicit_unit_identity(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "images"
            save_image(root / "good" / "tray" / "start.png", 1)
            save_image(root / "bad" / "tray" / "final.png", 2)
            mapping = Path(tmp) / "groups.csv"
            write_csv(mapping, [{"relative_path": "good\\tray\\start.png", "group": "TRAY1_UNIT1"},
                                {"relative_path": "bad\\tray\\final.png", "group": "TRAY1_UNIT1"}])
            rows = audit(dict(config(root), groups_csv=str(mapping)), Path(tmp) / "audit")
            self.assertEqual({r["group"] for r in rows}, {"TRAY1_UNIT1"})
            self.assertEqual({r["label"] for r in rows}, {0, 1})

    def test_exact_duplicates_merge_aliases_but_near_duplicates_do_not(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "images"
            save_image(root / "good" / "UNIT1_a.png", 1)
            image = Image.open(root / "good" / "UNIT1_a.png")
            image.save(root / "good" / "UNIT2_copy.bmp")
            save_image(root / "good" / "UNIT2_other.png", 3)
            save_image(root / "bad" / "UNIT3.png", 2)
            cfg = dict(config(root), group_regex=r"(?P<group>UNIT[0-9]+)", near_duplicate_distance=64)
            rows = audit(cfg, Path(tmp) / "audit")
            self.assertEqual(len(rows), 3)
            good = [r for r in rows if r["label"] == 1]
            self.assertEqual({r["group"] for r in good}, {"UNIT1"})
            self.assertEqual(set(json.loads(good[0]["group_aliases"])), {"UNIT1", "UNIT2"})
            self.assertEqual(next(r for r in rows if r["label"] == 0)["group"], "UNIT3")

    def test_exact_duplicate_across_splits_fails_before_deduplication(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "images"
            for split, seed in (("train", 1), ("test", 1)):
                save_image(root / split / "good" / "a.png", seed)
                save_image(root / split / "bad" / "b.png", seed + 10)
            with self.assertRaisesRegex(ValueError, "different existing splits"):
                audit(config(root), Path(tmp) / "audit")

    def test_near_duplicate_work_is_bounded_even_with_matching_phashes(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "images"
            for c, label in enumerate(("good", "bad")):
                for i in range(20):
                    path = root / label / f"{i}.png"
                    path.parent.mkdir(parents=True, exist_ok=True)
                    Image.new("RGB", (32, 32), (i + c * 50, 20, 30)).save(path)
            cfg = dict(config(root), near_duplicate_distance=64, near_duplicate_report_limit=100000,
                       near_duplicate_comparison_limit=12)
            rows = audit(cfg, Path(tmp) / "audit")
            summary = read_json(Path(tmp) / "audit" / "audit_summary.json")
            self.assertEqual(len(rows), 40)
            self.assertLessEqual(summary["near_duplicate_work_used"], 12)
            self.assertFalse(summary["near_duplicate_search_complete"])


class GroupAllocationTests(unittest.TestCase):
    def test_rarest_feasible_binary_class_is_covered_in_every_partition(self):
        rows = [r for r in synthetic_rows(100) if r["label"] == 1 or int(r["relative_path"].split("/")[1].split(".")[0]) < 5]
        result = allocate(rows, config("unused")["split_fractions"], 7)
        for split in SPLITS:
            labels = [r["label"] for r in result if r["split"] == split]
            self.assertEqual(set(labels), {0, 1})
            self.assertEqual(labels.count(0), 1)

    def test_mixed_label_units_use_one_split_per_physical_unit(self):
        rows = synthetic_rows(5)
        for row in rows:
            row["group"] = "UNIT" + row["relative_path"].split("/")[1]
        result = allocate(rows, config("unused")["split_fractions"], 8)
        self.assertEqual(len({r["group"] for r in result}), 5)
        for group in {r["group"] for r in result}:
            self.assertEqual(len({r["split"] for r in result if r["group"] == group}), 1)
        for split in SPLITS:
            self.assertEqual({r["label"] for r in result if r["split"] == split}, {0, 1})

    def test_one_mixed_group_and_pure_groups_are_feasible(self):
        rows = synthetic_rows(5)
        rows[0]["group"] = rows[5]["group"] = "MIXED"
        result = allocate(rows, config("unused")["split_fractions"], 13)
        for split in SPLITS:
            self.assertEqual({r["label"] for r in result if r["split"] == split}, {0, 1})

    def test_insufficient_independent_bad_groups_has_actionable_error(self):
        rows = synthetic_rows(20)
        for row in rows:
            if row["label"] == 0:
                row["group"] = "ONE_BAD_UNIT"
        with self.assertRaisesRegex(ValueError, "1 containing bad"):
            allocate(rows, config("unused")["split_fractions"], 42)

    def test_balanced_data_matches_requested_ratios_and_is_order_independent(self):
        rows = synthetic_rows(100)
        fractions = config("unused")["split_fractions"]
        result = allocate(rows, fractions, 42)
        mapping = {r["pixel_hash"]: r["split"] for r in result}
        reversed_mapping = {r["pixel_hash"]: r["split"] for r in allocate(list(reversed(rows)), fractions, 42)}
        self.assertEqual(mapping, reversed_mapping)
        for split in SPLITS:
            for c in (0, 1):
                count = sum(r["split"] == split and r["label"] == c for r in result)
                self.assertLessEqual(abs(count - 100 * fractions[split]), 1)

    def test_supplied_five_splits_are_checked_for_both_classes(self):
        with tempfile.TemporaryDirectory() as tmp:
            rows = synthetic_rows(5)
            for i, row in enumerate(rows):
                row["split_hint"] = SPLITS[i % 5]
            next(r for r in rows if r["split_hint"] == "test" and r["label"] == 0)["split_hint"] = "train"
            with self.assertRaisesRegex(ValueError, "Split 'test' must contain both"):
                make_manifest(config("unused"), rows, tmp)


class IncrementalLineageTests(unittest.TestCase):
    def previous(self, root, cfg=None):
        cfg = cfg or config("unused")
        previous = Path(root) / "old"
        rows = make_manifest(cfg, synthetic_rows(), previous)
        write_json(previous / "config.json", cfg)
        return previous, rows, cfg

    def test_changes_to_previous_group_ids_are_blocked(self):
        with tempfile.TemporaryDirectory() as tmp:
            previous, rows, cfg = self.previous(tmp)
            rows = copy.deepcopy(rows)
            rows[0]["group"] = "RENAMED_UNIT"
            cfg["previous_run"] = str(previous)
            with self.assertRaisesRegex(ValueError, "Physical unit mapping changed"):
                make_manifest(cfg, rows, Path(tmp) / "new")

    def test_changed_regex_cannot_reassign_future_views_of_old_units(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg = dict(config("unused"), group_regex=r"(?P<group>UNIT[0-9]+)")
            previous, rows, cfg = self.previous(tmp, cfg)
            cfg.update(previous_run=str(previous), group_regex=r"(?P<group>UNIT[0-9]+_VIEW[0-9]+)")
            with self.assertRaisesRegex(ValueError, "Grouping method or group_regex changed"):
                make_manifest(cfg, rows, Path(tmp) / "new")

    def test_changed_label_requires_new_lineage(self):
        with tempfile.TemporaryDirectory() as tmp:
            previous, rows, cfg = self.previous(tmp)
            rows = copy.deepcopy(rows)
            rows[0]["label"] = 1 - rows[0]["label"]
            cfg["previous_run"] = str(previous)
            with self.assertRaisesRegex(ValueError, "old label changed"):
                make_manifest(cfg, rows, Path(tmp) / "new")

    def test_historical_test_views_remain_excluded_over_two_updates(self):
        with tempfile.TemporaryDirectory() as tmp:
            previous, rows, cfg = self.previous(tmp)
            test_row = next(r for r in rows if r["split"] == "test")
            extra = dict(test_row, pixel_hash="new_test_view", relative_path="good/new_test_view.png")
            cfg["previous_run"] = str(previous)
            current = Path(tmp) / "current"
            updated = make_manifest(cfg, rows + [extra], current)
            write_json(current / "config.json", cfg)
            self.assertEqual(next(r for r in updated if r["pixel_hash"] == "new_test_view")["split"], "excluded_old_test_group")
            cfg["previous_run"] = str(current)
            updated_again = make_manifest(cfg, updated, Path(tmp) / "next")
            self.assertEqual({r["pixel_hash"]: r["split"] for r in updated}, {r["pixel_hash"]: r["split"] for r in updated_again})

    def test_previous_manifest_tampering_is_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            previous, rows, cfg = self.previous(tmp)
            corrupt = copy.deepcopy(rows)
            # Swap two same-class independent units; class coverage remains valid.
            a = next(r for r in corrupt if r["split"] == "train" and r["label"] == 0)
            b = next(r for r in corrupt if r["split"] == "test" and r["label"] == 0)
            a["split"], b["split"] = b["split"], a["split"]
            write_csv(previous / "manifest.csv", corrupt)
            cfg["previous_run"] = str(previous)
            with self.assertRaisesRegex(ValueError, "integrity check failed"):
                make_manifest(cfg, rows, Path(tmp) / "new")

    def test_fingerprint_is_portable_when_paths_change(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg = config("unused")
            a = make_manifest(cfg, synthetic_rows(), Path(tmp) / "a")
            moved = [dict(r, path="D:/moved/" + r["relative_path"], relative_path="relocated/" + r["relative_path"]) for r in synthetic_rows()]
            make_manifest(cfg, moved, Path(tmp) / "b")
            one = read_json(Path(tmp) / "a" / "split_summary.json")["_metadata"]["manifest_fingerprint"]
            two = read_json(Path(tmp) / "b" / "split_summary.json")["_metadata"]["manifest_fingerprint"]
            self.assertEqual(one, two)

    def test_manifest_read_rejects_path_traversal(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "manifest.csv"
            write_csv(path, [{"relative_path": "../../outside.png", "label": 0}])
            with self.assertRaisesRegex(ValueError, "safe dataset-relative"):
                read_manifest(path)


if __name__ == "__main__":
    unittest.main()
