"""Local inspection gallery with immutable predictions and separate operator reviews.

The HTTP layer must allow only configured output roots. This module additionally
requires a session marker, rejects escaping paths, and serves only copied image
assets explicitly referenced by a completed prediction record.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path, PureWindowsPath
import time

from .common import EXTENSIONS, read_json, write_json, sha_file

FORMAT = "inspection_review_session_v4"
LABELS = {"good", "bad"}
DECISIONS = LABELS | {"review"}


def _now():
    return datetime.now(timezone.utc).isoformat()


def input_fingerprint(rows):
    """Identify exactly the supplied files, including invalid images when audited."""
    identity = sorted((str(row["relative_path"]), row.get("file_sha256") or sha_file(row["path"])) for row in rows)
    return hashlib.sha256(json.dumps(identity, ensure_ascii=False, separators=(",", ":")).encode("utf-8")).hexdigest()


def _session(path):
    path = Path(path).resolve()
    marker = path / "review_session.json"
    if marker.is_symlink():
        raise ValueError("A review session marker cannot be a symbolic link.")
    data = read_json(marker)
    if data.get("format") != FORMAT or data.get("id") != path.name:
        raise ValueError("This directory is not a registered review session.")
    return path, data


@contextmanager
def _lock(path, timeout=5.0):
    """Cross-process short transaction lock; a stale lock is never deleted silently."""
    deadline = time.monotonic() + timeout
    while True:
        try:
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            break
        except FileExistsError:
            if time.monotonic() >= deadline:
                raise TimeoutError("Review file is busy. Retry after the active writer finishes: " + str(path))
            time.sleep(.025)
    try:
        os.close(fd)
        yield
    finally:
        Path(path).unlink(missing_ok=True)


def initialize_session(out, kind="classification", metadata=None, total=0):
    out = Path(out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    if kind not in ("classification", "workflow"):
        raise ValueError("Unknown review session kind.")
    if (out / "review_session.json").exists() or (out / "predictions.jsonl").exists():
        raise ValueError("Review session already exists. Use a new output directory.")
    marker = {"format": FORMAT, "id": out.name, "kind": kind,
              "created_utc": _now(), "metadata": metadata or {}}
    write_json(out / "review_session.json", marker)
    (out / "records").mkdir()
    (out / "predictions.jsonl").touch(exist_ok=False)
    write_json(out / "review_progress.json", {"status": "running", "total": int(total),
               "completed": 0, "updated_utc": _now()})
    return marker


def _relative(value):
    value = str(value).replace("\\", "/")
    path = Path(value)
    if not value or path.is_absolute() or PureWindowsPath(value).drive or ".." in path.parts:
        raise ValueError("Expected a relative path within the review session.")
    return value


def _label(value):
    normalized = str(value or "").lower()
    if normalized == "unknown":
        return None
    if normalized and normalized not in LABELS:
        raise ValueError("An image label must be good, bad or unknown.")
    return normalized or None


def append_prediction(out, record):
    """Commit a completed immutable record; journal readers ignore partial last lines.

    Individual atomic records are authoritative, so a process interruption during
    journal append cannot hide a committed prediction from the review gallery.
    """
    out, _ = _session(out)
    entry = dict(record)
    relative = _relative(entry["relative_path"])
    identity = hashlib.sha256(relative.encode("utf-8")).hexdigest()[:24]
    if entry.get("id", identity) != identity:
        raise ValueError("Prediction identity does not match its relative path.")
    reference = _label(entry.get("reference_label", entry.get("true_class")))
    prediction = str(entry.get("prediction", entry.get("predicted_class")) or "").lower() or None
    if prediction is not None and prediction not in DECISIONS:
        raise ValueError("A prediction must be good, bad, review or empty for scores-only.")
    score = entry.get("bad_score", entry.get("score"))
    if score is not None:
        score = float(score)
        if not math.isfinite(score):
            raise ValueError("Prediction score must be finite.")
    copied = entry.get("copied_path", entry.get("output_path")) or ""
    if copied:
        copied = _relative(copied)
        asset = (out / copied).resolve()
        if not asset.is_relative_to(out) or Path(copied).parts[0] not in ("predicted", "copies"):
            raise ValueError("A review asset must be a copied session image.")
        if not asset.is_file() or asset.suffix.lower() not in EXTENSIONS:
            raise ValueError("Copied image is missing or has an unsupported extension.")
    entry.update(id=identity, relative_path=relative, reference_label=reference,
                 prediction=prediction, bad_score=score, copied_path=copied,
                 stage_results=entry.get("stage_results", []), completed_utc=_now())
    payload = json.dumps(entry, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n"
    with _lock(out / "prediction_write.lock"):
        target = out / "records" / (identity + ".json")
        if target.exists():
            raise ValueError("A prediction for this image has already been committed.")
        write_json(target, entry)
        with (out / "predictions.jsonl").open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
    return entry


def update_progress(out, *, status=None, completed=None, total=None, **extra):
    out, _ = _session(out)
    with _lock(out / "progress_write.lock"):
        path = out / "review_progress.json"
        value = read_json(path) if path.exists() else {}
        value.update(extra)
        for key, item in (("status", status), ("completed", completed), ("total", total)):
            if item is not None:
                value[key] = item
        value["updated_utc"] = _now()
        write_json(path, value)
    return value


def finish_session(out, status="completed", **extra):
    return update_progress(out, status=status, **extra)


def _read_optional(path, default):
    try:
        return read_json(path), None
    except FileNotFoundError:
        return default, None
    except (OSError, ValueError) as error:
        return default, "Review data is temporarily unavailable: " + str(error)


def list_sessions(output_root):
    """List direct child sessions only, skipping incomplete or unavailable markers."""
    root = Path(output_root).resolve()
    if not root.is_dir():
        return []
    result = []
    for path in root.iterdir():
        if not path.is_dir() or path.is_symlink():
            continue
        try:
            path, session = _session(path)
            progress, warning = _read_optional(path / "review_progress.json", {})
            result.append({**session, "path": str(path), "progress": progress, "read_warning": warning})
        except (OSError, ValueError):
            continue
    return sorted(result, key=lambda value: value["created_utc"], reverse=True)


def _load_records(path):
    records, warnings = [], []
    if (path / "records").is_symlink():
        raise ValueError("A review records directory cannot be a symbolic link.")
    for source in sorted((path / "records").glob("*.json")):
        if source.is_symlink():
            continue
        value, warning = _read_optional(source, None)
        if warning:
            warnings.append(warning)
        if value:
            records.append(value)
    records.sort(key=lambda row: (row.get("completed_utc", ""), row["relative_path"]))
    return records, warnings


def read_records(session_path):
    """Read immutable completed records for comparison; fail if a record is unreadable."""
    path, _ = _session(session_path)
    records, warnings = _load_records(path)
    if warnings:
        raise OSError("; ".join(warnings))
    return records


def decision_metrics(records):
    """Account for abstentions explicitly; class error rates use ALL labeled inputs.

    Accuracy remains selective (automatic decisions only) and is always reported
    with coverage. REVIEW is not silently counted as a correct classification.
    """
    divide = lambda a, b: a / b if b else None
    valid = [r for r in records if r.get("status", "ok") == "ok"]
    labeled = [r for r in records if r.get("reference_label") in LABELS]
    pairs = [(r["reference_label"], r.get("prediction")) for r in valid
             if r.get("reference_label") in LABELS and r.get("prediction") in LABELS]
    tp = sum(a == "bad" and b == "bad" for a, b in pairs)
    fn = sum(a == "bad" and b == "good" for a, b in pairs)
    fp = sum(a == "good" and b == "bad" for a, b in pairs)
    tn = sum(a == "good" and b == "good" for a, b in pairs)
    n_bad = sum(r["reference_label"] == "bad" for r in labeled)
    n_good = sum(r["reference_label"] == "good" for r in labeled)
    review_bad = sum(r.get("reference_label") == "bad" and r.get("prediction") == "review" for r in valid)
    review_good = sum(r.get("reference_label") == "good" and r.get("prediction") == "review" for r in valid)
    automatic = sum(r.get("prediction") in LABELS for r in valid)
    review = sum(r.get("prediction") == "review" for r in valid)
    return {"n": len(pairs), "n_total": len(records), "n_labeled": len(labeled),
            "n_bad": n_bad, "n_good": n_good, "n_automatic": automatic,
            "n_review": review, "n_unavailable": len(records) - automatic - review,
            "n_labeled_review": review_bad + review_good,
            "n_labeled_unavailable": len(labeled) - len(pairs) - review_bad - review_good,
            "accuracy": divide(tp + tn, len(pairs)),
            "selective_accuracy": divide(tp + tn, len(pairs)),
            "automatic_correct_rate": divide(tp + tn, len(labeled)),
            "decision_coverage": divide(automatic, len(records)),
            "labeled_decision_coverage": divide(len(pairs), len(labeled)),
            "review_rate": divide(review, len(records)),
            "bad_review_rate": divide(review_bad, n_bad), "good_review_rate": divide(review_good, n_good),
            "bad_escape_rate": divide(fn, n_bad), "good_reject_rate": divide(fp, n_good),
            "bad_detection_rate": divide(tp, n_bad), "good_accept_rate": divide(tn, n_good),
            "accepted_contamination": divide(fn, fn + tn),
            "bad_detected_TP": tp, "bad_passed_as_good_FN": fn,
            "good_rejected_as_bad_FP": fp, "good_accepted_TN": tn,
            "bad_sent_to_review": review_bad, "good_sent_to_review": review_good,
            "note": "Accuracy is conditional on automatic labeled decisions. Escape, reject and class review rates use ALL inputs of that true class; review is not success. These descriptive operator counts are not independent validation."}


def _metrics(records, mode):
    resolved = []
    for record in records:
        reviewed = record["review"]["label"]
        reference = record["reference_label"]
        if mode == "reviewed_only":
            reference = reviewed if reviewed in LABELS else None
        elif mode == "effective_reference" and reviewed in LABELS:
            reference = reviewed
        elif mode == "effective_reference" and reviewed == "unknown":
            reference = None
        resolved.append({**record, "reference_label": reference})
    return decision_metrics(resolved)


def _priority(row):
    """Heuristic review ordering, NOT calibrated uncertainty or training labels."""
    reasons, distances = [], []
    if row.get("prediction") == "review":
        reasons.append("abstained")
    if row.get("reference_mismatch") or row.get("review_mismatch"):
        reasons.append("label_mismatch")
    stages = row.get("stage_results") or []
    if isinstance(stages, dict):
        stages = list(stages.values())
    decisions = {r.get("prediction", r.get("predicted_class", r.get("decision")))
                 for r in stages if isinstance(r, dict)} & LABELS
    disagree = len(decisions) > 1 or row.get("model_disagreement") is True
    if disagree:
        reasons.append("model_disagreement")
    score = row.get("bad_score")
    if isinstance(score, (int, float)) and not isinstance(score, bool) and math.isfinite(score):
        for key in ("threshold", "good_threshold", "bad_threshold", "threshold_good", "threshold_bad", "low_threshold", "high_threshold"):
            value = row.get(key)
            if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value):
                distances.append(abs(score - value))
    if not distances:
        for stage in stages:
            if not isinstance(stage, dict):
                continue
            score = stage.get("score")
            if not isinstance(score, (int, float)) or isinstance(score, bool) or not math.isfinite(score):
                continue
            for key in ("threshold", "good_threshold", "bad_threshold"):
                threshold = stage.get(key)
                if isinstance(threshold, (int, float)) and not isinstance(threshold, bool) and math.isfinite(threshold):
                    distances.append(abs(score - threshold))
    distance = min(distances) if distances else None
    if distance is not None:
        reasons.append("threshold_distance_available")
    row.update(priority_reasons=reasons, threshold_distance=distance, model_disagreement=disagree)


def _sort_key(row, mode):
    distance = row.get("threshold_distance")
    distance = distance if distance is not None else math.inf
    chronological = (row.get("completed_utc", ""), row["relative_path"])
    if mode == "chronological":
        return chronological
    if mode == "uncertainty":
        return (row.get("prediction") != "review", distance, *chronological)
    if mode == "disagreement":
        return (not row["model_disagreement"], *chronological)
    if mode == "errors":
        return (not (row.get("reference_mismatch") or row.get("review_mismatch")), *chronological)
    return (row["review"]["label"] != "unreviewed", row.get("prediction") != "review",
            not (row.get("reference_mismatch") or row.get("review_mismatch")),
            not row["model_disagreement"], distance, *chronological)


def session_detail(session_path, page=1, page_size=40, prediction=None, reference=None,
                   review=None, errors_only=False, search="", offset=None, limit=None, filter=None,
                   sort="chronological"):
    path, session = _session(session_path)
    records, warnings = _load_records(path)
    reviews, warning = _read_optional(path / "reviews.json", {"items": {}})
    if warning:
        warnings.append(warning)
    progress, warning = _read_optional(path / "review_progress.json", {})
    if warning:
        warnings.append(warning)
    for row in records:
        row["review"] = reviews.get("items", {}).get(row["id"], {"label": "unreviewed", "note": "", "updated_utc": None})
        row["reference_mismatch"] = (row["reference_label"] != row["prediction"]
            if row["reference_label"] in LABELS and row["prediction"] in LABELS else None)
        row["review_mismatch"] = (row["review"]["label"] != row["prediction"]
            if row["review"]["label"] in LABELS and row["prediction"] in LABELS else None)
        _priority(row)
    metrics = {mode: _metrics(records, mode) for mode in ("dataset_reference", "reviewed_only", "effective_reference")}
    if filter not in (None, "", "all", "errors", "unknown", "reviewed", "unreviewed", "needs_review", "disagreement"):
        raise ValueError("Unknown gallery filter.")
    if sort not in ("chronological", "priority", "uncertainty", "disagreement", "errors"):
        raise ValueError("Unknown review ordering.")
    errors_only = errors_only or filter == "errors"
    if filter == "unknown":
        reference = "unknown"
    if filter in ("reviewed", "unreviewed"):
        review = filter
    for key, selected in (("prediction", prediction), ("reference", reference)):
        allowed = (None, "", "all", "good", "bad", "unknown") + (("review",) if key == "prediction" else ())
        if selected not in allowed:
            raise ValueError("Unknown " + key + " filter.")
    if review not in (None, "", "all", "good", "bad", "unknown", "reviewed", "unreviewed"):
        raise ValueError("Unknown review filter.")
    items = []
    for row in records:
        if filter == "needs_review" and row["prediction"] != "review":
            continue
        if filter == "disagreement" and not row["model_disagreement"]:
            continue
        if errors_only and row["reference_mismatch"] is not True:
            continue
        if search and str(search).casefold() not in row["relative_path"].casefold():
            continue
        if any(selected not in (None, "", "all") and (row[field] or "unknown") != selected
               for field, selected in (("prediction", prediction), ("reference_label", reference))):
            continue
        if review == "reviewed" and row["review"]["label"] == "unreviewed":
            continue
        if review in ("good", "bad", "unknown", "unreviewed") and row["review"]["label"] != review:
            continue
        items.append(row)
    items.sort(key=lambda row: _sort_key(row, sort))
    page_size = min(200, max(1, int(limit if limit is not None else page_size)))
    page = max(1, int(page))
    offset = max(0, int(offset)) if offset is not None else (page - 1) * page_size
    return {"session": {**session, "path": str(path)}, "progress": progress,
            "items": items[offset:offset + page_size],
            "pagination": {"page": offset // page_size + 1, "page_size": page_size,
                "offset": offset, "limit": page_size, "total": len(items), "pages": math.ceil(len(items) / page_size)},
            "metrics": metrics, "read_warning": "; ".join(warnings) or None}


def _item(session_path, item_id):
    path, _ = _session(session_path)
    if len(str(item_id)) != 24 or any(c not in "0123456789abcdef" for c in str(item_id)):
        raise ValueError("Invalid prediction identity.")
    source = path / "records" / (item_id + ".json")
    if source.is_symlink() or (path / "records").is_symlink():
        raise ValueError("Prediction records cannot be symbolic links.")
    item = read_json(source)
    if item.get("id") != item_id:
        raise ValueError("Prediction record identity mismatch.")
    return path, item


def save_review(session_path, item_id, label, note=""):
    path, _ = _item(session_path, item_id)
    label = str(label).lower()
    if label not in ("good", "bad", "unknown", "unreviewed"):
        raise ValueError("Review label must be good, bad, unknown or unreviewed.")
    if not isinstance(note, str) or len(note) > 4000:
        raise ValueError("Review note must contain at most 4000 characters.")
    with _lock(path / "review_write.lock"):
        target = path / "reviews.json"
        reviews = read_json(target) if target.exists() else {"format": "inspection_human_reviews_v4", "items": {}}
        previous = reviews["items"].get(item_id)
        entry = {"label": label, "note": note, "updated_utc": _now()}
        # Keep review history separate from original labels and model decisions.
        history = reviews.setdefault("history", [])
        history.append({"item_id": item_id, "previous": previous, "review": entry})
        reviews["items"][item_id] = entry
        write_json(target, reviews)
    return {"item_id": item_id, **entry}


def resolve_review_asset(session_path, item_id):
    path, item = _item(session_path, item_id)
    relative = _relative(item.get("copied_path") or "")
    if Path(relative).parts[0] not in ("predicted", "copies"):
        raise ValueError("Only copied classification assets can be viewed.")
    candidate = path / relative
    resolved = candidate.resolve()
    if (not resolved.is_relative_to(path) or resolved.suffix.lower() not in EXTENSIONS
            or not resolved.is_file() or candidate.is_symlink()):
        raise ValueError("Copied image is unavailable or outside this session.")
    return resolved
