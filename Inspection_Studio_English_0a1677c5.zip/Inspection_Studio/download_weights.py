"""Explicitly provision verified official weights. Never uploads image data."""
import argparse
from pathlib import Path
from nilt.engine import WEIGHTS
from nilt.backbones import TIMM_MODELS
from nilt.weights import ensure_pretrained_weights


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="weights")
    parser.add_argument("--models", nargs="+", choices=list(WEIGHTS) + list(TIMM_MODELS), default=list(WEIGHTS))
    parser.add_argument("--model-usage", choices=["commercial", "research"], default="commercial")
    args = parser.parse_args()
    output = Path(args.output).resolve()
    ensure_pretrained_weights({"models": args.models, "weights_dir": str(output),
                               "pretrained": True, "model_usage": args.model_usage}, allow_download=True)
    print(f"Ready: {output}")


if __name__ == "__main__":
    main()
