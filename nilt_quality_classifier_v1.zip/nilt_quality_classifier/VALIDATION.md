# Validation performed before packaging

The code was checked in an isolated local environment with synthetic GOOD/BAD images.

Completed checks:

- Python byte-code compilation for every module and entry-point script.
- `self_test.py` for Unit Identifier normalization, group-safe splitting, threshold selection and semicolon-separated ground-truth parsing.
- End-to-end initial training run with a ResNet18 checkpoint.
- Folder inference and creation of `predictions.csv`.
- Automatic join against a synthetic `evaluation_results.csv` using `p/f` labels and `-` versus `_` Unit Identifier separators.
- Fine-tuning from a previous checkpoint with old-data replay and new-data splits.
- Automatic base/candidate comparison on the legacy frozen test split.
- Dataset preparation from a `..._Sources` column containing a Python-style list of image paths.
- Dataset audit and duplicate detection.
- One-experiment hyperparameter sweep using a shared fixed split.

These smoke tests verify program flow and file generation. They do not validate classification accuracy on the real company images; that depends on the real labels, preprocessing, defect diversity and independent test data.
