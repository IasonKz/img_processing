"""Create project.visual.yaml beside an existing project configuration."""
import argparse
from copy import deepcopy
from pathlib import Path
import yaml


def configure(source):
    source = Path(source).resolve()
    raw = yaml.safe_load(source.read_text(encoding="utf-8"))
    if not isinstance(raw, dict) or raw.get("schema_version") != 2 or not raw.get("tasks"):
        raise ValueError("Expected a schema_version: 2 project with tasks.")
    if "profile" in raw:
        raise ValueError("Use plural 'profiles:', not 'profile:'.")
    data = deepcopy(raw)
    profiles = data.setdefault("profiles", {})
    for name, settings in {
        "laptop": dict(models=["resnet18"], seeds=[42], device="cpu", pilot=True,
                       ensembles=False, num_workers=0),
        "workstation": dict(models=["resnet18", "resnet50", "efficientnet_b0", "convnext_tiny", "swin_t", "patchcore"],
                            seeds=[42, 123], device="cuda", pilot=False, ensembles=True, num_workers=0),
    }.items():
        profile = profiles.setdefault(name, {})
        profile.update(settings)
        profile.setdefault("training", {}).update({
            "epochs": 15 if name == "laptop" else 30,
            "warmup_epochs": 2, "patience": 5 if name == "laptop" else 7,
            "batch_size": 1, "eval_batch_size": 1,
            "accumulation_steps": 4 if name == "laptop" else 16,
            "learning_rate": .0001, "head_learning_rate": .001,
            "weight_decay": .0001, "freeze_batch_norm": True,
            "imbalance": "auto", "amp": name == "workstation"})
    target = source.with_name("project.visual.yaml")
    with target.open("x", encoding="utf-8") as stream:
        stream.write("# Explicit resource profiles. Original project.yaml is unchanged.\n")
        stream.write("# Relative paths still resolve beside this file. Training goals are unchanged.\n")
        yaml.safe_dump(data, stream, sort_keys=False, allow_unicode=True)
    for task, options in data["tasks"].items():
        if isinstance(options, dict) and any(k in options for k in ("training", "models", "device", "seeds")):
            print(f"NOTICE: task '{task}' has overrides that take precedence over profiles.")
    print(f"Created {target}")
    print("Workstation requires a compatible NVIDIA GPU and CUDA-enabled PyTorch. Batch size 1 is a starting budget, not a memory guarantee.")
    return target


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="project.yaml")
    args = parser.parse_args()
    try:
        configure(args.config)
    except (ValueError, OSError, yaml.YAMLError) as exc:
        parser.exit(2, f"Configuration error: {exc}\n")
