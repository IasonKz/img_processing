# Αναβάθμιση από Studio v1 σε v2

Η v2 χρησιμοποιεί το υπάρχον annotation project και τα υπάρχοντα training results. Δεν χρειάζεται να ξαναμαρκάρεις τις εικόνες.

## Βήματα

1. Κλείσε την παλιά εφαρμογή. Αν τρέχει training, σταμάτησέ το με **Stop operation** πριν κλείσεις το terminal.
2. Κράτησε ένα αντίγραφο του παλιού `project.yaml` και του annotation project πριν αποθηκεύσεις αλλαγές με τη v2. Μην τρέχεις v1 και v2 ταυτόχρονα πάνω στο ίδιο project.
3. Κάνε extract τη v2 σε **νέο φάκελο**. Μην αντιγράψεις το παλιό `.venv`.
4. Τρέξε **Setup.cmd** στα Windows ή `bash Setup.sh` στο Linux. Η v2 προσθέτει το `opencv-python-headless` στις βασικές εξαρτήσεις. Η εγκατάσταση απαιτεί internet ή διαθέσιμα τοπικά πακέτα/wheels· η χρήση παραμένει offline.
5. Ξεκίνα με **Start.cmd** ή `bash Start.sh`.
6. Στο **Workspace**, βάλε **τα ίδια πραγματικά paths** που χρησιμοποιούσες στη v1 για **Top image folder**, **Annotation project folder** και **Results folder**. Διατήρησε και το ίδιο `group_regex`. Πάτησε **Save project settings**.
7. Άνοιξε μια ήδη αποθηκευμένη εικόνα και έλεγξε το polygon και τα annotations της. Δοκίμασε νέα μέθοδο με **Reload proposals**. Αποθήκευσε με **Save draft** ή **Approve & next** όταν είσαι ικανοποιημένος.

Παράδειγμα: αν το παλιό annotation project βρίσκεται μέσα στον φάκελο της v1, στο **Annotation project folder** βάλε το πλήρες path προς εκείνον τον παλιό υποφάκελο `annotation_project`. Το ίδιο ισχύει για `results`. Ο νέος κενός φάκελος της v2 δεν περιέχει τα προηγούμενα δεδομένα σου.

Εναλλακτικά, από το περιβάλλον Python της v2, ξεκίνα με το παλιό YAML στη θέση του:

```bash
python segmentation.py studio --config /absolute/path/to/v1/project.yaml
```

Η εντολή δίνεται από τον φάκελο της **v2**. Τα σχετικά paths του παλιού YAML εξακολουθούν να υπολογίζονται ως προς τη θέση εκείνου του αρχείου. Αν μεταφέρεις το YAML αλλού, διόρθωσε τα paths ή κάν' τα απόλυτα.

## Τι διατηρείται

- Εικόνες, αποθηκευμένα masks, annotation objects, σημειώσεις, κατάσταση draft/approved/excluded και προηγούμενο ιστορικό.
- Το αποθηκευμένο custom polygon και οι ρυθμίσεις επαναχρησιμοποίησής του.
- Optuna studies, frozen datasets, splits, completed trials και checkpoints στα ίδια results paths.

Το άνοιγμα μιας υπάρχουσας αποθηκευμένης εικόνας δεν αντικαθιστά το annotation της. Το **Reload proposals** δείχνει προεπισκόπηση χωρίς να γράφει νέα annotation revision. Το **Save draft** ή **Approve & next** αποθηκεύει την αλλαγή ως νέα revision. Η αποθήκευση polygon/profile και η ρητή μαζική εφαρμογή polygon είναι χωριστές ενέργειες που γράφουν στο project.

## Νέα δεδομένα της v2

Οι νέες revisions μπορούν να περιέχουν επιλεγμένη μέθοδο, detection area, ζώνες και επίμονες χειροκίνητες διαγραφές. Το project αποθηκεύει επίσης εκδόσεις του automation profile. Η v1 δεν γνωρίζει αυτά τα νέα πεδία: μην θεωρήσεις ότι η εναλλαγή πίσω στη v1 θα διατηρήσει τη συμπεριφορά της v2. Για πλήρη επιστροφή στην προηγούμενη κατάσταση χρησιμοποίησε το αντίγραφο που κράτησες πριν την αναβάθμιση.

Η v2 δεν μπορεί να ανακατασκευάσει ποιες προτάσεις είχες σβήσει σε παλιά v1 sessions. Διατηρεί το παλιό αποθηκευμένο mask, αλλά ένα νέο reload μπορεί να ξαναπροτείνει εκείνες τις περιοχές. Οι διαγραφές που κάνεις και αποθηκεύεις στη v2 καταγράφονται για τα επόμενα reloads με **Keep manual additions and erasures**.

## Πρώτη ρύθμιση των νέων επιλογών

1. **Annotation method → Basic + exclusion zones**.
2. Σχεδίασε τις ζώνες για label και σύμβολα· κράτησε το eye ενεργό ή εξαιρούμενο ανάλογα με την εικόνα.
3. **Save automation profile** για να χρησιμοποιείται σε νέες εικόνες. Για μια υπάρχουσα: **Load profile on this image → Reload proposals**.
4. Προσάρμοσε το polygon στο **Chamfered rectangle geometry** και πάτησε **Save custom polygon**. Το polygon αποθηκεύεται χωριστά από το automation profile.
5. Αν τα φίλτρα κρύβουν κάτι που χρειάζεσαι, γύρισε σε **Basic — current detector**, επίλεξε **Full image**, κάνε reload και διόρθωσε με το χέρι.

Τα **Structure-aware** και **Good-reference comparison** είναι πειραματικές βοηθητικές μέθοδοι. Δεν έχουν πιστοποιηθεί ως παραγωγικός έλεγχος defects. Οι οδηγίες και οι περιορισμοί τους βρίσκονται στο **docs/ANNOTATION_V2.md**.

Η εκπαίδευση δεν αλλάζει ανάλυση σε σχέση με τη v1: εξακολουθεί να χρησιμοποιεί το επιλεγμένο image size με resize/padding. Η ανάλυση του annotation στη v2 γίνεται στις αρχικές διαστάσεις. Ένα υπάρχον Optuna study συνεχίζει με το παλιό frozen dataset· για να εκπαιδεύσεις με τα νέα approved annotations δημιούργησε νέο study.
