"""Workflow integrity and decision semantics using synthetic images/fake scoring.

These checks validate application behavior, not industrial model performance.
"""
from itertools import product
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
from PIL import Image

from nilt.common import read_json, sha_file, write_json
from nilt.decisions import create_decision
from nilt.inspection_flow import aggregate_votes, create_workflow, load_workflow, run_workflow
from test_integration_v2 import fixture_run


class AggregationTests(unittest.TestCase):
    def test_complete_truth_tables_and_conservative_ties(self):
        for n in range(1, 6):
            for votes in product(("good", "bad"), repeat=n):
                bad = votes.count("bad")
                expected = {"any_bad": bad > 0, "all_bad": bad == n, "majority": bad * 2 >= n}
                for rule, rejected in expected.items():
                    with self.subTest(votes=votes, rule=rule):
                        self.assertEqual(aggregate_votes(votes, rule), "bad" if rejected else "good")

    def test_invalid_votes_do_not_become_good(self):
        for votes in ([], ["review"], [None], [0, 1]):
            with self.assertRaises(ValueError):
                aggregate_votes(votes, "any_bad")
        with self.assertRaises(ValueError):
            aggregate_votes(["good"], "average_score")


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.run, self.data, self.manifest = fixture_run(self.root)
        self.decisions = [create_decision(self.run, mode="manual", threshold=threshold,
                                         output_root=self.root / "decisions") for threshold in (.4, .6, .8)]
        self.source = self.root / "incoming"
        for label, color in (("good", "white"), ("bad", "black")):
            (self.source / label).mkdir(parents=True)
            Image.new("RGB", (32, 32), color).save(self.source / label / "image.png")

    def create(self, rule="any_bad", count=2):
        return create_workflow({"name": "Test inspection", "rule": rule, "task": "top",
                                "stages": [{"name": f"Stage {i + 1}", "decision": str(path)}
                                           for i, path in enumerate(self.decisions[:count])]}, self.root / "flows")

    def run_flow(self, flow, sequences, **kwargs):
        with patch("nilt.workflow.predict_members", side_effect=[(np.array(scores), .01) for scores in sequences]) as backend:
            output = run_workflow(flow, self.source, self.root / "outputs", labeled=True, **kwargs)
        return output, backend

    def entries(self, output):
        return {row["relative_path"]: row for row in (json.loads(line) for line in
                (output / "predictions.jsonl").read_text(encoding="utf-8").splitlines())}

    def test_any_bad_short_circuits_individual_images_and_preserves_originals(self):
        flow = self.create()
        before = {p: sha_file(p) for p in self.source.rglob("*") if p.is_file()}
        out, backend = self.run_flow(flow, [[.1, .9], [.2]])
        entries = self.entries(out)
        self.assertEqual(backend.call_count, 2)
        self.assertEqual(len(backend.call_args_list[1].args[2]), 1)
        self.assertEqual(entries["bad/image.png"]["prediction"], "bad")
        self.assertEqual(entries["bad/image.png"]["stage_results"][1]["status"], "skipped")
        self.assertEqual(entries["good/image.png"]["prediction"], "good")
        self.assertEqual(before, {p: sha_file(p) for p in self.source.rglob("*") if p.is_file()})
        for entry in entries.values():
            self.assertEqual(sha_file(out / entry["copied_path"]), sha_file(self.source / entry["relative_path"]))
        met = read_json(out / "metrics.json")
        self.assertEqual((met["bad_detected_TP"], met["good_accepted_TN"]), (1, 1))
        self.assertNotIn("pr_auc_bad", met)
        self.assertEqual(met["qualification_status"], "NOT_INDEPENDENTLY_VALIDATED")
        summary = read_json(out / "summary.json")
        self.assertEqual(summary["stage_counts"][1]["skipped"], 1)
        self.assertEqual(summary["stage_counts"][1]["conditional_metrics"]["n_images"], 1)
        self.assertGreater(summary["images_per_second"], 0)
        self.assertEqual(read_json(out / "review_progress.json")["completed"], 2)

    def test_all_bad_accepts_at_first_good_and_skips_remaining_stage(self):
        out, backend = self.run_flow(self.create("all_bad"), [[.1, .9], [.8]])
        entries = self.entries(out)
        self.assertEqual(entries["good/image.png"]["stage_results"][1]["status"], "skipped")
        self.assertEqual(entries["good/image.png"]["prediction"], "good")
        self.assertEqual(entries["bad/image.png"]["prediction"], "bad")
        self.assertEqual(len(backend.call_args_list[1].args[2]), 1)

    def test_all_images_resolved_stages_never_load(self):
        out, backend = self.run_flow(self.create("any_bad", 3), [[.9, .9]])
        self.assertEqual(backend.call_count, 1)
        self.assertEqual([s["evaluated"] for s in read_json(out / "summary.json")["stage_counts"]], [2, 0, 0])

    def test_majority_runs_every_stage_and_tie_is_bad(self):
        out, backend = self.run_flow(self.create("majority"), [[.1, .9], [.9, .1]])
        self.assertTrue(all(len(call.args[2]) == 2 for call in backend.call_args_list))
        entries = self.entries(out)
        self.assertTrue(all(row["prediction"] == "bad" for row in entries.values()))
        self.assertTrue(all(stage["status"] == "evaluated" for row in entries.values() for stage in row["stage_results"]))
        self.assertTrue(all(row["bad_score"] is None for row in entries.values()))

    def test_versions_unique_and_snapshot_independent_of_original_decision_file(self):
        first, second = self.create(), self.create()
        self.assertNotEqual(first, second)
        original = read_json(self.decisions[0])
        original["threshold"] = 123
        write_json(self.decisions[0], original)
        frozen, stages = load_workflow(first)
        self.assertEqual(stages[0]["record"]["threshold"], .4)
        self.assertEqual(frozen["stages"][0]["threshold"], .4)

    def test_recipe_tamper_stage_tamper_and_checkpoint_tamper_rejected(self):
        first = self.create()
        record = read_json(first)
        record["rule"] = "all_bad"
        write_json(first, record)
        with self.assertRaisesRegex(ValueError, "checksum"):
            load_workflow(first)
        second = self.create()
        snapshot = second.parent / read_json(second)["stages"][0]["decision_file"]
        snapshot.write_text("{}", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "checksum"):
            load_workflow(second)
        third = self.create()
        next(self.run.rglob("best.pt")).write_bytes(b"changed checkpoint")
        with self.assertRaisesRegex(ValueError, "checksum"):
            load_workflow(third)

    def test_contained_asset_traversal_rejected_even_with_recomputed_recipe_hash(self):
        flow = self.create()
        record = read_json(flow)
        record["stages"][0]["decision_file"] = "../outside.json"
        write_json(flow, record)
        write_json(flow.parent / "workflow_integrity.json", {"format": record["format"], "workflow_sha256": sha_file(flow)})
        with self.assertRaisesRegex(ValueError, "Unsafe"):
            load_workflow(flow)

    def test_scores_only_duplicate_stage_and_unknown_definition_fields_rejected(self):
        score_only = create_decision(self.run, mode="scores_only", output_root=self.root / "decisions")
        for spec in ({"rule": "any_bad", "stages": [{"decision": str(score_only)}]},
                     {"rule": "any_bad", "stages": [{"decision": str(self.decisions[0])}] * 2},
                     {"rule": "any_bad", "stages": [{"decision": str(self.decisions[0]), "threshold": .2}]},
                     {"rule": "any_bad", "stages": []},
                     {"rule": "any_bad", "stages": [{"decision": str(self.decisions[0])}], "task": "vig"}):
            with self.subTest(spec=spec), self.assertRaises(ValueError):
                create_workflow(spec, self.root / "flows")

    def test_incompatible_tasks_rejected(self):
        other, _, _ = fixture_run(self.root, name="other")
        cfg = read_json(other / "config.json")
        cfg["task"] = "bottom"
        write_json(other / "config.json", cfg)
        write_json(other / "integrity.json", {"config_sha256": sha_file(other / "config.json"),
                                             "manifest_sha256": sha_file(other / "manifest.csv")})
        decision = create_decision(other, mode="manual", threshold=.5, output_root=self.root / "decisions")
        with self.assertRaisesRegex(ValueError, "same inspection task"):
            create_workflow({"rule": "any_bad", "stages": [{"decision": str(self.decisions[0])},
                                                           {"decision": str(decision)}]}, self.root / "flows")

    def test_workflow_and_runs_can_move_together(self):
        flow = self.create()
        relocated = self.root / "relocated"
        relocated.mkdir()
        shutil.copytree(self.root / "flows", relocated / "flows")
        shutil.copytree(self.run, relocated / self.run.name)
        moved = relocated / flow.relative_to(self.root)
        _, stages = load_workflow(moved)
        self.assertEqual(stages[0]["run"], relocated / self.run.name)

    def test_overlap_output_and_invalid_scores_fail_before_good_classification(self):
        flow = self.create()
        with patch("nilt.workflow.predict_members") as backend:
            with self.assertRaisesRegex(ValueError, "separate"):
                run_workflow(flow, self.source, self.source / "results")
            backend.assert_not_called()
        with patch("nilt.workflow.predict_members", return_value=(np.array([np.nan, .5]), .1)):
            with self.assertRaisesRegex(ValueError, "invalid scores"):
                run_workflow(flow, self.source, self.root / "failed")
        out = next((self.root / "failed").iterdir())
        self.assertEqual(read_json(out / "summary.json")["status"], "failed")
        self.assertEqual(self.entries(out), {})

    def test_invalid_images_are_reported_and_never_passed_good(self):
        (self.source / "bad" / "broken.png").write_bytes(b"invalid image")
        out, _ = self.run_flow(self.create(), [[.1, .9], [.1]])
        entries = self.entries(out)
        broken = entries["bad/broken.png"]
        self.assertIsNone(broken["prediction"])
        self.assertEqual(broken["status"], "input_error")
        self.assertEqual(read_json(out / "summary.json")["status"], "completed_with_input_errors")
        self.assertEqual(read_json(out / "metrics.json")["invalid_excluded"], 1)

    def test_mid_workflow_failure_retains_trace_and_only_committed_decisions(self):
        flow = self.create()
        with patch("nilt.workflow.predict_members", side_effect=[(np.array([.1, .9]), .1), RuntimeError("test failure")]):
            with self.assertRaisesRegex(RuntimeError, "test failure"):
                run_workflow(flow, self.source, self.root / "failed", labeled=True)
        out = next((self.root / "failed").iterdir())
        self.assertEqual(list(self.entries(out)), ["bad/image.png"])
        self.assertEqual(read_json(out / "review_progress.json")["status"], "failed")
        self.assertEqual(read_json(out / "summary.json")["completed_images"], 1)

    def test_input_fingerprint_is_shared_across_rules_and_source_overlap_is_explicit(self):
        one, _ = self.run_flow(self.create("any_bad"), [[.1, .9], [.1]], copy_images=False)
        two, _ = self.run_flow(self.create("majority"), [[.1, .9], [.1, .9]], copy_images=False)
        self.assertEqual(read_json(one / "summary.json")["input_fingerprint"], read_json(two / "summary.json")["input_fingerprint"])
        self.assertEqual(read_json(one / "summary.json")["source_overlap"]["holdout_status"], "INDEPENDENCE_NOT_ESTABLISHED")
        Image.open(self.data / "good" / "train_0.png").save(self.source / "good" / "known.bmp")
        flow = self.create("majority")
        with patch("nilt.workflow.predict_members", return_value=(np.array([.1, .1, .9]), .1)):
            out = run_workflow(flow, self.source, self.root / "outputs", labeled=True)
        overlap = read_json(out / "summary.json")["source_overlap"]
        self.assertEqual(overlap["matched_images"], 1)
        self.assertEqual(overlap["by_split"]["train"], 1)
        self.assertEqual(overlap["holdout_status"], "KNOWN_SOURCE_DATA_PRESENT")

    def test_cli_arguments_and_relative_spec_paths(self):
        import inspection
        parser = inspection.build_parser()
        args = parser.parse_args(["workflow-run", "--workflow", "flow", "--input", "images", "--labeled", "--no-copy-images"])
        self.assertTrue(args.labeled and args.no_copy_images)
        spec = self.root / "spec.json"
        write_json(spec, {"rule": "any_bad", "stages": [{"decision": self.decisions[0].relative_to(self.root).as_posix()}]})
        args = parser.parse_args(["workflow-create", "--spec", str(spec), "--output-root", str(self.root / "cli")])
        self.assertEqual(inspection.dispatch(args), 0)
        path = next((self.root / "cli").glob("*/workflow.json"))
        self.assertEqual(load_workflow(path)[0]["rule"], "any_bad")

    @unittest.skipUnless(importlib.util.find_spec("torch") and importlib.util.find_spec("torchvision"),
                         "Requires the optional training stack")
    def test_real_cpu_inference_matches_single_decision_and_shared_fingerprint(self):
        """Exercise real tensors/checkpoints on synthetic images, not model quality."""
        import torch
        from nilt.engine import make_model, save_checkpoint
        from nilt.decisions import predict_decision
        from nilt.workflow import open_run
        torch.set_num_threads(1)
        cfg, _ = open_run(self.run)
        model, _ = make_model("resnet18")
        checkpoint = next(self.run.rglob("best.pt"))
        save_checkpoint(checkpoint, model.eval(), cfg, "resnet18", 42, 0)
        candidate = read_json(self.run / "selected.json")
        candidate["members"][0].update(architecture="resnet18", kind="supervised", sha256=sha_file(checkpoint))
        candidate["score_type"] = "bad_probability_uncalibrated"
        write_json(self.run / "selected.json", candidate)
        write_json(self.run / "selection_integrity.json", {"sha256": sha_file(self.run / "selected.json")})
        write_json(self.run / "candidates.json", [candidate])
        decision = create_decision(self.run, mode="argmax", output_root=self.root / "decisions")
        flow = create_workflow({"rule": "any_bad", "stages": [{"decision": str(decision)}]}, self.root / "flows")
        direct = predict_decision(decision, self.source, self.root / "direct", labeled=True)
        workflow = run_workflow(flow, self.source, self.root / "outputs", labeled=True)
        expected = self.entries(direct)
        observed = self.entries(workflow)
        self.assertEqual({k: v["prediction"] for k, v in expected.items()},
                         {k: v["prediction"] for k, v in observed.items()})
        self.assertEqual(read_json(direct / "summary.json")["input_fingerprint"],
                         read_json(workflow / "summary.json")["input_fingerprint"])
        self.assertEqual(read_json(workflow / "summary.json")["status"], "completed")
        from nilt.session_compare import compare_sessions
        comparison = compare_sessions([direct, workflow])
        self.assertEqual(comparison["n_images"], len(expected))
        self.assertEqual(comparison["sessions"][0]["metrics"], comparison["sessions"][1]["metrics"])


if __name__ == "__main__":
    unittest.main()
