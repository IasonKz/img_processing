# Software validation — v3.0.0

Verification date: 2026-09-17. These checks establish software behavior, not
defect-detection performance on the user's images.

## Environment

Linux, Python 3.12.14, PyTorch 2.7.1+cpu, torchvision 0.22.1+cpu, Optuna 4.5.0,
ONNX 1.22.0, ONNX Runtime 1.30.0, NumPy 2.3.5, Pillow 12.3.0, SciPy 1.17.0,
scikit-learn 1.8.0, PyYAML 6.0.3 and psutil 7.2.2.

## Executed checks

| Check | Result and scope |
|---|---|
| Complete Python test suite | **197 tests passed, 0 failures/errors, 0 skipped**, in 52.595 seconds. Full transcript: [unit_tests.txt](validation/unit_tests.txt). Real PyTorch and ONNX dependencies were available. |
| Training backends | Actual forward/backward checks, training continuation, PatchCore behavior and loss normalization checks passed. |
| Full v3 smoke | Passed: grouped synthetic PNG/BMP images, local pretrained ResNet18 weights, two training epochs, Optuna study, supervised child process, selection and visual report. |
| Decisions and inference | Policy, manual threshold, argmax and scores-only decisions each produced a new result directory in the smoke run. |
| ONNX execution | Real export and runtime inference passed, including argmax and scores-only smoke packages. Unit tests also cover ensemble and PatchCore contracts. |
| Data contracts | Duplicate-label conflicts, unit grouping, whole-image padding, exact quarter-turns, unsupported image depth, fixed splits and checkpoint preprocessing are tested. |
| Search and budgets | Profile caps, resume accounting, real child termination at a short test deadline, cooperative pause/resume, frozen shortlists and confirmation handling are tested. Actual 2/6/12-hour sessions were not run here. |
| Dashboard | Local HTTP routes, command arguments, configuration snapshots, path containment, pause/resume, origin/CSRF checks and JavaScript syntax passed. |
| Packaging | A wheel built successfully; CLI modules, live dashboard assets and the static report template were present. The delivered ZIP is the editable source project. |
| Documentation | Application command examples were checked against the parser; relative document links were checked. |

The [smoke summary](validation/smoke_result.json) marks the dataset as synthetic
and `industrial_performance_evidence: false`. Its temporary paths identify test
fixtures in the verification environment; those datasets and model weights are
not included in the delivery. The smoke did not open the final-test split to
optimize the model or threshold.

ONNX Runtime telemetry is explicitly disabled before constructing runtime
sessions, including in generated standalone packages. Dashboard and hardware
telemetry logs are local. No company image data was available to this test run.

## Limits and local acceptance

- Windows 11 / PowerShell setup scripts and CUDA execution were not run in this
  Linux CPU environment. The setup script verifies an actual CPU/CUDA tensor
  operation; run `inspection.py doctor` on the target computer.
- Browser rendering was not visually inspected: browser downloads timed out.
  HTTP and JavaScript checks do not establish pixel layout or browser behavior.
- The exact laptop/workstation hardware is unknown. Native-resolution memory
  demand depends on image dimensions and model choice; a failed/OOM trial is
  recorded and is not a successful model result.
- Test the first real VIG run, review the good-reject and bad-escape counts,
  baselines, error images and tray distribution, and retain the final holdout for
  an independent evaluation after choosing the configuration.
- Three observed trays do not establish performance on all future trays. Related
  captures of one physical unit must stay grouped; if tray/slot IDs are reused,
  supply true unit IDs through `groups_csv`.
- Optuna can choose the strongest measured candidate inside the supplied search
  space and time allowance. It does not guarantee a globally best model, improved
  customer accuracy, or that the configured industrial limits are achievable.

For a repeatable installation check, run `scripts/smoke_v3.py` as described in
[INSTALLATION.md](INSTALLATION.md). For normal operation use [V3_GUIDE.md](V3_GUIDE.md).
