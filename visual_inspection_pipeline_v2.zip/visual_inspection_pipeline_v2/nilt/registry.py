"""Version comparison, operational selection and portable training archives."""
from __future__ import annotations

from contextlib import ExitStack
import html
from pathlib import Path
import shutil

import numpy as np

from .common import (read_json, write_json, write_csv, sha_file, safe_relative, utc_now,
                     load_project, object_hash, run_lock)
from .policy import metrics, empirical_pass
from .reporting import html_table, render_run_report


def _empty_destination(path, forbidden=None):
    path = Path(path).resolve()
    if forbidden and path.is_relative_to(Path(forbidden).resolve()):
        raise ValueError("Destination must be outside the source directory.")
    if path.exists() and any(path.iterdir()):
        raise FileExistsError(f"Destination must be new or empty: {path}")
    path.mkdir(parents=True, exist_ok=True)
    return path


def _dependency_paths(run, cfg):
    """Resolve only declared portable resource locations inside one run snapshot."""
    path = Path(run) / "dependency_locations.json"
    mapping = read_json(path) if path.exists() else {}
    if not isinstance(mapping, dict) or set(mapping) - {"weights_dir", "previous_run"}:
        raise ValueError("Unsupported training dependency location fields.")
    resolved = dict(cfg)
    for key, relative in mapping.items():
        resolved[key] = str(safe_relative(run, relative))
    return resolved


def create_training_package(run, output):
    """Create a coherent snapshot, including dependencies required for continuation."""
    from .workflow import open_run, load_selected
    from .engine import required_weight_names, weight_path
    run = Path(run).resolve()
    output = Path(output).resolve()
    suffixes = {".pt", ".json", ".jsonl", ".yaml", ".csv", ".npy", ".npz", ".html", ".txt", ".log"}
    active = set()
    with ExitStack() as locks:
        def snapshot(source_run, destination):
            source_run = Path(source_run).resolve()
            if source_run in active:
                raise ValueError("Cyclic previous_run lineage cannot be packaged.")
            if output.is_relative_to(source_run):
                raise ValueError("Package output must be outside every source run in the lineage.")
            active.add(source_run)
            locks.enter_context(run_lock(source_run))
            cfg, _ = open_run(source_run)
            cfg = _dependency_paths(source_run, cfg)
            if (source_run / "selected.json").exists():
                for member in load_selected(source_run)["members"]:
                    if sha_file(safe_relative(source_run, member["checkpoint"])) != member["sha256"]:
                        raise ValueError("Selected checkpoint checksum changed.")
            prior = Path(cfg["previous_run"]).resolve() if cfg.get("previous_run") else None
            if prior is not None and (prior == source_run or source_run.is_relative_to(prior)):
                raise ValueError("A predecessor run must not contain the current run directory.")
            # Existing embedded predecessors keep their location and are copied once,
            # under their own operation lock. External predecessors are embedded here.
            prior_relative = (prior.relative_to(source_run) if prior and prior.is_relative_to(source_run)
                              else Path("dependencies/previous"))
            destination.mkdir(parents=True, exist_ok=True)
            for source in sorted(source_run.rglob("*")):
                if prior is not None and source.is_relative_to(prior):
                    continue
                if not source.is_file() or source.suffix not in suffixes or source.is_symlink():
                    continue
                if source.name in ("runtime_overrides.json", "operation.lock", "dependency_locations.json") or "__pycache__" in source.parts:
                    continue
                target = destination / source.relative_to(source_run)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
            locations = {}
            if cfg.get("pretrained", True):
                relative_weights = Path("dependencies/weights")
                for name in required_weight_names(cfg):
                    source = weight_path(cfg, name)
                    if not source.is_file():
                        raise FileNotFoundError(f"Required pretrained weights are unavailable for portable continuation: {source}")
                    expected = sha_file(source)
                    target = destination / relative_weights / source.name
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(source, target)
                    if sha_file(target) != expected:
                        raise ValueError("A pretrained weights file changed while it was being packaged.")
                locations["weights_dir"] = relative_weights.as_posix()
            if prior is not None:
                snapshot(prior, destination / prior_relative)
                locations["previous_run"] = prior_relative.as_posix()
            write_json(destination / "dependency_locations.json", locations)
            active.remove(source_run)
            return cfg

        # Acquire the main run lock before examining state or copying any files.
        # snapshot owns all source locks until the complete archive has been hashed.
        if output.exists() and any(output.iterdir()):
            raise FileExistsError(f"Destination must be new or empty: {output}")
        cfg = snapshot(run, output / "run")
        files = {p.relative_to(output).as_posix(): sha_file(p)
                 for p in sorted((output / "run").rglob("*")) if p.is_file()}
        manifest = {"schema_version": 2, "kind": "training", "created_at": utc_now(),
                    "task": cfg["task"], "source_run_id": run.name, "dataset_included": False,
                    "dependencies_included": True,
                    "dataset_fingerprint": cfg.get("dataset_fingerprint"), "files": files}
        write_json(output / "package_manifest.json", manifest)
        (output / "RESTORE.txt").write_text(
            "Install the compatible application/training environment. Dataset images are not included.\n"
            "Required pretrained weights and predecessor experiment states are included.\n"
            "inspection restore --package PATH --data-root MATCHING_DATASET --output NEW_RUN_DIRECTORY\n",
            encoding="utf-8")
    return output


def restore_training_package(package, data_root, output):
    """Verify all archived evidence and rebind every lineage snapshot by image hash."""
    from .data import read_manifest, pixel_signature
    from .workflow import write_state
    from .engine import required_weight_names, weight_path
    package = Path(package).resolve()
    manifest = read_json(package / "package_manifest.json")
    if manifest.get("kind") != "training" or not isinstance(manifest.get("files"), dict):
        raise ValueError("Not a supported training package.")
    files = manifest["files"]
    for rel, expected in files.items():
        path = Path(rel)
        if not path.parts or path.parts[0] != "run" or len(path.parts) < 2:
            raise ValueError("Training package entry outside run directory.")
        source = safe_relative(package, rel)
        if not source.is_file() or sha_file(source) != expected:
            raise ValueError(f"Training package integrity failed: {rel}")
    required = {"run/config.json", "run/manifest.csv", "run/integrity.json"}
    if not required.issubset(files):
        raise ValueError("Training package missing required experiment files.")
    main = package / "run"
    rows = read_manifest(main / "manifest.csv")
    data_root = Path(data_root).resolve()
    prior_location = read_json(main / "data_location.json") if (main / "data_location.json").exists() else {}
    prior_paths = prior_location.get("image_paths", {})
    by_hash, image_paths = {}, {}
    for row in rows:
        relative = prior_paths.get(row["pixel_hash"], row["relative_path"])
        source = safe_relative(data_root, relative)
        if not source.is_file() or pixel_signature(source)[0] != row["pixel_hash"]:
            raise ValueError(f"Restored dataset content mismatch: {relative}")
        by_hash[row["pixel_hash"]] = row
        image_paths[row["pixel_hash"]] = relative

    snapshots, visited = [], set()
    def check_snapshot(source_run):
        source_run = Path(source_run).resolve()
        if source_run in visited:
            raise ValueError("Cyclic predecessor dependencies in training package.")
        visited.add(source_run)
        for filename in ("config.json", "manifest.csv", "integrity.json"):
            if (source_run / filename).relative_to(package).as_posix() not in files:
                raise ValueError(f"Predecessor snapshot is incomplete: {filename}")
        integrity = read_json(source_run / "integrity.json")
        for filename, field in (("config.json", "config_sha256"), ("manifest.csv", "manifest_sha256")):
            if sha_file(source_run / filename) != integrity.get(field):
                raise ValueError(f"Archived experiment integrity failed: {filename}")
        source_rows = read_manifest(source_run / "manifest.csv")
        for row in source_rows:
            current = by_hash.get(row["pixel_hash"])
            if current is None:
                raise ValueError(f"Main dataset is missing a predecessor image: {row['relative_path']}")
            if int(current["label"]) != int(row["label"]):
                raise ValueError("Predecessor and current dataset labels conflict.")
        cfg = read_json(source_run / "config.json")
        locations_path = source_run / "dependency_locations.json"
        locations = read_json(locations_path) if locations_path.exists() else {}
        resolved = _dependency_paths(source_run, cfg)
        if cfg.get("pretrained", True):
            if "weights_dir" not in locations:
                raise ValueError("Training package lacks portable pretrained weights. Recreate the package with dependencies.")
            for name in required_weight_names(resolved):
                relative = weight_path(resolved, name).relative_to(package).as_posix()
                if relative not in files:
                    raise ValueError(f"Training package missing required pretrained weights: {name}")
        snapshots.append((source_run.relative_to(main), {r["pixel_hash"]: image_paths[r["pixel_hash"]] for r in source_rows}))
        if cfg.get("previous_run"):
            if "previous_run" not in locations:
                raise ValueError("Training package lacks its predecessor snapshot. Recreate the package with dependencies.")
            check_snapshot(resolved["previous_run"])
    check_snapshot(main)

    output = _empty_destination(output, package)
    for rel in files:
        path = Path(rel)
        target = safe_relative(output, Path(*path.parts[1:]))
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(safe_relative(package, rel), target)
    for relative_run, paths in snapshots:
        write_json(output / relative_run / "data_location.json",
                   {"data_root": str(data_root), "image_paths": paths, "restored_at": utc_now()})
    # Immutable experiment and lineage metadata retain their original identities.
    old_state = read_json(output / "model_state.json") if (output / "model_state.json").exists() else {}
    write_state(output, "RESTORED", restored_from=str(package), prior_status=old_state.get("status"))
    return output


def compare_runs(old_run, new_run, output=None):
    from .workflow import open_run, load_selected, predict_members, verify_sources
    old_run, new_run = Path(old_run).resolve(), Path(new_run).resolve()
    old_cfg, old_rows = open_run(old_run)
    new_cfg, new_rows = open_run(new_run)
    if old_cfg["task"] != new_cfg["task"]:
        raise ValueError("Comparison requires the same task.")
    a, b = load_selected(old_run), load_selected(new_run)
    old_map = {r["pixel_hash"]: r for r in old_rows}
    new_map = {r["pixel_hash"]: r for r in new_rows}
    for digest in set(old_map) & set(new_map):
        if int(old_map[digest]["label"]) != int(new_map[digest]["label"]):
            raise ValueError("Shared images have conflicting labels; version comparison requires consistent ground truth.")
    shared = sorted(k for k in old_map.keys() & new_map.keys()
                    if old_map[k]["split"] == new_map[k]["split"] == "selection")
    if not shared:
        raise ValueError("No shared selection images; use a common independent evaluation dataset.")
    eval_old, eval_new = [old_map[k] for k in shared], [new_map[k] for k in shared]
    if {int(r["label"]) for r in eval_new} != {0, 1}:
        raise ValueError("Shared comparison set requires both good and bad.")
    old_used_groups = {r["group"] for r in old_rows if r["split"] in ("train", "val", "threshold")}
    new_used_groups = {r["group"] for r in new_rows if r["split"] in ("train", "val", "threshold")}
    if any(r["group"] in old_used_groups for r in eval_old) or any(r["group"] in new_used_groups for r in eval_new):
        raise ValueError("Comparison group overlaps training/validation/threshold data.")
    for x, y in zip(eval_old, eval_new):
        if x["group"] != y["group"]:
            raise ValueError("Shared image has different unit grouping; resolve grouping before comparison.")
    verify_sources(eval_old)
    verify_sources(eval_new)
    output = _empty_destination(output or new_run / "version_comparison")
    s_old, seconds_old = predict_members(old_run, a["members"], eval_old, old_cfg)
    s_new, seconds_new = predict_members(new_run, b["members"], eval_new, new_cfg)
    y = np.array([r["label"] for r in eval_new])
    p_old, p_new = np.where(s_old >= a["threshold"], 0, 1), np.where(s_new >= b["threshold"], 0, 1)
    m_old = metrics(y, s_old, a["threshold"], [r["group"] for r in eval_old], old_cfg["policy"]["confidence"])
    m_new = metrics(y, s_new, b["threshold"], [r["group"] for r in eval_new], new_cfg["policy"]["confidence"])
    records = []
    for kind in ("corrected", "regressions", "disagreements"):
        (output / kind).mkdir()
    for i, row in enumerate(eval_new):
        corrected = bool(p_old[i] != y[i] and p_new[i] == y[i])
        regression = bool(p_old[i] == y[i] and p_new[i] != y[i])
        disagreement = bool(p_old[i] != p_new[i])
        source = Path(row["path"])
        name = row["pixel_hash"][:24] + "__" + source.name[:80]
        for kind, condition in (("corrected", corrected), ("regressions", regression), ("disagreements", disagreement)):
            if condition:
                shutil.copy2(source, output / kind / name)
        records.append({"pixel_hash": row["pixel_hash"], "relative_path": row["relative_path"],
                        "true_class": "bad" if y[i] == 0 else "good",
                        "old_score": float(s_old[i]), "new_score": float(s_new[i]),
                        "old_threshold": a["threshold"], "new_threshold": b["threshold"],
                        "old_prediction": "bad" if p_old[i] == 0 else "good",
                        "new_prediction": "bad" if p_new[i] == 0 else "good",
                        "corrected": corrected, "regression": regression, "disagreement": disagreement})
    fields = ("bad_escape_rate", "good_reject_rate", "accuracy", "pr_auc_bad", "bad_passed_as_good_FN", "good_rejected_as_bad_FP")
    summary = {"old_run": str(old_run), "new_run": str(new_run), "task": new_cfg["task"],
               "evaluation_role": "shared selection data; development comparison, not independent qualification",
               "n_shared_images": len(shared), "n_old_selection": sum(r["split"] == "selection" for r in old_rows),
               "n_new_selection": sum(r["split"] == "selection" for r in new_rows),
               "old_threshold": a["threshold"], "new_threshold": b["threshold"],
               "old_score_type": a.get("score_type"), "new_score_type": b.get("score_type"),
               "old_metrics": m_old, "new_metrics": m_new,
               "new_minus_old": {k: m_new[k] - m_old[k] for k in fields},
               "n_corrected": sum(r["corrected"] for r in records),
               "n_regressions": sum(r["regression"] for r in records),
               "n_disagreements": sum(r["disagreement"] for r in records),
               "timing_seconds": {"old": seconds_old, "new": seconds_new},
               "score_scale_note": "Raw scores across different model types are not directly comparable."}
    write_json(output / "comparison.json", summary)
    write_csv(output / "paired_predictions.csv", records)
    page = '<!doctype html><html lang="en"><meta charset="utf-8"><title>Version comparison</title><style>body{font:15px system-ui;margin:30px}table{border-collapse:collapse}td,th{border:1px solid #ccc;padding:8px;vertical-align:top}pre{white-space:pre-wrap}</style><h1>Frozen version comparison</h1>' + html_table(summary) + "</html>"
    (output / "comparison.html").write_text(page, encoding="utf-8")
    if output == new_run / "version_comparison":
        write_json(new_run / "comparison_with_previous.json", summary)
        (new_run / "comparison_with_previous.html").write_text(page, encoding="utf-8")
        render_run_report(new_run)
    return summary


def registry_root(cfg):
    return Path(cfg["output_root"]) / cfg["task"]


def activate_run(run, project_config=None):
    from .workflow import open_run, load_selected, write_state
    run = Path(run).resolve()
    cfg, _ = open_run(run)
    selected = load_selected(run)
    if cfg.get("pilot", False):
        raise ValueError("Pilot runs cannot become operational releases. Run a full experiment with pilot:false.")
    state = read_json(run / "model_state.json") if (run / "model_state.json").exists() else {}
    evaluation_path = safe_relative(run, state.get("last_evaluation", "final_test_summary.json"))
    if not evaluation_path.exists():
        raise ValueError("Evaluate the frozen model on a final holdout before activation.")
    evaluation = read_json(evaluation_path)
    if evaluation.get("selected_sha256") != sha_file(run / "selected.json"):
        raise ValueError("Evaluation was performed for a different selected system.")
    if not evaluation.get("empirical_target_met"):
        raise ValueError("Final evaluation did not meet the configured defect/good rejection targets.")
    policy = cfg.get("release", {})
    if policy.get("require_complete_comparison", True) and not selected.get("comparison_complete", False):
        raise ValueError("The configured candidate comparison is incomplete.")
    if policy.get("require_statistical_evidence", True) and not evaluation.get("statistical_target_supported"):
        raise ValueError("Statistical evidence requirement is not met; inspect support, independence and test reuse.")
    for member in selected["members"]:
        if sha_file(safe_relative(run, member["checkpoint"])) != member["sha256"]:
            raise ValueError("Selected checkpoint integrity failed.")
    local_cfg = cfg
    if project_config:
        local_cfg = load_project(project_config, profile=cfg.get("profile", "workstation"), task=cfg["task"])[0]
    root = registry_root(local_cfg)
    root.mkdir(parents=True, exist_ok=True)
    pointer = root / "current_model.json"
    previous = read_json(pointer) if pointer.exists() else None
    import os
    record = {"schema_version": 2, "task": cfg["task"], "run_id": run.name,
              "run_path": os.path.relpath(run, root), "activated_at": utc_now(),
              "selected_sha256": sha_file(run / "selected.json"),
              "evaluation_sha256": sha_file(evaluation_path),
              "evaluation_path": evaluation_path.relative_to(run).as_posix(),
              "previous_run_id": previous.get("run_id") if previous else None}
    write_json(pointer, record)
    history = root / "activation_history.json"
    events = read_json(history) if history.exists() else []
    events.append(record)
    write_json(history, events)
    write_state(run, "ACTIVE", activated_at=record["activated_at"])
    return record


def current_run(cfg):
    root = registry_root(cfg)
    record = read_json(root / "current_model.json")
    run = (root / record["run_path"]).resolve()
    if sha_file(run / "selected.json") != record["selected_sha256"]:
        raise ValueError("Active model decision metadata changed.")
    return run
