"""ROI identity survives frozen decisions, workflows, systems and review."""
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
from PIL import Image

from nilt.common import read_json, sha_file, write_json
from nilt.decisions import create_decision, load_decision, predict_decision
from nilt.decision_lab import create_system, load_system, preview_system, run_system
from nilt.inspection_flow import create_workflow, load_workflow, run_workflow
from nilt.review import initialize_session, list_sessions
from nilt.review_dataset import export_review_dataset
from tests.test_integration_v2 import fixture_run


class ROIContextTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def run_fixture(self, name, scope):
        run, _, _ = fixture_run(self.root, name=name, threshold=.5)
        cfg = read_json(run / "config.json")
        if scope is not None:
            cfg["roi_scope"] = scope
        cfg["models"] = ["resnet18"]
        write_json(run / "config.json", cfg)
        write_json(run / "integrity.json", {"config_sha256": sha_file(run / "config.json"),
                                           "manifest_sha256": sha_file(run / "manifest.csv")})
        candidate = read_json(run / "selected.json")
        candidate.update(name="model", score_type="bad_probability_uncalibrated")
        checkpoint = run / candidate["members"][0]["checkpoint"]
        checkpoint.write_bytes(("opaque synthetic model " + name).encode())
        candidate["members"][0].update(architecture="resnet18", kind="supervised", sha256=sha_file(checkpoint))
        write_json(run / "selected.json", candidate)
        write_json(run / "selection_integrity.json", {"sha256": sha_file(run / "selected.json")})
        write_json(run / "candidates.json", [candidate])
        folder = run / "scores" / "model"
        folder.mkdir(parents=True)
        for split in ("threshold", "selection"):
            np.save(folder / (split + ".npy"), [.8, .9, .1, .2])
        write_json(folder / "provenance.json", {"candidate": "model", "manifest_sha256": sha_file(run / "manifest.csv"),
            "files": {split + ".npy": sha_file(folder / (split + ".npy")) for split in ("threshold", "selection")}})
        return run

    def decision(self, run):
        return create_decision(run, mode="manual", threshold=.5, output_root=self.root / "decisions")

    def images(self):
        root = self.root / "incoming"
        for label, color in (("good", "white"), ("bad", "black")):
            (root / label).mkdir(parents=True, exist_ok=True)
            Image.new("RGB", (32, 32), color).save(root / label / "crop.png")
        return root

    def assert_session_scope(self, output, scope):
        marker = read_json(output / "review_session.json")
        self.assertEqual(marker["metadata"]["roi_scope"], scope)
        self.assertEqual(marker["roi_scope"], scope)
        self.assertEqual(marker["task"], "top")
        listed = next(session for session in list_sessions(output.parent) if session["id"] == output.name)
        self.assertEqual(listed["roi_scope"], scope)

    def test_different_top_roi_scopes_cannot_form_workflow_or_system(self):
        corners = self.run_fixture("corners", "corners")
        label = self.run_fixture("label", "label")
        first, second = self.decision(corners), self.decision(label)
        with self.assertRaisesRegex(ValueError, "ROI scope"):
            create_workflow({"rule": "any_bad", "stages": [{"decision": str(first)}, {"decision": str(second)}]}, self.root / "workflows")
        with self.assertRaisesRegex(ValueError, "ROI scope"):
            preview_system({"kind": "weighted", "sources": [{"run": str(corners)}, {"run": str(label)}]})

    def test_decision_workflow_and_system_retain_scope_in_review_catalog(self):
        run = self.run_fixture("corners", "corners")
        decision = self.decision(run)
        self.assertEqual(load_decision(decision)[0]["roi_scope"], "corners")
        with patch("nilt.workflow.predict_members", return_value=(np.array([.8, .2]), .01)):
            output = predict_decision(decision, self.images(), self.root / "classified", labeled=True)
        self.assert_session_scope(output, "corners")
        workflow = create_workflow({"rule": "any_bad", "roi_scope": "corners", "stages": [{"decision": str(decision)}]}, self.root / "workflows")
        self.assertEqual(load_workflow(workflow)[0]["roi_scope"], "corners")
        with patch("nilt.workflow.predict_members", return_value=(np.array([.8, .2]), .01)):
            output = run_workflow(workflow, self.images(), self.root / "classified", labeled=True)
        self.assert_session_scope(output, "corners")
        system = create_system({"kind": "triage", "sources": [{"run": str(run)}], "thresholds": {"good": .3, "bad": .7}}, self.root / "systems")
        self.assertEqual(load_system(system)[0]["roi_scope"], "corners")
        with patch("nilt.workflow.predict_members", return_value=(np.array([.8, .2]), .01)):
            output = run_system(system, self.images(), self.root / "classified", labeled=True)
        self.assert_session_scope(output, "corners")

    def test_legacy_whole_image_records_still_load(self):
        run = self.run_fixture("legacy", None)
        decision = self.decision(run)
        record = read_json(decision)
        record.pop("roi_scope")
        write_json(decision, record)
        integrity = decision.with_name("decision_integrity.json")
        value = read_json(integrity)
        value["decision_sha256"] = sha_file(decision)
        write_json(integrity, value)
        self.assertNotIn("roi_scope", load_decision(decision)[0])
        session = self.root / "sessions" / "legacy"
        initialize_session(session, metadata={"task": "top"})
        marker = read_json(session / "review_session.json")
        marker.pop("roi_scope")
        marker.pop("task")
        write_json(session / "review_session.json", marker)
        listed = list_sessions(session.parent)[0]
        self.assertEqual(listed["roi_scope"], "whole_image")
        self.assertEqual(listed["task"], "top")

    def test_review_export_does_not_mix_scopes(self):
        sessions = []
        for scope in ("corners", "label"):
            path = self.root / "sessions" / scope
            initialize_session(path, metadata={"task": "top", "roi_scope": scope})
            sessions.append(path)
        with self.assertRaisesRegex(ValueError, "different ROI scopes"):
            export_review_dataset(sessions, self.root / "exports", include_replay=False)

    def test_threshold_report_preserves_roi_scope(self):
        from nilt.threshold_tuning import run_experiment
        run = self.run_fixture("label", "label")
        output = self.root / "threshold_report"
        with patch("nilt.workflow.predict_members", return_value=(np.array([.2, .8]), .01)):
            run_experiment({"run": str(run), "datasets": [{"path": str(self.images()), "name": "label crops"}]}, output)
        self.assertEqual(read_json(output / "report.json")["roi_scope"], "label")

    def test_quality_report_refuses_same_image_comparison_across_roi_scopes(self):
        from nilt.quality import build_quality_report
        from nilt.review import append_prediction, finish_session
        sessions = []
        for scope in ("corners", "label"):
            path = self.root / "sessions" / scope
            initialize_session(path, metadata={"task": "top", "roi_scope": scope}, total=1)
            append_prediction(path, {"relative_path": "crop.png", "true_class": "good", "predicted_class": "good",
                                    "score": .1, "status": "ok", "file_sha256": "a" * 64})
            finish_session(path, status="completed", completed=1)
            write_json(path / "summary.json", {"status": "completed"})
            sessions.append(path)
        report = build_quality_report([], sessions)
        self.assertEqual({s["roi_scope"] for s in report["sessions"]}, {"corners", "label"})
        self.assertFalse(report["comparisons"][0]["comparable"])
        self.assertIn("ROI scopes", report["comparisons"][0]["reason"])


if __name__ == "__main__":
    unittest.main()
