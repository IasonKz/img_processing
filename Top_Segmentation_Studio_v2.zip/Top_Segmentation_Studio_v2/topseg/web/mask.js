/* Discrete native-resolution raster operations shared by the UI and tests. */
(function (root) {
  'use strict';
  function decode(runs, total) {
    const out = new Uint8Array(total); let offset = 0;
    for (const pair of runs) {
      const [value, count] = pair;
      if (![0, 1, 2].includes(value) || !Number.isInteger(count) || count <= 0 || offset + count > total) throw new Error('Invalid mask data.');
      out.fill(value, offset, offset + count); offset += count;
    }
    if (offset !== total) throw new Error('Incomplete mask data.');
    return out;
  }
  function encode(mask) {
    if (mask.spans) {
      const result = []; let end = 0;
      for (const [start, count] of mask.spans) { if (start > end) result.push([0, start - end]); if (result.at(-1)?.[0] === 1) result[result.length - 1][1] += count; else result.push([1, count]); end = start + count; }
      if (end < mask.length) result.push([0, mask.length - end]);
      return result;
    }
    if (!mask.length) return [];
    const result = []; let start = 0;
    for (let i = 1; i <= mask.length; i++) {
      if (i === mask.length || mask[i] !== mask[start]) { result.push([mask[start], i - start]); start = i; }
    }
    return result;
  }
  function box(w, h, x0, y0, x1, y1, visit) {
    const left = Math.max(0, Math.floor(Math.min(x0, x1))), right = Math.min(w - 1, Math.ceil(Math.max(x0, x1)));
    const top = Math.max(0, Math.floor(Math.min(y0, y1))), bottom = Math.min(h - 1, Math.ceil(Math.max(y0, y1)));
    for (let y = top; y <= bottom; y++) for (let x = left; x <= right; x++) visit(x, y, x + y * w);
  }
  function ellipse(mask, w, h, cx, cy, rx, ry, value) {
    if (!(rx > 0 && ry > 0)) return;
    box(w, h, cx - rx, cy - ry, cx + rx, cy + ry, (x, y, index) => {
      if (((x + 0.5 - cx) / rx) ** 2 + ((y + 0.5 - cy) / ry) ** 2 <= 1) mask[index] = value;
    });
  }
  function stroke(mask, w, h, a, b, diameter, value) {
    const radius = Math.max(0.5, diameter / 2), length = Math.hypot(b.x - a.x, b.y - a.y);
    const steps = Math.max(1, Math.ceil(length / Math.max(0.5, radius / 2)));
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      ellipse(mask, w, h, Math.floor(a.x + (b.x - a.x) * t) + 0.5, Math.floor(a.y + (b.y - a.y) * t) + 0.5, radius, radius, value);
    }
  }
  function rectangle(mask, w, h, a, b, value) {
    const left = Math.min(a.x, b.x), right = Math.max(a.x, b.x), top = Math.min(a.y, b.y), bottom = Math.max(a.y, b.y);
    box(w, h, left, top, right, bottom, (x, y, index) => { if (x + 0.5 >= left && x + 0.5 <= right && y + 0.5 >= top && y + 0.5 <= bottom) mask[index] = value; });
  }
  function polygon(mask, w, h, points, value) {
    if (points.length < 3) return;
    box(w, h, Math.min(...points.map(p => p.x)), Math.min(...points.map(p => p.y)), Math.max(...points.map(p => p.x)), Math.max(...points.map(p => p.y)), (x, y, index) => {
      const px = x + 0.5, py = y + 0.5; let inside = false;
      for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
        const a = points[i], b = points[j];
        if ((a.y > py) !== (b.y > py) && px < (b.x - a.x) * (py - a.y) / (b.y - a.y) + a.x) inside = !inside;
      }
      if (inside) mask[index] = value;
    });
  }
  function counts(mask) {
    const result = [0, 0, 0]; for (const value of mask) result[value]++; return result;
  }
  function compact(mask) {
    if (mask.spans) return mask;
    const spans = []; let start = -1;
    for (let i = 0; i <= mask.length; i++) { if (i < mask.length && mask[i]) { if (start < 0) start = i; } else if (start >= 0) { spans.push([start, i - start]); start = -1; } }
    return {spans, length: mask.length};
  }
  function sparseDecode(runs, total) {
    const spans = []; let offset = 0;
    for (const [value, count] of runs) { if (![0, 1, 2].includes(value) || !Number.isInteger(count) || count <= 0 || offset + count > total) throw new Error('Invalid object mask data.'); if (value) { const last = spans.at(-1); if (last && last[0] + last[1] === offset) last[1] += count; else spans.push([offset, count]); } offset += count; }
    if (offset !== total) throw new Error('Incomplete object mask data.'); return {spans, length: total};
  }
  function each(mask, visit) { if (mask.spans) { for (const [start, count] of mask.spans) for (let i = start; i < start + count; i++) visit(i); } else for (let i = 0; i < mask.length; i++) if (mask[i]) visit(i); }
  function hasPixels(mask) { return mask.spans ? mask.spans.length > 0 : mask.some(Boolean); }
  function dense(mask) { if (!mask.spans) return mask; const result = new Uint8Array(mask.length); for (const [start, count] of mask.spans) result.fill(1, start, start + count); return result; }
  function strokeFootprint(w, h, a, b, diameter) {
    const radius = Math.max(0.5, diameter / 2) + 1;
    const left = Math.max(0, Math.floor(Math.min(a.x, b.x) - radius)), right = Math.min(w, Math.ceil(Math.max(a.x, b.x) + radius));
    const top = Math.max(0, Math.floor(Math.min(a.y, b.y) - radius)), bottom = Math.min(h, Math.ceil(Math.max(a.y, b.y) + radius));
    if (right <= left || bottom <= top) return {spans: [], length: w * h};
    const cw = right - left, ch = bottom - top, local = new Uint8Array(cw * ch);
    stroke(local, cw, ch, {x: a.x - left, y: a.y - top}, {x: b.x - left, y: b.y - top}, diameter, 1);
    const spans = [];
    for (let y = 0; y < ch; y++) { let start = -1; for (let x = 0; x <= cw; x++) { if (x < cw && local[x + y * cw]) { if (start < 0) start = x; } else if (start >= 0) { spans.push([left + start + (top + y) * w, x - start]); start = -1; } } }
    return {spans, length: w * h};
  }
  function subtract(mask, eraser) {
    const source = compact(mask), removal = compact(eraser), spans = []; let j = 0, changed = false;
    for (const [start, count] of source.spans) {
      let cursor = start; const end = start + count;
      while (j < removal.spans.length && removal.spans[j][0] + removal.spans[j][1] <= cursor) j++;
      let k = j;
      while (k < removal.spans.length && removal.spans[k][0] < end) {
        const [cut, length] = removal.spans[k]; if (cut > cursor) spans.push([cursor, cut - cursor]);
        if (cut + length > cursor) { changed = true; cursor = Math.min(end, cut + length); } if (cursor >= end) break; k++;
      }
      if (cursor < end) spans.push([cursor, end - cursor]);
    }
    return changed ? {spans, length: source.length} : source;
  }
  function union(...masks) {
    const usable = masks.filter(Boolean); if (!usable.length) return {spans: [], length: 0};
    const length = usable[0].length;
    if (usable.some(mask => mask.length !== length)) throw new Error('Mask geometries differ.');
    const all = usable.flatMap(mask => compact(mask).spans.map(span => [...span])).sort((a, b) => a[0] - b[0]), spans = [];
    for (const [start, count] of all) { const last = spans.at(-1); if (last && start <= last[0] + last[1]) last[1] = Math.max(last[0] + last[1], start + count) - last[0]; else spans.push([start, count]); }
    return {spans, length};
  }
  function chamferedRectangle(params) {
    const {cx, cy, width: w, height: h, rotation = 0} = params;
    if (![cx, cy, w, h, rotation].every(Number.isFinite) || w < 2 || h < 2) throw new Error('Boundary centre, dimensions and rotation must be finite; dimensions must be at least 2 px.');
    const cuts = params.cuts || {}, names = ['tl', 'tr', 'br', 'bl'];
    const c = Object.fromEntries(names.map(name => [name, {x: cuts[name]?.x ?? w * 0.15, y: cuts[name]?.y ?? h * 0.15}]));
    if (names.some(name => ![c[name].x, c[name].y].every(Number.isFinite) || c[name].x < 0 || c[name].y < 0)) throw new Error('Corner cuts must be finite and nonnegative.');
    if (c.tl.x + c.tr.x >= w || c.bl.x + c.br.x >= w || c.tl.y + c.bl.y >= h || c.tr.y + c.br.y >= h) throw new Error('Corner cuts must leave a straight segment on each side.');
    const raw = [{x: -w/2+c.tl.x,y:-h/2},{x:w/2-c.tr.x,y:-h/2},{x:w/2,y:-h/2+c.tr.y},{x:w/2,y:h/2-c.br.y},{x:w/2-c.br.x,y:h/2},{x:-w/2+c.bl.x,y:h/2},{x:-w/2,y:h/2-c.bl.y},{x:-w/2,y:-h/2+c.tl.y}];
    const angle = rotation * Math.PI / 180, cos = Math.cos(angle), sin = Math.sin(angle), points = [];
    for (const p of raw) { const q = {x: cx + p.x*cos-p.y*sin, y:cy+p.x*sin+p.y*cos}; if (!points.length || Math.hypot(q.x-points.at(-1).x,q.y-points.at(-1).y)>1e-6) points.push(q); }
    if (points.length>1 && Math.hypot(points[0].x-points.at(-1).x, points[0].y-points.at(-1).y)<1e-6) points.pop();
    if (!validPolygon(points)) throw new Error('Invalid corner geometry.');
    return {type:'polygon',points};
  }
  function octagon(a, b) {
    return chamferedRectangle({cx:(a.x+b.x)/2,cy:(a.y+b.y)/2,width:Math.max(2,Math.abs(b.x-a.x)),height:Math.max(2,Math.abs(b.y-a.y))});
  }
  function regionMask(w, h, roi) {
    const region = new Uint8Array(w * h);
    if (roi?.type === 'polygon') polygon(region, w, h, roi.points, 1);
    else if (roi) ellipse(region, w, h, roi.cx, roi.cy, roi.rx, roi.ry, 1);
    return region;
  }
  function compose(objects, region, visibleOnly = false) {
    const result = new Uint8Array(region.length);
    for (const object of objects) {
      if (visibleOnly && object.visible === false) continue;
      if (object.mask.length !== result.length) throw new Error('Annotation geometry does not match the image.');
      each(object.mask, i => { result[i] = region[i] ? 1 : 2; });
    }
    return result;
  }
  function bounds(mask, w, h) {
    let left = w, right = -1, top = h, bottom = -1, area = 0;
    each(mask, i => { const x = i % w, y = Math.floor(i / w); left = Math.min(left, x); right = Math.max(right, x); top = Math.min(top, y); bottom = Math.max(bottom, y); area++; });
    return area ? {left, right, top, bottom, area} : null;
  }
  function validPolygon(points) {
    if (points.length < 3) return false;
    let area = 0;
    const cross = (a, b, c) => (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
    const intersects = (a, b, c, d) => {
      const on = (p, q, r) => Math.abs(cross(p, q, r)) < 1e-8 && r.x >= Math.min(p.x, q.x) - 1e-8 && r.x <= Math.max(p.x, q.x) + 1e-8 && r.y >= Math.min(p.y, q.y) - 1e-8 && r.y <= Math.max(p.y, q.y) + 1e-8;
      return (cross(a, b, c) * cross(a, b, d) < 0 && cross(c, d, a) * cross(c, d, b) < 0) || on(a, b, c) || on(a, b, d) || on(c, d, a) || on(c, d, b);
    };
    for (let i = 0; i < points.length; i++) {
      const a = points[i], b = points[(i + 1) % points.length];
      if (![a.x, a.y].every(Number.isFinite) || Math.hypot(a.x - b.x, a.y - b.y) < 1e-6) return false;
      area += a.x * b.y - b.x * a.y;
      for (let j = i + 1; j < points.length; j++) {
        if (j === i + 1 || (i === 0 && j === points.length - 1)) continue;
        if (intersects(a, b, points[j], points[(j + 1) % points.length])) return false;
      }
    }
    return Math.abs(area) >= 2;
  }
  root.TopsegMask = {decode, encode, ellipse, stroke, rectangle, polygon, counts, octagon, regionMask, compose, bounds, validPolygon, compact, sparseDecode, each, hasPixels, dense, strokeFootprint, subtract, union, chamferedRectangle};
})(typeof window === 'undefined' ? globalThis : window);
