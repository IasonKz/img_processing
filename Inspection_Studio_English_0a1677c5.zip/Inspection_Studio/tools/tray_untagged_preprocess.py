"""Project entry point for preparing untagged tester folders for classification.

python tools/tray_untagged_preprocess.py --tray PATH --output NEW_FOLDER
Uses the same engine and options as inspection.py preprocess --mode untagged.
"""
from pathlib import Path
import sys

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from nilt import dataset_preparation


def main(argv=None):
    return dataset_preparation.main([*(sys.argv[1:] if argv is None else argv), "--mode", "untagged"])


if __name__ == "__main__":
    sys.exit(main())
