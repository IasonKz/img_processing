# Quality reports and training documentation

Quality reports combine recorded training-run evidence and recorded inspection sessions. They do not retrain a model, change a decision threshold, rerun a final test, upload data or modify manual labels.

## What the report contains

- Training configuration, dataset fingerprint, recorded split sizes, tray membership, checkpoint hashes and learning history.
- Model validation measurements, selection measurements and existing final-test measurements, kept separate.
- Per-epoch validation AP and training/validation loss curves for up to 12 recorded model/trial histories in source order. Full history is retained in the JSON and expandable training evidence. Training and validation loss may use different weighting.
- Existing final-test confusion counts and operating-rate charts, with the recorded qualification and prior-test-exposure flags.
- Previously recorded final-test and external-holdout predictions, broken down by tray against their original manual labels, with per-tray coverage and error denominators. These historical evaluations are not pooled with later inspection sessions, and no new evaluation is triggered.
- Original manual labels versus model decisions, and later operator judgments versus model decisions as a separate comparison.
- A two-by-three confusion matrix: manual Bad / Good against predicted Bad / Good / Human review.
- Per-session, per-task and per-tray decision counts, bad escape, good rejection, human-review load and automatic coverage.
- Prior training/development exposure where the source manifests permit it to be checked. Missing provenance is not treated as proof of independence.
- Comparisons on matching image content and task, including disagreement and label conflicts.
- Image-level records and a source-artifact inventory with SHA-256 hashes.

## Export

Choose a new or empty report folder. Existing reports are never overwritten or merged. Export creates:

| File | Content |
| --- | --- |
| `report.html` | Self-contained, offline report with the NILT logo and vector charts. |
| `report.json` | Complete machine-readable report snapshot. |
| `images.csv` | Every recorded image prediction, with manual labels, operator labels and provenance. |
| `dataset_membership.csv` | Exact recorded source-run image membership, labels, split assignments and content fingerprints. |
| `recorded_evaluation_predictions.csv` | Previously saved final-test and external-evaluation predictions, retaining run, task and evaluation identifiers. |
| `recorded_evaluation_trays.csv` | Tray-level manual-label comparisons from those recorded evaluations, with class counts, review and unavailable outcomes. |
| `trays.csv` | Per-session, per-task and per-tray metrics and counts. |
| `sessions.csv` | Session configuration, model identity, decision policy and metrics. |
| `models.csv` | Recorded model/trial completion, parameters, checkpoint hashes and validation metrics. |
| `measurements.csv` | Selection and existing final-test evidence. |
| `comparisons.csv` | Matched-image session comparisons. |
| `disagreements.csv` | Recorded disagreement details. |
| `artifacts.csv` | Source artifacts, sizes and content hashes. |
| `issues.csv` | Missing, inconsistent or unusable evidence. |
| `export_manifest.json` | Hashes and sizes of the exported files, excluding the manifest itself. |

Open `report.html` in a browser. No internet connection or application server is required. To produce a PDF, expand the required evidence panels, then use **Print → Save as PDF**. The HTML image table previews the first 250 image records; CSV and JSON retain all records. Reports contain paths, labels and configuration metadata, so treat them as internal company data.

Bar-chart previews show up to 40 groups; complete groups remain in the adjacent tables and data exports. Extremely long learning histories are subsampled for plotting only. No saved training measurements are dropped from the report snapshot.

CSV text fields beginning with spreadsheet formula characters are prefixed with an apostrophe to prevent formula execution when opened in Excel or LibreOffice. This only affects the CSV representation. JSON preserves the original text. UTF-8 paths and filenames are retained.

## Interpreting quality

**Model-flagged bad** describes a model decision, not a verified physical defect. **Human review pending** means a person still needs to resolve uncertain predictions. **No model-flagged bad** does not certify a tray as defect-free.

Bad escape uses all known manual-bad images as its denominator. Good rejection uses all known manual-good images. Review and unavailable decisions remain visible; they are not counted as correct automatic decisions. Selective accuracy only covers labeled images that received an automatic Good/Bad decision and must be read together with coverage.

An absent class produces an unavailable class-specific rate, not zero errors. Unlabeled inputs contribute to operational counts but cannot prove model accuracy. Later operator labels can be influenced by seeing the model result; they are not automatically an independent blinded test.

**Automatic coverage (labeled)** is the number of labeled images receiving a
Good/Bad decision divided by all labeled images. It is not the fraction of
images that have manual tags. Review and unavailable predictions reduce that
coverage; the number of labeled inputs is displayed separately.

Validation AP measures score ranking, not the false-reject rate at a particular threshold. Development metrics from different runs are not directly comparable unless their task, dataset and split are equivalent. The matched comparison only uses verified common image content with compatible manual references.

Reports do not create production qualification, calibrated probabilities or statistical independence. Use a frozen model and decision policy on independent held-out trays before establishing release criteria, and retain the full report plus source evidence for review.
