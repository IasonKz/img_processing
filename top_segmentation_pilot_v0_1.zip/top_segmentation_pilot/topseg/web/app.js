/* Local annotation controller. Source images are read-only working copies. */
'use strict';
(() => {
  const $ = id => document.getElementById(id), M = window.TopsegMask;
  const token = document.querySelector('meta[name="session-token"]').content;
  const state = {items: [], current: null, mask: null, image: null, tool: 'brush', label: 1, dirty: false, busy: false, zoom: 1, x: 0, y: 0, undo: [], redo: [], drag: null, polygon: [], pointer: null, space: false};
  const viewport = $('viewport'), wrap = $('canvas-wrap');
  const imageCanvas = $('image-canvas'), maskCanvas = $('mask-canvas'), guideCanvas = $('guide-canvas');
  const imageContext = imageCanvas.getContext('2d'), maskContext = maskCanvas.getContext('2d'), guideContext = guideCanvas.getContext('2d');
  let toastTimer;
  async function api(path, payload) {
    const response = await fetch(path, {method: payload === undefined ? 'GET' : 'POST', headers: {'X-Session-Token': token, ...(payload === undefined ? {} : {'Content-Type': 'application/json'})}, ...(payload === undefined ? {} : {body: JSON.stringify(payload)})});
    if (!response.ok) { let body; try { body = await response.json(); } catch (_) {} throw new Error(body?.error || `Request failed (${response.status}).`); }
    return response.json();
  }
  function toast(message, error = false) { $('toast').textContent = message; $('toast').classList.toggle('error', error); $('toast').classList.remove('hidden'); clearTimeout(toastTimer); toastTimer = setTimeout(() => $('toast').classList.add('hidden'), error ? 11000 : 4000); }
  function error(exc) { console.error(exc); toast(exc.message || String(exc), true); }
  function busy(value, message = 'Loading image…') { state.busy = value; $('loading').textContent = message; $('loading').classList.toggle('hidden', !value); updateButtons(); }
  function pending() { return state.dirty || state.polygon.length > 0 || (state.drag && state.drag.mode !== 'pan'); }
  function dirty() { state.dirty = true; updateStatus(); }
  function currentIndex() { return state.items.findIndex(x => x.id === state.current?.id); }
  function updateStatus() {
    const status = state.current?.status || 'unannotated';
    $('image-status').textContent = state.current ? (state.dirty ? 'Unsaved changes' : status === 'approved' ? 'Approved' : 'Draft · review required') : 'No image';
    $('image-status').className = `status ${state.dirty ? 'draft' : status}`;
    $('save-state').textContent = state.current ? (state.dirty ? '● Unsaved changes' : `Saved revision ${state.current.revision}`) : 'No unsaved changes';
    $('save-state').style.color = state.dirty ? '#ebbf76' : '';
    updateButtons();
  }
  function updateButtons() {
    const disabled = !state.current || state.busy;
    for (const id of ['save-draft', 'approve', 'approve-clean', 'regenerate', 'clear-mask', 'class-inner', 'class-outer', 'brush-size']) $(id).disabled = disabled;
    document.querySelectorAll('[data-tool], .properties-panel input, .properties-panel select, .properties-panel textarea').forEach(element => { element.disabled = disabled; });
    $('undo').disabled = disabled || !state.undo.length; $('redo').disabled = disabled || !state.redo.length;
    $('previous').disabled = disabled || currentIndex() <= 0; $('next').disabled = disabled || currentIndex() >= state.items.length - 1;
  }
  function renderQueue() {
    const approved = state.items.filter(x => x.status === 'approved').length;
    $('queue-total').textContent = state.items.length; $('progress-text').textContent = `${approved} / ${state.items.length} approved`;
    $('progress-bar').style.width = `${state.items.length ? approved / state.items.length * 100 : 0}%`;
    const list = $('image-list'); list.replaceChildren(); const term = $('search').value.toLowerCase();
    for (const item of state.items) {
      if (term && !item.relative_path.toLowerCase().includes(term)) continue;
      if ($('unapproved-only').checked && item.status === 'approved' && item.id !== state.current?.id) continue;
      const button = document.createElement('button'); button.className = `image-item ${item.id === state.current?.id ? 'active' : ''}`;
      button.dataset.imageId = item.id;
      const name = document.createElement('span'); name.className = 'image-item-name'; name.textContent = item.relative_path;
      const meta = document.createElement('span'); meta.className = 'image-item-meta';
      const status = document.createElement('span'); status.textContent = item.status === 'approved' ? '✓ Approved' : item.status === 'draft' ? '○ Draft' : '· Unreviewed'; if (item.status === 'approved') status.className = 'approved-dot';
      const dimensions = document.createElement('span'); dimensions.textContent = `${item.width} × ${item.height}`;
      meta.append(status, dimensions); button.append(name, meta); button.addEventListener('click', () => openImage(item.id)); list.append(button);
    }
  }
  function mergeItem(item) { const index = state.items.findIndex(x => x.id === item.id); if (index >= 0) state.items[index] = {...state.items[index], ...item}; renderQueue(); }
  async function openImage(id, force = false) {
    if (state.busy || (!force && state.current?.id === id)) return;
    if (pending() && !force && !confirm('Discard unsaved changes and open another image?')) return;
    busy(true);
    try {
      const item = await api(`/api/image/${id}`);
      const response = await fetch(item.rgb_url, {headers: {'X-Session-Token': token}});
      if (!response.ok) throw new Error('The working-copy image could not be loaded.');
      const image = await createImageBitmap(await response.blob());
      if (image.width !== item.width || image.height !== item.height) { image.close(); throw new Error('Image geometry differs from the annotation record.'); }
      if (state.image) state.image.close(); state.image = image; applyRecord(item); state.polygon = []; state.drag = null;
      for (const canvas of [imageCanvas, maskCanvas, guideCanvas]) { canvas.width = item.width; canvas.height = item.height; }
      wrap.style.width = `${item.width}px`; wrap.style.height = `${item.height}px`;
      imageContext.drawImage(image, 0, 0); $('empty-state').classList.add('hidden');
      $('image-name').textContent = item.relative_path; $('image-name').title = item.relative_path;
      $('image-position').textContent = `IMAGE ${currentIndex() + 1} OF ${state.items.length}`;
      $('canvas-info').textContent = `${item.width} × ${item.height} px · native annotation resolution`;
      fit(); drawMask(); drawGuide(); mergeItem(item);
      if (item.statistics?.proposal?.low_contrast) toast('Low-contrast image: inspect it manually. No reliable automatic proposal may be available.');
    } catch (exc) { error(exc); } finally { busy(false); }
  }
  function applyRecord(item) {
    state.current = item; state.mask = M.decode(item.mask_rle, item.width * item.height); state.dirty = false; state.undo = []; state.redo = [];
    $('notes').value = item.notes || ''; $('sensitivity').value = item.settings?.sensitivity ?? 4; $('min-area').value = item.settings?.min_area ?? 6; $('polarity').value = item.settings?.polarity || 'both';
    updateStatus();
  }
  function capture() { return {mask: state.mask.slice(), roi: {...state.current.roi}}; }
  function historyPush() {
    state.undo.push(capture()); state.redo = [];
    // Bound each history direction to 128 MiB and at most 30 revisions.
    const max = Math.max(1, Math.min(30, Math.floor(128 * 1024 * 1024 / state.mask.length)));
    if (state.undo.length > max) state.undo.splice(0, state.undo.length - max);
    updateButtons();
  }
  function historyMove(from, to) {
    if (!from.length || state.busy) return;
    state.polygon = []; state.drag = null; to.push(capture()); const previous = from.pop(); state.mask = previous.mask; state.current.roi = previous.roi; dirty(); drawMask(); drawGuide();
  }
  function drawMask() {
    if (!state.mask) return;
    const pixels = maskContext.createImageData(state.current.width, state.current.height), opacity = Number($('opacity').value) * 2.55;
    for (let i = 0; i < state.mask.length; i++) {
      const label = state.mask[i]; if (!label) continue; const p = i * 4;
      pixels.data[p] = label === 1 ? 255 : 70; pixels.data[p + 1] = label === 1 ? 100 : 186; pixels.data[p + 2] = label === 1 ? 105 : 255; pixels.data[p + 3] = opacity;
    }
    maskContext.putImageData(pixels, 0, 0); maskCanvas.style.display = $('show-mask').checked ? '' : 'none';
    const counts = M.counts(state.mask); $('inner-count').textContent = counts[1].toLocaleString(); $('outer-count').textContent = counts[2].toLocaleString();
  }
  function roiString(roi) { return `Centre ${Math.round(roi.cx)}, ${Math.round(roi.cy)} · radii ${Math.round(roi.rx)} × ${Math.round(roi.ry)} px`; }
  function ellipseFromDrag(a, b, shift) {
    let dx = b.x - a.x, dy = b.y - a.y;
    if (shift) { const size = Math.min(Math.abs(dx), Math.abs(dy)); dx = Math.sign(dx || 1) * size; dy = Math.sign(dy || 1) * size; }
    return {cx: a.x + dx / 2, cy: a.y + dy / 2, rx: Math.abs(dx) / 2, ry: Math.abs(dy) / 2};
  }
  function drawGuide() {
    guideContext.clearRect(0, 0, guideCanvas.width, guideCanvas.height);
    if (!state.current) return;
    const ctx = guideContext, roi = state.current.roi, lineWidth = 1.5 / state.zoom;
    const drawEllipse = r => { if (r && r.rx > 0 && r.ry > 0) { ctx.beginPath(); ctx.ellipse(r.cx, r.cy, r.rx, r.ry, 0, 0, 2 * Math.PI); ctx.stroke(); } };
    ctx.lineWidth = lineWidth;
    if (roi && $('show-roi').checked) { ctx.strokeStyle = '#f4d77c'; ctx.setLineDash([7 / state.zoom, 5 / state.zoom]); drawEllipse(roi); ctx.setLineDash([]); }
    $('roi-readout').textContent = roi ? roiString(roi) : 'Draw a lens ROI to guide automatic proposals.';
    ctx.strokeStyle = state.tool === 'roi' ? '#f4d77c' : state.tool === 'eraser' ? '#ffffff' : state.label === 1 ? '#ff817e' : '#5ec4ff';
    ctx.fillStyle = state.tool === 'roi' ? '#f4d77c22' : state.label === 1 ? '#ff817e22' : '#5ec4ff22';
    const drag = state.drag;
    if (drag && drag.mode === 'shape') {
      const a = drag.start, b = drag.end;
      if (state.tool === 'circle') { const r = Math.hypot(b.x - a.x, b.y - a.y); drawEllipse({cx: a.x, cy: a.y, rx: r, ry: r}); ctx.fill(); }
      else if (state.tool === 'ellipse' || state.tool === 'roi') { drawEllipse(ellipseFromDrag(a, b, drag.shift)); ctx.fill(); }
      else if (state.tool === 'rectangle') { ctx.strokeRect(a.x, a.y, b.x - a.x, b.y - a.y); ctx.fillRect(a.x, a.y, b.x - a.x, b.y - a.y); }
    }
    if (state.polygon.length) {
      ctx.beginPath(); ctx.moveTo(state.polygon[0].x, state.polygon[0].y); for (const p of state.polygon.slice(1)) ctx.lineTo(p.x, p.y); if (state.pointer) ctx.lineTo(state.pointer.x, state.pointer.y); ctx.stroke();
      for (const p of state.polygon) { ctx.beginPath(); ctx.arc(p.x, p.y, 3 / state.zoom, 0, 2 * Math.PI); ctx.fill(); }
    }
    if (state.pointer && !state.space && ['brush', 'eraser'].includes(state.tool)) drawEllipse({cx: state.pointer.x, cy: state.pointer.y, rx: Number($('brush-size').value) / 2, ry: Number($('brush-size').value) / 2});
  }
  function transform() { wrap.style.transform = `translate(${state.x}px, ${state.y}px) scale(${state.zoom})`; $('zoom-value').textContent = `${Math.round(state.zoom * 100)}%`; drawGuide(); }
  function fit() { if (!state.current) return; state.zoom = Math.max(0.01, Math.min((viewport.clientWidth - 40) / state.current.width, (viewport.clientHeight - 40) / state.current.height)); state.x = (viewport.clientWidth - state.current.width * state.zoom) / 2; state.y = (viewport.clientHeight - state.current.height * state.zoom) / 2; transform(); }
  function zoom(value, clientX, clientY) {
    if (!state.current) return; const rect = viewport.getBoundingClientRect(), px = (clientX ?? rect.left + rect.width / 2) - rect.left, py = (clientY ?? rect.top + rect.height / 2) - rect.top;
    const next = Math.max(0.01, Math.min(30, value)), ratio = next / state.zoom; state.x = px - (px - state.x) * ratio; state.y = py - (py - state.y) * ratio; state.zoom = next; transform();
  }
  function point(event) { const rect = viewport.getBoundingClientRect(); return {x: (event.clientX - rect.left - state.x) / state.zoom, y: (event.clientY - rect.top - state.y) / state.zoom}; }
  function inside(p) { return state.current && p.x >= 0 && p.y >= 0 && p.x < state.current.width && p.y < state.current.height; }
  function bounded(p) { return {x: Math.max(0, Math.min(state.current.width, p.x)), y: Math.max(0, Math.min(state.current.height, p.y))}; }
  function setTool(tool) { if (state.polygon.length && tool !== 'polygon' && !confirm('Discard the unfinished polygon?')) return; state.polygon = []; state.drag = null; state.tool = tool; document.querySelectorAll('[data-tool]').forEach(x => x.classList.toggle('selected', x.dataset.tool === tool)); viewport.style.cursor = tool === 'pan' ? 'grab' : 'crosshair'; drawGuide(); }
  function setClass(label) { state.label = label; $('class-inner').classList.toggle('selected', label === 1); $('class-outer').classList.toggle('selected', label === 2); drawGuide(); }
  function finishPolygon() { if (state.polygon.length < 3) { toast('A polygon needs at least three vertices.'); return; } historyPush(); M.polygon(state.mask, state.current.width, state.current.height, state.polygon, state.label); state.polygon = []; dirty(); drawMask(); drawGuide(); }
  viewport.addEventListener('pointerdown', event => {
    if (!state.current || state.busy || (event.button !== 0 && event.button !== 1)) return;
    event.preventDefault(); viewport.focus(); const p = point(event);
    if (state.tool === 'pan' || state.space || event.button === 1) { state.drag = {mode: 'pan', start: {x: event.clientX, y: event.clientY}, originX: state.x, originY: state.y}; viewport.setPointerCapture(event.pointerId); return; }
    if (!inside(p)) return;
    if (state.tool === 'polygon') { state.polygon.push(p); drawGuide(); return; }
    viewport.setPointerCapture(event.pointerId);
    if (['brush', 'eraser'].includes(state.tool)) { historyPush(); state.drag = {mode: 'brush', last: p}; M.stroke(state.mask, state.current.width, state.current.height, p, p, Number($('brush-size').value), state.tool === 'eraser' ? 0 : state.label); dirty(); drawMask(); }
    else state.drag = {mode: 'shape', start: p, end: p, shift: event.shiftKey};
    drawGuide();
  });
  viewport.addEventListener('pointermove', event => {
    if (!state.current || state.busy) return;
    state.pointer = point(event); const drag = state.drag;
    if (drag?.mode === 'pan') { state.x = drag.originX + event.clientX - drag.start.x; state.y = drag.originY + event.clientY - drag.start.y; transform(); return; }
    if (drag?.mode === 'brush') { M.stroke(state.mask, state.current.width, state.current.height, drag.last, state.pointer, Number($('brush-size').value), state.tool === 'eraser' ? 0 : state.label); drag.last = state.pointer; dirty(); drawMask(); }
    else if (drag?.mode === 'shape') { drag.end = bounded(state.pointer); drag.shift = event.shiftKey; }
    drawGuide();
  });
  viewport.addEventListener('pointerup', event => {
    const drag = state.drag; if (!drag) return;
    if (drag.mode === 'shape') {
      drag.end = bounded(point(event)); drag.shift = event.shiftKey; const a = drag.start, b = drag.end;
      if (Math.hypot(b.x - a.x, b.y - a.y) >= 1) {
        historyPush(); const w = state.current.width, h = state.current.height;
        if (state.tool === 'circle') { const radius = Math.hypot(b.x - a.x, b.y - a.y); M.ellipse(state.mask, w, h, a.x, a.y, radius, radius, state.label); }
        else if (state.tool === 'rectangle') M.rectangle(state.mask, w, h, a, b, state.label);
        else { const roi = ellipseFromDrag(a, b, drag.shift); if (roi.rx >= 1 && roi.ry >= 1) { if (state.tool === 'roi') state.current.roi = roi; else M.ellipse(state.mask, w, h, roi.cx, roi.cy, roi.rx, roi.ry, state.label); } }
        dirty(); drawMask();
      }
    }
    state.drag = null; if (viewport.hasPointerCapture(event.pointerId)) viewport.releasePointerCapture(event.pointerId); drawGuide();
  });
  viewport.addEventListener('pointercancel', () => { state.drag = null; drawGuide(); });
  viewport.addEventListener('pointerleave', () => { if (!state.drag) { state.pointer = null; drawGuide(); } });
  viewport.addEventListener('wheel', event => { event.preventDefault(); if (!state.busy) zoom(state.zoom * Math.exp(-event.deltaY * 0.0015), event.clientX, event.clientY); }, {passive: false});
  function settings() {
    const sensitivity = Number($('sensitivity').value), minArea = Number($('min-area').value);
    if (!Number.isFinite(sensitivity) || sensitivity < 0.5 || sensitivity > 20 || !Number.isInteger(minArea) || minArea < 1 || minArea > 100000) throw new Error('Sensitivity must be 0.5–20 and minimum area must be an integer from 1 to 100000.');
    return {...state.current.settings, sensitivity, min_area: minArea, polarity: $('polarity').value};
  }
  async function save(approved, clean = false) {
    if (!state.current || state.busy) return;
    if (state.polygon.length || state.drag) { toast('Finish the current stroke or shape, or cancel the polygon, before saving.', true); return; }
    const counts = M.counts(state.mask);
    if (approved && counts[1] + counts[2] === 0 && !clean) { toast('This mask is empty. Use “Approve clean & next” to confirm a reviewed negative image.', true); return; }
    if (clean && counts[1] + counts[2] > 0) { toast('Clear all defect pixels before approving a clean image.', true); return; }
    let payload; try { payload = {mask_rle: M.encode(state.mask), roi: state.current.roi, settings: settings(), expected_revision: state.current.revision, approved, clean, notes: $('notes').value}; } catch (exc) { error(exc); return; }
    const id = state.current.id; busy(true, 'Saving annotation…');
    try {
      const item = await api(`/api/image/${id}/annotation`, payload); applyRecord(item); mergeItem(item); drawMask(); drawGuide();
      toast(approved ? (clean ? 'Clean image approved.' : 'Annotation approved.') : 'Draft saved.');
      if (approved) {
        const index = currentIndex(); const next = [...state.items.slice(index + 1), ...state.items.slice(0, index)].find(x => x.status !== 'approved');
        busy(false); if (next) await openImage(next.id); else toast('Review complete. All images are approved; the dataset is ready for training.');
      }
    } catch (exc) { error(exc); } finally { busy(false); updateStatus(); }
  }
  async function regenerate() {
    if (!state.current || state.busy) return;
    if (!confirm('Replace the current defect mask with a new automatic proposal? Unsaved mask, ROI, detector-setting, and note changes may be replaced. The result remains a draft.')) return;
    let payload; try { payload = {roi: state.current.roi, settings: settings(), expected_revision: state.current.revision}; } catch (exc) { error(exc); return; }
    busy(true, 'Generating classical defect proposals…');
    try { const item = await api(`/api/image/${state.current.id}/propose`, payload); applyRecord(item); state.polygon = []; mergeItem(item); drawMask(); drawGuide(); toast('New proposal saved as a draft. Review and correct it before approval.'); } catch (exc) { error(exc); } finally { busy(false); }
  }
  function navigate(direction) { const index = currentIndex() + direction; if (index >= 0 && index < state.items.length) openImage(state.items[index].id); }
  document.querySelectorAll('[data-tool]').forEach(x => x.addEventListener('click', () => setTool(x.dataset.tool)));
  $('class-inner').addEventListener('click', () => setClass(1)); $('class-outer').addEventListener('click', () => setClass(2));
  $('brush-size').addEventListener('input', () => { $('brush-value').textContent = `${$('brush-size').value} px`; drawGuide(); });
  $('opacity').addEventListener('input', () => { $('opacity-value').textContent = `${$('opacity').value}%`; drawMask(); });
  $('show-mask').addEventListener('change', drawMask); $('show-roi').addEventListener('change', drawGuide);
  $('undo').addEventListener('click', () => historyMove(state.undo, state.redo)); $('redo').addEventListener('click', () => historyMove(state.redo, state.undo));
  $('fit').addEventListener('click', fit); $('actual-size').addEventListener('click', () => zoom(1)); $('zoom-in').addEventListener('click', () => zoom(state.zoom * 1.25)); $('zoom-out').addEventListener('click', () => zoom(state.zoom / 1.25));
  $('previous').addEventListener('click', () => navigate(-1)); $('next').addEventListener('click', () => navigate(1));
  $('save-draft').addEventListener('click', () => save(false)); $('approve').addEventListener('click', () => save(true)); $('approve-clean').addEventListener('click', () => save(true, true)); $('regenerate').addEventListener('click', regenerate);
  $('clear-mask').addEventListener('click', () => { if (state.current && !state.busy && confirm('Clear every defect pixel in this image? This can be undone before saving.')) { historyPush(); state.mask.fill(0); state.polygon = []; dirty(); drawMask(); drawGuide(); } });
  $('search').addEventListener('input', renderQueue); $('unapproved-only').addEventListener('change', renderQueue);
  for (const id of ['notes', 'sensitivity', 'min-area', 'polarity']) $(id).addEventListener('input', () => { if (state.current && !state.busy) dirty(); });
  $('help-button').addEventListener('click', () => $('help-dialog').showModal()); $('close-help').addEventListener('click', () => $('help-dialog').close());
  window.addEventListener('beforeunload', event => { if (pending()) { event.preventDefault(); event.returnValue = ''; } });
  window.addEventListener('blur', () => { state.space = false; });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && !$('help-dialog').open && (state.polygon.length || state.drag?.mode === 'shape')) { state.polygon = []; state.drag = null; drawGuide(); event.preventDefault(); return; }
    const key = event.key.toLowerCase();
    if ((event.ctrlKey || event.metaKey) && key === 's') { event.preventDefault(); if (!state.busy && !$('help-dialog').open) save(false); return; }
    if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName) || $('help-dialog').open) return;
    if ((event.ctrlKey || event.metaKey) && ['z', 'y', 's'].includes(key)) {
      event.preventDefault(); if (state.busy) return;
      if (key === 's') save(false); else if (key === 'y' || event.shiftKey) historyMove(state.redo, state.undo); else historyMove(state.undo, state.redo); return;
    }
    if (state.busy || event.ctrlKey || event.metaKey || event.altKey) return;
    const shortcuts = {b: 'brush', c: 'circle', e: 'ellipse', p: 'polygon', r: 'rectangle', x: 'eraser', l: 'roi', h: 'pan'};
    if (shortcuts[key]) setTool(shortcuts[key]);
    else if (key === '1' || key === '2') setClass(Number(key));
    else if (key === ' ') { state.space = true; event.preventDefault(); }
    else if (key === 'enter' && state.polygon.length) { finishPolygon(); event.preventDefault(); }
    else if (key === '0') fit();
    else if (key === '+' || key === '=') zoom(state.zoom * 1.25);
    else if (key === '-') zoom(state.zoom / 1.25);
    else if (key === 'm') { $('show-mask').checked = !$('show-mask').checked; drawMask(); }
    else if (key === 'pageup') { navigate(-1); event.preventDefault(); }
    else if (key === 'pagedown') { navigate(1); event.preventDefault(); }
    else if (key === '?') $('help-dialog').showModal();
  });
  document.addEventListener('keyup', event => { if (event.key === ' ') state.space = false; });
  new ResizeObserver(() => { if (state.current && !state.drag) drawGuide(); }).observe(viewport);
  async function start() {
    try {
      const project = await api('/api/project'); state.items = project.items; renderQueue(); updateButtons();
      if (state.items.length) await openImage((state.items.find(x => x.status !== 'approved') || state.items[0]).id);
      else { $('empty-state').querySelector('h2').textContent = 'No images have been imported'; $('empty-state').querySelector('p').textContent = 'Set input_dir in your configuration, then run the import command.'; }
    } catch (exc) { error(exc); $('empty-state').querySelector('h2').textContent = 'Workspace could not be loaded'; $('empty-state').querySelector('p').textContent = exc.message; }
  }
  start();
})();
