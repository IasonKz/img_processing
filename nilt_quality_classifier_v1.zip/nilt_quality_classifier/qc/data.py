from __future__ import annotations

import hashlib
import math
import random
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Sequence

import cv2
import numpy as np
import pandas as pd
import torch
from PIL import Image, ImageOps
from torch.utils.data import DataLoader, Dataset, WeightedRandomSampler
from torchvision import transforms
from torchvision.transforms import InterpolationMode

from .constants import (
    BAD_LABEL,
    DEFAULT_IMAGE_EXTENSIONS,
    GOOD_LABEL,
    INDEX_TO_LABEL,
    LABEL_TO_INDEX,
)

# Avoid oversubscribing CPU threads when several DataLoader workers call OpenCV.
try:
    cv2.setNumThreads(0)
except Exception:
    pass


DEFAULT_UNIT_ID_REGEX = r"(?i)(C\d+[-_]Rc\d+Cc\d+)"


@dataclass
class ImageRecord:
    path: str
    label: int
    group: str
    source: str = "dataset"
    split: str = ""
    sample_weight: float = 1.0

    @property
    def label_name(self) -> str:
        return INDEX_TO_LABEL[int(self.label)]


def canonicalize_unit_id(value: str) -> str:
    """Normalize IDs so ``C...-Rc...`` and ``C..._Rc...`` join correctly."""
    return re.sub(r"[^A-Za-z0-9]", "", str(value)).upper()


def extract_unit_id(value: str | Path, pattern: str = DEFAULT_UNIT_ID_REGEX) -> tuple[str, str]:
    text = str(value)
    match = re.search(pattern, text)
    if match:
        raw = match.group(1) if match.groups() else match.group(0)
    else:
        raw = Path(text).stem
    return raw, canonicalize_unit_id(raw)


def normalize_extensions(values: Sequence[str] | None) -> set[str]:
    extensions = values or DEFAULT_IMAGE_EXTENSIONS
    normalized: set[str] = set()
    for value in extensions:
        suffix = str(value).strip().lower()
        if not suffix.startswith("."):
            suffix = "." + suffix
        normalized.add(suffix)
    return normalized


def list_images(root: str | Path, *, recursive: bool, extensions: Sequence[str] | None) -> list[Path]:
    root_path = Path(root).expanduser().resolve()
    if not root_path.is_dir():
        raise FileNotFoundError(f"Image folder not found: {root_path}")
    allowed = normalize_extensions(extensions)
    iterator = root_path.rglob("*") if recursive else root_path.glob("*")
    return sorted(path for path in iterator if path.is_file() and path.suffix.lower() in allowed)


def scan_labeled_root(
    root: str | Path,
    *,
    source: str = "dataset",
    recursive: bool = True,
    extensions: Sequence[str] | None = None,
    unit_id_regex: str = DEFAULT_UNIT_ID_REGEX,
    sample_weight: float = 1.0,
) -> list[ImageRecord]:
    """Scan one folder containing exactly ``good/`` and ``bad/`` subfolders."""
    root_path = Path(root).expanduser().resolve()
    if not root_path.is_dir():
        raise FileNotFoundError(f"Dataset root not found: {root_path}")

    records: list[ImageRecord] = []
    for label_name in (GOOD_LABEL, BAD_LABEL):
        class_dir = root_path / label_name
        if not class_dir.is_dir():
            raise FileNotFoundError(
                f"Expected class folder '{label_name}' at: {class_dir}\n"
                "The required structure is dataset_root/good and dataset_root/bad."
            )
        for path in list_images(class_dir, recursive=recursive, extensions=extensions):
            _, group = extract_unit_id(path.name, unit_id_regex)
            records.append(
                ImageRecord(
                    path=str(path),
                    label=LABEL_TO_INDEX[label_name],
                    group=group,
                    source=source,
                    sample_weight=float(sample_weight),
                )
            )

    if not records:
        raise ValueError(f"No supported images found under: {root_path}")
    validate_records(records, require_both_classes=True)
    return records


def validate_records(records: Sequence[ImageRecord], *, require_both_classes: bool = False) -> None:
    if not records:
        raise ValueError("No image records were provided.")

    paths: set[str] = set()
    group_labels: dict[str, set[int]] = {}
    for record in records:
        path = str(Path(record.path).resolve())
        if path in paths:
            raise ValueError(f"Duplicate image path in dataset: {path}")
        paths.add(path)
        if int(record.label) not in INDEX_TO_LABEL:
            raise ValueError(f"Unsupported label {record.label} for {record.path}")
        group_labels.setdefault(record.group, set()).add(int(record.label))

    conflicts = [group for group, labels in group_labels.items() if len(labels) > 1]
    if conflicts:
        preview = ", ".join(conflicts[:10])
        raise ValueError(
            "The same Unit Identifier/group appears with both GOOD and BAD labels. "
            f"This would make group-safe splitting impossible. Examples: {preview}"
        )

    if require_both_classes:
        labels = {int(record.label) for record in records}
        if labels != {0, 1}:
            present = [INDEX_TO_LABEL[label] for label in sorted(labels)]
            raise ValueError(f"Both GOOD and BAD are required; found only: {present}")


def class_counts(records: Sequence[ImageRecord]) -> dict[str, int]:
    return {
        GOOD_LABEL: sum(int(record.label) == 0 for record in records),
        BAD_LABEL: sum(int(record.label) == 1 for record in records),
    }


def split_counts(records: Sequence[ImageRecord]) -> dict[str, dict[str, int]]:
    result: dict[str, dict[str, int]] = {}
    for split in sorted({record.split for record in records}):
        result[split] = class_counts([record for record in records if record.split == split])
    return result


def _allocate_counts(n: int, validation_fraction: float, test_fraction: float) -> tuple[int, int, int]:
    if n <= 0:
        return 0, 0, 0

    n_test = int(round(n * test_fraction))
    n_val = int(round(n * validation_fraction))

    if test_fraction > 0 and n >= 3:
        n_test = max(1, n_test)
    if validation_fraction > 0 and n >= 3:
        n_val = max(1, n_val)

    # Always leave at least one group for training.
    while n_test + n_val >= n:
        if n_test >= n_val and n_test > 0:
            n_test -= 1
        elif n_val > 0:
            n_val -= 1
        else:
            break

    n_train = n - n_val - n_test
    return n_train, n_val, n_test


def stratified_group_split(
    records: Sequence[ImageRecord],
    *,
    validation_fraction: float = 0.15,
    test_fraction: float = 0.15,
    seed: int = 42,
    fixed_validation_substrings: Sequence[str] | None = None,
    fixed_test_substrings: Sequence[str] | None = None,
    require_both_classes: bool = True,
) -> list[ImageRecord]:
    """Split by group while approximately preserving the two class ratios.

    The algorithm first assigns any fixed source/path substrings and then
    stratifies the remaining groups independently within GOOD and BAD.
    """
    if validation_fraction < 0 or test_fraction < 0 or validation_fraction + test_fraction >= 1:
        raise ValueError("validation_fraction and test_fraction must be >=0 and sum to <1")

    copied = [ImageRecord(**asdict(record)) for record in records]
    validate_records(copied, require_both_classes=require_both_classes)

    fixed_validation_substrings = [str(x).lower() for x in (fixed_validation_substrings or [])]
    fixed_test_substrings = [str(x).lower() for x in (fixed_test_substrings or [])]

    group_to_records: dict[str, list[ImageRecord]] = {}
    for record in copied:
        group_to_records.setdefault(record.group, []).append(record)

    fixed_assignments: dict[str, str] = {}
    for group, group_records in group_to_records.items():
        searchable = " ".join([group] + [record.path for record in group_records]).lower()
        in_test = any(token in searchable for token in fixed_test_substrings)
        in_val = any(token in searchable for token in fixed_validation_substrings)
        if in_test and in_val:
            raise ValueError(f"Group {group} matched both fixed validation and fixed test filters")
        if in_test:
            fixed_assignments[group] = "test"
        elif in_val:
            fixed_assignments[group] = "validation"

    rng = random.Random(seed)
    remaining_by_label: dict[int, list[str]] = {0: [], 1: []}
    for group, group_records in group_to_records.items():
        if group in fixed_assignments:
            continue
        label = int(group_records[0].label)
        remaining_by_label[label].append(group)

    assignments = dict(fixed_assignments)
    for label, groups in remaining_by_label.items():
        rng.shuffle(groups)
        _, n_val, n_test = _allocate_counts(len(groups), validation_fraction, test_fraction)
        test_groups = set(groups[:n_test])
        val_groups = set(groups[n_test : n_test + n_val])
        for group in groups:
            if group in test_groups:
                assignments[group] = "test"
            elif group in val_groups:
                assignments[group] = "validation"
            else:
                assignments[group] = "train"

    for record in copied:
        record.split = assignments[record.group]

    validate_split(copied, require_train_both_classes=require_both_classes)
    return copied


def validate_split(
    records: Sequence[ImageRecord],
    *,
    require_train_both_classes: bool = True,
) -> None:
    group_splits: dict[str, set[str]] = {}
    for record in records:
        if record.split not in {"train", "validation", "test"}:
            raise ValueError(f"Invalid split '{record.split}' for {record.path}")
        group_splits.setdefault(record.group, set()).add(record.split)
    leakage = [group for group, splits in group_splits.items() if len(splits) > 1]
    if leakage:
        raise ValueError(f"Group leakage detected for: {', '.join(leakage[:10])}")

    train_labels = {record.label for record in records if record.split == "train"}
    if require_train_both_classes and train_labels != {0, 1}:
        raise ValueError("The training split must contain both GOOD and BAD images.")


def save_manifest(records: Sequence[ImageRecord], path: str | Path) -> Path:
    rows = []
    for record in records:
        row = asdict(record)
        row["label_name"] = record.label_name
        rows.append(row)
    frame = pd.DataFrame(rows)[
        ["path", "label", "label_name", "group", "source", "split", "sample_weight"]
    ]
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output, index=False, encoding="utf-8")
    return output


def load_manifest(path: str | Path, *, verify_files: bool = True) -> list[ImageRecord]:
    manifest = Path(path).expanduser().resolve()
    if not manifest.is_file():
        raise FileNotFoundError(f"Manifest not found: {manifest}")
    frame = pd.read_csv(manifest)
    required = {"path", "label", "group", "source", "split"}
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"Manifest is missing columns: {sorted(missing)}")

    records: list[ImageRecord] = []
    missing_files: list[str] = []
    for row in frame.to_dict(orient="records"):
        image_path = Path(str(row["path"]))
        if not image_path.is_absolute():
            image_path = (manifest.parent / image_path).resolve()
        if verify_files and not image_path.is_file():
            missing_files.append(str(image_path))
        records.append(
            ImageRecord(
                path=str(image_path),
                label=int(row["label"]),
                group=str(row["group"]),
                source=str(row.get("source", "dataset")),
                split=str(row.get("split", "")),
                sample_weight=float(row.get("sample_weight", 1.0)),
            )
        )
    if missing_files:
        preview = "\n".join(missing_files[:10])
        raise FileNotFoundError(
            f"{len(missing_files)} manifest images do not exist. First entries:\n{preview}"
        )
    validate_records(records, require_both_classes=False)
    if all(record.split for record in records):
        validate_split(records)
    return records


def merge_old_and_new_records(
    old_records: Sequence[ImageRecord],
    new_records: Sequence[ImageRecord],
    *,
    validation_fraction: float,
    test_fraction: float,
    seed: int,
    new_sample_weight: float = 1.0,
) -> list[ImageRecord]:
    """Merge fine-tuning data without leaking a known group into another split."""
    old = [ImageRecord(**asdict(record)) for record in old_records]
    new = [ImageRecord(**asdict(record)) for record in new_records]
    validate_split(old)

    old_group_split: dict[str, str] = {}
    for record in old:
        old_group_split.setdefault(record.group, record.split)
        if old_group_split[record.group] != record.split:
            raise ValueError(f"Old manifest contains group leakage: {record.group}")

    known_group_new: list[ImageRecord] = []
    unseen_group_new: list[ImageRecord] = []
    for record in new:
        record.sample_weight = float(new_sample_weight)
        if record.group in old_group_split:
            record.split = old_group_split[record.group]
            known_group_new.append(record)
        else:
            unseen_group_new.append(record)

    if unseen_group_new:
        unseen_group_new = stratified_group_split(
            unseen_group_new,
            validation_fraction=validation_fraction,
            test_fraction=test_fraction,
            seed=seed,
            require_both_classes=False,
        )

    combined = old + known_group_new + unseen_group_new

    # A path may have been copied into the new root even though it already exists
    # in the old manifest. Exact duplicate paths are never useful.
    deduplicated: list[ImageRecord] = []
    seen_paths: set[str] = set()
    for record in combined:
        canonical_path = str(Path(record.path).resolve()).lower()
        if canonical_path in seen_paths:
            continue
        seen_paths.add(canonical_path)
        deduplicated.append(record)

    validate_records(deduplicated, require_both_classes=True)
    validate_split(deduplicated)
    return deduplicated


class RandomQuarterTurn:
    def __init__(self, probability: float = 1.0) -> None:
        self.probability = float(probability)

    def __call__(self, image: Image.Image) -> Image.Image:
        if random.random() > self.probability:
            return image
        angle = random.choice((0, 90, 180, 270))
        if angle == 0:
            return image
        return image.rotate(angle, resample=Image.Resampling.NEAREST, expand=False)


class PadToSquare:
    def __init__(self, fill: int = 0) -> None:
        self.fill = fill

    def __call__(self, image: Image.Image) -> Image.Image:
        width, height = image.size
        side = max(width, height)
        left = (side - width) // 2
        top = (side - height) // 2
        right = side - width - left
        bottom = side - height - top
        return ImageOps.expand(image, border=(left, top, right, bottom), fill=self.fill)


def build_transforms(data_config: dict[str, Any], *, training: bool) -> transforms.Compose:
    input_size = int(data_config.get("input_size", 512))
    spatial_mode = str(data_config.get("spatial_mode", "resize")).lower()
    augmentation = data_config.get("augmentations", {}) or {}

    operations: list[Any] = []
    if training:
        if bool(augmentation.get("quarter_turns", True)):
            operations.append(RandomQuarterTurn(float(augmentation.get("quarter_turn_probability", 1.0))))
        if bool(augmentation.get("horizontal_flip", False)):
            operations.append(transforms.RandomHorizontalFlip(float(augmentation.get("horizontal_flip_probability", 0.5))))
        if bool(augmentation.get("vertical_flip", False)):
            operations.append(transforms.RandomVerticalFlip(float(augmentation.get("vertical_flip_probability", 0.5))))
        rotation = float(augmentation.get("small_rotation_degrees", 0.0))
        translate = float(augmentation.get("translation_fraction", 0.0))
        scale_jitter = augmentation.get("scale_range", [1.0, 1.0])
        if rotation > 0 or translate > 0 or list(scale_jitter) != [1.0, 1.0]:
            operations.append(
                transforms.RandomAffine(
                    degrees=rotation,
                    translate=(translate, translate) if translate > 0 else None,
                    scale=tuple(float(x) for x in scale_jitter),
                    interpolation=InterpolationMode.BILINEAR,
                    fill=0,
                )
            )
        brightness = float(augmentation.get("brightness", 0.0))
        contrast = float(augmentation.get("contrast", 0.0))
        if brightness > 0 or contrast > 0:
            operations.append(transforms.ColorJitter(brightness=brightness, contrast=contrast))

    if spatial_mode == "resize":
        operations.append(
            transforms.Resize(
                (input_size, input_size),
                interpolation=InterpolationMode.BILINEAR,
                antialias=True,
            )
        )
    elif spatial_mode == "pad_resize":
        operations.extend(
            [
                PadToSquare(fill=int(data_config.get("pad_value", 0))),
                transforms.Resize(
                    (input_size, input_size),
                    interpolation=InterpolationMode.BILINEAR,
                    antialias=True,
                ),
            ]
        )
    elif spatial_mode == "center_crop":
        operations.append(transforms.CenterCrop(input_size))
    else:
        raise ValueError(f"Unsupported data.spatial_mode: {spatial_mode}")

    operations.append(transforms.ToTensor())
    normalization = data_config.get("normalization", {}) or {}
    if bool(normalization.get("enabled", True)):
        mean = normalization.get("mean", [0.485, 0.456, 0.406])
        std = normalization.get("std", [0.229, 0.224, 0.225])
        operations.append(transforms.Normalize(mean=mean, std=std))
    return transforms.Compose(operations)


def _scale_to_uint8(array: np.ndarray, config: dict[str, Any]) -> np.ndarray:
    if array.dtype == np.uint8:
        return array

    mode = str(config.get("uint16_scaling", "fixed")).lower()
    array_float = array.astype(np.float32)

    if np.issubdtype(array.dtype, np.integer):
        dtype_info = np.iinfo(array.dtype)
        default_min = float(dtype_info.min)
        default_max = float(dtype_info.max)
    else:
        default_min = float(np.nanmin(array_float))
        default_max = float(np.nanmax(array_float))

    if mode == "fixed":
        low = float(config.get("fixed_min", default_min))
        high = float(config.get("fixed_max", default_max))
    elif mode == "percentile":
        low_p = float(config.get("lower_percentile", 0.5))
        high_p = float(config.get("upper_percentile", 99.5))
        low, high = np.nanpercentile(array_float, [low_p, high_p])
    elif mode == "minmax":
        low = float(np.nanmin(array_float))
        high = float(np.nanmax(array_float))
    else:
        raise ValueError(f"Unsupported uint16_scaling mode: {mode}")

    if not np.isfinite(low) or not np.isfinite(high) or high <= low:
        return np.zeros_like(array_float, dtype=np.uint8)
    scaled = (array_float - low) / (high - low)
    scaled = np.clip(scaled, 0.0, 1.0)
    return np.round(scaled * 255.0).astype(np.uint8)


def read_image_rgb(path: str | Path, image_loading_config: dict[str, Any] | None = None) -> Image.Image:
    image_loading_config = image_loading_config or {}
    image_path = Path(path)
    array = cv2.imread(str(image_path), cv2.IMREAD_UNCHANGED)
    if array is None:
        raise ValueError(f"OpenCV could not read image: {image_path}")

    array = _scale_to_uint8(array, image_loading_config)
    if array.ndim == 2:
        rgb = cv2.cvtColor(array, cv2.COLOR_GRAY2RGB)
    elif array.ndim == 3 and array.shape[2] == 1:
        rgb = cv2.cvtColor(array[:, :, 0], cv2.COLOR_GRAY2RGB)
    elif array.ndim == 3 and array.shape[2] == 3:
        rgb = cv2.cvtColor(array, cv2.COLOR_BGR2RGB)
    elif array.ndim == 3 and array.shape[2] == 4:
        rgb = cv2.cvtColor(array, cv2.COLOR_BGRA2RGB)
    else:
        raise ValueError(f"Unsupported image shape {array.shape} for {image_path}")
    return Image.fromarray(rgb)


class LabeledImageDataset(Dataset[dict[str, Any]]):
    def __init__(
        self,
        records: Sequence[ImageRecord],
        *,
        transform: Any,
        image_loading_config: dict[str, Any] | None = None,
    ) -> None:
        self.records = list(records)
        self.transform = transform
        self.image_loading_config = image_loading_config or {}

    def __len__(self) -> int:
        return len(self.records)

    def __getitem__(self, index: int) -> dict[str, Any]:
        record = self.records[index]
        image = read_image_rgb(record.path, self.image_loading_config)
        image_tensor = self.transform(image)
        raw_unit_id, _ = extract_unit_id(record.path)
        return {
            "image": image_tensor,
            "label": int(record.label),
            "path": record.path,
            "group": record.group,
            "unit_id_raw": raw_unit_id,
            "unit_id": record.group,
            "source": record.source,
            "split": record.split,
        }


@dataclass
class UnlabeledRecord:
    path: str
    relative_path: str
    unit_id_raw: str
    unit_id: str


class UnlabeledImageDataset(Dataset[dict[str, Any]]):
    def __init__(
        self,
        records: Sequence[UnlabeledRecord],
        *,
        transform: Any,
        image_loading_config: dict[str, Any] | None = None,
    ) -> None:
        self.records = list(records)
        self.transform = transform
        self.image_loading_config = image_loading_config or {}

    def __len__(self) -> int:
        return len(self.records)

    def __getitem__(self, index: int) -> dict[str, Any]:
        record = self.records[index]
        image = read_image_rgb(record.path, self.image_loading_config)
        return {
            "image": self.transform(image),
            "path": record.path,
            "relative_path": record.relative_path,
            "unit_id_raw": record.unit_id_raw,
            "unit_id": record.unit_id,
        }


def scan_unlabeled_folder(
    root: str | Path,
    *,
    recursive: bool,
    extensions: Sequence[str] | None,
    unit_id_regex: str = DEFAULT_UNIT_ID_REGEX,
) -> list[UnlabeledRecord]:
    root_path = Path(root).expanduser().resolve()
    records: list[UnlabeledRecord] = []
    for image_path in list_images(root_path, recursive=recursive, extensions=extensions):
        raw, canonical = extract_unit_id(image_path.name, unit_id_regex)
        records.append(
            UnlabeledRecord(
                path=str(image_path),
                relative_path=str(image_path.relative_to(root_path)),
                unit_id_raw=raw,
                unit_id=canonical,
            )
        )
    if not records:
        raise ValueError(f"No supported images found in: {root_path}")
    return records


def _worker_seed(worker_id: int) -> None:
    worker_seed = torch.initial_seed() % (2**32)
    np.random.seed(worker_seed)
    random.seed(worker_seed)


def build_labeled_loader(
    records: Sequence[ImageRecord],
    *,
    transform: Any,
    image_loading_config: dict[str, Any],
    batch_size: int,
    shuffle: bool,
    num_workers: int,
    pin_memory: bool,
    persistent_workers: bool,
    sampler_config: dict[str, Any] | None = None,
    seed: int = 42,
) -> DataLoader:
    dataset = LabeledImageDataset(
        records,
        transform=transform,
        image_loading_config=image_loading_config,
    )

    sampler = None
    sampler_config = sampler_config or {}
    if bool(sampler_config.get("enabled", False)):
        balance_classes = bool(sampler_config.get("balance_classes", False))
        labels = np.array([record.label for record in records], dtype=np.int64)
        counts = np.bincount(labels, minlength=2).astype(np.float64)
        class_weights = np.ones(2, dtype=np.float64)
        if balance_classes:
            class_weights = len(labels) / np.maximum(2.0 * counts, 1.0)
        weights = [
            float(class_weights[record.label]) * float(record.sample_weight)
            for record in records
        ]
        generator = torch.Generator()
        generator.manual_seed(seed)
        sampler = WeightedRandomSampler(
            weights=torch.as_tensor(weights, dtype=torch.double),
            num_samples=int(sampler_config.get("num_samples", len(records))),
            replacement=bool(sampler_config.get("replacement", True)),
            generator=generator,
        )
        shuffle = False

    generator = torch.Generator()
    generator.manual_seed(seed)
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        sampler=sampler,
        num_workers=num_workers,
        pin_memory=pin_memory,
        persistent_workers=bool(persistent_workers and num_workers > 0),
        worker_init_fn=_worker_seed,
        generator=generator,
        drop_last=False,
    )


def build_unlabeled_loader(
    records: Sequence[UnlabeledRecord],
    *,
    transform: Any,
    image_loading_config: dict[str, Any],
    batch_size: int,
    num_workers: int,
    pin_memory: bool,
    persistent_workers: bool,
) -> DataLoader:
    dataset = UnlabeledImageDataset(
        records,
        transform=transform,
        image_loading_config=image_loading_config,
    )
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=pin_memory,
        persistent_workers=bool(persistent_workers and num_workers > 0),
        drop_last=False,
    )


def sha256_file(path: str | Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()
