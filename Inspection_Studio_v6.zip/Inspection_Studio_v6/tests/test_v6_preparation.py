"""Exercise dataset export with native intensity and spatial fidelity."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

import cv2
import numpy as np

spec = importlib.util.spec_from_file_location("preparation_v6", Path(__file__).parents[1] / "tools" / "good_bad_folders.py")
prep = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prep)


class PreparationTests(unittest.TestCase):
    def test_native16_no_brightness_round_trip_is_exact(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "C0000083_Rc09Cc17.png"
            pixels = np.arange(53 * 71, dtype=np.uint16).reshape(53, 71) * 13
            prep.write_png(source, pixels)
            result, info, _ = prep.prepare_one(source, "vig", brightness=False)
            np.testing.assert_array_equal(result, pixels)
            self.assertEqual(info["output_dtype"], "uint16")
            self.assertEqual((info["output_width"], info["output_height"]), (71, 53))

    def test_brightness_preserves_size_depth_and_order(self):
        pixels = np.arange(40 * 64, dtype=np.uint16).reshape(40, 64)
        result, info = prep.intensity_to_pipeline(pixels, "vig")
        self.assertEqual(result.shape, pixels.shape)
        self.assertEqual(result.dtype, pixels.dtype)
        self.assertGreater(int(result.max()), int(pixels.max()))
        self.assertTrue(np.all(np.diff(result.ravel().astype(np.int64)) >= 0))
        self.assertGreaterEqual(info["gain"], 1)

    def test_eight_bit_quantization_requires_explicit_option(self):
        pixels = np.array([[0, 1, 65534, 65535]], dtype=np.uint16)
        native, _ = prep.intensity_to_pipeline(pixels, "top", brightness=False)
        quantized, _ = prep.intensity_to_pipeline(pixels, "top", brightness=False, output_depth="8")
        np.testing.assert_array_equal(native, pixels)
        np.testing.assert_array_equal(quantized, [[0, 0, 255, 255]])
        self.assertEqual(quantized.dtype, np.uint8)
        with self.assertRaisesRegex(ValueError, "refusing clipping"):
            prep.intensity_to_pipeline(pixels, "vig", white_level=4095)

    def test_labelled_export_folders_and_provenance(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "C0000083_Rc09Cc17.png"
            pixels = np.full((43, 59), 12345, dtype=np.uint16)
            prep.write_png(source, pixels)
            output = root / "dataset"
            counts, failures = prep.export_plan([("vig", "bad", source, {"csv": "labels.csv"})], output, brightness=False)
            self.assertEqual(failures, 0)
            self.assertEqual(counts[("vig", "bad")], 1)
            for task in ("vig", "top", "bottom"):
                for label in ("good", "bad"):
                    self.assertTrue((output / task / label).is_dir())
            np.testing.assert_array_equal(cv2.imread(str(output / "vig" / "bad" / source.name), cv2.IMREAD_UNCHANGED), pixels)
            record = json.loads((output / "processing.jsonl").read_text())
            self.assertEqual(record["label"], "bad")
            self.assertEqual(record["source_dtype"], "uint16")
            np.testing.assert_array_equal(prep.decode_image(source), pixels)
            with self.assertRaisesRegex(ValueError, "NEW or EMPTY"):
                prep.export_plan([("vig", "bad", source, {})], output)


if __name__ == "__main__":
    unittest.main()
