"""Integrated local top-view annotation and segmentation training."""
__version__ = "1.0.0"
