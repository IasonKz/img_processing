"""One native-depth crop primitive for dataset export and production inference."""
from __future__ import annotations

from copy import deepcopy
import math
import numpy as np
from ..image_io import load_rgb
from .geometry import roi_bounds, transform_points, validate_points, CROP_VERSION


def _cv():
    try:
        import cv2
        return cv2
    except ImportError as exc:
        raise RuntimeError("ROI crops require opencv-python-headless.") from exc


def mask_for_roi(roi, image_size):
    """Independent binary mask; nested regions are never overwritten by peers."""
    cv2 = _cv()
    width,height = map(int,image_size)
    if width<1 or height<1:
        raise ValueError("Mask dimensions must be positive.")
    mask=np.zeros((height,width),np.uint8)
    points=np.asarray(validate_points(roi["points"],roi["shape"]),float)
    if roi["shape"]=="polygon":
        cv2.fillPoly(mask,[np.rint(points).astype(np.int32)],255)
    elif roi["shape"]=="circle":
        cv2.circle(mask,tuple(np.rint(points[0]).astype(int)),max(1,round(np.linalg.norm(points[1]-points[0]))),255,-1)
    else:
        cv2.circle(mask,tuple(np.rint(points[0]).astype(int)),1,255,-1)
    return mask


def crop_roi(image_path,roi,settings=None,transform=None):
    """Return RGB pixels, independent uint8 mask, and crop/source mapping.

    margin is a fraction of the ROI's larger bounding dimension added on EACH
    side. Defaults retain contextual pixels; masked=True explicitly blacks out
    everything outside the feature. canonical=True removes global rotation at
    native pixel scale; it does not shrink a feature to match expected size.
    With canonical=True, normalize_corners=True additionally rotates corner_BL
    by 180 degrees so both L corners share an orientation without mirroring.
    No CLAHE, contrast adjustment or intensity normalization is performed.
    """
    cv2=_cv()
    settings=dict(settings or {})
    image=load_rgb(image_path)
    pixels=np.asarray(image)
    height,width=pixels.shape[:2]
    roi=deepcopy(roi)
    validate_points(roi["points"],roi["shape"])
    canonical=bool(settings.get("canonical",settings.get("canonical_rotation",False)))
    image_to_work=np.eye(3)
    applied_rotation=0.
    if canonical:
        if transform is None:
            raise ValueError("Canonical crop requires the localization transform.")
        matrix=np.asarray(transform,float)
        if matrix.shape==(2,3):
            matrix=np.vstack([matrix,[0,0,1]])
        # Geometry validator also verifies that the matrix is finite/invertible.
        transform_points([[0,0]],matrix)
        theta=math.atan2(matrix[1,0],matrix[0,0])
        # Optional corners normalization is explicit in the stored recipe.
        theta+=math.radians(float(settings.get("rotation_degrees",0)))
        if settings.get("normalize_corners",False) and str(roi.get("id", "")).lower()=="corner_bl":
            theta+=math.pi
        applied_rotation=math.degrees(theta)
        co,si=math.cos(theta),math.sin(theta)
        rotation=np.array([[co,si],[-si,co]])
        rotation[np.abs(rotation)<1e-12]=0.  # Exact quarter turns must not grow a crop by one pixel.
        centre=np.asarray(roi["points"],float)[0] if roi["shape"] in ("point","circle") else np.mean(roi["points"],axis=0)
        image_to_work[:2,:2]=rotation
        image_to_work[:2,2]=centre-rotation@centre
        roi["points"]=transform_points(roi["points"],image_to_work)
    bounds=roi_bounds(roi)
    extent=max(bounds[2]-bounds[0],bounds[3]-bounds[1],1.)
    margin=settings.get("margin",roi.get("margin",.15))
    if isinstance(margin,bool) or not isinstance(margin,(int,float)) or not math.isfinite(margin) or not 0<=margin<=5:
        raise ValueError("Crop margin must be between 0 and 5.")
    pad=float(settings.get("margin_pixels",0))+float(margin)*extent
    if not math.isfinite(pad) or pad<0:
        raise ValueError("Crop margin_pixels must be finite and nonnegative.")
    if roi["shape"]=="point":
        pad=max(pad,float(settings.get("point_radius",4)))
    x0,y0=int(math.floor(bounds[0]-pad)),int(math.floor(bounds[1]-pad))
    x1,y1=int(math.ceil(bounds[2]+pad))+1,int(math.ceil(bounds[3]+pad))+1
    if settings.get("square",False):
        side=max(x1-x0,y1-y0); cx=(x0+x1)/2; cy=(y0+y1)/2
        x0=math.floor(cx-side/2); y0=math.floor(cy-side/2); x1=x0+side; y1=y0+side
    crop_width,crop_height=x1-x0,y1-y0
    if crop_width<1 or crop_height<1 or crop_width*crop_height>64_000_000:
        raise ValueError("Invalid or excessive crop dimensions.")
    work_to_crop=np.array([[1.,0.,-x0],[0.,1.,-y0],[0.,0.,1.]])
    image_to_crop=work_to_crop@image_to_work
    if not canonical:
        # Integer translation with constant padding preserves source samples exactly.
        crop=np.zeros((crop_height,crop_width,pixels.shape[2]),dtype=pixels.dtype)
        sx0,sy0=max(0,x0),max(0,y0); sx1,sy1=min(width,x1),min(height,y1)
        valid=np.zeros((crop_height,crop_width),np.uint8)
        if sx1>sx0 and sy1>sy0:
            crop[sy0-y0:sy1-y0,sx0-x0:sx1-x0]=pixels[sy0:sy1,sx0:sx1]
            valid[sy0-y0:sy1-y0,sx0-x0:sx1-x0]=255
    else:
        crop=cv2.warpAffine(pixels,image_to_crop[:2],(crop_width,crop_height),flags=cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT,borderValue=0)
        valid=cv2.warpAffine(np.full((height,width),255,np.uint8),image_to_crop[:2],(crop_width,crop_height),flags=cv2.INTER_NEAREST,borderMode=cv2.BORDER_CONSTANT,borderValue=0)
    mask_roi={**roi,"points":transform_points(roi["points"],work_to_crop)}
    mask=mask_for_roi(mask_roi,[crop_width,crop_height])
    mask[valid==0]=0
    if settings.get("masked",False):
        crop[mask==0]=0
    valid_fraction=float(np.count_nonzero(valid)/valid.size)
    metadata={"version":CROP_VERSION,"roi_id":roi["id"],"kind":roi.get("kind"),
              "source_size":[width,height],"crop_size":[crop_width,crop_height],"dtype":str(crop.dtype),
              "bbox_work":[x0,y0,x1,y1],"image_to_crop":image_to_crop.tolist(),
              "crop_to_image":np.linalg.inv(image_to_crop).tolist(),"valid_fraction":round(valid_fraction,6),
              "clipped":valid_fraction<1.,"canonical":canonical,"masked":bool(settings.get("masked",False)),
              "margin":float(margin),"settings":settings,"applied_rotation_degrees":applied_rotation,
              "normalize_corners":bool(canonical and settings.get("normalize_corners",False)),
              "needs_review":valid_fraction<1.}
    return crop,mask,metadata
