# Migration to Inspection Studio 5

## Preserve the old installation

1. Pause the current search in the old dashboard and wait for its worker to stop.
2. Keep the old project, complete experiment folders, model/decision artifacts, source dataset, and virtual environment unchanged.
3. Extract v5 into a new short folder. Do not copy only a replacement `common.py` or merge arbitrary patch files.
4. Use a new results root for v5. Never run both versions as writers against one experiment directory.

Closing a browser or the dashboard console is not proof that a background worker has stopped. Check the operation status first. Do not delete locks while another worker is alive.

## Move settings, not execution history

Use the supplied v5 `project.yaml` as the starting point. Copy only these intentional settings from your previous configuration:

- The VIG input dataset path, containing original `good` and `bad` images.
- The local public-weight folder, if you want to reuse verified downloaded weights.
- New output, incoming, and classification directories.
- A verified physical-unit mapping when filenames alone do not identify a unit.
- Deliberate policy targets and resource limits.

Do not replace the v5 configuration with an old `resolved_config.yaml`; it contains run-specific resolved values and paths. Do not change old `config.json`, manifests, saved thresholds, SQLite trial states, or integrity records to make them look current.

Relative paths resolve beside the configuration file. On Linux replace Windows drive paths with real Linux paths. Retain the original crop and all pixels; no migration step modifies source images.

## Python environments

The default Windows setup uses `%USERPROFILE%\venvs\studio5-cpu` or `studio5-cuda`. It leaves v3/v4 environments intact. Use `Setup.cmd -Device cpu` or `Setup.cmd -Device cuda`, then `Start.cmd`.

On Linux create `.venv-studio5` using the [Linux guide](docs/INSTALLATION_LINUX.md), then `bash Start.sh`.

The pinned torch/torchvision pair remains 2.7.1/0.22.1, targeting Python 3.12. An existing matching environment on the same computer can be reused after the installation-guide checks; this is optional, not a requirement. Do not copy a virtual environment between operating systems or computers.

## Existing weights and model checkpoints

Reusing an existing public pretrained-weight folder avoids downloading the same weights again. Newly selected model families need their own provisioned weight files. The training worker does not silently download missing files or substitute random initialization.

Old full-image trained checkpoints retain their inference meaning when all required artifacts remain intact. Inspect their recorded preprocessing, class map, and saved decision. Do not assume an old threshold applies to a newly trained model, global-plus-patches mode, new image geometry, or a composed workflow.

## Do not resume old training with new optimizer semantics

Version 5 corrects weighted-loss normalization for single-image microbatches and gradient accumulation. It uses a fixed training-dataset normalization rather than canceling the class weight within a one-sample batch. This can change new training behavior without changing how an old checkpoint performs inference.

Old resumable optimizer/training states are intentionally not assumed compatible with this change. Keep v4 to reproduce/resume a v4 training run. In v5, start a new experiment from pretrained weights or use the controlled fine-tuning/update route with lineage and holdout checks. Do not bypass a training-fingerprint mismatch.

## First v5 experiment

1. Check installation and weights on the target device.
2. Audit the dataset and inspect the actual split counts and group identities.
3. Start with full-image mode and one or two established architectures.
4. Confirm a complete trial and compare its selection results with your baseline on compatible records.
5. Add one experiment at a time: Custom search, another backbone, global plus patches, triage, or an ensemble.

Adding more features is not evidence of improvement. Compare bad escapes, false rejects, review workload, coverage, and runtime on the same independent images.

## Review data and model updates

Review exports use explicit human labels, not predictions as pseudo-labels. Supply the previous source run and include replay when preparing a training-ready revision. Old held-out groups/content remain protected; old training examples are replayed with newly reviewed training examples. Label conflicts in old training data require a deliberate fresh lineage/evaluation design rather than an unnoticed rewrite.

Retain previous versions so the new model can be compared with the old one. A reviewed-only accuracy score on selected difficult cases is not a production-quality estimate.
