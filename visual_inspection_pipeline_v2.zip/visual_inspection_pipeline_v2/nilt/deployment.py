"""Export selected candidates to integrity-checked, runtime-only ONNX packages."""
from __future__ import annotations

from datetime import datetime, timezone
import importlib.metadata
import platform
import sys
from pathlib import Path
import shutil
import time

import numpy as np

from .common import read_json, sha_file, write_csv, write_json
from .runtime import PackageRunner, predict_package, safe_asset


def parity_result(source_scores, exported_scores, threshold, atol=1e-5, rtol=1e-4):
    source = np.asarray(source_scores, dtype=float)
    exported = np.asarray(exported_scores, dtype=float)
    if source.ndim != 1 or source.shape != exported.shape or not len(source):
        raise ValueError("Parity requires equal nonempty one-dimensional score arrays.")
    finite = bool(np.isfinite(source).all() and np.isfinite(exported).all())
    if not finite:
        return {"status": "failed", "images": len(source), "reason": "Nonfinite source/export scores."}
    absolute = np.abs(source - exported)
    decisions_changed = (source >= threshold) != (exported >= threshold)
    close = np.isclose(source, exported, atol=atol, rtol=rtol)
    return {"status": "passed" if close.all() and not decisions_changed.any() else "failed",
            "images": len(source), "atol": float(atol), "rtol": float(rtol),
            "max_absolute_score_difference": float(absolute.max()),
            "mean_absolute_score_difference": float(absolute.mean()),
            "score_tolerance_failures": int((~close).sum()),
            "decision_mismatches": int(decisions_changed.sum()), "threshold": float(threshold)}


def _validate_selection(rows):
    if not rows or any(r.get("split") != "selection" for r in rows):
        raise ValueError("ONNX parity validation requires reserved selection records only; final test is not used for export.")
    if len({r.get("pixel_hash", str(r["path"])) for r in rows}) != len(rows):
        raise ValueError("Duplicate images in export parity validation rows.")


def _versions():
    result = {"python": platform.python_version(), "platform": platform.platform()}
    for name in ("torch", "torchvision", "onnx", "onnxruntime", "numpy", "Pillow"):
        try:
            result[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            result[name] = "not_installed"
    return result


def export_package(run, output, kind="inference", format="onnx", validation_rows=None):
    """Export a run's selected candidate and validate numeric/decision parity.

    Artifacts are usable only after successful validation. CPU export validation is
    distinct from model quality qualification; exporting never activates a model.
    """
    if kind != "inference" or format != "onnx":
        raise ValueError("This exporter supports inference/onnx only. Use the training package command for checkpoints.")
    from .engine import load_checkpoint, predict_checkpoint, torch_modules
    from .workflow import open_run, verify_sources, load_selected

    run, output = Path(run).resolve(), Path(output).resolve()
    if output.is_relative_to(run) or run.is_relative_to(output):
        raise ValueError("Export output must be outside the immutable run and must not contain the run.")
    if output.exists() and (not output.is_dir() or any(output.iterdir())):
        raise FileExistsError("Export output must be absent or empty.")
    cfg, manifest_rows = open_run(run)
    selected = load_selected(run)
    rows = list(validation_rows) if validation_rows is not None else [r for r in manifest_rows if r["split"] == "selection"]
    _validate_selection(rows)
    manifest_ids = {(r.get("pixel_hash"), r.get("relative_path")) for r in manifest_rows if r["split"] == "selection"}
    if any((r.get("pixel_hash"), r.get("relative_path")) not in manifest_ids for r in rows):
        raise ValueError("Export validation rows must belong to the run's reserved selection manifest.")
    verify_sources(rows)
    threshold = float(selected["threshold"])
    if not np.isfinite(threshold):
        raise ValueError("Selected threshold must be finite for deployment.")
    torch, _ = torch_modules()
    try:
        import onnx
        import onnxruntime
    except ImportError as error:
        raise RuntimeError("Install requirements-export.txt before ONNX export; export never downloads dependencies.") from error
    output.mkdir(parents=True, exist_ok=True)
    write_json(output / "export_validation.json", {"status": "in_progress", "validated_providers": []})
    start = time.perf_counter()
    deployment_cfg = cfg.get("deployment", {})
    members = []
    source_member_scores = []
    try:
        for index, member in enumerate(selected["members"]):
            checkpoint = safe_asset(run, member["checkpoint"])
            if sha_file(checkpoint) != member["sha256"]:
                raise ValueError("Selected checkpoint checksum mismatch.")
            state = torch.load(checkpoint, map_location="cpu", weights_only=True)
            member_dir = output / "members" / f"{index:03d}"
            member_dir.mkdir(parents=True)
            onnx_path = member_dir / "model.onnx"
            kind_name = state.get("kind", member.get("kind", "supervised"))
            source_scores, elapsed = predict_checkpoint(checkpoint, rows, cfg, device="cpu")
            source_member_scores.append(np.asarray(source_scores, dtype=float))
            item = {"architecture": member["architecture"], "kind": kind_name,
                    "source_checkpoint_sha256": member["sha256"],
                    "onnx": onnx_path.relative_to(output).as_posix(), "input_name": "images",
                    "source_validation_seconds": float(elapsed)}
            if kind_name == "patchcore":
                if len(selected["members"]) != 1:
                    raise ValueError("PatchCore scores cannot be averaged with supervised probabilities.")
                from .patchcore import load_patchcore
                loaded, state = load_patchcore(checkpoint, cfg, torch.device("cpu"))
                export_model = loaded.extractor.eval()
                bank_path = member_dir / "memory_bank.npy"
                bank = state["memory_bank"].detach().cpu().numpy().astype(np.float32)
                if bank.ndim != 2 or not len(bank) or not np.isfinite(bank).all():
                    raise ValueError("Invalid PatchCore memory bank.")
                np.save(bank_path, bank, allow_pickle=False)
                item.update(memory_bank=bank_path.relative_to(output).as_posix(), output_name="embedding",
                            scoring="max_patch_euclidean_1nn_unweighted", memory_bank_shape=list(bank.shape),
                            query_chunk=int(state.get("patchcore_settings", cfg.get("patchcore", {})).get("query_chunk_size", 256)),
                            bank_chunk=int(state.get("patchcore_settings", cfg.get("patchcore", {})).get("memory_chunk_size", 2048)))
            elif kind_name == "supervised":
                model, state = load_checkpoint(checkpoint, cfg, torch.device("cpu"))

                class BadScore(torch.nn.Module):
                    def __init__(self, model):
                        super().__init__()
                        self.model = model

                    def forward(self, images):
                        return torch.softmax(self.model(images).float(), dim=1)[:, 0]

                export_model = BadScore(model).eval()
                item["output_name"] = "bad_score"
            else:
                raise ValueError(f"Unsupported deployment member: {kind_name}")
            sample = torch.zeros(1, 3, int(cfg["image_size"]), int(cfg["image_size"]), dtype=torch.float32)
            # Explicit legacy exporter avoids default changes between Torch releases.
            # Fixed input geometry is intentional and stored in preprocessing.json.
            with torch.inference_mode():
                torch.onnx.export(export_model, sample, str(onnx_path), export_params=True,
                                  opset_version=int(deployment_cfg.get("opset", 17)), do_constant_folding=True,
                                  input_names=["images"], output_names=[item["output_name"]],
                                  dynamic_axes=None, dynamo=False, external_data=False)
            onnx.checker.check_model(str(onnx_path))
            # Runtime loading must not resolve external tensor paths outside the package.
            proto = onnx.load(str(onnx_path), load_external_data=False)
            if any(t.data_location == onnx.TensorProto.EXTERNAL for t in proto.graph.initializer):
                raise ValueError("Unexpected external ONNX weights; this exporter requires self-contained member graphs.")
            members.append(item)
            del export_model, sample
        score_type = selected.get("score_type") or ("anomaly_distance" if members[0]["kind"] == "patchcore" else "bad_probability_score")
        preprocessing = {"format_version": 1, "image_size": int(cfg["image_size"]), "resize": cfg["resize"],
                         "input_shape": [1, 3, int(cfg["image_size"]), int(cfg["image_size"])],
                         "input_dtype": "float32", "channel_order": "RGB", "tensor_layout": "NCHW",
                         "exif_transpose": True, "scale_divisor": 255.0, "mean": list(state.get("mean", [0.485, 0.456, 0.406])),
                         "std": list(state.get("std", [0.229, 0.224, 0.225])), "padding_rgb": [124, 116, 104],
                         "resize_interpolation": "Pillow.BILINEAR", "unsupported_bit_depths": ["16bit", "float"],
                         "automatic_input_rescaling": False}
        write_json(output / "preprocessing.json", preprocessing)
        write_json(output / "decision_policy.json", {"format_version": 1, "class_to_index": {"bad": 0, "good": 1},
                   "threshold": threshold, "rule": "bad_if_score_greater_equal_threshold", "score_type": score_type,
                   "ensemble_rule": "arithmetic_mean_member_bad_scores" if len(members) > 1 else "single_member",
                   "quality_policy": selected.get("policy", cfg.get("policy", {}))})
        current_state = read_json(run / "model_state.json") if (run / "model_state.json").exists() else {}
        evaluation_path = current_state.get("last_evaluation")
        latest_evaluation = read_json(safe_asset(run, evaluation_path)) if evaluation_path else None
        metadata = {"format_version": 1, "created_utc": datetime.now(timezone.utc).isoformat(),
                    "task": cfg["task"], "model_version": run.name + "/" + selected["name"],
                    "candidate_name": selected["name"], "members": members, "runtime_cpu_threads": int(cfg.get("cpu_threads", 4)),
                    "qualification_status": current_state.get("status", selected.get("status", "not_recorded")),
                    "selection_status": selected.get("status", "not_recorded"),
                    "profile": cfg.get("profile", "unspecified"),
                    "source_config_sha256": sha_file(run / "config.json"), "source_manifest_sha256": sha_file(run / "manifest.csv")}
        write_json(output / "package.json", metadata)
        write_json(output / "model_metadata.json", {**metadata, "versions": _versions(),
                   "selection_metrics": selected.get("selection_metrics"),
                   "latest_evaluation": latest_evaluation,
                   "source_run_id": run.name,
                   "note": "Source/runtime parity is separate from defect detection qualification. No final test images are used for export validation."})
        # Temporary in-progress packages cannot be loaded by the normal verify=True runtime.
        runner = PackageRunner(output, device="cpu", verify=False)
        exported = np.asarray([runner.score(row["path"]) for row in rows], dtype=float)
        source = np.mean(source_member_scores, axis=0)
        atol = float(deployment_cfg.get("score_atol", 1e-5))
        rtol = float(deployment_cfg.get("score_rtol", 1e-4))
        if atol < 0 or rtol < 0:
            raise ValueError("Parity tolerances cannot be negative.")
        if int(deployment_cfg.get("max_decision_disagreements", 0)) != 0:
            raise ValueError("Deployment requires zero decision disagreements; relaxing this gate is unsupported.")
        result = parity_result(source, exported, threshold, atol, rtol)
        # Compare against original selection scores as well: relocating a GPU-trained
        # candidate must not conceal a change in threshold decisions on CPU.
        archived_scores = run / "scores" / selected["name"] / "selection.npy"
        if archived_scores.exists():
            archived_scores = safe_asset(run, archived_scores.relative_to(run).as_posix())
            original = np.load(archived_scores, allow_pickle=False)
            original_rows = [r for r in manifest_rows if r["split"] == "selection"]
            if original.shape != (len(original_rows),):
                raise ValueError("Archived selection score shape does not match manifest.")
            index_by_id = {(r.get("pixel_hash"), r.get("relative_path")): i for i, r in enumerate(original_rows)}
            original = np.asarray([original[index_by_id[(r.get("pixel_hash"), r.get("relative_path"))]] for r in rows])
            result["archived_selection_parity"] = parity_result(original, exported, threshold, atol, rtol)
            if result["archived_selection_parity"]["status"] != "passed":
                result["status"] = "failed"
        else:
            result["archived_selection_parity"] = {"status": "unavailable", "reason": "Original selection scores not found."}
        result.update(validated_providers=["CPUExecutionProvider"] if result["status"] == "passed" else [],
                      unvalidated_providers=["CUDAExecutionProvider"], validation_split="selection",
                      source_device="cpu", source_precision="float32",
                      validation_scope="all_selection_records" if len(rows) == len(manifest_ids) else "selection_subset",
                      source_dataset_manifest_sha256=sha_file(run / "manifest.csv"),
                      versions=_versions(), elapsed_seconds=time.perf_counter() - start)
        write_json(output / "export_validation.json", result)
        write_csv(output / "parity_predictions.csv", [{"relative_path": row["relative_path"], "pixel_hash": row["pixel_hash"],
                   "source_score": float(a), "onnx_score": float(b), "absolute_difference": float(abs(a - b)),
                   "source_class": "bad" if a >= threshold else "good", "onnx_class": "bad" if b >= threshold else "good"}
                   for row, a, b in zip(rows, source, exported)])
        if result["status"] != "passed":
            raise RuntimeError("ONNX parity failed; inspect export_validation.json and parity_predictions.csv. No deployable package was qualified.")
        shutil.copy2(Path(__file__).with_name("runtime.py"), output / "runtime.py")
        (output / "predict.py").write_text('from runtime import main\n\nif __name__ == "__main__":\n    raise SystemExit(main())\n', encoding="utf-8")
        versions = _versions()
        (output / "requirements-runtime.txt").write_text("\n".join(f"{p}=={versions[p]}" for p in ("numpy", "Pillow", "onnxruntime")) + "\n", encoding="utf-8")
        (output / "OPERATOR_GUIDE.md").write_text(
            "# Visual Inspection Deployment Package\n\n"
            f"Copy this entire folder. Use Python {sys.version_info.major}.{sys.version_info.minor} to match the validated export environment. "
            "Only NumPy, Pillow and ONNX Runtime are required. Install dependencies using `python -m pip install -r requirements-runtime.txt`. "
            "For offline installation, prepare compatible wheels on a connected machine and use `--no-index --find-links WHEEL_DIRECTORY`.\n\n"
            "Run from this folder: `python predict.py --input IMAGE_DIRECTORY --output NEW_OUTPUT_DIRECTORY --device cpu`. "
            "Add `--labeled` when the input has good and bad subfolders. Outputs include predictions.csv, inference_summary.json, "
            "and copied images in predicted/good, predicted/bad and predicted/review. Labeled inputs also generate error folders. "
            "Source images are never modified. Output must be empty and outside input and package folders.\n\n"
            "Input geometry and threshold are immutable package settings. A larger input is rejected for review under the pad policy; "
            "fit permits explicitly configured whole-image rescaling. Re-export a separately validated model for a different policy.\n\n"
            "CPU source/runtime parity is recorded in export_validation.json. It is not a production quality certification. "
            "CUDA requires onnxruntime-gpu instead of onnxruntime and compatible NVIDIA libraries; use `--device cuda` or `--device auto`. "
            "CUDA parity has not been validated by this package export and this is recorded in inference_summary.json. "
            "GPU execution may use CPU kernels for unsupported operators. Explicit GPU requests fail if CUDA initialization is unavailable.\n\n"
            "Preserve the accompanying training checkpoint separately for further training. This package is inference-only. "
            "Integrity hashes detect file changes, not authenticity; use only packages from a trusted source.\n", encoding="utf-8")
        files = {p.relative_to(output).as_posix(): sha_file(p) for p in sorted(output.rglob("*")) if p.is_file() and p.name != "integrity.json"}
        write_json(output / "integrity.json", {"algorithm": "sha256", "files": files})
        return output
    except Exception as error:
        validation_file = output / "export_validation.json"
        current = read_json(validation_file) if validation_file.exists() else {}
        current.update(status="failed", error_type=type(error).__name__, error=str(error), validated_providers=[])
        write_json(validation_file, current)
        raise
