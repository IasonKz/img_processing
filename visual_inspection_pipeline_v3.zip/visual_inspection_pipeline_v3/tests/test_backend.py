"""Backend correctness checks; Torch integration checks skip when unavailable."""
from __future__ import annotations

import copy
import importlib.util
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
from PIL import Image

from nilt.engine import backend_fingerprints, required_weight_names
from nilt.patchcore import FeatureReservoir, patchcore_settings
from nilt.preprocessing import prepare_image

TORCH_AVAILABLE = importlib.util.find_spec("torch") is not None and importlib.util.find_spec("torchvision") is not None


class PortableBackendTests(unittest.TestCase):
    def test_padding_preserves_pixels_and_rejects_implicit_scaling(self):
        image = Image.fromarray(np.arange(20 * 26 * 3, dtype=np.uint8).reshape(20, 26, 3))
        padded = np.asarray(prepare_image(image, {"image_size": 32, "resize": "pad"}))
        self.assertEqual(padded.shape, (32, 32, 3))
        np.testing.assert_array_equal(padded[6:26, 3:29], np.asarray(image))
        with self.assertRaisesRegex(ValueError, "no automatic scaling"):
            prepare_image(Image.new("RGB", (100, 32)), {"image_size": 64, "resize": "pad"})
        self.assertEqual(prepare_image(Image.new("RGB", (120, 60)), {"image_size": 64, "resize": "fit"}).size, (64, 64))
        with self.assertRaisesRegex(ValueError, "tiling"):
            prepare_image(image, {"image_size": 64, "resize": "tile"})

    def test_resolution_larger_than_six_hundred_is_supported(self):
        image = Image.new("RGB", (1000, 750), (25, 50, 75))
        result = prepare_image(image, {"image_size": 1024, "resize": "pad"})
        self.assertEqual(result.size, (1024, 1024))
        self.assertEqual(result.getpixel((12, 137)), (25, 50, 75))

    def test_fingerprints_allow_relocation_but_detect_data_and_settings_change(self):
        cfg = {"task": "top", "image_size": 64, "resize": "pad", "training": {"epochs": 3},
               "data_root": "/computer/a", "device": "cpu"}
        rows = [{"path": "/computer/a/good/x.png", "relative_path": "good/x.png", "pixel_hash": "abc",
                 "label": 1, "group": "unit1", "split": "train"}]
        first = backend_fingerprints("resnet18", 42, rows, cfg)
        relocated = copy.deepcopy(rows)
        relocated[0]["path"] = "/computer/b/good/x.png"
        changed_cfg = dict(cfg, data_root="/computer/b", device="cuda")
        self.assertEqual(first, backend_fingerprints("resnet18", 42, relocated, changed_cfg))
        relocated[0]["label"] = 0
        self.assertNotEqual(first["data_fingerprint"], backend_fingerprints("resnet18", 42, relocated, cfg)["data_fingerprint"])
        self.assertNotEqual(first["config_fingerprint"], backend_fingerprints("resnet18", 43, rows, cfg)["config_fingerprint"])

    def test_local_weights_mapping_deduplicates_patchcore_backbone(self):
        self.assertEqual(required_weight_names({"models": ["resnet18", "patchcore", "resnet50"]}),
                         ["resnet18", "resnet50"])
        with self.assertRaises(ValueError):
            required_weight_names({"models": ["patchcore"], "patchcore": {"backbone": "swin_t"}})

    def test_reservoir_is_bounded_deterministic_and_covers_stream(self):
        values = np.arange(3000, dtype=np.float32).reshape(1000, 3)
        first, second = FeatureReservoir(23, 42), FeatureReservoir(23, 42)
        first.update(values)
        for part in np.array_split(values, 10):
            second.update(part)
        self.assertEqual(first.seen, 1000)
        self.assertEqual(first.values.shape, (23, 3))
        # Reservoir ordering may differ with input chunking; membership must not.
        np.testing.assert_array_equal(np.sort(first.values[:, 0]), np.sort(second.values[:, 0]))
        self.assertTrue((first.values[:, 0] > 2000).any())
        self.assertTrue((first.values[:, 0] < 1000).any())
        with self.assertRaises(ValueError):
            first.update([[float("nan"), 2, 3]])

    def test_patchcore_configuration_rejects_unbounded_or_unsupported_settings(self):
        with self.assertRaises(ValueError):
            patchcore_settings({"patchcore": {"reservoir_size": 5, "coreset_size": 6}})
        with self.assertRaises(ValueError):
            patchcore_settings({"patchcore": {"num_neighbors": 9}})


@unittest.skipUnless(TORCH_AVAILABLE, "PyTorch and torchvision are not installed")
class TorchBackendTests(unittest.TestCase):
    @staticmethod
    def fixture(root):
        from nilt.common import sha_file
        rng = np.random.default_rng(31)
        rows = []
        for index in range(12):
            path = root / f"image_{index}.png"
            Image.fromarray(rng.integers(0, 255, (32, 32, 3), dtype=np.uint8)).save(path)
            rows.append({"path": str(path), "relative_path": path.name, "label": index % 2,
                         "pixel_hash": sha_file(path), "group": str(index), "split": "train" if index < 8 else "val"})
        cfg = {"task": "top", "image_size": 32, "resize": "pad", "pretrained": False,
               "device": "cpu", "cpu_threads": 1, "num_workers": 0, "augmentation": {},
               "training": {"batch_size": 3, "eval_batch_size": 2, "epochs": 2, "learning_rate": .001,
                            "head_learning_rate": .002, "weight_decay": .0001, "accumulation_steps": 2,
                            "warmup_epochs": 0, "patience": 5, "amp": False, "imbalance": "sampler"}}
        return rows, cfg

    @staticmethod
    def tiny_model(*args, **kwargs):
        import torch
        model = torch.nn.Sequential(torch.nn.Conv2d(3, 4, 3, padding=1), torch.nn.ReLU(),
                                    torch.nn.AdaptiveAvgPool2d(1), torch.nn.Flatten(), torch.nn.Linear(4, 2))
        return model, model[-1]

    def test_epoch_resume_matches_uninterrupted_training_and_rejects_drift(self):
        import torch
        from nilt import engine
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            rows, cfg = self.fixture(root)
            with patch.object(engine, "make_model", self.tiny_model):
                uninterrupted = engine.train_one("resnet18", 19, rows, cfg, root / "full")
                original_save = engine._atomic_torch_save

                def interrupt_after_epoch(payload, path):
                    original_save(payload, path)
                    if Path(path).name == "last.pt" and payload["epoch"] == 1:
                        raise RuntimeError("simulated process interruption")

                with patch.object(engine, "_atomic_torch_save", interrupt_after_epoch):
                    with self.assertRaisesRegex(RuntimeError, "simulated"):
                        engine.train_one("resnet18", 19, rows, cfg, root / "resumed")
                # Simulate the next epoch's best swap succeeding while last.pt
                # still belongs to the previous epoch. Recovery must use the
                # retained consistent best before restoring the optimizer/RNG.
                best_path = root / "resumed" / "best.pt"
                shutil.copy2(best_path, root / "resumed" / "previous_best.pt")
                incomplete = torch.load(best_path, weights_only=True)
                incomplete["epoch"] = 999
                torch.save(incomplete, best_path)
                resumed = engine.train_one("resnet18", 19, rows, cfg, root / "resumed")
                reference = torch.load(uninterrupted, weights_only=True)
                actual = torch.load(resumed, weights_only=True)
                for key in reference["state_dict"]:
                    torch.testing.assert_close(reference["state_dict"][key], actual["state_dict"][key], rtol=0, atol=0)
                changed = copy.deepcopy(cfg)
                changed["training"]["epochs"] = 3
                with self.assertRaisesRegex(ValueError, "fingerprint"):
                    engine.train_one("resnet18", 19, rows, changed, root / "resumed")
                scores, seconds = engine.predict_checkpoint(resumed, rows, cfg)
                self.assertEqual(len(scores), len(rows))
                self.assertTrue(np.isfinite(scores).all())
                self.assertGreaterEqual(seconds, 0)

    def test_chunked_patch_distances_equal_brute_force(self):
        import torch
        from nilt.patchcore import nearest_distances, greedy_coreset
        generator = torch.Generator().manual_seed(5)
        queries = torch.randn((11, 6), generator=generator)
        bank = torch.randn((7, 6), generator=generator)
        queries[0] = bank[2]
        scores = nearest_distances(queries, bank, 3, 2)
        expected = torch.sqrt(((queries[:, None] - bank[None]) ** 2).sum(-1)).min(1).values
        torch.testing.assert_close(scores, expected, rtol=1e-5, atol=1e-6)
        self.assertEqual(scores[0].item(), 0.0)
        features = np.asarray([[0, 0], [0, 0], [10, 10], [100, 100]], dtype=np.float32)
        selected = greedy_coreset(features, 3, projection_dim=2, seed=8)
        self.assertEqual(len(selected), 3)
        self.assertTrue((selected.numpy() == [100, 100]).all(axis=1).any())

    def test_patchcore_fit_uses_good_training_only_and_roundtrips_scores(self):
        import torch
        from nilt import engine, patchcore
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            rows, cfg = self.fixture(root)
            cfg["patchcore"] = {"reservoir_size": 20, "coreset_size": 5, "projection_dim": 3,
                                "query_chunk_size": 7, "memory_chunk_size": 2}
            checkpoint = engine.train_one("patchcore", 3, rows, cfg, root / "patchcore")
            state = torch.load(checkpoint, weights_only=True)
            self.assertEqual(state["good_training_image_count"], 4)
            self.assertEqual(state["coreset_count"], 5)
            model, _ = patchcore.load_patchcore(checkpoint, cfg, "cpu")
            direct, _ = patchcore.predict_patchcore(model, rows, cfg, "cpu")
            loaded, _ = engine.predict_checkpoint(checkpoint, rows, cfg, "cpu")
            np.testing.assert_allclose(direct, loaded, rtol=0, atol=0)
            self.assertTrue(np.isfinite(loaded).all())
            self.assertTrue((loaded >= 0).all())


if __name__ == "__main__":
    unittest.main()
