"""Versioned post-training decisions; source runs and final-test data stay untouched.

A decision refers to an immutable run by relative path and content fingerprints.
Moving both together preserves that reference. ``run_override`` permits relocation
of the run alone, after validating the same config, manifest and checkpoints.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import html
import math
import os
from pathlib import Path
import shutil
import time
import uuid

import numpy as np

from .common import read_json, safe_relative, sha_file, write_csv, write_json
from .policy import check_scores, metrics, threshold_curve, tune_threshold_details
from .runtime import discover_inputs, load_rgb, prepare_image, safe_asset

MODES = ("policy", "manual", "argmax", "scores_only")
FORMAT = "visual_inspection_decision_v3"
UNQUALIFIED = "NOT_INDEPENDENTLY_VALIDATED"


def _overlap(a, b):
    a, b = Path(a).resolve(), Path(b).resolve()
    return a.is_relative_to(b) or b.is_relative_to(a)


def _new_folder(output_root, protected=()):
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
    folder = Path(output_root).resolve() / (stamp + "_" + uuid.uuid4().hex[:8])
    if any(_overlap(folder, item) for item in protected if item):
        raise ValueError("Output must be separate from the input dataset, run and decision files.")
    folder.mkdir(parents=True, exist_ok=False)
    return folder


def _busy(run):
    if (Path(run) / "operation.lock").exists():
        raise ValueError("Run is busy. Wait until the active operation finishes.")


def _validate_candidate(run, candidate):
    if not isinstance(candidate.get("name"), str) or not candidate["name"]:
        raise ValueError("Candidate has no name.")
    # Candidate names are directory names, never paths.
    if any(c in candidate["name"] for c in ("/", "\\", ":")) or candidate["name"] in (".", ".."):
        raise ValueError("Invalid candidate name.")
    members = candidate.get("members", [])
    if not members:
        raise ValueError("Candidate has no model members.")
    kinds = {m.get("kind", "patchcore" if m.get("architecture") == "patchcore" else "supervised") for m in members}
    if not kinds <= {"supervised", "patchcore"} or ("patchcore" in kinds and len(members) != 1):
        raise ValueError("Unsupported mixture of model score types.")
    for member in members:
        if sha_file(safe_asset(run, member["checkpoint"])) != member["sha256"]:
            raise ValueError("Checkpoint checksum mismatch.")
        if member.get("config"):
            if sha_file(safe_asset(run, member["config"])) != member.get("config_sha256"):
                raise ValueError("Candidate configuration checksum mismatch.")
    return "patchcore" if "patchcore" in kinds else "supervised"


def list_candidates(run):
    """List recorded candidates without touching image data or test predictions."""
    from .workflow import open_run, load_selected
    run = Path(run).resolve()
    _busy(run)
    open_run(run)
    path = run / "candidates.json"
    records = read_json(path) if path.exists() else [load_selected(run)]
    if not isinstance(records, list) or not records:
        raise ValueError("Run has no recorded candidates.")
    if len({c["name"] for c in records}) != len(records):
        raise ValueError("Duplicate candidate names.")
    return deepcopy(records)


def _candidate(run, name):
    from .workflow import load_selected
    records = list_candidates(run)
    if name == "selected":
        chosen = load_selected(run)
    else:
        matches = [c for c in records if c["name"] == name]
        if not matches:
            raise ValueError("Unknown candidate. Choose a name from candidates.json.")
        chosen = matches[0]
    chosen = deepcopy(chosen)
    _validate_candidate(run, chosen)
    return chosen


def _calibration(run, chosen, cfg, manifest):
    """Load only threshold.npy, verifying hashes (or legacy recorded metrics)."""
    rows = [r for r in manifest if r["split"] == "threshold"]
    folder = safe_relative(run, "scores/" + chosen["name"])
    path = safe_asset(folder, "threshold.npy")
    scores_hash = sha_file(path)
    manifest_hash = sha_file(Path(run) / "manifest.csv")
    provenance_path = folder / "provenance.json"
    legacy = not provenance_path.exists()
    if not legacy:
        provenance = read_json(provenance_path)
        if (provenance.get("candidate") != chosen["name"] or
                provenance.get("manifest_sha256") != manifest_hash or
                provenance.get("files", {}).get("threshold.npy") != scores_hash):
            raise ValueError("Calibration score provenance mismatch.")
    labels, scores = check_scores([r["label"] for r in rows], np.load(path, allow_pickle=False))
    if len({r["relative_path"] for r in rows}) != len(rows):
        raise ValueError("Repeated paths in calibration manifest.")
    if legacy:
        recorded = chosen.get("threshold_metrics", {})
        if not recorded or chosen.get("threshold") is None:
            raise ValueError("Legacy calibration scores lack both provenance and recorded metrics; regenerate scores from the checkpoint first.")
        observed = metrics(labels, scores, float(chosen["threshold"]))
        for key in ("bad_detected_TP", "bad_passed_as_good_FN", "good_rejected_as_bad_FP", "good_accepted_TN", "pr_auc_bad", "roc_auc_bad"):
            if recorded.get(key) is not None and not np.isclose(observed[key], recorded[key], rtol=1e-9, atol=1e-12):
                raise ValueError("Legacy calibration scores disagree with recorded " + key)
    return rows, labels, scores, {"relative_path": path.relative_to(run).as_posix(), "sha256": scores_hash,
                                 "original_provenance_available": not legacy}


def calibration_preview(run, candidate="selected", threshold=None):
    """Return threshold-only explorer data. Never evaluates selection/final test."""
    from .workflow import open_run
    run = Path(run).resolve()
    cfg, manifest = open_run(run)
    chosen = _candidate(run, candidate)
    rows, labels, scores, provenance = _calibration(run, chosen, cfg, manifest)
    details = tune_threshold_details(labels, scores, cfg["policy"])
    value = details["threshold"] if threshold is None else _finite_threshold(threshold)
    curve = threshold_curve(labels, scores)
    return {"candidate": chosen["name"], "source_split": "threshold", "threshold": value,
            "score_type": chosen.get("score_type", "bad_probability_uncalibrated"),
            "policy": cfg["policy"], "policy_decision": details, "provenance": provenance,
            "metrics": metrics(labels, scores, value, [r["group"] for r in rows]),
            "curve": [{key: float(values[i]) for key, values in curve.items()} for i in range(len(curve["threshold"]))],
            "rows": [{"relative_path": row["relative_path"], "true_class": "bad" if label == 0 else "good", "score": float(score)}
                     for row, label, score in zip(rows, labels, scores)],
            "note": "Exploratory calibration results. No independent qualification and no final-test access."}


def _finite_threshold(value):
    if isinstance(value, (bool, str)) or value is None or not np.isscalar(value) or not math.isfinite(float(value)):
        raise ValueError("A finite numeric threshold is required.")
    return float(value)


def _mode_threshold(mode, threshold, kind):
    if mode not in MODES:
        raise ValueError("Unknown decision mode: " + str(mode))
    if mode == "scores_only":
        if threshold is not None:
            raise ValueError("scores_only has no threshold.")
        return None
    if mode == "argmax":
        if kind != "supervised":
            raise ValueError("argmax is supported only for supervised binary classifiers, not PatchCore anomaly distances.")
        if threshold is not None and threshold != .5:
            raise ValueError("argmax uses an implicit 0.5 threshold.")
        return .5
    return _finite_threshold(threshold)


def create_decision(run, mode="policy", threshold=None, candidate="selected", output_root="decisions"):
    """Freeze a new decision version; changing it requires creating another one."""
    from .workflow import open_run
    run = Path(run).resolve()
    cfg, manifest = open_run(run)
    chosen = _candidate(run, candidate)
    kind = _validate_candidate(run, chosen)
    score_files, calibration, details = [], None, None
    cache = run / "scores" / chosen["name"] / "threshold.npy"
    if mode == "policy" and threshold is not None:
        raise ValueError("Use manual mode to supply a threshold; policy mode fits calibration data.")
    if mode == "policy" or cache.exists():
        rows, labels, scores, provenance = _calibration(run, chosen, cfg, manifest)
        score_files.append(provenance)
        if mode == "policy":
            details = tune_threshold_details(labels, scores, cfg["policy"])
            threshold = details["threshold"]
    threshold = _mode_threshold(mode, threshold, kind)
    if score_files:
        calibration = decision_metrics(labels, scores, mode, threshold)
    out = _new_folder(output_root, (run, cfg.get("data_root")))
    # os.path.relpath fails across Windows drives; an explicit run override remains supported.
    try:
        run_reference = {"kind": "relative", "path": Path(os.path.relpath(run, out)).as_posix()}
    except ValueError:
        run_reference = {"kind": "absolute", "path": str(run)}
    record = {"format": FORMAT, "created_utc": datetime.now(timezone.utc).isoformat(),
              "mode": mode, "threshold": threshold, "task": cfg["task"], "kind": kind,
              "class_to_index": {"bad": 0, "good": 1},
              "rule": "scores_only" if mode == "scores_only" else "bad_if_score_greater_equal_threshold",
              "argmax_tie_break": "bad" if mode == "argmax" else None,
              # Only freeze model identity here: the candidate's old threshold,
              # old confusion metrics and qualification are not this decision.
              "candidate": {key: deepcopy(chosen[key]) for key in ("name", "members", "score_type") if key in chosen},
              "original_threshold": chosen.get("threshold"),
              "run_reference": run_reference, "source_run_id": run.name,
              "source_config_sha256": sha_file(run / "config.json"),
              "source_manifest_sha256": sha_file(run / "manifest.csv"), "score_files": score_files,
              "score_type": chosen.get("score_type", "anomaly_distance" if kind == "patchcore" else "bad_probability_uncalibrated"),
              "qualification_status": UNQUALIFIED, "policy": cfg["policy"], "policy_decision": details,
              "calibration_metrics": calibration, "calibration_split": "threshold" if score_files else None,
              "note": "New decision version. Original model qualification does not transfer. No final-test data used."}
    path = out / "decision.json"
    write_json(path, record)
    write_json(out / "decision_integrity.json", {"format": FORMAT, "decision_sha256": sha_file(path)})
    return path


def load_decision(decision, run_override=None):
    from .workflow import open_run
    path = Path(decision).resolve()
    if path.is_dir():
        path /= "decision.json"
    integrity = read_json(path.with_name("decision_integrity.json"))
    if sha_file(path) != integrity.get("decision_sha256"):
        raise ValueError("Decision checksum mismatch. Create a new version instead of editing decision.json.")
    record = read_json(path)
    if record.get("format") != FORMAT or record.get("class_to_index") != {"bad": 0, "good": 1}:
        raise ValueError("Unsupported decision format or class mapping.")
    reference = record["run_reference"]
    if run_override is not None:
        run = Path(run_override).resolve()
    elif reference["kind"] == "relative":
        run = (path.parent / reference["path"]).resolve()
    elif reference["kind"] == "absolute":
        run = Path(reference["path"]).resolve()
    else:
        raise ValueError("Unsupported run reference.")
    _busy(run)
    for filename, field in (("config.json", "source_config_sha256"), ("manifest.csv", "source_manifest_sha256")):
        if sha_file(run / filename) != record[field]:
            raise ValueError("Relocated run fingerprint mismatch: " + filename)
    cfg, _ = open_run(run)
    chosen = deepcopy(record["candidate"])
    kind = _validate_candidate(run, chosen)
    value = _mode_threshold(record["mode"], record["threshold"], kind)
    if value != record["threshold"] or kind != record["kind"]:
        raise ValueError("Decision mode/model mismatch.")
    for item in record.get("score_files", []):
        if sha_file(safe_asset(run, item["relative_path"])) != item["sha256"]:
            raise ValueError("Recorded calibration score changed.")
    return record, run, cfg, chosen


def decision_metrics(labels, scores, mode, threshold=None):
    """Descriptive metrics; undefined class-specific values remain JSON null."""
    labels, scores = check_scores(labels, scores)
    if mode != "scores_only":
        result = metrics(labels, scores, _finite_threshold(threshold))
        result.update(mode=mode, qualification_status=UNQUALIFIED,
                      note="Descriptive image-level results, not independent-unit qualification.")
        return result
    from sklearn.metrics import average_precision_score, roc_auc_score
    bad = labels == 0
    both = bool(bad.any() and (~bad).any())
    return {"mode": mode, "n_images": len(labels), "n_bad": int(bad.sum()), "n_good": int((~bad).sum()),
            "pr_auc_bad": float(average_precision_score(bad, scores)) if both else None,
            "roc_auc_bad": float(roc_auc_score(bad, scores)) if both else None,
            "constant_score_pr_auc_baseline": float(bad.mean()),
            "note": "Ranking metrics only. No decisions, confusion matrix or accuracy exist in scores_only mode."}


def _audit_inputs(root, labeled, cfg):
    rows = discover_inputs(root, labeled=labeled)
    if labeled:
        from .common import EXTENSIONS
        outside = [p for p in Path(root).rglob("*") if p.is_file() and p.suffix.lower() in EXTENSIONS
                   and p.relative_to(root).parts[0] not in ("good", "bad")]
        if outside:
            raise ValueError("Labeled images must be inside good/ or bad/: " + str(outside[0]))
    good, invalid, pixel_labels, duplicates = [], [], {}, []
    for source in rows:
        row = {"path": str(source["path"]), "relative_path": source["relative_path"], "true_class": source["true_class"] or ""}
        try:
            image = load_rgb(source["path"])
            prepare_image(image, {"image_size": cfg["image_size"], "resize": cfg["resize"]})
            digest = hashlib.sha256(str(image.size).encode() + image.tobytes()).hexdigest()
            if digest in pixel_labels:
                previous = pixel_labels[digest]
                if labeled and previous["true_class"] != row["true_class"]:
                    raise RuntimeError("Identical decoded image appears in both good and bad: " + previous["relative_path"] + " / " + row["relative_path"])
                duplicates.append({"original": previous["relative_path"], "duplicate": row["relative_path"]})
            else:
                pixel_labels[digest] = row
            row.update(file_sha256=sha_file(source["path"]), pixel_sha256=digest)
            good.append(row)
        except (OSError, ValueError) as error:
            invalid.append({**row, "error": str(error)})
    return good, invalid, duplicates


def predict_decision(decision, input_dir, output_root="classified", labeled=False, copy_images=True,
                     device="cpu", run_override=None):
    from .workflow import predict_members
    record, run, cfg, chosen = load_decision(decision, run_override)
    source = Path(input_dir).resolve()
    cfg = {**cfg, "device": device}
    rows, invalid, duplicates = _audit_inputs(source, labeled, cfg)
    if not rows:
        raise ValueError("No valid input images. " + "; ".join(r["error"] for r in invalid[:3]))
    decision_path = Path(decision).resolve()
    if decision_path.is_dir():
        decision_path /= "decision.json"
    out = _new_folder(output_root, (source, run, decision_path.parent, cfg.get("data_root")))
    write_json(out / "summary.json", {"status": "incomplete", "decision_sha256": sha_file(decision_path)})
    start = time.perf_counter()
    try:
        scores, _ = predict_members(run, chosen["members"], rows, cfg)
        scores = np.asarray(scores, dtype=float)
        if scores.shape != (len(rows),) or not np.isfinite(scores).all():
            raise ValueError("Inference returned invalid scores.")
        if record["kind"] == "supervised" and np.any((scores < 0) | (scores > 1)):
            raise ValueError("Supervised bad scores must be in [0,1].")
        for row in rows:
            if sha_file(row["path"]) != row["file_sha256"]:
                raise ValueError("Input changed during inference: " + row["relative_path"])
        predictions = []
        for row, score in zip(rows, scores):
            predicted = "" if record["mode"] == "scores_only" else ("bad" if score >= record["threshold"] else "good")
            entry = {"relative_path": row["relative_path"], "true_class": row["true_class"], "score": float(score),
                     "score_type": record["score_type"], "predicted_class": predicted, "threshold": record["threshold"],
                     "decision_mode": record["mode"], "status": "ok", "error": "", "output_path": ""}
            if copy_images and predicted:
                identity = hashlib.sha256(row["relative_path"].encode()).hexdigest()[:20]
                name = identity + "__" + Path(row["path"]).name[-100:]
                destination = out / "predicted" / predicted / name
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(row["path"], destination)
                entry["output_path"] = destination.relative_to(out).as_posix()
                if labeled and row["true_class"] != predicted:
                    error_dir = out / "errors" / (row["true_class"] + "_to_" + predicted)
                    error_dir.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(row["path"], error_dir / name)
            predictions.append(entry)
        for row in invalid:
            predictions.append({"relative_path": row["relative_path"], "true_class": row["true_class"], "score": None,
                                "score_type": record["score_type"], "predicted_class": "", "threshold": record["threshold"],
                                "decision_mode": record["mode"], "status": "input_error", "error": row["error"], "output_path": ""})
        write_csv(out / "predictions.csv", predictions)
        write_csv(out / "invalid_images.csv", invalid, ["relative_path", "true_class", "error"])
        write_csv(out / "duplicate_images.csv", duplicates, ["original", "duplicate"])
        write_json(out / "scores.json", {"rows": rows, "scores": scores.tolist(), "invalid": invalid})
        if labeled:
            met = decision_metrics([0 if r["true_class"] == "bad" else 1 for r in rows], scores, record["mode"], record["threshold"])
            met.update(invalid_excluded=len(invalid), exact_duplicate_count=len(duplicates),
                       note="Descriptive image-level metrics. Invalid inputs excluded; duplicates listed; no qualification claim.")
            write_json(out / "metrics.json", met)
        # Snapshot identifies the exact frozen decision, while its original location remains explicit.
        write_json(out / "applied_decision.json", record)
        write_json(out / "summary.json", {"status": "completed_with_input_errors" if invalid else "completed",
                   "created_utc": datetime.now(timezone.utc).isoformat(), "task": record["task"],
                   "candidate": chosen["name"], "mode": record["mode"], "threshold": record["threshold"],
                   "qualification_status": UNQUALIFIED, "decision_sha256": sha_file(decision_path),
                   "scores_sha256": sha_file(out / "scores.json"), "labeled": bool(labeled), "valid_images": len(rows),
                   "invalid_images": len(invalid), "exact_duplicate_count": len(duplicates),
                   "counts": None if record["mode"] == "scores_only" else {name: sum(r["predicted_class"] == name for r in predictions) for name in ("good", "bad")},
                   "elapsed_seconds": time.perf_counter() - start})
        return out
    except Exception as error:
        write_json(out / "summary.json", {"status": "failed", "error": str(error), "error_type": type(error).__name__})
        raise


def review_decisions(run, thresholds=None, candidate="selected", output_root="threshold_review"):
    """Save a cached calibration comparison. Creating a deployment decision is explicit."""
    from .workflow import open_run
    run = Path(run).resolve()
    cfg, _ = open_run(run)
    preview = calibration_preview(run, candidate)
    values = [preview["threshold"]] if thresholds is None else list(dict.fromkeys(_finite_threshold(t) for t in thresholds))
    if not values:
        raise ValueError("At least one threshold is required.")
    labels = [0 if r["true_class"] == "bad" else 1 for r in preview["rows"]]
    scores = [r["score"] for r in preview["rows"]]
    comparison = [{"threshold": value, **decision_metrics(labels, scores, "manual", value)} for value in values]
    out = _new_folder(output_root, (run, cfg.get("data_root")))
    write_json(out / "review.json", {**preview, "comparisons": comparison})
    write_csv(out / "comparison.csv", comparison)
    write_csv(out / "calibration_curve.csv", preview["curve"])
    columns = ["threshold", "bad_escape_rate", "good_reject_rate", "accuracy", "balanced_accuracy"]
    table = "<tr>" + "".join("<th>" + name + "</th>" for name in columns) + "</tr>"
    table += "".join("<tr>" + "".join("<td>" + html.escape(str(row.get(name))) + "</td>" for name in columns) + "</tr>" for row in comparison)
    (out / "comparison.html").write_text('<!doctype html><meta charset="utf-8"><title>Calibration threshold review</title><style>body{font:16px system-ui;margin:2em}td,th{padding:.6em;border:1px solid #bbb}table{border-collapse:collapse}</style><h1>Calibration threshold review</h1><p>Only the threshold split was read. No final-test data used. Lower threshold rejects more images. These development results do not qualify a model.</p><table>' + table + "</table>", encoding="utf-8")
    return out
