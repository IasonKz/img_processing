# Ξεκίνα εδώ — Top Segmentation Studio v2

Annotation και segmentation training στο ίδιο τοπικό περιβάλλον, αποκλειστικά για **top images**. Τα ονόματα των κουμπιών παρακάτω είναι αυτά του αγγλικού UI.

## Windows — Python 3.12

1. Κάνε extract ολόκληρο το ZIP σε νέο φάκελο.
2. Τρέξε **Setup.cmd** μία φορά. Δημιουργεί `.venv` και εγκαθιστά τις εξαρτήσεις.
3. Τρέξε **Start.cmd** και κράτησε ανοιχτό το terminal.
4. Άνοιξε http://127.0.0.1:8765 αν δεν ανοίξει αυτόματα.
5. Στο **Workspace**, συμπλήρωσε **Top image folder**, **Annotation project folder** και **Results folder**. Πάτησε **Save project settings**, μετά **Import top images**.

Αν έχεις ήδη v1, ακολούθησε πρώτα το **UPGRADE_v2.md** για να χρησιμοποιήσεις τα ίδια annotations και αποτελέσματα.

Για περιβάλλον Python που έχεις ήδη δημιουργήσει:

```powershell
python -m pip install -r requirements-training.txt
python segmentation.py studio --config project.yaml
```

Για NVIDIA GPU χρειάζεται συμβατό PyTorch/torchvision CUDA build στον συγκεκριμένο υπολογιστή. Το **CPU** λειτουργεί χωρίς CUDA. Το πρόγραμμα δεν επιβάλλει συγκεκριμένο αριθμό trials ή χρονικό όριο για laptop/workstation.

## Linux

```bash
bash Setup.sh
bash Start.sh
```

Ή χειροκίνητα:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-training.txt
python segmentation.py studio --config project.yaml
```

Για annotation χωρίς εγκατάσταση των neural-network πακέτων:

```bash
python -m pip install -r requirements.txt
python segmentation.py studio --config project.yaml
```

Η αρχική εγκατάσταση χρειάζεται internet ή ήδη διαθέσιμα πακέτα/wheels. Μετά την εγκατάσταση το πρόγραμμα λειτουργεί τοπικά, χωρίς upload εικόνων. Στη v2 οι βασικές εξαρτήσεις περιλαμβάνουν και `opencv-python-headless` για τη σύγκριση με εικόνες αναφοράς.

## Διάλεξε μέθοδο και κάνε reload

1. Άνοιξε **Annotation** και μια εικόνα.
2. Στο **Annotation method**, διάλεξε **Basic — current detector**, **Basic + exclusion zones**, **Structure-aware — experimental** ή **Good-reference comparison — experimental**.
3. Στο **Detection area**, διάλεξε **Full image**, **Central die — automatic** ή **Custom area**.
4. Άφησε ενεργό το **Keep manual additions and erasures** για να διατηρούνται οι χειροκίνητες διορθώσεις σου.
5. Πάτησε **Reload proposals**. Αλλάζει η προεπισκόπηση της τρέχουσας εικόνας. Για άμεση επιστροφή, πάτησε **Undo last reload**. Μετά από επόμενες διορθώσεις χρησιμοποίησε το κανονικό Undo/Ctrl+Z.
6. Σβήσε ή πρόσθεσε defects και πάτησε **Save draft** ή **Approve & next** για αποθήκευση.

Για επιστροφή στην αρχική μέθοδο: **Basic — current detector → Full image → Reload proposals**. Το Basic αγνοεί τις πρόσθετες εξαιρέσεις, αλλά σέβεται τις χειροκίνητες διορθώσεις όταν είναι ενεργή η διατήρησή τους. Για εντελώς νέες προτάσεις, απενεργοποίησε τη διατήρηση διορθώσεων πριν το reload.

## Αποθήκευσε εξαιρέσεις για label, σύμβολα και eye

1. Διάλεξε **Basic + exclusion zones**.
2. Στο **Exclusion zones and lens eye**, διάλεξε **New zone category**.
3. Πάτησε **Draw exclusion polygon**, κάνε κλικ στις κορυφές και **Enter** για κλείσιμο. Σχεδίασε χωριστά το label και τα δύο σύμβολα.
4. Με τους ανεξάρτητους διακόπτες **Label**, **Orientation symbols**, **Lens eye**, **Custom zones**, επίλεξε τι θα παραλείπεται.
5. Για το κεντρικό eye χρησιμοποίησε **Draw lens eye ellipse** ή τις αριθμητικές διαστάσεις. Χωρίς δική σου έλλειψη εμφανίζεται εκτίμηση από το inner polygon· έλεγξέ την.
6. Στο **Reusable automation profile**, άφησε ενεργό **Use profile for new images** και πάτησε **Save automation profile**.

Το profile αποθηκεύει μέθοδο, detection area, ζώνες, eye και επιλογή references. Οι υπάρχουσες αποθηκευμένες εικόνες κρατούν τις δικές τους ρυθμίσεις. Για μία από αυτές: **Load profile on this image → Reload proposals → Save draft**.

Οι ζώνες προσαρμόζονται στις διαστάσεις της εικόνας, αλλά δεν ακολουθούν αυτόματα μετατόπιση ή περιστροφή του εξαρτήματος. Έλεγξε τη θέση τους. Οι διακόπτες label/συμβόλων χρειάζονται τις αντίστοιχες σχεδιασμένες ζώνες: δεν αναγνωρίζουν τα σημάδια από μόνοι τους. Μια περιοχή που εξαιρείται από τις αυτόματες προτάσεις μπορεί πάντα να μαρκαριστεί με το χέρι.

## Φτιάξε το σωστό polygon μία φορά

1. Με **Boundary** σχεδίασε τις κορυφές του inner area και πάτησε **Enter**. Ή με **Octagon** σύρε το πλαίσιο του σχήματος.
2. Άνοιξε **Inner boundary and saved polygon → Chamfered rectangle geometry**. Ρύθμισε θέση, πλάτος, ύψος, περιστροφή και τα ανεξάρτητα **Cut X / Cut Y** κάθε γωνίας. Πάτησε **Apply geometry to boundary**.
3. Με το **Boundary** μπορείς επίσης να σύρεις κάθε κορυφή ανεξάρτητα.
4. Για μικρή προσαρμογή στις ακμές: **Follow current polygon edges → Detect inner boundary**. Για αναζήτηση νέου σχήματος: **Find polygon automatically**. Αν δεν υπάρχει αξιόπιστη ακμή, διατηρείται το προηγούμενο περίγραμμα.
5. Διάλεξε **Relative to image size** ή **Exact pixels (same dimensions)**, άφησε ενεργό **Use for new images** και πάτησε **Save custom polygon**.

Το polygon παραμένει μετά το κλείσιμο του προγράμματος και δεν αλλάζει όταν αλλάζεις μέθοδο annotation. Για ήδη αποθηκευμένες εικόνες χρησιμοποίησε **Use saved polygon on this image** ή **Apply saved polygon to existing images**. Η μαζική εφαρμογή αφορά drafts από προεπιλογή· το **Include approved images in batch** περιλαμβάνει και approved εικόνες. Όσες αλλάξουν επιστρέφουν σε draft για έλεγχο και διατηρούν το ιστορικό τους.

Το inner polygon χωρίζει τα σημειωμένα defects σε inner/outer. Δεν βάφει όλο το εσωτερικό ως defect και δεν περιορίζει από μόνο του την περιοχή ανίχνευσης.

## Εκπαίδευση και αποτελέσματα

1. Έλεγξε και κάνε approve αντιπροσωπευτικές εικόνες, με καθαρές εικόνες και πραγματικά inner/outer defects.
2. Στο **Model search**, επίλεξε μοντέλα, image sizes, batch sizes, παραμέτρους και budgets.
3. Πάτησε **Preflight selected models**, μετά **Start / resume search** με ένα study name. Το `0` απενεργοποιεί το αντίστοιχο όριο χρόνου/trials· με όλα τα όρια απενεργοποιημένα συνεχίζει μέχρι να σταματήσεις τη διαδικασία.
4. Στο **Results & compare**, σύγκρινε τα validation metrics. Στο **Inspect & predict**, έλεγξε τα overlays. Χρησιμοποίησε το held-out test αφού επιλέξεις το τελικό μοντέλο.
5. Στο **Export**, εξήγαγε μοντέλο ή dataset. Για ONNX χρειάζεται `python -m pip install -r requirements-export.txt`.

Το ίδιο study συνεχίζει με το αρχικό frozen dataset. Νέα annotations/approvals ή αλλαγή search space χρειάζονται **νέο study name**. Η επανεκκίνηση συνεχίζει τα completed trials, όχι το ακριβές batch που διακόπηκε. Τα pruned trials είναι δοκιμές που σταμάτησαν νωρίς· τα failed trials εμφανίζουν το συγκεκριμένο σφάλμα.

**Ανάλυση:** annotation, boundary detection και masks δουλεύουν στις αρχικές διαστάσεις. Το training παραμένει όπως στη v1: κάνει resize στο επιλεγμένο image size και padding. Η v2 δεν προσθέτει native-resolution tile training. Μικρά defects μπορεί να χαθούν στο resize, ακόμη και αν τα τελικά prediction masks επανέλθουν στις αρχικές διαστάσεις.

## Πού αποθηκεύονται

Τα σχετικά paths υπολογίζονται ως προς τον φάκελο του YAML:

- `input/top/`: οι αρχικές εικόνες, που δεν τροποποιούνται.
- `annotation_project/`: αντίγραφα εργασίας, annotations, masks, ιστορικό, polygon και automation profile.
- `results/studies/<study>/`: frozen dataset, splits, Optuna SQLite, checkpoints και metrics.
- `results/predictions/`: prediction masks, overlays και CSV.
- `results/packages/`, `results/datasets/`, `results/reports/`: exports.
- `results/jobs/`: κατάσταση και logs εργασιών.

Επίλεξε φάκελο μόνο με top εικόνες: το import διαβάζει και υποφακέλους και δεν αναγνωρίζει αυτόματα ότι κάποια εικόνα είναι bottom/vig. Δεν απαιτούνται good/bad υποφάκελοι για segmentation.

Το κλείσιμο του browser δεν σταματά το training. Χρησιμοποίησε **Stop operation** όταν θέλεις να σταματήσει. Οι **Structure-aware** και **Good-reference comparison** είναι πειραματικές μέθοδοι και απαιτούν έλεγχο σε πραγματικές εικόνες. Περισσότερα: **docs/ANNOTATION_V2.md**.
