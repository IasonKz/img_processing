"""Actual preparation workers, native pixels, output safeguards and saved setup."""
import csv
import hashlib
import json
from pathlib import Path
import tempfile
import time
import unittest

import cv2
import numpy as np

from nilt.dashboard import Dashboard
from nilt import dataset_preparation as prep


class DashboardPreprocessingTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.config = self.root / "project.yaml"
        self.config.write_text("tasks:\n  vig:\n    dataset_root: ./data\n", encoding="utf-8")
        self.app = Dashboard(self.config)
        self.pixels = np.arange(31 * 47, dtype=np.uint16).reshape(31, 47) * 17
        self.sources = []
        for name in ("C0000083_Rc09Cc17.png", "C0000083_Rc10Cc17.png"):
            source = self.root / name
            prep.write_png(source, self.pixels)
            self.sources.append(source)
        self.csv = self.write_csv("labels ; with spaces.csv", "vig", [("p", self.sources[0]), ("f", self.sources[1])])

    def tearDown(self):
        self.temp.cleanup()

    def write_csv(self, name, task, rows):
        path = self.root / name
        columns = prep.TASK_COLUMNS[task]
        with path.open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(columns["labels"] + columns["sources"]), delimiter=";")
            writer.writeheader()
            for label, source in rows:
                row = {key: label for key in columns["labels"]}
                row.update({key: repr([str(source)]) for key in columns["sources"]})
                writer.writerow(row)
        return path

    def payload(self, **changes):
        return {"csv_files": [str(self.csv)], "output": str(self.root / "prepared"),
                "vig_brightness": False, "debug": True, "output_depth": "native", **changes}

    def run_job(self, action="preprocess", **changes):
        result = self.app.start(action, self.payload(**changes))
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline:
            job = next(j for j in self.app.jobs if j["id"] == result["job"])
            if job["status"] != "running":
                return next(j for j in self.app.preprocessing_state()["jobs"] if j["id"] == job["id"])
            time.sleep(.05)
        self.fail("Preparation worker did not finish within 20 seconds")

    def test_reference_check_writes_report_but_no_dataset_and_cannot_train(self):
        job = self.run_job("preprocess-check")
        self.assertEqual(job["status"], "finished")
        self.assertTrue(job["report"]["dry_run"])
        self.assertEqual(job["report"]["counts"], {"vig/good": 1, "vig/bad": 1})
        self.assertFalse((self.root / "prepared").exists())
        with self.assertRaisesRegex(ValueError, "complete dataset"):
            self.app.preprocessing_use_dataset({"job": job["id"], "task": "vig"})

    def test_real_preparation_keeps_pixels_sources_and_persists_dataset_setup(self):
        original_config = self.config.read_bytes()
        source_hashes = [hashlib.sha256(p.read_bytes()).hexdigest() for p in self.sources]
        job = self.run_job()
        self.assertEqual(job["status"], "finished")
        report = job["report"]
        self.assertTrue(report["complete"])
        self.assertEqual(report["processed_images"], 2)
        self.assertEqual(report["counts"], {"vig/good": 1, "vig/bad": 1})
        for label, source in zip(("good", "bad"), self.sources):
            np.testing.assert_array_equal(prep.decode_image(self.root / "prepared" / "vig" / label / source.name), self.pixels)
        self.assertEqual(source_hashes, [hashlib.sha256(p.read_bytes()).hexdigest() for p in self.sources])
        saved = self.app.preprocessing_use_dataset({"job": job["id"], "task": "vig"})
        self.assertEqual(saved["datasets"]["vig"], str(self.root / "prepared" / "vig"))
        self.assertEqual(self.config.read_bytes(), original_config)
        reopened = Dashboard(self.config)
        self.assertEqual(reopened.bootstrap()["datasets"]["vig"], saved["datasets"]["vig"])
        self.assertEqual(reopened.preprocessing_state()["jobs"][-1]["report"], report)
        summary = self.root / "prepared" / "summary.json"
        self.assertEqual(reopened.checked_output(summary), summary)
        with self.assertRaises(ValueError):
            self.app.preprocessing_use_dataset({"job": job["id"], "task": "top"})

    def test_omissions_are_incomplete_and_not_automatically_used(self):
        self.csv = self.write_csv("missing.csv", "vig", [("p", self.sources[0]), ("f", self.root / "missing.png")])
        job = self.run_job()
        self.assertEqual(job["status"], "incomplete")
        self.assertEqual(job["report"]["omitted_references"], 1)
        self.assertFalse(job["report"]["complete"])
        with self.assertRaisesRegex(ValueError, "incomplete"):
            self.app.preprocessing_use_dataset({"job": job["id"], "task": "vig"})

    def test_all_three_tasks_share_the_engine_and_connect_in_one_snapshot(self):
        die = self.root / "C0000083_Rc11Cc17.png"
        pixels = np.full((600, 600), 500, dtype=np.uint16)
        pixels[235:365, 235:365] = 30000
        prep.write_png(die, pixels)
        top = self.write_csv("top.csv", "top", [("p", die)])
        bottom = self.write_csv("bottom.csv", "bottom", [("f", die)])
        job = self.run_job(csv_files=[str(self.csv), str(top), str(bottom)])
        self.assertEqual(job["status"], "finished", job["lines"])
        self.assertEqual(job["report"]["counts"], {"vig/good": 1, "vig/bad": 1, "top/good": 1, "bottom/bad": 1})
        saved = self.app.preprocessing_use_dataset({"job": job["id"], "task": "top"})
        for task in ("vig", "top", "bottom"):
            self.assertEqual(saved["datasets"][task], str(self.root / "prepared" / task))
            self.assertTrue(saved["task_enabled"][task])
        for task, label in (("top", "good"), ("bottom", "bad")):
            crop = prep.decode_image(self.root / "prepared" / task / label / die.name)
            self.assertEqual(crop.dtype, np.uint16)
            self.assertGreaterEqual(min(crop.shape), 130)
            self.assertTrue((self.root / "prepared" / "_debug" / task / label / die.name).is_file())
        np.testing.assert_array_equal(prep.decode_image(die), pixels)

    def test_foreign_job_metadata_does_not_register_an_output_root(self):
        job = self.run_job()
        marker = self.root / "foreign"
        marker.mkdir()
        record_path = self.app.logs_root / (job["id"] + ".job.json")
        record = json.loads(record_path.read_text())
        record["preprocessing_output"] = str(marker)
        record_path.write_text(json.dumps(record))
        reopened = Dashboard(self.config)
        with self.assertRaises(ValueError):
            reopened.checked_output(marker / "private.txt")
        with self.assertRaisesRegex(ValueError, "verified"):
            reopened.preprocessing_use_dataset({"job": job["id"], "task": "vig"})

    def test_conflicting_labels_fail_before_writing_dataset(self):
        self.csv = self.write_csv("conflict.csv", "vig", [("p", self.sources[0]), ("f", self.sources[0])])
        job = self.run_job()
        self.assertEqual(job["status"], "failed")
        self.assertFalse((self.root / "prepared").exists())
        self.assertTrue(any("Conflicting" in line for line in job["lines"]))

    def test_failed_crop_is_saved_for_review_outside_training(self):
        source = self.root / "flat.png"
        prep.write_png(source, np.zeros((200, 200), dtype=np.uint16))
        self.csv = self.write_csv("top.csv", "top", [("f", source)])
        job = self.run_job()
        self.assertEqual(job["status"], "incomplete")
        self.assertEqual(job["report"]["failed_images"], 1)
        self.assertFalse(any((self.root / "prepared" / "top" / "bad").iterdir()))
        self.assertEqual((self.root / "prepared" / "_review" / "top" / "bad" / "flat.png").read_bytes(), source.read_bytes())

    def test_nonempty_output_and_invalid_options_are_rejected_before_launch(self):
        output = self.root / "prepared"
        output.mkdir()
        marker = output / "keep.txt"
        marker.write_text("keep")
        with self.assertRaisesRegex(ValueError, "NEW or EMPTY"):
            self.app.command("preprocess", self.payload())
        invalid = [{"csv_files": "labels.csv"}, {"csv_files": []}, {"csv_files": [123]},
                   {"white_level": True}, {"white_level": 65536}, {"white_level": 1.5},
                   {"output_depth": "16"}, {"debug": "yes"}, {"vig_brightness": 1}, {"tray": "missing"}]
        for options in invalid:
            with self.subTest(options=options), self.assertRaises(ValueError):
                self.app.command("preprocess", self.payload(output=str(self.root / "fresh"), **options))
        self.assertEqual(marker.read_text(), "keep")
        self.assertEqual(self.app.jobs, [])
        command = self.app.command("preprocess-check", self.payload())
        self.assertIn(str(self.csv), command)
        self.assertIn("--dry-run", command)

    def test_cooperative_stop_retains_partial_output_and_report(self):
        stop = self.root / "stop"
        stop.touch()
        report = self.root / "report.json"
        code = prep.main(["--csv", str(self.csv), "--output", str(self.root / "prepared"),
                          "--stop-file", str(stop), "--report", str(report)])
        self.assertEqual(code, 130)
        summary = json.loads(report.read_text())
        self.assertTrue(summary["cancelled"])
        self.assertFalse(summary["complete"])
        self.assertEqual(summary["processed_images"], 0)
        self.assertTrue(all(source.is_file() for source in self.sources))

    def test_stop_requires_a_known_running_preparation(self):
        with self.assertRaises(ValueError):
            self.app.preprocessing_cancel({"job": "unknown"})
        job = self.run_job("preprocess-check")
        with self.assertRaisesRegex(ValueError, "not running"):
            self.app.preprocessing_cancel({"job": job["id"]})

    def test_untagged_worker_classification_handoff_preserves_training_configuration(self):
        tray = self.root / "original tester"
        source = tray / "MeasurementData" / "Results" / "C0000083_Rc09Cc17_FlatFieldBright.png"
        prep.write_png(source, self.pixels)
        original_config = self.app.config
        original_datasets = self.app.bootstrap()["datasets"]
        job = self.run_job(mode="untagged", tray=str(tray), csv_files=[])
        self.assertEqual(job["mode"], "untagged")
        self.assertEqual(job["status"], "finished", job["lines"])
        summary = job["report"]
        self.assertEqual(summary["counts"], {"vig": 1, "top": 0, "bottom": 0})
        np.testing.assert_array_equal(prep.decode_image(self.root / "prepared" / "vig" / source.name), self.pixels)
        handoff = self.app.preprocessing_use_classification({"job": job["id"], "task": "vig"})
        self.assertEqual(handoff, {"task": "vig", "input": str(self.root / "prepared" / "vig"),
                                  "labeled": False, "roi_scope": "whole_image"})
        self.assertEqual(self.app.config, original_config)
        self.assertEqual(self.app.bootstrap()["datasets"], original_datasets)
        with self.assertRaisesRegex(ValueError, "no training labels"):
            self.app.preprocessing_use_dataset({"job": job["id"], "task": "vig"})
        with self.assertRaisesRegex(ValueError, "no prepared images"):
            self.app.preprocessing_use_classification({"job": job["id"], "task": "top"})
        reopened = Dashboard(self.config)
        self.assertEqual(reopened.preprocessing_use_classification({"job": job["id"], "task": "vig"}), handoff)

    def test_untagged_scan_is_not_classification_input_and_validates_folder_options(self):
        tray = self.root / "original tester"
        prep.write_png(tray / "C0000083_Rc09Cc17_ViTopStart.png", self.pixels)
        prep.write_png(tray / "C0000083_Rc09Cc17_ViTopFinal.png", self.pixels)
        prep.write_png(tray / "C0000083_Rc09Cc17_ViBottomStart.png", self.pixels)
        prep.write_png(tray / "C0000083_Rc09Cc17_ViBottomPostTarget.png", self.pixels)
        job = self.run_job("preprocess-check", mode="untagged", tray=str(tray))
        self.assertEqual(job["status"], "finished")
        self.assertEqual(job["report"]["counts"], {"vig": 0, "top": 1, "bottom": 1})
        self.assertEqual(job["report"]["stage"], "final")
        self.assertEqual(job["report"]["skipped_reasons"], {"stage_filter": 2})
        self.assertFalse((self.root / "prepared").exists())
        with self.assertRaisesRegex(ValueError, "complete dataset"):
            self.app.preprocessing_use_classification({"job": job["id"], "task": "top"})
        for options in ({"tray": ""}, {"stage": "unknown"}, {"top_pattern": "["},
                        {"vig_pattern": 1}, {"output": str(tray / "prepared")}):
            with self.subTest(options=options), self.assertRaises(ValueError):
                self.app.command("preprocess", self.payload(**{"mode": "untagged", "tray": str(tray), **options}))

    def test_labelled_worker_cannot_be_handed_off_as_untagged(self):
        job = self.run_job()
        with self.assertRaisesRegex(ValueError, "untagged preparation"):
            self.app.preprocessing_use_classification({"job": job["id"], "task": "vig"})


if __name__ == "__main__":
    unittest.main()
