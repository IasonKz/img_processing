"""Offline loopback annotation server. No network services or web dependencies."""
from __future__ import annotations

from contextlib import suppress
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from io import BytesIO
from pathlib import Path
import html
import json
import logging
import secrets
import threading
from urllib.parse import urlsplit
import webbrowser

import numpy as np
from PIL import Image

from .project import ConflictError, Project
from .annotations import decode_rle, encode_rle, MAX_ANNOTATION_PIXELS

WEB_ROOT = Path(__file__).with_name("web")
MAX_BODY_BYTES = 64 * 1024 * 1024


class AnnotationServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, cfg, port=0):
        self.project = Project(cfg)
        self.project_lock = threading.RLock()
        self.session_token = secrets.token_urlsafe(32)
        super().__init__(("127.0.0.1", int(port)), AnnotationHandler)
        self.local_hosts = {f"127.0.0.1:{self.server_port}", f"localhost:{self.server_port}"}


class AnnotationHandler(BaseHTTPRequestHandler):
    server: AnnotationServer
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        logging.getLogger("topseg.annotation").info(fmt, *args)

    def _send(self, status, data, content_type="application/json; charset=utf-8"):
        if isinstance(data, dict):
            data = json.dumps(data, allow_nan=False).encode("utf-8")
        elif isinstance(data, str):
            data = data.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cross-Origin-Resource-Policy", "same-origin")
        self.send_header("X-Frame-Options", "SAMEORIGIN")
        self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self' blob: data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; object-src 'none'; frame-ancestors 'self'; base-uri 'none'")
        self.end_headers()
        self.wfile.write(data)

    def _authorize(self, mutate=False):
        host = self.headers.get("Host", "")
        if host not in self.server.local_hosts:
            self._send(403, {"error": "Only the local annotation address is allowed."})
            return False
        if urlsplit(self.path).path.startswith("/api/"):
            token = self.headers.get("X-Session-Token", "")
            if not secrets.compare_digest(token, self.server.session_token):
                self._send(403, {"error": "Invalid annotation session. Reload the application."})
                return False
        origin = self.headers.get("Origin")
        if (mutate or origin is not None) and origin != f"http://{host}":
            self._send(403, {"error": "The request must originate from this local application."})
            return False
        return True

    def _route(self):
        parts = urlsplit(self.path).path.strip("/").split("/")
        if len(parts) in (3, 4) and parts[:2] == ["api", "image"]:
            image_id = parts[2]
            if not image_id or len(image_id) > 128 or not all(c.isalnum() or c in "_-" for c in image_id):
                raise ValueError("Invalid image identifier.")
            return image_id, (parts[3] if len(parts) == 4 else "")
        return None, None

    def _mask(self, image_id, metadata=None):
        path = self.server.project.mask_path(image_id)
        if path:
            with Image.open(path) as image:
                return np.asarray(image, dtype=np.uint8).copy()
        metadata = metadata or self.server.project.open_image(image_id)
        return np.zeros((metadata["height"], metadata["width"]), dtype=np.uint8)

    def _enrich(self, image_id, result=None):
        result = dict(result or self.server.project.open_image(image_id))
        result["mask_rle"] = encode_rle(self._mask(image_id, result))
        result["rgb_url"] = f"/api/image/{image_id}/rgb"
        result["mask_url"] = f"/api/image/{image_id}/mask"
        return result

    def do_GET(self):
        try:
            if not self._authorize():
                return
            path = urlsplit(self.path).path
            if path == "/":
                page = (WEB_ROOT / "index.html").read_text(encoding="utf-8")
                self._send(200, page.replace("__SESSION_TOKEN__", html.escape(self.server.session_token)), "text/html; charset=utf-8")
                return
            assets = {"/app.js": ("app.js", "text/javascript; charset=utf-8"), "/mask.js": ("mask.js", "text/javascript; charset=utf-8"), "/styles.css": ("styles.css", "text/css; charset=utf-8")}
            if path in assets:
                filename, content_type = assets[path]
                self._send(200, (WEB_ROOT / filename).read_bytes(), content_type)
                return
            with self.server.project_lock:
                if path == "/api/template":
                    self._send(200, self.server.project.polygon_template())
                    return
                if path == "/api/project":
                    items = self.server.project.items()
                    self._send(200, {"items": items, "classes": {"background": 0, "inner": 1, "outer": 2}, "approved": sum(x.get("status") == "approved" for x in items), "total": len(items)})
                    return
                image_id, operation = self._route()
                if image_id is not None:
                    if operation == "":
                        self._send(200, self._enrich(image_id))
                        return
                    if operation == "rgb":
                        self._send(200, self.server.project.image_path(image_id).read_bytes(), "image/png")
                        return
                    if operation == "mask":
                        buffer = BytesIO()
                        Image.fromarray(self._mask(image_id)).save(buffer, format="PNG")
                        self._send(200, buffer.getvalue(), "image/png")
                        return
            self._send(404, {"error": "Resource not found."})
        except (FileNotFoundError, KeyError):
            self._send(404, {"error": "Image or resource not found."})
        except ValueError as exc:
            self._send(400, {"error": str(exc)})
        except Exception:
            logging.exception("Annotation request failed")
            self._send(500, {"error": "Annotation operation failed. See the terminal log."})

    def do_POST(self):
        try:
            if not self._authorize(mutate=True):
                # Do not retain unread request bytes on a keep-alive connection.
                self.close_connection = True
                return
            if self.headers.get("Transfer-Encoding") or self.headers.get("Content-Type", "").split(";")[0] != "application/json":
                self.close_connection = True
                self._send(415, {"error": "Send application/json with Content-Length."})
                return
            size = int(self.headers.get("Content-Length", "0"))
            if size <= 0 or size > MAX_BODY_BYTES:
                self.close_connection = True
                self._send(413, {"error": "Request body is empty or exceeds 64 MiB."})
                return
            payload = json.loads(self.rfile.read(size), parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Non-finite JSON values are not allowed.")))
            if not isinstance(payload, dict):
                raise ValueError("Expected a JSON object.")
            route = urlsplit(self.path).path
            if route.startswith('/api/template'):
                with self.server.project_lock:
                    p = self.server.project
                    if route == '/api/template':
                        result = p.save_polygon_template(payload['image_id'],payload['roi'],payload['expected_revision'],payload.get('mode','normalized'),payload.get('enabled',True))
                    elif route == '/api/template/roi':
                        row=p._row(payload['image_id']); template=p.polygon_template()
                        if not template.get('revision'): raise ValueError('Save a custom polygon first.')
                        result={'roi':p.template_roi(row['width'],row['height'],{**template,'enabled':True})}
                    elif route == '/api/template/apply':
                        result=p.apply_polygon_template(payload.get('include_approved',False))
                    else:
                        self._send(404, {'error':'Unknown template operation.'})
                        return
                self._send(200,result)
                return
            image_id, operation = self._route()
            if image_id is None or operation not in ("annotation", "propose", "reject", "restore", "detect-roi"):
                self._send(404, {"error": "Operation not found."})
                return
            revision = payload.get("expected_revision")
            if type(revision) is not int or revision < 0:
                raise ValueError("expected_revision must be a non-negative integer.")
            with self.server.project_lock:
                if operation == "detect-roi":
                    result = self.server.project.detect_roi(image_id, expected_revision=revision, roi=payload.get("roi"))
                    self._send(200, result)
                    return
                if operation in ("reject", "restore"):
                    self.server.project.set_rejected(image_id, rejected=operation == "reject", expected_revision=revision, reason=payload.get("reason", ""))
                elif operation == "propose":
                    self.server.project.propose(image_id, roi=payload.get("roi"), settings=payload.get("settings"), expected_revision=revision)
                else:
                    metadata = self.server.project.open_image(image_id)
                    mask = decode_rle(payload.get("mask_rle"), metadata["width"], metadata["height"])
                    approved = payload.get("approved", False)
                    clean = payload.get("clean", False)
                    notes = payload.get("notes", "")
                    if type(approved) is not bool or type(clean) is not bool or not isinstance(notes, str) or len(notes) > 10000:
                        raise ValueError("Invalid approval, clean-image flag, or notes.")
                    self.server.project.save_annotation(image_id, mask, roi=payload.get("roi"), expected_revision=revision, approved=approved, clean=clean, notes=notes, settings=payload.get("settings"), origin="manual", objects=payload.get("objects"))
                self._send(200, self._enrich(image_id))
        except ConflictError as exc:
            self._send(409, {"error": str(exc)})
        except (FileNotFoundError, KeyError):
            self._send(404, {"error": "Image not found."})
        except (ValueError, TypeError) as exc:
            self._send(400, {"error": str(exc)})
        except Exception:
            logging.exception("Annotation write failed")
            self._send(500, {"error": "Annotation operation failed. See the terminal log."})


def make_server(cfg, port=0):
    return AnnotationServer(cfg, port)


def serve(cfg, open_browser=True):
    port = cfg.get("annotation", {}).get("port", 8765)
    server = make_server(cfg, port)
    url = f"http://127.0.0.1:{server.server_port}/"
    print(f"Annotation application: {url}\nKeep this terminal open. Press Ctrl+C to stop.", flush=True)
    if open_browser:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nAnnotation server stopped.")
    finally:
        with suppress(Exception):
            server.server_close()
