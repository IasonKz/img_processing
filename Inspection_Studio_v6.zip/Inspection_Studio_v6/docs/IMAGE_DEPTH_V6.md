# Image depth and native resolution

Inspection Studio accepts unsigned 8-bit and 16-bit images. Grayscale images are
replicated into three channels; color images retain RGB channel values. PNG and
TIFF are decoded at native depth. Float, signed integer and multiframe files
require an explicit conversion or frame extraction before ingestion.

Pixel dimensions and intensity precision are different properties. A 1600 x
1600 image contains the same spatial samples whether it stores 256 or 65,536
intensity levels. Native 16-bit loading prevents truncating subtle differences;
it does not reconstruct details already removed by previous 8-bit conversion.

## Fixed intensity conversion

For unsigned 16-bit input, the model receives float32 values computed as:

```
value = (pixel - uint16_black_level) / (uint16_white_level - uint16_black_level)
```

The default configuration is:

```yaml
intensity:
  uint16_black_level: 0
  uint16_white_level: 65535
```

This is followed by the model's channel normalization. There is no intermediate
8-bit image, per-image min/max adjustment, gamma adjustment or clipping. Values
outside the configured black/white interval are preserved below zero or above
one. Padding uses the same normalized background as eight-bit inputs.

Use the sensor's documented acquisition range. A right-aligned 12-bit signal
stored in a 16-bit container may use white level 4095; a left-aligned signal
does not use that same scale. Do not infer the sensor range from the darkest or
brightest pixel in one picture. Keep settings fixed across a dataset and
production acquisition. Eight-bit sources always retain the historical /255
conversion and are unaffected by these two settings.

Intensity settings travel with checkpoints and ONNX packages. Resume rejects
a conflicting setting. Inference uses the checkpoint's recorded conversion.
New 16-bit inputs should be evaluated before deploying an older model trained
on converted 8-bit images; equivalent filenames do not imply equivalent input
intensities.

## Spatial geometry

Use `resize: pad` and `preserve_native_resolution: true` to keep native pixels.
Automatic image size chooses a canvas that holds every image. Larger images
are rejected instead of silently reduced when an explicit canvas is too small.
The image size limit is a memory guard that can be increased deliberately.
Exact quarter-turn augmentation preserves pixel values and exchanges width and
height for non-square images. `resize: fit` remains an explicit resampling
option and cannot be combined with native-resolution preservation.

The existing dataset preparation tool's 8-bit output remains accepted. Keep
original 16-bit files if sensor precision is needed. Crop/alignment and intensity
conversion in a dataset preparation tool are separate operations; alignment can
interpolate pixels even when the output pixel spacing is unchanged.

## Audit and display

Audit reports the source depth counts and fixed intensity settings. Exact
duplicate identities include every decoded 16-bit value, so images differing
by one sensor count are distinct. Perceptual duplicate hints and browser
previews use display representations; those are not model inputs. Browser
support for displaying a 16-bit PNG does not establish its decoded precision
inside a model.

OpenCV is required for native 16-bit decoding and is included in the installation
requirements. Portable ONNX exports bundle the same decoding and conversion
implementation used by training.
