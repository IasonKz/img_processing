[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('cpu', 'cuda')]
    [string]$Device,
    [ValidateSet('3.11', '3.12')]
    [string]$PythonVersion = '3.11',
    [string]$OfflineWheelhouse = '',
    [switch]$WithExport
)

$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$VenvPath = Join-Path $ProjectRoot '.venv'
$PythonExe = Join-Path $VenvPath 'Scripts\python.exe'

function Invoke-Checked {
    param([string]$Executable, [string[]]$Arguments)
    & $Executable @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Command failed with exit code $LASTEXITCODE : $Executable $($Arguments -join ' ')"
    }
}

Push-Location $ProjectRoot
try {
    if (-not (Test-Path -LiteralPath $PythonExe)) {
        if (-not (Get-Command py -ErrorAction SilentlyContinue)) {
            throw 'Python launcher py was not found. Install 64-bit Python 3.11/3.12 or follow docs/INSTALLATION.md.'
        }
        Invoke-Checked -Executable 'py' -Arguments @("-$PythonVersion", '-m', 'venv', $VenvPath)
    }
    Invoke-Checked -Executable $PythonExe -Arguments @('-c', "import sys; assert '.'.join(map(str,sys.version_info[:2])) == '$PythonVersion', 'Existing .venv has a different Python version. Use a fresh project folder or match -PythonVersion.'; assert sys.maxsize > 2**32, '64-bit Python is required'; print(sys.version)")

    if ($OfflineWheelhouse) {
        $WheelhousePath = (Resolve-Path -LiteralPath $OfflineWheelhouse).Path
        if (-not (Test-Path -LiteralPath $WheelhousePath -PathType Container)) {
            throw 'OfflineWheelhouse must name a directory of Windows wheels matching this Python version.'
        }
        $SourceArguments = @('--no-index', '--find-links', $WheelhousePath)
        Invoke-Checked -Executable $PythonExe -Arguments (@('-m', 'pip', 'install') + $SourceArguments + @('-r', 'requirements.txt', 'torch==2.7.1', 'torchvision==0.22.1'))
        if ($WithExport) {
            Invoke-Checked -Executable $PythonExe -Arguments (@('-m', 'pip', 'install') + $SourceArguments + @('-r', 'requirements-export.txt'))
        }
    }
    else {
        Invoke-Checked -Executable $PythonExe -Arguments @('-m', 'pip', 'install', '--upgrade', 'pip')
        Invoke-Checked -Executable $PythonExe -Arguments @('-m', 'pip', 'install', '-r', 'requirements.txt')
        $TorchIndex = if ($Device -eq 'cuda') { 'https://download.pytorch.org/whl/cu128' } else { 'https://download.pytorch.org/whl/cpu' }
        Invoke-Checked -Executable $PythonExe -Arguments @('-m', 'pip', 'install', 'torch==2.7.1', 'torchvision==0.22.1', '--index-url', $TorchIndex)
        if ($WithExport) {
            Invoke-Checked -Executable $PythonExe -Arguments @('-m', 'pip', 'install', '-r', 'requirements-export.txt')
        }
    }

    Invoke-Checked -Executable $PythonExe -Arguments @('-m', 'pip', 'check')
    $DeviceCheck = @'
import sys
import torch
import torchvision
print('PyTorch:', torch.__version__)
print('torchvision:', torchvision.__version__)
mode = sys.argv[1]
if mode == 'cuda':
    if not torch.cuda.is_available():
        raise SystemExit('CUDA is unavailable. Check the NVIDIA driver and the CUDA wheel; no CPU fallback was selected.')
    item = torch.cuda.get_device_properties(0)
    print('GPU:', item.name)
    print('VRAM GiB:', round(item.total_memory / 2**30, 2))
    test = torch.ones(4, device='cuda')
    assert (test + test).cpu().tolist() == [2.0] * 4
    torch.cuda.synchronize()
    print('Actual CUDA tensor operation passed.')
else:
    if torch.version.cuda is not None:
        raise SystemExit('This .venv contains a CUDA wheel. For the requested CPU setup use a fresh project environment and CPU wheelhouse.')
    assert (torch.ones(4) + 1).tolist() == [2.0] * 4
    print('CPU tensor operation passed.')
'@
    Invoke-Checked -Executable $PythonExe -Arguments @('-c', $DeviceCheck, $Device)
    Write-Host ''
    Write-Host 'Environment ready. Next: edit project.yaml, provision public weights, and run inspection.py doctor.'
    Write-Host 'Guide: docs/INSTALLATION.md. No image data was read or uploaded by this setup script.'
}
finally {
    Pop-Location
}
