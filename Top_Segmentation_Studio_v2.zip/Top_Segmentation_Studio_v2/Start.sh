#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [[ ! -x .venv/bin/python ]]; then
  echo 'Run bash Setup.sh first, or use: python segmentation.py studio --config project.yaml'
  exit 1
fi
exec .venv/bin/python segmentation.py studio --config project.yaml
