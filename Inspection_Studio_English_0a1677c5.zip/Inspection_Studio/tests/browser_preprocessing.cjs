"use strict";
// Actual CSV and untagged preparation, native pixels and GUI handoffs.
const {chromium}=require("playwright"),{spawn,spawnSync}=require("node:child_process");
const fs=require("node:fs"),path=require("node:path"),os=require("node:os"),assert=require("node:assert/strict");
const root=path.resolve(__dirname,".."),temporary=fs.mkdtempSync(path.join(os.tmpdir(),"studio-preprocessing-browser-"));
const output=path.resolve(process.argv[2]||path.join(os.tmpdir(),"studio-preprocessing-screenshots"));
fs.mkdirSync(output,{recursive:true});
const python=process.env.STUDIO_PYTHON||"python",port=18767;
const fixture=spawnSync(python,["-c",`import csv, sys
from pathlib import Path
import numpy as np
from nilt.dataset_preparation import write_png, TASK_COLUMNS
root = Path(sys.argv[1])
columns = TASK_COLUMNS['vig']
with (root / 'labels.csv').open('w', newline='', encoding='utf-8-sig') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(columns['labels'] + columns['sources']), delimiter=';')
    writer.writeheader()
    for index, tag in enumerate(('p', 'f')):
        source = root / f'C00000083_Rc0{index+1}Cc01.png'
        write_png(source, np.arange(31 * 47, dtype=np.uint16).reshape(31, 47) * 17)
        row = {key: tag for key in columns['labels']}
        row.update({key: repr([str(source)]) for key in columns['sources']})
        writer.writerow(row)
raw = root / 'original tester' / 'MeasurementData' / 'Results'
die = np.full((600, 600), 500, dtype=np.uint16)
die[235:365, 235:365] = 30000
for token in ('ViTopFinal', 'ViBottomPostTarget', 'ViTopStart', 'ViBottomStart', 'AlignTop'):
    write_png(raw / f'C00000083_Rc01Cc01_{token}.png', die)
write_png(raw / 'C00000083_Rc01Cc01_FlatFieldBright.png', np.arange(31 * 47, dtype=np.uint16).reshape(31, 47) * 17)
write_png(raw / 'EvaluationResults' / 'C00000083_Rc01Cc01_ViTopFinal.png', die)
`,temporary],{cwd:root,encoding:"utf8"});
if(fixture.status!==0)throw Error(fixture.stderr);
const config=path.join(temporary,"project.yaml");
fs.writeFileSync(config,"tasks:\n  vig:\n    dataset_root: ./images\n");
const server=spawn(python,["inspection.py","dashboard","--config",config,"--port",String(port),"--no-browser"],{cwd:root,stdio:["ignore","pipe","pipe"]});
let browser,log="";server.stderr.on("data",chunk=>log+=chunk.toString());
async function main(){
  await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error("Startup timeout: "+log)),20000);server.stdout.on("data",chunk=>{log+=chunk.toString();if(log.includes("Local dashboard:")){clearTimeout(timer);resolve();}});server.on("exit",code=>{clearTimeout(timer);reject(Error("Server exited: "+code));});});
  browser=await chromium.launch({headless:true,...(process.env.STUDIO_BROWSER_EXECUTABLE?{executablePath:process.env.STUDIO_BROWSER_EXECUTABLE}:{})});
  const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];
  page.on("pageerror",error=>errors.push(error.message));
  await page.goto(`http://127.0.0.1:${port}`);
  await page.waitForFunction(()=>document.getElementById("connection").textContent.includes("Connected"));
  await page.waitForFunction(()=>document.getElementById("custom-contract-status").textContent.includes("Loaded profile defaults"));
  assert.equal(await page.locator("#notice.error").isVisible(),false);
  assert.equal(await page.locator("nav button").first().getAttribute("id"),"nav-preprocessing");
  assert.equal(await page.locator("#tab-preprocessing").isVisible(),true);
  assert.equal(await page.locator("#nav-preprocessing").getAttribute("aria-current"),"page");
  assert.equal(await page.locator(".nilt-logo").evaluate(image=>image.complete&&image.naturalWidth>0),true);
  assert.equal(await page.locator("#prep-start").evaluate(button=>getComputedStyle(button).backgroundColor),"rgb(0, 118, 189)");
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
  await page.screenshot({path:path.join(output,"preprocessing-desktop.png"),fullPage:true});
  await page.locator("#prep-csv").fill(path.join(temporary,"labels.csv"));
  await page.locator("#prep-output").fill(path.join(temporary,"prepared"));
  await page.locator("#prep-brightness").uncheck();
  await page.locator("#prep-check").click();
  await page.waitForFunction(()=>document.getElementById("prep-status").textContent.includes("CSV reference check · finished"));
  assert.equal(fs.existsSync(path.join(temporary,"prepared")),false);
  assert.equal(await page.locator("#prep-use").isDisabled(),true);
  await page.locator("#prep-start").click();
  await page.waitForFunction(()=>document.getElementById("prep-status").textContent.includes("Dataset preparation · finished"));
  assert.match(await page.locator("#prep-results").innerText(),/Complete/);
  assert.equal(await page.locator("#prep-use").isEnabled(),true);
  const summary=JSON.parse(fs.readFileSync(path.join(temporary,"prepared","summary.json"),"utf8"));
  assert.deepEqual(summary.counts,{"vig/good":1,"vig/bad":1});
  const native=spawnSync(python,["-c",`import sys, numpy as np
from pathlib import Path
from nilt.dataset_preparation import decode_image
root = Path(sys.argv[1])
for label, index in [('good',1),('bad',2)]:
    name = f'C00000083_Rc0{index}Cc01.png'
    original = decode_image(root / name)
    prepared = decode_image(root / 'prepared' / 'vig' / label / name)
    assert prepared.dtype == np.uint16
    np.testing.assert_array_equal(original, prepared)
`,temporary],{cwd:root,encoding:"utf8"});
  assert.equal(native.status,0,native.stderr);
  await page.screenshot({path:path.join(output,"preprocessing-results.png"),fullPage:true});
  await page.locator("#prep-use").click();
  await page.waitForFunction(()=>document.getElementById("tab-setup").classList.contains("active"));
  assert.equal(await page.locator("#dataset").inputValue(),path.join(temporary,"prepared","vig"));
  assert.equal(fs.readFileSync(config,"utf8"),"tasks:\n  vig:\n    dataset_root: ./images\n");
  await page.locator("#nav-preprocessing").click();
  await page.locator("#prep-start").click();
  await page.waitForFunction(()=>document.getElementById("notice").textContent.includes("NEW or EMPTY"));
  assert.equal(fs.readFileSync(path.join(temporary,"prepared","summary.json"),"utf8"),JSON.stringify(summary,null,2));
  await page.locator("#prep-mode").selectOption("untagged");
  assert.equal(await page.locator("#prep-csv").isVisible(),false);
  assert.equal(await page.locator("#prep-folder").isVisible(),true);
  assert.equal(await page.locator("#prep-folder").locator("..").getByRole("button",{name:"Browse for folder"}).isVisible(),true);
  await page.locator("#prep-folder").fill(path.join(temporary,"original tester"));
  await page.locator("#prep-output").fill(path.join(temporary,"untagged"));
  assert.equal(await page.locator("#prep-stage").inputValue(),"final");
  await page.locator("#prep-check").click();
  await page.waitForFunction(()=>document.getElementById("prep-status").textContent.includes("Capture name scan · finished"));
  assert.equal(fs.existsSync(path.join(temporary,"untagged")),false);
  assert.equal(await page.locator("#prep-use").isDisabled(),true);
  assert.match(await page.locator("#prep-results").innerText(),/stage_filter: 2/);
  await page.locator("#prep-start").click();
  await page.waitForFunction(()=>document.getElementById("prep-status").textContent.includes("Untagged preparation · finished"));
  const untagged=JSON.parse(fs.readFileSync(path.join(temporary,"untagged","summary.json"),"utf8"));
  assert.deepEqual(untagged.counts,{vig:1,top:1,bottom:1});
  assert.equal(untagged.labels_present,false);
  assert.equal(untagged.complete,true);
  assert.equal(untagged.stage,"final");
  assert.deepEqual(fs.readdirSync(path.join(temporary,"untagged","top")),["C00000083_Rc01Cc01_ViTopFinal.png"]);
  assert.deepEqual(fs.readdirSync(path.join(temporary,"untagged","bottom")),["C00000083_Rc01Cc01_ViBottomPostTarget.png"]);
  for(const task of ["vig","top","bottom"]){
    assert.equal(fs.readdirSync(path.join(temporary,"untagged",task)).length,1);
    assert.equal(fs.existsSync(path.join(temporary,"untagged",task,"good")),false);
    assert.equal(fs.existsSync(path.join(temporary,"untagged",task,"bad")),false);
  }
  assert.equal(fs.existsSync(path.join(temporary,"untagged__debug","top","C00000083_Rc01Cc01_ViTopFinal.png")),true);
  assert.match(await page.locator("#prep-use").innerText(),/classify/);
  assert.match(await page.locator("#prep-results").innerText(),/Untagged images/i);
  await page.screenshot({path:path.join(output,"preprocessing-untagged.png"),fullPage:true});
  const trainingBefore=await page.evaluate(async()=> (await api("/api/bootstrap")).datasets);
  for(const task of ["vig","top","bottom"]){
    await page.locator("#nav-predict").click();await page.locator("#labeled").check();
    await page.locator("#nav-preprocessing").click();
    await page.locator("#prep-task").selectOption(task);
    await page.locator("#prep-use").click();
    await page.waitForFunction(()=>document.getElementById("tab-predict").classList.contains("active"));
    assert.equal(await page.locator("#predict-input").inputValue(),path.join(temporary,"untagged",task));
    assert.equal(await page.locator("#labeled").isChecked(),false);
    assert.equal(await page.locator("#task").inputValue(),task);
    assert.equal(await page.locator("#classification-scope").inputValue(),"whole_image");
    assert.equal(await page.locator("#dataset").inputValue()===path.join(temporary,"untagged",task),false);
  }
  assert.deepEqual(await page.evaluate(async()=> (await api("/api/bootstrap")).datasets),trainingBefore);
  await page.locator('[data-workspace="vig"]').click();
  for(const name of ["setup","search","compare","decision","predict","workflow","review","manage","systems","quality"]){
    await page.locator("#nav-"+name).click();
    assert.equal(await page.locator("#tab-"+name).isVisible(),true);
    assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false,"desktop overflow in "+name);
  }
  await page.locator("#nav-search").click();await page.screenshot({path:path.join(output,"search-desktop.png"),fullPage:true});
  await page.locator("#nav-preprocessing").click();await page.setViewportSize({width:390,height:844});
  await page.evaluate(()=>window.scrollTo(0,0));
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false,"mobile overflow");
  await page.screenshot({path:path.join(output,"preprocessing-mobile.png"),fullPage:true});
  const forbidden=await page.evaluate(async()=>{const response=await fetch("/api/preprocessing/use-dataset",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({})});return response.status;});
  assert.equal(forbidden,403);assert.deepEqual(errors,[]);
  console.log("PASS: real CSV and untagged tester preparation; native uint16; stage selection; clean TOP/BOTTOM/VIG outputs; classification handoffs without reference labels or training dataset changes; overwrite protection; authenticated actions; desktop/mobile layout.");
}
main().catch(error=>{console.error(error);console.error(log);process.exitCode=1;}).finally(async()=>{if(browser)await browser.close();server.kill("SIGINT");fs.rmSync(temporary,{recursive:true,force:true});});
