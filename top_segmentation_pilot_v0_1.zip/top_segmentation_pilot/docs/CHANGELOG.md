# Changelog

## 0.1.0

- Added local, one-image-at-a-time top-view annotation with manual Inner/Outer defect classes.
- Added classical contrast-based proposals guided by a per-image lens ellipse.
- Added editable native-resolution masks, revision history, explicit approval, and clean-negative approval.
- Added independent approved-data snapshots with physical-unit grouping.
- Added optional small U-Net training, per-class validation metrics, checkpoints, and native-geometry mask prediction.
- Separated the lightweight annotation environment from the PyTorch training dependency.

This release is a pilot for annotation and segmentation experiments. It includes no trained weights, real inspection dataset, or production accuracy certification.
