"""Raw tester discovery and exports suitable for unlabelled classification."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

from nilt import dataset_preparation as engine
from nilt import untagged_preparation as prep


class UntaggedPreparationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.tray = self.root / "tester tray café"
        self.raw = self.tray / "MeasurementData" / "Results"
        self.raw.mkdir(parents=True)
        self.output = self.root / "prepared captures"
        self.pixels = np.arange(31 * 47, dtype=np.uint16).reshape(31, 47) * 17
        self.die = np.full((600, 600), 500, dtype=np.uint16)
        self.die[235:365, 235:365] = 30000

    def tearDown(self):
        self.temp.cleanup()

    def image(self, name, pixels=None, base=None):
        path = (base or self.raw) / name
        engine.write_png(path, self.pixels if pixels is None else pixels)
        return path

    def run_preparation(self, *options):
        return engine.main(["--mode", "untagged", "--tray", str(self.tray),
                            "--output", str(self.output), *options])

    def test_discovery_prefers_raw_data_skips_derived_and_filters_stages(self):
        for token in ("ViTopStart", "ViTopFinal", "ViBottomStart", "ViBottomPostTarget", "FlatFieldBright", "vivig1", "AlignTop", "SideImage"):
            self.image(f"C00000083_Rc01Cc01_{token}.PNG")
        self.image("C00000083_Rc01Cc01_ViTopFinal.png", base=self.raw / "EvaluationResults")
        self.image("C00000083_Rc01Cc01_ViTopFinal.png", base=self.tray / "EvaluationResults")
        external = self.root / "external"
        self.image("C00000083_Rc01Cc01_ViTopFinal.png", base=external)
        (self.raw / "linked directory").symlink_to(external, target_is_directory=True)
        (self.raw / "C00000083_Rc01Cc01_ViTopFinal_link.png").symlink_to(external / "C00000083_Rc01Cc01_ViTopFinal.png")
        patterns = prep.compile_patterns({})
        scan_root, final, skipped = prep.scan_images(self.tray, patterns)
        self.assertEqual(scan_root, self.raw)
        self.assertEqual([task for task, _, _ in final], ["vig", "vig", "top", "bottom"])
        self.assertEqual({row["reason"] for row in skipped}, {"unrecognized_capture", "stage_filter", "symlink"})
        self.assertEqual(len(prep.scan_images(self.raw, patterns, "all")[1]), 6)
        starts = prep.scan_images(self.tray, patterns, "start")[1]
        self.assertEqual({stage for task, _, stage in starts if task != "vig"}, {"start"})

    def test_export_keeps_native_pixels_no_labels_and_separate_overlays(self):
        sources = [self.image("C00000083_Rc01Cc01_FlatFieldBright.png"),
                   self.image("C00000083_Rc01Cc01_ViTopFinal.png", self.die),
                   self.image("C00000083_Rc01Cc01_ViBottomPostTarget.png", self.die)]
        starts = [self.image(f"C00000083_Rc01Cc01_{token}.png", self.die)
                  for token in ("ViTopStart", "ViBottomStart")]
        before = [hashlib.sha256(p.read_bytes()).hexdigest() for p in sources]
        self.assertEqual(self.run_preparation("--no-vig-brightness", "--debug"), 0)
        summary = json.loads((self.output / "summary.json").read_text())
        settings = json.loads((self.output / "preparation.json").read_text())
        self.assertEqual(summary["counts"], {"vig": 1, "top": 1, "bottom": 1})
        self.assertTrue(summary["complete"])
        self.assertEqual(summary["stage"], "final")
        self.assertEqual(summary["skipped_reasons"], {"stage_filter": 2})
        self.assertFalse(settings["labels_present"])
        self.assertFalse(settings["uses_csv"])
        self.assertEqual(settings["output_bit_depth"], "native")
        for task, source in zip(prep.TASKS, sources):
            expected, _, _ = engine.prepare_one(source, task, brightness=False)
            actual = engine.decode_image(self.output / task / source.name)
            np.testing.assert_array_equal(actual, expected)
            self.assertEqual(actual.dtype, np.uint16)
            self.assertFalse((self.output / task / "good").exists())
            self.assertFalse((self.output / task / "bad").exists())
        for task, source in zip(("top", "bottom"), sources[1:]):
            self.assertTrue((Path(summary["debug_folder"]) / task / source.name).is_file())
        self.assertFalse(Path(summary["debug_folder"]).is_relative_to(self.output))
        self.assertEqual(len(list(self.output.rglob("*.png"))), 3)
        for start in starts:
            self.assertTrue(start.is_file())
        self.assertEqual(before, [hashlib.sha256(p.read_bytes()).hexdigest() for p in sources])

    def test_repeated_filenames_and_extensions_never_overwrite(self):
        name = "C00000083_Rc01Cc01_FlatFieldBright"
        self.image(name + ".png", self.pixels, self.raw / "a")
        self.image(name + ".tiff", self.pixels + 1, self.raw / "a")
        self.image(name + ".png", self.pixels + 2, self.raw / "b")
        self.assertEqual(self.run_preparation("--no-vig-brightness"), 0)
        paths = list((self.output / "vig").glob("*.png"))
        self.assertEqual(len(paths), 3)
        self.assertEqual({int(engine.decode_image(p)[0, 0]) for p in paths}, {0, 1, 2})
        originals = {p.name: p.read_bytes() for p in paths}
        self.assertEqual(self.run_preparation(), 1)
        self.assertEqual(originals, {p.name: p.read_bytes() for p in paths})

    def test_failed_originals_stay_outside_recursive_classification_input(self):
        failed = self.image("C00000083_Rc01Cc01_ViTopFinal.png", np.zeros((200, 200), dtype=np.uint16))
        self.image("C00000083_Rc01Cc01_FlatFieldBright.png")
        self.assertEqual(self.run_preparation(), 2)
        summary = json.loads((self.output / "summary.json").read_text())
        self.assertEqual(summary["failed_images"], 1)
        self.assertFalse(summary["complete"])
        self.assertEqual((Path(summary["review_folder"]) / "top" / failed.name).read_bytes(), failed.read_bytes())
        self.assertEqual(len(list(self.output.rglob("*.png"))), 1)
        self.assertFalse(any((self.output / "top").iterdir()))

    def test_dry_scan_writes_only_requested_report_and_cancellation_is_incomplete(self):
        self.image("C00000083_Rc01Cc01_FlatFieldBright.png")
        report = self.root / "report.json"
        self.assertEqual(self.run_preparation("--dry-run", "--report", str(report)), 0)
        self.assertFalse(self.output.exists())
        summary = json.loads(report.read_text())
        self.assertTrue(summary["dry_run"])
        self.assertEqual(summary["processed_images"], 0)
        stop = self.root / "stop"
        stop.touch()
        self.assertEqual(self.run_preparation("--stop-file", str(stop), "--report", str(report)), 130)
        summary = json.loads(report.read_text())
        self.assertTrue(summary["cancelled"])
        self.assertFalse(summary["complete"])
        self.assertEqual(summary["processed_images"], 0)

    def test_overlap_auxiliary_alias_and_ambiguous_patterns_fail_before_export(self):
        self.image("C00000083_Rc01Cc01_FlatFieldBright.png")
        with self.assertRaisesRegex(ValueError, "OUTSIDE"):
            prep.validate_output(self.tray, self.tray / "prepared", True)
        auxiliary = self.output.with_name(self.output.name + "__review")
        empty = self.tray / "empty"
        empty.mkdir()
        auxiliary.symlink_to(empty, target_is_directory=True)
        self.assertEqual(self.run_preparation(), 1)
        self.assertFalse(any(empty.iterdir()))
        auxiliary.unlink()
        self.assertEqual(self.run_preparation("--top-pattern", "FlatFieldBright"), 1)
        self.assertEqual(self.run_preparation("--vig-pattern", "["), 1)
        self.assertFalse(self.output.exists())

    def test_custom_names_and_explicit_eight_bit_use_shared_intensity_pipeline(self):
        source = self.image("C00000083_Rc01Cc01_MyVigCapture.png")
        self.assertEqual(self.run_preparation("--vig-pattern", "MyVigCapture", "--output-depth", "8"), 0)
        expected, _, _ = engine.prepare_one(source, "vig", output_depth="8")
        actual = engine.decode_image(self.output / "vig" / source.name)
        self.assertEqual(actual.dtype, np.uint8)
        np.testing.assert_array_equal(actual, expected)


if __name__ == "__main__":
    unittest.main()
