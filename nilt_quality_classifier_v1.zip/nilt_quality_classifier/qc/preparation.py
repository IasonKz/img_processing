from __future__ import annotations

import ast
import json
import re
import shutil
from pathlib import Path
from typing import Any, Iterable, Sequence

import pandas as pd

from .config import get, resolve_path
from .constants import DEFAULT_IMAGE_EXTENSIONS, INDEX_TO_LABEL
from .data import DEFAULT_UNIT_ID_REGEX, canonicalize_unit_id, extract_unit_id, normalize_extensions
from .ground_truth import (
    _label_lookup,
    combine_row_labels,
    resolve_column,
    resolve_columns,
)
from .utils import setup_logging, write_json


def _extract_path_candidates(value: Any) -> list[str]:
    text = str(value).strip()
    if not text:
        return []

    candidates: list[str] = []
    try:
        parsed = ast.literal_eval(text)
        if isinstance(parsed, (list, tuple, set)):
            candidates.extend(str(item) for item in parsed)
        elif isinstance(parsed, str):
            candidates.append(parsed)
    except (ValueError, SyntaxError):
        pass

    if not candidates:
        # Covers a plain path as well as loosely formatted lists.
        quoted = re.findall(r"['\"]([^'\"]+\.(?:bmp|png|jpe?g|tiff?))['\"]", text, flags=re.I)
        candidates.extend(quoted)
    if not candidates and Path(text.strip("'\"")).suffix:
        candidates.append(text.strip("'\""))

    output: list[str] = []
    seen: set[str] = set()
    for candidate in candidates:
        candidate = candidate.strip().strip("'\"")
        if candidate and candidate not in seen:
            seen.add(candidate)
            output.append(candidate)
    return output


def _apply_replacements(path_text: str, replacements: Sequence[dict[str, Any]]) -> str:
    result = path_text
    for replacement in replacements:
        old = str(replacement.get("from", ""))
        new = str(replacement.get("to", ""))
        if old:
            result = result.replace(old, new)
    return result


def _build_fallback_index(
    root: Path,
    *,
    extensions: Sequence[str] | None,
    unit_id_regex: str,
) -> dict[str, list[Path]]:
    allowed = normalize_extensions(extensions)
    index: dict[str, list[Path]] = {}
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in allowed:
            continue
        _, unit_id = extract_unit_id(path.name, unit_id_regex)
        index.setdefault(unit_id, []).append(path)
    return index


def run_dataset_preparation(config: dict[str, Any]) -> dict[str, Any]:
    prepare = config.get("prepare", {}) or {}
    csv_path = resolve_path(prepare.get("csv_path"), config=config, must_exist=True)
    output_root = resolve_path(prepare.get("output_root"), config=config)
    if csv_path is None or output_root is None:
        raise ValueError("Set prepare.csv_path and prepare.output_root")
    output_root.mkdir(parents=True, exist_ok=True)
    (output_root / "good").mkdir(exist_ok=True)
    (output_root / "bad").mkdir(exist_ok=True)
    logger = setup_logging(output_root / "prepare_dataset.log")

    frame = pd.read_csv(
        csv_path,
        sep=str(prepare.get("separator", ";")),
        encoding=str(prepare.get("encoding", "utf-8-sig")),
        dtype=str,
        keep_default_na=False,
        engine="python",
    )
    unit_column = resolve_column(frame, str(prepare.get("unit_id_column", "Unit Identifier")))
    label_columns = resolve_columns(
        frame,
        exact_names=prepare.get("label_columns", []),
        regexes=prepare.get("label_column_regexes", []),
    )
    source_columns = resolve_columns(
        frame,
        exact_names=prepare.get("source_columns", []),
        regexes=prepare.get("source_column_regexes", []),
    )
    timestamp_column = None
    if prepare.get("timestamp_column"):
        timestamp_column = resolve_column(frame, str(prepare["timestamp_column"]))

    lookup = _label_lookup(prepare)
    unit_regex = str(prepare.get("unit_id_regex", DEFAULT_UNIT_ID_REGEX))
    replacements = prepare.get("path_replacements", []) or []
    must_contain = [str(value).lower() for value in prepare.get("source_path_must_contain", [])]
    must_not_contain = [
        str(value).lower() for value in prepare.get("source_path_must_not_contain", [])
    ]
    copy_all = bool(prepare.get("copy_all_matching_sources", False))
    overwrite = bool(prepare.get("overwrite", False))

    fallback_root = resolve_path(prepare.get("fallback_search_root"), config=config)
    fallback_index = None
    if fallback_root is not None:
        logger.info("Building fallback image index under %s", fallback_root)
        fallback_index = _build_fallback_index(
            fallback_root,
            extensions=prepare.get("image_extensions", DEFAULT_IMAGE_EXTENSIONS),
            unit_id_regex=unit_regex,
        )

    rows_to_process: list[dict[str, Any]] = []
    skipped_rows: list[dict[str, Any]] = []
    for index, row in frame.iterrows():
        raw_unit = str(row[unit_column]).strip()
        _, unit_id = extract_unit_id(raw_unit, unit_regex)
        label, reason = combine_row_labels(
            row,
            columns=label_columns,
            config=prepare,
            lookup=lookup,
        )
        if label is None:
            skipped_rows.append(
                {"csv_row": index + 2, "unit_id": unit_id, "reason": reason}
            )
            continue
        rows_to_process.append(
            {
                "csv_index": index,
                "csv_row": index + 2,
                "unit_id": unit_id,
                "unit_id_raw": raw_unit,
                "label": int(label),
                "timestamp": str(row[timestamp_column]).strip() if timestamp_column else "",
            }
        )

    rows_frame = pd.DataFrame(rows_to_process)
    duplicate_policy = str(prepare.get("duplicate_policy", "latest")).lower()
    if not rows_frame.empty and rows_frame.duplicated("unit_id", keep=False).any():
        if duplicate_policy == "latest":
            rows_frame = rows_frame.sort_values("timestamp").drop_duplicates("unit_id", keep="last")
        elif duplicate_policy == "first":
            rows_frame = rows_frame.drop_duplicates("unit_id", keep="first")
        elif duplicate_policy == "error":
            duplicates = rows_frame[rows_frame.duplicated("unit_id", keep=False)]["unit_id"].unique()
            raise ValueError(f"Duplicate Unit Identifiers: {duplicates[:20]}")
        else:
            raise ValueError(f"Unsupported duplicate_policy: {duplicate_policy}")

    prepared: list[dict[str, Any]] = []
    missing_images: list[dict[str, Any]] = []
    used_sources: set[str] = set()

    for entry in rows_frame.to_dict(orient="records"):
        row = frame.iloc[int(entry["csv_index"])]
        candidates: list[Path] = []
        for column in source_columns:
            for path_text in _extract_path_candidates(row[column]):
                replaced = _apply_replacements(path_text, replacements)
                candidate = Path(replaced).expanduser()
                if not candidate.is_absolute():
                    candidate = (csv_path.parent / candidate).resolve()
                if candidate.is_file():
                    candidates.append(candidate)

        # Apply task-specific path filters, e.g. require ViBottomPostTarget.
        candidates = [
            path
            for path in candidates
            if all(token in str(path).lower() for token in must_contain)
            and not any(token in str(path).lower() for token in must_not_contain)
        ]

        if not candidates and fallback_index is not None:
            candidates = list(fallback_index.get(str(entry["unit_id"]), []))
            candidates = [
                path
                for path in candidates
                if all(token in str(path).lower() for token in must_contain)
                and not any(token in str(path).lower() for token in must_not_contain)
            ]

        candidates = sorted(set(path.resolve() for path in candidates))
        if not copy_all and candidates:
            candidates = candidates[:1]
        if not candidates:
            missing_images.append(
                {
                    "csv_row": entry["csv_row"],
                    "unit_id": entry["unit_id"],
                    "label": INDEX_TO_LABEL[int(entry["label"])],
                    "reason": "No existing source image matched",
                }
            )
            continue

        for source in candidates:
            source_key = str(source).lower()
            if source_key in used_sources:
                continue
            used_sources.add(source_key)
            label_name = INDEX_TO_LABEL[int(entry["label"])]
            destination_name = f"{entry['unit_id']}__{source.name}"
            destination = output_root / label_name / destination_name
            if destination.exists() and not overwrite:
                counter = 2
                while destination.exists():
                    destination = output_root / label_name / (
                        f"{entry['unit_id']}__{source.stem}__{counter}{source.suffix}"
                    )
                    counter += 1
            shutil.copy2(source, destination)
            prepared.append(
                {
                    "unit_id": entry["unit_id"],
                    "unit_id_raw": entry["unit_id_raw"],
                    "label": int(entry["label"]),
                    "label_name": label_name,
                    "source_path": str(source),
                    "prepared_path": str(destination),
                    "csv_row": entry["csv_row"],
                }
            )

    prepared_frame = pd.DataFrame(prepared)
    missing_frame = pd.DataFrame(missing_images)
    skipped_frame = pd.DataFrame(skipped_rows)
    prepared_frame.to_csv(output_root / "prepared_manifest.csv", index=False, encoding="utf-8")
    missing_frame.to_csv(output_root / "missing_images.csv", index=False, encoding="utf-8")
    skipped_frame.to_csv(output_root / "skipped_labels.csv", index=False, encoding="utf-8")

    summary = {
        "csv_path": str(csv_path),
        "output_root": str(output_root),
        "label_columns": label_columns,
        "source_columns": source_columns,
        "prepared_images": int(len(prepared_frame)),
        "prepared_good": int((prepared_frame.get("label", pd.Series(dtype=int)) == 0).sum()),
        "prepared_bad": int((prepared_frame.get("label", pd.Series(dtype=int)) == 1).sum()),
        "missing_images": int(len(missing_frame)),
        "skipped_label_rows": int(len(skipped_frame)),
    }
    write_json(summary, output_root / "prepare_summary.json")
    logger.info("Prepared %d images under %s", len(prepared_frame), output_root)
    return summary
