from __future__ import annotations

from typing import Sequence

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F


def automatic_class_weights(
    labels: Sequence[int],
    *,
    bad_multiplier: float = 1.0,
    power: float = 1.0,
    maximum_ratio: float | None = 10.0,
    normalize_mean_to_one: bool = True,
) -> torch.Tensor:
    labels_array = np.asarray(labels, dtype=np.int64)
    counts = np.bincount(labels_array, minlength=2).astype(np.float64)
    if np.any(counts == 0):
        raise ValueError(f"Cannot compute class weights with class counts {counts.tolist()}")

    total = float(counts.sum())
    weights = (total / (2.0 * counts)) ** float(power)
    weights[1] *= float(bad_multiplier)

    if maximum_ratio is not None and maximum_ratio > 0:
        smallest = max(float(weights.min()), 1e-12)
        largest_allowed = smallest * float(maximum_ratio)
        weights = np.minimum(weights, largest_allowed)

    if normalize_mean_to_one:
        weights = weights / weights.mean()
    return torch.tensor(weights, dtype=torch.float32)


class FocalLoss(nn.Module):
    def __init__(
        self,
        *,
        gamma: float = 2.0,
        class_weights: torch.Tensor | None = None,
        label_smoothing: float = 0.0,
    ) -> None:
        super().__init__()
        self.gamma = float(gamma)
        self.register_buffer("class_weights", class_weights)
        self.label_smoothing = float(label_smoothing)

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        cross_entropy = F.cross_entropy(
            logits,
            targets,
            weight=self.class_weights,
            reduction="none",
            label_smoothing=self.label_smoothing,
        )
        probabilities = torch.softmax(logits, dim=1)
        target_probability = probabilities.gather(1, targets.unsqueeze(1)).squeeze(1)
        modulation = (1.0 - target_probability).pow(self.gamma)
        return (modulation * cross_entropy).mean()


def build_loss(
    config: dict,
    *,
    train_labels: Sequence[int],
    device: torch.device,
) -> tuple[nn.Module, dict[str, float]]:
    loss_type = str(config.get("type", "weighted_cross_entropy")).lower()
    weights_config = config.get("class_weights", {}) or {}

    class_weights = None
    if bool(weights_config.get("enabled", True)):
        class_weights = automatic_class_weights(
            train_labels,
            bad_multiplier=float(weights_config.get("bad_multiplier", 1.0)),
            power=float(weights_config.get("power", 1.0)),
            maximum_ratio=(
                None
                if weights_config.get("maximum_ratio", 10.0) is None
                else float(weights_config.get("maximum_ratio", 10.0))
            ),
            normalize_mean_to_one=bool(weights_config.get("normalize_mean_to_one", True)),
        ).to(device)

    label_smoothing = float(config.get("label_smoothing", 0.0))
    if loss_type in {"cross_entropy", "weighted_cross_entropy"}:
        criterion: nn.Module = nn.CrossEntropyLoss(
            weight=class_weights,
            label_smoothing=label_smoothing,
        )
    elif loss_type == "focal":
        criterion = FocalLoss(
            gamma=float(config.get("focal_gamma", 2.0)),
            class_weights=class_weights,
            label_smoothing=label_smoothing,
        )
    else:
        raise ValueError(f"Unsupported loss.type: {loss_type}")

    weight_summary = {
        "good": float(class_weights[0].item()) if class_weights is not None else 1.0,
        "bad": float(class_weights[1].item()) if class_weights is not None else 1.0,
    }
    return criterion, weight_summary
