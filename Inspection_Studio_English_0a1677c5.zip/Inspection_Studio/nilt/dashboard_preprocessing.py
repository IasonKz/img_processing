"""Labelled and untagged image preparation using managed local workers."""
from pathlib import Path
import sys


PREPROCESS_ACTIONS = {"preprocess", "preprocess-check"}


class PreprocessingDashboardMixin:
    @staticmethod
    def preprocessing_mode(job):
        command = job.get("command", [])
        if not isinstance(command, list):
            return None
        if "--mode" in command:
            index = command.index("--mode") + 1
            return command[index] if index < len(command) else None
        return "labelled"

    def preprocessing_recorded_output(self, job):
        """Only register the output of a recorded, fixed-entry-point worker."""
        from .dashboard import PROJECT
        command = job.get("command")
        if not isinstance(command, list) or len(command) < 4 or not all(isinstance(x, str) for x in command):
            return None
        try:
            if Path(command[2]).resolve() != PROJECT / "inspection.py" or command[3] != "preprocess":
                return None
            output = Path(command[command.index("--output") + 1]).resolve()
            if output != Path(job.get("preprocessing_output", "")).resolve():
                return None
            for flag, suffix in (("--report", ".preprocessing.json"), ("--stop-file", ".stop")):
                if Path(command[command.index(flag) + 1]).resolve() != (self.logs_root / (job["id"] + suffix)).resolve():
                    return None
            return output
        except (KeyError, IndexError, TypeError, ValueError, OSError):
            return None

    def preprocessing_command(self, action, data, project):
        if action not in PREPROCESS_ACTIONS:
            return None
        mode = data.get("mode", "labelled")
        if mode not in ("labelled", "untagged"):
            raise ValueError("Preparation mode must be labelled or untagged.")
        resolved = []
        if mode == "labelled":
            files = data.get("csv_files")
            if not isinstance(files, list) or not 1 <= len(files) <= 64:
                raise ValueError("Enter one CSV file path per line (maximum 64).")
            for value in files:
                if not isinstance(value, str) or not value.strip():
                    raise ValueError("CSV paths must be nonempty strings.")
                path = self._configured_path(value.strip())
                if not path.is_file() or path.suffix.lower() != ".csv":
                    raise ValueError(f"CSV file does not exist: {path}")
                if path not in resolved:
                    resolved.append(path)
        output_value = data.get("output")
        if not isinstance(output_value, str) or not output_value.strip():
            raise ValueError("Choose a new or empty output folder.")
        output = self._configured_path(output_value.strip())
        if any(path.is_relative_to(output) for path in resolved):
            raise ValueError("Input CSV files must be outside the output folder.")
        if action == "preprocess" and output.exists() and (not output.is_dir() or any(output.iterdir())):
            raise ValueError("Choose a NEW or EMPTY output folder; existing datasets are retained.")
        command = [sys.executable, "-u", str(project / "inspection.py"), "preprocess",
                   "--mode", mode, "--output", str(output)]
        if resolved:
            command += ["--csv", *map(str, resolved)]
        tray = data.get("tray", "")
        if not isinstance(tray, str):
            raise ValueError("Tray path must be a string.")
        if mode == "untagged" and not tray.strip():
            raise ValueError("Choose the original tester folder for untagged preparation.")
        if tray.strip():
            root = self._configured_path(tray.strip())
            if not root.is_dir():
                raise ValueError("The tray folder does not exist.")
            if root.is_relative_to(output):
                raise ValueError("The tray must be outside the output folder.")
            command += ["--tray", str(root)]
        if mode == "untagged":
            from .untagged_preparation import compile_patterns, validate_output
            stage = data.get("stage", "final")
            if stage not in ("all", "final", "start"):
                raise ValueError("Capture stage must be all, final or start.")
            command += ["--stage", stage]
            overrides = {}
            for task in ("vig", "top", "bottom"):
                pattern = data.get(task + "_pattern", "")
                if not isinstance(pattern, str):
                    raise ValueError("Capture patterns must be strings.")
                if pattern.strip():
                    overrides[task] = pattern.strip()
                    command += ["--" + task + "-pattern", pattern.strip()]
            compile_patterns(overrides)
            validate_output(root, output, data.get("debug", True), require_empty=action == "preprocess")
        depth = data.get("output_depth", "native")
        if depth not in ("native", "8"):
            raise ValueError("Output depth must be native or 8.")
        command += ["--output-depth", depth]
        for field, default in (("vig_brightness", True), ("debug", True)):
            if not isinstance(data.get(field, default), bool):
                raise ValueError(f"{field} must be a boolean.")
        if not data.get("vig_brightness", True):
            command.append("--no-vig-brightness")
        if data.get("debug", True):
            command.append("--debug")
        white = data.get("white_level")
        if white is not None:
            if isinstance(white, bool) or not isinstance(white, int) or not 1 <= white <= 65535:
                raise ValueError("Sensor white level must be an integer from 1 to 65535, or blank.")
            command += ["--white-level", str(white)]
        if action == "preprocess-check":
            command.append("--dry-run")
        return command

    def preprocessing_state(self):
        from .dashboard import _read_json
        with self.lock:
            jobs = []
            for job in self.jobs:
                if job.get("action") not in PREPROCESS_ACTIONS:
                    continue
                report = _read_json(self.logs_root / (job["id"] + ".preprocessing.json"), {})
                if not isinstance(report, dict):
                    report = {}
                jobs.append({key: job.get(key) for key in
                             ("id", "action", "status", "started", "exit_code", "preprocessing_output", "stop_requested")}
                            | {"mode": self.preprocessing_mode(job), "report": report,
                               "lines": job.get("lines", [])[-12:]})
            return {"jobs": jobs[-20:]}

    def _preprocessing_job(self, value):
        job = next((j for j in self.jobs if j.get("id") == value and j.get("action") in PREPROCESS_ACTIONS), None)
        if job is None:
            raise ValueError("Choose a recorded preprocessing operation.")
        return job

    def preprocessing_cancel(self, data):
        with self.lock:
            self._refresh_recovered_jobs()
            job = self._preprocessing_job(data.get("job"))
            if job.get("status") != "running":
                raise ValueError("This preprocessing operation is not running.")
            (self.logs_root / (job["id"] + ".stop")).touch(exist_ok=True)
            job["stop_requested"] = True
            self._persist_job(job)
            return {"message": "Stop requested. The current image will finish; partial output is retained for review."}

    def _preprocessing_completed(self, data):
        from .dashboard import _read_json
        self._refresh_recovered_jobs()
        job = self._preprocessing_job(data.get("job"))
        report = _read_json(self.logs_root / (job["id"] + ".preprocessing.json"), {})
        if (job["action"] != "preprocess" or job.get("status") not in ("finished", "ended")
                or not isinstance(report, dict) or report.get("dry_run") or not report.get("complete")):
            raise ValueError("Prepare a complete dataset first. Input checks and incomplete output cannot be used automatically.")
        output = self.preprocessing_recorded_output(job)
        if output is None:
            raise ValueError("The recorded preparation worker/output could not be verified.")
        if report.get("output") != str(output):
            raise ValueError("Preparation output does not match its recorded operation.")
        mode = self.preprocessing_mode(job)
        if report.get("dataset_kind", "labelled") != mode:
            raise ValueError("Preparation mode does not match its recorded operation.")
        return mode, report, output

    def preprocessing_use_classification(self, data):
        with self.lock:
            mode, report, output = self._preprocessing_completed(data)
            if mode != "untagged" or report.get("labels_present") is not False:
                raise ValueError("Choose an untagged preparation for classification handoff.")
            task = data.get("task", "vig")
            if task not in ("vig", "top", "bottom") or not report.get("counts", {}).get(task):
                raise ValueError("The selected task has no prepared images.")
            source = output / task
            if not source.is_dir():
                raise ValueError("The prepared image folder is no longer available.")
            return {"task": task, "input": str(source), "labeled": False, "roi_scope": "whole_image"}

    def preprocessing_use_dataset(self, data):
        with self.lock:
            mode, report, output = self._preprocessing_completed(data)
            if mode != "labelled":
                raise ValueError("Untagged captures have no training labels. Use them for classification instead.")
            datasets = {task: str(output / task) for task in ("vig", "top", "bottom")
                        if sum(report.get("counts", {}).get(f"{task}/{label}", 0) for label in ("good", "bad")) > 0
                        and all((output / task / label).is_dir() for label in ("good", "bad"))}
            task = data.get("task", "vig")
            if task not in datasets:
                raise ValueError("The selected task has no prepared images.")
            return self.save_config({"task": task, "roi_scope": "whole_image", "dataset": datasets[task]}, prepared_tasks=datasets)
