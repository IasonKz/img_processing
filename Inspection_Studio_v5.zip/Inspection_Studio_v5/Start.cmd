@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\start_windows.ps1" %*
set "STUDIO_EXIT=%ERRORLEVEL%"
echo.
if not "%STUDIO_EXIT%"=="0" echo Dashboard did not start or exited with an error. Read the message above.
pause
exit /b %STUDIO_EXIT%
