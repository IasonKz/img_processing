# Ξεκίνα εδώ — Visual Inspection v3

Αυτό είναι **ολόκληρο το ενοποιημένο project**, όχι patch. Κράτησε το παλιό v2 σε
ξεχωριστό φάκελο και αποσυμπίεσε το v3 σε νέο φάκελο. Δεν χρειάζεται να αντιγράψεις
τα προηγούμενα add-ons πάνω του.

## 1. Εγκατάσταση μία φορά σε κάθε υπολογιστή

Χρησιμοποίησε Windows 11 και Python 3.11 ή 3.12. Μην μεταφέρεις το παλιό `.venv`
ή `.venv_vig`. Στο PowerShell, μπες στον φάκελο όπου υπάρχει το `inspection.py`:

```powershell
cd "C:\YOUR_PATH\visual_inspection_pipeline_v3"
```

Αντικατάστησε το `C:\YOUR_PATH\visual_inspection_pipeline_v3` με τον πραγματικό
φάκελο. Στο laptop εκτέλεσε:

```powershell
powershell -NoProfile -File .\scripts\setup_windows.ps1 -Device cpu
```

Στο workstation με NVIDIA GPU:

```powershell
powershell -NoProfile -File .\scripts\setup_windows.ps1 -Device cuda
```

Το setup χρειάζεται internet μόνο για τα δημόσια Python packages. Αν η εταιρική
πολιτική δεν επιτρέπει εκτέλεση PowerShell scripts, χρησιμοποίησε τις μεμονωμένες
εντολές στο [INSTALLATION.md](docs/INSTALLATION.md)· δεν χρειάζεται αλλαγή πολιτικής.
Για εγκατεστημένη Python 3.12 πρόσθεσε `-PythonVersion 3.12`.

Προαιρετικά, πριν βάλεις εταιρικά δεδομένα, έλεγξε την εγκατάσταση με συνθετικές
εικόνες και πραγματική μικρή εκπαίδευση:

```powershell
.\.venv\Scripts\python.exe scripts/smoke_v3.py --output ..\smoke_check
```

Ο φάκελος `smoke_check` πρέπει να είναι νέος ή κενός. Το αποτέλεσμα αυτής της
δοκιμής ελέγχει το λογισμικό, όχι την απόδοση στα δικά σου defects. Αφού κατεβάσεις
τα weights, μπορείς να προσθέσεις `--weights .\weights`. Με εγκατεστημένα export
dependencies, το `--with-onnx` ελέγχει και ONNX.

## 2. Βάλε το path των εικόνων

Άνοιξε το `project.yaml`. Άλλαξε **μόνο** την τιμή `tasks.vig.dataset_root`:

```yaml
tasks:
  vig:
    dataset_root: 'C:/YOUR_DATA/vig'
```

Το παράδειγμα δείχνει ποιο πεδίο αλλάζεις — μην αντικαταστήσεις ολόκληρο το task
και χάσεις τις υπόλοιπες ρυθμίσεις. Μέσα στο `C:/YOUR_DATA/vig` πρέπει να υπάρχουν
οι φάκελοι `good` και `bad`. Μπορούν να περιέχουν υποφακέλους ανά tray.

Οι εικόνες παραμένουν στην αρχική τους θέση. Μην βάλεις `results`, `classified`
ή αντίγραφα augmentation μέσα στο dataset.

## 3. Δημόσια pretrained weights — μία φορά

Με internet, κατέβασε τα weights για το profile που θα χρησιμοποιήσεις:

```powershell
.\.venv\Scripts\python.exe inspection.py download-weights --config project.yaml --profile laptop --task vig
```

Άλλαξε το `laptop` σε `workstation` ή `workstation_large` για εκείνο το μηχάνημα.
Αντέγραψε τον φάκελο `weights` για offline χρήση· δεν ανεβαίνουν εικόνες.

## 4. Άνοιξε το γραφικό περιβάλλον

```powershell
.\.venv\Scripts\python.exe inspection.py doctor --config project.yaml --profile laptop --task vig
.\.venv\Scripts\python.exe inspection.py dashboard --config project.yaml
```

Στο workstation άλλαξε το profile της πρώτης εντολής. Άνοιξε στον browser την
τοπική διεύθυνση που τυπώνει η δεύτερη. Το παράθυρο του terminal μένει ανοιχτό.
Το dashboard και οι εικόνες λειτουργούν τοπικά.

## 5. Ή ξεκίνα απευθείας αναζήτηση από το PowerShell

Διάλεξε **μία** από τις παρακάτω εντολές:

```powershell
# Laptop: συνολικό όριο 2 ώρες
.\.venv\Scripts\python.exe inspection.py search --config project.yaml --profile laptop --task vig

# Workstation: συνολικό όριο 6 ώρες
.\.venv\Scripts\python.exe inspection.py search --config project.yaml --profile workstation --task vig

# Μεγάλο workstation: συνολικό όριο 12 ώρες
.\.venv\Scripts\python.exe inspection.py search --config project.yaml --profile workstation_large --task vig
```

Για πρώτη σύντομη δοκιμή, πρόσθεσε `--hours 0.1 --models resnet18`. Τα έξι λεπτά
ελέγχουν την εκκίνηση και τα δεδομένα· μπορεί να μην αρκούν για ολοκληρωμένο μοντέλο.
Το κανονικό search παράγει νέο φάκελο στο `results/vig/` και εμφανίζει το ακριβές path.

Η λήξη του χρόνου μπορεί να αφήσει έτοιμα checkpoints αλλά εκκρεμή αξιολόγηση.
Τότε μπορείς να ζητήσεις χωριστά έως μισή ώρα για ολοκλήρωση της σύγκρισης:

```powershell
.\.venv\Scripts\python.exe inspection.py finalize-search --run "C:\PATH\TO\RUN" --hours 0.5
```

Αυτός ο επιπλέον χρόνος είναι ξεχωριστή ενέργεια που επιλέγεις εσύ.
Αν συνεχίσεις το ίδιο search μετά από διακοπή, παραμένει μόνο ο χρόνος που είχε
απομείνει· δεν ξεκινούν αυτόματα άλλες 2, 6 ή 12 ώρες.

## Τι σημαίνει το αποτέλεσμα

- `bad escape`: ελαττωματικά που περνούν ως good.
- `good reject`: καλά που απορρίπτονται ως bad.
- `TARGET_NOT_MET`: το μοντέλο δεν πέτυχε τους δηλωμένους στόχους.
- Χαμηλότερο threshold απορρίπτει περισσότερες εικόνες.
- Η αλλαγή threshold δεν εκπαιδεύει ξανά το μοντέλο.
- `argmax`: απλή ταξινόμηση από τον classifier, αντίστοιχη με όριο 0.5 για τις
  δύο softmax εξόδους. Δεν εφαρμόζεται σε raw anomaly scores του PatchCore.
- `scores_only`: αριθμοί χωρίς απόφαση good/bad.

Μην αλλάζεις χειροκίνητα το `selected.json` ή παλιά reports. Η νέα απόφαση
αποθηκεύεται χωριστά. Αναλυτικές εντολές και εξηγήσεις:
[V3_GUIDE.md](docs/V3_GUIDE.md).
