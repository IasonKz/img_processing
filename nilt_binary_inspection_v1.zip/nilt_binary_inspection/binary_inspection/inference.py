from __future__ import annotations

import html
import json
from pathlib import Path
import shutil
from datetime import datetime, timezone

import numpy as np
from PIL import Image

from .common import (LOG, choose_device, file_sha256, object_hash, output_dir, read_csv, read_json,
                     write_csv, write_json)
from .images import load_image, input_hash, image_qc
from .metrics import classification_metrics, reliability_bins
from .patchcore import score_patchcore
from .selector import combine, decide
from .splitting import read_manifest, verify_manifest
from .training import score_checkpoint


def load_selector(cfg: dict) -> dict:
    folder = output_dir(cfg)
    selector = read_json(folder / "selector.json")
    if selector["task"] != cfg["project"]["task"]:
        raise ValueError("Wrong inspection task: TOP, BOTTOM and VIG require separately trained selectors")
    if selector["class_map"] != {"good": 0, "bad": 1}:
        raise ValueError("Invalid class mapping in selector")
    for artifact in list(selector["models"].values()) + ([selector["anomaly"]] if selector["anomaly"] else []):
        path = (folder / artifact["path"]).resolve()
        if folder.resolve() not in path.parents:
            raise ValueError("Checkpoint path escapes run directory")
        if not path.is_file() or file_sha256(path) != artifact["sha256"]:
            raise ValueError(f"Selected checkpoint is missing or modified: {path}")
    return selector


def infer_rows(cfg: dict, rows: list[dict], selector: dict) -> list[dict]:
    if not rows:
        return []
    folder, device = output_dir(cfg), choose_device(cfg)
    scores = {}
    for name, artifact in selector["models"].items():
        LOG.info("Inference: %s (%s images)", name, len(rows))
        predictions, metadata = score_checkpoint(folder / artifact["path"], rows, cfg, device)
        if metadata["task"] != selector["task"] or metadata["dataset_signature"] != selector["dataset_signature"]:
            raise ValueError("Selector/checkpoint provenance mismatch")
        scores[name] = np.array([predictions[r["sample_id"]] for r in rows])
    anomaly = None
    if selector["anomaly"]:
        LOG.info("Inference: PatchCore veto (%s images)", len(rows))
        anomaly_dict = score_patchcore(folder / selector["anomaly"]["path"], rows, cfg, device)
        anomaly = np.array([anomaly_dict[r["sample_id"]] for r in rows])
    combined, members = combine(selector["chosen"], scores, selector["calibrators"])
    decisions, reasons = decide(combined, members, selector["chosen"]["policy"], anomaly)
    result = []
    for i, row in enumerate(rows):
        result.append({**row, "task": selector["task"], "bad_score": float(combined[i]),
                       **{f"{m}_bad_score": float(members[i, j]) for j, m in enumerate(selector["chosen"]["members"])},
                       "model_disagreement": float(members[i].max() - members[i].min()),
                       "anomaly_score": float(anomaly[i]) if anomaly is not None else None,
                       "decision": str(decisions[i]), "reason": reasons[i],
                       "selected_candidate": selector["chosen"]["name"], "release_authorized": False})
    return result


def report_gallery(folder: Path, rows: list[dict], data_cfg: dict, title: str, maximum: int = 100) -> None:
    assets = folder / "review_thumbnails"
    assets.mkdir(parents=True, exist_ok=True)
    candidates = sorted(rows, key=lambda r: (0 if int(r.get("label", -1)) == 1 and r["decision"] == "PASS" else
                                             1 if r["decision"] == "REVIEW" else 2))[:maximum]
    cards = []
    for index, row in enumerate(candidates):
        image_markup = "<p>Unreadable image</p>"
        try:
            image, _ = load_image(row["path"], data_cfg)
            image.thumbnail((240, 240), Image.Resampling.BILINEAR)
            name = f"image_{index:04d}.jpg"
            image.save(assets / name, quality=90)
            image_markup = f'<img src="review_thumbnails/{name}" alt="Inspection image">'
        except Exception:
            pass
        score = row.get("bad_score")
        score_text = f"{score:.5f}" if isinstance(score, (int, float)) else "unavailable"
        cards.append(f'<article>{image_markup}<h3>{html.escape(str(row["decision"]))}</h3>'
                     f'<p>{html.escape(str(row.get("relpath", Path(row["path"]).name)))}</p>'
                     f'<p>BAD score: {score_text}; true label: {html.escape(str(row.get("label", "unknown")))}</p>'
                     f'<p>{html.escape(str(row["reason"]))}</p></article>')
    content = f'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>{html.escape(title)}</title><style>body{{font:16px system-ui; margin:2rem;}}main{{display:flex;flex-wrap:wrap;gap:1rem;}}
article{{border:1px solid #bbb;padding:1rem;width:260px;overflow-wrap:anywhere;}}img{{max-width:240px;max-height:240px;}}</style>
<h1>{html.escape(title)}</h1><p>Local report. Labels: GOOD=0, BAD=1, unknown=-1. At most {maximum} images; full results are in CSV.
No automatic production release is authorized.</p><main>{''.join(cards)}</main></html>'''
    (folder / "review.html").write_text(content, encoding="utf-8")


def evaluate(cfg: dict) -> dict:
    verify_manifest(cfg)
    selector = load_selector(cfg)
    folder = output_dir(cfg) / "evaluation"
    folder.mkdir(parents=True, exist_ok=True)
    selector_sha = file_sha256(output_dir(cfg) / "selector.json")
    report_path = folder / "test_report.json"
    if report_path.exists():
        old = read_json(report_path)
        if old["selector_sha256"] != selector_sha:
            raise ValueError("Selector changed after test evaluation. This is no longer an untouched test")
        LOG.warning("Reusing existing test report. Repeated inspection does not produce independent evidence")
        return old
    rows = [r for r in read_manifest(cfg) if r["split"] == "test"]
    predictions = infer_rows(cfg, rows, selector)
    labels = [r["label"] for r in predictions]
    scores = [r["bad_score"] for r in predictions]
    decisions = [r["decision"] for r in predictions]
    settings = selector["chosen"]["policy"]["settings"]
    metrics = classification_metrics(labels, scores, decisions, [r["group_id"] for r in predictions], settings["confidence_level"])
    target = float(settings["max_bad_escape_rate"])
    bound = metrics["bad_escape_upper_bound_iid"]
    report = {"task": selector["task"], "selector_sha256": selector_sha, "candidate": selector["chosen"]["name"],
              "metrics": metrics, "target_bad_escape_rate": target,
              "observed_target_met": metrics["bad_escape_rate"] is not None and metrics["bad_escape_rate"] <= target,
              "iid_image_upper_bound_below_target": bound is not None and bound <= target,
              "grouping": selector["grouping"], "audit_warnings": selector["audit_warnings"],
              "release_authorized": False, "evaluated_utc": datetime.now(timezone.utc).isoformat(),
              "important": "These are per-image results. REVIEW is not a correct automatic classification. Confidence bounds require representative independent sampling; zero observed escapes is not proof of zero future escapes"}
    write_csv(folder / "test_predictions.csv", predictions)
    write_csv(folder / "test_reliability_bins.csv", reliability_bins(labels, scores))
    for name, subset in (("bad_escaped_as_pass", [r for r in predictions if r["label"] == 1 and r["decision"] == "PASS"]),
                         ("good_false_failed", [r for r in predictions if r["label"] == 0 and r["decision"] == "FAIL"]),
                         ("review_queue", [r for r in predictions if r["decision"] == "REVIEW"])):
        write_csv(folder / f"{name}.csv", subset, list(predictions[0]) if predictions else [])
    per_tray = []
    for tray in sorted({r.get("tray_id", "") for r in predictions}):
        if not tray:
            continue
        subset = [r for r in predictions if r.get("tray_id") == tray]
        stats = classification_metrics([r["label"] for r in subset], [r["bad_score"] for r in subset],
                                       [r["decision"] for r in subset], confidence=settings["confidence_level"])
        per_tray.append({"tray_id": tray, **stats})
    write_csv(folder / "per_tray_metrics.csv", per_tray)
    write_json(report_path, report)
    report_gallery(folder, predictions, selector["input_data_cfg"], "Held-out test: binary inspection")
    LOG.info("TEST: BAD escapes %s/%s | GOOD false FAIL %s/%s | review %.3f", metrics["bad_pass"], metrics["bad"],
             metrics["good_fail"], metrics["good"], metrics["review_rate"])
    return report


def collect_prediction_rows(input_path: Path, cfg: dict, selector: dict) -> tuple[list[dict], list[dict]]:
    if not input_path.exists():
        raise ValueError(f"Input not found: {input_path}")
    files = [input_path] if input_path.is_file() else sorted(p for p in input_path.rglob("*") if p.is_file())
    ext = {s.lower() for s in selector["input_data_cfg"]["extensions"]}
    files = [p for p in files if p.suffix.lower() in ext]
    if not files:
        raise ValueError("No supported images in input folder")
    valid, invalid = [], []
    for i, path in enumerate(files):
        rel = path.name if input_path.is_file() else path.relative_to(input_path).as_posix()
        label = -1
        if not input_path.is_file():
            first = rel.split("/")[0]
            if first == selector["input_data_cfg"]["good_folder"]:
                label = 0
            elif first == selector["input_data_cfg"]["bad_folder"]:
                label = 1
        row = {"sample_id": f"prediction_{i:07d}", "path": str(path.resolve()), "relpath": rel, "label": label}
        try:
            if path.is_symlink():
                raise ValueError("Symlink inputs are not allowed")
            image, native = load_image(path, selector["input_data_cfg"])
            qc, issues = image_qc(image, selector["input_data_cfg"].get("qc", {}))
            if issues:
                raise ValueError("QC: " + ";".join(issues))
            valid.append({**row, "input_sha256": input_hash(image), "pixel_sha256": native, **qc})
        except Exception as exc:
            invalid.append({**row, "task": selector["task"], "bad_score": None, "decision": "REVIEW",
                            "reason": f"INVALID_IMAGE: {type(exc).__name__}: {exc}", "release_authorized": False})
    return valid, invalid


def predict_folder(cfg: dict, input_path: Path, destination: Path | None = None) -> dict:
    selector = load_selector(cfg)
    if destination is None:
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
        destination = output_dir(cfg) / "predictions" / timestamp
    destination = destination.resolve()
    if destination.exists() and any(destination.iterdir()):
        raise ValueError("Prediction output must be a new/empty directory; no silent overwrite")
    if input_path.is_dir() and (destination == input_path.resolve() or input_path.resolve() in destination.parents):
        raise ValueError("Prediction output must be outside its input folder")
    destination.mkdir(parents=True, exist_ok=True)
    valid, invalid = collect_prediction_rows(input_path, cfg, selector)
    failure = None
    try:
        predictions = infer_rows(cfg, valid, selector)
    except Exception as exc:
        # Preserve a complete REVIEW-only report instead of emitting partial PASSes.
        failure = f"{type(exc).__name__}: {exc}"
        LOG.exception("Inference failed; all affected images are REVIEW")
        predictions = [{**r, "task": selector["task"], "bad_score": None, "decision": "REVIEW",
                        "reason": "MODEL_FAILURE: " + failure, "release_authorized": False} for r in valid]
    manifest_path = output_dir(cfg) / "manifest.csv"
    if cfg["prediction"]["compare_training_hashes"] and manifest_path.exists():
        old = read_csv(manifest_path)
        seen = {r["input_sha256"] for r in old if r["split"] != "test"}
        for row in predictions:
            row["seen_in_development"] = row["input_sha256"] in seen
            if row["seen_in_development"] and cfg["prediction"]["mask_seen_images_from_pass"] and row["decision"] == "PASS":
                row["decision"] = "REVIEW"
                row["reason"] = "SEEN_IN_DEVELOPMENT_NOT_INDEPENDENT"
    predictions.extend(invalid)
    predictions.sort(key=lambda r: r["sample_id"])
    write_csv(destination / "predictions.csv", predictions)
    summary = {"images": len(predictions), "task": selector["task"], "selector": selector["chosen"]["name"],
               "counts": {d: sum(r["decision"] == d for r in predictions) for d in ("PASS", "REVIEW", "FAIL")},
               "model_failure": failure, "output_dir": str(destination), "release_authorized": False,
               "mode": "SHADOW_PROPOSALS_ONLY", "selector_sha256": file_sha256(output_dir(cfg) / "selector.json")}
    labeled = [r for r in predictions if r["label"] in (0, 1)]
    if labeled:
        summary["labeled_subset_metrics"] = classification_metrics([r["label"] for r in labeled],
                              [np.nan if r.get("bad_score") is None else r["bad_score"] for r in labeled],
                              [r["decision"] for r in labeled])
        summary["evaluation_warning"] = "Folder labels are used only for reporting. Known development images are flagged. This is not the locked final TEST evaluation"
    if cfg["prediction"]["copy_images"]:
        for row in predictions:
            target = destination / "sorted" / row["decision"] / f"{row['sample_id']}__{Path(row['path']).name}"
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(row["path"], target)
    write_json(destination / "summary.json", summary)
    report_gallery(destination, predictions, selector["input_data_cfg"], "Binary inspection predictions")
    LOG.info("Predictions saved to %s: %s", destination, summary["counts"])
    return summary
