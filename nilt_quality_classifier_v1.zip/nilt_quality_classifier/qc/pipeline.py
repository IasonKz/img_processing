from __future__ import annotations

import copy
import logging
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import pandas as pd
import torch

from .config import clean_for_serialization, get, resolve_path, save_yaml
from .data import (
    DEFAULT_UNIT_ID_REGEX,
    ImageRecord,
    build_labeled_loader,
    build_transforms,
    class_counts,
    load_manifest,
    save_manifest,
    scan_labeled_root,
    split_counts,
    stratified_group_split,
)
from .engine import fit_model, predict_labeled
from .losses import build_loss
from .metrics import (
    binary_metrics,
    choose_safety_threshold,
    markdown_metrics,
    predictions_frame,
    save_evaluation_bundle,
    save_training_history,
    threshold_sweep,
)
from .models import count_parameters, create_model, load_torch_checkpoint, model_from_checkpoint
from .utils import (
    choose_device,
    device_summary,
    env_info,
    make_run_dir,
    seed_everything,
    setup_logging,
    write_json,
)


def _cpu_state_dict(state_dict: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
    return {name: tensor.detach().cpu() for name, tensor in state_dict.items()}


def _resolve_output_root(config: dict[str, Any]) -> Path:
    output_value = get(config, "project.output_root", "runs")
    resolved = resolve_path(output_value, config=config)
    assert resolved is not None
    return resolved


def _records_from_config(config: dict[str, Any], logger: logging.Logger) -> tuple[list[ImageRecord], Path | None]:
    manifest_value = get(config, "data.manifest_path")
    if manifest_value:
        manifest_path = resolve_path(manifest_value, config=config, must_exist=True)
        assert manifest_path is not None
        logger.info("Loading fixed split manifest: %s", manifest_path)
        return load_manifest(manifest_path), None

    root = resolve_path(get(config, "data.root"), config=config, must_exist=True)
    if root is None:
        raise ValueError("Set data.root or data.manifest_path in the training configuration")
    records = scan_labeled_root(
        root,
        source=str(get(config, "data.source_name", root.name)),
        recursive=bool(get(config, "data.recursive", True)),
        extensions=get(config, "data.image_extensions"),
        unit_id_regex=str(get(config, "data.unit_id_regex", DEFAULT_UNIT_ID_REGEX)),
    )
    split_config = config.get("split", {}) or {}
    records = stratified_group_split(
        records,
        validation_fraction=float(split_config.get("validation_fraction", 0.15)),
        test_fraction=float(split_config.get("test_fraction", 0.15)),
        seed=int(split_config.get("seed", get(config, "project.seed", 42))),
        fixed_validation_substrings=split_config.get("fixed_validation_substrings", []),
        fixed_test_substrings=split_config.get("fixed_test_substrings", []),
    )
    return records, root


def _ensure_nonempty_splits(records: Sequence[ImageRecord]) -> None:
    train = [record for record in records if record.split == "train"]
    validation = [record for record in records if record.split == "validation"]
    if not train:
        raise ValueError("Training split is empty")
    if not validation:
        raise ValueError(
            "Validation split is empty. Increase the dataset size or set split.validation_fraction > 0."
        )


def _model_and_metadata(
    config: dict[str, Any],
    *,
    device: torch.device,
    initial_checkpoint: str | Path | None,
) -> tuple[torch.nn.Module, str, float, dict[str, Any] | None]:
    model_config = config.get("model", {}) or {}
    if initial_checkpoint is not None:
        model, checkpoint = model_from_checkpoint(initial_checkpoint, device=device)
        architecture = str(checkpoint["architecture"])
        dropout = float(checkpoint.get("dropout", 0.0))
        requested_architecture = model_config.get("architecture")
        if requested_architecture and str(requested_architecture).lower() not in {
            architecture.lower(),
            "from_checkpoint",
        }:
            raise ValueError(
                f"Config requests {requested_architecture}, but checkpoint is {architecture}"
            )
        return model, architecture, dropout, checkpoint

    architecture = str(model_config.get("architecture", "resnet18")).lower()
    dropout = float(model_config.get("dropout", 0.0))
    model = create_model(
        architecture,
        pretrained=bool(model_config.get("pretrained", True)),
        num_classes=2,
        dropout=dropout,
    ).to(device)
    return model, architecture, dropout, None


def _save_checkpoint(
    path: Path,
    *,
    state: dict[str, Any],
    architecture: str,
    dropout: float,
    config: dict[str, Any],
    data_config: dict[str, Any],
    class_weights: dict[str, float],
    mode: str,
    base_checkpoint: str | Path | None,
) -> None:
    checkpoint = {
        "format_version": 1,
        "mode": mode,
        "architecture": architecture,
        "dropout": dropout,
        "num_classes": 2,
        "class_names": ["good", "bad"],
        "positive_class": "bad",
        "model_state": _cpu_state_dict(state["model_state"]),
        "optimizer_state": state.get("optimizer_state"),
        "scheduler_state": state.get("scheduler_state"),
        "scaler_state": state.get("scaler_state"),
        "epoch": int(state.get("epoch", 0)),
        "history": state.get("history", []),
        "best_epoch": state.get("best_epoch"),
        "best_score": state.get("best_score"),
        "selection_metric": state.get("selection_metric"),
        "selection_mode": state.get("selection_mode"),
        "threshold_bad": None,
        "data_config": copy.deepcopy(data_config),
        "class_weights": copy.deepcopy(class_weights),
        "config": clean_for_serialization(config),
        "base_checkpoint": str(base_checkpoint) if base_checkpoint else None,
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(checkpoint, path)


def _loader_config(config: dict[str, Any], device: torch.device) -> dict[str, Any]:
    training = config.get("training", {}) or {}
    workers = int(training.get("num_workers", 4))
    pin_default = device.type == "cuda"
    return {
        "batch_size": int(training.get("batch_size", 16)),
        "validation_batch_size": int(training.get("validation_batch_size", training.get("batch_size", 16))),
        "num_workers": workers,
        "pin_memory": bool(training.get("pin_memory", pin_default)),
        "persistent_workers": bool(training.get("persistent_workers", workers > 0)),
    }


def _metrics_by_source(frame: pd.DataFrame, threshold: float) -> dict[str, Any]:
    if "true_index" not in frame.columns:
        return {}
    output: dict[str, Any] = {}
    for source, subset in frame.groupby("source", dropna=False):
        output[str(source)] = binary_metrics(
            subset["true_index"].to_numpy(),
            subset["p_bad"].to_numpy(),
            threshold=threshold,
        )
    return output


def run_training(
    config: dict[str, Any],
    *,
    records_override: Sequence[ImageRecord] | None = None,
    initial_checkpoint: str | Path | None = None,
    mode: str = "train",
    run_name_override: str | None = None,
) -> dict[str, Any]:
    seed = int(get(config, "project.seed", 42))
    deterministic = bool(get(config, "project.deterministic", False))
    seed_everything(seed, deterministic=deterministic)

    output_root = _resolve_output_root(config)
    run_name = run_name_override or str(get(config, "project.name", "quality_classifier"))
    explicit_run_dir = get(config, "project.run_dir")
    if explicit_run_dir:
        run_dir = resolve_path(explicit_run_dir, config=config)
        assert run_dir is not None
        run_dir.mkdir(parents=True, exist_ok=False)
    else:
        run_dir = make_run_dir(output_root, run_name)

    logger = setup_logging(run_dir / "run.log", verbose=bool(get(config, "project.verbose", True)))
    save_yaml(config, run_dir / "config_resolved.yaml")
    write_json(env_info(), run_dir / "environment.json")

    device = choose_device(str(get(config, "training.device", "auto")))
    logger.info("Run directory: %s", run_dir)
    logger.info("Device: %s", device_summary(device))

    if records_override is None:
        records, dataset_root = _records_from_config(config, logger)
    else:
        records = [ImageRecord(**record.__dict__) for record in records_override]
        dataset_root = None
    _ensure_nonempty_splits(records)
    manifest_path = save_manifest(records, run_dir / "split_manifest.csv")
    counts = split_counts(records)
    write_json(counts, run_dir / "split_counts.json")
    logger.info("Split counts: %s", counts)

    train_records = [record for record in records if record.split == "train"]
    validation_records = [record for record in records if record.split == "validation"]
    test_records = [record for record in records if record.split == "test"]

    data_config = copy.deepcopy(config.get("data", {}) or {})
    data_config.pop("root", None)
    data_config.pop("manifest_path", None)
    train_transform = build_transforms(data_config, training=True)
    evaluation_transform = build_transforms(data_config, training=False)
    image_loading_config = data_config.get("image_loading", {}) or {}

    loader_config = _loader_config(config, device)
    training_config = copy.deepcopy(config.get("training", {}) or {})
    train_loader = build_labeled_loader(
        train_records,
        transform=train_transform,
        image_loading_config=image_loading_config,
        batch_size=loader_config["batch_size"],
        shuffle=True,
        num_workers=loader_config["num_workers"],
        pin_memory=loader_config["pin_memory"],
        persistent_workers=loader_config["persistent_workers"],
        sampler_config=training_config.get("sampler", {}) or {},
        seed=seed,
    )
    validation_loader = build_labeled_loader(
        validation_records,
        transform=evaluation_transform,
        image_loading_config=image_loading_config,
        batch_size=loader_config["validation_batch_size"],
        shuffle=False,
        num_workers=loader_config["num_workers"],
        pin_memory=loader_config["pin_memory"],
        persistent_workers=loader_config["persistent_workers"],
        sampler_config={"enabled": False},
        seed=seed,
    )

    model, architecture, dropout, base_checkpoint_data = _model_and_metadata(
        config,
        device=device,
        initial_checkpoint=initial_checkpoint,
    )
    logger.info("Model parameters before freeze logic: %s", count_parameters(model))

    criterion, class_weight_summary = build_loss(
        config.get("loss", {}) or {},
        train_labels=[record.label for record in train_records],
        device=device,
    )
    logger.info("Loss class weights: %s", class_weight_summary)
    write_json(class_weight_summary, run_dir / "class_weights.json")

    best_path = run_dir / "best_model.pt"
    last_path = run_dir / "last_model.pt"

    def checkpoint_callback(kind: str, state: dict[str, Any]) -> None:
        destination = best_path if kind == "best" else last_path
        _save_checkpoint(
            destination,
            state=state,
            architecture=architecture,
            dropout=dropout,
            config=config,
            data_config=data_config,
            class_weights=class_weight_summary,
            mode=mode,
            base_checkpoint=initial_checkpoint,
        )

    fit = fit_model(
        model=model,
        architecture=architecture,
        train_loader=train_loader,
        validation_loader=validation_loader,
        criterion=criterion,
        device=device,
        training_config=training_config,
        logger=logger,
        checkpoint_callback=checkpoint_callback,
    )
    model = fit["model"]
    history: pd.DataFrame = fit["history"]
    history.to_csv(run_dir / "history.csv", index=False, encoding="utf-8")
    save_training_history(history, run_dir / "training_history.png")

    validation_output = predict_labeled(
        model,
        validation_loader,
        device=device,
        criterion=criterion,
        use_amp=bool(training_config.get("mixed_precision", True) and device.type == "cuda"),
        show_progress=bool(training_config.get("show_progress", True)),
    )
    threshold_config = config.get("threshold", {}) or {}
    selected_threshold, validation_threshold_metrics, sweep = choose_safety_threshold(
        validation_output["y_true"],
        validation_output["p_bad"],
        target_bad_recall=float(threshold_config.get("target_bad_recall", 0.99)),
        max_false_pass_rate=(
            None
            if threshold_config.get("max_false_pass_rate", None) is None
            else float(threshold_config["max_false_pass_rate"])
        ),
        fallback_threshold=float(threshold_config.get("fallback_threshold", 0.5)),
        steps=int(threshold_config.get("search_steps", 10001)),
    )
    logger.info(
        "Selected BAD threshold %.5f from validation; BAD recall %.4f; false-pass rate %.4f",
        selected_threshold,
        validation_threshold_metrics["bad_recall"],
        validation_threshold_metrics["false_pass_rate"],
    )

    validation_predictions = predictions_frame(
        paths=validation_output["paths"],
        unit_ids=validation_output["unit_ids"],
        unit_ids_raw=validation_output["unit_ids_raw"],
        sources=validation_output["sources"],
        splits=validation_output["splits"],
        p_bad=validation_output["p_bad"],
        threshold=selected_threshold,
        y_true=validation_output["y_true"],
    )
    validation_metrics = save_evaluation_bundle(
        output_dir=run_dir / "validation",
        name="validation",
        y_true=validation_output["y_true"],
        p_bad=validation_output["p_bad"],
        threshold=selected_threshold,
        predictions=validation_predictions,
        threshold_sweep_frame=sweep,
        export_error_images=bool(get(config, "evaluation.export_error_images", True)),
        source_root=dataset_root,
    )
    write_json(
        _metrics_by_source(validation_predictions, selected_threshold),
        run_dir / "validation" / "metrics_by_source.json",
    )

    test_metrics: dict[str, Any] | None = None
    test_predictions: pd.DataFrame | None = None
    evaluate_test = bool(get(config, "evaluation.evaluate_test", True))
    if evaluate_test and test_records:
        test_loader = build_labeled_loader(
            test_records,
            transform=evaluation_transform,
            image_loading_config=image_loading_config,
            batch_size=loader_config["validation_batch_size"],
            shuffle=False,
            num_workers=loader_config["num_workers"],
            pin_memory=loader_config["pin_memory"],
            persistent_workers=loader_config["persistent_workers"],
            sampler_config={"enabled": False},
            seed=seed,
        )
        test_output = predict_labeled(
            model,
            test_loader,
            device=device,
            criterion=criterion,
            use_amp=bool(training_config.get("mixed_precision", True) and device.type == "cuda"),
            show_progress=bool(training_config.get("show_progress", True)),
        )
        test_predictions = predictions_frame(
            paths=test_output["paths"],
            unit_ids=test_output["unit_ids"],
            unit_ids_raw=test_output["unit_ids_raw"],
            sources=test_output["sources"],
            splits=test_output["splits"],
            p_bad=test_output["p_bad"],
            threshold=selected_threshold,
            y_true=test_output["y_true"],
        )
        test_metrics = save_evaluation_bundle(
            output_dir=run_dir / "test",
            name="test",
            y_true=test_output["y_true"],
            p_bad=test_output["p_bad"],
            threshold=selected_threshold,
            predictions=test_predictions,
            threshold_sweep_frame=threshold_sweep(
                test_output["y_true"], test_output["p_bad"], steps=1001
            ),
            export_error_images=bool(get(config, "evaluation.export_error_images", True)),
            source_root=dataset_root,
        )
        write_json(
            _metrics_by_source(test_predictions, selected_threshold),
            run_dir / "test" / "metrics_by_source.json",
        )

    # Update the best checkpoint with the validation-derived production threshold
    # and final metrics. The test split never influences this threshold.
    best_checkpoint = load_torch_checkpoint(best_path, map_location="cpu")
    best_checkpoint["model_state"] = _cpu_state_dict(model.state_dict())
    best_checkpoint["threshold_bad"] = float(selected_threshold)
    best_checkpoint["validation_metrics"] = validation_metrics
    best_checkpoint["test_metrics"] = test_metrics
    best_checkpoint["manifest_path"] = str(manifest_path)
    best_checkpoint["run_dir"] = str(run_dir)
    best_checkpoint["device_summary"] = device_summary(device)
    torch.save(best_checkpoint, best_path)

    summary = {
        "run_dir": str(run_dir),
        "best_model": str(best_path),
        "last_model": str(last_path),
        "manifest": str(manifest_path),
        "mode": mode,
        "architecture": architecture,
        "parameter_count": count_parameters(model),
        "best_epoch": fit["best_epoch"],
        "best_score": fit["best_score"],
        "selection_metric": fit["selection_metric"],
        "class_weights": class_weight_summary,
        "selected_threshold_bad": selected_threshold,
        "split_counts": counts,
        "validation_metrics": validation_metrics,
        "test_metrics": test_metrics,
    }
    write_json(summary, run_dir / "run_summary.json")

    report_parts = [
        f"# Model run: {run_name}",
        "",
        f"- Mode: **{mode}**",
        f"- Architecture: **{architecture}**",
        f"- Best epoch: **{fit['best_epoch']}**",
        f"- Positive/safety class: **BAD**",
        f"- Selected validation threshold P(BAD): **{selected_threshold:.5f}**",
        "",
        markdown_metrics(validation_metrics, "Validation results"),
    ]
    if test_metrics is not None:
        report_parts.extend(["", markdown_metrics(test_metrics, "Frozen test results")])
    (run_dir / "MODEL_REPORT.md").write_text("\n".join(report_parts), encoding="utf-8")

    logger.info("Finished. Best checkpoint: %s", best_path)
    return summary
