"""Native precision, geometry, checkpoint, and portable runtime regressions."""
import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

from nilt.data import audit, pixel_signature
from nilt.image_io import load_rgb, intensity_settings, NativeImage
from nilt.preprocessing import prepare_image, rotate_quarter_turn
from nilt.runtime import preprocess, PackageRunner
from nilt.deployment import parity_result


def write16(path, rgb):
    values = rgb[:, :, ::-1] if rgb.ndim == 3 else rgb
    ok, encoded = cv2.imencode(path.suffix, values)
    if not ok:
        raise AssertionError("Synthetic fixture encoding failed")
    path.write_bytes(encoded.tobytes())


class NativeDepthTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.cfg = {"image_size": 32, "resize": "pad", "preserve_native_resolution": True,
                    "intensity": {"uint16_black_level": 0, "uint16_white_level": 65535}}

    def tearDown(self):
        self.temp.cleanup()

    def test_gray_and_color_png_tiff_decode_exact_levels_and_unicode_path(self):
        gray = np.array([[0, 1, 32768, 32769, 65535], [255, 256, 4095, 4096, 60000]], dtype=np.uint16)
        rgb = np.stack([gray, np.flip(gray, 1), np.flip(gray, 0)], axis=2)
        for extension in ("png", "tiff"):
            for source in (gray, rgb):
                path = self.root / ("sensor_ü." + extension)
                write16(path, source)
                loaded = load_rgb(path)
                self.assertIsInstance(loaded, NativeImage)
                self.assertEqual(loaded.size, (5, 2))
                expected = np.repeat(gray[:, :, None], 3, axis=2) if source.ndim == 2 else rgb
                np.testing.assert_array_equal(np.asarray(loaded), expected)

    def test_one_sensor_count_survives_to_float_model_tensor(self):
        source = np.array([[32768, 32769]], dtype=np.uint16)
        path = self.root / "sensor.png"
        write16(path, source)
        tensor = preprocess(path, {**self.cfg, "mean": [0, 0, 0], "std": [1, 1, 1]})
        self.assertEqual(tensor.shape, (1, 3, 32, 32))
        self.assertGreater(tensor[0, 0, 15, 16], tensor[0, 0, 15, 15])
        np.testing.assert_allclose(tensor[0, 0, 15, 15:17], source[0] / 65535, atol=1e-7)

    def test_png_and_tiff_apply_exif_orientation_exactly_once(self):
        source = np.arange(3 * 5, dtype=np.uint16).reshape(3, 5) + 32000
        expected = {1: source, 2: source[:, ::-1], 3: source[::-1, ::-1],
                    4: source[::-1], 5: source.T, 6: np.rot90(source, 3),
                    7: source.T[::-1, ::-1], 8: np.rot90(source, 1)}
        for extension in ("png", "tiff"):
            for orientation in range(1, 9):
                with self.subTest(extension=extension, orientation=orientation):
                    image = Image.fromarray(source)
                    exif = image.getexif()
                    exif[274] = orientation
                    path = self.root / ("oriented." + extension)
                    image.save(path, exif=exif)
                    np.testing.assert_array_equal(np.asarray(load_rgb(path))[:, :, 0], expected[orientation])

    def test_train_and_portable_preprocessing_are_identical_for_all_depths(self):
        from nilt.engine import Transform
        rng = np.random.default_rng(7)
        for dtype, upper in ((np.uint8, 256), (np.uint16, 65536)):
            source = rng.integers(0, upper, (21, 29, 3), dtype=dtype)
            path = self.root / "input.png"
            if dtype == np.uint8:
                Image.fromarray(source).save(path)
            else:
                write16(path, source)
            for mode in ("pad", "fit"):
                cfg = {**self.cfg, "resize": mode, "preserve_native_resolution": mode == "pad"}
                training = Transform(cfg)(load_rgb(path)).numpy()
                np.testing.assert_array_equal(training, preprocess(path, cfg)[0])

    def test_custom_sensor_range_fixed_without_clipping_or_per_image_normalization(self):
        path = self.root / "raw12.png"
        source = np.array([[50, 100, 1100, 2100, 3100]], dtype=np.uint16)
        write16(path, source)
        cfg = {**self.cfg, "intensity": {"uint16_black_level": 100, "uint16_white_level": 2100},
               "mean": [0, 0, 0], "std": [1, 1, 1]}
        values = preprocess(path, cfg)[0, 0, 15, 13:18]
        np.testing.assert_allclose(values, [-.025, 0, .5, 1, 1.5], atol=1e-7)

    def test_quarter_turns_preserve_uint16_rectangle(self):
        source = np.arange(7 * 11 * 3, dtype=np.uint16).reshape(7, 11, 3) + 32000
        image = NativeImage(source)
        for k in range(4):
            rotated = rotate_quarter_turn(image, k)
            np.testing.assert_array_equal(np.asarray(rotated), np.rot90(source, k))
            padded = prepare_image(rotated, self.cfg)
            h, w = np.asarray(rotated).shape[:2]
            top, left = (32 - h) // 2, (32 - w) // 2
            np.testing.assert_allclose(np.asarray(padded)[top:top+h, left:left+w],
                                       np.rot90(source, k) / 65535, atol=1e-7)

    def test_depth_hash_retains_low_bits_and_old_8bit_identity(self):
        import hashlib
        a, b = self.root / "a.png", self.root / "b.png"
        write16(a, np.array([[32000]], dtype=np.uint16))
        write16(b, np.array([[32001]], dtype=np.uint16))
        self.assertNotEqual(pixel_signature(a)[0], pixel_signature(b)[0])
        image = Image.new("RGB", (32, 32), (34, 72, 145))
        image.save(a)
        expected = hashlib.sha256(str(image.size).encode() + image.tobytes()).hexdigest()
        self.assertEqual(pixel_signature(a)[0], expected)

    def test_audit_records_native_depth_without_resampling(self):
        from nilt.common import read_json
        data = self.root / "data"
        for label, offset in (("good", 0), ("bad", 500)):
            (data / label).mkdir(parents=True)
            write16(data / label / "raw.png", np.arange(31 * 43, dtype=np.uint16).reshape(31, 43) + offset)
        cfg = {**self.cfg, "data_root": str(data), "image_size": "auto", "near_duplicate_distance": -1}
        rows = audit(cfg, self.root / "audit")
        self.assertEqual(cfg["image_size"], 43)
        self.assertEqual({(r["width"], r["height"], r["source_bit_depth"]) for r in rows}, {(43, 31, 16)})
        self.assertEqual(read_json(self.root / "audit/audit_summary.json")["source_bit_depth_counts"], {"16": 2})

    def test_invalid_sensor_levels_fail(self):
        for levels in ({"uint16_white_level": 0}, {"uint16_black_level": -1},
                       {"uint16_white_level": float("nan")}, {"uint16_white_level": 65536},
                       {"uint16_white_level": True}, {"unknown": 1}):
            with self.subTest(levels=levels), self.assertRaises(ValueError):
                intensity_settings({"intensity": levels})

    def test_oversized_16bit_image_is_rejected_not_resized(self):
        image = NativeImage(np.zeros((17, 35, 3), dtype=np.uint16))
        with self.assertRaisesRegex(ValueError, "exceeds"):
            prepare_image(image, self.cfg)

    def test_checkpoint_intensity_metadata_and_mismatch(self):
        from nilt.engine import checkpoint_metadata, verify_checkpoint_configuration
        cfg = {**self.cfg, "task": "vig", "pretrained": True}
        metadata = checkpoint_metadata(cfg, "resnet18", 42, 0)
        self.assertEqual(metadata["intensity"], intensity_settings(cfg))
        verify_checkpoint_configuration(metadata, cfg)
        with self.assertRaisesRegex(ValueError, "intensity mismatch"):
            verify_checkpoint_configuration(metadata, {**cfg, "intensity": {"uint16_white_level": 4095}})

    def test_three_way_portable_boundaries_and_parity(self):
        runner = PackageRunner.__new__(PackageRunner)
        runner.mode, runner.good_threshold, runner.threshold = "triage", .3, .7
        self.assertEqual([runner.classify_score(x) for x in (.29, .3, .5, .7, .71)],
                         ["good", "review", "review", "bad", "bad"])
        parity = parity_result([.299999], [.300001], .7, atol=1e-3, good_threshold=.3)
        self.assertEqual(parity["status"], "failed")
        self.assertEqual(parity["decision_mismatches"], 1)


if __name__ == "__main__":
    unittest.main()
