# Annotation Operator Guide

## Start or continue a project

```bash
python segmentation.py annotate --config project.yaml
```

The command imports working copies automatically when the project is empty and starts the local interface. Existing annotations remain available. The input can contain nested folders; the browser shows one image at a time rather than processing all images into automatically approved labels.

For an import without opening the browser:

```bash
python segmentation.py init --config project.yaml
python segmentation.py status --config project.yaml
```

Run `init` again whenever new image files are added to an existing project's input folder. It imports new copies and preserves existing annotations. Restart or refresh the annotation interface afterward. `annotate` does not rescan an already populated project automatically.

To start the server without automatically opening a browser:

```bash
python segmentation.py annotate --config project.yaml --no-browser
```

Open the printed URL on the same computer. The server binds only to `127.0.0.1`. Keep the terminal running throughout the annotation session.

## Define the annotation consistently

**Inner** and **Outer** identify defect pixels in two inspection regions. They do not mean that the complete inner lens area or entire outer module area should be painted.

Before a labeling session, use the same defect acceptance definitions for every image. Include accepted texture as background. Include scratches, marks, or other unwanted features only when they meet the intended defect definition. Keep boundaries as close to the visible defect as practical; very generous circles also label healthy pixels and will teach that expanded shape to the network.

Use the lens ellipse to guide the automatic Inner/Outer assignment. Manual labels may override this division when the inspection definition requires it. The initial ellipse is a centered estimate, not an automatically verified lens contour.

## Review the automatic proposal

Opening an image for the first time creates a saved **draft** with classical suggestions. The detector:

1. Converts the working RGB image to brightness and applies mild smoothing.
2. Estimates a slowly varying background with a wider Gaussian filter.
3. Subtracts that background to obtain local contrast.
4. Estimates a robust contrast threshold separately inside and outside the lens ellipse.
5. Keeps connected components within the configured area limits and assigns their defect class.

The detector excludes the configured lens-boundary band and image-border band. It can flag acceptable texture, reflections, and edges. It can also miss broad or low-contrast defects. An empty proposal means only that no candidates passed these settings.

Adjust the ellipse and proposal settings before detailed manual work. Generating proposals again creates a new draft and replaces the current working mask with a fresh detector result. Previously saved revisions remain in the project history; unsaved browser edits are not a saved revision.

## Correct the mask

| Tool | Intended use |
| --- | --- |
| Brush | Paint irregular defect shapes with the selected class |
| Circle | Drag from center to edge to fill a round defect |
| Ellipse | Drag between opposite bounding-box corners to fill an oval defect |
| Polygon | Trace a defect boundary using several points |
| Rectangle | Mark a rectangular area |
| Eraser | Return selected pixels to background |
| Lens ROI | Position the ellipse used for automatic class assignment |
| Pan and zoom | Inspect details without changing image or mask resolution |
| Undo / redo | Revert or restore edits in the current browser editing session |

Choose the class before drawing. Inner and Outer cannot occupy the same pixel; painting a class replaces the previous value. The eraser restores background. Lower the overlay opacity to inspect the underlying image and confirm that the annotation follows the actual feature.

The interface retains discrete class indices at native resolution. Zoom affects the display only. Use the on-screen tool hints for drawing gestures and shortcuts.

Click polygon vertices, then press Enter to fill the polygon. Hold Shift while drawing an ellipse or lens ROI to constrain it to a circle. Brush size is measured in native image pixels.

## Keyboard shortcuts

| Shortcut | Action |
| --- | --- |
| `B`, `C`, `E` | Brush, Circle, Ellipse |
| `P`, `R`, `X` | Polygon, Box, Erase |
| `L`, `H` | Lens ROI, Pan |
| `1`, `2` | Inner, Outer defect class |
| `Enter`, `Escape` | Finish polygon, cancel current shape |
| `Space` + drag | Pan image |
| Mouse wheel, `+`, `-` | Zoom |
| `0`, `M` | Fit image, show/hide mask |
| `Ctrl+Z`, `Ctrl+Shift+Z` | Undo, redo |
| `Ctrl+S` | Save draft |
| `Page Up`, `Page Down` | Previous, next image |

Use Command instead of Control on macOS. The **Shortcuts** button opens the same reference in the interface. Text fields retain ordinary text-entry behavior.

## Save and approve

| Action | Result |
| --- | --- |
| Save draft | Save unfinished work as a new revision; exclude it from future datasets |
| Approve and continue | Save the current reviewed defect mask as approved and advance |
| Approve clean and continue | Explicitly approve an empty mask as a clean negative and advance |
| Previous / next | Navigate between images; resolve the unsaved-work prompt when shown |

Do not approve an image merely because the automatic proposal looks plausible at low zoom. Review it first. Real clean images are useful training examples and should be explicitly approved rather than left unannotated.

For a clean image with false-positive proposals, use **Clear defect mask**, inspect the full image, then choose **Approve clean & next**. The clean action requires an empty mask; it does not silently discard remaining defect pixels.

Editing a previously approved image does not change already exported datasets. Save the revised annotation and approve it again to include the new revision in the next export. A draft remains excluded even if an earlier revision was approved.

Undo history includes mask and lens-ROI edits. It retains up to 30 states within a 128 MiB memory budget, so large images retain fewer undo steps. This editor history does not replace saved revision history. Save important work before closing the browser or stopping the terminal.

## Export the reviewed data

```bash
python segmentation.py dataset --config project.yaml --output outputs/top_dataset_v1
```

The command creates a new independent dataset with approved image and mask copies. Re-running training also snapshots approved annotations automatically, so a separate export is optional for training and useful for dataset review or transfer.

Record the snapshot fingerprint with any reported result. If the reviewed masks change, create a new dataset snapshot and training run rather than modifying an existing result directory.
