/* Optional real-browser integration. Requires local Playwright + Chromium.
 * Run from the project root: node tests/test_ui_browser.js
 * Set PLAYWRIGHT_MODULE to an installed module path if it is not on Node's path.
 * Set TOPSEG_UI_SCREENSHOT to a PNG filename to retain a verified screenshot.
 * This test creates temporary synthetic data and never opens an operator project.
 */
'use strict';
const assert = require('node:assert/strict');
const {spawn} = require('node:child_process');
const readline = require('node:readline');
const path = require('node:path');
const fs = require('node:fs');
const crypto = require('node:crypto');
let chromium;
try { ({chromium} = require(process.env.PLAYWRIGHT_MODULE || 'playwright')); }
catch (_) { console.log('SKIP: Playwright is not installed. Install Playwright and its Chromium browser to run this optional test.'); process.exit(77); }
(async () => {
  let browser, fixture;
  try {
    browser = await chromium.launch({headless: true, args: ['--no-sandbox']});
    fixture = spawn(process.env.PYTHON || 'python', [path.join(__dirname, 'browser_fixture.py')], {cwd: path.join(__dirname, '..'), stdio: ['ignore', 'pipe', 'pipe']});
    fixture.stderr.on('data', x => process.stderr.write(x));
    const info = await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('Synthetic annotation server did not start.')), 15000);
      const lines = readline.createInterface({input: fixture.stdout});
      lines.once('line', line => { clearTimeout(timer); try { resolve(JSON.parse(line)); } catch (exc) { reject(exc); } });
      fixture.once('exit', code => { clearTimeout(timer); reject(new Error(`Fixture exited (${code}).`)); });
    });
    const page = await browser.newPage({viewport: {width: 1600, height: 1000}});
    const errors = []; page.on('pageerror', exc => errors.push(exc.message));
    page.on('dialog', dialog => dialog.accept());
    await page.goto(info.url); await page.waitForFunction(() => document.querySelector('#image-canvas').width === 720 && document.querySelector('#loading').classList.contains('hidden'));
    assert.equal(await page.locator('.image-item').count(), 2);
    assert.match(await page.locator('#image-status').textContent(), /Draft/);
    await page.locator('#clear-mask').click();
    assert.equal((await page.locator('#inner-count').textContent()).replaceAll(',', ''), '0');
    const bounds = await page.locator('#image-canvas').boundingBox();
    const position = (x, y) => ({x: bounds.x + x * bounds.width / 720, y: bounds.y + y * bounds.height / 640});
    async function drag(x0, y0, x1, y1) { const a = position(x0, y0), b = position(x1, y1); await page.mouse.move(a.x, a.y); await page.mouse.down(); await page.mouse.move(b.x, b.y, {steps: 8}); await page.mouse.up(); }
    await page.locator('[data-tool="circle"]').click(); await drag(312, 260, 337, 260);
    const circlePixels = Number((await page.locator('#inner-count').textContent()).replaceAll(',', '')); assert(circlePixels > 1800 && circlePixels < 2100);
    await page.locator('#undo').click(); assert.equal((await page.locator('#inner-count').textContent()).replaceAll(',', ''), '0');
    await page.locator('#redo').click(); assert.equal(Number((await page.locator('#inner-count').textContent()).replaceAll(',', '')), circlePixels);
    await page.locator('#class-outer').click(); await page.locator('[data-tool="polygon"]').click();
    for (const [x, y] of [[552, 178], [590, 178], [590, 214], [552, 214]]) { const p = position(x, y); await page.mouse.click(p.x, p.y); }
    await page.keyboard.press('Enter'); assert(Number((await page.locator('#outer-count').textContent()).replaceAll(',', '')) > 1000);
    await page.locator('#notes').fill('Synthetic browser integration review.');
    await page.locator('#save-draft').click(); await page.waitForFunction(() => document.querySelector('#save-state').textContent === 'Saved revision 2');
    assert.match(await page.locator('#image-status').textContent(), /Draft/);
    if (process.env.TOPSEG_UI_SCREENSHOT) await page.screenshot({path: process.env.TOPSEG_UI_SCREENSHOT, fullPage: true});
    await page.locator('#approve').click(); await page.waitForFunction(() => document.querySelector('#image-name').textContent === 'top_unit_02.png' && document.querySelector('#loading').classList.contains('hidden'));
    await page.locator('#clear-mask').click(); await page.locator('#approve-clean').click(); await page.waitForFunction(() => document.querySelector('#progress-text').textContent === '2 / 2 approved');
    const records = await page.evaluate(async () => {
      const headers = {'X-Session-Token': document.querySelector('meta[name="session-token"]').content};
      const project = await (await fetch('/api/project', {headers})).json();
      const images = await Promise.all(project.items.map(async x => (await fetch(`/api/image/${x.id}`, {headers})).json()));
      return {project, images};
    });
    assert.equal(records.project.approved, 2);
    const annotated = records.images.find(x => x.relative_path === 'top_unit_01.png'), clean = records.images.find(x => x.relative_path === 'top_unit_02.png');
    assert.equal(annotated.notes, 'Synthetic browser integration review.'); assert(annotated.mask_rle.some(x => x[0] === 1)); assert(annotated.mask_rle.some(x => x[0] === 2));
    assert.equal(clean.clean, true); assert.deepEqual(clean.mask_rle, [[0, 720 * 640]]);
    for (const [name, hash] of Object.entries(info.sources)) assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(info.root, 'source', name))).digest('hex'), hash);
    assert.deepEqual(errors, []);
    console.log('PASS: real Chromium UI, automatic first proposal, native circle/polygon masks, undo/redo, save draft, approval/navigation, clean negative, source preservation; no page errors.');
  } catch (exc) {
    console.error(exc.stack || exc.message);
    if (/Executable doesn't exist/.test(exc.message)) { console.log('SKIP: Chromium browser binary is not installed.'); process.exitCode = 77; } else process.exitCode = 1;
  } finally {
    if (fixture) fixture.kill('SIGINT');
    if (browser) await browser.close();
  }
})();
