"""Synthetic browser fixture with a real randomly initialized CPU checkpoint.

This verifies inference plumbing, never model accuracy or training quality.
"""
from pathlib import Path
import sys
import zipfile
import numpy as np
from PIL import Image
import yaml

from nilt.common import read_json, write_json, sha_file
from nilt.engine import make_model, save_checkpoint
from nilt.decisions import create_decision
from test_integration_v2 import fixture_run
from test_data_v2 import save_image


def main(root):
    root.mkdir(parents=True, exist_ok=True)
    run, _, _ = fixture_run(root / "results", threshold=.5)
    cfg = read_json(run / "config.json")
    cfg.update(task="vig", models=["resnet18"], batch_size=2, cpu_threads=1)
    write_json(run / "config.json", cfg)
    integrity = read_json(run / "integrity.json")
    integrity["config_sha256"] = sha_file(run / "config.json")
    write_json(run / "integrity.json", integrity)
    checkpoint = run / "models" / "resnet18_demo" / "best.pt"
    checkpoint.parent.mkdir()
    model, _ = make_model("resnet18", cfg, pretrained=False)
    save_checkpoint(checkpoint, model, cfg, "resnet18", 42, 0)
    candidate = read_json(run / "selected.json")
    candidate.update(name="resnet18_demo", task="vig", score_type="bad_probability_uncalibrated",
                     members=[{"checkpoint": checkpoint.relative_to(run).as_posix(), "sha256": sha_file(checkpoint),
                               "architecture": "resnet18", "kind": "supervised"}])
    write_json(run / "selected.json", candidate)
    write_json(run / "selection_integrity.json", {"sha256": sha_file(run / "selected.json")})
    write_json(run / "candidates.json", [candidate])
    write_json(run / "model_state.json", {"status": "SELECTED", "task": "vig"})
    calibration = run / "scores" / candidate["name"]
    calibration.mkdir(parents=True)
    np.save(calibration / "threshold.npy", [.1, .8, .3, .7])
    write_json(calibration / "provenance.json", {"candidate": candidate["name"],
               "manifest_sha256": sha_file(run / "manifest.csv"),
               "files": {"threshold.npy": sha_file(calibration / "threshold.npy")}})
    decision = create_decision(run, mode="triage", good_threshold=.3, bad_threshold=.7,
                               output_root=root / "decisions")
    for tray in (83, 84, 85):
        for i, label in enumerate(("good", "bad")):
            save_image(root / "dataset" / label / f"C{tray:08d}_Rc01Cc{i+1:02d}.png", tray * 10 + i)
    incoming = root / "incoming"
    for i in range(3):
        save_image(incoming / f"C00000091_Rc01Cc{i+1:02d}.png", 190 + i)
    with zipfile.ZipFile(root / "captures.zip", "w") as archive:
        for image in incoming.iterdir():
            archive.write(image, "captures/" + image.name)
    for task in ("top", "bottom"):
        for i in range(2):
            save_image(root / "inputs" / task / f"C00000091_Rc01Cc{i+1:02d}.png", i + 31)
    project = {"schema_version": 3, "paths": {"output_root": str(root / "results"),
        "weights_root": str(root / "weights"), "incoming_root": str(incoming), "classification_output_root": str(root / "classified")},
        "tasks": {"vig": {"dataset_root": str(root / "dataset")},
                  "top": {"dataset_root": str(root / "inputs/top")}, "bottom": {"dataset_root": str(root / "inputs/bottom")}}}
    (root / "project.yaml").write_text(yaml.safe_dump(project), encoding="utf-8")
    write_json(root / "fixture.json", {"run": str(run), "decision": str(decision)})


if __name__ == "__main__":
    main(Path(sys.argv[1]).resolve())
