"""Filesystem, annotation review and dataset isolation regression tests."""
from pathlib import Path
import shutil
import tempfile
import unittest
import numpy as np
from PIL import Image
from topseg.common import DEFAULTS, load_config, merge, read_json, read_rgb, sha256
from topseg.project import Project, ConflictError

class ProjectTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source = self.root / 'source'
        self.source.mkdir()
        self.cfg = merge(DEFAULTS, {'input_dir': str(self.source), 'project_dir': str(self.root / 'annotations'), 'output_dir': str(self.root / 'results')})
        self.rgb = np.random.default_rng(22).integers(50, 150, (40, 60, 3), dtype=np.uint8)
        Image.fromarray(self.rgb).save(self.source / 'first.png')
        self.project = Project(self.cfg)
        self.project.import_images()
        self.id = self.project.items()[0]['id']
    def tearDown(self):
        self.temp.cleanup()
    def mask(self):
        mask = np.zeros((40, 60), dtype=np.uint8)
        mask[5:10, 5:10], mask[20:25, 30:35] = 1, 2
        return mask
    def test_import_deduplicates_pixels_and_preserves_original(self):
        digest = sha256(self.source / 'first.png')
        Image.fromarray(self.rgb).save(self.source / 'same.bmp')
        report = self.project.import_images()
        self.assertEqual(report['total_images'], 1)
        self.assertEqual(report['duplicates_or_existing'], 2)
        self.project.open_image(self.id)
        self.assertEqual(sha256(self.source / 'first.png'), digest)
        np.testing.assert_array_equal(np.asarray(read_rgb(self.project.image_path(self.id))), self.rgb)
    def test_open_proposes_once_and_never_approves(self):
        first = self.project.open_image(self.id)
        self.assertEqual(first['status'], 'draft')
        self.assertEqual(first['origin'], 'classical')
        self.assertEqual(self.project.open_image(self.id)['revision'], first['revision'])
        with self.assertRaisesRegex(ValueError, 'No reviewed'):
            self.project.snapshot(self.root / 'dataset')
    def test_clean_approval_must_be_explicit_and_not_contradict_mask(self):
        empty = np.zeros((40, 60), dtype=np.uint8)
        with self.assertRaisesRegex(ValueError, 'Approve clean'):
            self.project.save_annotation(self.id, empty, approved=True)
        approved = self.project.save_annotation(self.id, empty, approved=True, clean=True)
        self.assertTrue(approved['clean'])
        with self.assertRaisesRegex(ValueError, 'no defect pixels'):
            self.project.save_annotation(self.id, self.mask(), expected_revision=approved['revision'], approved=True, clean=True)
    def test_stale_editor_cannot_replace_revision(self):
        annotation = self.project.save_annotation(self.id, self.mask(), approved=True)
        with self.assertRaises(ConflictError):
            self.project.save_annotation(self.id, self.mask(), expected_revision=0)
        self.assertEqual(self.project.items()[0]['revision'], annotation['revision'])
        self.assertEqual(self.project.items()[0]['status'], 'approved')
    def test_edit_demotes_approval_and_preserves_frozen_snapshot(self):
        old = self.project.save_annotation(self.id, self.mask(), approved=True)
        path = self.project.snapshot(self.root / 'dataset')
        copied = path.parent / read_json(path)['records'][0]['mask']
        digest = sha256(copied)
        changed = self.mask()
        changed[5:10, 5:10] = 2
        latest = self.project.save_annotation(self.id, changed, expected_revision=old['revision'])
        self.assertEqual(latest['status'], 'draft')
        self.assertEqual(sha256(copied), digest)
        self.assertTrue((self.project.root / old['mask']).exists())
        with self.assertRaises(ValueError):
            self.project.snapshot(self.root / 'dataset2')
    def test_invalid_masks_rejected_without_valid_annotation(self):
        for mask in (np.zeros((1, 1), dtype=np.uint8), np.full((40, 60), 256, dtype=np.uint16), np.full((40, 60), -1, dtype=np.int8), np.full((40, 60), .5)):
            with self.subTest(dtype=mask.dtype, shape=mask.shape):
                with self.assertRaises(ValueError):
                    self.project.save_annotation(self.id, mask)
        self.assertEqual(self.project.items()[0]['status'], 'unannotated')
    def test_snapshot_rejects_tampered_mask(self):
        annotation = self.project.save_annotation(self.id, self.mask(), approved=True)
        Image.fromarray(np.zeros((40, 60), dtype=np.uint8)).save(self.project.root / annotation['mask'])
        with self.assertRaisesRegex(ValueError, 'checksum'):
            self.project.snapshot(self.root / 'dataset')
        self.assertFalse((self.root / 'dataset' / 'dataset.json').exists())
    def test_changed_original_cannot_replace_imported_pixels(self):
        Image.fromarray(255 - self.rgb).save(self.source / 'first.png')
        self.assertEqual(len(self.project.import_images()['invalid']), 1)
        np.testing.assert_array_equal(np.asarray(read_rgb(self.project.image_path(self.id))), self.rgb)
    def test_moved_project_operates_after_originals_removed(self):
        self.project.save_annotation(self.id, self.mask(), approved=True)
        moved = self.root / 'moved'
        shutil.move(self.project.root, moved)
        shutil.rmtree(self.source)
        restored = Project(dict(self.cfg, project_dir=str(moved)))
        self.assertEqual(restored.open_image(self.id)['status'], 'approved')
        self.assertEqual(len(read_json(restored.snapshot(self.root / 'dataset'))['records']), 1)
    def test_unit_grouping_and_cross_unit_duplicate_conflict(self):
        cfg = dict(self.cfg, project_dir=str(self.root / 'grouped'), group_regex=r'(unit_[0-9]+)')
        (self.source / 'first.png').unlink()
        for name, data in [('unit_001_a.png', self.rgb), ('unit_001_b.png', 255 - self.rgb), ('unit_002_a.png', self.rgb)]:
            Image.fromarray(data).save(self.source / name)
        project = Project(cfg)
        self.assertEqual(len(project.import_images()['invalid']), 1)
        self.assertEqual(len(project.items()), 2)
        self.assertEqual({row['group'] for row in project.items()}, {'unit_001'})
        with self.assertRaisesRegex(ValueError, 'group_regex'):
            Project(dict(cfg, group_regex=None))
    def test_nested_output_rejected_in_configuration(self):
        import yaml
        for output in (self.root / 'annotations' / 'results', self.source / 'results'):
            path = self.root / 'config.yaml'
            path.write_text(yaml.safe_dump(dict(self.cfg, output_dir=str(output))))
            with self.assertRaises(ValueError):
                load_config(path)
    def test_exif_rotation_normalizes_native_geometry(self):
        exif = Image.Exif()
        exif[274] = 6
        Image.fromarray(self.rgb).save(self.source / 'rotated.jpg', exif=exif)
        self.assertEqual(read_rgb(self.source / 'rotated.jpg').size, (40, 60))
    def test_ambiguous_bit_depth_and_transparency_rejected(self):
        paths = [self.source / 'sixteen.tif', self.source / 'transparent.png']
        Image.fromarray(np.arange(2400, dtype=np.uint16).reshape(40, 60)).save(paths[0])
        Image.new('RGBA', (20, 20), (0, 0, 0, 0)).save(paths[1])
        for path in paths:
            with self.assertRaises(ValueError):
                read_rgb(path)

if __name__ == '__main__':
    unittest.main()
