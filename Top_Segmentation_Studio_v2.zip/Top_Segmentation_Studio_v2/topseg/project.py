"""Working image copies, revisioned human review, and frozen training datasets."""
from __future__ import annotations
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import shutil
import uuid

import numpy as np
from PIL import Image

from .common import (CLASSES, DEFAULTS, EXTENSIONS, atomic_json, merge, project_lock,
                     read_json, read_rgb, safe_path, sha256, utc_now)
from .classical import (default_roi, suggest, validate_roi, validate_settings,
                        reclassify_mask, detect_inner_roi)
from .annotations import objects_from_mask, validate_objects, decode_rle, encode_rle
from .annotation_profiles import AnnotationProfiles, validate_manual_edits
from .proposals import suggest_advanced, validate_automation


class ConflictError(ValueError):
    """An annotation changed since the editor loaded its revision."""


from .templates import PolygonTemplates


class Project(PolygonTemplates, AnnotationProfiles):
    def __init__(self, cfg):
        self.cfg = merge(DEFAULTS, cfg)
        self.root = Path(self.cfg['project_dir']).resolve()
        self.source = Path(self.cfg['input_dir']).resolve()
        if self.root.is_relative_to(self.source) or self.source.is_relative_to(self.root):
            raise ValueError('Input and project must be separate directory trees.')
        self.root.mkdir(parents=True, exist_ok=True)
        if not (self.root / 'project.json').exists():
            with project_lock(self.root):
                if not (self.root / 'project.json').exists():
                    atomic_json(self.root / 'project.json', {
                        'schema_version': 1, 'name': self.cfg['name'], 'task': 'top',
                        'created_at': utc_now(), 'classes': CLASSES,
                        'group_regex': self.cfg.get('group_regex'), 'images': []})
        self._manifest()

    def _manifest(self):
        manifest = read_json(self.root / 'project.json')
        if manifest['schema_version'] != 1 or manifest['classes'] != CLASSES:
            raise ValueError('Unsupported project schema or class mapping.')
        if manifest.get('group_regex') != self.cfg.get('group_regex'):
            raise ValueError('Changing group_regex requires a separate annotation project; existing unit assignments are fixed.')
        return manifest

    def _row(self, image_id):
        if not isinstance(image_id, str) or not re.fullmatch('[a-f0-9]{24}', image_id):
            raise ValueError('Invalid image identifier.')
        for row in self._manifest()['images']:
            if row['id'] == image_id:
                return row
        raise KeyError(f'Unknown image: {image_id}')

    def _annotation(self, image_id):
        path = self.root / 'annotations' / f'{image_id}.json'
        return read_json(path) if path.exists() else None

    @staticmethod
    def _retain_reviewed_v1_objects(objects, annotation):
        """Keep reviewed v1 footprints when their edit provenance is unknown.

        v1 retained ``kind=proposal`` after users erased/edited and saved an
        object. With no v2 erase history we cannot safely regenerate those
        reviewed footprints. Treat matching old objects as legacy/manual until
        the user explicitly discards them. This normalization never writes an
        existing revision; new proposal UUIDs remain automatic proposals.
        """
        if (not isinstance(objects, list) or not annotation or 'manual_edits' in annotation
                or annotation.get('origin') != 'manual'):
            return objects
        reviewed_ids = {obj['id'] for obj in annotation.get('objects', []) if obj.get('kind') == 'proposal'}
        return [dict(obj, kind='legacy') if isinstance(obj, dict) and obj.get('kind') == 'proposal' and obj.get('id') in reviewed_ids
                else obj for obj in objects]

    def import_images(self):
        if not self.source.is_dir():
            raise FileNotFoundError(f'Input directory not found: {self.source}')
        with project_lock(self.root):
            manifest = self._manifest()
            known = {row['pixel_sha256']: row for row in manifest['images']}
            ids = {row['id'] for row in manifest['images']}
            aliases = {alias: row for row in manifest['images'] for alias in row.get('source_aliases', [row['relative_path']])}
            regex = re.compile(self.cfg['group_regex']) if self.cfg.get('group_regex') else None
            added, duplicate, invalid = [], [], []
            for path in sorted(self.source.rglob('*')):
                if not path.is_file() or path.suffix.lower() not in EXTENSIONS:
                    continue
                relative = path.relative_to(self.source).as_posix()
                try:
                    if not path.resolve().is_relative_to(self.source):
                        raise ValueError('Image symlink points outside the input directory.')
                    original_hash = sha256(path)
                    image = read_rgb(path, self.cfg['max_image_pixels'])
                    if sha256(path) != original_hash:
                        raise ValueError('Source changed during import; retry after acquisition finishes.')
                    pixel_hash = hashlib.sha256(f'{image.width}x{image.height}\0'.encode() + image.tobytes()).hexdigest()
                    image_id = pixel_hash[:24]
                    group = 'pixel:' + pixel_hash
                    if regex:
                        match = regex.search(relative)
                        if not match:
                            raise ValueError('group_regex did not match this relative path.')
                        group = match.groupdict().get('unit') or match.group(1)
                        if not group:
                            raise ValueError('group_regex produced an empty unit identifier.')
                    if relative in aliases and aliases[relative]['pixel_sha256'] != pixel_hash:
                        raise ValueError('A previously imported source path now contains different pixels. Use a new filename for a new acquisition.')
                    if pixel_hash in known:
                        row = known[pixel_hash]
                        if row['group'] != group:
                            raise ValueError('Identical pixels assigned to different units; resolve the duplicate before import.')
                        if relative not in row['source_aliases']:
                            row['source_aliases'].append(relative)
                        aliases[relative] = row
                        duplicate.append(relative)
                        continue
                    if image_id in ids:
                        raise ValueError('Image identifier collision; import aborted for this image.')
                    destination = self.root / 'images' / (image_id + '.png')
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    temp = destination.with_suffix('.png.tmp')
                    image.save(temp, format='PNG')
                    temp.replace(destination)
                    row = {'id': image_id, 'relative_path': relative, 'source_aliases': [relative],
                           'source_sha256': original_hash, 'pixel_sha256': pixel_hash,
                           'image': destination.relative_to(self.root).as_posix(),
                           'image_sha256': sha256(destination), 'width': image.width,
                           'height': image.height, 'group': group, 'imported_at': utc_now()}
                    manifest['images'].append(row)
                    known[pixel_hash], aliases[relative] = row, row
                    ids.add(image_id)
                    added.append(relative)
                except (ValueError, OSError, Image.DecompressionBombError) as exc:
                    invalid.append({'relative_path': relative, 'error': str(exc)})
            manifest['updated_at'] = utc_now()
            atomic_json(self.root / 'project.json', manifest)
            report = {'imported': len(added), 'duplicates_or_existing': len(duplicate),
                      'invalid': invalid, 'total_images': len(manifest['images']), 'at': utc_now()}
            atomic_json(self.root / 'import_report.json', report)
            return report

    def items(self):
        result = []
        for row in self._manifest()['images']:
            annotation = self._annotation(row['id'])
            result.append({**row, 'status': annotation['status'] if annotation else 'unannotated',
                           'revision': annotation['revision'] if annotation else 0,
                           'clean': annotation.get('clean', False) if annotation else False,
                           'statistics': annotation.get('statistics', {}) if annotation else {}})
        return result

    def image_path(self, image_id):
        row = self._row(image_id)
        path = safe_path(self.root, row['image'])
        if sha256(path) != row['image_sha256']:
            raise ValueError('Working image changed after import; restore its verified copy.')
        return path

    def mask_path(self, image_id):
        self._row(image_id)
        annotation = self._annotation(image_id)
        if annotation is None:
            return None
        path = safe_path(self.root, annotation['mask'])
        if sha256(path) != annotation['mask_sha256']:
            raise ValueError('Saved mask checksum mismatch; restore the annotation revision.')
        return path

    def open_image(self, image_id):
        row = self._row(image_id)
        self.image_path(image_id)
        if self._annotation(image_id) is None:
            try:
                self.propose(image_id, expected_revision=0, allow_unavailable=True)
            except ConflictError:
                pass
        annotation = self._annotation(image_id)
        mask_path = self.mask_path(image_id)
        # Opening a pre-object project must not rewrite immutable revisions or
        # change its saved class labels. Objects migrate only on an explicit save.
        if 'objects' not in annotation:
            with Image.open(mask_path) as saved:
                annotation = dict(annotation, objects=objects_from_mask(np.asarray(saved)))
        # Response-only migration: never rewrite legacy immutable revisions on open.
        annotation = dict(annotation)
        annotation['objects'] = self._retain_reviewed_v1_objects(annotation['objects'], annotation)
        annotation.setdefault('automation', validate_automation(None, row['width'], row['height']))
        annotation.setdefault('manual_edits', validate_manual_edits(None, row['width'], row['height']))
        return {**row, **annotation}

    def save_annotation(self, image_id, mask, roi=None, expected_revision=0,
                        approved=False, clean=False, notes='', settings=None, origin='manual', objects=None,
                        automation=None, manual_edits=None, proposal_statistics=None):
        with project_lock(self.root):
            return self._save(image_id, mask, roi, expected_revision, approved, clean, notes, settings, origin,
                              objects=objects, automation=automation, manual_edits=manual_edits, proposal_statistics=proposal_statistics)

    def _save(self, image_id, mask, roi, expected_revision, approved, clean, notes, settings, origin, proposal_statistics=None, objects=None, status=None, preserve_labels=False, rejection_reason=None, roi_detection=None, automation=None, manual_edits=None):
        row = self._row(image_id)
        self.image_path(image_id)
        previous = self._annotation(image_id)
        current_revision = previous['revision'] if previous else 0
        if isinstance(expected_revision, bool) or not isinstance(expected_revision, int) or expected_revision != current_revision:
            raise ConflictError('Annotation changed in another tab or process. Reload this image before saving.')
        if approved and previous and previous['status'] == 'rejected' and status != 'draft':
            raise ValueError('Restore this rejected image to a draft before approving it.')
        if not isinstance(approved, bool) or not isinstance(clean, bool):
            raise ValueError('approved and clean must be booleans.')
        values = np.asarray(mask)
        if values.shape != (row['height'], row['width']) or values.dtype.kind not in ('i', 'u'):
            raise ValueError('Mask must be an integer array matching the native image dimensions.')
        if not np.isin(values, [0, 1, 2]).all():
            raise ValueError('Mask labels must be 0=background, 1=inner or 2=outer.')
        is_empty = not bool(np.any(values))
        if approved and is_empty and not clean:
            raise ValueError('Use Approve clean to explicitly confirm an image with no defects.')
        if clean and not is_empty:
            raise ValueError('A clean annotation must contain no defect pixels.')
        if not isinstance(notes, str) or len(notes) > 10000:
            raise ValueError('Annotation notes must be text with at most 10000 characters.')
        if origin not in ('manual', 'classical'):
            raise ValueError('Annotation origin must be manual or classical.')
        roi = validate_roi(roi if roi is not None else (previous or {}).get('roi'), row['width'], row['height'])
        settings = validate_settings(settings if settings is not None else (previous or {}).get('settings', self.cfg['classical']))
        automation = validate_automation(automation if automation is not None else (previous or {}).get('automation'), row['width'], row['height'])
        manual_edits = validate_manual_edits(manual_edits if manual_edits is not None else (previous or {}).get('manual_edits'), row['width'], row['height'])
        if objects is None:
            objects = objects_from_mask(values, kind='proposal' if origin == 'classical' else 'legacy')
        objects = self._retain_reviewed_v1_objects(objects, previous)
        objects, support = validate_objects(objects, row['width'], row['height'])
        if not np.array_equal(support > 0, values > 0):
            raise ValueError('Annotation object footprints must match the supplied mask support.')
        # Class labels follow geometry automatically, including hidden objects.
        # Status-only revisions retain legacy saved labels byte-for-byte.
        if not preserve_labels:
            values = reclassify_mask(support, roi)
        if status is None:
            status = ('rejected' if previous and previous['status'] == 'rejected'
                      else 'approved' if approved else 'draft')
        last_proposal = proposal_statistics if proposal_statistics is not None else (previous or {}).get('statistics', {}).get('proposal')
        if last_proposal is not None:
            if not isinstance(last_proposal, dict):
                raise ValueError('Proposal diagnostics must be an object.')
            try:
                encoded = json.dumps(last_proposal, allow_nan=False)
            except (ValueError, TypeError) as exc:
                raise ValueError('Proposal diagnostics must contain finite JSON data.') from exc
            if len(encoded.encode('utf-8')) > 1024 * 1024:
                raise ValueError('Proposal diagnostics exceed 1 MiB.')
            last_proposal = deepcopy(last_proposal)
            if 'input_context' not in last_proposal and previous:
                last_proposal['input_context'] = {key: deepcopy(previous.get(key)) for key in ('roi', 'settings', 'automation')}
            last_proposal['stale'] = last_proposal.get('input_context') != {'roi': roi, 'settings': settings, 'automation': automation}
        revision = current_revision + 1
        revision_dir = self.root / 'history' / image_id / f'{revision:06d}'
        # A failed write can leave an unreferenced revision. Keep it for inspection
        # and allocate a new directory instead of overwriting any annotation history.
        while revision_dir.exists():
            revision += 1
            revision_dir = self.root / 'history' / image_id / f'{revision:06d}'
        revision_dir.mkdir(parents=True)
        mask_path = revision_dir / 'mask.png'
        Image.fromarray(values.astype(np.uint8)).save(mask_path)
        statistics = {'background_pixels': int((values == 0).sum()),
                      'inner_pixels': int((values == 1).sum()), 'outer_pixels': int((values == 2).sum())}
        if last_proposal is not None:
            statistics['proposal'] = last_proposal
        annotation = {'id': image_id, 'revision': revision, 'status': status,
                      'approved': approved, 'clean': bool(clean and approved),
                      'mask': mask_path.relative_to(self.root).as_posix(), 'mask_sha256': sha256(mask_path),
                      'image_sha256': row['image_sha256'], 'roi': roi, 'settings': settings,
                      'objects': objects, 'objects_schema_version': 1,
                      'automation': automation, 'manual_edits': manual_edits,
                      'statistics': statistics, 'origin': origin, 'notes': notes,
                      'updated_at': utc_now(), 'approved_at': utc_now() if approved else None}
        if rejection_reason is not None:
            annotation['rejection_reason'] = rejection_reason
        elif previous and previous.get('rejection_reason'):
            annotation['rejection_reason'] = previous['rejection_reason']
        if roi_detection is not None:
            annotation['roi_detection'] = roi_detection
        elif previous and previous.get('roi_detection') and previous.get('roi') == roi:
            annotation['roi_detection'] = previous['roi_detection']
        atomic_json(revision_dir / 'annotation.json', annotation)
        atomic_json(self.root / 'annotations' / f'{image_id}.json', annotation)
        return {**row, **annotation}

    @staticmethod
    def _check_revision(previous, expected_revision):
        current = previous['revision'] if previous else 0
        if type(expected_revision) is not int or expected_revision != current:
            raise ConflictError('Annotation changed in another tab or process. Reload this image before saving.')

    def detect_roi(self, image_id, expected_revision, roi=None, mode='guided'):
        """Return a detection candidate without altering saved annotations."""
        row = self._row(image_id)
        previous = self._annotation(image_id)
        self._check_revision(previous, expected_revision)
        prior = roi if roi is not None else (previous or {}).get('roi')
        if prior is not None:
            prior = validate_roi(prior, row['width'], row['height'])
        candidate, metadata = detect_inner_roi(
            read_rgb(self.image_path(image_id), self.cfg['max_image_pixels']), prior_roi=prior, mode=mode)
        # Detection can take time: reject a result computed across another save.
        self._check_revision(self._annotation(image_id), expected_revision)
        return {'roi': candidate, 'detection': metadata}

    def set_rejected(self, image_id, rejected, expected_revision, reason=''):
        """Exclude/restore a working image through a new immutable revision.

        Source images, existing masks, notes, geometry and object footprints are
        preserved. A restore always creates a draft needing fresh approval.
        """
        if type(rejected) is not bool:
            raise ValueError('rejected must be a boolean.')
        if not isinstance(reason, str) or len(reason) > 10000:
            raise ValueError('Rejection reason must be text with at most 10000 characters.')
        with project_lock(self.root):
            row = self._row(image_id)
            previous = self._annotation(image_id)
            self._check_revision(previous, expected_revision)
            if not rejected and (not previous or previous['status'] != 'rejected'):
                raise ValueError('Only rejected images can be restored.')
            if previous:
                with Image.open(self.mask_path(image_id)) as saved:
                    mask = np.asarray(saved).copy()
            else:
                mask = np.zeros((row['height'], row['width']), dtype=np.uint8)
            old = previous or {}
            return self._save(image_id, mask, old.get('roi'), expected_revision,
                              False, False, old.get('notes', ''), old.get('settings'),
                              old.get('origin', 'manual'),
                              proposal_statistics=old.get('statistics', {}).get('proposal'),
                              objects=old.get('objects'),
                              status='rejected' if rejected else 'draft',
                              preserve_labels=True,
                              rejection_reason=reason if rejected else old.get('rejection_reason', ''))

    def _proposal_inputs(self, image_id, roi, settings, automation, expected_revision):
        row = self._row(image_id)
        previous = self._annotation(image_id) or {}
        self._check_revision(previous, expected_revision)
        image = read_rgb(self.image_path(image_id), self.cfg['max_image_pixels'])
        detection = None
        if roi is None and not previous.get('roi'):
            roi = self.template_roi(row['width'], row['height'])
        if roi is None and not previous.get('roi'):
            selected_roi, detection = detect_inner_roi(image)
        else:
            selected_roi = validate_roi(roi if roi is not None else previous.get('roi'), row['width'], row['height'])
        selected_settings = validate_settings(settings if settings is not None else previous.get('settings', self.cfg['classical']))
        if automation is None:
            automation = previous.get('automation') or self.profile_automation(row['width'], row['height'])
        selected_automation = validate_automation(automation, row['width'], row['height'])
        return row, previous, image, selected_roi, selected_settings, selected_automation, detection

    def _automatic_mask(self, image_id, image, roi, settings, automation):
        references = []
        if automation['method'] == 'reference':
            for reference_id in automation['reference_ids']:
                if reference_id == image_id:
                    raise ValueError('The image under review cannot be its own good reference. Select another reference or use Basic.')
                try:
                    reference = np.asarray(read_rgb(self.image_path(reference_id), self.cfg['max_image_pixels']))
                except (FileNotFoundError, KeyError) as exc:
                    raise ValueError('A selected reference image is unavailable. Select another reference or use Basic.') from exc
                if reference.shape != np.asarray(image).shape:
                    raise ValueError('Good references must have the same native dimensions as the image under review. No images are resized.')
                references.append((reference_id, reference))
        mask, statistics = suggest_advanced(image, roi, settings, automation, references=references)
        statistics['input_context'] = {'roi': deepcopy(roi), 'settings': deepcopy(settings), 'automation': deepcopy(automation)}
        statistics['stale'] = False
        return mask, statistics

    def preview_proposal(self, image_id, roi=None, settings=None, automation=None, expected_revision=0):
        """Return candidates only; failed previews never change saved or editor data."""
        row, previous, image, roi, settings, automation, detection = self._proposal_inputs(
            image_id, roi, settings, automation, expected_revision)
        mask, statistics = self._automatic_mask(image_id, image, roi, settings, automation)
        self._check_revision(self._annotation(image_id), expected_revision)
        objects = objects_from_mask(mask, kind='proposal')
        for obj in objects:
            obj['id'] = 'proposal-' + uuid.uuid4().hex
        return {'roi': roi, 'automation': automation, 'settings': settings,
                'mask_rle': encode_rle(mask), 'objects': objects, 'statistics': {'proposal': statistics},
                'expected_revision': expected_revision}

    def propose(self, image_id, roi=None, settings=None, expected_revision=0,
                automation=None, keep_manual_edits=True, allow_unavailable=False):
        """Persist proposals for CLI/initial open; editor reload uses preview instead."""
        if type(keep_manual_edits) is not bool:
            raise ValueError('keep_manual_edits must be boolean.')
        row, previous, image, selected_roi, selected_settings, automation, detection = self._proposal_inputs(
            image_id, roi, settings, automation, expected_revision)
        try:
            mask, statistics = self._automatic_mask(image_id, image, selected_roi, selected_settings, automation)
        except ValueError as exc:
            if not allow_unavailable:
                raise
            # A saved advanced profile may not work for every new image. Opening
            # must still allow the user to select Basic or annotate manually.
            mask = np.zeros((row['height'], row['width']), dtype=np.uint8)
            statistics = {'method': automation['method'], 'failed': True, 'automatic_proposal': True,
                          'review_required': True, 'warnings': [str(exc)],
                          'input_context': {'roi': deepcopy(selected_roi), 'settings': deepcopy(selected_settings), 'automation': deepcopy(automation)},
                          'note': 'No automatic proposal was generated. Change method or settings and reload; review manually before approval.'}
        edits = validate_manual_edits(previous.get('manual_edits') if keep_manual_edits else None, row['width'], row['height'])
        if keep_manual_edits:
            mask[decode_rle(edits['erase_rle'], row['width'], row['height']) > 0] = 0
        objects = objects_from_mask(mask, kind='proposal')
        for obj in objects:
            obj['id'] = 'proposal-' + uuid.uuid4().hex
        if keep_manual_edits:
            prior_objects = previous.get('objects')
            if prior_objects is None and previous:
                with Image.open(self.mask_path(image_id)) as old_mask:
                    prior_objects = objects_from_mask(np.asarray(old_mask), kind='legacy')
            prior_objects = self._retain_reviewed_v1_objects(prior_objects or [], previous)
            objects.extend(o for o in (prior_objects or []) if o['kind'] != 'proposal')
        objects, support = validate_objects(objects, row['width'], row['height'])
        mask = reclassify_mask(support, selected_roi)
        with project_lock(self.root):
            return self._save(image_id, mask, selected_roi, expected_revision, False, False,
                              previous.get('notes', ''), selected_settings, 'classical', statistics,
                              objects=objects, roi_detection=detection, automation=automation, manual_edits=edits)

    def snapshot(self, output):
        output = Path(output).resolve()
        if (output.is_relative_to(self.root) or self.root.is_relative_to(output) or
                output.is_relative_to(self.source) or self.source.is_relative_to(output)):
            raise ValueError('Dataset snapshot must be outside both input and annotation project trees.')
        if output.exists() and any(output.iterdir()):
            raise FileExistsError('Dataset output must be new or empty.')
        with project_lock(self.root):
            approved = [(row, self._annotation(row['id'])) for row in self._manifest()['images']]
            approved = [(row, annotation) for row, annotation in approved if annotation and annotation['status'] == 'approved']
            if not approved:
                raise ValueError('No reviewed annotations. Approve defects or explicitly approve clean images first.')
            output.mkdir(parents=True, exist_ok=True)
            records = []
            try:
                for row, annotation in approved:
                    image_path, mask_path = self.image_path(row['id']), self.mask_path(row['id'])
                    with Image.open(mask_path) as source:
                        mask = np.asarray(source)
                    if mask.shape != (row['height'], row['width']) or not np.isin(mask, [0, 1, 2]).all():
                        raise ValueError('Approved mask has invalid dimensions or labels.')
                    revision_path = safe_path(self.root, annotation['mask']).parent / 'annotation.json'
                    if read_json(revision_path) != annotation:
                        raise ValueError('Current annotation differs from its immutable revision record.')
                    if annotation['image_sha256'] != row['image_sha256']:
                        raise ValueError('Annotation belongs to a different image version.')
                    if not np.any(mask) and not annotation['clean']:
                        raise ValueError('Empty annotation lacks explicit clean approval.')
                    image_rel, mask_rel = f'images/{row["id"]}.png', f'masks/{row["id"]}.png'
                    for source, relative in ((image_path, image_rel), (mask_path, mask_rel)):
                        destination = output / relative
                        destination.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(source, destination)
                    records.append({'id': row['id'], 'group': row['group'], 'image': image_rel, 'mask': mask_rel,
                                    'width': row['width'], 'height': row['height'], 'annotation_revision': annotation['revision'],
                                    'clean': annotation['clean'], 'image_sha256': row['image_sha256'],
                                    'mask_sha256': annotation['mask_sha256'], 'pixel_sha256': row['pixel_sha256']})
                fingerprint = hashlib.sha256(json.dumps(records, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
                result = {'schema_version': 1, 'created_at': utc_now(), 'classes': CLASSES,
                          'task': 'top', 'fingerprint': fingerprint, 'records': records,
                          'grouping': 'regex' if self.cfg.get('group_regex') else 'pixel_identity',
                          'note': 'Only explicitly approved annotations; background-only images require clean approval.'}
                atomic_json(output / 'dataset.json', result)
                return output / 'dataset.json'
            except Exception as exc:
                atomic_json(output / 'snapshot_failed.json', {'error': str(exc), 'at': utc_now()})
                raise
