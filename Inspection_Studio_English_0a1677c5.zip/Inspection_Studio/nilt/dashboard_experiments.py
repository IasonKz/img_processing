"""Long threshold experiments and frozen deployment pipelines."""
from datetime import datetime, timezone
from pathlib import Path
import sys
import uuid

from .common import read_json, write_json, sha_file

EXPERIMENT_ACTIONS = {"threshold-tune", "deploy-pipeline"}


class ExperimentDashboardMixin:
    def experiment_command(self, action, data, project):
        if action not in EXPERIMENT_ACTIONS:
            return None
        from .devices import validate_device_name
        device = validate_device_name(data.get("device", "cpu"))
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%f") + "_" + uuid.uuid4().hex[:8]
        if action == "threshold-tune":
            from .threshold_tuning import options
            run = self.run_path(data.get("run", ""))
            candidate = data.get("candidate", "selected")
            from .decisions import _candidate
            _candidate(run, candidate)
            datasets = data.get("datasets")
            if not isinstance(datasets, list) or not 1 <= len(datasets) <= 100:
                raise ValueError("Add between one and 100 labelled datasets.")
            cleaned = []
            for dataset in datasets:
                if not isinstance(dataset, dict) or not isinstance(dataset.get("path"), str) or not dataset["path"].strip():
                    raise ValueError("Each tuning dataset needs a local folder path.")
                root = self._configured_path(dataset["path"])
                if any(not (root / label).is_dir() for label in ("good", "bad")):
                    raise ValueError("Tuning dataset folders must contain good/ and bad/.")
                trays = dataset.get("trays", [])
                if not isinstance(trays, list) or any(not isinstance(tray, str) for tray in trays):
                    raise ValueError("Selected trays must be a list of tray names.")
                from .dataset_tools import classification_roles
                roles = classification_roles(self.config, root) or {}
                cleaned.append({"name": str(dataset.get("name", root.name)), "path": str(root), "trays": trays,
                                "excluded_trays": [tray for tray, role in roles.items() if role == "excluded"]})
            settings = {"run": str(run), "candidate": candidate, "datasets": cleaned,
                        "options": options(data.get("options")), "device": device}
            output = self.config.parent / "threshold_tuning" / stamp
        else:
            from .pipeline_deployment import load_pipeline
            pipeline = self.checked_output(data.get("pipeline", ""), exists=True)
            load_pipeline(pipeline)
            source = self._configured_path(data.get("input", ""))
            if not data.get("input") or not (source.is_dir() or source.is_file() and source.suffix.lower() == ".zip"):
                raise ValueError("Choose an image folder or ZIP input.")
            output = self.config.parent / "deployment" / "runs" / stamp
            if source.is_dir() and (output.is_relative_to(source) or source.is_relative_to(output)):
                raise ValueError("Deployment results must be outside the source images.")
            settings = {"pipeline": str(pipeline), "input": str(source), "device": device}
            if source.is_dir():
                from .dataset_tools import classification_roles
                roles = classification_roles(self.config, source)
                if roles is not None:
                    settings["tray_roles"] = roles
        self.logs_root.mkdir(parents=True, exist_ok=True)
        request = self.logs_root / (stamp + ".workspace.json")
        write_json(request, {"action": action, "settings": settings, "output": str(output)})
        return [sys.executable, "-u", str(project / "inspection.py"), "_workspace-worker", "--request", str(request)]

    def experiment_history(self):
        with self.lock:
            return self._experiment_history()

    def _experiment_history(self):
        from .dashboard import _read_json
        result = {"tuning": [], "pipelines": [], "deployment": []}
        cache = getattr(self, "_experiment_cache", {})
        active_paths = set()
        for kind, pattern in (("tuning", "threshold_tuning/*/report.json"),
                              ("pipelines", "deployment/pipelines/*/pipeline.json"),
                              ("deployment", "deployment/runs/*/report.json")):
            for path in sorted(self.config.parent.glob(pattern), reverse=True)[:20]:
                if path.is_symlink():
                    continue
                active_paths.add(str(path))
                stat = path.stat()
                stamp = (stat.st_mtime_ns, stat.st_size)
                stored = cache.get(str(path))
                report = stored[1] if stored and stored[0] == stamp else _read_json(path, {})
                if report:
                    curve = report.get("single_curve", [])
                    if len(curve) > 500:
                        import numpy as np
                        report["single_curve"] = [curve[i] for i in np.linspace(0, len(curve) - 1, 500, dtype=int)]
                        report["display_curve_sampled"] = True
                    cache[str(path)] = (stamp, report)
                    # Full results remain in the report and CSV downloads.
                    result[kind].append({"path": str(path), "name": report.get("name") or path.parent.name,
                                         "report": report, "url": self.file_url(path),
                                         "html_url": self.file_url(path.with_name("report.html")) if path.with_name("report.html").is_file() else None})
        self._experiment_cache = {path: value for path, value in cache.items() if path in active_paths}
        return result

    def save_tuned_decision(self, data):
        from .decisions import create_decision
        path = self.checked_output(data.get("report", ""), exists=True)
        if path.name != "report.json" or path.parent.parent != self.config.parent / "threshold_tuning":
            raise ValueError("Choose a recorded threshold tuning report.")
        report = read_json(path)
        if not report.get("complete"):
            raise ValueError("Threshold tuning must complete before saving its decision.")
        best = report["best"]
        arguments = {"candidate": report["candidate"], "output_root": self.config.parent / "decisions"}
        if report["config"]["mode"] == "double":
            arguments.update(mode="triage", good_threshold=best["good_threshold"], bad_threshold=best["bad_threshold"])
        else:
            arguments.update(mode="manual", threshold=best["bad_threshold"])
        decision = create_decision(report["run"], **arguments)
        write_json(Path(decision).with_name("external_tuning.json"), {"report": str(path), "sha256": sha_file(path),
                   "scope": report["source_scope"], "best": best, "datasets": report["datasets"]})
        return {"path": str(decision)}

    def save_deployment_pipeline(self, data):
        from .pipeline_deployment import create_pipeline
        kind = data.get("kind", "decision")
        source = self.checked_output(data.get("source", ""), exists=True)
        expected = {"decision": "decision.json", "system": "decision_system.json", "workflow": "workflow.json"}
        if expected.get(kind) != source.name:
            raise ValueError("Select a saved decision, decision system or workflow.")
        root = self.config.parent / "deployment" / "pipelines" / (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%f") + "_" + uuid.uuid4().hex[:8])
        record = create_pipeline(data.get("name", "VIG pipeline"), kind, source, root)
        return {"path": str(root / "pipeline.json"), "pipeline": record}
