# Start Here

This procedure runs the complete development workflow from labeled image folders. Commands assume the terminal is open in the project directory and the project Python environment is active. Replace example paths with local locations; no source-code editing is required.

## 1. Install the application

Follow [docs/INSTALLATION.md](docs/INSTALLATION.md) for the CPU or GPU environment. Pretrained weight files are provisioned once, separately from training. The laptop profile is intended for pilot work; it does not certify a model for production.

## 2. Configure folders

Edit the supplied `project.yaml`. Set the output and weights locations, then set each enabled task's dataset root. Each task directory must contain `good` and `bad` subdirectories. Images may be nested beneath these class directories.

| Item | Example location |
| --- | --- |
| Top good images | `C:/inspection/data/top/good` |
| Top bad images | `C:/inspection/data/top/bad` |
| Bottom dataset root | `C:/inspection/data/bottom` |
| Vig dataset root | `C:/inspection/data/vig` |
| Result directory | `C:/inspection/results` |
| Local pretrained weights | `C:/inspection/weights` |

Forward slashes work in Windows YAML paths. Relative paths resolve from the configuration file directory. Keep result directories outside all input datasets.

Configure unit grouping before interpreting held-out metrics. Start/final images and repeat views of a physical unit must remain together. Use a `groups_csv` mapping or `group_regex` when a unit has multiple images. Enable `independent_units_confirmed` only after confirming that the declared groups represent independent physical units and that no group spans dataset splits. A group may contain multiple views of the same unit.

Leave `image_size: auto` and `resize: pad` to resolve a square envelope from the input dimensions while preserving pixels. Large images increase memory and execution time. The same envelope is retained for inference.

## 3. Check installation and data

```bash
python inspection.py doctor --config project.yaml --profile laptop --task top
python inspection.py audit --config project.yaml --task top
```

Resolve missing weights, unreadable images, label conflicts, grouping errors, or insufficient held-out class support before training. An audit is read-only with respect to source images.

## 4. Run a pilot, then the full experiment

```bash
python inspection.py run --config project.yaml --profile laptop --task top
```

Record the run directory printed by the command. After the pilot confirms the dataset and workflow, execute the workstation profile in its GPU environment:

```bash
python inspection.py run --config project.yaml --profile workstation --task top
```

Replace `top` with `bottom` or `vig`. Omit `--task` to process all enabled tasks. Windows launchers under `scripts` wrap these commands and require the Python environment to be activated first.

## 5. Review and qualify the selected system

Open the run's HTML report and comparison output. Inspect defect escapes and false rejections in the exported image folders. A selected candidate is not automatically an active release. A target failure is recorded even if one model ranks first.

Use the final test only after the model and threshold are fixed:

```bash
python inspection.py evaluate --run ./results/top/RUN_ID --split final-test
python inspection.py status --config project.yaml
```

See [docs/MODEL_MANAGEMENT.md](docs/MODEL_MANAGEMENT.md) for activation and subsequent updates. A zero observed defect-escape count is not proof of a zero population escape rate.

## 6. Export and transfer

Use [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) to create an ONNX package and run inference on a second computer. Copy the complete package directory. An ONNX file alone does not include the required preprocessing, threshold, or PatchCore memory bank.

The receiving computer needs its own compatible runtime environment. Copying a Python virtual environment between computers or between CPU/GPU builds is not a supported transfer method.
