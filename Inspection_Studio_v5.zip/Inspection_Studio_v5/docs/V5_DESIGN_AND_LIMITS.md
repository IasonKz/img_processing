# Version 5: design and limits

Inspection Studio 5 is an offline-capable inspection-development application. It supports deliberate experiments and traceable local batch decisions; it is not a certified line controller. All accuracy, latency, and production-acceptance claims require measurements on representative customer data and target hardware.

## Implemented scope

| Area | Version 5 behavior |
| --- | --- |
| Image backbones | Pretrained ResNet18/50, EfficientNet-B0/B2, EfficientNetV2-S, MobileNetV3-Large, DenseNet121, ConvNeXt-Tiny, Swin-T |
| Anomaly baseline | Existing PatchCore-style local-feature memory bank |
| Search | Profile presets or validated Custom Optuna contracts; TPE, Random, finite Grid |
| Pruning | None, Median, Successive Halving, Hyperband, plus minimum fine-tuning opportunity |
| Search controls | User-defined total budget with no profile ceiling; trial soft limit, trial count, completed-trial improvement patience, true failure cap |
| Execution | CPU, CUDA, or Auto independent of the preset; editable CPU threads and data-loader workers |
| Image strategy | Native-resolution full-image padding or shared global-plus-overlapping-patch classification |
| Augmentation | Exact quarter-turn VIG rotations during training only |
| Decisions | Single model, triage, compatible weighted ensemble, held-out stacking, cascade, legacy voting |
| Review | Copied-image gallery, original/predicted/human labels, priority review, immutable reviewed-data revision |
| Continuity | Explicit experiment/config lineage, heldout protection, old training replay for updates |

The additional model families are selectable, not a recommendation to train all of them in a two-hour CPU search. Missing weights and invalid input combinations are errors, not invitations to silent fallback.

## What an Optuna contract controls

The contract records architectures, numerical ranges or choices, training settings, the validation objective, sampler/pruner configuration, seeds, stopping conditions, and resource allowance. Presets are editable starting points; total duration has no profile-specific maximum. It is data, not executable code. Supervised image-model optimization can maximize validation bad-class AP, ROC AUC, or balanced accuracy at the fixed 0.5 boundary. PatchCore search requires AP. Changing a decision threshold does not improve the underlying ranking metrics.

The trial search uses train/validation only. Calibration data support decision fitting; selection data provide a separately identified comparison after fitting. The final test is not read by the search. Repeatedly selecting based on the same selection set still makes that set development evidence, not a fresh final test.

See [CUSTOM_OPTUNA.md](CUSTOM_OPTUNA.md) for exact supported fields and stopping semantics. There is no arbitrary neural architecture generator, parallel multi-GPU scheduler, automatic multi-objective Pareto search, or automatic expansion beyond declared ranges.

## Global image plus patches

An image patch is a rectangular view of the input, not a software update or a new labeled training example. `image_strategy: global_patches` uses one shared pretrained classifier to evaluate the complete padded image and exhaustive overlapping local windows. The local branch pools bad-vs-good margins with max or top-k pooling, then mixes local and global margins before the image-level classification loss.

This preserves global VIG structure while exposing local details to the backbone. It does not label every patch of a bad image as bad. It produces image classification, not a verified defect segmentation mask or location annotation.

```yaml
image_strategy: global_patches
patches:
  size: 256
  overlap: 64
  max_patches: 64
  chunk_size: 4
  aggregation: topk
  topk: 3
  global_weight: 0.5
```

This fragment belongs in a resolved configuration/defaults or task overrides; it is not a complete project file. The mode requires `resize: pad`, frozen BatchNorm, and supervised models. It cannot be applied as a second wrapper around PatchCore. The complete source image is retained; grid coverage includes the final edges, and no random patches are silently discarded. Exceeding `max_patches` raises an error. Reduce the number of windows deliberately by changing patch geometry, not by hiding dropped coverage.

The quarter-turn is applied to the image before window generation. Chunking and activation checkpointing limit some intermediate memory, but the global full-resolution branch remains and may still run out of memory. The mode usually costs additional computation and does not guarantee better AP. It has local PyTorch checkpoint/inference support; automatic ONNX export for this multi-view path is not provided.

## Decision systems and uncertainty

A review decision is an abstention, not a third defect class. Low or high scores do not become statistically reliable confidence statements merely because they are far from 0.5. Score thresholds must be checked against labeled evidence.

The weighted route combines comparable supervised scores, or fits per-source logistic score calibration before mixing supervised and PatchCore scores. The stacking route learns a regularized logistic combiner from held-out calibration predictions and standardizes differing score scales. It does not perform automatic grouped out-of-fold retraining of every backbone. Using held-out fitting keeps the base models from training on the meta-training images but reduces the small amount of data available for each decision-development role. Candidate sources must share the exact audited manifest and split assignments.

When fitting a combiner or score calibration, the threshold partition is split into group-disjoint fit and tune subsets; fitting cannot reuse the tune groups. At least four independent groups and both classes in each subset are required, and small samples still trigger caution. A plain uncalibrated single-model triage uses the threshold partition directly. Decision fitting/tuning and selection reporting remain separate. An optimizer result is an empirical development result; it is not a calibrated guarantee or a statistical release certificate. The selection set may already have influenced the choice of source candidates, so its system report is not independent qualification. The final frozen whole system needs explicit independent evaluation.

A cascade routes uncertain images to later stages; a final early acceptance cannot be rescued downstream. Its full-system defect escape, false reject, review workload, and latency must be measured directly. Do not multiply per-model error rates as if model errors were independent.

## Review and fine-tuning

Only explicit human good/bad tags can be promoted. Unknown, unreviewed, and model-only labels are not ground truth. Review exports preserve hashes and provenance. A training-ready export requires a source run and replay of its old partitioned data; old training contributes replay while validation/calibration/selection/test remain protected. New confirmed independent units join training, not the test.

Source images are not moved or overwritten. Overlap with protected groups/content is rejected, and conflicting old training labels require a fresh lineage rather than silently mutating old evidence. A review-only export without lineage can support curation but is not automatically safe for fine-tuning.

## Data and hardware limitations

- Three trays can contain many independent physical units, but unit-level splitting does not establish generalization to an unseen tray or manufacturing batch. Evaluate a new tray separately.
- Rotations and patches do not create new independent units or justify narrower confidence intervals.
- The supplied five-way split needs enough independent examples of both classes. More optimization cannot repair weak or inconsistent reference labels.
- Native image preservation does not guarantee that deep feature maps retain every tiny defect. Inspect actual misses.
- Supported inputs follow the existing 8-bit RGB conversion path; unsupported high-bit-depth inputs fail rather than being silently clipped.
- Sixteen GB VRAM does not guarantee that every architecture/global-patch configuration fits every image size.
- Windows file retries handle transient sharing contention, not permanent permission denial. Do not run as administrator or disable endpoint protection as a blanket fix.

## Explicitly not included

- Non-pretrained image-model training, as requested. Training a new classification head or small logistic meta-classifier is still necessary and is not a randomly initialized image backbone.
- DINOv2 integrations, arbitrary third-party checkpoints, detection, segmentation, and paired before/after damage comparison.
- Automatic full OOF stacking, automatic active-learning retraining without operator review, or automatic pseudo-label acceptance.
- Temperature scaling and isotonic calibration. Optional logistic score calibration is implemented, but calibration quality on future production data is not guaranteed; raw softmax outputs remain scores.
- Automated machine/PLC control, human-review staffing, a latency guarantee, or production certification.
- A single portable ONNX graph for an arbitrary cascade, learned workflow, or global-patch classifier.

See the release verification record for actual executed software checks. Passing tests or creating an export is not a substitute for Windows/GPU target acceptance and representative independent inspection validation.
