# Τεχνικές πηγές και αποφάσεις υλοποίησης

Έλεγχος δημόσιας τεκμηρίωσης: 7 Σεπτεμβρίου 2026.
Οι πηγές τεκμηριώνουν τις αρχιτεκτονικές και τις γενικές μεθόδους, **όχι την
αποτελεσματικότητα αυτού του πακέτου στα δεδομένα NILT**. Αυτή απαιτεί δική σας
εκπαίδευση, ανεξάρτητες παρτίδες και αξιολόγηση.

## S1. PyTorch / torchvision και pretrained CNNs / Swin

- https://docs.pytorch.org/vision/stable/models.html
- https://docs.pytorch.org/vision/stable/models/generated/torchvision.models.resnet50.html
- https://docs.pytorch.org/vision/stable/models/generated/torchvision.models.convnext_tiny.html
- https://docs.pytorch.org/vision/stable/models/generated/torchvision.models.swin_t.html
- https://pytorch.org/get-started/previous-versions/
- https://pytorch.org/get-started/locally/

Χρησιμοποιούνται οι επίσημες torchvision αρχιτεκτονικές και συγκεκριμένα enums
weights, όχι το μεταβαλλόμενο alias DEFAULT. Το τελικό classification head είναι
νέο και εκπαιδεύεται για GOOD=0, BAD=1. Το torchvision αναφέρει ότι τα pretrained
weights μπορεί να έχουν ξεχωριστούς όρους χρήσης· χρειάζεται εταιρικός έλεγχος.

Το ζεύγος torch 2.10.0 / torchvision 0.25.0 υπάρχει στην επίσημη σελίδα εκδόσεων.
Η επιλογή cu126 στον σύντομο οδηγό είναι παράδειγμα, όχι αυτόματη ανίχνευση του driver.
Τα tests εδώ έγιναν με CPU builds του ίδιου ζεύγους.

## S2. DINOv2 backbone μέσω timm

- https://huggingface.co/timm/vit_small_patch14_dinov2.lvd142m
- https://pypi.org/project/timm/1.0.25/

Το model card περιγράφει self-supervised ViT feature backbone, pretrained στο
LVD-142M, με patches 14 και ονομαστική είσοδο 518×518. Το `num_classes=0` επιτρέπει
χρήση ως feature extractor. Η υλοποίηση του πακέτου προσθέτει **δική της** binary
head πάνω σε concatenation CLS / mean patch / max patch features. Αυτό είναι
σχεδιαστική επιλογή για το πείραμα, όχι ισχυρισμός ότι αποτελεί το επίσημο ή
βέλτιστο DINOv2 classification recipe για defects.

Το timm έχει pinned έκδοση 1.0.25. Η εκτέλεση του DINOv2 δεν ελέγχθηκε στο παρόν
runtime, επειδή δεν ήταν εγκατεστημένο το timm και δεν υπήρχε πρόσβαση δικτύου
για εγκατάσταση ή λήψη checkpoints. Δες το TEST_REPORT.md.

## S3. PatchCore αρχή λειτουργίας

- https://anomalib.readthedocs.io/en/stable/markdown/guides/reference/models/image/patchcore.html
- https://openaccess.thecvf.com/content/CVPR2022/html/Roth_Towards_Total_Recall_in_Industrial_Anomaly_Detection_CVPR_2022_paper.html

Η γενική μέθοδος χρησιμοποιεί nominal patch features, coreset memory bank και
nearest-neighbor distances για anomaly scoring. Εδώ υπάρχει **τοπική native
PatchCore-style υλοποίηση**, όχι import του Anomalib ούτε αντιγραφή της πλήρους
επίσημης υλοποίησης. Περιορίζεται το αρχικό pool με random reservoir και κατόπιν
χρησιμοποιείται projected greedy coreset. Υπάρχει image-level reweighting.

Τα συγκεκριμένα memory limits, το sampling και η χρήση του score μόνο ως veto
είναι επιλογές αυτού του πακέτου. Δεν υπονοείται ισότητα benchmark αποτελεσμάτων
με το paper. Δεν παράγονται segmentation masks σε αυτήν τη binary έκδοση.

## S4. Calibration / fusion

- https://scikit-learn.org/stable/modules/calibration.html

Η βαθμονόμηση πρέπει να χρησιμοποιεί δεδομένα ανεξάρτητα από αυτά της εκπαίδευσης
του classifier. Το πακέτο χρησιμοποιεί disjoint calibration split για
regularized logistic calibration και, για τα stacking pairs, regularized
nonnegative logistic fusion. Οι προβλέψεις στο TRAIN δεν χρησιμοποιούνται για
την εκπαίδευση του calibrator / stacker.

Το calibration δεν καθιστά ένα score εγγυημένη πιθανότητα αστοχίας σε μελλοντική
παραγωγή διαφορετικής σύνθεσης ή σε νέο imaging setup. Τα mean/max ensembles
δεν αποκτούν αυτομάτως τέλειο calibration.

## S5. Grouped αξιολόγηση και thresholds

- https://scikit-learn.org/stable/modules/cross_validation.html
- https://scikit-learn.org/stable/modules/classification_threshold.html

Τα correlated samples χρειάζονται κοινό group, ενώ το τελικό test δεν πρέπει να
χρησιμοποιείται για επιλογή μοντέλου ή threshold. Το πακέτο έχει πέντε διακριτούς
ρόλους: train, tune, calibration, selection, test. Αυτός ο συγκεκριμένος
πενταμερής σχεδιασμός και οι default αναλογίες είναι δική μας επιλογή για να
διαχωρίζονται τα βήματα· δεν είναι μοναδική έγκυρη λύση.

Ο έλεγχος hashes δεν αντικαθιστά unit / tray metadata και δεν αποδεικνύει ότι
όλες οι λήψεις διαφορετικών αρχείων ανήκουν σε διαφορετικά κομμάτια.

## S6. Στατιστική αβεβαιότητα μετρημένων σφαλμάτων

- https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.binomtest.html
- https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.beta.html

Το πακέτο υπολογίζει μονόπλευρα exact binomial upper bounds με beta quantiles,
όχι απλώς ένα ποσοστό σφάλματος. Η κάλυψη προϋποθέτει το αντίστοιχο binomial / IID
μοντέλο. Υπάρχει χωριστό group-event statistic, το οποίο αφορά το διαφορετικό
γεγονός «τουλάχιστον ένα BAD escape στο group» και δεν ισούται με image escape rate.
Τα selection bounds είναι περιγραφικά μετά το optimization, όχι ανεξάρτητη
πιστοποίηση του επιλεγμένου policy.

## Τι δεν τεκμηριώνεται από δημόσιες πηγές

Κανένα από τα παραπάνω δεν αποδεικνύει ότι το NILT dataset έχει συγκεκριμένο
recall, ότι το ensemble κερδίζει το ResNet, ότι το PatchCore εντοπίζει κάθε
άγνωστο defect ή ότι επιτρέπεται αυτόματο release εξαρτημάτων. Αυτά δεν δηλώνονται
ως δεδομένα. Το πακέτο είναι ελέγξιμη βάση πειραμάτων και παραμένει σε shadow mode.
