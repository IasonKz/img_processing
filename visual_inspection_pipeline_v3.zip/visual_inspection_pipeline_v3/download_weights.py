"""Optional, explicitly online SETUP script. Never reads or uploads image data.

Run on an internet-connected machine, then copy the resulting weights directory
to the offline workstation. Training/inference always load local files only.
"""
import argparse
from pathlib import Path
from urllib.parse import urlparse
import re

from nilt.common import sha_file, write_json
from nilt.engine import WEIGHTS, torch_modules


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="weights")
    parser.add_argument("--models", nargs="+", choices=list(WEIGHTS), default=list(WEIGHTS))
    args = parser.parse_args()
    torch, tv = torch_modules()
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    manifest = []
    for name in args.models:
        weight = tv.models.get_model_weights(name)[WEIGHTS[name]]
        target = output / f"{name}__{WEIGHTS[name]}.pth"
        original_name = Path(urlparse(weight.url).path).name
        match = re.search(r"-([a-f0-9]+)\.", original_name)
        prefix = match.group(1) if match else None
        if not target.exists():
            tmp = target.with_suffix(".download")
            print(f"Downloading public pretrained weights: {name}", flush=True)
            torch.hub.download_url_to_file(weight.url, str(tmp), hash_prefix=prefix, progress=True)
            tmp.replace(target)
        digest = sha_file(target)
        if prefix and not digest.startswith(prefix):
            raise ValueError(f"Checksum mismatch for {target}; remove that file and download again.")
        manifest.append({"model": name, "weight": WEIGHTS[name], "filename": target.name,
                         "sha256": digest, "source": weight.url})
    write_json(output / "weights_manifest.json", manifest)
    print(f"Ready: {output}")


if __name__ == "__main__":
    main()
