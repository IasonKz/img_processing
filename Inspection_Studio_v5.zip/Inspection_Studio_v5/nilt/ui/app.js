"use strict";
const $ = id => document.getElementById(id);
const escapeHtml = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const number = (v, digits=3) => v === null || v === undefined || v === "" || !Number.isFinite(Number(v)) ? "—" : Number(v).toFixed(digits);
const percent = v => v === null || v === undefined ? "—" : number(100 * Number(v), 1) + "%";
const duration = s => s===null || s===undefined || s==="" || !Number.isFinite(Number(s)) ? "—" : Math.max(0, Math.round(Number(s)/60)) + " min";
let boot, current, live, preview, token, polling = false, lastJobRun = null;
let activeTab = "setup", reviewData = null, reviewPage = 1, reviewLoading = false, reviewQueued = false, reviewItems = [], reviewSelected = null;
let workflowStages = [], workflowRecords = [], reviewSessions = [], reviewSearchTimer = null, workflowDefaultAdded = false, pendingReviewPaths = null;
const descriptions = {
  setup:["Dataset & setup", "CONFIGURATION / DATA INTEGRITY"], search:["Train & search", "DEVELOPMENT / TRAINING"],
  compare:["Compare models", "DEVELOPMENT / EVALUATION"], decision:["Decision explorer", "DEVELOPMENT / DECISION RULES"],
  predict:["Classify images", "INSPECTION / SINGLE MODEL"], workflow:["Inspection workflow", "INSPECTION / MODEL SEQUENCE"],
  review:["Image review", "INSPECTION / PREDICTION AND REFERENCE"], manage:["Models & reports", "ASSETS / REPORTS AND EXPORT"],
  systems:["Decision lab", "DEVELOPMENT / TRIAGE AND MODEL COMBINATION"]
};
function notify(message, error=false) { $("notice").textContent=message; $("notice").className=error?"error":""; $("notice").hidden=false; }
async function api(path, data) {
  const opts = data ? {method:"POST",headers:{"Content-Type":"application/json","X-Inspection-Token":token},body:JSON.stringify(data)} : {};
  const response=await fetch(path,opts), result=await response.json();
  if(!response.ok) throw new Error(result.error || "Request failed");
  return result;
}
function selectOptions(id, items, empty, previous) {
  const element=$(id), old=previous ?? element.value;
  const signature=JSON.stringify(items);
  if(element.dataset.options!==signature){element.innerHTML=items.length ? items.map(item=>`<option value="${escapeHtml(item.value)}">${escapeHtml(item.label)}</option>`).join("") : `<option value="">${escapeHtml(empty)}</option>`;element.dataset.options=signature;}
  if(items.some(item=>item.value===old)) element.value=old;
}
function tab(name) {
  activeTab=name;
  document.querySelectorAll(".tab").forEach(el=>el.classList.toggle("active",el.id==="tab-"+name));
  document.querySelectorAll("nav button").forEach(el=>{el.classList.toggle("active",el.dataset.tab===name);if(el.dataset.tab===name)el.setAttribute("aria-current","page");else el.removeAttribute("aria-current");});
  $("page-title").textContent=descriptions[name][0]; $("page-eyebrow").textContent=descriptions[name][1];
  if(name==="review") refreshReview().catch(e=>notify(e.message,true));
  if(name==="systems" && typeof InspectionV5!=="undefined") InspectionV5.refreshSystems().catch(e=>notify(e.message,true));
}
function setup(data) {
  const firstSetup=!boot;boot=data; token=data.token;
  if(firstSetup&&data.profile&&data.profiles[data.profile]){$("profile").value=data.profile;$("hours").value=data.profiles[data.profile];$("hours").removeAttribute("max");$("predict-device").value=data.profile==="laptop"?"cpu":"cuda";$("workflow-device").value=$("predict-device").value;}
  selectOptions("task",data.tasks.map(value=>({value,label:value.toUpperCase()})),"No task",$("task").value||"vig");
  $("dataset").value=data.datasets[$("task").value]||"";
  $("output").value=data.paths.output; $("weights").value=data.paths.weights;
  $("config-path").textContent="Configuration: "+data.config;
  $("predict-input").value=data.paths.incoming; $("predict-output").value=data.paths.classified;
  $("workflow-input").value=data.paths.incoming; $("workflow-output").value=data.paths.classified;
  $("package-output").value=data.paths.packages + (data.paths.packages.includes("\\")?"\\":"/") + "selected_model";
  $("models").innerHTML=data.models.map(model=>`<label><input type="checkbox" value="${escapeHtml(model)}">${escapeHtml(model)}</label>`).join("");
  profileModels();
  $("connection").textContent="Connected · 127.0.0.1";
  if(typeof InspectionV5!=="undefined") InspectionV5.ready(data);
}
function settings() { return {task:$("task").value,profile:$("profile").value}; }
function profileModels() {
  const defaults=boot.task_models?.[$("task").value]||boot.profile_models?.[$("profile").value]||["resnet18"];
  $("models").querySelectorAll("input").forEach(el=>{el.checked=defaults.includes(el.value);});
}
async function action(name, extra={}) {
  if(["search","audit"].includes(name) && $("dataset").value!==boot.datasets[$("task").value]) throw new Error("Save a configuration copy to apply the changed dataset path first.");
  if(["search","audit"].includes(name) && boot.task_enabled?.[$("task").value]===false) throw new Error("This task is disabled. Save its dataset settings first to enable it in a new configuration copy.");
  if(!["doctor","prepare-weights","audit","search","classify","workflow-run","system-classify","system-evaluate","review-finetune"].includes(name) && !$("run-select").value) throw new Error("Choose an experiment first.");
  const result=await api("/api/action",{action:name,...settings(),run:$("run-select").value,...extra});
  if(["classify","workflow-run","system-classify"].includes(name))pendingReviewPaths=new Set(reviewSessions.map(sessionPath));
  notify("Operation started. Follow its progress and log below.");
  await refresh(); return result;
}
function table(id, columns, rows) {
  const element=$(id);
  if(!rows.length) { element.classList.add("empty");element.textContent="No recorded results yet.";return; }
  element.classList.remove("empty");
  element.innerHTML="<table><thead><tr>"+columns.map(c=>`<th>${escapeHtml(c[0])}</th>`).join("")+"</tr></thead><tbody>"+rows.map(row=>"<tr>"+columns.map(c=>`<td>${escapeHtml(typeof c[1]==="function"?c[1](row):row[c[1]])}</td>`).join("")+"</tr>").join("")+"</tbody></table>";
}
function plot(id, sets, xLabel="Epoch", limits=null) {
  const svg=$(id), all=sets.flatMap(s=>s.points).filter(p=>p.every(Number.isFinite));
  if(!all.length) {svg.innerHTML='<text x="280" y="110" text-anchor="middle">No recorded values yet</text>';return;}
  const left=47,right=541,top=20,bottom=178;
  let xmin=Math.min(...all.map(p=>p[0])), xmax=Math.max(...all.map(p=>p[0])), ymin=limits?limits[0]:Math.min(...all.map(p=>p[1])), ymax=limits?limits[1]:Math.max(...all.map(p=>p[1]));
  if(xmin===xmax) xmax=xmin+1;
  if(ymin===ymax) {ymin=Math.max(0,ymin-.05);ymax+=.05;}
  const X=v=>left+(v-xmin)/(xmax-xmin)*(right-left), Y=v=>bottom-(v-ymin)/(ymax-ymin)*(bottom-top);
  let html="";
  for(let i=0;i<5;i++){const v=ymin+(ymax-ymin)*i/4,y=Y(v);html+=`<line x1="${left}" y1="${y}" x2="${right}" y2="${y}" stroke="#e3eaf0"/><text x="${left-8}" y="${y+4}" text-anchor="end">${number(v,2)}</text>`;}
  for(let i=0;i<5;i++){const v=xmin+(xmax-xmin)*i/4;html+=`<text x="${X(v)}" y="195" text-anchor="middle">${number(v,xLabel==="Epoch"?0:3)}</text>`;}
  sets.forEach((s,i)=>{const pts=s.points.filter(p=>p.every(Number.isFinite));html+=`<polyline points="${pts.map(p=>X(p[0])+","+Y(p[1])).join(" ")}" stroke="${s.color}" stroke-width="2.5" fill="none"/>`;if(pts.length===1)html+=`<circle cx="${X(pts[0][0])}" cy="${Y(pts[0][1])}" r="3" fill="${s.color}"/>`;html+=`<text x="${left+i*170}" y="215" style="fill:${s.color}">${escapeHtml(s.name)}</text>`;});
  svg.innerHTML=html;
}
function chartHistory() {
  const item=$("history-select").value==="__live__" ? [...(current?.histories||[])].sort((a,b)=>b.updated-a.updated)[0] : current?.histories.find(h=>h.name===$("history-select").value), rows=item?.history||[];
  const points=key=>rows.filter(r=>r[key]!==null&&r[key]!==undefined&&r[key]!=="").map(r=>[Number(r.epoch),Number(r[key])]);
  plot("ap-chart",[{name:"Validation AP · bad",color:"#156ae8",points:points("val_pr_auc_bad")}],"Epoch",[0,1]);
  plot("loss-chart",[{name:"Train loss",color:"#156ae8",points:points("train_loss")},{name:"Validation loss",color:"#d17b20",points:points("val_loss")}]);
  const p=item?.progress||{}, last=rows.at(-1)||{};
  $("progress-detail").textContent=[item?.name,p.current_epoch?`Epoch ${p.current_epoch}/${p.total_epochs||"?"}`:null,p.batch?`Batch ${p.batch}/${p.batches||"?"}`:null,last.backbone_lr?`Backbone LR ${Number(last.backbone_lr).toExponential(2)}`:null,last.head_lr?`Head LR ${Number(last.head_lr).toExponential(2)}`:null,(p.stage||last.stage)?`Stage: ${p.stage||last.stage}`:null,p.ram_bytes?`RAM ${number(p.ram_bytes/2**30,2)} GiB`:null,p.vram_bytes?`VRAM ${number(p.vram_bytes/2**30,2)} GiB`:null,p.images_per_second?`${number(p.images_per_second,1)} images/s`:null,p.elapsed_seconds?`Recorded training ${duration(p.elapsed_seconds)}`:null].filter(Boolean).join("   ·   ");
}
function confusion(metrics) {
  if(!metrics||metrics.bad_detected_TP===undefined){$("confusion").className="empty";$("confusion").textContent="No selected candidate.";return;}
  $("confusion").className="cm";
  $("confusion").innerHTML='<div class="axis">True / predicted</div><div class="axis">Predicted bad</div><div class="axis">Predicted good</div><div class="axis">True bad</div>'+`<div class="correct"><strong>${metrics.bad_detected_TP}</strong>Detected · TP</div><div class="wrong"><strong>${metrics.bad_passed_as_good_FN}</strong>Escaped · FN</div>`+'<div class="axis">True good</div>'+`<div class="wrong"><strong>${metrics.good_rejected_as_bad_FP}</strong>Rejected · FP</div><div class="correct"><strong>${metrics.good_accepted_TN}</strong>Accepted · TN</div>`;
}
function renderRun(data) {
  current=data; const s=data.search||{};
  const remaining=s.status==="SEARCHING"&&s.deadline?Math.max(0,s.deadline-Date.now()/1000):s.remaining_seconds;
  $("search-summary").innerHTML=[[s.completed_trials,"Completed trials"],[s.pruned_trials,"Pruned trials"],[duration(remaining),"Time remaining"],[s.current_model||"—","Current architecture"]].map(([v,k])=>`<div><strong>${escapeHtml(v??"—")}</strong><span>${k}</span></div>`).join("");
  $("search-status").textContent=[s.status||data.state.status,s.stop_reason,s.failed_trials?`${s.failed_trials} failed trials`:null].filter(Boolean).join(" · ");
  renderTrials(data.trials);
  const hs=[{value:"__live__",label:"Follow current trial"},...data.histories.map(h=>({value:h.name,label:h.name}))];
  let choose=$("history-select").value;
  if(!hs.some(x=>x.value===choose)) choose="__live__";
  selectOptions("history-select",hs,"No trial history",choose);chartHistory();
  table("candidate-table",[["Candidate","name"],["AP · bad",c=>number(c.selection_metrics?.pr_auc_bad)],["Bad escape",c=>percent(c.selection_metrics?.bad_escape_rate)],["Good reject",c=>percent(c.selection_metrics?.good_reject_rate)],["Balanced acc.",c=>percent(c.selection_metrics?.balanced_accuracy)],["Accuracy",c=>percent(c.selection_metrics?.accuracy)],["Always-good acc.",c=>percent(c.selection_metrics?.always_good_accuracy)],["AP baseline",c=>number(c.selection_metrics?.constant_score_pr_auc_baseline)],["Both targets",c=>c.empirical_target_met?"MET on development splits":"NOT MET"]],data.candidates);
  confusion(data.selected.selection_metrics);
  $("selection-warning").textContent=data.selected.name ? `${data.selected.name}: ${data.selected.status||"Development selection"}. `+(data.selected.empirical_target_met?"Independent qualification is still required.":"The requested error targets are not jointly met. Adjusting a threshold cannot establish missing class separation.") : "A selected model is a development choice. Selection alone is not production qualification.";
  selectOptions("candidate",[{value:"selected",label:"Selected candidate"},...data.candidates.map(c=>({value:c.name,label:c.name}))],"No candidates");
  $("report-links").className=data.reports.length?"":"empty";
  $("report-links").innerHTML=data.reports.length?data.reports.map(r=>`<a class="report-link" href="${escapeHtml(r.url)}" target="_blank" rel="noopener">↗ ${escapeHtml(r.name)}</a>`).join(""):"No HTML reports saved yet.";
  $("run-path").textContent=data.path;
  const splitRows=Object.entries(data.splits).filter(([name,value])=>!name.startsWith("_")&&value.images).map(([name,value])=>({split:name,...value}));
  table("split-view",[["Split","split"],["Good images",r=>r.images.good||0],["Bad images",r=>r.images.bad||0],["Physical groups","groups"],["Trays",r=>Object.keys(r.trays||{}).join(", ")]],splitRows);
  if(typeof InspectionV5!=="undefined") InspectionV5.runChanged(data);
  if(typeof Analytics!=="undefined") Analytics.render(data);
}
async function loadRun() {
  const run=$("run-select").value;
  if(!run) return;
  const data=await api("/api/run?"+new URLSearchParams({run}));renderRun(data);
}
async function refresh() {
  if(polling) return; polling=true;
  try {
    live=await api("/api/state");
    const old=$("run-select").value;
    selectOptions("run-select",live.runs.map(r=>({value:r.path,label:`${r.task||"?"} · ${r.name} · ${r.status}`})),"Choose an experiment",old);
    const job=live.jobs.at(-1), running=live.jobs.find(j=>["running","unverified"].includes(j.status));
    if(job?.run && job.run!==lastJobRun && live.runs.some(r=>r.path===job.run)){ $("run-select").value=job.run;lastJobRun=job.run;preview=null; }
    $("active-job").hidden=!running;
    if(running){$("job-title").textContent=running.action;$("job-meta").textContent=running.status==="unverified"?"Worker status could not be verified. Check the operation log before starting another job.":duration(Date.now()/1000-running.started)+(running.pause_requested?" · Pause requested":"")+(running.detached?" · Reconnected worker":"");$("pause").hidden=!["search","resume-search"].includes(running.action);$("pause").disabled=!!running.pause_requested;}
    if(job){const log=$("console"), nearBottom=log.scrollHeight-log.scrollTop-log.clientHeight<70;log.textContent=job.lines.join("\n")||"Starting Python worker…";if(nearBottom)log.scrollTop=log.scrollHeight;$("log-status").textContent=`${job.action} · ${job.status}${job.exit_code!==undefined?" · exit "+job.exit_code:""}`;}
    selectOptions("decision-select",live.decisions.map(d=>({value:d.path,label:`${d.candidate||"model"} · ${d.mode}${d.threshold!==null&&d.threshold!==undefined?" · "+number(d.threshold,6):""} · ${d.name}`})),"Save a decision first");
    selectOptions("package-decision",[{value:"",label:"Run's original selected decision"},...live.decisions.filter(d=>d.source_run===$("run-select").value).map(d=>({value:d.path,label:`${d.candidate||"model"} · ${d.mode}${d.threshold!==null&&d.threshold!==undefined?" · "+number(d.threshold,6):""} · ${d.name}`}))],"Run's original selected decision");
    workflowRecords=live.workflows||await api("/api/workflows");
    reviewSessions=live.review_sessions||await api("/api/review-sessions");
    updateInspectionLists();
    if(typeof InspectionV5!=="undefined") InspectionV5.stateChanged(live);
    if(activeTab==="review"&&$("review-live").checked&&!$("image-dialog").open)await refreshReview();
    await loadRun(); $("connection").textContent="Connected · updated "+new Date().toLocaleTimeString();
  } catch(error){$("connection").textContent="Connection issue: "+error.message;} finally {polling=false;}
}
function modeChanged() {
  const mode=$("decision-mode").value;
  $("threshold-controls").hidden=mode!=="manual";
  $("mode-help").textContent={policy:"The policy fits calibration data. If both targets are infeasible, the result remains TARGET_NOT_MET.",manual:"Your threshold applies to this score scale. score ≥ threshold means bad. Saving creates a new decision version.",argmax:"Standard two-class classification uses the larger output. Equal softmax scores are treated as bad.",scores_only:"Scores are exported without class decisions. No confusion matrix or classification accuracy is calculated."}[mode];
  if(preview) updatePreview();
}
function activeThreshold() {
  const mode=$("decision-mode").value;
  return mode==="scores_only"?null:mode==="argmax"?.5:mode==="policy"?preview?.policy_decision?.threshold:Number($("threshold").value);
}
function updatePreview() {
  if(!preview) return;
  const mode=$("decision-mode").value, threshold=activeThreshold();
  if(mode==="argmax" && preview.score_type==="anomaly_distance") {$("preview-summary").textContent="Argmax does not apply to PatchCore anomaly scores. Choose policy, manual threshold or scores only.";$("gallery").textContent="";return;}
  const rows=preview.rows, nb=rows.filter(r=>r.true_class==="bad").length, ng=rows.length-nb;
  let fn=0,fp=0;
  for(const r of rows){if(r.true_class==="bad"&&r.score<threshold)fn++;if(r.true_class==="good"&&r.score>=threshold)fp++;}
  $("preview-summary").className="";
  $("preview-summary").innerHTML=threshold===null?`<p>${rows.length} calibration scores. Scores-only mode makes no good/bad decision.</p>`:`<div class="stats-grid">${[[percent(nb?fn/nb:null),"Bad escape"],[percent(ng?fp/ng:null),"Good reject"],[percent(nb&&ng?1-(fn/nb+fp/ng)/2:null),"Balanced accuracy"],[number(threshold,6),"Threshold"]].map(([v,k])=>`<div><strong>${v}</strong><span>${k}</span></div>`).join("")}</div><p class="hint">${fn} / ${nb} bad accepted · ${fp} / ${ng} good rejected · calibration only</p>`;
  plot("threshold-chart",[{name:"Bad escape",color:"#156ae8",points:preview.curve.map(r=>[r.threshold,r.bad_escape_rate])},{name:"Good reject",color:"#d17b20",points:preview.curve.map(r=>[r.threshold,r.good_reject_rate])}],"Threshold",[0,1]);
  const filter=$("gallery-filter").value;
  let gallery=rows.map(r=>({...r,predicted:threshold===null?null:r.score>=threshold?"bad":"good"}));
  if(filter==="errors") gallery=gallery.filter(r=>r.predicted&&r.predicted!==r.true_class);
  else if(filter!=="all") gallery=gallery.filter(r=>r.true_class===filter);
  gallery=gallery.slice(0,60);$("gallery").className="gallery"+(gallery.length?"":" empty");
  $("gallery").innerHTML=gallery.length?gallery.map(r=>`<div class="image-card">${r.image_url?`<a href="${escapeHtml(r.image_url)}" target="_blank" rel="noopener"><img src="${escapeHtml(r.image_url)}" alt="${escapeHtml(r.relative_path)}" loading="lazy"></a>`:"<div class='empty'>Image unavailable at configured path</div>"}<div class="image-caption ${r.predicted&&r.predicted!==r.true_class?"error":""}"><b>True ${escapeHtml(r.true_class)}${r.predicted?" → "+r.predicted:""}</b>Score ${number(r.score,5)}<br>${escapeHtml(r.relative_path)}</div></div>`).join(""):"No images match this filter. Scores-only mode has no decision errors.";
}
async function loadPreview() {
  if(!$("run-select").value) throw new Error("Choose a finalized experiment first.");
  preview=await api("/api/preview?"+new URLSearchParams({run:$("run-select").value,candidate:$("candidate").value}));
  const scores=preview.rows.map(r=>r.score), lo=Math.min(...scores), hi=Math.max(...scores), span=Math.max(hi-lo,1e-6), slider=$("threshold-slider");
  slider.min=String(lo-span*.01);slider.max=String(hi+span*.01);slider.step=String(span/1000);
  $("threshold").value=String(preview.threshold);slider.value=String(preview.threshold);updatePreview();
}
function renderTrials(rows) {
  const host=$("trials-table"), opened=new Set([...host.querySelectorAll("details[open]")].map(e=>e.dataset.trial));
  if(!rows.length){host.className="table-scroll empty";host.textContent="No trials recorded yet.";return;}
  host.className="table-scroll";
  host.innerHTML='<table><thead><tr><th>Architecture</th><th>Trial</th><th>Status</th><th>Outcome / details</th><th>Objective value</th><th>Validation AP</th><th>Time</th></tr></thead><tbody>'+rows.map(r=>{
    const failure=r.failure||{}, key=r.model+":"+r.trial, err=failure.error||r.error, timeout=["TIMEOUT","TIMEOUT_RESUMABLE"].includes(r.outcome), failed=!timeout&&(["FAIL","FAILED"].includes(r.state)||r.outcome==="FAILED");
    const details=failed?`<details data-trial="${escapeHtml(key)}" ${opened.has(key)?"open":""}><summary>Failure details</summary><p>${escapeHtml(err||"This trial ended with an execution error. Open its failure.json in the experiment folder for the recorded exception.")}</p>${failure.traceback?`<pre>${escapeHtml(failure.traceback)}</pre>`:""}${failure.url?`<a href="${escapeHtml(failure.url)}" target="_blank" rel="noopener">Open failure record</a>`:""}</details>`:"";
    const objective=r.objective||current?.search?.objective||"validation_ap",objectiveLabel={validation_ap:"AP · bad",validation_roc_auc:"ROC AUC · bad",validation_balanced_accuracy:"Balanced accuracy · 0.5"}[objective]||objective;
    return `<tr><td>${escapeHtml(r.model)}</td><td>${escapeHtml(r.trial)}</td><td><span class="status-badge ${failed?"status-error":timeout?"label-review":r.state==="COMPLETE"?"status-good":r.state==="RUNNING"?"status-active":"status-neutral"}">${escapeHtml(timeout?r.outcome:r.state)}</span></td><td>${escapeHtml(r.outcome||"—")}${timeout?"<p class='hint'>Time budget reached; not a model-quality failure.</p>":""}${details}</td><td>${number(r.value)}<p class="hint">${escapeHtml(objectiveLabel)}</p></td><td>${number(r.validation_ap??(objective==="validation_ap"?r.value:null))}</td><td>${duration(r.seconds)}</td></tr>`;
  }).join("")+"</tbody></table>";
}
const classBadge=label=>`<span class="class-badge ${label==="bad"?"label-bad":label==="good"?"label-good":label==="review"?"label-review":"label-unknown"}">${escapeHtml(label||"Unlabeled")}</span>`;
const decisionLabel=d=>`${d.candidate||d.name||"Model"} · ${d.mode}${d.threshold!==null&&d.threshold!==undefined?" · threshold "+number(d.threshold,6):""}`;
const sessionPath=s=>s.path||s.session_path||s.id;
const sessionLabel=s=>`${s.name||s.path?.split(/[\\/]/).pop()||s.id} · ${s.kind||"classification"} · ${s.status||s.progress?.status||"recorded"}`;
function updateInspectionLists() {
  selectOptions("workflow-select",workflowRecords.map(w=>({value:w.path,label:`${w.name||"Recipe"} · ${w.stages?.length||0} stages · ${w.rule}`})),"No saved recipes");
  renderSavedWorkflow();
  selectOptions("review-session",reviewSessions.map(s=>({value:sessionPath(s),label:sessionLabel(s)})),"No classification or workflow sessions");
  if(pendingReviewPaths){const created=reviewSessions.find(s=>!pendingReviewPaths.has(sessionPath(s)));if(created){$("review-session").value=sessionPath(created);reviewPage=1;pendingReviewPaths=null;}}
  const choices=$("session-compare-options"), selected=new Set([...choices.querySelectorAll("input:checked")].map(e=>e.value));
  const completedSessions=reviewSessions.filter(s=>(s.status||s.progress?.status)==="completed");
  const signature=JSON.stringify(completedSessions.map(s=>[sessionPath(s),s.status,s.progress?.status]));
  if(choices.dataset.sessions!==signature){
    choices.dataset.sessions=signature;choices.className="comparison-options"+(completedSessions.length?"":" empty");
    choices.innerHTML=completedSessions.length?completedSessions.map((s,i)=>`<label class="checkbox"><input type="checkbox" id="compare-session-${i}" value="${escapeHtml(sessionPath(s))}" ${selected.has(sessionPath(s))?"checked":""}>${escapeHtml(sessionLabel(s))}</label>`).join(""):"No completed inspection sessions available.";
  }
  if(!workflowDefaultAdded&&live.decisions.length){workflowDefaultAdded=true;workflowStages.push({name:"Stage 1",decision:live.decisions.find(d=>d.mode!=="scores_only")?.path||""});renderWorkflowStages();}
}
function workflowRuleDescription() {
  const rule=$("workflow-rule").value;
  $("workflow-rule-help").textContent={any_bad:"Reject cascade: a bad prediction rejects the image immediately. Good images continue to the next stage. An image is accepted only after all stages pass.",all_bad:"Accept cascade: a good prediction accepts the image immediately. Bad predictions continue to the next stage. An image is rejected only when every stage predicts bad.",majority:"Voting sequence: every stage evaluates every image. The class with more votes wins. A tied vote produces a bad decision."}[rule];
  renderWorkflowFlow();
}
function renderWorkflowStages() {
  const decisions=(live?.decisions||[]).filter(d=>d.mode!=="scores_only");
  $("workflow-stages").innerHTML=workflowStages.length?workflowStages.map((stage,i)=>{
    const record=decisions.find(d=>d.path===stage.decision);
    return `<div class="workflow-stage" data-stage="${i}"><div class="stage-number">${i+1}</div><div class="stage-body"><label>Stage name<input data-stage-name="${i}" value="${escapeHtml(stage.name)}" maxlength="120" aria-label="Stage ${i+1} name"></label><label>Saved decision<select data-stage-decision="${i}" aria-label="Stage ${i+1} decision"><option value="">Select a saved decision</option>${decisions.map(d=>`<option value="${escapeHtml(d.path)}" ${d.path===stage.decision?"selected":""}>${escapeHtml(decisionLabel(d))} · ${escapeHtml(d.name||"")}</option>`).join("")}</select></label><p class="hint">${record?escapeHtml(record.source_run||record.path):"Save a policy, manual or argmax decision in Decision explorer first."}</p></div><div class="stage-controls"><button class="secondary small" data-stage-up="${i}" ${i===0?"disabled":""} aria-label="Move stage ${i+1} up">↑</button><button class="secondary small" data-stage-down="${i}" ${i===workflowStages.length-1?"disabled":""} aria-label="Move stage ${i+1} down">↓</button><button class="secondary small" data-stage-remove="${i}" aria-label="Remove stage ${i+1}">×</button></div></div>`;
  }).join(""):"<div class='empty'>Add a model stage to start the inspection sequence.</div>";
  workflowRuleDescription();
}
function renderWorkflowFlow() {
  const rule=$("workflow-rule").value, stop=rule==="any_bad"?"Bad → reject":rule==="all_bad"?"Good → accept":"Record vote";
  $("workflow-flow").innerHTML='<div class="flow-node flow-terminal">Input images</div>'+workflowStages.map((s,i)=>`<div class="flow-connector" aria-hidden="true">↓</div><div class="flow-node"><span>${i+1}. ${escapeHtml(s.name||"Model stage")}</span><small>${stop}</small></div>`).join("")+'<div class="flow-connector" aria-hidden="true">↓</div><div class="flow-node flow-terminal">'+(rule==="any_bad"?"All passed → good":rule==="all_bad"?"All rejected → bad":"Count votes → final class")+'</div><p class="hint">Every result records the evaluated and skipped stages.</p>';
}
function renderSavedWorkflow() {
  const record=workflowRecords.find(w=>w.path===$("workflow-select").value), host=$("workflow-saved-info");
  if(!record){host.textContent="Save a recipe to inspect its frozen stages.";return;}
  host.innerHTML=`<p><b>${escapeHtml(record.name)}</b> · ${escapeHtml(record.rule)} · ${escapeHtml(record.qualification_status||"Development recipe")}</p><ol class="saved-stage-list">${(record.stages||[]).map(s=>`<li><b>${escapeHtml(s.name)}</b><br>${escapeHtml(s.candidate||s.kind||"Model")} · ${escapeHtml(s.mode||"saved decision")}${s.threshold!==null&&s.threshold!==undefined?" · threshold "+number(s.threshold,6):""}</li>`).join("")}</ol>`;
}
async function refreshReview() {
  if(reviewLoading){reviewQueued=true;return;}
  const session=$("review-session").value;if(!session)return;
  reviewLoading=true;
  try {
    const query=new URLSearchParams({session,page:String(reviewPage),page_size:"24",prediction:$("review-prediction").value,reference:$("review-reference").value,review:$("review-label-filter").value,search:$("review-search").value});
    if($("review-sort"))query.set("sort",$("review-sort").value);
    if($("review-errors").checked)query.set("errors_only","true");
    const data=await api("/api/review?"+query);
    if(session!==$("review-session").value)return;
    reviewData=data;reviewItems=data.items||[];
    const p=data.progress||{}, page=data.pagination||{};
    $("review-status").textContent=`${p.status||"Recorded"} · ${p.completed??reviewItems.length} / ${p.total??"?"} images processed`;
    $("review-progress").max=Math.max(1,p.total||1);$("review-progress").value=p.completed||0;
    $("review-read-warning").hidden=!data.read_warning;$("review-read-warning").textContent=data.read_warning||"";
    $("review-page").textContent=`Page ${page.page||reviewPage} of ${Math.max(1,page.pages||1)}`;
    $("review-previous").disabled=reviewPage<=1;$("review-next").disabled=reviewPage>=Math.max(1,page.pages||1);
    $("review-count").textContent=`${page.total??reviewItems.length} matching images · click an image to inspect at full resolution`;
    renderReviewMetrics();renderReviewGallery();
  } finally {reviewLoading=false;if(reviewQueued){reviewQueued=false;queueMicrotask(()=>refreshReview().catch(e=>notify(e.message,true)));}}
}
function renderReviewMetrics() {
  if(!reviewData)return;
  const source=$("review-metric-source").value, m=reviewData.metrics?.[source]||{};
  $("review-summary").innerHTML=[[m.n_total??m.n??0,"Images in reference view"],[percent(m.selective_accuracy??m.accuracy),"Accuracy · automated only"],[percent(m.bad_escape_rate),"Bad escape · all bad"],[percent(m.good_reject_rate),"Good reject · all good"],[percent(m.decision_coverage),"Automated coverage"],[percent(m.review_rate),"Manual review"]].map(([value,label])=>`<div><strong>${escapeHtml(value)}</strong><span>${label}</span></div>`).join("");
  $("review-metric-note").textContent=source==="reviewed_only"?"Measured against human-reviewed labels only. Review can focus on difficult images, so this subset may not represent the complete dataset.":source==="effective_reference"?"Human review overrides the original dataset label for this view only. Images without either label are excluded. Original labels remain unchanged.":"Measured against original dataset labels across this session. Unlabeled images and missing predictions are excluded. Gallery filters do not change these metrics.";
  $("review-metric-note").textContent+=" Accuracy is conditional on automated decisions. REVIEW is abstention, never a correct classification. Escape/reject rates use all labeled images of the corresponding true class.";
  const host=$("review-confusion");
  if(!m.n){host.className="empty";host.textContent="No labeled predictions for this reference source.";return;}
  host.className="cm";
  host.innerHTML='<div class="axis">Reference / prediction</div><div class="axis">Predicted bad</div><div class="axis">Predicted good</div><div class="axis">Reference bad</div>'+`<div class="correct"><strong>${escapeHtml(m.bad_detected_TP??0)}</strong>Detected · TP</div><div class="wrong"><strong>${escapeHtml(m.bad_passed_as_good_FN??0)}</strong>Escaped · FN</div>`+'<div class="axis">Reference good</div>'+`<div class="wrong"><strong>${escapeHtml(m.good_rejected_as_bad_FP??0)}</strong>Rejected · FP</div><div class="correct"><strong>${escapeHtml(m.good_accepted_TN??0)}</strong>Accepted · TN</div>`;
  if(m.n_review)host.innerHTML+=`<div class="review-counts">Sent to REVIEW: ${escapeHtml(m.bad_sent_to_review??0)} bad · ${escapeHtml(m.good_sent_to_review??0)} good. ${escapeHtml(m.n_unavailable??0)} results unavailable.</div>`;
}
function renderReviewGallery() {
  const host=$("review-gallery"), signature=JSON.stringify(reviewItems);
  if(host.dataset.items===signature)return;host.dataset.items=signature;
  host.className="review-gallery"+(reviewItems.length?"":" empty");
  host.innerHTML=reviewItems.length?reviewItems.map((item,i)=>`<button type="button" class="review-card ${item.reference_mismatch?"mismatch":""}" data-review-index="${i}" aria-label="Review ${escapeHtml(item.relative_path)}"><div class="review-thumbnail">${item.image_url?`<img src="${escapeHtml(item.image_url)}" alt="${escapeHtml(item.relative_path)}" loading="lazy">`:'<span>Preview unavailable</span>'}${item.reference_mismatch?'<span class="mismatch-flag">Mismatch</span>':""}${item.status==="input_error"?'<span class="mismatch-flag">Input error</span>':""}</div><div class="review-card-body"><strong title="${escapeHtml(item.relative_path)}">${escapeHtml(item.relative_path)}</strong><div><span>Prediction</span>${classBadge(item.prediction||"No decision")}</div><div><span>Dataset tag</span>${classBadge(item.reference_label)}</div><div><span>Human review</span>${classBadge(item.review?.label==="unreviewed"?"Unreviewed":item.review?.label||"Unreviewed")}</div><small>${item.bad_score!==null&&item.bad_score!==undefined?"Score "+number(item.bad_score,5):item.stage_results?.length?item.stage_results.length+" recorded stages":"No classification score"}</small></div></button>`).join(""):"No images match these filters. Adjust the filters or wait for more results.";
}
function openImage(index) {
  const item=reviewItems[index];if(!item)return;reviewSelected={...item,session:$("review-session").value};
  $("image-title").textContent=item.relative_path||"Image details";
  $("image-large").src=item.image_url||"";$("image-large").hidden=!item.image_url;$("image-large").alt=item.relative_path||"Inspection image";
  $("image-original-link").href=item.image_url||"#";$("image-original-link").hidden=!item.image_url;$("image-viewport").classList.remove("native-size");
  $("image-labels").innerHTML=`<div><span>Model prediction</span>${classBadge(item.prediction||"No decision")}</div><div><span>Original dataset tag</span>${classBadge(item.reference_label)}</div><div><span>Recorded human review</span>${classBadge(item.review?.label||"Unreviewed")}</div>`;
  $("image-path").textContent=item.copied_path?"Copied image: "+item.copied_path:"No copied image is recorded for this result. Enable image copying for visual review.";
  $("image-review-label").value=item.review?.label||"unreviewed";$("image-review-note").value=item.review?.note||"";
  $("image-save-status").textContent="Review does not change the model prediction or dataset tag.";
  const stages=item.stage_results||[];
  $("image-trace").innerHTML=(item.error?`<p class="callout">${escapeHtml(item.error)}</p>`:"")+`<h3>Decision trace</h3>`+(stages.length?`<ol class="trace-list">${stages.map(s=>`<li class="${s.status==="skipped"?"trace-skipped":""}"><b>${escapeHtml(s.name||s.stage_name||s.candidate||"Stage "+(Number(s.index||0)+1))}</b><span>${escapeHtml(s.status||"evaluated")} ${s.predicted_class?" · "+escapeHtml(s.predicted_class):""}</span>${s.score!==undefined&&s.score!==null?`<small>Score ${number(s.score,6)}${s.threshold!==undefined&&s.threshold!==null?" · threshold "+number(s.threshold,6):""}</small>`:""}${s.reason?`<small>${escapeHtml(s.reason)}</small>`:""}</li>`).join("")}</ol>`:`<p class="hint">Single model${item.bad_score!==null&&item.bad_score!==undefined?" · score "+number(item.bad_score,6):""}. The saved decision defines the classification rule.</p>`);
  $("image-dialog").showModal();
}
function bind(id,fn){$(id).addEventListener("click",async()=>{const button=$(id);if(button.disabled)return;button.disabled=true;try{await fn();}catch(error){notify(error.message,true);}finally{button.disabled=id==="review-previous"?reviewPage<=1:id==="review-next"?reviewPage>=Math.max(1,reviewData?.pagination?.pages||1):id==="system-evaluate"?!$("system-test-ack").checked||!$("system-saved").value:false;}});}
document.querySelectorAll("nav button").forEach(button=>button.addEventListener("click",()=>tab(button.dataset.tab)));
$("task").addEventListener("change",()=>{$("dataset").value=boot.datasets[$("task").value]||"";profileModels();});
$("profile").addEventListener("change",()=>{const h=boot.profiles[$("profile").value];$("hours").removeAttribute("max");$("hours").value=h;profileModels();});
$("run-select").addEventListener("change",async()=>{preview=null;$("preview-summary").textContent="Load scores for this candidate.";$("gallery").textContent="";try{await loadRun();}catch(e){notify(e.message,true);}});
$("history-select").addEventListener("change",chartHistory);
$("decision-mode").addEventListener("change",modeChanged);
$("candidate").addEventListener("change",()=>{preview=null;$("preview-summary").textContent="Load scores for this candidate.";$("gallery").textContent="";});
$("gallery-filter").addEventListener("change",updatePreview);
$("threshold-slider").addEventListener("input",()=>{$("threshold").value=$("threshold-slider").value;updatePreview();});
$("threshold").addEventListener("input",()=>{$("threshold-slider").value=$("threshold").value;updatePreview();});
bind("save-config",async()=>{setup(await api("/api/config",{task:$("task").value,profile:$("profile").value,dataset:$("dataset").value,output:$("output").value,weights:$("weights").value}));notify("Saved a new configuration copy. The original configuration is unchanged.");await refresh();});
bind("doctor",()=>action("doctor"));bind("audit",()=>action("audit"));
bind("download-weights",()=>action("prepare-weights",{models:[...$("models").querySelectorAll("input:checked")].map(e=>e.value)}));
bind("load-run",async()=>{const path=$("load-run-path").value.trim();if(!path)throw new Error("Enter the experiment folder path.");const result=await api("/api/load-run",{path});await refresh();const run=result.run?.path||path;$("run-select").value=run;await loadRun();notify("Experiment loaded. Recorded results are available in the workspace.");});
bind("start-search",async()=>{const extra=typeof InspectionV5!=="undefined"?InspectionV5.searchPayload():{};await action("search",{models:[...$("models").querySelectorAll("input:checked")].map(e=>e.value),hours:Number($("hours").value),...extra});tab("search");});
bind("resume-search",()=>action("resume-search"));
bind("pause",async()=>{const result=await api("/api/pause",{run:$("run-select").value});notify(result.message);await refresh();});
bind("pause-selected",async()=>{const result=await api("/api/pause",{run:$("run-select").value});notify(result.message);await refresh();});
bind("refresh",refresh);
bind("finalize-search",()=>action("finalize-search"));
bind("load-preview",loadPreview);
bind("save-decision",async()=>{if($("decision-mode").value==="argmax"&&preview?.score_type==="anomaly_distance")throw new Error("PatchCore needs policy, manual threshold or scores only.");await action("decision",{mode:$("decision-mode").value,candidate:$("candidate").value,threshold:Number($("threshold").value),output:boot.paths.decisions});});
bind("classify",async()=>{if(typeof InspectionV5!=="undefined"&&$("classify-source").value==="system")return InspectionV5.classifySystem();if(!$("decision-select").value)throw new Error("Save or select a decision first.");await action("classify",{decision:$("decision-select").value,input:$("predict-input").value,output:$("predict-output").value,device:$("predict-device").value,labeled:$("labeled").checked,copy_images:$("copy-images").checked});tab("review");});
bind("refresh-report",()=>action("report"));
bind("open-folder",async()=>{if(!$("run-select").value)throw new Error("Choose an experiment first.");const result=await api("/api/open-folder",{path:$("run-select").value});notify(result.message);});
$("package-kind").addEventListener("change",()=>{$("package-decision").disabled=$("package-kind").value!=="inference";if($("package-decision").disabled)$("package-decision").value="";});
bind("package",()=>action("package",{output:$("package-output").value,kind:$("package-kind").value,decision:$("package-decision").value}));

$("workflow-rule").addEventListener("change",workflowRuleDescription);
$("workflow-select").addEventListener("change",renderSavedWorkflow);
$("workflow-stages").addEventListener("input",event=>{const i=event.target.dataset.stageName;if(i!==undefined){workflowStages[Number(i)].name=event.target.value;renderWorkflowFlow();}});
$("workflow-stages").addEventListener("change",event=>{const i=event.target.dataset.stageDecision;if(i!==undefined){workflowStages[Number(i)].decision=event.target.value;renderWorkflowStages();}});
$("workflow-stages").addEventListener("click",event=>{
  const button=event.target.closest("button");if(!button)return;
  if(button.dataset.stageRemove!==undefined)workflowStages.splice(Number(button.dataset.stageRemove),1);
  else if(button.dataset.stageUp!==undefined){const i=Number(button.dataset.stageUp);[workflowStages[i-1],workflowStages[i]]=[workflowStages[i],workflowStages[i-1]];}
  else if(button.dataset.stageDown!==undefined){const i=Number(button.dataset.stageDown);[workflowStages[i+1],workflowStages[i]]=[workflowStages[i],workflowStages[i+1]];}
  renderWorkflowStages();
});
bind("workflow-add",()=>{workflowStages.push({name:"Stage "+(workflowStages.length+1),decision:""});renderWorkflowStages();});
bind("workflow-clear",()=>{workflowStages=[];renderWorkflowStages();});
bind("workflow-save",async()=>{
  if(!$("workflow-name").value.trim())throw new Error("Enter a recipe name.");
  if(!workflowStages.length||workflowStages.some(s=>!s.decision||!s.name.trim()))throw new Error("Choose a saved decision and a name for every stage.");
  const result=await api("/api/workflows",{definition:{name:$("workflow-name").value.trim(),task:$("task").value,rule:$("workflow-rule").value,stages:workflowStages.map(s=>({name:s.name.trim(),decision:s.decision}))}});
  await refresh();$("workflow-select").value=result.path;renderSavedWorkflow();notify("New inspection recipe saved. Its stages and decision versions are frozen.");
});
bind("workflow-edit-copy",()=>{
  const record=workflowRecords.find(w=>w.path===$("workflow-select").value);if(!record)throw new Error("Select a saved recipe first.");
  $("workflow-name").value=(record.name||"Inspection")+" revision";$("workflow-rule").value=record.rule;
  workflowStages=(record.stages||[]).map(s=>({name:s.name,decision:s.source_decision||s.decision||s.decision_file}));renderWorkflowStages();
  notify("Recipe copied into the draft. Saving creates a separate recipe.");
});
bind("workflow-run",async()=>{
  if(!$("workflow-select").value)throw new Error("Select a saved recipe first.");
  await action("workflow-run",{workflow:$("workflow-select").value,input:$("workflow-input").value,output:$("workflow-output").value,device:$("workflow-device").value,labeled:$("workflow-labeled").checked,copy_images:$("workflow-copy").checked});tab("review");
});
bind("workflow-review",()=>tab("review"));
bind("review-refresh",async()=>{reviewSessions=await api("/api/review-sessions");updateInspectionLists();await refreshReview();});
$("review-session").addEventListener("change",()=>{reviewPage=1;refreshReview().catch(e=>notify(e.message,true));});
["review-prediction","review-reference","review-label-filter","review-errors"].forEach(id=>$(id).addEventListener("change",()=>{reviewPage=1;refreshReview().catch(e=>notify(e.message,true));}));
$("review-search").addEventListener("input",()=>{clearTimeout(reviewSearchTimer);reviewSearchTimer=setTimeout(()=>{reviewPage=1;refreshReview().catch(e=>notify(e.message,true));},300);});
$("review-metric-source").addEventListener("change",renderReviewMetrics);
bind("review-previous",async()=>{reviewPage=Math.max(1,reviewPage-1);await refreshReview();});
bind("review-next",async()=>{reviewPage++;await refreshReview();});
$("review-gallery").addEventListener("click",event=>{const card=event.target.closest("[data-review-index]");if(card)openImage(Number(card.dataset.reviewIndex));});
bind("image-close",()=>$("image-dialog").close());
bind("image-fit",()=>$("image-viewport").classList.remove("native-size"));
bind("image-native",()=>$("image-viewport").classList.add("native-size"));
bind("image-save-review",async()=>{
  if(!reviewSelected)return;
  await api("/api/review-label",{session:reviewSelected.session,item_id:reviewSelected.id,label:$("image-review-label").value,note:$("image-review-note").value});
  $("image-save-status").textContent="Human review saved. Original dataset tag and prediction retained.";
  $("image-labels").lastElementChild.innerHTML='<span>Recorded human review</span>'+classBadge($("image-review-label").value);
  await refreshReview();
});
bind("session-compare",async()=>{
  const sessions=[...$("session-compare-options").querySelectorAll("input:checked")].map(e=>e.value);
  if(sessions.length<2||sessions.length>4)throw new Error("Select between two and four completed sessions.");
  const result=await api("/api/review-compare",{sessions});
  table("session-compare-result",[["Session",s=>s.name||s.path],["Kind","kind"],["Accuracy",s=>percent(s.metrics?.accuracy)],["Balanced accuracy",s=>percent(s.metrics?.balanced_accuracy)],["Bad escape",s=>percent(s.metrics?.bad_escape_rate)],["Good reject",s=>percent(s.metrics?.good_reject_rate)],["Time",s=>duration(s.elapsed_seconds)],["Images / sec",s=>number(s.images_per_second,1)]],result.sessions||[]);
  $("session-compare-note").textContent=`${result.n_images} matched images · ${result.n_labeled} labeled. ${result.note||""}`;
});
(async()=>{try{setup(await api("/api/bootstrap"));modeChanged();renderWorkflowStages();await refresh();setInterval(refresh,3000);}catch(error){notify("Cannot start dashboard: "+error.message,true);}})();
