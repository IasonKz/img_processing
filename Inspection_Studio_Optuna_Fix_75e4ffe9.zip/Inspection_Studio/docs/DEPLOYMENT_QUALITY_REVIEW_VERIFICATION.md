# Deployment quality review verification — 2026-10-05

Environment: Linux, Python 3.12, CPU PyTorch, OpenCV, Node and system Chromium. Model outputs and image inputs used for these checks are synthetic. Windows, CUDA/DirectML and production defect accuracy were not evaluated.

## Backend and model evidence

```bash
python -m pytest -q tests/segmentation \
  tests/test_roi_geometry.py tests/test_roi_context.py tests/test_roi_project.py \
  tests/test_roi_learning.py tests/test_roi_dashboard.py tests/test_roi_classification.py \
  tests/test_roi_segmentation.py tests/test_workspace_studio.py \
  tests/test_deployment_review.py tests/test_v6_image_depth.py \
  tests/test_dashboard_preprocessing.py tests/test_untagged_preparation.py \
  tests/test_v3_decisions.py tests/test_v4_flow.py tests/test_v5_decision_lab.py \
  tests/test_v4_dashboard.py tests/test_v5_dashboard.py tests/test_v61_quality_dashboard.py
```

**341 passed, 1 skipped, 283 subtests passed.** This is one combined regression run. The skipped check requires optional ONNX and ONNX Runtime dependencies, which were absent from this environment.

Coverage includes physical-unit identity, all three views, conservative missing-view and ROI-only routing, native uint16 snapshots, source/index/unit checksum enforcement, cancellation preserving the previous snapshot, failed or inconsistent masks, one observation per physical unit, separate threshold contracts, selected/batch reports, portable native evidence, local HTTP access and authenticated requests. Mixed input folders classify only their identified VIG captures under a VIG recipe.

The ROI round trip runs a real one-epoch CPU crop segmentation study and prediction. Its prediction records are checked for inherited unit identity/split, exact native source copies, original full images, geometry masks and pixel probability/count summaries. The resulting segmentation records can be consumed by the quality-review evidence loader. Existing exported standalone segmentation prediction and classification decision/system/workflow tests remain covered.

## Browser workflows

```bash
STUDIO_PYTHON=/path/to/python \
STUDIO_BROWSER_EXECUTABLE=/path/to/chromium \
  node tests/browser_deployment_review.cjs /tmp/deployment-review-evidence

STUDIO_PYTHON=/path/to/python \
STUDIO_BROWSER_EXECUTABLE=/path/to/chromium \
  node tests/browser_roi_workflow.cjs /tmp/roi-regression-evidence
```

Both workflows use actual loopback APIs, temporary projects and managed workers, without route interception. The quality-review workflow checks unit selection, cross-inspection snapshot changes, explicit evidence linking, TOP/BOTTOM/VIG previews, model masks, native downloads, keyboard navigation, score margins, cohort percentiles, filters and optional selected-unit/batch report exports. Desktop, laptop and narrow layouts are checked for horizontal overflow and browser errors. The existing shared ROI annotation workflow also passes.

The four JavaScript behavior suites (`test_roi_ui.cjs`, `test_v4_ui.cjs`, `test_v5_ui.cjs`, `test_v61_quality_ui.cjs`) pass. Package verification confirms that the new Python modules and dashboard JavaScript/CSS are included in the wheel. Source release checks include an English-only audit and archive/manifest integrity.

## Interpretation limits

The completed checks establish data preservation, evidence linkage, calculations and operator workflows. They do not establish calibrated unit certainty or production inspection performance. Linked TOP/BOTTOM runs must belong to the same inspection batch; unit-name matching alone does not prove acquisition identity across batches. The frozen deployment runner remains VIG-only. Representative data and an explicit combined recipe are still required for a qualified TOP/BOTTOM/VIG production verdict.

See [Deployment quality review](DEPLOYMENT_QUALITY_REVIEW.md) for operator controls, routing rules and report files.
