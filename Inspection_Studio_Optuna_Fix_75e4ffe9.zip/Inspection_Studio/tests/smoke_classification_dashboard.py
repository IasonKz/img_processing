"""Real dashboard-to-worker Optuna training with a pretrained ResNet18 on CPU.

Uses synthetic images and a new output directory. Public pretrained weights are
downloaded only when --allow-download is supplied; model accuracy is not assessed.
"""
import argparse
import csv
from http.server import ThreadingHTTPServer
import json
from pathlib import Path
import sys
import threading
import time
from urllib.request import Request, urlopen

import numpy as np
from PIL import Image
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from nilt.common import load_project, read_json, sha_file, write_json
from nilt.dashboard import Dashboard, make_handler
from nilt.engine import check_weights


def run(output, weights, allow_download=False):
    output.mkdir(parents=True, exist_ok=False)
    data = output/'data'
    for label, lower in (('bad', 10), ('good', 120)):
        for index in range(20):
            pixels = np.random.default_rng(index + lower).integers(lower, lower + 80, (32, 32, 3), dtype=np.uint8)
            path = data/label/f'C00000083_Rc{1 if label == "bad" else 2:02d}Cc{index+1:02d}_vig.png'
            path.parent.mkdir(parents=True, exist_ok=True)
            Image.fromarray(pixels).save(path)
    profile_settings = {'device': 'cpu', 'models': ['resnet18'], 'seeds': [42], 'ensembles': False,
        'search': {'total_budget_seconds': 120, 'max_trials_per_model': 1, 'min_finetune_epochs': 1,
            'minimum_trial_seconds': .01, 'enqueue_presets': False, 'pruner': 'none',
            'space': {'mode': ['head_only'], 'optimizer': ['adamw'], 'scheduler': ['constant'],
                'imbalance': ['none'], 'learning_rate': 1e-5, 'head_learning_rate': 2e-5,
                'weight_decay': 1e-6, 'effective_batch_size': [2], 'warmup_epochs': [0]}},
        'training': {'epochs': 1, 'warmup_epochs': 0, 'amp': False}}
    config = output/'project.yaml'
    config.write_text(yaml.safe_dump({'paths': {'weights_root': str(weights)},
        'defaults': {'image_size': 32, 'cpu_threads': 1, 'num_workers': 0, 'near_duplicate_distance': -1,
                     'export_images': False, 'download_missing_weights': allow_download},
        'profiles': {'laptop': profile_settings, 'workstation': profile_settings},
        'tasks': {'vig': {'dataset_root': './data'}}}), encoding='utf-8')
    cfg = load_project(config, task='vig')[0]
    check_weights(cfg)
    app = Dashboard(config)
    server = ThreadingHTTPServer(('127.0.0.1', 0), make_handler(app))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f'http://127.0.0.1:{server.server_port}'
    records = []

    def request(endpoint, payload=None):
        headers = {'X-Inspection-Token': app.token, 'Origin': base}
        body = json.dumps(payload).encode() if payload is not None else None
        if body is not None:
            headers['Content-Type'] = 'application/json'
        with urlopen(Request(base+endpoint, data=body, headers=headers), timeout=20) as response:
            return json.load(response)

    try:
        for profile in ('laptop', 'workstation'):
            for mode in ('profile', 'custom'):
                payload = {'action': 'search', 'task': 'vig', 'profile': profile,
                           'models': ['resnet18'], 'hours': 120/3600}
                if mode == 'custom':
                    payload['custom'] = request('/api/v5/defaults?profile='+profile+'&task=vig')
                job_id = request('/api/action', payload)['job']
                deadline = time.monotonic() + 150
                while time.monotonic() < deadline:
                    job = next(job for job in request('/api/state')['jobs'] if job['id'] == job_id)
                    if job['status'] not in ('running', 'unverified'):
                        break
                    time.sleep(.2)
                else:
                    raise RuntimeError(f'{profile}/{mode}: training timeout')
                if job['status'] != 'finished' or job.get('exit_code') != 0:
                    raise AssertionError(f'{profile}/{mode}: {job}')
                run_path = Path(job['run'])
                with (run_path/'trials.csv').open(encoding='utf-8-sig', newline='') as stream:
                    trials = list(csv.DictReader(stream))
                assert len(trials) == 1 and trials[0]['state'] == 'COMPLETE', trials
                trial = run_path/'search/resnet18/trial_00000'
                completed = read_json(trial/'completed.json')
                assert completed['epochs_ran'] == 1
                assert sha_file(trial/'best.pt') == completed['checkpoint_sha256']
                with (trial/'history.csv').open(encoding='utf-8-sig', newline='') as stream:
                    history = list(csv.DictReader(stream))
                assert len(history) == 1 and float(history[0]['head_lr']) > 0
                assert np.isfinite(float(history[0]['train_loss']))
                persisted = Path(job['command'][job['command'].index('--config')+1])
                actual = load_project(persisted, profile=profile, task='vig')[0]
                assert isinstance(actual['training']['learning_rate'], float)
                records.append({'profile': profile, 'mode': mode, 'device': 'cpu', 'model': 'resnet18',
                    'pretrained': actual['pretrained'], 'trial_state': trials[0]['state'],
                    'epochs': completed['epochs_ran'], 'head_learning_rate': float(history[0]['head_lr']),
                    'source_learning_rate': actual['training']['learning_rate'], 'run': str(run_path)})
                print(f'PASS: {profile}/{mode} completed real pretrained CPU Optuna training.', flush=True)
        write_json(output/'verification.json', {'status': 'passed', 'input': 'synthetic', 'results': records,
            'not_tested': ['Production accuracy', 'Windows', 'CUDA', 'DirectML']})
    finally:
        if any(job['status'] in ('running', 'unverified') for job in app.jobs):
            app.stop_workers({'mode': 'force'})
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
    return records


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True, help='New directory for synthetic data, runs and verification.')
    parser.add_argument('--weights-dir', type=Path, required=True, help='Pretrained weight cache.')
    parser.add_argument('--allow-download', action='store_true', help='Allow verified official pretrained weight downloads.')
    args = parser.parse_args()
    run(args.output.resolve(), args.weights_dir.resolve(), args.allow_download)
