"""Portable, explicit whole-image preprocessing shared by training and deployment."""
from __future__ import annotations

import math
from PIL import Image, ImageOps

MEAN = [0.485, 0.456, 0.406]
STD = [0.229, 0.224, 0.225]
PAD_COLOR = (124, 116, 104)
PATCH_DEFAULTS = {"size": 256, "overlap": 64, "max_patches": 64, "chunk_size": 4,
                  "aggregation": "max", "topk": 3, "global_weight": .5}


def validate_patch_settings(cfg):
    """Validate native-pixel, image-label MIL settings without importing torch."""
    if cfg.get("image_strategy", "full_image") not in ("full_image", "global_patches"):
        raise ValueError("image_strategy must be full_image or global_patches.")
    raw = cfg.get("patches", {})
    if not isinstance(raw, dict) or set(raw) - set(PATCH_DEFAULTS):
        raise ValueError("Unknown patch settings; use size, overlap, max_patches, chunk_size, aggregation, topk, global_weight.")
    result = {**PATCH_DEFAULTS, **raw}
    for key, minimum in (("size", 32), ("overlap", 0), ("max_patches", 1), ("chunk_size", 1), ("topk", 1)):
        value = result[key]
        if not isinstance(value, int) or isinstance(value, bool) or value < minimum:
            raise ValueError(f"patches.{key} must be an integer >= {minimum}.")
    if result["overlap"] >= result["size"]:
        raise ValueError("patches.overlap must be smaller than patches.size.")
    if result["aggregation"] not in ("max", "topk"):
        raise ValueError("patches.aggregation must be max or topk.")
    weight = result["global_weight"]
    if isinstance(weight, bool) or not isinstance(weight, (int, float)) or not math.isfinite(weight) or not 0 < weight < 1:
        raise ValueError("patches.global_weight must be strictly between 0 and 1 so both branches contribute.")
    return result


def patch_boxes(width, height, settings):
    """Complete overlapping coverage, including borders; never sample/drop evidence.

    Coordinates cover the native-pixel padded global canvas. Patches smaller than
    size (when the entire canvas is smaller) are padded, never resampled.
    """
    if any(not isinstance(v, int) or isinstance(v, bool) or v < 1 for v in (width, height)):
        raise ValueError("Patch canvas dimensions must be positive integers.")
    settings = validate_patch_settings({"image_strategy": "global_patches", "patches": settings})
    size, stride = settings["size"], settings["size"] - settings["overlap"]
    def starts(length):
        last = max(0, length - size)
        values = list(range(0, last + 1, stride))
        if values[-1] != last:
            values.append(last)
        return values
    xs, ys = starts(width), starts(height)
    count = len(xs) * len(ys)
    if count > settings["max_patches"]:
        raise ValueError(f"Complete image coverage requires {count} patches but max_patches={settings['max_patches']}. "
                         "Increase max_patches or patch size, or reduce overlap. No patches were silently omitted.")
    return [(x, y, min(x + size, width), min(y + size, height)) for y in ys for x in xs]


def rotate_quarter_turn(image, k):
    """Exact 90-degree rotation with every original pixel preserved.

    A non-square image swaps width and height for odd k. Padding is applied only
    afterwards; no interpolation, corner crop, reflected pixels or relabeling.
    """
    if not isinstance(k, int) or isinstance(k, bool):
        raise ValueError("Quarter-turn count must be an integer.")
    method = {1: Image.Transpose.ROTATE_90, 2: Image.Transpose.ROTATE_180,
              3: Image.Transpose.ROTATE_270}.get(k % 4)
    return image.copy() if method is None else image.transpose(method)


def prepare_image(image, cfg):
    """Return an RGB square; pad never resamples or crops input pixels.

    ``fit`` is an explicit opt-in to aspect-preserving resampling. Images must
    already contain the intended inspection ROI. No detector or alignment step
    is inferred from image content.
    """
    size = cfg.get("image_size")
    if not isinstance(size, int) or isinstance(size, bool) or size < 32:
        raise ValueError("image_size must be a resolved integer >= 32.")
    mode = cfg.get("resize", "pad")
    if mode not in ("pad", "fit"):
        raise ValueError("Supported resize modes are pad and fit; resize-level tiling is unsupported. Use image_strategy=global_patches for MIL.")
    if cfg.get("preserve_native_resolution", False) and mode != "pad":
        raise ValueError("Native resolution preservation requires resize=pad.")
    image = ImageOps.exif_transpose(image).convert("RGB")
    if mode == "fit":
        scale = size / max(image.size)
        dimensions = (max(1, round(image.width * scale)), max(1, round(image.height * scale)))
        image = image.resize(dimensions, Image.Resampling.BILINEAR)
    elif max(image.size) > size:
        raise ValueError(
            f"Input image {image.size} exceeds image_size={size}. "
            "Increase image_size or explicitly select resize=fit; no automatic scaling is performed."
        )
    left, top = (size - image.width) // 2, (size - image.height) // 2
    return ImageOps.expand(image, (left, top, size - image.width - left, size - image.height - top),
                           fill=PAD_COLOR)
