[CmdletBinding()]
param(
    [string]$EnvironmentPath = '',
    [string]$OfflineWheelhouse = '',
    [ValidateRange(0, 1024)]
    [int]$Adapter = 0
)
$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
function Invoke-Checked {
    param([string]$Executable, [string[]]$Arguments)
    & $Executable @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Command failed ($LASTEXITCODE): $Executable $($Arguments -join ' ')" }
}
if (-not $EnvironmentPath) { $EnvironmentPath = Join-Path $env:USERPROFILE 'venvs\studio6-directml' }
$EnvironmentPath = [IO.Path]::GetFullPath($EnvironmentPath)
$PythonExe = Join-Path $EnvironmentPath 'Scripts\python.exe'
$MarkerPath = Join-Path $EnvironmentPath '.inspection-studio.json'
Push-Location $ProjectRoot
try {
    if (Test-Path -LiteralPath $EnvironmentPath) {
        if (-not (Test-Path -LiteralPath $MarkerPath)) { throw 'Choose a new environment path; this existing folder is not a Studio DirectML environment.' }
        $Marker = Get-Content -LiteralPath $MarkerPath -Raw | ConvertFrom-Json
        if ($Marker.application -ne 'Inspection Studio 6' -or $Marker.device -ne 'directml') {
            throw 'DirectML must use a separate environment. Choose a new -EnvironmentPath.'
        }
    } else {
        if (-not (Get-Command py -ErrorAction SilentlyContinue)) { throw 'Install 64-bit Python 3.12 with the Python launcher first.' }
        Invoke-Checked 'py' @('-3.12', '-c', 'import sys; assert sys.maxsize > 2**32')
        Invoke-Checked 'py' @('-3.12', '-m', 'venv', $EnvironmentPath)
        @{ application = 'Inspection Studio 6'; device = 'directml' } | ConvertTo-Json | Set-Content -LiteralPath $MarkerPath -Encoding UTF8
    }
    Invoke-Checked $PythonExe @('-c', 'import sys; assert sys.version_info[:2] == (3,12); assert sys.maxsize > 2**32')
    if ($OfflineWheelhouse) {
        $WheelhousePath = (Resolve-Path -LiteralPath $OfflineWheelhouse).Path
        Invoke-Checked $PythonExe @('-m', 'pip', 'install', '--no-index', '--find-links', $WheelhousePath, '-r', 'requirements-directml.txt')
    } else {
        Invoke-Checked $PythonExe @('-m', 'pip', 'install', '--upgrade', 'pip')
        Invoke-Checked $PythonExe @('-m', 'pip', 'install', '-r', 'requirements-directml.txt')
    }
    Invoke-Checked $PythonExe @('-m', 'pip', 'check')
    $Probe = @'
import sys, torch, torchvision
from nilt.devices import directml_devices
from nilt.engine import device_for
assert torch.__version__.split('+')[0] == '2.4.1'
assert torchvision.__version__.split('+')[0] == '0.19.1'
print('Available DirectML adapters:', directml_devices()[1])
device = device_for({'device':'directml:' + sys.argv[1], 'cpu_threads':4})
model = torchvision.models.resnet18(weights=None).to(device).eval()
x = torch.randn(2, 3, 64, 64).to(device)
loss = model(x).square().mean()
loss.backward()
assert bool(torch.isfinite(loss.detach().cpu()).all()), 'Nonfinite device output'
print('ResNet forward/backward probe passed on', device)
print('DirectML remains experimental; verify every selected architecture on your adapter.')
'@
    Invoke-Checked $PythonExe @('-c', $Probe, "$Adapter")
    Set-Content -LiteralPath (Join-Path $ProjectRoot '.studio-python.txt') -Value $PythonExe -Encoding UTF8
    & $PythonExe -m pip freeze | Set-Content -LiteralPath (Join-Path $ProjectRoot 'environment-installed.txt') -Encoding UTF8
    if ($LASTEXITCODE -ne 0) { throw 'Could not record installed versions.' }
    Write-Host 'Setup complete. Open Start.cmd, select DirectML in Custom search, then choose the adapter index.'
    Write-Host 'CPU and CUDA environments were not changed. Use Setup.cmd to switch the launch interpreter back.'
} finally { Pop-Location }
